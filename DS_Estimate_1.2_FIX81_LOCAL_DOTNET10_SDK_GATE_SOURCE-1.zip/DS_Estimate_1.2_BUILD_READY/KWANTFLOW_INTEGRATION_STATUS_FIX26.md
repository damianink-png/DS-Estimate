# Kwantflow → DS Estimate — status FIX26

Źródła porównane: DS Estimate 1.2 FIX20 (Biblioteka), FIX25 (ostatnia baza),
Kwantflow 0.13.0 (`kwantflow-main.zip`) i poprawka PDF R1.

- Kwantflow jest projektem GPL-3.0-only (LICENSE, package.json).
- FIX26 nie zawiera kodu Kwantflow; nie ma nowej zależności licencyjnej.
- Wprowadzono w Python/C# niezależny, addytywny ślad pochodzenia danych
  (pageEvidence) potrzebny do bezpiecznego powiązania PDF ↔ BOM ↔ STEP.
- Dopasowanie numerów rysunków do pozycji BOM, automatyczne przypisywanie
  materiałów i wycenę wg arkuszy pozostawiono wyłączone do czasu
  testów niejednoznaczności, rewizji i hierarchii złożeń.
- Zachowano wszystkie istniejące zależności, pliki licencyjne i oznaczenia autorów.
- Dystrybucja przyszłej wersji ze skopiowanym kodem GPL wymaga analizy
  obowiązków GPL i licencji pozostałych komponentów.
