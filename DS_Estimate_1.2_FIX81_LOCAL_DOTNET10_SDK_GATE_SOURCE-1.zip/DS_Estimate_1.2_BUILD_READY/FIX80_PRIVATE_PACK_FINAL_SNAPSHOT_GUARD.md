# DS Estimate 1.2 FIX80 — final source snapshot guard

FIX79 validated each file after hashing and extraction, but an early source could be modified or removed while later files or the ZIP itself were being processed. The generated manifest could then describe a stale mixed snapshot while the generator reported success.

FIX80 remembers each processed file's `(st_dev, st_ino, st_size, st_mtime_ns)` and checks all previously processed paths immediately before the atomic ZIP replacement. Changes, deletions and symlink substitutions fail closed with `SOURCE_CHANGED_DURING_PACK`; the last known-good ZIP is preserved and the temporary ZIP is removed.

This is a best-effort filesystem metadata consistency guard, not a transaction or an adversarial anti-tampering guarantee. It cannot rule out a race after the last check, or an edit with restored size, timestamp and file identity. It adds a final O(N) stat pass without rehashing source content. OCR, BOM, CNC, costing, STEP geometry and licensing are unchanged.

Regression: `python tests/run_fix80_private_pack_final_snapshot_guard.py` uses real CLI/ZIP, deterministic late edit/deletion, earlier-file mutation during later-file extraction, retry, hash and rollback checks, and verifies release gate wiring. It is not .NET/Windows/xUnit execution.
