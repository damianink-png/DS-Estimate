﻿## FIX35 — TRX UnitTestResult Discovery Guard — 2026-10-31

- Weryfikator wyników .NET CI w trybie `--require-results` wymaga rzeczywistych
  wpisów `UnitTestResult`, nie tylko deklaracji liczników w `Counters`.
- Porównuje liczbę wyników Passed z licznikiem passed, wymaga testId,
  odrzuca błędne wyniki i niekompletne sekcje Results; pominięte testy są dozwolone.
- Wsteczna zgodność: domyślny tryb licznikowy zachowany dla wcześniejszych testów.
- 20 nowych kontroli Python; bramki Windows/portable i workflow zaktualizowane.
- Brak zmian w runtime C# i silnikach Python. Kompilacja .NET/xUnit nadal niewykonana.

## FIX32 — STEP Empty-File Guard + .NET CI Workflow — 2026-10-31

- Diagnostyczne powiązanie PDF/BOM↔STEP odrzuca pliki STEP/STP o zerowym
  rozmiarze oraz zachowawczo obsługuje błędy odczytu metadanych pliku.
- Dodano 3 przypadki C# xUnit (nie uruchomiono — brak SDK .NET) i 11 statycznych
  kontroli Python; przygotowano Windows GitHub Actions (.NET 10, build, xUnit, TRX).
- Zachowano dotychczasowe funkcje i licencje; żadnej automatycznej zmiany wyceny.

## FIX31 — STEP Physical Filename Identity Guard — 2026-10-31

- Diagnostyczne dopasowanie PDF/BOM↔STEP używa rzeczywistej nazwy pliku z `ProjectDocument.Path`,
  a nie nazwy wyświetlanej `ProjectDocument.Name` (może mieć sufiks `[KONFLIKT N]`).
- Sprawdzanie rozszerzenia `.step`/`.stp` dotyczy również faktycznej ścieżki;
  etykieta UI nie może podszyć się pod inny plik STEP.
- Identyczne nazwy fizycznych plików w różnych katalogach pozostają niejednoznaczne;
  żadna część nie otrzymuje automatycznie materiału, ilości, operacji ani kosztu.
- Dodano cztery przypadki xUnit (bez uruchomienia, jeżeli brak .NET SDK) i skrypt FIX31:
  statyczne kontrakty C# oraz rzeczywisty dwustronicowy PDF i dwu-bryłowy STEP
  generowany przez CadQuery, analizowany przez istniejące silniki Python.
- Nie zmieniano kodu silników Python, cache, OCR, wyceny CNC, raportowania ani licencji;
  kodu Kwantflow nie kopiowano. Nadal brak weryfikacji geometrii względem rysunku.

## FIX29 — Exact PDF Drawing/BOM Link Hints — 2026-10-31

- Informacyjne powiązania numeru rysunku z pozycją BOM wyłącznie przy identycznym
  identyfikatorze i jednoznacznym wystąpieniu w obrębie jednego PDF.
- Przy wielokrotnych numerach na różnych arkuszach nie ma dopasowania; dodano
  ostrzeżenie. Nie ma dopasowań przy podobnych, ale różnych numerach.
- C# przechowuje powiązania, scala je bez łączenia różnych plików i wyświetla
  w raporcie diagnostycznym. Brak wpływu na ilości, materiały, CNC i ceny.
- Nowy test, bramki Windows/portable, inwalidacja cache. Kod Kwantflow niekopiowany.

## FIX28 — PDF Drawing IDs from CAD Title Blocks — 2026-10-31

- Rozpoznawanie numerów rysunków bez dwukropka oraz w osobnym wierszu tabelki:
  DRAWING NO, DWG NO, NUMER RYSUNKU, NR RYS., ZEICHNUNGS-NR.
- Konserwatywne filtry eliminują daty, gatunki stali, krótkie wymiary i normy.
  Rozpoznane identyfikatory pozostają informacyjne i przypisane do konkretnego arkusza.
- Dodano testy syntetyczne i integracyjne na rzeczywistym PDF, aktualizację
  cache oraz bramki Windows i portable. Bez zmian wyceny CNC, STEP i BOM.
- Nie skopiowano kodu Kwantflow; pliki licencyjne pozostają bez zmian.

## FIX27 — PDF Page Text Fusion & Provenance — 2026-10-31

- Zachowano tekst strony rozpoznany przez pypdf, nawet gdy PyMuPDF nie odzyskał
  numeru rysunku, materiału lub pozycji BOM z tego samego arkusza.
- Łączenie wyników ekstraktorów odbywa się wyłącznie w obrębie zgodnych indeksów
  stron. Przy rozbieżnej liczbie stron dane pypdf pozostają w analizie globalnej,
  ale nie są przypisywane do arkuszy MuPDF; pojawia się ostrzeżenie.
- Fallback pypdf-only działa również po błędzie PyMuPDF. Zachowano istniejące
  reguły OCR, budżet pamięci, STEP, BOM i silnik kalkulacji CNC.
- Dodano testy regresyjne z rzeczywistym PDF i symulowaną częściową ekstrakcją,
  testy rozbieżnej liczby stron oraz bramki wydania Windows/portable.
- Zmieniono wersję cache dokumentów, aby ponownie analizować stare pliki PDF.
- Nie skopiowano kodu Kwantflow (GPL-3.0); pełna kompilacja .NET nadal wymaga SDK.

## FIX26 — PDF Page Evidence & BOM Traceability — 2026-10-31

- Zapis pochodzenia danych z PDF wg numeru arkusza: numery rysunków, gatunek z tabelki,
  referencja materiałowa, sygnały BOM, normy oraz status OCR na konkretnej stronie.
- Ostrzeżenie o różnych materiałach na arkuszach bez automatycznego przypisania do BOM.
- Rozdzielone teksty OCR i BOM pomiędzy stronami; raport diagnostyczny pokazuje źródła.
- Jednorazowa ekstrakcja tekstu układu i tabelki dla każdego arkusza, bez powtórnych przebiegów.
- Inwalidacja cache dokumentów; nowy test i bramki Windows/portable.
- Brak zmian w algorytmach wyceny CNC/STEP i brak skopiowanego kodu Kwantflow.
- Nie wykonano pełnej kompilacji .NET; testy Python i rzeczywisty OCR wykonano osobno.

## FIX23 — PDF Tiled & Inline Raster Detection — 2026-10-30

- Wykrywanie zeskanowanych arkuszy rozbitych na wiele małych kafelków oraz obrazów inline (BI/ID/EI).
- Suma pokrycia obrazu uwzględnia tylko unikalny obszar strony (bez podwójnego liczenia nakładających się grafik), przycięty do granic arkusza.
- Limit analizy 512 największych obrazów na stronę chroni przed nieograniczonym kosztem; przypadki z większą liczbą drobnych kafelków mogą wymagać dalszej poprawy.
- Zachowano progi detekcji, limit stron OCR, limit pamięci, szybki import i fallback starszych wersji PyMuPDF.
- Nowy test FIX23 (syntetyczne i rzeczywiste PDF), bramka wydania i build; zmieniono przestrzeń nazw cache PDF.
- Naprawiono odziedziczony FAIL testu FIX16D: test FIX20 używa CadQuery/OCP i musi bezpiecznie kończyć proces natywny; lista testów natywnych jest kompletna.
- Nie kopiowano kodu Kwantflow (GPL-3.0); rozwiązanie niezależne, bez zmiany licencji DS Estimate.
- Bez zmian w silnikach CNC, STEP, BOM i kalkulacji kosztów.

## FIX22 — Mixed PDF Scanned Sheet Coverage — 2026-10-30

- Dla PDF z bogatą warstwą tekstową wykrywamy osobno arkusze z małą ilością tekstu i dużym obrazem rastrowym.
- Takie arkusze uruchamiają uzupełniający OCR i mają pierwszeństwo w ograniczonym budżecie stron OCR.
- Małe logotypy i pieczątki nie uruchamiają OCR; jawny tryb szybkiego importu nadal go wyłącza.
- Raportujemy numery rastrowych stron pominiętych po wyczerpaniu limitu.
- Wersja cache analizy PDF została zmieniona, żeby nie używać starego wyniku.
- Dodano testy jednostkowe i rzeczywisty PDF mieszany do bramki testów i builda.
- Brak zmian w silnikach CNC, STEP, BOM i kalkulacji kosztów.

## FIX21 — PDF OCR Raster Memory Budget — 2026-10-30

- Usunięto minimalny zoom 1.15x, który mógł przekraczać limit pikseli na dużych arkuszach PDF.
- Wprowadzono adaptacyjne skalowanie z zapasem na zaokrąglenia MuPDF.
- Dodano test z rzeczywistą rasteryzacją oraz włączono go do bramki wydania i builda.
- Bez zmian w wycenie CNC, STEP, BOM i licencjach komponentów.

## FIX20 — Open-source Integrations — 2026-09-21

- Po audycie kodu OpenMill dodano konserwatywne wykrywanie kandydatów kieszeni bezpośrednio na ścianach BREP CadQuery/OCC.
- Kandydaci kieszeni przechodzą przez checkpoint, cache, agregację złożeń, raport oraz model złożoności CNC.
- Dodano opcjonalną integrację API Docling dla kolejności tekstu i struktury dokumentów; dotychczasowe lekkie parsery pozostają bezpiecznym fallbackiem.
- Zapisano pochodzenie, commity i licencje Docling, OpenMill, CadQuery, build123d oraz PDFMathTranslate-next.
- Kod AGPL PDFMathTranslate-next nie został włączony do aplikacji.

## FIX19 — Document Intelligence & Release Gate Repair — 2026-09-21

- OCR wielostronicowych PDF obejmuje reprezentatywne strony z całego dokumentu, zawsze pierwszą i ostatnią, bez zwiększania limitu pamięci/czasu.
- Diagnostyka pokazuje numery stron rzeczywiście poddanych OCR.
- Cache analiz dokumentów ma nową wersję, więc starszy wynik nie maskuje ulepszonej logiki.
- Naprawiono fałszywy FAIL kontroli odcisku zatwierdzonego wyjątku w teście FIX18.
- Usunięto zdublowaną funkcję wektorową z silnika STEP i dodano bramkę regresyjną FIX19.

## FIX18 — Release Safety — 2026-09-14

- Limit pamięci działa podczas pojedynczego zadania STEP i zachowuje ścieżkę wznowienia.
- Eksport XLSX ma twardą bramkę kompletności oraz audytowany wyjątek związany z odciskiem stanu.
- Eksport zapisuje zamrożony snapshot SHA-256 wszystkich warstw wejściowych i obliczeniowych.
- Kalibracja ma chronologiczny split rodzin, ochronę rewizji, bias, P90 i rolling backtest.
- Dodano panel zdrowia .NET/Python/STEP/OCR/DWG/dokumentów/RAM i restart bezczynnego STEP workera.
- Dodano walidator i pusty szablon golden setu firmy (minimum 20 realnych projektów).
- Build testuje cold/warm/corrupt/key-change i generuje raporty FIX18 bez usuwania zgodności FIX17.

## FIX17 — Build Resume & Runtime Health — 2026-09-14

- Dodano content-addressed cache .NET i Python/CAD z pełnym manifestem SHA-256.
- Cache .NET/Python jest zatwierdzany dopiero po kontroli artefaktu EXE i realnym smoke teście importów.
- Modele OCR są cache'owane; pełne testy wydania i kompletności portable nie są pomijane.
- Raport TXT/JSON powstaje po sukcesie i po błędzie builda.
- Persistent STEP worker ma kontrolowany recykling po liczbie zadań, czasie i pamięci.
- Kalibracja firmowa ma deterministyczny train/holdout oraz blokadę regresji MAPE.
- Dodano kompaktową macierz gotowości wyceny z przejściem do właściwych szczegółów.
- Materiał nierozpoznany/założony pozostaje w macierzy do sprawdzenia nawet wtedy, gdy model wyliczył jego koszt.
- Dodano test FIX17 do obu bramek wydania.
- Obie pełne bramki uruchamiają teraz projekt xUnit przez `dotnet test`, więc testy C# nie są już wyłącznie statycznie obecne w źródłach.

## FIX16E — STEP Worker Shutdown Fix — 2026-08-28

- Naprawiono timeout po dwóch poprawnych odpowiedziach persistent STEP workera.
- Zabezpieczono zamykanie produkcyjnych `step_worker.py`, `analyze_step.py` oraz
  `prescan_step_batch.py` przed zawieszeniem/0xC0000005 finalizatorów OCP.
- Test protokołu ma kontrolowany limit 60 s na cold start, dwa zadania i quit;
  usunięto bezterminowy `readline()` oraz zbyt krótki `wait(5)`.
- Rzeczywiste błędy procesu nadal zatrzymują bramkę.

## FIX16D — Native Test Shutdown Fix — 2026-08-27

- Naprawiono `0xC0000005` po prawidłowym wyniku 17/17 testu R9.0.7.
- Zabezpieczono wszystkie cztery testy ładujące CadQuery/OCP bezpośrednio,
  włącznie z procesami potomnymi pełnego stress-testu.
- Rzeczywisty PASS/FAIL i timeout nadal są egzekwowane; pomijana jest wyłącznie
  wadliwa finalizacja biblioteki natywnej po zakończeniu kontroli.
- Dodano automatyczną kontrolę importów natywnych i kodów procesu.

## FIX16C — Embedded Python Exit Fix — 2026-08-26

- Naprawiono fałszywy błąd bramki po `PARAMETRIC PASS=61 FAIL=0`.
- `run_r7_parametric.py` zwraca teraz rzeczywisty wynik testów bez uruchamiania
  niestabilnych finalizatorów CadQuery/OCP w embedded Python.
- Zachowano kod 1 dla prawdziwych błędów i kod 2 przy braku silnika CadQuery.
- Dodano kontrolę FIX16C do release gate i portable build gate.
- Komunikat awarii bramki podaje teraz także natywny kod procesu testu.

## FIX16B — Compile Fix — 2026-08-26

- Usunięto CS0136 w `ProjectAnalysisService.ParseRevision`: zmienne specjalnej
  gałęzi rewizji klienta mają teraz odrębne nazwy zakresowe.
- Dodano test `run_fix16b_compile_guard.py` do release gate i portable build gate.
- Zachowano komplet zmian FIX16A Reliability Hardening i FIX16 Decision Support.

## FIX16A — Reliability Hardening — 2026-08-26
- Mnożniki `calibration.json` są null-safe, normalizowane i niewrażliwe na wielkość liter.
- Profil bez wersji/daty jest odrzucany, a nieobsługiwany schemat nie jest po cichu zastępowany profilem domyślnym.
- Kalibracja mieszanego materiału jest ważona kosztem gatunków, nie wyłącznie ich masą.
- What-if nie przepuszcza `NaN`/`Infinity` i zachowuje znak narzutu zgodny z właściwą wyceną.
- Usunięto fałszywe rozpoznanie niemieckiego `Kanten` jako gięcia; pozostają precyzyjne `Abkanten/Biegen`.
- Hash analizatorów dokumentów obejmuje także parser tabelaryczny.
- Neutralne współczynniki technologiczne nie zostały zmienione.

## FIX16 — Decision Support / Trust Hardening — 2026-08-26
- Naprawiono realne użycie `MaterialMultipliers`, dystrybucję `config/calibration.json` oraz kolejność model fizyczny → historia → kalibracja zewnętrzna.
- Kalibracja jest idempotentna; nie może narastać po ponownym przeliczeniu ani nadpisywać ręcznych godzin.
- Profile przyszłe, niepoprawne albo nie-neutralne bez `GoldenSetId`/`ChangeReason` są bezpiecznie odrzucane.
- Ręczne przeliczenie zachowuje historyczny blend ceny.
- Dodano what-if dla ceny materiału i czasu procesów, bez ponownego STEP/OCR i bez nadpisywania P50.
- Dodano konserwatywne wykrywanie gięcia/walcowania oraz rozwinięcia; brak danych i stawki pozostaje jawną pozycją nieujętą w cenie.
- UI, XLSX i raport pokazują scenariusze, następną czynność, patch oraz hashe silników.
- Pełny true-shape nesting i automatyczne rozwijanie blach pozostają poza zakresem DS Estimate do czasu integracji zweryfikowanego CAD/CAM.

## FIX15 — Trust Foundation
- Golden set: bias + MAPE zamiast samego pass/fail.
- Wersjonowany `calibration.json` oddzielony od modelu fizycznego.
- Nie-neutralna kalibracja wymaga `GoldenSetId` i `ChangeReason`.
- Audytowalny `MeasuredValue<T>`: wartość, źródło, evidence, confidence, scope, authority, validation i calibration.
- Jawne P50 + zakres ryzyka w UI, Excelu i raporcie.
- Ostrzeżenia o wieku cenników.
- Brak strojenia pod TEST19/TEST49 w tej wersji.

## FIX14 ALL-IN — STABILITY + PARTIAL QUOTE + PROJECT RECONSTRUCTION — 2026-08-25
- Dodano Resource Governor i globalne ograniczenie ciężkich workerów, aby OCR/STEP nie doprowadzały Windows do swap-storm/OOM.
- OCR A0/A1 jest przetwarzany strona-po-stronie z limitem megapikseli i watchdogiem procesu.
- Historia działa domyślnie w bezpiecznym trybie bez OCR skanów, ma prawdziwe anulowanie i snapshoty na dysku zamiast trzymania wszystkich pełnych analiz w RAM.
- Dodano source-free crash package z etapem, wyjątkiem i telemetrią pamięci.
- Mass Reconstruction 2.0 liczy masę per rodzina root BOM także bez pełnego STEP; częściowa rekonstrukcja może zasilić koszt rozpoznanego materiału, ale nie odblokowuje pełnej ceny.
- Zamiast `0 PLN` przy zablokowanej wycenie UI/raport/Excel pokazują `NIE WYZNACZONO` i osobny koszt rozpoznanego zakresu.
- NDT i strefy powłok pozostają lokalne per rodzina; CNC grupuje setup/programowanie dla podobnych rodzin.
- Dodano Sanity Check Engine oraz pełny audyt FIX14 w raporcie.
- Nie zmieniano współczynników technologicznych pod TEST19/TEST49.

## FIX13A HARDENING
- trwałe ręczne override procesów i prawdziwy reset do automatyki
- AUTO/DOKUMENT/HISTORIA/RĘCZNIE w procesach
- checkpoint/wznowienie dużej analizy przez istniejący content-hash cache
- audyt override/checkpoint w raporcie
- bez zmian współczynników technologicznych

# 1.2 FIX12E HYBRID PROJECT RECONSTRUCTION — 2026-08-24
- Powierzchnia malowania nie wymaga kompletnego STEP: jest składana per rodzina z jawnej powierzchni, lokalnego STEP, DXF+grubość, profili/BOM lub bezpiecznego fallbacku masowego.
- Ta sama rodzina ma jedno najlepsze źródło, więc STEP/DXF/BOM nie są podwójnie sumowane.
- Częściowy STEP nie może narzucić 0,568 m² jako powierzchni całego projektu.
- Raport pokazuje pokrycie rodzin, udział źródeł i pewność powierzchni.
- Brak masy/podstawy materiałowej blokuje cenę ofertową; koszt rozpoznanych operacji pozostaje diagnostyczny.
- Lokalne różnice materiałów i wymiarów spoin nie zwiększają globalnego konfliktu projektu.
- Eksport XLSX i główne UI używają bezpiecznej ceny AutoQuote.

# 1.2 FIX12D DOCUMENT FAMILY RESOLVER — 2026-08-24
- Dodano hierarchiczny resolver root BOM → podzespoły → detale na podstawie numerów rysunków 8–14 cyfr.
- PDF/DXF/STEP spoza potwierdzonego drzewa root BOM nie wpływają globalnie na cięcie, materiał, spawanie ani masę.
- Twarde filtrowanie włącza się dopiero po potwierdzeniu root BOM przez realne rodziny dokumentów; słaby OCR działa tylko w trybie AUDIT_ONLY.
- Przy kilku niezależnych root BOM-ach resolver nie wybiera arbitralnie jednego projektu.
- Częściowy STEP nie jest już traktowany jako masa całego projektu ani jako PROJECT_TOTAL w Evidence Orchestrator.
- Materiały różnych pozycji są dowodami lokalnymi PART zamiast fałszywego konfliktu globalnego.
- Oznaczenia A20:/A40:/A41: z legend ISO/NDT nie są interpretowane jako a20/a40/a41 spoiny; prawidłowe symbole a4/a6 pozostają obsługiwane.
- Największa masa w hierarchicznym BOM-ie pozostaje SUBASSEMBLY, jeśli nie ma jawnej etykiety TOTAL/GESAMT.
- Pakiet prywatny V2 zachowuje wartości dziesiętne kosztów/godzin i dodaje anonimowe ENTITY_ID do korelacji dokumentów.
- Raport diagnostyczny zawiera osobną sekcję FIX12D z pokryciem BOM/STEP/DXF i statusem egzekwowania scope.

# 1.2 FIX12A TABLE SEMANTICS — 2026-08-24
- Parser tabelek PDF/DXF rozpoznaje `CAD Masse / CAD mass / Masse CAO (Kg)` także wtedy, gdy jednostka jest w nagłówku, a wartość (np. 138) w osobnej komórce.
- Wartości procentowe z sąsiednich pól (np. `Welds 0.000 %`) nie mogą zostać pomylone z masą.
- `Werkstoff / Material / Matière` rozdziela teraz fizyczny gatunek materiału od kodu/specyfikacji klienta.
- Kody typu `LH350CAT2-LH11657002` są zachowywane diagnostycznie jako `MaterialReference`, ale nie wpływają na gęstość, koszt ani wybór materiału.
- Rozszerzono rozpoznawanie typowych gatunków (m.in. 42CrMo4, C45, 16MnCr5, P265GH/P355, S420/S460/S700/S890).
- Dodano regresje wektorowego PDF i DXF dla masy 138, kodu materiałowego oraz pasowania `Ø90 F8/h9`.

# 1.2 FIX12A — 2026-08-23
- Dodano Contract-First model CAPP: `UniquePartGroup`, `AssemblyState`, `ProcessNode`, `EvidenceBinding`, `ConfidenceVector`.
- Dodano `AssemblyStateGraphBuilder` działający jako Shadow Pipeline obok FIX11; `HasPriceAuthority=false`.
- Graf rozróżnia stan geometrii przed i po spawaniu; POST_WELD CNC dziedziczy gabaryt i masę całego złożenia.
- Evidence binding zachowuje nierozwiązane cele jako kandydatów zamiast wymuszać globalne przypisanie.
- Dodano wielowymiarową pewność Existence/Binding/Geometry/Parameters oraz pochodną Cost Confidence.
- Dodano shadow reality-checks dla częściowego scope DXF i skrajnie małej automatycznej powierzchni malowania.
- Raport diagnostyczny pokazuje FIX11 vs FIX12A Dual-Run bez wpływu FIX12A na cenę.
- Dodano `run_fix12a_shadow_graph.py` i testy xUnit FIX12A.

# 1.2 FIX11 — 2026-08-23
- Routing technologiczny rozpoznaje jawne `AFTER WELDING` / `POST-WELD` i ustawia `Spawanie → CNC`.
- Dobór stanowiska CNC dla obróbki po spawaniu używa gabarytu i masy całego złożenia, nie największego luźnego detalu.
- Sama tolerancja/chropowatość potwierdza potrzebę CNC, ale nie podnosi już automatycznie pewności czasu CNC do 94%.
- Globalny sygnał obróbki po spawaniu nie rozszerza już topologicznie CNC na wszystkie złożone bryły STEP.
- Zmierzony DXF ma jawne pokrycie rodzin detali; niepokryte blachy są liczone fallbackiem STEP.
- Ekstremalny współczynnik nestingu prostokątnych obwiedni obniża pewność i generuje ryzyko do weryfikacji CAM.
- Automatyczna powierzchnia malowania <20% powierzchni brutto obniża pewność pola i generuje ryzyko kontroli wnętrz/komór.
- Model niepewności uwzględnia post-weld CNC, częściowe pokrycie DXF, ekstremalny nesting i nietypowo małą powierzchnię malowania.
- Dodano `run_fix11_technology_scope.py` oraz testy zachowania xUnit dla nowych przypadków.

# 1.2 — 2026-08-23
- Główna wycena uproszczona z 5 zakładek do 2: `Wycena` i `Szczegóły`.
- `Wycena` łączy kluczowe cechy, edycję procesów i kompaktowe podsumowanie kosztu.
- Główne KPI skupiają się na otworach, otworach pasowanych/tolerowanych, spoinach, malowaniu i czasie procesów.
- Rozbudowany routing, BOM/Rule Engine, pełna struktura kosztów i plan-vs-wykonanie nie są już na głównym ekranie.
- Ustawienia codzienne ograniczone do stawek i narzutu; reszta pod `Tryb ekspercki`.
- Silnik staged analysis/Hole Engine/CNC z 1.1 pozostaje bez regresji.

# 1.1 — 2026-08-22
- Staged STEP checkpoints, progress-aware watchdog, Hole Engine 3.0, topology-only CNC disabled, incremental process recalculation.

## 1.2 FIX12B COST REALITY — 2026-08-24
- Skrajny/mało pewny nesting bbox nie ma już automatycznej władzy nad ceną materiału; stosowany jest firmowy naddatek materiałowy.
- Masa PDF/DXF o zasięgu UNKNOWN pozostaje lokalnym kandydatem i nie jest porównywana z masą całego STEP.
- Warianty tej samej rodziny S355 na różnych pozycjach nie są automatycznie konfliktem całego projektu.
- Dodano osobne operacje przygotowania ręcznego 3302, przygotowania maszynowego 3303 i ręcznych operacji CNC 3205.
- CNC uwzględnia programowanie/oprzyrządowanie per unikalna obrabiana rodzina.
- Montaż korzysta z modelu Fabrication Complexity: części + styki + ciężar + gabaryt.
- Wymagana kooperacja bez stawki zmienia wycenę na NIEPEŁNĄ / CENĘ CZĘŚCIOWĄ zamiast pełnej ceny rekomendowanej.
- Dodano regresję `run_fix12b_cost_reality.py` i testy zachowania `Fix12BCostRealityTests.cs`.

## FIX13 — Historical Intelligence
- Kalibracja procesów na podobnych zakończonych projektach z ochroną manual override.
- Materiały i półfabrykaty per rodzina/BOM, opcjonalne stawki per gatunek.
- Spoiny per rodzina zamiast jednego globalnego największego a/z.
- Strukturalny CNC Feature Model i confidence z następną czynnością.
- Kompletność systemu powłok oraz rozszerzony audyt FIX12E.
- Hierarchia BOM zachowuje poziomy i lokalne dowiązania STEP.
- Usunięto przycisk prywatnego eksportu z głównego UI.
- Dodano testy FIX13 i rozszerzono release gate.
