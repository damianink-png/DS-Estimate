﻿param([switch]$KeepDiagnosticCache)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$cacheRoot = Join-Path $env:TEMP ("DSE_FIX18_CACHE_CYCLE_" + [Guid]::NewGuid().ToString("N"))
$reportPath = Join-Path $PSScriptRoot "publish\BUILD_REPORT_FIX18.json"

function Run-BuildAndReadReport([string]$Label) {
    Write-Host "=== $Label ===" -ForegroundColor Cyan
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "BUILD_FULL_PORTABLE_ZIP.ps1") -FastBuild | Out-Host
    if ($LASTEXITCODE -ne 0) { throw "${Label}: build zakończony kodem $LASTEXITCODE" }
    if (-not (Test-Path -LiteralPath $reportPath)) { throw "${Label}: brak BUILD_REPORT_FIX18.json" }
    return Get-Content -LiteralPath $reportPath -Raw | ConvertFrom-Json
}

function Cache-Result($Report, [string]$Component) {
    return ($Report.Cache | Where-Object { $_.Component -eq $Component } | Select-Object -First 1).Result
}

try {
    New-Item -ItemType Directory -Force -Path $cacheRoot | Out-Null
    $env:DSE_BUILD_CACHE_ROOT = $cacheRoot

    $cold = Run-BuildAndReadReport "1/3 COLD"
    if ((Cache-Result $cold ".NET publish") -ne "MISS") { throw "COLD: .NET nie zgłosił MISS" }
    if ((Cache-Result $cold "Python/CAD runtime") -ne "MISS") { throw "COLD: Python nie zgłosił MISS" }

    $warm = Run-BuildAndReadReport "2/3 WARM"
    if ((Cache-Result $warm ".NET publish") -ne "HIT") { throw "WARM: .NET nie zgłosił HIT" }
    if ((Cache-Result $warm "Python/CAD runtime") -ne "HIT") { throw "WARM: Python nie zgłosił HIT" }

    $payload = Get-ChildItem -LiteralPath (Join-Path $cacheRoot "dotnet") -Recurse -File |
        Where-Object { $_.Name -notlike ".dse_cache_*" } |
        Select-Object -First 1
    if ($null -eq $payload) { throw "Brak pliku cache .NET do testu korupcji" }
    Add-Content -LiteralPath $payload.FullName -Value "FIX18_CORRUPTION_PROBE" -Encoding ASCII

    $corrupt = Run-BuildAndReadReport "3/3 CORRUPT"
    if ((Cache-Result $corrupt ".NET publish") -ne "MISS") { throw "CORRUPT: .NET nie odrzucił uszkodzonego cache" }
    Write-Host "[PASS] Rzeczywisty cykl cache: COLD MISS / WARM HIT / CORRUPT MISS." -ForegroundColor Green
}
finally {
    Remove-Item Env:DSE_BUILD_CACHE_ROOT -ErrorAction SilentlyContinue
    if (-not $KeepDiagnosticCache -and (Test-Path -LiteralPath $cacheRoot))
    {
        Remove-Item -LiteralPath $cacheRoot -Recurse -Force
    }
}
