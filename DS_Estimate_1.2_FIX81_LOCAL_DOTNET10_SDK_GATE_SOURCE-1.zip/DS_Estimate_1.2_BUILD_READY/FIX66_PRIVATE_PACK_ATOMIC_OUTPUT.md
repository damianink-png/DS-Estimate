# DS Estimate FIX66 — atomowy zapis prywatnego pakietu analitycznego

Punkt startowy: zweryfikowany pełny FIX65. Zmiana dotyczy wyłącznie
`engines/python/build_private_analysis_pack.py` i testów/workflow.

Wcześniej `ZipFile(out, "w")` natychmiast nadpisywał poprawny ZIP. Awaria
podczas zapisu mogła zniszczyć ostatni dobry pakiet. Teraz nowy ZIP
powstaje w tym samym katalogu jako plik tymczasowy, po zamknięciu jest
zastępowany atomowo przez `os.replace`, a w razie wyjątku plik tymczasowy
jest usuwany. Istniejący wynik pozostaje nietknięty.

Testy runtime wstrzykują awarię zapisu ZIP oraz awarię `os.replace`,
sprawdzają integralność poprzedniego ZIP, brak plików tymczasowych,
przypadek ponownego zapisu do folderu wejściowego i standardowy wynik.
Nie zmieniono silników kosztów, OCR, PDF, STEP, BOM, CNC, cache ani licencji.

Nie przeprowadzono kompilacji .NET 10, testów xUnit, TRX ani Windows CI.
