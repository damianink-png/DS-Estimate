@echo off
setlocal
cd /d "%~dp0"
echo === DS Estimate 1.2 - testy jednostkowe Core (xUnit) ===
dotnet test tests\DSEstimate.Core.Tests\DSEstimate.Core.Tests.csproj -c Release
if errorlevel 1 (
  echo.
  echo TESTY JEDNOSTKOWE: FAIL
  exit /b 1
)
echo.
echo TESTY JEDNOSTKOWE: OK
endlocal
