#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from collections import Counter
from pathlib import Path

from analyze_document import (result_from_text, configure_tesseract, choose_ocr_languages, run_technical_ocr)

ENTITY_GROUPS = {
    "LINE": "lines",
    "ARC": "arcs",
    "CIRCLE": "circles",
    "LWPOLYLINE": "polylines",
    "POLYLINE": "polylines",
    "SPLINE": "splines",
    "ELLIPSE": "ellipses",
    "HATCH": "hatches",
    "INSERT": "inserts",
    "DIMENSION": "dimensions",
    "TEXT": "textEntities",
    "MTEXT": "textEntities",
    "ATTRIB": "textEntities",
    "ATTDEF": "textEntities",
    "TOLERANCE": "otherEntities",
}


def base_result():
    data = {
        "lines": 0,
        "arcs": 0,
        "circles": 0,
        "polylines": 0,
        "splines": 0,
        "ellipses": 0,
        "hatches": 0,
        "inserts": 0,
        "dimensions": 0,
        "textEntities": 0,
        "otherEntities": 0,
        "totalEntities": 0,
        "reader": "",
        "cutLengthMm": 0.0,
        "markingLengthMm": 0.0,
        "ignoredNonCutLengthMm": 0.0,
        "cutGeometryEntityCount": 0,
        "closedProfileCount": 0,
        "openPathCount": 0,
        "minimumPierceCount": 0,
        "cutStartCount": 0,
        "cutBoundingXmm": 0.0,
        "cutBoundingYmm": 0.0,
        "cutBoundingAreaMm2": 0.0,
        "closedProfileAreaMm2": 0.0,
        "geometryHoleCandidateCount": 0,
        "estimatedRapidTravelMm": 0.0,
        "sourceFileCount": 1,
        "cutLayers": [],
        "markingLayers": [],
        "drawingUnits": "",
        "geometryMeasurementReliable": False,
        "layerCount": 0,
        "entityTypeSummary": "",
        "extentsSummary": "",
        "fileEncoding": "",
        "binaryFormat": False,
        "referenceOnlyLikely": False,
        "diagnosticSummary": "",
        "extractedTextLength": 0,
        "materialHint": "",
        "materialReference": "",
        "materialReferenceConfidence": 0,
        "materialReferenceEvidence": "",
        "keywords": [],
        "norms": [],
        "weldProcessCode": "",
        "weldTypeHint": "",
        "weldSizeKind": "",
        "weldSizeMm": None,
        "weldSideCount": 0,
        "weldSideCountConfirmed": False,
        "weldIntermittent": False,
        "weldIntermittentLengthMm": None,
        "weldPitchMm": None,
        "weldIntermittencyConfirmed": False,
        "weldAllAround": False,
        "weldGrooveAngleDeg": None,
        "weldRootGapMm": None,
        "surfacePreparation": "",
        "corrosionClass": "",
        "paintColour": "",
        "totalDftMicron": None,
        "paintLayers": [],
        "paintStripeCoatRequired": False,
        "holeRequirements": [],
        "dimensionalTolerances": [],
        "geometricTolerances": [],
        "documentMassKg": None,
        "documentMassConfidence": 0,
        "documentMassEvidence": "",
        "documentMassScope": "UNKNOWN",
        "documentSurfaceAreaM2": None,
        "documentSurfaceAreaConfidence": 0,
        "documentSurfaceAreaEvidence": "",
        "paintMaskMachinedSurfaces": False,
        "paintScope": "AUTO",
        "paintScopeEvidence": "",
        "paintScopeConflict": False,
        "projectQuantityHint": None,
        "findings": [],
        "warnings": [],
    }
    return data


def merge_text_signals(result, text: str):
    intel = result_from_text(text or "")
    scalar_keys = (
        "materialHint", "materialReference", "materialReferenceConfidence", "materialReferenceEvidence",
        "extractedTextLength", "weldProcessCode", "weldTypeHint",
        "weldSizeKind", "weldSizeMm", "weldSideCount", "weldSideCountConfirmed",
        "weldIntermittent", "weldIntermittentLengthMm", "weldPitchMm",
        "weldIntermittencyConfirmed", "weldAllAround", "weldGrooveAngleDeg",
        "weldRootGapMm", "surfacePreparation", "corrosionClass", "paintColour",
        "totalDftMicron", "paintStripeCoatRequired", "documentMassKg",
        "documentMassConfidence", "documentMassEvidence", "documentMassScope", "documentSurfaceAreaM2",
        "documentSurfaceAreaConfidence", "documentSurfaceAreaEvidence",
        "paintMaskMachinedSurfaces", "paintScope", "paintScopeEvidence",
        "paintScopeConflict", "projectQuantityHint",
    )
    list_keys = (
        "keywords", "norms", "findings", "warnings", "paintLayers", "holeRequirements",
        "dimensionalTolerances", "geometricTolerances",
    )
    for key in scalar_keys:
        if key in intel:
            result[key] = intel[key]
    for key in list_keys:
        if key in intel:
            if key == "warnings":
                result[key].extend(intel[key] or [])
            else:
                result[key] = intel[key] or []


def _dimension_text(entity, unit_scale_to_mm=1.0, unit_known=False):
    parts = []
    try:
        value = str(entity.dxf.text or "")
        if value and value not in {"<>", " "}:
            parts.append(value)
    except Exception:
        pass
    try:
        measurement_raw = float(entity.get_measurement())
        measurement = measurement_raw * float(unit_scale_to_mm) if unit_known else measurement_raw
    except Exception:
        measurement = None
    try:
        dim_type = int(getattr(entity.dxf, "dimtype", 0) or 0) & 0x0F
    except Exception:
        dim_type = 0

    try:
        override = entity.override()
        dimtol = bool(override.get("dimtol", 0))
        dimlim = bool(override.get("dimlim", 0))
        plus = override.get("dimtp", None)
        minus = override.get("dimtm", None)
        if (dimtol or dimlim) and measurement is not None:
            try:
                plus_v = abs(float(plus or 0)) * (float(unit_scale_to_mm) if unit_known else 1.0)
                minus_v = abs(float(minus or 0)) * (float(unit_scale_to_mm) if unit_known else 1.0)
                if plus_v or minus_v:
                    prefix = "Ø" if dim_type == 3 else ("R" if dim_type == 4 else "DIM ")
                    parts.append(f"{prefix}{measurement:g} +{plus_v:g}/-{minus_v:g} mm")
            except Exception:
                pass
    except Exception:
        pass

    # A real DXF DIAMETER dimension still carries useful 2D hole/diameter evidence
    # even when its displayed text was exploded or left as the default `<>` token.
    # It remains a generic candidate only; without fit/+/-/thread semantics CostEngine
    # does not force CNC automatically.
    if measurement is not None and dim_type == 3 and not any("Ø" in x for x in parts):
        parts.append(f"DIAMETER Ø{measurement:g} mm")
    return " ".join(parts)


def _collect_virtual_text(entity, texts, depth=0, unit_scale_to_mm=1.0, unit_known=False):
    if depth > 4:
        return
    kind = entity.dxftype().upper()
    if kind in {"TEXT", "ATTRIB", "ATTDEF"}:
        try:
            value = str(entity.dxf.text)
            if value.strip():
                texts.append(value)
        except Exception:
            pass
    elif kind == "MTEXT":
        value = _safe_mtext(entity)
        if value.strip():
            texts.append(value)
    elif kind == "DIMENSION":
        value = _dimension_text(entity, unit_scale_to_mm, unit_known)
        if value.strip():
            texts.append(value)
    elif kind == "TOLERANCE":
        for attr in ("content", "text", "tolerance"):
            try:
                value = str(getattr(entity.dxf, attr))
                if value.strip():
                    texts.append(value)
                    break
            except Exception:
                pass
    elif kind == "MLEADER":
        for method in ("get_mtext_content", "get_text"):
            try:
                fn = getattr(entity, method, None)
                if fn:
                    value = str(fn() or "")
                    if value.strip():
                        texts.append(value)
                        break
            except Exception:
                pass
    elif kind == "INSERT":
        # Some CAD systems encode weld/tolerance symbols as named blocks with
        # little or no attribute text. Preserve only technically meaningful block
        # names; generic component names are intentionally ignored.
        try:
            block_name = str(entity.dxf.name or "")
            if re.search(r"WELD|SCHWEISS|SPAW|SOUD|FILLET|KEHL|GROOVE|TOLER|ISO|RAL|PAINT|LACK|H[3-9]", block_name, re.IGNORECASE):
                texts.append("BLOCK " + block_name.replace("_", " "))
        except Exception:
            pass
        try:
            for attrib in entity.attribs:
                _collect_virtual_text(attrib, texts, depth + 1, unit_scale_to_mm, unit_known)
        except Exception:
            pass
        try:
            for child in entity.virtual_entities():
                _collect_virtual_text(child, texts, depth + 1, unit_scale_to_mm, unit_known)
        except Exception:
            pass


def _safe_mtext(entity):
    try:
        if hasattr(entity, "plain_text"):
            return entity.plain_text()
    except Exception:
        pass
    try:
        return str(entity.dxf.text)
    except Exception:
        return ""


def _drawing_unit_scale_to_mm(doc):
    try:
        from ezdxf import units
        code = int(getattr(doc, "units", 0) or 0)
        names = {
            0: "unitless", 1: "inch", 2: "foot", 3: "mile", 4: "mm", 5: "cm",
            6: "m", 7: "km", 8: "microinch", 9: "mil", 10: "yard", 14: "dm",
        }
        if code == 0:
            return 1.0, names.get(code, str(code)), False
        return float(units.conversion_factor(code, units.MM)), names.get(code, str(code)), True
    except Exception:
        return 1.0, "unknown", False


def _path_metrics(entity, flattening_distance=0.05):
    # ezdxf.path handles bulges, arcs, ellipses and splines consistently.
    # Return endpoints as well so separate LINE/ARC entities can be chained into
    # real contours instead of counting every entity as a separate open path.
    try:
        import ezdxf.path
        path = ezdxf.path.make_path(entity)
        points = list(path.flattening(distance=max(1e-6, flattening_distance)))
        if len(points) < 2:
            return 0.0, bool(path.is_closed), None, None
        length = sum((points[i] - points[i - 1]).magnitude for i in range(1, len(points)))
        start = points[0]
        end = points[-1]
        return float(length), bool(path.is_closed), (float(start.x), float(start.y)), (float(end.x), float(end.y))
    except Exception:
        return 0.0, False, None, None


def _layer_role(layer_name: str):
    name = (layer_name or "0").strip().upper()
    # Explicit cut/profile names take precedence over broad annotation tokens.
    if re.search(r"(?:^|[_ .-])(CUT|PROFILE|CONTOUR|LASER|PLASMA|OXY)(?:$|[_ .-])", name):
        return "cut"
    if re.search(r"(?:^|[_ .-])(ETCH|MARK|MARKING|ENGRAV|SCRIBE|SIGN)(?:$|[_ .-])", name):
        return "mark"
    if re.search(
        r"(?:^|[_ .-])(DIM|DIMS|DIMENSION|CENTER|CENTRE|CENTERLINE|AXIS|HIDDEN|TEXT|NOTE|NOTES|ANNOT|ANNOTATION|CONSTR|CONSTRUCTION|AUX|HELP|BEND|BENDS|FOLD|FOLDING)(?:$|[_ .-])",
        name,
    ):
        return "ignore"
    return "cut"


def _snap_point(point, tolerance):
    if point is None:
        return None
    tol = max(float(tolerance), 1e-9)
    return (int(round(point[0] / tol)), int(round(point[1] / tol)))


def _chain_open_entities(open_edges, tolerance):
    """Return (closed_components, open_components, anchors) for separate paths.

    Many production DXFs contain a rectangle as four LINE entities rather than
    one closed polyline.  A connected component whose every endpoint has even
    degree can be cut continuously from one pierce.  Every independent open
    component also needs at least one process start, therefore it contributes to
    the conservative pierce/start count.  `anchors` are approximate component
    centroids used only for non-cut rapid-travel estimation.
    """
    if not open_edges:
        return 0, 0, []

    adjacency = {}
    for start, end in open_edges:
        a = _snap_point(start, tolerance)
        b = _snap_point(end, tolerance)
        if a is None or b is None:
            continue
        adjacency.setdefault(a, []).append(b)
        adjacency.setdefault(b, []).append(a)

    visited = set()
    closed = 0
    opened = 0
    anchors = []
    for node in adjacency:
        if node in visited:
            continue
        stack = [node]
        component = []
        visited.add(node)
        while stack:
            cur = stack.pop()
            component.append(cur)
            for nxt in adjacency.get(cur, []):
                if nxt not in visited:
                    visited.add(nxt)
                    stack.append(nxt)
        if component:
            anchors.append((
                sum(n[0] for n in component) / len(component) * tolerance,
                sum(n[1] for n in component) / len(component) * tolerance,
            ))
        if component and all(len(adjacency.get(n, [])) >= 2 and len(adjacency.get(n, [])) % 2 == 0 for n in component):
            closed += 1
        else:
            opened += 1
    return closed, opened, anchors


def _nearest_neighbor_travel(points):
    """Simple deterministic lower-bound style travel estimate between cut starts."""
    pts = [(float(x), float(y)) for x, y in points if x is not None and y is not None]
    if len(pts) <= 1:
        return 0.0
    remaining = pts[1:]
    current = pts[0]
    total = 0.0
    while remaining:
        best_i = min(
            range(len(remaining)),
            key=lambda i: (remaining[i][0] - current[0]) ** 2 + (remaining[i][1] - current[1]) ** 2,
        )
        nxt = remaining.pop(best_i)
        total += ((nxt[0] - current[0]) ** 2 + (nxt[1] - current[1]) ** 2) ** 0.5
        current = nxt
    return total



def _closed_path_area(entity, flattening_distance=0.05):
    try:
        import ezdxf.path
        path = ezdxf.path.make_path(entity)
        if not path.is_closed:
            return 0.0
        pts = list(path.flattening(distance=max(1e-6, flattening_distance)))
        if len(pts) < 3:
            return 0.0
        xy = [(float(p.x), float(p.y)) for p in pts]
        if xy[0] != xy[-1]:
            xy.append(xy[0])
        area2 = sum(xy[i][0] * xy[i + 1][1] - xy[i + 1][0] * xy[i][1] for i in range(len(xy) - 1))
        return abs(area2) * 0.5
    except Exception:
        return 0.0


def _iter_virtual_graphics(entity, depth=0):
    if depth > 3:
        return
    kind = entity.dxftype().upper()
    if kind in {"INSERT", "DIMENSION"}:
        try:
            for child in entity.virtual_entities():
                yield from _iter_virtual_graphics(child, depth + 1)
            return
        except Exception:
            pass
    yield entity


def _recover_exploded_text_with_ocr(doc, msp, total_entities):
    """Rasterize vector geometry and OCR it when visible text was exploded to LINE/ARC.

    This is deliberately bounded. It is a recovery path for customer drawings, not a
    replacement for native DXF text/DIMENSION extraction.
    """
    if total_entities < 30 or total_entities > 12000:
        return "", ""
    try:
        import ezdxf.bbox
        from PIL import Image, ImageDraw, ImageOps, ImageEnhance
        import pytesseract

        executable, config = configure_tesseract(pytesseract)
        if executable is None:
            return "", "DXF_VECTOR_OCR_SKIPPED: nie znaleziono tesseract.exe."
        entities = []
        for ent in msp:
            for child in _iter_virtual_graphics(ent):
                if child.dxftype().upper() in {"LINE", "CIRCLE", "ARC", "LWPOLYLINE", "POLYLINE"}:
                    entities.append(child)
                    if len(entities) >= 15000:
                        break
            if len(entities) >= 15000:
                break
        if not entities:
            return "", ""
        ext = ezdxf.bbox.extents(entities, fast=True)
        if not ext.has_data:
            return "", ""
        xmin, ymin = float(ext.extmin.x), float(ext.extmin.y)
        xmax, ymax = float(ext.extmax.x), float(ext.extmax.y)
        dx, dy = max(1e-6, xmax - xmin), max(1e-6, ymax - ymin)
        max_px = 3000
        min_px = 1000
        if dx >= dy:
            width = max_px
            height = max(min_px, int(max_px * dy / dx))
        else:
            height = max_px
            width = max(min_px, int(max_px * dx / dy))
        width = min(3200, width); height = min(3200, height)
        margin = 35
        sx = (width - 2 * margin) / dx
        sy = (height - 2 * margin) / dy
        scale = min(sx, sy)
        def pt(x, y):
            return (margin + (float(x) - xmin) * scale, height - margin - (float(y) - ymin) * scale)

        image = Image.new("RGB", (width, height), "white")
        draw = ImageDraw.Draw(image)
        line_width = 2
        for ent in entities:
            kind = ent.dxftype().upper()
            try:
                if kind == "LINE":
                    a, b = ent.dxf.start, ent.dxf.end
                    draw.line([pt(a.x, a.y), pt(b.x, b.y)], fill="black", width=line_width)
                elif kind == "CIRCLE":
                    c, r = ent.dxf.center, float(ent.dxf.radius)
                    x0, y0 = pt(c.x - r, c.y - r); x1, y1 = pt(c.x + r, c.y + r)
                    draw.ellipse([min(x0,x1), min(y0,y1), max(x0,x1), max(y0,y1)], outline="black", width=line_width)
                elif kind in {"LWPOLYLINE", "POLYLINE", "ARC"}:
                    length, closed, _, _ = _path_metrics(ent, max(dx,dy)/5000.0)
                    import ezdxf.path
                    path = ezdxf.path.make_path(ent)
                    pts = [pt(p.x, p.y) for p in path.flattening(distance=max(dx,dy)/5000.0)]
                    if len(pts) >= 2:
                        draw.line(pts, fill="black", width=line_width, joint="curve")
                        if closed:
                            draw.line([pts[-1], pts[0]], fill="black", width=line_width)
            except Exception:
                pass

        lang_string, selected = choose_ocr_languages(pytesseract, config)
        text, _, _, _, _, _ = run_technical_ocr(
            pytesseract, image, lang_string, config, ImageOps, ImageEnhance
        )
        return text, f"DXF vector OCR: {width}x{height}px; języki {'+'.join(selected) if selected else 'default'}."
    except Exception as exc:
        return "", f"DXF_VECTOR_OCR_FAILED: {type(exc).__name__}: {exc}"

def parse_with_ezdxf(path: Path):
    import ezdxf

    doc = ezdxf.readfile(path)
    msp = doc.modelspace()
    counts = Counter()
    texts = []
    cut_length_units = 0.0
    mark_length_units = 0.0
    ignored_length_units = 0.0
    directly_closed_profiles = 0
    closed_profile_area_units2 = 0.0
    circle_diameters_mm = []
    direct_closed_anchors = []
    open_cut_edges = []
    cut_geometry_entities = 0
    cut_entities = []
    cut_layers = set()
    marking_layers = set()
    cuttable_kinds = {"LINE", "ARC", "CIRCLE", "LWPOLYLINE", "POLYLINE", "SPLINE", "ELLIPSE"}

    unit_scale, unit_name, unit_known = _drawing_unit_scale_to_mm(doc)
    try:
        layer_count = len(doc.layers)
    except Exception:
        layer_count = 0
    # Geometric tolerance of about 0.10 mm for endpoint chaining.  In unitless
    # drawings use 0.10 drawing units and keep the measurement non-authoritative.
    chain_tolerance_units = 0.10 / unit_scale if unit_known and unit_scale > 1e-12 else 0.10
    flattening_units = 0.05 / unit_scale if unit_known and unit_scale > 1e-12 else 0.05

    for entity in msp:
        kind = entity.dxftype().upper()
        counts[kind] += 1

        if kind in cuttable_kinds:
            length, is_closed, start_pt, end_pt = _path_metrics(entity, flattening_units)
            if length > 0:
                try:
                    layer = str(entity.dxf.layer or "0")
                except Exception:
                    layer = "0"
                role = _layer_role(layer)
                if role == "mark":
                    mark_length_units += length
                    marking_layers.add(layer)
                elif role == "ignore":
                    ignored_length_units += length
                else:
                    cut_geometry_entities += 1
                    cut_length_units += length
                    cut_entities.append(entity)
                    cut_layers.add(layer)
                    if is_closed:
                        directly_closed_profiles += 1
                        if start_pt is not None:
                            direct_closed_anchors.append(start_pt)
                    elif start_pt is not None and end_pt is not None:
                        open_cut_edges.append((start_pt, end_pt))
                    if is_closed:
                        closed_profile_area_units2 += _closed_path_area(entity, flattening_units)
                    if kind == "CIRCLE" and unit_known:
                        try:
                            diameter_mm = 2.0 * abs(float(entity.dxf.radius)) * unit_scale
                            if 0.5 <= diameter_mm <= 5000:
                                circle_diameters_mm.append(diameter_mm)
                        except Exception:
                            pass

        if kind in {"TEXT", "MTEXT", "ATTRIB", "ATTDEF", "INSERT", "DIMENSION", "TOLERANCE", "MLEADER"}:
            _collect_virtual_text(entity, texts, unit_scale_to_mm=unit_scale, unit_known=unit_known)

    chained_closed, open_components, chained_anchors = _chain_open_entities(open_cut_edges, chain_tolerance_units)
    closed_profiles = directly_closed_profiles + chained_closed
    cut_start_count = closed_profiles + open_components
    rapid_travel_units = _nearest_neighbor_travel(direct_closed_anchors + chained_anchors)

    bbox_x_units = 0.0
    bbox_y_units = 0.0
    if cut_entities:
        try:
            import ezdxf.bbox
            ext = ezdxf.bbox.extents(cut_entities, fast=False)
            if ext.has_data:
                size = ext.size
                bbox_x_units = abs(float(size.x))
                bbox_y_units = abs(float(size.y))
        except Exception:
            pass

    result = base_result()
    total = sum(counts.values())
    result["totalEntities"] = total
    result["reader"] = "ezdxf"
    result["drawingUnits"] = unit_name
    result["layerCount"] = layer_count
    result["fileEncoding"] = str(getattr(doc, "encoding", "") or "unknown")
    try:
        result["binaryFormat"] = path.read_bytes()[:22].startswith(b"AutoCAD Binary DXF")
    except Exception:
        result["binaryFormat"] = False
    result["cutLengthMm"] = cut_length_units * unit_scale
    result["markingLengthMm"] = mark_length_units * unit_scale
    result["ignoredNonCutLengthMm"] = ignored_length_units * unit_scale
    result["cutGeometryEntityCount"] = cut_geometry_entities
    result["closedProfileCount"] = closed_profiles
    result["openPathCount"] = open_components
    # Every independent cut component needs at least one start/pierce.
    result["minimumPierceCount"] = cut_start_count
    result["cutStartCount"] = cut_start_count
    result["cutBoundingXmm"] = bbox_x_units * unit_scale
    result["cutBoundingYmm"] = bbox_y_units * unit_scale
    result["cutBoundingAreaMm2"] = result["cutBoundingXmm"] * result["cutBoundingYmm"]
    result["closedProfileAreaMm2"] = closed_profile_area_units2 * unit_scale * unit_scale
    result["geometryHoleCandidateCount"] = len(circle_diameters_mm)
    result["estimatedRapidTravelMm"] = rapid_travel_units * unit_scale
    result["cutLayers"] = sorted(cut_layers, key=str.upper)[:40]
    result["markingLayers"] = sorted(marking_layers, key=str.upper)[:40]
    result["geometryMeasurementReliable"] = bool(unit_known and result["cutLengthMm"] > 0)
    if not unit_known and cut_length_units > 0:
        result["warnings"].append(
            "DXF_UNITS_UNKNOWN: długość geometrii policzono w jednostkach rysunku, ale $INSUNITS nie określa skali. "
            "Czas cięcia nie powinien używać tej długości automatycznie."
        )

    used = 0
    for entity_name, prop in ENTITY_GROUPS.items():
        value = counts.get(entity_name, 0)
        result[prop] += value
        used += value

    result["otherEntities"] = max(0, total - used)
    result["entityTypeSummary"] = ", ".join(
        f"{name}:{count}" for name, count in counts.most_common(16)
    ) or "brak"
    result["extentsSummary"] = (
        f"{result['cutBoundingXmm']:.3f} x {result['cutBoundingYmm']:.3f} mm"
        if result["cutBoundingXmm"] > 0 and result["cutBoundingYmm"] > 0
        else "brak wiarygodnych extents geometrii cięcia"
    )
    result["referenceOnlyLikely"] = bool(
        total > 0 and cut_geometry_entities == 0 and
        (counts.get("INSERT", 0) + counts.get("IMAGE", 0) + counts.get("XREF", 0)) > 0
    )
    native_text = "\n".join(texts)
    merge_text_signals(result, native_text)

    # Exploded/outlined annotations are common in customer DXFs. Native entity text
    # can then be almost empty although a human sees a complete drawing. Rasterize
    # and OCR only in that sparse-text case.
    if result.get("extractedTextLength", 0) < 120 and total >= 30:
        recovered_text, ocr_note = _recover_exploded_text_with_ocr(doc, msp, total)
        if recovered_text.strip():
            merge_text_signals(result, native_text + "\n" + recovered_text)
            result["findings"].append(ocr_note or "DXF vector OCR: odzyskano tekst z geometrii liniowej.")
        elif ocr_note:
            result["warnings"].append(ocr_note)

    # Closed CIRCLE entities are useful 2D hole candidates even when dimension text
    # is missing. They are intentionally low-semantic: they do not force CNC without
    # a fit/tolerance/thread/reaming signal.
    if circle_diameters_mm:
        from collections import Counter as _Counter
        groups = _Counter(round(x, 2) for x in circle_diameters_mm)
        existing = result.get("holeRequirements") or []
        for diameter, count in groups.most_common(100):
            if any(abs(float(h.get("nominalDiameterMm") or 0) - diameter) <= 0.05 for h in existing):
                continue
            existing.append({
                "nominalDiameterMm": diameter,
                "count": int(count),
                "fitCode": "",
                "threadCode": "",
                "operationHint": "DXF_CIRCLE",
                "reamedLikely": False,
                "fitConfirmed": False,
                "precisionMachined": False,
                "sourceText": f"DXF CIRCLE Ø{diameter:g}: {count} szt. kandydatów geometrycznych",
                "requiresDrill": False,
                "requiresReam": False,
                "requiresTap": False,
                "requiresBore": False,
                "requiresCnc": False,
                "canThermalCut": True,
            })
        result["holeRequirements"] = existing[:100]
        result["findings"].append(f"DXF: {len(circle_diameters_mm)} zamkniętych okręgów potraktowano jako kandydatów otworów 2D (bez automatycznego wymuszania CNC).")

    result["diagnosticSummary"] = (
        f"DXF_DIAG | Reader=ezdxf | Entities={total} | Layers={layer_count} | "
        f"Types={result['entityTypeSummary']} | Units={unit_name} | Extents={result['extentsSummary']} | "
        f"Encoding={result['fileEncoding']} | Binary={result['binaryFormat']} | "
        f"ReferenceOnly={result['referenceOnlyLikely']}"
    )
    result["findings"].append(result["diagnosticSummary"])
    if total == 0:
        result["warnings"].append(
            "DXF_ZERO_ENTITIES: modelspace nie zawiera rozpoznanych encji. "
            f"Warstwy={layer_count}; jednostki={unit_name}; kodowanie={result['fileEncoding']}."
        )
    if result["cutLengthMm"] > 0:
        result["findings"].append(
            f"DXF cut geometry: {result['cutLengthMm']:.1f} mm; closed contours: {closed_profiles}; "
            f"open components: {open_components}; min starts/pierces: {cut_start_count}; "
            f"rapid travel~{result['estimatedRapidTravelMm']:.1f} mm; units: {unit_name}"
        )
    if result["markingLengthMm"] > 0:
        result["findings"].append(f"DXF marking/etch geometry: {result['markingLengthMm']:.1f} mm")
    if result["ignoredNonCutLengthMm"] > 0:
        result["findings"].append(f"DXF non-cut helper geometry ignored: {result['ignoredNonCutLengthMm']:.1f} mm")
    return result


def decode_text(data: bytes):
    if data.startswith(b"\xef\xbb\xbf"):
        return data.decode("utf-8-sig"), "UTF-8-BOM"
    try:
        return data.decode("ascii"), "ASCII"
    except UnicodeDecodeError:
        pass
    for enc, label in (("utf-8", "UTF-8"), ("cp1250", "CP1250"),
                       ("cp1252", "CP1252"), ("latin1", "LATIN1")):
        try:
            return data.decode(enc), label
        except UnicodeDecodeError:
            pass
    return data.decode("latin1", errors="replace"), "LATIN1-REPLACE"


def parse_ascii_fallback(path: Path):
    data = path.read_bytes()
    if data.startswith(b"AutoCAD Binary DXF"):
        raise RuntimeError("Binary DXF wymaga ezdxf; parser tekstowy nie może go odczytać.")

    text, encoding = decode_text(data)
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    result = base_result()
    counts = Counter()
    extracted = []
    section = ""
    current_entity = ""

    # DXF is encoded as pairs: group-code line + value line. Whitespace around
    # group codes is legal and very common in real customer drawings.
    i = 0
    while i + 1 < len(lines):
        code_raw = lines[i].strip()
        value = lines[i + 1].strip()
        i += 2
        try:
            code = int(code_raw)
        except ValueError:
            continue

        upper = value.upper()
        if code == 0 and upper == "SECTION":
            continue
        if code == 2 and not current_entity:
            if upper in {"HEADER", "CLASSES", "TABLES", "BLOCKS", "ENTITIES", "OBJECTS", "THUMBNAILIMAGE"}:
                section = upper
                continue

        if code == 0:
            if upper in {"ENDSEC", "EOF", "SECTION", "TABLE", "ENDTAB", "BLOCK", "ENDBLK", "SEQEND", "VERTEX"}:
                current_entity = ""
                continue
            current_entity = upper
            if section == "ENTITIES":
                counts[current_entity] += 1
            continue

        if section == "ENTITIES" and current_entity in {"TEXT", "MTEXT", "ATTRIB", "ATTDEF", "DIMENSION", "TOLERANCE", "MLEADER"} and code in {1, 3}:
            if value and value != "<>":
                extracted.append(value)

    # Some exporters omit a clean SECTION marker. As a recovery path, scan
    # type markers with whitespace-tolerant regex, but never double-count if the
    # structured pair parser already found entities.
    if not counts:
        known = set(ENTITY_GROUPS) | {
            "POINT", "SOLID", "TRACE", "3DFACE", "RAY", "XLINE", "LEADER",
            "MLEADER", "MLINE", "WIPEOUT", "IMAGE", "MESH", "VIEWPORT", "SHAPE"
        }
        for name in known:
            c = len(re.findall(rf"(?mi)^\s*0\s*$\n\s*{re.escape(name)}\s*$", text))
            if c:
                counts[name] = c

    total = sum(counts.values())
    result["totalEntities"] = total
    result["reader"] = "ascii-fallback"
    result["fileEncoding"] = encoding
    result["binaryFormat"] = False
    result["layerCount"] = len(re.findall(r"(?mi)^\s*0\s*$\n\s*LAYER\s*$", text))
    used = 0
    for entity_name, prop in ENTITY_GROUPS.items():
        value = counts.get(entity_name, 0)
        result[prop] += value
        used += value
    result["otherEntities"] = max(0, total - used)
    result["entityTypeSummary"] = ", ".join(
        f"{name}:{count}" for name, count in counts.most_common(16)
    ) or "brak"
    result["extentsSummary"] = "niedostępne w parserze ASCII"
    result["referenceOnlyLikely"] = bool(
        total > 0 and sum(counts.get(name, 0) for name in ("LINE", "ARC", "CIRCLE", "LWPOLYLINE", "POLYLINE", "SPLINE", "ELLIPSE")) == 0 and
        (counts.get("INSERT", 0) + counts.get("IMAGE", 0)) > 0
    )
    merge_text_signals(result, "\n".join(extracted))
    result["diagnosticSummary"] = (
        f"DXF_DIAG | Reader=ascii-fallback | Entities={total} | Layers={result['layerCount']} | "
        f"Types={result['entityTypeSummary']} | Units=unknown | Extents={result['extentsSummary']} | "
        f"Encoding={encoding} | Binary=False | ReferenceOnly={result['referenceOnlyLikely']}"
    )
    result["findings"].append(result["diagnosticSummary"])
    if total == 0:
        result["warnings"].append(
            "DXF_ZERO_ENTITIES: nie znaleziono encji modelspace. "
            f"Warstwy={result['layerCount']}; typy={result['entityTypeSummary']}; "
            f"kodowanie={encoding}; możliwy pusty plik, sama ramka/XREF albo odmiana wymagająca ezdxf."
        )
    return result


def analyze(path: Path):
    warnings = []
    try:
        return parse_with_ezdxf(path)
    except Exception as exc:
        warnings.append(f"ezdxf: {type(exc).__name__}: {exc}")

    try:
        result = parse_ascii_fallback(path)
        result["warnings"] = warnings + result.get("warnings", [])
        return result
    except Exception as exc:
        result = base_result()
        result["reader"] = "failed"
        result["warnings"] = warnings + [f"ASCII fallback: {type(exc).__name__}: {exc}"]
        result["diagnosticSummary"] = (
            "DXF_DIAG | Reader=failed | Entities=0 | Layers=0 | Types=brak | "
            f"Units=unknown | Extents=brak | ParseErrors={' | '.join(result['warnings'])[:500]}"
        )
        result["findings"].append(result["diagnosticSummary"])
        return result


def main():
    if len(sys.argv) != 2:
        result = base_result()
        result["warnings"].append("Brak ścieżki DXF.")
        print(json.dumps(result, ensure_ascii=True))
        return 2

    path = Path(sys.argv[1])
    if not path.exists():
        result = base_result()
        result["warnings"].append("Plik DXF nie istnieje.")
        print(json.dumps(result, ensure_ascii=True))
        return 2

    print(json.dumps(analyze(path), ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
