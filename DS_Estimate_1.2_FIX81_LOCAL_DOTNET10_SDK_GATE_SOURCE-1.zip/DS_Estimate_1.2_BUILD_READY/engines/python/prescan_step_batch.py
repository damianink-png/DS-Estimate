#!/usr/bin/env python3
from __future__ import annotations
import json, os, sys
from collections import defaultdict
from pathlib import Path

import cadquery as cq
import analyze_step as step


def scan_one(path: Path):
    r = step.empty_result()
    r["analysisMode"] = "batch-prescan"
    try:
        shape, solids, importer, warnings = step.load_step_solids(path, cq)
        r["warnings"].extend(warnings)
        if not solids:
            r["warnings"].append("Batch pre-scan: brak brył SOLID.")
            return r
        r["available"] = True
        r["solidCount"] = len(solids)
        r["importer"] = importer
        bx, by, bz = step.solids_union_bbox(solids)
        r["boundingXmm"], r["boundingYmm"], r["boundingZmm"] = bx, by, bz

        groups = defaultdict(list)
        for solid in solids:
            bb = solid.BoundingBox()
            dims = (float(bb.xlen), float(bb.ylen), float(bb.zlen))
            volume = abs(float(solid.Volume()))
            area = abs(float(solid.Area()))
            faces = list(solid.Faces())
            edges = list(solid.Edges())
            face_types = [f.geomType() for f in faces]
            cyl = sum(1 for t in face_types if t == "CYLINDER")
            cone = sum(1 for t in face_types if t == "CONE")
            plane = sum(1 for t in face_types if t == "PLANE")
            face_sig = tuple(sorted((f.geomType(), round(abs(float(f.Area())), 1)) for f in faces))
            key = (tuple(sorted(round(v, 1) for v in dims)), round(volume, 1), round(area, 1),
                   len(faces), len(edges), cyl, cone, plane, face_sig)
            groups[key].append((dims, volume, area, len(faces), len(edges), cyl, cone, plane))

        parts = []
        total_volume = total_area = 0.0
        for idx, items in enumerate(groups.values(), start=1):
            dims, volume, area, face_count, edge_count, cyl, cone, plane = items[0]
            qty = len(items)
            total_volume += volume * qty
            total_area += area * qty
            parts.append({
                "groupKey": f"BPRE-{idx:04d}", "name": f"Pre-scan {idx:03d}",
                "sourceFile": path.name, "classification": "Pre-scan", "quantity": qty,
                "xmm": dims[0], "ymm": dims[1], "zmm": dims[2],
                "volumeMm3Each": volume, "surfaceMm2Each": area,
                "faceCount": face_count, "edgeCount": edge_count,
                "cylindricalFaceCount": cyl, "conicalFaceCount": cone, "planarFaceCount": plane,
                "holes": [], "bevel": [], "massKgEach": 0.0,
            })
        r["parts"] = parts
        r["uniquePartGroups"] = len(parts)
        r["volumeMm3"] = total_volume
        r["surfaceMm2"] = total_area
        r["paintableSurfaceMm2"] = total_area
        r["exposedSurfaceMm2"] = total_area
        return r
    except Exception as exc:
        r["warnings"].append(f"Batch pre-scan {path.name}: {type(exc).__name__}: {exc}")
        return r


def main():
    if len(sys.argv) != 2:
        print(json.dumps({}, ensure_ascii=True))
        return 0
    manifest = Path(sys.argv[1])
    paths = json.loads(manifest.read_text(encoding="utf-8"))
    result = {}
    for raw in paths:
        path = Path(raw)
        result[str(path)] = scan_one(path)
    print(json.dumps(result, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    rc = main()
    # Batch JSON is complete; bypass unstable CadQuery/OCP native finalizers.
    try:
        sys.stdout.flush(); sys.stderr.flush()
    finally:
        os._exit(rc)
