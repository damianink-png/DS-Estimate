﻿#!/usr/bin/env python3
from __future__ import annotations

import contextlib
import gc
import io
import json
import os
import sys
import traceback

# Keep CadQuery/OCP and analyze_step imported for the lifetime of this worker.
# analyze_step.main() is intentionally reused with a temporary argv/environment;
# Python's module cache means the very expensive native imports happen only once.
import analyze_step


def _write_response(payload):
    sys.stdout.write(json.dumps(payload, ensure_ascii=True) + "\n")
    sys.stdout.flush()


def _run_request(req):
    path = str(req.get("path") or req.get("Path") or "")
    env = req.get("env") or req.get("Env") or {}
    if not path:
        return {"ok": False, "stdout": "", "stderr": "Brak ścieżki STEP w żądaniu workera."}

    old_argv = list(sys.argv)
    old_env = {}
    try:
        for key, value in env.items():
            key = str(key)
            old_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        sys.argv = [str(getattr(analyze_step, "__file__", "analyze_step.py")), path]
        capture = io.StringIO()
        # Progress stays on the worker stderr and can be streamed by the host.
        with contextlib.redirect_stdout(capture):
            code = analyze_step.main()
        output = capture.getvalue().strip()
        ok = int(code or 0) == 0 and bool(output)
        return {"ok": ok, "stdout": output, "stderr": ""}
    except BaseException as exc:
        return {
            "ok": False,
            "stdout": "",
            "stderr": f"STEP worker: {type(exc).__name__}: {exc}\n{traceback.format_exc(limit=8)}",
        }
    finally:
        sys.argv = old_argv
        for key, value in old_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        # Release transient CadQuery/OCP shapes between jobs while keeping the
        # expensive native modules loaded in the long-lived worker.
        try:
            gc.collect()
        except Exception:
            pass


def main():
    # One JSON request per line. The worker is deliberately sequential; C# keeps a
    # pool of up to two workers so separate STEP roots can still run in parallel.
    for raw in sys.stdin:
        raw = raw.strip()
        if not raw:
            continue
        if raw == "__quit__":
            break
        try:
            req = json.loads(raw)
            _write_response(_run_request(req))
        except BaseException as exc:
            _write_response({
                "ok": False,
                "stdout": "",
                "stderr": f"STEP worker protocol: {type(exc).__name__}: {exc}",
            })
    return 0


if __name__ == "__main__":
    rc = main()
    # CadQuery/OCP native finalizers can hang or raise 0xC0000005 on Windows
    # after the protocol loop has already completed.  Return the real worker
    # status immediately; transient shapes were released between requests.
    try:
        sys.stdout.flush(); sys.stderr.flush()
    finally:
        os._exit(rc)
