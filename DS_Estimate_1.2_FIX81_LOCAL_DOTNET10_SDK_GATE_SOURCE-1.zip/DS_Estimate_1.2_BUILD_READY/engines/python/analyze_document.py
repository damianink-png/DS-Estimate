#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import re
import shutil
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path


MATERIAL_RE = re.compile(
    r"\b("
    r"S235(?:JR|J0|J2)?|"
    r"S275(?:JR|J0|J2)?|"
    r"S355(?:J2\+N|J2|JR|J0|MC|NL|N)?|"
    r"S420(?:MC|N|NL)?|S460(?:MC|N|NL)?|S500MC|S700MC|"
    r"S690QL|S890QL|S960QL|"
    r"P265GH|P355(?:N|NH|NL1|NL2|GH)|"
    r"C45(?:E)?|42CRMO4|34CRNIMO6|25CRMO4|16MNCR5|100CR6|"
    r"X5CRNI18-10|X2CRNIMO17-12-2|"
    r"HARDOX\s*\d+|"
    r"1\.4301|1\.4404|1\.0570|"
    r"ST52-3|"
    r"AISI\s*304|AISI\s*316|"
    r"EN\s*AW[-\s]?\d+|"
    r"ASTM\s*A36|"
    r"ASTM\s*A572(?:\s*(?:GR|GRADE)\.?\s*50)?|"
    r"ASTM\s*A514|"
    r"(?:ASTM\s*)?A516\s*(?:GR|GRADE)\.?\s*70|"
    r"SA-516\s*(?:GR|GRADE)\.?\s*70"
    r")\b",
    re.IGNORECASE
)



_TITLEBLOCK_MATERIAL_LABEL_RE = re.compile(
    r"(?:WERKSTOFF|MATERIAL(?:\s+GRADE)?|MATERIA[ŁL]|MATI[ÈE]RE|MATERIA)",
    re.IGNORECASE,
)

_INTERNAL_MATERIAL_REFERENCE_RE = re.compile(
    r"^(?:[A-Z]{1,6}\d{3,}[A-Z0-9]*[-_/]){1,3}[A-Z]{0,6}\d{3,}[A-Z0-9._/-]*$",
    re.IGNORECASE,
)

def _clean_titleblock_value(value: str) -> str:
    value = re.sub(r"[*#]+", " ", str(value or ""))
    value = re.sub(r"\s+", " ", value).strip(" \t:;|,-")
    return value[:160]

def _looks_like_material_reference(value: str) -> bool:
    compact = re.sub(r"\s+", "", _clean_titleblock_value(value)).upper()
    if not compact:
        return False
    if MATERIAL_RE.search(compact):
        return False
    if _INTERNAL_MATERIAL_REFERENCE_RE.match(compact):
        return True
    # Vendor/CAD identifiers typically contain multiple long digit groups plus
    # separators. Do not let them become a steel grade merely because they live
    # under a multilingual 'Material/Werkstoff' title-block label.
    digit_groups = re.findall(r"\d{3,}", compact)
    return len(digit_groups) >= 2 and any(ch in compact for ch in "-_/.")

def _detect_titleblock_material(text: str):
    lines = [re.sub(r"\s+", " ", x).strip() for x in (text or "").splitlines() if x.strip()]
    references = []
    for i, line in enumerate(lines):
        lm = _TITLEBLOCK_MATERIAL_LABEL_RE.search(line)
        if not lm:
            continue
        # Same-cell value after the label, or a value placed in one of the next
        # title-block rows/cells. Keep the window short to avoid swallowing notes.
        candidates = []
        tail = _clean_titleblock_value(line[lm.end():])
        if tail:
            candidates.append(tail)
        candidates.extend(_clean_titleblock_value(x) for x in lines[i + 1:i + 5])
        for raw in candidates:
            if not raw or _TITLEBLOCK_MATERIAL_LABEL_RE.fullmatch(raw):
                continue
            m = MATERIAL_RE.search(raw)
            if m:
                return " ".join(m.group(0).upper().split()), "", 96, f"pole tabelki materiałowej: {raw[:120]}"
            if _looks_like_material_reference(raw):
                references.append(raw)
                break
    reference = references[0] if references else ""
    return "", reference, (92 if reference else 0), (f"kod/specyfikacja w polu materiałowym: {reference}" if reference else "")


NORM_PATTERNS = [
    re.compile(r"\b(?:PN-EN|DIN\s+EN|NF\s+EN|BS\s+EN)\s+ISO\s+\d+(?:-\d+)?(?:-[A-Z0-9]{1,6})?", re.IGNORECASE),
    re.compile(r"\b(?:DIN\s+ISO|NF\s+ISO|BS\s+ISO|PN-EN|EN|DIN|ISO|NF|BS)\s+\d+(?:-\d+)?(?:-[A-Z0-9]{1,6})?", re.IGNORECASE),
    re.compile(r"\bAWS\s+[A-Z]\d+(?:\.\d+)+(?:/[A-Z]\d+(?:\.\d+)*)?", re.IGNORECASE),
    re.compile(r"\bASTM\s+[A-Z]\d+(?:/[A-Z]\d+)?(?:\s+(?:GR|GRADE)\.?\s*\d+)?", re.IGNORECASE),
    re.compile(r"\bASME\s+[A-Z0-9]+(?:\.[A-Z0-9]+)+", re.IGNORECASE),
    re.compile(r"\bANSI\s+[A-Z0-9]+(?:\.[A-Z0-9]+)+", re.IGNORECASE),
    re.compile(r"\bSSPC[-\s]*SP\s*\d+", re.IGNORECASE),
    re.compile(r"\bNACE\s+(?:NO\.?\s*\d+|[A-Z]{1,4}\d*)", re.IGNORECASE),
]

# Existing literal signals are preserved for backward compatibility.
KEYWORDS = [
    "WELD", "SPAW", "ISO 5817", "ISO 2553",
    "MACHIN", "OBRÓB", "FREZ", "H7", "H8", "RA ", "TOLER",
    "UT", "MT", "PT", "RT",
    "PAINT", "MALOW", "C3", "C4", "C5",
    "SHOT BLAST", "ŚRUT",
    "GALV", "CYNK",
    "HEAT TREAT", "WYŻAR",
]

EXACT_SHORT_KEYWORDS = {
    "UT", "MT", "PT", "RT", "H7", "H8", "C3", "C4", "C5"
}

CANONICAL_RULES = {
    "WELD": [
        r"\bWELD(?:ING|ED|S)?\b", r"\bFILLET\s+WELD\b", r"\bBUTT\s+WELD\b",
        r"\bGMAW\b", r"\bFCAW\b", r"\bSMAW\b",
        r"\bSCHWEISS(?:EN|UNG|NAHT|NÄHTE|N[aä]HTE)?\b", r"\bSCHWEISSNAHT(?:L[ÄA]NGE)?\b", r"\bKEHLNAHT\b", r"\bSTUMPFNAHT\b",
        r"\bSOUD(?:AGE|URE|ER|ÉE|ÉES)?\b", r"\bCORDON(?:S)?\s+DE\s+SOUDURE\b",
        r"\bSPAW(?:ANIE|AĆ|Y|U|ÓW)?\b", r"\bSPOIN(?:A|Y|Ę|ACH)?\b",
    ],
    "MACHIN": [
        r"\bMACHIN(?:E|ING|ED)?\b", r"\bMILL(?:ING|ED)?\b", r"\bDRILL(?:ING|ED)?\b",
        r"\bREAM(?:ING|ED)?\b", r"\bBOR(?:E|ING)\b",
        r"\bZERSPAN(?:UNG|EN)?\b", r"\bFRÄS(?:EN|UNG)?\b", r"\bFRAES(?:EN|UNG)?\b",
        r"\bBOHR(?:EN|UNG)?\b", r"\bDREH(?:EN|UNG)?\b", r"\bBEARBEITUNG\b",
        r"\bUSIN(?:AGE|ER|ÉE|ÉES)?\b", r"\bFRAIS(?:AGE|ER)?\b",
        r"\bPERÇ(?:AGE|ER)?\b", r"\bPERC(?:AGE|ER)?\b", r"\bALÉS(?:AGE|ER)?\b",
        r"\bALES(?:AGE|ER)?\b", r"\bTOURN(?:AGE|ER)?\b",
        r"\bOBRÓB(?:KA|KI|KĘ)?\b", r"\bFREZ(?:OWANIE|OWAĆ)?\b", r"\bWIERC(?:ENIE|IĆ)?\b",
    ],
    "PAINT": [
        r"\bPAINT(?:ING|ED)?\b", r"\bCOAT(?:ING|ED)?\b", r"\bPRIMER\b", r"\bTOP\s*COAT\b",
        r"\bLACKIER(?:UNG|EN)?\b", r"\bBESCHICHT(?:UNG|EN)?\b", r"\bANSTRICH(?:SYSTEM)?\b",
        r"\bGRUNDIER(?:UNG|EN)?\b", r"\bDECKLACK\b", r"\bOBERFL[ÄA]CHENBEHANDLUNG\b",
        r"\bPEINT(?:URE|URES|RE)?\b", r"\bREV[ÊE]TEMENT\b",
        r"\bMALOW(?:ANIE|AĆ)?\b", r"\bPOW[ŁL]OK(?:A|I|OWY|OWE)?\b",
    ],
    "SHOT BLAST": [
        r"\bSHOT\s+BLAST(?:ING)?\b", r"\bABRASIVE\s+BLAST(?:ING)?\b", r"\bBLAST\s+CLEAN(?:ING)?\b", r"\bSANDBLAST(?:ING)?\b",
        r"\bSTRAHL(?:EN|UNG)?\b", r"\bSANDSTRAHL(?:EN|UNG)?\b", r"\bKUGELSTRAHL(?:EN|UNG)?\b",
        r"\bGRENAILL(?:AGE|ER)?\b", r"\bSABL(?:AGE|ER)?\b",
        r"\bŚRUT(?:OWANIE|OWAĆ)?\b",
    ],
    "GALV": [
        r"\bGALVANI[ZS](?:E|ED|ING|ATION)?\b",
        r"\bVERZINK(?:EN|UNG)?\b", r"\bGALVANIS(?:ATION|ER)?\b", r"\bZINGAGE\b",
        r"\bCYNK(?:OWANIE|OWAĆ)?\b",
    ],
    "HEAT TREAT": [
        r"\bHEAT\s+TREAT(?:MENT|ED)?\b", r"\bSTRESS\s+RELIE(?:F|VED)\b", r"\bANNEAL(?:ING|ED)?\b",
        r"\bWÄRMEBEHANDLUNG\b", r"\bWAERMEBEHANDLUNG\b", r"\bSPANNUNGSARMGLÜHEN\b",
        r"\bTRAITEMENT\s+THERMIQUE\b", r"\bRECUIT\b",
        r"\bWYŻAR(?:ZANIE|ZAN)?\b",
    ],
    "BENDING": [
        r"\bBEND(?:ING|ED)?\b", r"\bPRESS\s+BRAK(?:E|ING)\b", r"\bROLL\s+FORM(?:ING|ED)?\b",
        r"\bABKANT(?:EN|UNG)?\b", r"\bBIEG(?:EN|UNG)?\b",
        r"\bPLI(?:AGE|ER|ÉE|EE)\b", r"\bCINTR(?:AGE|ER|ÉE|EE)\b",
        r"\bGI[ĘE]C(?:IE|IA|IEM)?\b", r"\bWALC(?:OWANIE|OWAĆ|OWAC)?\b",
    ],
    "FLAT_PATTERN": [
        r"\bFLAT\s+PATTERN\b", r"\bUNFOLD(?:ED|ING)?\b", r"\bDEVELOPED\s+(?:LENGTH|VIEW)\b",
        r"\bABWICKLUNG\b", r"\bABGEWICKELT\b", r"\bD[ÉE]PLI[ÉE]\b",
        r"\bROZWINI[ĘE]C(?:IE|IA)\b", r"\bROZWINI[ĘE]TY\b",
    ],
}

NDT_RULES = {
    "UT": [
        r"\bULTRASONIC\s+TEST(?:ING)?\b",
        r"\bULTRASCHALLPRÜFUNG\b", r"\bULTRASCHALLPRUEFUNG\b",
        r"\bCONTR[ÔO]LE\s+ULTRASONORE\b",
    ],
    "MT": [
        r"\bMAGNETIC\s+PARTICLE\s+(?:TEST(?:ING)?|INSPECTION)\b",
        r"\bMAGNETPULVERPRÜFUNG\b", r"\bMAGNETPULVERPRUEFUNG\b",
        r"\bMAGN[ÉE]TOSCOPIE\b", r"\bCONTR[ÔO]LE\s+MAGN[ÉE]TOSCOPIQUE\b",
    ],
    "PT": [
        r"\bLIQUID\s+PENETRANT\s+(?:TEST(?:ING)?|INSPECTION)\b",
        r"\bDYE\s+PENETRANT\b",
        r"\bEINDRINGPRÜFUNG\b", r"\bEINDRINGPRUEFUNG\b",
        r"\bRESSUAGE\b", r"\bCONTR[ÔO]LE\s+PAR\s+RESSUAGE\b",
    ],
    "RT": [
        r"\bRADIOGRAPHIC\s+TEST(?:ING)?\b", r"\bX-RAY\s+INSPECTION\b",
        r"\bDURCHSTRAHLUNGSPRÜFUNG\b", r"\bDURCHSTRAHLUNGSPRUEFUNG\b",
        r"\bRADIOGRAPHIE\b", r"\bCONTR[ÔO]LE\s+RADIOGRAPHIQUE\b",
    ],
}

LANGUAGE_MARKERS = {
    "PL": [
        "MATERIAŁ", "SPAWANIE", "OBRÓBKA", "MALOWANIE", "ŚRUTOWANIE",
        "TOLERANCJE", "BADANIA", "POWIERZCHNIA", "OTWÓR",
    ],
    "EN": [
        "MATERIAL", "WELDING", "MACHINING", "PAINTING", "COATING",
        "TOLERANCE", "INSPECTION", "SURFACE", "HOLE",
    ],
    "DE": [
        "WERKSTOFF", "SCHWEISSEN", "SCHWEISSUNG", "BEARBEITUNG", "ZERSPANUNG",
        "LACKIERUNG", "STRAHLEN", "ALLGEMEINTOLERANZEN", "BOHRUNG", "OBERFLÄCHE",
    ],
    "FR": [
        "MATIÈRE", "MATIERE", "SOUDAGE", "USINAGE", "PEINTURE",
        "GRENAILLAGE", "TOLÉRANCES", "TOLERANCES", "PERÇAGE", "PERCAGE", "RUGOSITÉ", "RUGOSITE",
    ],
}


def normalize_keyword_value(value: str) -> str:
    return value.strip().upper().rstrip(" .,:;")


def contains_keyword(upper_text: str, keyword: str) -> bool:
    token = keyword.strip().upper()

    if token in EXACT_SHORT_KEYWORDS:
        return re.search(
            rf"(?<![A-Z0-9]){re.escape(token)}(?![A-Z0-9])",
            upper_text
        ) is not None

    if token == "RA":
        return re.search(r"(?<![A-Z0-9])RA\s*[0-9]", upper_text) is not None

    return keyword.upper() in upper_text


def find_norms(text: str):
    found = []
    for pattern in NORM_PATTERNS:
        for match in pattern.finditer(text):
            value = " ".join(match.group(0).upper().split()).rstrip(" .,:;")
            if value not in found:
                found.append(value)
    return found[:40]


def add_unique(values, item):
    if item not in values:
        values.append(item)


def detect_keywords(text: str):
    upper = text.upper()
    keywords = []

    for item in KEYWORDS:
        # ISO fit case is semantic: uppercase H7/H8 belongs to a hole, lowercase
        # h7/h8 to a shaft. Do not let `SHAFT Ø50 h7` enable project-wide CNC.
        if item in {"H7", "H8"}:
            found = re.search(rf"(?<![A-Za-z0-9]){item}(?![A-Za-z0-9])", text) is not None
        else:
            found = contains_keyword(upper, item)
        if found:
            add_unique(keywords, normalize_keyword_value(item))

    for canonical, patterns in CANONICAL_RULES.items():
        if any(re.search(pattern, upper, re.IGNORECASE) for pattern in patterns):
            add_unique(keywords, canonical)

    for canonical, patterns in NDT_RULES.items():
        if any(re.search(pattern, upper, re.IGNORECASE) for pattern in patterns):
            add_unique(keywords, canonical)

    # Surface roughness is language-independent.
    if re.search(r"(?<![A-Z0-9])RA\s*[0-9]", upper):
        add_unique(keywords, "RA")

    return keywords


def detect_languages(text: str, norms):
    upper = text.upper()
    scores = {}

    for code, markers in LANGUAGE_MARKERS.items():
        score = sum(1 for marker in markers if marker in upper)
        if score:
            scores[code] = score

    # Distinguish American technical documentation from generic English.
    us_markers = ["AWS ", "ASTM ", "SSPC", "NACE", "GMAW", "FCAW", "SMAW", " IN.", " INCH", " MIL "]
    if scores.get("EN", 0) and any(marker in upper for marker in us_markers):
        scores["EN-US"] = scores["EN"] + 2

    # German/French national prefixes are strong hints.
    if any(n.startswith("DIN ") for n in norms):
        scores["DE"] = scores.get("DE", 0) + 2
    if any(n.startswith("NF ") for n in norms):
        scores["FR"] = scores.get("FR", 0) + 2
    if any(n.startswith("BS ") for n in norms):
        scores["EN-GB"] = scores.get("EN", 0) + 3

    if not scores:
        return []

    ranked = sorted(scores.items(), key=lambda x: (-x[1], x[0]))
    best_score = ranked[0][1]
    return [code for code, score in ranked if score >= max(1, best_score - 1)]



def _to_float_token(value: str):
    try:
        return float(value.replace(",", "."))
    except Exception:
        return None


_NON_WELD_GRADE_TOKEN_RE = re.compile(
    r"(?<![A-Z0-9=])A36(?![A-Z0-9])|(?<=\+)Z(?:15|25|35)(?![A-Z0-9])",
    re.IGNORECASE,
)
# FIX12D: drawing legends use A1:, A20:, A40:, A41: as requirement indexes
# (e.g. A40: ISO 17635-UT). They are not ISO 2553 weld throat dimensions.
_SPEC_INDEX_TOKEN_RE = re.compile(
    r"(?<![A-Z0-9])A(?:[1-9]\d?|100)\s*:(?=\s*(?:ISO|EN|DIN|ST|STA|TL|PA|PR|AWS|ASME|NDT|UT|MT|PT|RT)\b)",
    re.IGNORECASE,
)


def _mask_non_weld_grade_tokens(value: str) -> str:
    """Keep material grades out of the ambiguous a/z weld-size fallback.

    Bare ``A36`` is the ASTM steel grade; an unusually large weld must be written
    unambiguously as ``a=36`` or ``a 36``.  Likewise ``+Z25`` is a through-thickness
    steel quality, not a 25 mm z-dimension weld.
    """
    masked = _NON_WELD_GRADE_TOKEN_RE.sub(lambda m: " " * len(m.group(0)), value or "")
    return _SPEC_INDEX_TOKEN_RE.sub(lambda m: " " * len(m.group(0)), masked)


def _parse_engineering_number(value: str, decimal_comma_hint: bool = False):
    """Parse common PL/DE/EN engineering number formats.

    Examples: 2.926,073 -> 2926.073, 2,926.073 -> 2926.073,
    236,974 in a German context -> 236.974.  The function deliberately does
    not guess units; callers provide context (kg, mm, m2, quantity).
    """
    raw = re.sub(r"\s+", "", str(value or "")).replace("'", "")
    raw = raw.replace("−", "-").replace("–", "-")
    if not raw:
        return None
    raw = re.sub(r"[^0-9,\.\-+]", "", raw)
    if not raw or raw in {"+", "-", ".", ","}:
        return None
    try:
        if "," in raw and "." in raw:
            # The last punctuation mark is the decimal separator.
            if raw.rfind(",") > raw.rfind("."):
                normalized = raw.replace(".", "").replace(",", ".")
            else:
                normalized = raw.replace(",", "")
        elif "," in raw:
            parts = raw.split(",")
            if len(parts) == 2:
                left, right = parts
                # PL/DE drawings overwhelmingly use comma as decimal separator.
                # For mass/tolerance contexts decimal_comma_hint is set explicitly.
                if decimal_comma_hint or len(right) != 3 or len(left.lstrip("+-")) <= 3:
                    normalized = left + "." + right
                else:
                    normalized = left + right
            else:
                normalized = "".join(parts[:-1]) + "." + parts[-1]
        elif "." in raw and raw.count(".") > 1:
            parts = raw.split(".")
            # 2.926.073 is an integer thousands-grouping form.
            normalized = "".join(parts) if all(len(x) == 3 for x in parts[1:]) else "".join(parts[:-1]) + "." + parts[-1]
        else:
            normalized = raw
        return float(normalized)
    except Exception:
        return None


def _detect_document_mass(text: str):
    upper = text.upper()
    decimal_comma = bool(re.search(r"\b(?:GEWICHT|MENGE|MASSE|MASA|STÜCK|STUECK)\b", upper))
    label = (
        r"(?:CAD\s*(?:MASSE|MASS|GEWICHT)|MASSE\s+CAO|"
        r"NETTOGEWICHT|GESAMTGEWICHT|GEWICHT|WEIGHT|NET\s+WEIGHT|TOTAL\s+WEIGHT|"
        r"MASS|MASA(?:\s+NETTO|\s+CAŁKOWITA|\s+CALKOWITA)?|POIDS|MASSE)"
    )
    number = r"([0-9]{1,3}(?:[.\s][0-9]{3})*(?:,[0-9]{1,4})?|[0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{1,4})?|[0-9]+(?:[.,][0-9]+)?)"
    candidates = []

    # Classic form: label ... 138 kg.
    for m in re.finditer(label + r"[^0-9]{0,100}" + number + r"\s*(KG|KGS|KILOGRAM(?:S|ME)?|T|TON(?:NE|NES|S)?)\b", text, re.IGNORECASE | re.DOTALL):
        value = _parse_engineering_number(m.group(1), decimal_comma)
        if value is None:
            continue
        unit = m.group(2).upper()
        if unit in {"T", "TON", "TONS", "TONNE", "TONNES"}:
            value *= 1000.0
        if 0.001 <= value <= 1e8:
            basis = "jawna etykieta masy/ciężaru"
            if re.search(r"CAD\s*(?:MASSE|MASS|GEWICHT)|MASSE\s+CAO", m.group(0), re.IGNORECASE):
                basis = "CAD mass z tabelki rysunkowej"
            candidates.append((value, 94, basis, m.group(0).strip()[:220]))

    # Title blocks often put the unit in the HEADER -- e.g.
    # 'CAD Masse / CAD mass / Masse CAO (Kg)' -- and the value (138) in a
    # separate cell below. The old parser required '138 kg' and missed it.
    lines = [re.sub(r"\s+", " ", x).strip() for x in text.splitlines() if x.strip()]
    # Separate-cell lookahead is intentionally limited to the explicit CAD-mass
    # family. Generic 'Weight kg' labels are too common in title blocks and OCR
    # reading order may place unrelated revision/date digits after them.
    mass_header_re = re.compile(
        r"CAD\s*(?:MASSE|MASS|GEWICHT)|MASSE\s+CAO",
        re.IGNORECASE,
    )
    pure_number_re = re.compile(r"^[+]?([0-9]{1,7}(?:[.,][0-9]{1,4})?)$")
    for i, line in enumerate(lines):
        header_match = mass_header_re.search(line)
        if not header_match:
            continue
        # Look only a few visual/OCR rows ahead. Reject percentages (e.g. Welds
        # 0.000 %) and dates/drawing numbers. Prefer the last plausible standalone
        # number because CAD title blocks commonly put modifiers above the mass cell.
        local = []
        same_tail = line[header_match.end():].strip()
        if same_tail and "%" not in same_tail:
            # Accept a number in the same visual row after an optional '(kg)' unit.
            sm = re.search(r"(?:\(?\s*KG\s*\)?\s*)?(?:[:=]\s*)?([0-9]{1,7}(?:[.,][0-9]{1,4})?)\s*$", same_tail, re.IGNORECASE)
            if sm:
                value = _parse_engineering_number(sm.group(1), decimal_comma_hint=True)
                if value is not None and 0.1 <= value <= 1e7:
                    local.append((0, value, same_tail))
        for j, candidate_line in enumerate(lines[i + 1:i + 10], start=1):
            if "%" in candidate_line:
                continue
            cm = pure_number_re.fullmatch(candidate_line.strip())
            if not cm:
                continue
            value = _parse_engineering_number(cm.group(1), decimal_comma_hint=True)
            if value is None or not (0.001 <= value <= 1e7):
                continue
            # Tiny 0/1 values close to 'incl./welds' are usually flags/percent
            # remnants, not CAD mass. Keep legitimate sub-kilogram values only
            # when an explicit kg suffix exists (handled by the classic branch).
            if value < 0.1:
                continue
            local.append((j, value, candidate_line))
        if local:
            j, value, raw = local[-1]
            candidates.append((value, 93, "wartość pod nagłówkiem CAD mass (kg)", f"{line} -> {raw}"[:220]))

    # ERP/parts-list drawings often have a column header 'Menge Gewicht' and each
    # position stores quantity on one line and kg on the next. In a hierarchical BOM
    # summing those rows would double-count subassemblies, so use the largest row mass
    # as a fallback candidate rather than summing it.
    kg_values = []
    for m in re.finditer(r"(?<![A-Z0-9])" + number + r"\s*(KG|KGS|KILOGRAM(?:S|ME)?)\b", text, re.IGNORECASE):
        value = _parse_engineering_number(m.group(1), decimal_comma)
        if value is not None and 0.001 <= value <= 1e8:
            kg_values.append((value, m.group(0).strip()[:100]))
    table_context = bool(re.search(r"\bMENGE\b.{0,80}\bGEWICHT\b|\bQTY\b.{0,80}\bWEIGHT\b|\bILO[SŚ][ĆC]\b.{0,80}\bMASA\b", upper, re.DOTALL))
    if kg_values and not candidates:
        if table_context:
            value, raw = max(kg_values, key=lambda x: x[0])
            candidates.append((value, 68, "największa pozycja masy w hierarchicznym zestawieniu", raw))
        elif len(kg_values) == 1:
            value, raw = kg_values[0]
            candidates.append((value, 72, "jedyna wartość kg w dokumencie", raw))

    if not candidates:
        return None, 0, ""
    candidates.sort(key=lambda x: (x[1], x[0]), reverse=True)
    value, confidence, basis, raw = candidates[0]
    return value, confidence, f"{basis}: {raw}"

def _detect_explicit_surface_area(text: str):
    number = r"([0-9]+(?:[.,][0-9]+)?)"
    label = r"(?:PAINT(?:ING)?\s+AREA|COATING\s+AREA|SURFACE\s+AREA|OBERFL[ÄA]CHE|LACKIERFL[ÄA]CHE|POWIERZCHNIA(?:\s+MALOWANIA)?|SURFACE\s+À\s+PEINDRE)"
    for m in re.finditer(label + r"[^0-9]{0,50}" + number + r"\s*(M2|M²|QM|SQ\.?\s*M)\b", text, re.IGNORECASE):
        value = _parse_engineering_number(m.group(1), decimal_comma_hint=True)
        if value is not None and 0.001 <= value <= 1e7:
            return value, 90, m.group(0).strip()[:180]
    return None, 0, ""



def _hole_multiplicity(line: str, diameter_start: int) -> int:
    prefix = line[max(0, diameter_start - 72):diameter_start]
    descriptor = (
        r"(?:"
        r"(?:BOLT|SCREW)\s+HOLES?|"
        r"HOLES?|"
        r"OTW[ÓO]R(?:Y)?(?:\s+POD\s+(?:ŚRUBY|SRUBY))?|"
        r"SCHRAUBENBOHRUNG(?:EN)?|BOHRUNG(?:EN)?(?:\s+F[ÜU]R\s+SCHRAUBEN)?|"
        r"TROU(?:S)?(?:\s+DE\s+(?:BOULON|VIS))?"
        r")"
    )
    m = re.search(rf"(?:^|\s)(\d{{1,3}})\s*[X×](?:\s+{descriptor})?\s*$", prefix, re.IGNORECASE)
    if not m:
        return 1
    try:
        return max(1, min(999, int(m.group(1))))
    except Exception:
        return 1


def _engineering_scan_lines(text: str):
    """Return original lines plus short neighbour windows.

    OCR and CAD exports often split a nominal diameter, its +/- deviation and the
    datum/tolerance symbol into consecutive lines.  The semantic engine should bind
    those fragments before deciding that the drawing has no machining information.
    """
    lines = [re.sub(r"\s+", " ", x).strip() for x in text.splitlines() if x.strip()]
    out = list(lines)
    for i in range(len(lines)):
        for width in (2, 3):
            if i + width <= len(lines):
                joined = " ".join(lines[i:i + width])
                if len(joined) <= 420:
                    out.append(joined)
    # Preserve order, remove exact duplicates.
    return list(dict.fromkeys(out))


_DIAMETER_RE = re.compile(
    r"(?:[Ø⌀Φ@]|DIA(?:METER)?\.?|DIAM\.?|FI)\s*(\d+(?:[.,]\d+)?)",
    re.IGNORECASE,
)
_HOLE_CONTEXT_RE = re.compile(
    r"HOLES?|BORE|BOHRUNG(?:EN)?|OTW[ÓO]R(?:Y)?|TROU(?:S)?|THRU|THROUGH|PRZELOT",
    re.IGNORECASE,
)
_BOLT_CONTEXT_RE = re.compile(
    r"BOLT|SCREW|SCHRAUB|ŚRUB|SRUB|BOULON|VIS\b",
    re.IGNORECASE,
)
_EXTERNAL_DIAMETER_CONTEXT_RE = re.compile(
    r"SHAFT|WELLE|WA[ŁL]|ARBRE|BOLZEN|PIN\b|ROD\b|PR[ĘE]T|"
    r"AUSSEN(?:DURCHMESSER)?|OUTSIDE\s+DIAM(?:ETER)?|\bOD\b",
    re.IGNORECASE,
)


def _original_engineering_lines(text: str):
    """Clean source lines without recursively generated neighbour windows."""
    return [re.sub(r"\s+", " ", x).strip() for x in text.splitlines() if x.strip()]


def _nearest_diameter_context(line: str, diameter_start: int, diameter_end: int) -> str:
    """Return the closest semantic owner of one diameter callout.

    Generated CAD/OCR windows may contain several unrelated callouts. Binding by the
    closest marker prevents `BOLT HOLE Ø14 SHAFT Ø50` from turning Ø50 into a bolt
    hole and prevents uppercase/lowercase fit fragments from escaping shaft context.
    """
    candidates = []
    for kind, pattern in (
        ("external", _EXTERNAL_DIAMETER_CONTEXT_RE),
        ("bolt", _BOLT_CONTEXT_RE),
        ("hole", _HOLE_CONTEXT_RE),
    ):
        for match in pattern.finditer(line):
            if match.end() <= diameter_start:
                distance = diameter_start - match.end()
                side_penalty = 0
            elif match.start() >= diameter_end:
                distance = match.start() - diameter_end
                side_penalty = 2
            else:
                distance = 0
                side_penalty = 0
            if distance <= 64:
                candidates.append((distance, side_penalty, -match.start(), kind))
    return min(candidates)[3] if candidates else ""


def _hole_operation_flags(operation_hint: str, *, fit_confirmed=False,
                          precision=False, reamed=False, threaded=False):
    """Keep resource routing separate from the physical hole operations."""
    hint = (operation_hint or "").upper()
    requires_tap = bool(threaded or hint == "THREAD")
    requires_ream = bool(reamed or (hint == "FIT" and fit_confirmed)) and not requires_tap
    requires_bore = bool(precision and not requires_ream and not requires_tap and hint in {"FIT", "TOLERANCED"})
    requires_drill = hint not in {"DRAWING_DIAMETER", "DXF_CIRCLE"}
    requires_cnc = requires_drill or requires_ream or requires_tap or requires_bore
    return {
        "requiresDrill": requires_drill,
        "requiresReam": requires_ream,
        "requiresTap": requires_tap,
        "requiresBore": requires_bore,
        "requiresCnc": requires_cnc,
        "canThermalCut": hint in {"DRAWING_DIAMETER", "DXF_CIRCLE"},
    }


def _detect_erp_bom_items(text: str):
    """Recover common drawing-embedded ERP BOM rows from PDF/OCR text.

    This intentionally targets the frequent DE/PL layout where a part/document code
    is followed by quantity in ST/PCS and weight in KG.  It does not sum hierarchical
    masses; the drawing-mass detector separately selects the top-level/largest value.
    """
    upper = text.upper()
    if not re.search(r"\b(?:MENGE|QTY|QUANTITY|ILO[SŚ][ĆC])\b.{0,160}\b(?:GEWICHT|WEIGHT|MASA|MASS)\b", upper, re.DOTALL):
        return []
    lines = [re.sub(r"\s+", " ", x).strip() for x in text.splitlines() if x.strip()]
    part_re = re.compile(r"^(?P<part>[A-ZÄÖÜ]{1,8}[ -]?[A-Z0-9][A-Z0-9 ._/-]{2,70})$", re.IGNORECASE)
    qty_re = re.compile(r"(?P<qty>\d+(?:[.,]\d+)?)\s*(?:ST|STK|STCK|PCS|PC|SZT)\b", re.IGNORECASE)
    mass_re = re.compile(r"(?<![A-Z0-9])(?P<mass>[0-9]{1,3}(?:[.\s][0-9]{3})*(?:,[0-9]{1,4})?|[0-9]+(?:[.,][0-9]+)?)\s*KG\b", re.IGNORECASE)
    # A title block can contain MENGE + GEWICHT without being a BOM.  Require a
    # parts-list style header or multiple credible coded rows before promoting rows.
    has_parts_header = bool(re.search(
        r"\b(?:POS(?:NR)?|POSITION|DOKNR|DOKUMENTNR|TEIL(?:NR)?|PART\s*(?:NO|NUMBER)|ITEM|ARTIKEL(?:NR)?)\b",
        upper, re.IGNORECASE))
    reject_note = re.compile(
        r"\b(?:RAL|DFT|WELD|SCHWEISS|PAINT|MALOW|LACK|BESCHICHT|OBERFLAECH|OBERFLÄCH|"
        r"SA\s*2[.,]?5|DOKUMENT\s+TECHNICZNY|TECHNICAL\s+DOCUMENT|DOCUMENT\s+TECHNIQUE|"
        r"NOTES?|UWAGI|BEMERKUNGEN|TOLER|ALLGEMEIN|PROZESS|PROCESS|COLOR|COLOUR|FARBE|"
        r"ISO|DIN|ASTM|TOTAL\s+WEIGHT|TOTALWEIGHT|GESAMTGEWICHT|GESAMTMASSE|WEIGHT|GEWICHT|MENGE|MATERIAL|WERKSTOFF)\b", re.IGNORECASE)
    items = []
    seen = set()
    for i, line in enumerate(lines):
        pm = part_re.match(line)
        if not pm:
            continue
        part = pm.group('part').strip()
        # Avoid treating drawing notes (RAL/DFT/WELD/etc.) as purchased/BOM items.
        if reject_note.search(part):
            continue
        # Credible part/document identifiers contain a compact code, not only prose.
        compact_code = bool(re.search(r"(?:^|[ _./-])(?:[A-Z]{1,8}[-_ ]?)?\d{2,}[A-Z0-9._/-]*(?:$|[ _./-])", part, re.IGNORECASE))
        if not compact_code:
            continue
        window = " ".join(lines[i:i + 8])
        qm = qty_re.search(window)
        mm = mass_re.search(window)
        if not qm and not mm:
            continue
        qty = _parse_engineering_number(qm.group('qty'), decimal_comma_hint=True) if qm else 1.0
        mass = _parse_engineering_number(mm.group('mass'), decimal_comma_hint=True) if mm else None
        if qty is None or not (0 < qty <= 100000):
            qty = 1.0
        key = (part.upper(), round(qty, 3), round(mass or 0, 3))
        if key in seen:
            continue
        seen.add(key)
        item = {
            "partNumber": part[:120],
            "description": "",
            "quantity": qty,
            "material": "",
            "sourceFile": "PDF/OCR",
        }
        if mass is not None and 0 < mass <= 1e8:
            item["massKgEach"] = mass / max(qty, 1.0)
            item["totalMassKg"] = mass
        items.append(item)
        if len(items) >= 500:
            break
    # Two or more credible rows are enough even when OCR lost the POS/DOKNR header.
    # A single row without a parts-list header is much more likely to be a title-block note.
    if not has_parts_header and len(items) < 2:
        return []
    return items

def _detect_tolerances(text: str):
    dimensional = []
    geometric = []
    seen_dim = set()
    seen_geo = set()

    def add_dim(kind, plus=None, minus=None, symmetric=None, source=""):
        vals = [x for x in (plus, minus, symmetric) if x is not None]
        if not vals:
            return
        tight = min(abs(float(x)) for x in vals) <= 0.10
        key = (kind, round(plus or 0, 5), round(minus or 0, 5), round(symmetric or 0, 5))
        if key in seen_dim:
            return
        seen_dim.add(key)
        dimensional.append({
            "kind": kind,
            "plusMm": plus,
            "minusMm": minus,
            "symmetricMm": symmetric,
            "tight": tight,
            "sourceText": source.strip()[:220],
        })

    # Symmetric ± tolerances, including ASCII +/-. Neighbour windows recover
    # split OCR/CAD callouts such as "Ø50" on one line and "+0,025/+0,010" on the next.
    scan_lines = _engineering_scan_lines(text)
    for line in scan_lines:
        for m in re.finditer(r"(?:±|\+\s*/\s*-)\s*(\d+(?:[.,]\d+)?)\s*(?:MM)?", line, re.IGNORECASE):
            val = _parse_engineering_number(m.group(1), True)
            if val is not None and 0 < val <= 100:
                add_dim("SYMMETRIC", symmetric=val, source=line)
        # Explicit upper/lower deviations: +0.2 / -0.1 or +0,2 -0,1.
        m = re.search(r"\+\s*(\d+(?:[.,]\d+)?)\s*(?:/|\\|\s+)\s*-\s*(\d+(?:[.,]\d+)?)", line)
        if m:
            plus = _parse_engineering_number(m.group(1), True)
            minus = _parse_engineering_number(m.group(2), True)
            if plus is not None and minus is not None and max(plus, minus) <= 100:
                add_dim("BILATERAL", plus=plus, minus=minus, source=line)
        # Limit/unilateral notation often used on holes: +0,025/+0,010 or +0,025/0.
        m2 = re.search(r"\+\s*(\d+(?:[.,]\d+)?)\s*(?:/|\\|\s+)\s*\+?\s*(0(?:[.,]\d+)?|\d+(?:[.,]\d+)?)", line)
        if m2 and not re.search(r"/\s*-", m2.group(0)):
            upper = _parse_engineering_number(m2.group(1), True)
            lower = _parse_engineering_number(m2.group(2), True)
            if upper is not None and lower is not None and max(abs(upper), abs(lower)) <= 100:
                add_dim("LIMIT", plus=upper, minus=lower, source=line)

    # General tolerance notes such as "Allgemeintoleranzen ±0,5".
    general_pat = re.compile(r"(?:ALLGEMEIN(?:TOLERANZ(?:EN)?)?|GENERAL\s+TOLERANCES?|TOLERANCJE\s+OG[ÓO]LNE|TOL[ÉE]RANCES?\s+G[ÉE]N[ÉE]RALES?).{0,100}?(?:±|\+\s*/\s*-)?\s*(\d+(?:[.,]\d+)?)\s*MM", re.IGNORECASE)
    for m in general_pat.finditer(text):
        val = _parse_engineering_number(m.group(1), True)
        if val is not None and 0 < val <= 100:
            add_dim("GENERAL", symmetric=val, source=m.group(0))

    geo_rules = [
        ("POSITION", r"⌖|POSITION(?:AL)?\s+TOLERANCE|POSITIONSTOLERANZ|TOLERANCJA\s+PO[ŁL]O[ŻZ]ENIA|TOL[ÉE]RANCE\s+DE\s+POSITION"),
        ("FLATNESS", r"⏥|FLATNESS|EBENHEIT|P[ŁL]ASKO[SŚ][ĆC]|PLAN[ÉE]IT[ÉE]|PLANEITE"),
        ("PERPENDICULARITY", r"(?:⟂|⊥|_\s*\|\s*_)|PERPENDICULARITY|RECHTWINKLIGKEIT|PROSTOPAD[ŁL]O[SŚ][ĆC]|PERPENDICULARIT[ÉE]"),
        ("PARALLELISM", r"(?:∥|//|\|\s*\|)|PARALLELISM|PARALLELIT(?:[ÄA]T|AET)|R[ÓO]WNOLEG[ŁL]O[SŚ][ĆC]|PARALL[ÉE]LISME"),
        ("STRAIGHTNESS", r"STRAIGHTNESS|GERADHEIT|PROSTOLINIOWO[SŚ][ĆC]|RECTITUDE"),
        ("CIRCULARITY", r"CIRCULARITY|RUNDHEIT|OKR[ĄA]G[ŁL]O[SŚ][ĆC]|CIRCULARIT[ÉE]"),
        ("CYLINDRICITY", r"CYLINDRICITY|ZYLINDRIZIT(?:[ÄA]T|AET)|WALCOWO[SŚ][ĆC]|CYLINDRICIT[ÉE]"),
        ("RUNOUT", r"TOTAL\s+RUNOUT|CIRCULAR\s+RUNOUT|RUNOUT|RUNDLAUF|BICIE(?:\s+PROMIENIOWE|\s+CA[ŁL]KOWITE)?|BATTEMENT"),
    ]
    for line in scan_lines:
        for kind, pattern in geo_rules:
            m = re.search(pattern, line, re.IGNORECASE)
            if not m:
                continue
            tail = line[m.end():]
            vm = re.search(
                r"(?:[Ø⌀Φ]\s*)?(\d+(?:[.,]\d+)?)\s*(?:MM)?"
                r"(?:\s*[|/]?\s*([A-Z](?![A-Z])(?:\s*[-|/]\s*[A-Z](?![A-Z])){0,3}))?",
                tail, re.IGNORECASE)
            value = _parse_engineering_number(vm.group(1), True) if vm else None
            datum = re.sub(r"\s+", "", vm.group(2) or "") if vm else ""
            if value is not None and not (0 < value <= 100):
                value = None
            key = (kind, round(value or 0, 5), datum)
            if key in seen_geo:
                continue
            seen_geo.add(key)
            geometric.append({
                "type": kind,
                "valueMm": value,
                "datum": datum,
                "tight": value is not None and value <= 0.10,
                "sourceText": line.strip()[:220],
            })

    # If the same GD&T type was first seen as a bare word/symbol and later with an
    # actual numeric frame, keep the valued form.  This avoids showing/costing both
    # `PARALLELISM` and `PARALLELISM 0.05 A` from split OCR lines.
    valued_geo_types = {g.get("type") for g in geometric if g.get("valueMm") is not None}
    if valued_geo_types:
        geometric = [g for g in geometric if g.get("valueMm") is not None or g.get("type") not in valued_geo_types]

    return dimensional[:100], geometric[:100]


def detect_structured_technical_signals(text: str):
    upper = text.upper()
    signals = {
        "weldProcessCode": "",
        "weldTypeHint": "",
        "weldSizeKind": "",
        "weldSizeMm": None,
        "weldSideCount": 0,
        "weldSideCountConfirmed": False,
        "weldIntermittent": False,
        "weldIntermittentLengthMm": None,
        "weldPitchMm": None,
        "weldExplicitLengthMm": None,
        "weldExplicitLengthConfidence": 0,
        "weldExplicitLengthEvidence": "",
        "weldIntermittencyConfirmed": False,
        "weldAllAround": False,
        "weldGrooveAngleDeg": None,
        "weldRootGapMm": None,
        "surfacePreparation": "",
        "corrosionClass": "",
        "paintColour": "",
        "totalDftMicron": None,
        "paintLayers": [],
        "paintStripeCoatRequired": False,
        "holeRequirements": [],
        "dimensionalTolerances": [],
        "geometricTolerances": [],
        "documentMassKg": None,
        "documentMassConfidence": 0,
        "documentMassEvidence": "",
        "documentMassScope": "UNKNOWN",
        "documentSurfaceAreaM2": None,
        "documentSurfaceAreaConfidence": 0,
        "documentSurfaceAreaEvidence": "",
        "paintMaskMachinedSurfaces": False,
        # AUTO = external/accessible surfaces (current safe default).
        # ALL = external + internal non-mating surfaces. INTERNAL_ONLY and
        # EXTERNAL_ONLY are explicit drawing overrides.
        "paintScope": "AUTO",
        "paintScopeEvidence": "",
        "paintScopeConflict": False,
        "bomItems": [],
        "bomTotalMassKg": None,
        "bomMassRowCount": 0,
        "bomPositiveMassRowCount": 0,
    }

    document_mass, mass_conf, mass_evidence = _detect_document_mass(text)
    signals["documentMassKg"] = document_mass
    signals["documentMassConfidence"] = mass_conf
    signals["documentMassEvidence"] = mass_evidence
    if document_mass is not None:
        upper_mass = text.upper()
        # Explicit assembly language is strong enough for ASSEMBLY_TOTAL.  Generic
        # GESAMTGEWICHT/TOTAL WEIGHT in a title block remains UNKNOWN until BOM/table
        # structure confirms that it is the total for the whole list.
        if re.search(r"(?:ASSEMBLY|ZESP[ÓO][ŁL]|BAUGRUPPE).{0,45}(?:GEWICHT|WEIGHT|MASA|MASS)|(?:GEWICHT|WEIGHT|MASA|MASS).{0,45}(?:ASSEMBLY|ZESP[ÓO][ŁL]|BAUGRUPPE)", upper_mass, re.IGNORECASE | re.DOTALL):
            signals["documentMassScope"] = "ASSEMBLY_TOTAL"
        elif re.search(r"(?:ST[ÜU]CKGEWICHT|EINZELGEWICHT|PART\s+WEIGHT|MASA\s+DETALU|UNIT\s+WEIGHT)", upper_mass, re.IGNORECASE):
            signals["documentMassScope"] = "PART"
    erp_bom_items = _detect_erp_bom_items(text)
    if erp_bom_items:
        signals["bomItems"] = erp_bom_items
        signals["bomMassRowCount"] = sum(1 for x in erp_bom_items if x.get("totalMassKg") is not None)
        signals["bomPositiveMassRowCount"] = sum(1 for x in erp_bom_items if float(x.get("totalMassKg") or 0) > 0)
        if signals.get("documentMassKg") is not None and signals.get("documentMassScope") == "UNKNOWN" and len(erp_bom_items) >= 2:
            # FIX12D: the generic ERP fallback deliberately picks the largest row
            # from a hierarchical parts list; that is NOT the BOM total. Promote a
            # document mass to BOM_TOTAL only when the mass evidence itself carries
            # an explicit total label. Otherwise keep the value local/diagnostic.
            explicit_bom_total = re.search(
                r"GESAMTGEWICHT|GESAMTMASSE|TOTAL\s+WEIGHT|TOTAL\s+MASS|MASA\s+CA[ŁL]KOWITA|MASA\s+CAŁKOWITA",
                mass_evidence or "", re.IGNORECASE)
            if explicit_bom_total:
                signals["documentMassScope"] = "BOM_TOTAL"
            elif "największa pozycja masy" in (mass_evidence or "").lower():
                signals["documentMassScope"] = "SUBASSEMBLY"
    surface_area, surface_conf, surface_evidence = _detect_explicit_surface_area(text)
    signals["documentSurfaceAreaM2"] = surface_area
    signals["documentSurfaceAreaConfidence"] = surface_conf
    signals["documentSurfaceAreaEvidence"] = surface_evidence
    dim_tols, geo_tols = _detect_tolerances(text)
    signals["dimensionalTolerances"] = dim_tols
    signals["geometricTolerances"] = geo_tols

    # Hole semantics: unlike pure geometry, fit/thread/reaming information normally
    # comes from manufacturing annotations. Bind it to a nominal diameter when possible.
    hole_requirements = []
    seen_holes = set()
    # Preserve case for ISO fits. Hole fundamental deviations are uppercase
    # (e.g. H7), while shaft fits are lowercase (e.g. h7). Do not uppercase the
    # whole line before matching, otherwise shaft h7 becomes a false hole H7.
    # A bare letter D is accepted only as an explicit D= diameter marker; this
    # prevents WELD 135 a6 from being interpreted as a fictitious Ø135 A6 hole.
    fit_pat = re.compile(
        r"(?:[Ø⌀Φ@]|(?i:DIA(?:METER)?\.?|DIAM\.?|FI)|(?i:\bD)\s*=)"
        r"\s*(\d+(?:[.,]\d+)?)\s*(?i:MM)?\s*([A-Z]{1,2}\s*\d{1,2})(?![A-Za-z0-9])"
    )
    thread_pat = re.compile(
        r"(?<![A-Z0-9])M\s*(\d+(?:[.,]\d+)?)(?:\s*[X×]\s*(\d+(?:[.,]\d+)?))?(?![A-Z0-9])",
        re.IGNORECASE,
    )
    ream_context = re.compile(
        r"ROZWI(?:ER|ERT)|REAM(?:ED|ING)?|AL[ÉE]S(?:ÉE|AGE|ER)|AUFREIB",
        re.IGNORECASE,
    )
    precision_context = re.compile(
        r"FIT|PASOW|TOLER|LIMITS?\s*/?\s*FITS?|REAM|ROZWI|AL[ÉE]S|AUFREIB",
        re.IGNORECASE,
    )
    for line in _engineering_scan_lines(text):
        upper_line = line.upper()
        for m in fit_pat.finditer(line):
            if _nearest_diameter_context(line, m.start(), m.end()) == "external":
                continue
            dia = _to_float_token(m.group(1))
            fit = re.sub(r"\s+", "", m.group(2).upper())
            # ISO hole fits use an uppercase fundamental deviation. Restrict grades
            # to a plausible dimensional-tolerance range and reject common false tokens.
            gm = re.fullmatch(r"([A-Z]{1,2})(\d{1,2})", fit)
            if dia is None or gm is None:
                continue
            grade = int(gm.group(2))
            if not (3 <= grade <= 18) or not (0.5 <= dia <= 2000):
                continue
            key = (round(dia, 3), fit, "FIT")
            if key in seen_holes:
                continue
            seen_holes.add(key)
            hole_requirements.append({
                "nominalDiameterMm": dia,
                "count": _hole_multiplicity(line, m.start()),
                "fitCode": fit,
                "threadCode": "",
                "operationHint": "REAM" if ream_context.search(upper_line) else "FIT",
                "reamedLikely": bool(ream_context.search(upper_line)),
                # For costing, IT3-IT8 tied to a hole is treated as a confirmed
                # precision-fit hole. IT9-IT11 remains precision-machined but is
                # not labelled as a fitted hole without an explicit fit context.
                "fitConfirmed": grade <= 8,
                "precisionMachined": grade <= 11,
                "sourceText": line.strip()[:220],
                **_hole_operation_flags(
                    "REAM" if ream_context.search(upper_line) else "FIT",
                    fit_confirmed=grade <= 8,
                    precision=grade <= 11,
                    reamed=bool(ream_context.search(upper_line)),
                ),
            })

        # Explicit numerical tolerance on a hole, e.g. Ø50 +0,025/+0,010,
        # Ø20 +0.02/-0.01 or Ø12 ±0.02. This is a precision-machined hole even
        # without an ISO fit code such as H7.
        diameter_match = re.search(r"(?:[Ø⌀Φ@]|DIA(?:METER)?\.?|DIAM\.?|FI)\s*(\d+(?:[.,]\d+)?)", line, re.IGNORECASE)
        if diameter_match and _nearest_diameter_context(line, diameter_match.start(), diameter_match.end()) == "external":
            diameter_match = None
        if diameter_match:
            dia = _to_float_token(diameter_match.group(1))
            tol_match = re.search(
                r"(?:±|\+\s*/\s*-)\s*(\d+(?:[.,]\d+)?)"
                r"|\+\s*(\d+(?:[.,]\d+)?)\s*(?:/|\\|\s+)\s*([+-]?)\s*(\d+(?:[.,]\d+)?)",
                line,
                re.IGNORECASE,
            )
            if dia is not None and 0.5 <= dia <= 2000 and tol_match:
                tol_values = []
                for group in tol_match.groups():
                    if not group or group in {"+", "-"}:
                        continue
                    value = _to_float_token(group)
                    if value is not None:
                        tol_values.append(abs(value))
                if tol_values and max(tol_values) <= 2.0:
                    key = (round(dia, 3), "", "TOLERANCED")
                    if key not in seen_holes and not any(k[0] == round(dia, 3) and k[2] == "FIT" for k in seen_holes):
                        seen_holes.add(key)
                        hole_requirements.append({
                            "nominalDiameterMm": dia,
                            "count": _hole_multiplicity(line, diameter_match.start()),
                            "fitCode": "",
                            "threadCode": "",
                            "operationHint": "TOLERANCED",
                            "reamedLikely": max(tol_values) <= 0.05,
                            "fitConfirmed": False,
                            "precisionMachined": max(tol_values) <= 0.20,
                            "sourceText": line.strip()[:220],
                            **_hole_operation_flags(
                                "TOLERANCED",
                                precision=max(tol_values) <= 0.20,
                                reamed=max(tol_values) <= 0.05,
                            ),
                        })

        # Reamed/precision hole with diameter but without explicit ISO fit.
        if ream_context.search(upper_line):
            ream_markers = list(ream_context.finditer(line))
            diameter_candidates = [
                dm for dm in _DIAMETER_RE.finditer(line)
                if _nearest_diameter_context(line, dm.start(), dm.end()) != "external"
            ]
            dm = min(
                diameter_candidates,
                key=lambda item: min(abs(item.start() - marker.start()) for marker in ream_markers),
                default=None,
            )
            if dm is not None:
                dia = _to_float_token(dm.group(1))
                if dia is not None and 0.5 <= dia <= 2000:
                    key = (round(dia, 3), "", "REAM")
                    already_precision = any(k[0] == round(dia, 3) and k[2] == "FIT" for k in seen_holes)
                    if key not in seen_holes and not already_precision:
                        seen_holes.add(key)
                        hole_requirements.append({
                            "nominalDiameterMm": dia,
                            "count": _hole_multiplicity(line, dm.start()),
                            "fitCode": "",
                            "threadCode": "",
                            "operationHint": "REAM",
                            "reamedLikely": True,
                            "fitConfirmed": False,
                            "precisionMachined": True,
                            "sourceText": line.strip()[:220],
                            **_hole_operation_flags("REAM", precision=True, reamed=True),
                        })

        # Bolt / screw clearance hole. In welded fabrication these holes are normally
        # drilled/machined rather than treated as an arbitrary thermal-cut circle.
        # Require explicit fastener context close to a diameter to avoid classifying
        # unrelated drawing dimensions as bolt holes.
        if _BOLT_CONTEXT_RE.search(line):
            for dm_bolt in _DIAMETER_RE.finditer(line):
                dia_bolt = _to_float_token(dm_bolt.group(1))
                if dia_bolt is None or not (1 <= dia_bolt <= 200):
                    continue
                owner = _nearest_diameter_context(line, dm_bolt.start(), dm_bolt.end())
                if owner == "external" or owner not in {"bolt", "hole"}:
                    continue
                local = line[max(0, dm_bolt.start() - 64):min(len(line), dm_bolt.end() + 40)]
                if not _BOLT_CONTEXT_RE.search(local):
                    continue
                key = (round(dia_bolt, 3), "", "BOLT_CLEARANCE")
                if key in seen_holes or any(k[0] == round(dia_bolt, 3) and k[2] in {"FIT", "THREAD", "REAM", "TOLERANCED"} for k in seen_holes):
                    continue
                seen_holes.add(key)
                hole_requirements.append({
                    "nominalDiameterMm": dia_bolt,
                    "count": _hole_multiplicity(line, dm_bolt.start()),
                    "fitCode": "",
                    "threadCode": "",
                    "operationHint": "BOLT_CLEARANCE",
                    "reamedLikely": False,
                    "fitConfirmed": False,
                    "precisionMachined": True,
                    "sourceText": line.strip()[:220],
                    **_hole_operation_flags("BOLT_CLEARANCE", precision=True),
                })

        # Generic diameter callout. Even without H7/explicit tolerance it is useful
        # as a 2D hole candidate. It does NOT by itself force CNC; only precision
        # semantics/tolerances do that in CostEngine.
        for dm_plain in _DIAMETER_RE.finditer(line):
            dia_plain = _to_float_token(dm_plain.group(1))
            if dia_plain is None or not (0.5 <= dia_plain <= 2000):
                continue
            if any(k[0] == round(dia_plain, 3) for k in seen_holes):
                continue
            owner = _nearest_diameter_context(line, dm_plain.start(), dm_plain.end())
            explicit_hole_context = owner in {"hole", "bolt"}
            external_diameter_context = owner == "external"
            # A diameter symbol is a useful 2D cue, but a shaft/pin/OD callout is an
            # external diameter rather than a manufacturing hole.  The closest semantic
            # word before the diameter wins in mixed notes (HOLE Ø50 ... SHAFT Ø40).
            if external_diameter_context:
                continue
            # A diameter symbol is itself a strong drawing cue; text-only DIA/FI is
            # accepted when hole context is present.
            strong_symbol = line[dm_plain.start():dm_plain.start()+1] in "Ø⌀Φ@"
            if not strong_symbol and not explicit_hole_context:
                continue
            key = (round(dia_plain, 3), "", "DRAWING_DIAMETER")
            seen_holes.add(key)
            hole_requirements.append({
                "nominalDiameterMm": dia_plain,
                "count": _hole_multiplicity(line, dm_plain.start()),
                "fitCode": "",
                "threadCode": "",
                "operationHint": "DRAWING_DIAMETER",
                "reamedLikely": False,
                "fitConfirmed": False,
                "precisionMachined": False,
                "sourceText": line.strip()[:220],
                **_hole_operation_flags("DRAWING_DIAMETER"),
            })

        # Metric thread. Nominal M diameter is intentionally stored separately from
        # the geometric core/tap-drill diameter; reconciliation uses a coarse-thread table.
        thread_context = re.search(r"THREAD|TAPPED|GWINT|GEWINDE|TARAUD", upper_line, re.IGNORECASE)
        for tm in thread_pat.finditer(upper_line):
            nominal = _to_float_token(tm.group(1))
            if nominal is None or not (1 <= nominal <= 100):
                continue
            # To avoid interpreting material grades or random M-prefixed IDs, require
            # thread context OR a standard pitch expression Mxx x pitch.
            if not thread_context and not tm.group(2):
                continue
            pitch = _to_float_token(tm.group(2)) if tm.group(2) else None
            code = f"M{nominal:g}" + (f"x{pitch:g}" if pitch else "")
            key = (round(nominal, 3), code, "THREAD")
            if key in seen_holes:
                continue
            seen_holes.add(key)
            hole_requirements.append({
                "nominalDiameterMm": nominal,
                "count": _hole_multiplicity(line, tm.start()),
                "fitCode": "",
                "threadCode": code,
                "operationHint": "THREAD",
                "reamedLikely": False,
                "fitConfirmed": False,
                "precisionMachined": True,
                "sourceText": line.strip()[:220],
                **_hole_operation_flags("THREAD", precision=True, threaded=True),
            })

    # R9.3.0: recover `Ø50` + `H7` only from two adjacent ORIGINAL lines.
    # Never join generated windows and never cross an explicit shaft/OD context.
    original_lines = _original_engineering_lines(text)
    fit_token_re = re.compile(r"(?<![A-Za-z0-9])([A-Z]{1,2}\s*(?:[3-9]|1[01]))(?![A-Za-z0-9])")
    for i in range(len(original_lines) - 1):
        pair = original_lines[i:i + 2]
        if any(len(item) > 140 for item in pair):
            continue
        diameter_hits = [(line_index, match) for line_index, item in enumerate(pair) for match in _DIAMETER_RE.finditer(item)]
        fit_hits = [(line_index, match) for line_index, item in enumerate(pair) for match in fit_token_re.finditer(item)]
        if len(diameter_hits) != 1 or len(fit_hits) != 1:
            continue
        diameter_line, diameter_match = diameter_hits[0]
        fit_line, fit_match = fit_hits[0]
        if diameter_line == fit_line:
            continue  # same-line fits were already handled by fit_pat
        diameter_source = pair[diameter_line]
        if _nearest_diameter_context(diameter_source, diameter_match.start(), diameter_match.end()) == "external":
            continue
        if any(_EXTERNAL_DIAMETER_CONTEXT_RE.search(item) for item in pair):
            continue
        dia = _to_float_token(diameter_match.group(1))
        fit = re.sub(r"\s+", "", fit_match.group(1))
        gm = re.fullmatch(r"([A-Z]{1,2})(\d{1,2})", fit or "")
        if dia is None or gm is None or not (0.5 <= dia <= 2000):
            continue
        grade = int(gm.group(2))
        key = (round(dia, 3), fit, "FIT")
        if key in seen_holes:
            continue
        window = " ".join(pair)[:220]
        seen_holes.add(key)
        hole_requirements.append({
            "nominalDiameterMm": dia,
            "count": _hole_multiplicity(diameter_source, diameter_match.start()),
            "fitCode": fit,
            "threadCode": "",
            "operationHint": "FIT",
            "reamedLikely": False,
            "fitConfirmed": grade <= 8,
            "precisionMachined": True,
            "sourceText": window,
            **_hole_operation_flags("FIT", fit_confirmed=grade <= 8, precision=True),
        })

    # A split OCR/CAD callout may first yield a generic `Ø20` and later the same
    # diameter with H7/+/-/thread semantics.  Keep the specific representation and
    # drop the generic duplicate so downstream CNC time is not doubled.
    specific_diameters = {
        round(float(h.get("nominalDiameterMm") or 0), 3)
        for h in hole_requirements
        if h.get("operationHint") not in {"DRAWING_DIAMETER", "DXF_CIRCLE"}
        and float(h.get("nominalDiameterMm") or 0) > 0
    }
    hole_requirements = [
        h for h in hole_requirements
        if not (
            h.get("operationHint") in {"DRAWING_DIAMETER", "DXF_CIRCLE"}
            and round(float(h.get("nominalDiameterMm") or 0), 3) in specific_diameters
        )
    ]
    signals["holeRequirements"] = hole_requirements[:100]

    # Painting scope override. Geometry defaults to external/accessible faces, but
    # an explicit drawing note must win. Patterns deliberately require paint/coating
    # context so that notes such as "weld inside and outside" do not become a false
    # painting instruction. PL/EN/DE/FR are covered because those are the portable
    # OCR languages shipped with DS Estimate.
    paint_scope_patterns = {
        "ALL": [
            r"(?:PAINT|COAT|COATING|MALOW|POW[ŁL]OK|LACKIER|BESCHICHT|PEINDR|PEINTUR).*?(?:INSIDE|INTERNAL|WEWN[ĄA]TRZ|WEWN[ĘE]TRZN|INNEN|INT[ÉE]RIEUR).*?(?:OUTSIDE|EXTERNAL|ZEWN[ĄA]TRZ|ZEWN[ĘE]TRZN|AU(?:SS|ẞ)EN|EXT[ÉE]RIEUR)",
            r"(?:INSIDE|INTERNAL|WEWN[ĄA]TRZ|WEWN[ĘE]TRZN|INNEN|INT[ÉE]RIEUR).*?(?:OUTSIDE|EXTERNAL|ZEWN[ĄA]TRZ|ZEWN[ĘE]TRZN|AU(?:SS|ẞ)EN|EXT[ÉE]RIEUR).*?(?:PAINT|COAT|MALOW|LACKIER|BESCHICHT|PEINDR)",
            r"(?:PAINT|COAT|MALOW|LACKIER|BESCHICHT|PEINDR).*?(?:ALL\s+SURFACES|WSZYSTK(?:IE|ICH)\s+POWIERZCHN|ALLE\s+(?:FL[ÄA]CHEN|OBERFL[ÄA]CHEN)|TOUTES?\s+LES\s+SURFACES)",
            r"(?:ALL\s+SURFACES|WSZYSTK(?:IE|ICH)\s+POWIERZCHN|ALLE\s+(?:FL[ÄA]CHEN|OBERFL[ÄA]CHEN)|TOUTES?\s+LES\s+SURFACES).*?(?:PAINT|COAT|MALOW|LACKIER|BESCHICHT|PEINDR)",
            r"(?:PAINT|COAT|MALOW|LACKIER|BESCHICHT|PEINDR).*?(?:ALSO|R[ÓO]WNIE[ŻZ]|TAK[ŻZ]E|AUCH|[ÉE]GALEMENT).*?(?:INSIDE|INTERNAL|WEWN[ĄA]TRZ|WEWN[ĘE]TRZN|INNEN|INT[ÉE]RIEUR)",
            # A positive internal-paint note without ONLY means "internal too",
            # because external/accessible coating is the normal baseline.
            r"(?<!DO\sNOT\s)(?<!NOT\s)(?:PAINT|COAT)\s+(?:THE\s+)?(?:INTERNAL|INSIDE)\s+SURFACES?",
            r"(?:INTERNAL|INSIDE)\s+SURFACES?\s+(?:(?:SHALL|MUST|TO)\s+BE\s+)?(?:PAINTED|COATED)",
            r"(?<!NIE\s)MALOWA[ĆC]?\s+(?:R[ÓO]WNIE[ŻZ]\s+|TAK[ŻZ]E\s+)?(?:POWIERZCHNIE?\s+)?WEWN[ĘE]TRZN",
            r"INNENFL[ÄA]CHEN?\s+(?:LACKIEREN|BESCHICHTEN)",
            r"(?<!NE\sPAS\s)PEINDRE\s+(?:LES\s+)?SURFACES?\s+INT[ÉE]RIEURES?",
        ],
        "INTERNAL_ONLY": [
            r"(?:PAINT|COAT)\s+(?:ONLY\s+)(?:THE\s+)?(?:INTERNAL|INSIDE)\s+SURFACES?",
            r"MALOWA[ĆC]?\s+TYLKO\s+(?:POWIERZCHNIE?\s+)?WEWN[ĘE]TRZN",
            r"NUR\s+INNENFL[ÄA]CHEN?\s+(?:LACKIEREN|BESCHICHTEN)",
            r"PEINDRE\s+UNIQUEMENT\s+(?:LES\s+)?SURFACES?\s+INT[ÉE]RIEURES?",
            r"(?:PAINT|COAT|MALOW|LACKIER|BESCHICHT|PEINDR).*?(?:INTERNAL|INSIDE|WEWN[ĘE]TRZN|WN[ĘE]TRZ|INNENFL[ÄA]CH|INT[ÉE]RIEUR).*?(?:ONLY|TYLKO|NUR|UNIQUEMENT)",
            r"(?:INTERNAL|INSIDE|WEWN[ĘE]TRZN|WN[ĘE]TRZ|INNENFL[ÄA]CH|INT[ÉE]RIEUR).*?(?:ONLY|TYLKO|NUR|UNIQUEMENT).*?(?:PAINT|COAT|MALOW|LACKIER|BESCHICHT|PEINDR)",
        ],
        "EXTERNAL_ONLY": [
            r"(?:PAINT|COAT)\s+(?:ONLY\s+)(?:THE\s+)?(?:EXTERNAL|OUTSIDE)\s+SURFACES?",
            r"MALOWA[ĆC]?\s+TYLKO\s+(?:POWIERZCHNIE?\s+)?(?:ZEWN[ĘE]TRZN|ZEWN[ĄA]TRZ)",
            r"NUR\s+AU(?:SS|ẞ)ENFL[ÄA]CHEN?\s+(?:LACKIEREN|BESCHICHTEN)",
            r"PEINDRE\s+UNIQUEMENT\s+(?:LES\s+)?SURFACES?\s+EXT[ÉE]RIEURES?",
            r"(?:PAINT|COAT|MALOW|LACKIER|BESCHICHT|PEINDR).*?(?:EXTERNAL|OUTSIDE|ZEWN[ĘE]TRZN|ZEWN[ĄA]TRZ|AU(?:SS|ẞ)ENFL[ÄA]CH|EXT[ÉE]RIEUR).*?(?:ONLY|TYLKO|NUR|UNIQUEMENT)",
            r"(?:EXTERNAL|OUTSIDE|ZEWN[ĘE]TRZN|ZEWN[ĄA]TRZ|AU(?:SS|ẞ)ENFL[ÄA]CH|EXT[ÉE]RIEUR).*?(?:ONLY|TYLKO|NUR|UNIQUEMENT).*?(?:PAINT|COAT|MALOW|LACKIER|BESCHICHT|PEINDR)",
            r"(?:DO\s+NOT\s+PAINT|DO\s+NOT\s+COAT).*?(?:INTERNAL|INSIDE)\s+SURFACES?",
            r"(?:NIE\s+MALOWA[ĆC]?|NIE\s+POKRYWA[ĆC]?).*?(?:POWIERZCHN(?:I|IE)\s+WEWN[ĘE]TRZN|WN[ĘE]TRZ)",
            r"(?:INNENFL[ÄA]CHEN?).*?(?:NICHT\s+LACKIEREN|NICHT\s+BESCHICHTEN)",
            r"(?:NE\s+PAS\s+PEINDRE|NE\s+PAS\s+REV[ÊE]TIR).*?(?:SURFACES?\s+INT[ÉE]RIEURES?|INT[ÉE]RIEUR)",
        ],
    }
    scope_hits = []
    evidence = []
    # Evaluate sentence-sized notes, not the whole paragraph. This prevents
    # "do not paint internal. paint external" from being misread as an
    # "internal + external" instruction simply because both phrases share a line.
    paint_scope_segments = re.split(r"(?<=[.!?;])\s+|\n+", text)
    for line in paint_scope_segments:
        line_up = line.upper()
        segment_scopes = []
        for scope_name, patterns in paint_scope_patterns.items():
            if any(re.search(pattern, line_up, re.IGNORECASE) for pattern in patterns):
                segment_scopes.append(scope_name)
        # An explicit ONLY/negative instruction on the same sentence is more
        # specific than the generic positive "paint internal" pattern. True
        # contradictions in separate notes/sentences are still retained and
        # become a project-level conflict.
        if "INTERNAL_ONLY" in segment_scopes or "EXTERNAL_ONLY" in segment_scopes:
            segment_scopes = [x for x in segment_scopes if x != "ALL"]
        for scope_name in segment_scopes:
            if scope_name not in scope_hits:
                scope_hits.append(scope_name)
        if segment_scopes and line.strip() and line.strip() not in evidence:
            evidence.append(line.strip()[:220])

    if scope_hits:
        # If notes conflict, costing uses the conservative larger scope and exposes
        # the conflict for review. ALL is the conservative resolution.
        if len(scope_hits) > 1:
            signals["paintScopeConflict"] = True
            signals["paintScope"] = "ALL"
        else:
            signals["paintScope"] = scope_hits[0]
        signals["paintScopeEvidence"] = " | ".join(evidence[:4])

    # Do not treat a generic "DO NOT PAINT INTERNAL SURFACES" note as a request
    # to mask machined holes. Machined-surface masking now requires its own context.
    signals["paintMaskMachinedSurfaces"] = bool(re.search(
        r"(?:MACHINED|MACHINING)\s+(?:SURFACES?|AREAS?).{0,40}(?:DO\s+NOT\s+PAINT|UNPAINTED|MASK)|"
        r"(?:MASK(?:ING)?).{0,40}(?:MACHINED|MACHINING)|"
        r"POWIERZCHNIE\s+OBRABIANE.{0,40}(?:NIE.*MALOW|MASK)|"
        r"(?:BEARBEITETE|BEARBEITUNGS)\s*FL[ÄA]CHEN?.{0,40}(?:NICHT\s+LACKIEREN|NICHT\s+BESCHICHTEN|ABKLEBEN)|"
        r"(?:SURFACES?\s+USIN[ÉE]ES?).{0,40}(?:NE\s+PAS\s+PEINDRE|MASQUER)",
        upper, re.IGNORECASE
    ))
    signals["paintStripeCoatRequired"] = bool(re.search(
        r"STRIPE\s+COAT|STRIPE\s+COATING|PASEK\s+MALARSKI|MALOWANIE\s+KRAW[ĘE]DZI|KANTENVORSTRICH|KANTENBESCHICHTUNG|COUCHE\s+DE\s+RENFORT",
        upper, re.IGNORECASE
    ))

    # ISO 4063 process numbers, only when coupled to welding terminology.
    process_patterns = [
        r"(?:MAG|MIG|GMAW|FCAW|SMAW|MMA|E-?HAND|WELD(?:ING)?|SPAWAN(?:IE|IA)|SCHWEI[Sẞ]EN|SOUDAGE|PROC(?:ESS|ES|ÉDÉ)|PROZESS|VERFAHREN|METODA)\s*[:=#/\-]?\s*(111|135|136)\b",
        r"\b(111|135|136)\s*(?:MAG|MIG|GMAW|FCAW|SMAW|MMA)\b",
    ]
    for pattern in process_patterns:
        m = re.search(pattern, upper, re.IGNORECASE)
        if m:
            signals["weldProcessCode"] = m.group(1)
            break

    if re.search(
        r"\bFILLET\s+WELD\b|\bKEHLNAHT\b|\bSPOIN[AY]\s+PACHWIN|\bSOUDURE\s+D['’ ]?ANGLE\b",
        upper,
        re.IGNORECASE,
    ):
        signals["weldTypeHint"] = "FILLET"
    elif re.search(
        r"\bBUTT\s+WELD\b|\bGROOVE\s+WELD\b|\bSTUMPFNAHT\b|\bSPOIN[AY]\s+DOCZO|\bSOUDURE\s+BOUT",
        upper,
        re.IGNORECASE,
    ):
        signals["weldTypeHint"] = "GROOVE"

    # Groove-weld geometry for a physical weld-metal estimate. Supports common
    # EN/ISO drawing-note wording in PL/EN/DE/FR.
    groove_angle = re.search(
        r"(?:GROOVE\s+ANGLE|INCLUDED\s+ANGLE|K[ĄA]T\s+ROWKA|NAHTWINKEL|ANGLE\s+DE\s+CHANFREIN)\s*[:=]?\s*(\d+(?:[.,]\d+)?)\s*(?:°|DEG)?",
        upper, re.IGNORECASE)
    if groove_angle:
        value = _to_float_token(groove_angle.group(1))
        if value is not None and 20 <= value <= 160:
            signals["weldGrooveAngleDeg"] = value

    root_gap = re.search(
        r"(?:ROOT\s+GAP|ROOT\s+OPENING|SZCZELINA\s+(?:W\s+)?GRANI|WURZELSPALT|JEU\s+[ÀA]\s+LA\s+RACINE)\s*[:=]?\s*(\d+(?:[.,]\d+)?)\s*(?:MM)?",
        upper, re.IGNORECASE)
    if root_gap:
        value = _to_float_token(root_gap.group(1))
        if value is not None and 0 <= value <= 20:
            signals["weldRootGapMm"] = value

    # Weld-size parsing is restricted to lines that contain weld context.
    weld_context = re.compile(
        r"WELD|SPAW|SCHWEI|SOUD|KEHL|FILLET|NAHT|SPOINA|CORDON",
        re.IGNORECASE,
    )
    for line in text.splitlines():
        if not weld_context.search(line):
            continue
        weld_line = _mask_non_weld_grade_tokens(line.upper())
        m = re.search(
            r"(?<![A-Z0-9])([AZ])\s*=?\s*(\d+(?:[.,]\d+)?)\s*(?:MM)?\b(?!\s*:)",
            weld_line,
        )
        if m:
            value = _to_float_token(m.group(2))
            if value is not None and 0.5 <= value <= 50:
                signals["weldSizeKind"] = m.group(1).lower()
                signals["weldSizeMm"] = value
                break

    if signals["weldSizeMm"] is None:
        # US fillet weld dimensions are commonly specified as leg size in inches.
        for line in text.splitlines():
            if not weld_context.search(line):
                continue

            frac = re.search(
                r"(?<![0-9])(\d+)\s*/\s*(\d+)\s*(?:IN\.?|INCH(?:ES)?)\b",
                line.upper(),
            )
            dec = re.search(
                r"(?<![0-9])(\d+(?:\.\d+)?)\s*(?:IN\.?|INCH(?:ES)?)\b",
                line.upper(),
            )

            inches = None
            if frac:
                denominator = float(frac.group(2))
                if denominator > 0:
                    inches = float(frac.group(1)) / denominator
            elif dec:
                inches = float(dec.group(1))

            if inches is not None and 0.02 <= inches <= 2.0:
                signals["weldSizeKind"] = "z"
                signals["weldSizeMm"] = inches * 25.4
                break

    both_side_patterns = [
        r"\bOBUSTRONN",
        r"\bZ\s+OBU\s+STRON",
        r"\bBOTH\s+SIDES?\b",
        r"\bDOUBLE[- ]SIDED\b",
        r"\bBEIDSEITIG\b",
        r"\bBEIDE[NMR]?\s+SEITEN\b",
        r"\bDES\s+DEUX\s+C[ÔO]T[ÉE]S\b",
        r"\bDEUX\s+C[ÔO]T[ÉE]S\b",
    ]
    if any(re.search(p, upper, re.IGNORECASE) for p in both_side_patterns):
        signals["weldSideCount"] = 2
        signals["weldSideCountConfirmed"] = True
    elif any(
        re.search(p, upper, re.IGNORECASE)
        for p in [
            r"\bJEDNOSTRONN",
            r"\bONE\s+SIDE\b",
            r"\bSINGLE[- ]SIDED\b",
            r"\bEINSEITIG\b",
            r"\bUN\s+SEUL\s+C[ÔO]T[ÉE]\b",
        ]
    ):
        signals["weldSideCount"] = 1
        signals["weldSideCountConfirmed"] = True

    intermittent_patterns = [
        r"\bPRZERYWAN",
        r"\bINTERMITTENT\b",
        r"\bSTITCH\s+WELD",
        r"\bUNTERBROCHEN",
        r"\bINTERMITTIEREND",
        r"\bDISCONTINU",
    ]
    signals["weldIntermittent"] = any(
        re.search(p, upper, re.IGNORECASE) for p in intermittent_patterns
    )

    # Only reduce intermittent-weld length when both segment length and pitch/gap
    # are explicit. This mirrors mature CAD behavior and avoids optimistic guesses.
    intermittent_value_patterns = [
        r"(?:WELD|SPAW|SCHWEI|SOUD)[^\n]{0,100}?(?:LENGTH|D[ŁL]UGO[SŚ][CĆ]|L[ÄA]NGE|LONGUEUR)\s*[:=]?\s*(\d+(?:[.,]\d+)?)\s*MM[^\n]{0,80}?(?:PITCH|SKOK|TEILUNG|PAS)\s*[:=]?\s*(\d+(?:[.,]\d+)?)\s*MM",
        r"(?:INTERMITTENT|PRZERYWAN|UNTERBROCHEN|DISCONTINU)[^\n]{0,80}?(\d+(?:[.,]\d+)?)\s*MM[^\n]{0,50}?(?:@|CO|EVERY|PITCH|SKOK|TEILUNG|PAS)\s*(\d+(?:[.,]\d+)?)\s*MM",
    ]
    for pattern in intermittent_value_patterns:
        m = re.search(pattern, upper, re.IGNORECASE)
        if not m:
            continue
        wl = _to_float_token(m.group(1))
        pitch = _to_float_token(m.group(2))
        if wl and pitch and 1 <= wl <= pitch <= 5000:
            signals["weldIntermittent"] = True
            signals["weldIntermittentLengthMm"] = wl
            signals["weldPitchMm"] = pitch
            signals["weldIntermittencyConfirmed"] = True
            break

    # FIX10K / A5: an explicitly stated TOTAL weld length on a production
    # drawing outranks a STEP-only candidate length.  Keep this deliberately
    # narrow so an intermittent segment length or an arbitrary dimension does
    # not become a project-total weld length.
    explicit_length_patterns = [
        re.compile(r"(?:TOTAL\s+(?:WELD|WELDING)\s+LENGTH|TOTAL\s+LENGTH\s+OF\s+WELDS?|ŁĄCZNA\s+D[ŁL]UGO[SŚ][CĆ]\s+SPOIN|SUMA\s+D[ŁL]UGO[SŚ]CI\s+SPOIN|GESAMT(?:E)?\s+SCHWEI[Sẞ]NAHTL[ÄA]NGE|LONGUEUR\s+TOTALE\s+DES?\s+SOUDURES?)\s*[:=]?\s*(\d+(?:[.,]\d+)?)\s*(MM|M)\b", re.IGNORECASE),
        re.compile(r"(?:WELD|SPAW|SCHWEI[Sẞ]|SOUD)[^\n]{0,32}(?:LENGTH|D[ŁL]UGO[SŚ][CĆ]|L[ÄA]NGE|LONGUEUR)\s*(?:L\s*)?[:=]\s*(\d+(?:[.,]\d+)?)\s*(MM|M)\b", re.IGNORECASE),
    ]
    for line in text.splitlines():
        uline = line.upper()
        if re.search(r"INTERMITTENT|PRZERYWAN|STITCH|PITCH|SKOK|TEILUNG|DISCONTINU", uline, re.IGNORECASE):
            continue
        for index, pattern in enumerate(explicit_length_patterns):
            m = pattern.search(line)
            if not m:
                continue
            value = _to_float_token(m.group(1))
            if value is None:
                continue
            unit = (m.group(2) or "MM").upper()
            value_mm = value * 1000.0 if unit == "M" else value
            if 10 <= value_mm <= 10_000_000:
                signals["weldExplicitLengthMm"] = value_mm
                signals["weldExplicitLengthConfidence"] = 92 if index == 0 else 84
                signals["weldExplicitLengthEvidence"] = line.strip()[:220]
                break
        if signals["weldExplicitLengthMm"] is not None:
            break

    signals["weldAllAround"] = bool(re.search(
        r"ALL\s+AROUND|DOOKO[ŁL]A|WOKÓ[ŁL]|RUNDUM|TOUT\s+AUTOUR", upper, re.IGNORECASE
    ))

    prep_patterns = [
        r"\bSA\s*3\b",
        r"\bSA\s*2[.,]5\b",
        r"\bSA\s*2\b",
        r"\bST\s*3\b",
        r"\bST\s*2\b",
        r"\bSSPC[- ]SP\s*10\b",
        r"\bNACE\s*(?:NO\.?\s*)?2\b",
    ]
    for pattern in prep_patterns:
        m = re.search(pattern, upper, re.IGNORECASE)
        if m:
            signals["surfacePreparation"] = " ".join(m.group(0).upper().split()).replace(",", ".")
            break

    m = re.search(r"(?<![A-Z0-9])(C[345](?:-[A-Z])?)(?![A-Z0-9])", upper)
    if m:
        signals["corrosionClass"] = m.group(1)

    m = re.search(r"\bRAL\s*[-:]?\s*(\d{4})\b", upper)
    if m:
        signals["paintColour"] = f"RAL {m.group(1)}"

    dft_patterns = [
        r"\bDFT\s*[:=]?\s*(\d+(?:[.,]\d+)?)\s*([UµΜ]M|MICRONS?|MICROMET(?:ER|RE)S?|MILS?)\b",
        r"(?:DRY\s+FILM\s+THICKNESS|TROCKENSCHICHTDICKE|ÉPAISSEUR\s+S[ÈE]CHE|EPAISSEUR\s+SECHE|GRUBO[SŚ][CĆ]\s+SUCH(?:EJ|A)\s+POW[ŁL]OKI)\s*[:=]?\s*(\d+(?:[.,]\d+)?)\s*([UµΜ]M|MICRONS?|MILS?)\b",
    ]
    for pattern in dft_patterns:
        m = re.search(pattern, upper, re.IGNORECASE)
        if m:
            value = _to_float_token(m.group(1))
            unit = m.group(2).upper()
            if value is not None:
                if unit.startswith("MIL") and not unit.startswith("MIC"):
                    value *= 25.4
                if 5 <= value <= 3000:
                    signals["totalDftMicron"] = value
                    break

    # Fallback for a bare micron value only if coating context is present.
    if signals["totalDftMicron"] is None and re.search(
        r"PAINT|COAT|LACK|FARBE|PEINT|MALOW|POW[ŁL]OK",
        upper,
        re.IGNORECASE,
    ):
        m = re.search(r"\b(\d{2,4})\s*(?:[UµΜ]M|MICRONS?)\b", upper)
        if m:
            value = _to_float_token(m.group(1))
            if value is not None and 20 <= value <= 3000:
                signals["totalDftMicron"] = value

    layer_rules = [
        ("Podkład", r"PODK[ŁL]AD|PRIMER|GRUND(?:IERUNG|BESCHICHTUNG|ANSTRICH)?|APPR[ÊE]T"),
        ("Warstwa pośrednia", r"MI[ĘE]DZYWARSTW|INTERMEDIATE(?:\s+COAT)?|ZWISCHEN(?:BESCHICHTUNG|ANSTRICH)?|INTERM[ÉE]DIAIRE"),
        ("Nawierzchnia", r"NAWIERZCHN|TOP\s*COAT|TOPCOAT|FINISH(?:ING)?\s+COAT|DECKLACK|FINITION"),
    ]

    for line in text.splitlines():
        upper_line = line.upper()

        # A single note often contains the whole coating system, e.g.
        # "PRIMER 2x80 um + TOPCOAT 1x60 um". Older code stopped at the
        # first layer keyword and lost the following coat. Parse every layer
        # occurrence and bind the nearest thickness token to its own segment.
        occurrences = []
        for canonical_name, layer_pattern in layer_rules:
            for lm in re.finditer(layer_pattern, upper_line, re.IGNORECASE):
                occurrences.append((lm.start(), lm.end(), canonical_name))
        occurrences.sort(key=lambda x: x[0])

        for idx, (layer_start, layer_end, layer_name) in enumerate(occurrences):
            segment_end = occurrences[idx + 1][0] if idx + 1 < len(occurrences) else len(upper_line)
            segment = upper_line[layer_end:segment_end]
            m = re.search(
                r"(?:(\d{1,2})\s*[X×]\s*)?(\d+(?:[.,]\d+)?)\s*([UµΜ]M|MICRONS?|MILS?)\b",
                segment,
                re.IGNORECASE,
            )
            if not m:
                continue

            coat_count = int(m.group(1)) if m.group(1) else 1
            coat_count = max(1, min(coat_count, 12))
            value = _to_float_token(m.group(2))
            if value is None:
                continue

            unit = m.group(3).upper()
            if unit.startswith("MIL") and not unit.startswith("MIC"):
                value *= 25.4

            if not (5 <= value <= 1500):
                continue

            signals["paintLayers"].append({
                "name": layer_name,
                "dftMicron": value,
                "coatCount": coat_count,
            })

    # Coating systems are sometimes written only as "2x80 µm + 60 µm"
    # next to a painting/ISO 12944 note, without PRIMER/TOPCOAT words.
    # FIX10G: parse generic coats from ORIGINAL engineering lines only and never
    # reinterpret an explicit "total DFT 240 µm" note as several 240 µm layers.
    # Combined PDF/OCR passes can repeat the same total note multiple times; the
    # old whole-document scan turned those repeats into fictitious coats.
    if not signals["paintLayers"] and re.search(r"PAINT|COAT|LACK|BESCHICHT|ANSTRICH|MALOW|POW[ŁL]OK|ISO\s*12944", upper, re.IGNORECASE):
        generic_layers = []
        seen_generic = set()
        total_suffix_re = re.compile(
            r"(?:TOTAL\s+(?:DFT|DRY\s+FILM(?:\s+THICKNESS)?)|ŁĄCZN\w*\s+(?:DFT|GRUBO)|GESAMT\w*\s+(?:DFT|TROCKEN)|ÉPAISSEUR\s+TOTALE|EPAISSEUR\s+TOTALE)\s*[:=]?\s*\d+(?:[.,]\d+)?\s*(?:[UµΜ]M|MICRONS?|MILS?).*$",
            re.IGNORECASE,
        )
        micron_re = re.compile(r"(?:(\d{1,2})\s*[X×]\s*)?(\d+(?:[.,]\d+)?)\s*([UµΜ]M|MICRONS?|MILS?)", re.IGNORECASE)
        for source_line in _original_engineering_lines(text):
            if not re.search(r"PAINT|COAT|LACK|BESCHICHT|ANSTRICH|MALOW|POW[ŁL]OK|ISO\s*12944|PRIMER|TOPCOAT|INTERMEDIATE", source_line, re.IGNORECASE):
                continue
            candidate_line = total_suffix_re.sub("", source_line)
            matches = list(micron_re.finditer(candidate_line))
            # A generic layer system must contain explicit arithmetic/multiple coat
            # values. One bare micron token is a total/system DFT, not a layer list.
            if len(matches) < 2 and not re.search(r"\d{1,2}\s*[X×]\s*\d", candidate_line):
                continue
            for gm in matches:
                coats = max(1, min(int(gm.group(1) or 1), 12))
                value = _to_float_token(gm.group(2))
                if value is None:
                    continue
                unit = gm.group(3).upper()
                if unit.startswith("MIL") and not unit.startswith("MIC"):
                    value *= 25.4
                if not (5 <= value <= 1500):
                    continue
                key = (round(value, 3), coats, re.sub(r"\s+", " ", candidate_line.strip()).upper())
                if key in seen_generic:
                    continue
                seen_generic.add(key)
                generic_layers.append({"name": f"Warstwa {len(generic_layers)+1}", "dftMicron": value, "coatCount": coats})
        if len(generic_layers) >= 2:
            signals["paintLayers"] = generic_layers

    if signals["paintLayers"]:
        detailed_total = sum(
            layer["dftMicron"] * max(1, int(layer.get("coatCount", 1))) for layer in signals["paintLayers"]
        )
        explicit_total_marker = re.search(
            r"\bDFT\b|TOTAL\s+(?:DFT|DRY\s+FILM)|ŁĄCZN\w*\s+(?:DFT|GRUBO)|GESAMT\w*\s+(?:DFT|TROCKEN)|ÉPAISSEUR\s+TOTALE|EPAISSEUR\s+TOTALE",
            upper,
            re.IGNORECASE,
        )
        if signals["totalDftMicron"] is None or not explicit_total_marker:
            signals["totalDftMicron"] = detailed_total

    # Some DXF/PDF exporters split a weld symbol from its descriptive note. If the
    # document as a whole clearly contains welding context (or ISO 2553/5817), allow
    # a standalone a/z size token to supplement the missing association.
    if signals["weldSizeMm"] is None and (
        re.search(r"WELD|SPAW|SCHWEI|SOUD|KEHLNAHT|STUMPFNAHT", upper, re.IGNORECASE)
        or re.search(r"(?:ISO|EN\s+ISO|DIN\s+EN\s+ISO)\s+(?:2553|5817)", upper, re.IGNORECASE)
    ):
        candidates = []
        weld_candidate_text = _mask_non_weld_grade_tokens(text)
        for m in re.finditer(r"(?<![A-Z0-9])([AZ])\s*=?\s*(\d+(?:[.,]\d+)?)(?![A-Z0-9])(?!\s*:)", weld_candidate_text, re.IGNORECASE):
            value = _parse_engineering_number(m.group(2), True)
            # Standalone document-wide fallback has no leader/symbol binding.
            # Keep it conservative; very large a20/a40 tokens are much more often
            # requirement indexes than weld sizes in dense A0/A1 legends.
            if value is not None and 0.5 <= value <= 16:
                candidates.append((m.group(1).lower(), value))
        if candidates:
            kind, value = max(candidates, key=lambda x: x[1])
            signals["weldSizeKind"] = kind
            signals["weldSizeMm"] = value

    return signals

def result_from_text(text: str):
    material = ""
    material_reference = ""
    material_reference_confidence = 0
    material_reference_evidence = ""
    match = MATERIAL_RE.search(text)
    if match:
        material = " ".join(match.group(0).upper().split()).strip()
    table_grade, table_reference, table_conf, table_evidence = _detect_titleblock_material(text)
    if table_grade:
        material = table_grade
    elif table_reference:
        material_reference = table_reference
        material_reference_confidence = table_conf
        material_reference_evidence = table_evidence

    norms = find_norms(text)
    keywords = detect_keywords(text)
    languages = detect_languages(text, norms)

    findings = []
    signals = detect_structured_technical_signals(text)
    # Quantity/series hint is intentionally conservative. It is only used to amortize
    # setup/programming; it never multiplies geometry or BOM quantities silently.
    quantity_matches = []
    for pattern in (
        r"(?i)\b(?:ILO[SŚ][ĆC]|QTY|QUANTITY|MENGE|ST[ÜU]CK|SZT\.?|PCS\.?)\s*[:=]?\s*(\d{1,5})(?![.,]\d)",
        r"(?i)\b(\d{1,5})\s*(?:SZT\.?|PCS\.?|ST[ÜU]CK)\b",
    ):
        for m in re.finditer(pattern, text):
            try:
                value = int(m.group(1))
            except Exception:
                continue
            if 1 <= value <= 10000:
                quantity_matches.append(value)
    signals["projectQuantityHint"] = float(max(quantity_matches)) if quantity_matches else None

    if material:
        findings.append(f"Materiał: {material}")
    if material_reference:
        findings.append(
            f"Referencja/specyfikacja materiałowa: {material_reference} "
            "(nie użyto jako gatunku materiału)."
        )

    if norms:
        findings.append("Normy: " + ", ".join(norms[:8]))

    if languages:
        findings.append("Język dokumentacji: " + ", ".join(languages))

    if signals.get("documentMassKg") is not None:
        findings.append(
            f"Masa z dokumentacji: {signals['documentMassKg']:g} kg "
            f"(pewność {signals.get('documentMassConfidence',0)}%; {signals.get('documentMassEvidence','')})"
        )
    if signals.get("documentSurfaceAreaM2") is not None:
        findings.append(
            f"Powierzchnia z dokumentacji: {signals['documentSurfaceAreaM2']:g} m² "
            f"(pewność {signals.get('documentSurfaceAreaConfidence',0)}%)."
        )
    if signals.get("bomItems"):
        findings.append(f"PDF/OCR BOM: rozpoznano {len(signals['bomItems'])} pozycji ERP; mas hierarchicznych nie sumowano.")
    for tol in signals.get("dimensionalTolerances", [])[:12]:
        if tol.get("symmetricMm") is not None:
            findings.append(f"Tolerancja wymiarowa: ±{tol['symmetricMm']:g} mm")
        elif tol.get("plusMm") is not None or tol.get("minusMm") is not None:
            findings.append(f"Tolerancja wymiarowa: +{tol.get('plusMm',0):g}/-{tol.get('minusMm',0):g} mm")
    geo_labels = {
        "POSITION": "położenie", "FLATNESS": "płaskość", "PERPENDICULARITY": "prostopadłość",
        "PARALLELISM": "równoległość", "STRAIGHTNESS": "prostoliniowość", "CIRCULARITY": "okrągłość",
        "CYLINDRICITY": "walcowość", "RUNOUT": "bicie",
    }
    for tol in signals.get("geometricTolerances", [])[:12]:
        label = geo_labels.get(tol.get("type"), tol.get("type", "geometria"))
        value = tol.get("valueMm")
        datum = tol.get("datum") or ""
        findings.append(
            f"Tolerancja kształtu/położenia: {label}" +
            (f" {value:g} mm" if value is not None else "") +
            (f" względem {datum}" if datum else "")
        )

    if signals["weldProcessCode"]:
        findings.append(f"Proces spawania ISO 4063: {signals['weldProcessCode']}")
    if signals["weldTypeHint"]:
        findings.append(f"Typ spoiny: {signals['weldTypeHint']}")
    if signals["weldSizeMm"] is not None:
        findings.append(
            f"Wymiar spoiny: {signals['weldSizeKind']}{signals['weldSizeMm']:g}"
        )
    if signals["weldExplicitLengthMm"] is not None:
        findings.append(
            f"Jawna łączna długość spoin: {signals['weldExplicitLengthMm'] / 1000.0:g} m "
            f"(pewność {signals['weldExplicitLengthConfidence']}%)"
        )
    if signals["weldSideCount"] == 2:
        findings.append("Spawanie: obustronne")
    if signals["weldIntermittent"]:
        findings.append("Spawanie: przerywane / intermittent")
    if signals["surfacePreparation"]:
        findings.append(f"Przygotowanie powierzchni: {signals['surfacePreparation']}")
    if signals["corrosionClass"]:
        findings.append(f"Klasa korozyjności: {signals['corrosionClass']}")
    if signals["paintColour"]:
        findings.append(f"Kolor: {signals['paintColour']}")
    if signals["totalDftMicron"] is not None:
        findings.append(f"Łączna DFT: {signals['totalDftMicron']:g} µm")
    if signals["holeRequirements"]:
        for hole in signals["holeRequirements"][:12]:
            if hole["threadCode"]:
                findings.append(f"Otwór gwintowany: {hole['threadCode']}")
            elif hole["fitConfirmed"]:
                findings.append(f"Otwór pasowany: Ø{hole['nominalDiameterMm']:g} {hole['fitCode']}")
            elif hole["reamedLikely"]:
                findings.append(f"Otwór rozwiercany: Ø{hole['nominalDiameterMm']:g}")
    if signals["paintMaskMachinedSurfaces"]:
        findings.append("Powierzchnie obrabiane/maskowane: nie malować")
    if signals["paintStripeCoatRequired"]:
        findings.append("Malowanie: wymagany stripe coat / dodatkowe malowanie krawędzi i spoin")
    scope_labels = {
        "ALL": "zewnętrzne + wewnętrzne",
        "EXTERNAL_ONLY": "tylko zewnętrzne",
        "INTERNAL_ONLY": "tylko wewnętrzne",
    }
    if signals.get("paintScope") in scope_labels:
        findings.append("Zakres malowania: " + scope_labels[signals["paintScope"]])
    if signals.get("paintScopeConflict"):
        findings.append("Zakres malowania: wykryto sprzeczne zapisy; do kosztu przyjęto konserwatywnie powierzchnie zewnętrzne + wewnętrzne")

    if signals["paintLayers"]:
        layer_text = ", ".join(
            f"{layer['name']} {layer.get('coatCount',1)}x{layer['dftMicron']:g} µm"
            if int(layer.get('coatCount',1)) > 1 else f"{layer['name']} {layer['dftMicron']:g} µm"
            for layer in signals["paintLayers"]
        )
        findings.append("Warstwy malarskie: " + layer_text)

    return {
        "materialHint": material,
        "materialReference": material_reference,
        "materialReferenceConfidence": material_reference_confidence,
        "materialReferenceEvidence": material_reference_evidence,
        "keywords": keywords,
        "norms": norms,
        "findings": findings,
        "warnings": (["Sprzeczne wymagania zakresu malowania w jednym dokumencie; przyjęto konserwatywnie zewnętrzne + wewnętrzne."]
                     if signals.get("paintScopeConflict") else []),
        "extractedTextLength": len(text),
        "detectedLanguages": languages,
        "ocrLanguagesUsed": "",
        "ocrEnginePath": "",
        "ocrMeanConfidence": None,
        "ocrCriticalConfidence": None,
        "ocrLowConfidenceSignals": [],
        "ocrCriticalConflicts": [],
        **signals,
    }


def project_tessdata_dir():
    return Path(__file__).resolve().parents[2] / "tools" / "ocr" / "tessdata"


def resolve_tesseract_executable():
    from_path = shutil.which("tesseract")
    if from_path:
        return Path(from_path)

    local_appdata = Path.home() / "AppData" / "Local"

    script_root = Path(__file__).resolve().parents[2]
    candidates = [
        script_root / "tools" / "ocr" / "tesseract.exe",
        Path("tools/ocr/tesseract.exe"),
        Path(r"C:\Program Files\Tesseract-OCR\tesseract.exe"),
        Path(r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"),
        local_appdata / "Programs" / "Tesseract-OCR" / "tesseract.exe",
    ]

    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()

    return None


def configure_tesseract(pytesseract):
    executable = resolve_tesseract_executable()

    if executable is not None:
        pytesseract.pytesseract.tesseract_cmd = str(executable)

    local_tessdata = project_tessdata_dir()

    if local_tessdata.exists() and any(local_tessdata.glob("*.traineddata")):
        # Na Windows ustawiamy tessdata przez zmienną środowiskową.
        # To omija problemy z cytowaniem ścieżki w argumentach procesu.
        os.environ["TESSDATA_PREFIX"] = str(local_tessdata.resolve()) + os.sep

    return executable, ""


def choose_ocr_languages(pytesseract, config):
    preferred = ["pol", "eng", "deu", "fra"]

    try:
        available = set(pytesseract.get_languages(config=config))
    except Exception:
        available = set()

    selected = [code for code in preferred if code in available]

    if not selected:
        return None, []

    return "+".join(selected), selected



def _mupdf_layout_text(page):
    """Synthesize row-oriented text from PDF word coordinates.

    Standard PDF text extraction often walks each table column separately.  ERP/BOM
    drawings then lose the relationship between part number, quantity and weight.
    This companion representation groups words that sit on the same visual row and
    sorts them left-to-right.  The normal text layer is kept as well; downstream
    parsers see both representations and deduplicate exact lines.
    """
    try:
        raw_words = page.get_text("words") or []
    except Exception:
        return ""
    words = []
    for item in raw_words:
        if len(item) < 5:
            continue
        try:
            x0, y0, x1, y1 = map(float, item[:4])
        except Exception:
            continue
        text = str(item[4] or "").strip()
        if not text:
            continue
        words.append((x0, y0, x1, y1, text))
    if not words:
        return ""

    words.sort(key=lambda w: ((w[1] + w[3]) / 2.0, w[0]))
    rows = []
    for word in words:
        cy = (word[1] + word[3]) / 2.0
        height = max(1.0, word[3] - word[1])
        best = None
        best_dist = None
        for row in rows[-8:]:
            tolerance = max(2.0, min(8.0, max(height, row["height"]) * 0.48))
            dist = abs(cy - row["cy"])
            if dist <= tolerance and (best_dist is None or dist < best_dist):
                best = row
                best_dist = dist
        if best is None:
            rows.append({"cy": cy, "height": height, "words": [word]})
        else:
            n = len(best["words"])
            best["cy"] = (best["cy"] * n + cy) / (n + 1)
            best["height"] = max(best["height"], height)
            best["words"].append(word)

    rendered = []
    for row in sorted(rows, key=lambda r: r["cy"]):
        row_words = sorted(row["words"], key=lambda w: w[0])
        line = " ".join(w[4] for w in row_words)
        line = re.sub(r"\s+", " ", line).strip()
        if line:
            rendered.append(line)
    return "\n".join(rendered)

def _mupdf_titleblock_semantic_text(page):
    """Recover label->value relations from PDF word coordinates.

    Text extraction from CAD title blocks often walks columns independently.  This
    helper emits a tiny synthetic semantic layer for critical cells whose value is
    spatially below the label (CAD mass, material). It never invents a grade/value:
    only existing PDF words are rebound by proximity.
    """
    try:
        raw = page.get_text("words") or []
    except Exception:
        return ""
    words = []
    for item in raw:
        if len(item) < 5:
            continue
        try:
            x0, y0, x1, y1 = map(float, item[:4])
        except Exception:
            continue
        text = str(item[4] or "").strip()
        if text:
            words.append({"x0": x0, "y0": y0, "x1": x1, "y1": y1, "text": text, "u": text.upper()})
    if not words:
        return ""

    emitted = []
    number_word = re.compile(r"^[0-9]{1,7}(?:[.,][0-9]{1,4})?$")
    reject_value = re.compile(r"^(?:KG|KGS|DATE|DATUM|PAGE|SHEET|BLATT|INDEX|REV|REVISION)$", re.IGNORECASE)

    def center(w):
        return ((w["x0"] + w["x1"]) / 2.0, (w["y0"] + w["y1"]) / 2.0)

    # CAD mass anchors: require CAD+MASS(E/GEWICHT) or MASSE+CAO on the same row.
    anchors = []
    for i, w in enumerate(words):
        for j in range(max(0, i-3), min(len(words), i+4)):
            if i == j:
                continue
            v = words[j]
            same_row = abs(center(w)[1] - center(v)[1]) <= max(4.0, (w["y1"]-w["y0"] + v["y1"]-v["y0"]) * 0.55)
            if not same_row:
                continue
            pair = {w["u"], v["u"]}
            if ("CAD" in pair and any(x.startswith("MASS") or x.startswith("GEWICHT") for x in pair)) or ("MASSE" in pair and "CAO" in pair):
                x0=min(w["x0"],v["x0"]); x1=max(w["x1"],v["x1"]); y1=max(w["y1"],v["y1"])
                anchors.append((x0,x1,y1))
    for x0,x1,y1 in anchors:
        ac=(x0+x1)/2.0
        cands=[]
        for idx,c in enumerate(words):
            if c["y0"] < y1-2 or c["y0"] > y1+140:
                continue
            if not number_word.fullmatch(c["text"]):
                continue
            # reject a percentage token or a numeric word immediately followed by %
            if any(abs(center(n)[1]-center(c)[1]) < 5 and 0 <= n["x0"]-c["x1"] < 35 and "%" in n["text"] for n in words):
                continue
            val=_parse_engineering_number(c["text"], decimal_comma_hint=True)
            if val is None or val < 0.1 or val > 1e7:
                continue
            cx,cy=center(c)
            if abs(cx-ac) > 220:
                continue
            score=(cy-y1) + abs(cx-ac)*0.35
            cands.append((score,c["text"]))
        if cands:
            cands.sort(key=lambda x:x[0])
            emitted.append(f"CAD mass (kg) {cands[0][1]}")
            break

    # Material anchors. A vendor/internal identifier is kept as a reference by the
    # normal title-block classifier; a true grade such as S355 remains MaterialHint.
    material_anchors=[w for w in words if re.sub(r"[^A-ZÀ-Ž]", "", w["u"]) in {"WERKSTOFF","MATERIAL","MATERIAŁ","MATIERE","MATIÈRE","MATERIA"}]
    for a in material_anchors:
        ac,_=center(a)
        cands=[]
        for c in words:
            if c["y0"] < a["y1"]-2 or c["y0"] > a["y1"]+110:
                continue
            rawv=_clean_titleblock_value(c["text"])
            if not rawv or reject_value.match(rawv):
                continue
            if _TITLEBLOCK_MATERIAL_LABEL_RE.fullmatch(rawv):
                continue
            if not (MATERIAL_RE.search(rawv) or _looks_like_material_reference(rawv)):
                continue
            cx,cy=center(c)
            if abs(cx-ac) > 260:
                continue
            cands.append(((cy-a["y1"])+abs(cx-ac)*0.25, rawv))
        if cands:
            cands.sort(key=lambda x:x[0])
            emitted.append("Werkstoff / Material " + cands[0][1])
            break

    return "\n".join(dict.fromkeys(emitted))


def select_ocr_page_indices(page_count: int, page_cap: int, priority_indices=None):
    """Return a deterministic, representative OCR sample.

    Supplier manuals and multi-sheet drawing packs often keep the assembly title
    block, revision summary or final manufacturing notes on the last sheet. The
    former first-N policy silently missed those pages whenever the safety cap was
    reached. Keep the same memory/time ceiling, but cover the whole document.
    """
    count = max(0, int(page_count or 0))
    cap = max(0, int(page_cap or 0))
    if count == 0 or cap == 0:
        return []
    if count <= cap:
        return list(range(count))

    # FIX22: a scanned drawing inside a searchable multi-sheet PDF must take
    # precedence over uniformly sampled, already-searchable pages.
    priority = sorted({int(i) for i in (priority_indices or ()) if 0 <= int(i) < count})
    if priority:
        if len(priority) >= cap:
            if cap == 1:
                return [priority[0]]
            return sorted({priority[round(i * (len(priority) - 1) / (cap - 1))]
                           for i in range(cap)})
        baseline = select_ocr_page_indices(count, cap)
        selected = set(priority)
        selected.update(i for i in baseline if i not in selected and len(selected) < cap)
        if len(selected) < cap:
            selected.update(i for i in range(count) if i not in selected and len(selected) < cap)
        return sorted(selected)

    if cap == 1:
        return [0]

    selected = {round(i * (count - 1) / (cap - 1)) for i in range(cap)}
    if len(selected) < cap:
        selected.update(i for i in range(count) if i not in selected and len(selected) < cap)
    return sorted(selected)[:cap]



def _raster_union_area(rectangles, required_area: float) -> bool:
    """Measure the visible union of raster tiles without counting overlaps twice.

    FIX25: a 512-image shortlist missed CAD PDFs exported as 1024+ tiny
    non-overlapping tiles.  Use an x-sweep and a compressed-y segment tree:
    O(N log N) time and O(N) memory instead of a quadratic scan.  A generous
    20,000-image ceiling protects against pathological documents; exceeding it
    is a conservative (possible false-negative), never an overcount.
    """
    if not rectangles:
        return False
    if required_area <= 0:
        return True
    if len(rectangles) > 20_000:
        rectangles = sorted(
            rectangles, key=lambda r: (r[2] - r[0]) * (r[3] - r[1]),
            reverse=True,
        )[:20_000]
    if any((r[2] - r[0]) * (r[3] - r[1]) >= required_area for r in rectangles):
        return True

    ys = sorted({y for r in rectangles for y in (r[1], r[3])})
    if len(ys) < 2:
        return False
    y_index = {y: i for i, y in enumerate(ys)}
    events = []
    for x0, y0, x1, y1 in rectangles:
        if x1 <= x0 or y1 <= y0:
            continue
        lo, hi = y_index[y0], y_index[y1]
        events.append((x0, 1, lo, hi))
        events.append((x1, -1, lo, hi))
    if not events:
        return False
    events.sort()

    # Each tree node stores the count of rectangles spanning its entire
    # y interval and the resulting covered length of that interval.
    n = len(ys) - 1
    counts = [0] * (4 * n + 4)
    covered = [0.0] * (4 * n + 4)

    def update(node, left, right, qleft, qright, delta):
        if qleft <= left and right <= qright:
            counts[node] += delta
        else:
            mid = (left + right) // 2
            if qleft < mid:
                update(node * 2, left, mid, qleft, qright, delta)
            if qright > mid:
                update(node * 2 + 1, mid, right, qleft, qright, delta)
        if counts[node] > 0:
            covered[node] = ys[right] - ys[left]
        elif right - left == 1:
            covered[node] = 0.0
        else:
            covered[node] = covered[node * 2] + covered[node * 2 + 1]

    area = 0.0
    previous_x = events[0][0]
    i = 0
    while i < len(events):
        x = events[i][0]
        area += (x - previous_x) * covered[1]
        if area >= required_area:
            return True
        while i < len(events) and events[i][0] == x:
            _, delta, lo, hi = events[i]
            update(1, 0, n, lo, hi, delta)
            i += 1
        previous_x = x
    return False


def _page_has_scanned_drawing(page, min_image_fraction: float = 0.30) -> bool:
    """Detect large, tiled and inline scans on pages with little searchable text.

    `get_images()` lists PDF XObjects and can omit inline images; the prior
    24-XObject limit also missed tiled scans. `get_image_info()` reports drawn
    image positions including inline images, without decoding image payloads.
    Count clipped, non-overlapping *visible* area, not the number of images.
    """
    try:
        import math
        page_rect = page.rect
        x0, y0 = float(page_rect.x0), float(page_rect.y0)
        x1, y1 = float(page_rect.x1), float(page_rect.y1)
        area = (x1 - x0) * (y1 - y0)
        if not math.isfinite(area) or area <= 0:
            return False
        required = area * max(0.0, float(min_image_fraction))
        rects = []
        # PyMuPDF: includes inline images, unlike page.get_images().
        if hasattr(page, 'get_image_info'):
            raw_rects = (item.get('bbox') for item in page.get_image_info(xrefs=False))
        else:
            # Older MuPDF bindings: preserve the original XObject fallback.
            raw_rects = (rect for item in page.get_images(full=False)
                         for rect in page.get_image_rects(item[0]))
        for rect in raw_rects:
            if rect is None or len(rect) < 4:
                continue
            a, b, c, d = map(float, rect[:4])
            if not all(math.isfinite(v) for v in (a, b, c, d)):
                continue
            a, b, c, d = max(a, x0), max(b, y0), min(c, x1), min(d, y1)
            if c > a and d > b:
                rects.append((a, b, c, d))
        return _raster_union_area(rects, required)
    except Exception:
        # Heuristic failures must never abort extraction of the text layer.
        return False


# FIX24: searchable title blocks can coexist with raster-only geometry.
# Keep the extra OCR path conservative: at least two *different* title-block
# labels, little searchable text, and >=70% raster coverage.  A photograph in a
# manual or a small logo must not trigger costly technical OCR.
_PDF_TITLEBLOCK_CUES = (
    re.compile(r"\b(?:DRAWING|RYSUNEK|ZEICHNUNG|SHEET|BLATT|ARKUSZ)\b", re.IGNORECASE),
    re.compile(r"\b(?:MATERIAL|WERKSTOFF|MATERIA[ŁL])\b", re.IGNORECASE),
    re.compile(r"\b(?:REVISION|REV\.?|REWIZJA|ÄNDERUNGSSTAND)\b", re.IGNORECASE),
    re.compile(r"\b(?:SCALE|SKALA|MA[Sß]STAB)\b", re.IGNORECASE),
    re.compile(r"\b(?:PART\s*(?:NO\.?|NUMBER)|TEILNR\.?|DOKNR\.?|NUMER\s+RYSUNKU)\b", re.IGNORECASE),
    re.compile(r"\b(?:WEIGHT|GEWICHT|MASA)\b", re.IGNORECASE),
    re.compile(r"\b(?:TOLERANCE|TOLERANZ|TOLERANCJE)\b", re.IGNORECASE),
)


def find_sparse_raster_pdf_pages(page_texts, pages) -> list[int]:
    """Find likely raster drawings, including pages with searchable title blocks.

    The original <120-character branch is retained.  A second, stricter branch
    catches CAD PDFs where the title block is text but dimensions/geometry are
    raster.  The function returns only OCR candidates, not a verified BOM.
    """
    result = []
    for index, (text, page) in enumerate(zip(page_texts, pages)):
        content = (text or '').strip()
        if len(content) < 120:
            is_candidate = _page_has_scanned_drawing(page)
        elif len(content) < 900 and sum(bool(cue.search(content)) for cue in _PDF_TITLEBLOCK_CUES) >= 2:
            is_candidate = _page_has_scanned_drawing(page, min_image_fraction=0.70)
        else:
            is_candidate = False
        if is_candidate:
            result.append(index)
    return result


def bounded_pdf_ocr_zoom(width_points: float, height_points: float,
                         preferred_zoom: float, max_pixels: int) -> float:
    """Keep OCR rasterization within its pixel budget, including large sheets.

    A fixed minimum zoom of 1.15 previously overrode the megapixel cap for
    unusually large A0+/custom drawing sheets. The 2% margin accommodates
    integer rounding when MuPDF converts PDF coordinates to pixel dimensions.
    """
    page_pixels = max(1.0, float(width_points) * float(height_points))
    budget = max(1, int(max_pixels))
    return min(float(preferred_zoom), 0.98 * (budget / page_pixels) ** 0.5)


# FIX26: evidence is kept per physical PDF sheet. It is diagnostic only: an
# apparent material or BOM row on one sheet must not be assigned automatically
# to every part in a multi-sheet drawing pack.
_PDF_DRAWING_ID_LABEL = (
    r"(?:DRAWING[ \t]*(?:NO\.?|NUMBER|NR\.?)?|DWG[ \t]*(?:NO\.?|NR\.?)?|"
    r"RYSUNEK[ \t]*(?:NR\.?)?|NUMER[ \t]+RYSUNKU|NR\.?[ \t]+RYS(?:UNKU)?\.?|"
    r"ZEICHNUNGS[- \t]*(?:NR\.?|NUMMER)|DOK(?:UMENT)?[ \t]*(?:NR\.?|NO\.?))"
)
# PDF/CAD text extraction often puts the value in the next table cell/line,
# or omits a colon after the title-block label. Keep both patterns anchored
# to avoid treating arbitrary BOM positions as drawing identifiers.
_PDF_DRAWING_ID_LINE = re.compile(
    rf"(?im)^[ \t]*{_PDF_DRAWING_ID_LABEL}[ \t]*(?:[:#=-][ \t]*|[ \t]+)"
    r"([A-Z0-9][A-Z0-9._/-]{2,55})[ \t]*$"
)
_PDF_DRAWING_ID_NEXT_ROW = re.compile(
    rf"(?im)^[ \t]*{_PDF_DRAWING_ID_LABEL}[ \t]*[:#=-]?[ \t]*\r?\n"
    r"[ \t]*([A-Z0-9][A-Z0-9._/-]{2,55})[ \t]*(?=\r?\n|$)"
)


def _pdf_drawing_numbers(text: str) -> list[str]:
    """Conservative, page-local title-block IDs; never infer an ID from BOM.

    A next-row ID needs a recognizable identifier shape because a PDF text
    extractor can reorder neighboring table cells. Grades, dates and short
    dimensions must not silently become drawing numbers.
    """
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    candidates = []
    for multiline, pattern in ((False, _PDF_DRAWING_ID_LINE),
                               (True, _PDF_DRAWING_ID_NEXT_ROW)):
        for match in pattern.finditer(text or ""):
            token = match.group(1).upper()
            if not any(ch.isdigit() for ch in token) or MATERIAL_RE.fullmatch(token):
                continue
            if re.fullmatch(r"\d{4}[-/.]\d{1,2}[-/.]\d{1,2}", token):
                continue  # date (YYYY-MM-DD etc.), not a drawing identifier
            if multiline:
                structured = any(ch in token for ch in "-_/.")
                long_number = bool(re.fullmatch(r"[A-Z]{0,4}\d{5,}[A-Z0-9]*", token))
                letter_number = bool(re.fullmatch(r"[A-Z]{1,4}\d{4,}[A-Z0-9]*", token))
                if not (structured or long_number or letter_number):
                    continue
                if re.fullmatch(r"\d{1,5}\.\d{1,3}", token):
                    continue  # likely a decimal dimension
            candidates.append((match.start(), token))
    candidates.sort(key=lambda row: row[0])
    return list(dict.fromkeys(token for _, token in candidates))[:12]


def _pdf_page_evidence(page_texts, ocr_by_page=None, scanned_indices=(), source_file="", ocr_attempted=()):
    """Create non-authoritative, page-scoped audit metadata (1-based pages).

    Only rows recovered *within the same page* can appear as a page BOM hint;
    headers on a different page are not allowed to create cross-sheet BOM rows.
    OCR is merged into its own page, never into the text of another sheet.
    """
    ocr_by_page = ocr_by_page or {}
    scanned = set(scanned_indices)
    attempted = set(ocr_attempted) | set(ocr_by_page)
    evidence = []
    for index, raw in enumerate(page_texts):
        text_layer = bool((raw or "").strip())
        ocr_text = ocr_by_page.get(index, "")
        text = merge_ocr_texts(raw or "", ocr_text) if ocr_text else (raw or "")
        if not text.strip() and index not in scanned and index not in attempted:
            continue
        grade, reference, _, _ = _detect_titleblock_material(text)
        bom = _detect_erp_bom_items(text) if re.search(r"(?i)\b(?:MENGE|QTY|QUANTITY|ILO[SŚ][ĆC])\b", text) else []
        ids = _pdf_drawing_numbers(text)
        norms = find_norms(text)[:8] if text.strip() else []
        if not (grade or reference or bom or ids or norms or index in scanned or index in attempted):
            continue
        evidence.append({
            "sourceFile": source_file,
            "pageNumber": index + 1,
            "drawingNumbers": ids[:12],
            "materialHint": grade,
            "materialReference": reference,
            "bomPartNumbers": list(dict.fromkeys(str(row.get("partNumber", "")) for row in bom if row.get("partNumber")))[:20],
            "bomRowCount": len(bom),
            "norms": norms,
            "textLayerPresent": text_layer,
            "ocrApplied": index in attempted,
            "ocrTextPresent": bool(ocr_text.strip()),
            "suspectedRaster": index in scanned,
        })
    return evidence



def _pdf_exact_drawing_bom_links(page_evidence):
    """Non-authoritative exact cross-sheet links within ONE PDF only.

    Never strip punctuation or perform fuzzy matching: a near-match can
    incorrectly transfer a material or quantity to another manufactured part.
    Duplicate drawing IDs on different sheets or duplicate BOM occurrences
    are explicitly ambiguous and are *not* linked.
    """
    drawings = {}
    bom = {}
    for page in page_evidence:
        number = page.get("pageNumber")
        for identifier in set(str(x).strip().upper() for x in page.get("drawingNumbers", []) if str(x).strip()):
            drawings.setdefault(identifier, set()).add(number)
        for identifier in set(str(x).strip().upper() for x in page.get("bomPartNumbers", []) if str(x).strip()):
            bom.setdefault(identifier, set()).add(number)
    links, ambiguous = [], []
    for identifier in sorted(drawings.keys() & bom.keys()):
        drawing_pages = sorted(drawings[identifier])
        bom_pages = sorted(bom[identifier])
        if len(drawing_pages) != 1 or len(bom_pages) != 1:
            ambiguous.append(identifier)
            continue
        links.append({
            "sourceFile": page_evidence[0].get("sourceFile", "") if page_evidence else "",
            "drawingNumber": identifier,
            "drawingPageNumber": drawing_pages[0],
            "bomPartNumber": identifier,
            "bomPageNumber": bom_pages[0],
            "matchType": "exact-within-pdf",
        })
    return links[:100], ambiguous[:100]


def _merge_pdf_page_text_layers(pypdf_pages, mupdf_pages, layout_pages, titleblock_pages):
    """Combine extractor evidence by *page index*, never across page boundaries.

    Some CAD PDFs expose title-block text to pypdf but not to MuPDF (or vice
    versa). If the libraries disagree on page count, pypdf page positions are
    not trusted: retain MuPDF's page numbering rather than silently shifting
    a material or drawing number onto a different part.
    """
    if not mupdf_pages:
        return list(pypdf_pages)
    aligned_pypdf = pypdf_pages if len(pypdf_pages) == len(mupdf_pages) else []
    return [merge_ocr_texts(
        aligned_pypdf[index] if aligned_pypdf else "",
        mupdf_pages[index],
        layout_pages[index],
        titleblock_pages[index],
    ) for index in range(len(mupdf_pages))]


def analyze_pdf(path: Path):
    warnings = []
    texts = []
    page_count = 0
    ocr_languages_used = ""
    ocr_engine_path = ""
    ocr_mean_values = []
    ocr_critical_values = []
    ocr_low_tokens = []
    ocr_conflicts = []
    sparse_raster_indices = []
    page_texts = []
    pypdf_page_texts = []
    ocr_by_page = {}
    ocr_attempted = set()

    # Pass 1: pypdf text layer.
    try:
        from pypdf import PdfReader
        reader = PdfReader(str(path))
        page_count = len(reader.pages)
        pypdf_page_texts = [page.extract_text() or "" for page in reader.pages]
        page_texts = pypdf_page_texts
        pypdf_text = "\n".join(pypdf_page_texts)
        if pypdf_text.strip():
            texts.append(pypdf_text)
    except Exception as exc:
        warnings.append(f"pypdf: {type(exc).__name__}: {exc}")

    # Pass 2: MuPDF text extraction. It recovers text from many technical PDFs
    # where pypdf returns almost nothing because of font/encoding structure.
    fitz_doc = None
    try:
        import pymupdf as fitz  # PyMuPDF
        fitz_doc = fitz.open(str(path))
        page_count = max(page_count, fitz_doc.page_count)
        mupdf_page_texts = [page.get_text("text") or "" for page in fitz_doc]
        # Keep page boundaries while enriching the source text with CAD rows and
        # title-block cell associations. This is an audit layer only.
        # Extract each expensive word-coordinate representation only once;
        # reuse the same values for global parsing and page-level provenance.
        layout_pages = [_mupdf_layout_text(page) for page in fitz_doc]
        titleblock_pages = [_mupdf_titleblock_semantic_text(page) for page in fitz_doc]
        if pypdf_page_texts and len(pypdf_page_texts) != len(mupdf_page_texts):
            warnings.append(
                f"PDF_PAGE_COUNT_MISMATCH: pypdf={len(pypdf_page_texts)}, "
                f"MuPDF={len(mupdf_page_texts)}; nie połączono tekstu wg arkuszy "
                "z różnych ekstraktorów, aby uniknąć błędnego przypisania danych."
            )
        page_texts = _merge_pdf_page_text_layers(
            pypdf_page_texts, mupdf_page_texts, layout_pages, titleblock_pages
        )
        mupdf_text = "\n".join(mupdf_page_texts)
        # Page-level detection: an otherwise rich PDF may hide scanned sheets.
        sparse_raster_indices = find_sparse_raster_pdf_pages(mupdf_page_texts, fitz_doc)
        if mupdf_text.strip():
            texts.append(mupdf_text)
        layout_text = "\n".join(layout_pages)
        if layout_text.strip():
            texts.append(layout_text)
        titleblock_semantics = "\n".join(titleblock_pages)
        if titleblock_semantics.strip():
            texts.append(titleblock_semantics)
    except Exception as exc:
        warnings.append(f"PyMuPDF text: {type(exc).__name__}: {exc}")

    combined = merge_ocr_texts(*texts)

    # Pass 3: automatic OCR for scanned / outlined PDFs and mixed PDFs where the
    # title block is searchable text but critical manufacturing notes are rasterized.
    # Small technical drawings get OCR supplementation when the text layer contains
    # too few structured process signals; large manuals remain protected from costly OCR.
    probe = result_from_text(combined)
    probe_count = sum([
        bool(probe.get("materialHint")),
        bool(probe.get("weldProcessCode")),
        bool(probe.get("weldSizeMm")),
        bool(probe.get("paintColour")),
        bool(probe.get("totalDftMicron")),
        bool(probe.get("surfacePreparation")),
        bool(probe.get("corrosionClass")),
        bool(probe.get("holeRequirements")),
        bool(probe.get("dimensionalTolerances")),
        bool(probe.get("geometricTolerances")),
        bool(probe.get("documentMassKg")),
        len(probe.get("norms") or []) >= 1,
    ])
    text_len = len(combined.strip())
    # Rich vector PDFs should not be rasterized merely because they contain mostly
    # standards/general notes. OCR is expensive on A0/A1 drawings and adds little
    # when we already have hundreds of searchable characters.
    upper_combined = combined.upper()
    critical_cue_gap = (
        (bool(re.search(r"GEWICHT|WEIGHT|MASA|MASS|KG\b", upper_combined)) and not probe.get("documentMassKg")) or
        (bool(re.search(r"TOLER|ALLGEMEIN|POSITION|PARALLEL|PERPEND|FLATNESS|EBENHEIT|[Ø⌀Φ]", upper_combined)) and
         not probe.get("holeRequirements") and not probe.get("dimensionalTolerances") and not probe.get("geometricTolerances")) or
        (bool(re.search(r"WELD|SPAW|SCHWEI|SOUD|ISO\s*(?:5817|2553)", upper_combined)) and
         not probe.get("weldSizeMm") and not probe.get("weldProcessCode")) or
        (bool(re.search(r"PAINT|MALOW|LACKIER|BESCHICHT|RAL|ISO\s*12944", upper_combined)) and
         not probe.get("paintColour") and not probe.get("totalDftMicron") and not probe.get("surfacePreparation"))
    )
    # A one/two-page technical drawing with a modest text layer often has dimensions,
    # GD&T or title-block values converted to vector outlines.  OCR supplement is
    # worthwhile even when the general notes already provide hundreds of characters.
    sparse_critical_drawing = (
        0 < page_count <= 2 and text_len < 4000 and
        not probe.get("holeRequirements") and
        not probe.get("dimensionalTolerances") and
        not probe.get("geometricTolerances") and
        probe_count < 5
    )
    needs_ocr_supplement = (
        text_len < 100 or
        (0 < page_count <= 5 and text_len < 550 and probe_count < 2) or
        critical_cue_gap or
        sparse_critical_drawing or
        bool(sparse_raster_indices)
    )
    pair_fast_path = os.environ.get("DSE_SKIP_PDF_OCR", "").strip() == "1"
    if pair_fast_path:
        if sparse_raster_indices:
            warnings.append(
                "PDF_SCAN_PAGES_SKIPPED_FAST_PATH: pominięto OCR prawdopodobnych rysunków rastrowych "
                "na stronach " + ",".join(str(i + 1) for i in sparse_raster_indices[:30]) + "."
            )
        needs_ocr_supplement = False
    fast_history = os.environ.get("DSE_HISTORY_FAST_PDF", "").strip() == "1"
    if fast_history and needs_ocr_supplement:
        warnings.append("HISTORY_FAST_PDF: OCR pominięto w szybkim imporcie historii; wykorzystano warstwę tekstową PDF.")
        if sparse_raster_indices:
            warnings.append(
                "PDF_SCAN_PAGES_SKIPPED_HISTORY: pominięto OCR prawdopodobnych rysunków rastrowych "
                "na stronach " + ",".join(str(i + 1) for i in sparse_raster_indices[:30]) + "."
            )
        needs_ocr_supplement = False
    # OCR is deliberately capped to protect UI responsiveness on huge manuals.
    if needs_ocr_supplement:
        try:
            import pymupdf as fitz  # PyMuPDF
            from PIL import Image, ImageOps, ImageEnhance
            import pytesseract

            executable, config = configure_tesseract(pytesseract)
            if executable is not None:
                ocr_engine_path = str(executable)
            if executable is None:
                warnings.append(
                    "OCR_ENGINE_NOT_FOUND: PDF wymaga OCR/uzupełnienia OCR, ale nie znaleziono tesseract.exe."
                )
            else:
                if fitz_doc is None:
                    fitz_doc = fitz.open(str(path))
                page_count = max(page_count, fitz_doc.page_count)
                lang_string, selected = choose_ocr_languages(pytesseract, config)
                ocr_languages_used = "+".join(selected) if selected else "default"
                ocr_texts = []
                # FIX14: OCR is streamed one page at a time. The old implementation
                # rendered up to 20 A0/A1 pages into RGB buffers before Tesseract,
                # which could consume several GB of RAM and force Windows into swap.
                history_safe = os.environ.get("DSE_HISTORY_SAFE", "").strip() == "1"
                configured_pages = int(os.environ.get("DSE_OCR_MAX_PAGES", "0") or "0")
                default_page_cap = 4 if history_safe else 12
                ocr_page_indices = select_ocr_page_indices(
                    fitz_doc.page_count,
                    configured_pages if configured_pages > 0 else default_page_cap,
                    priority_indices=sparse_raster_indices,
                )
                max_megapixels = float(os.environ.get("DSE_OCR_MAX_MEGAPIXELS", "16") or "16")
                max_pixels = max(4_000_000, int(max_megapixels * 1_000_000))
                timeout_seconds = max(8, min(60, int(os.environ.get("DSE_TESSERACT_TIMEOUT_SECONDS", "28") or "28")))

                for page_index in ocr_page_indices:
                    ocr_attempted.add(page_index)
                    page = fitz_doc.load_page(page_index)
                    base_zoom = 2.55 if fitz_doc.page_count <= 2 else 2.05
                    # A0/A1 sheets can explode at fixed DPI. Estimate output pixels from
                    # the PDF point size and reduce zoom automatically to stay below cap.
                    zoom = bounded_pdf_ocr_zoom(
                        page.rect.width, page.rect.height, base_zoom, max_pixels
                    )
                    matrix = fitz.Matrix(zoom, zoom)
                    pix = page.get_pixmap(matrix=matrix, colorspace=fitz.csRGB, alpha=False)
                    image = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
                    # Release PyMuPDF sample storage before multi-pass preprocessing.
                    del pix
                    try:
                        text, _, mean_conf, critical_conf, low_tokens, page_conflicts = run_technical_ocr(
                            pytesseract, image, lang_string, config, ImageOps, ImageEnhance, timeout_seconds
                        )
                        if mean_conf is not None:
                            ocr_mean_values.append(mean_conf)
                        if critical_conf is not None:
                            ocr_critical_values.append(critical_conf)
                        ocr_low_tokens.extend(low_tokens)
                        ocr_conflicts.extend(page_conflicts)
                        # Track even empty OCR attempts so reports distinguish
                        # unprocessed sheets from attempted-but-unreadable scans.
                        ocr_by_page[page_index] = text
                        if text.strip():
                            ocr_texts.append(text)
                    except RuntimeError as exc:
                        warnings.append(f"OCR_TIMEOUT page {page_index + 1}: {exc}")
                    finally:
                        try:
                            image.close()
                        except Exception:
                            pass
                        del image

                if ocr_texts:
                    combined = merge_ocr_texts(combined, *ocr_texts)
                page_labels = ",".join(str(x + 1) for x in ocr_page_indices)
                warnings.append(
                    f"PDF OCR streaming: przeanalizowano {len(ocr_page_indices)}/{fitz_doc.page_count} stron "
                    f"(nr {page_labels}); "
                    f"limit {max_megapixels:g} MP/str., timeout {timeout_seconds}s/pass; języki: {'+'.join(selected) if selected else 'default'}."
                )
                unprocessed_scans = sorted(set(sparse_raster_indices) - set(ocr_page_indices))
                if unprocessed_scans:
                    warnings.append(
                        "PDF_SCAN_PAGES_NOT_OCR: nie przeanalizowano OCR stron rastrowych: " +
                        ",".join(str(i + 1) for i in unprocessed_scans[:30]) +
                        "; zwiększ DSE_OCR_MAX_PAGES, aby objąć więcej arkuszy."
                    )
                if fitz_doc.page_count > len(ocr_page_indices):
                    warnings.append(
                        f"PDF ma {fitz_doc.page_count} stron; OCR ograniczono do reprezentatywnych stron "
                        f"{page_labels}, aby chronić pamięć i czas analizy."
                    )
        except Exception as exc:
            warnings.append(f"PDF OCR: {type(exc).__name__}: {exc}")

    try:
        if fitz_doc is not None:
            fitz_doc.close()
    except Exception:
        pass

    result = result_from_text(combined)
    result["pdfPageCount"] = page_count
    result["pageEvidence"] = _pdf_page_evidence(
        page_texts, ocr_by_page, sparse_raster_indices, path.name, ocr_attempted
    )
    result["drawingBomLinks"], ambiguous_ids = _pdf_exact_drawing_bom_links(result["pageEvidence"])
    if ambiguous_ids:
        warnings.append(
            "PDF_DRAWING_BOM_AMBIGUOUS: powtarzające się identyfikatory rysunków/BOM "
            "na różnych arkuszach; nie utworzono powiązań dla: " +
            ", ".join(ambiguous_ids[:12]) + "."
        )
    sheet_materials = sorted({row["materialHint"] for row in result["pageEvidence"]
                              if row["materialHint"]})
    if len(sheet_materials) > 1:
        warnings.append(
            "PDF_MULTI_SHEET_MATERIALS: różne gatunki na arkuszach (" +
            ", ".join(sheet_materials[:8]) +
            "); materiał z całego PDF nie jest jednoznaczny dla pojedynczych pozycji BOM."
        )
    result["ocrLanguagesUsed"] = ocr_languages_used
    result["ocrEnginePath"] = ocr_engine_path
    result["ocrMeanConfidence"] = (sum(ocr_mean_values) / len(ocr_mean_values)) if ocr_mean_values else None
    result["ocrCriticalConfidence"] = (sum(ocr_critical_values) / len(ocr_critical_values)) if ocr_critical_values else None
    result["ocrLowConfidenceSignals"] = list(dict.fromkeys(ocr_low_tokens))[:20]
    result["ocrCriticalConflicts"] = list(dict.fromkeys(ocr_conflicts))[:12]
    if result["ocrCriticalConflicts"]:
        warnings.append(
            "OCR_CROSSCHECK_CONFLICT: przebiegi OCR zwróciły sprzeczne dane krytyczne bez większości: " + "; ".join(result["ocrCriticalConflicts"][:4])
        )
    if result["ocrCriticalConfidence"] is not None and result["ocrCriticalConfidence"] < 70:
        warnings.append(
            f"OCR_LOW_CONFIDENCE: krytyczne oznaczenia techniczne mają średnią pewność {result['ocrCriticalConfidence']:.0f}%. "
            "Średnice, tolerancje, RAL i DFT wymagają weryfikacji."
        )
    result["warnings"].extend(warnings)
    if pair_fast_path:
        result["findings"].append(
            "PDF_PAIR_FAST_PATH: OCR świadomie pominięto; sparowany DXF jest źródłem zastępczym, "
            "a warstwa tekstowa PDF została przeanalizowana."
        )
    if page_count:
        result["findings"].append(f"PDF strony: {page_count}")
    if len(combined.strip()) < 30 and not pair_fast_path:
        result["warnings"].append(
            "PDF: po ekstrakcji tekstu i OCR nadal odczytano bardzo mało treści."
        )
    return result


def _recover_ocr_hole_consensus(*texts):
    """Recover a diameter symbol only when two OCR passes support the same fit line.

    Technical drawings often turn `Ø50 H7` into `050 H7`, `850 H7` or
    `950 H7`.  A single corrupted token is too ambiguous to auto-correct.
    Two-pass OCR gives us a safer signal: if both lines are explicitly about a
    HOLE/BORE and their numeric tokens share the same suffix while only the
    first glyph differs, that first glyph is very likely the lost diameter
    symbol.  We synthesize an explicit Ø line for the normal parser and keep
    the raw OCR lines for diagnostics.
    """
    hole_word = r"(?:HOLE|BORE|OTW[ÓO]R|BOHRUNG|TROU)"
    pat = re.compile(
        rf"(?i)\b{hole_word}\b(?P<prefix>[^\n]{{0,24}}?)"
        r"(?P<num>\d{2,5})\s*(?P<fit>[A-Z]{1,2}\s*\d{1,2})(?![A-Za-z0-9])"
    )
    by_fit = {}
    for pass_index, text in enumerate(texts):
        for line in (text or "").splitlines():
            m = pat.search(line)
            if not m:
                continue
            fit = re.sub(r"\s+", "", m.group("fit").upper())
            gm = re.fullmatch(r"([A-Z]{1,2})(\d{1,2})", fit)
            if gm is None or not (3 <= int(gm.group(2)) <= 18):
                continue
            token = m.group("num")
            by_fit.setdefault(fit, []).append((pass_index, token, line.strip()))

    recovered = []
    confusion_prefixes = set("089")
    for fit, values in by_fit.items():
        # Compare observations from different OCR passes only.
        for i in range(len(values)):
            for j in range(i + 1, len(values)):
                p1, n1, line1 = values[i]
                p2, n2, line2 = values[j]
                if p1 == p2 or len(n1) != len(n2) or len(n1) < 2:
                    continue
                if n1[1:] != n2[1:] or n1[0] == n2[0]:
                    continue
                if n1[0] not in confusion_prefixes or n2[0] not in confusion_prefixes:
                    continue
                dia_token = n1[1:].lstrip("0") or "0"
                try:
                    dia = float(dia_token)
                except ValueError:
                    continue
                if not (0.5 <= dia <= 2000):
                    continue
                context = " REAMED" if re.search(r"REAM|ROZWI|AUFREIB|AL[ÉE]S", line1 + " " + line2, re.IGNORECASE) else ""
                recovered.append(f"HOLE Ø{dia:g} {fit}{context}")
                break
            else:
                continue
            break
    return list(dict.fromkeys(recovered))


def merge_ocr_texts(*texts):
    lines = []
    seen = set()

    # Majority-vote critical facts go first, so downstream parsers prefer consensus
    # over a single noisy OCR pass while raw text remains available for audit.
    for consensus in _ocr_consensus_lines(*texts):
        key = re.sub(r"\s+", " ", consensus).upper()
        if key not in seen:
            seen.add(key)
            lines.append(consensus)

    for text in texts:
        for line in (text or "").splitlines():
            cleaned = line.strip()
            if not cleaned:
                continue

            key = re.sub(r"\s+", " ", cleaned).upper()

            if key not in seen:
                seen.add(key)
                lines.append(cleaned)

    for recovered in _recover_ocr_hole_consensus(*texts):
        key = re.sub(r"\s+", " ", recovered).upper()
        if key not in seen:
            seen.add(key)
            lines.append(recovered)

    return "\n".join(lines)


def preprocess_for_technical_ocr(image, ImageOps, ImageEnhance):
    # Drugi przebieg jest ukierunkowany na drobne oznaczenia techniczne:
    # C4, H7, MT, Ra, a=6 itd.
    prepared = ImageOps.grayscale(image)
    prepared = ImageOps.autocontrast(prepared)

    # Nie powiększamy bez ograniczeń dużych skanów.
    max_dim = max(prepared.size)
    scale = 1.7 if max_dim < 3200 else max(1.0, 4800.0 / max_dim)

    if scale > 1.02:
        new_size = (
            max(1, int(prepared.width * scale)),
            max(1, int(prepared.height * scale)),
        )
        prepared = prepared.resize(new_size)

    prepared = ImageEnhance.Contrast(prepared).enhance(1.25)
    return prepared


def _ocr_critical_signal_map(text: str):
    signals = detect_structured_technical_signals(text or "")
    result = {}
    if signals.get("weldProcessCode"):
        result["weldProcess"] = signals["weldProcessCode"]
    if signals.get("weldSizeMm") is not None:
        result["weldSize"] = f"{signals.get('weldSizeKind','')}{signals['weldSizeMm']:g}"
    if signals.get("paintColour"):
        result["paintColour"] = signals["paintColour"]
    if signals.get("totalDftMicron") is not None:
        result["dft"] = f"{signals['totalDftMicron']:g}"
    holes = []
    for hole in signals.get("holeRequirements", []):
        holes.append((
            round(float(hole.get("nominalDiameterMm") or 0), 3),
            hole.get("fitCode") or "",
            hole.get("threadCode") or "",
            hole.get("operationHint") or "",
        ))
    if holes:
        result["holes"] = tuple(sorted(holes))
    return result


def _ocr_pass_conflicts(text_a: str, text_b: str):
    a = _ocr_critical_signal_map(text_a)
    b = _ocr_critical_signal_map(text_b)
    conflicts = []
    labels = {
        "weldProcess": "proces spawania",
        "weldSize": "wymiar spoiny",
        "paintColour": "RAL",
        "dft": "DFT",
        "holes": "otwory/tolerancje",
    }
    for key in sorted(set(a).intersection(b)):
        if a[key] != b[key]:
            conflicts.append(f"{labels.get(key,key)}: przebieg1={a[key]} vs przebieg2={b[key]}")
    return conflicts[:12]



def preprocess_binary_technical_ocr(image, ImageOps, ImageEnhance):
    """Third OCR view: high-contrast binary image for isolated callouts/tolerances."""
    prepared = preprocess_for_technical_ocr(image, ImageOps, ImageEnhance)
    # Adaptive-ish threshold based on histogram mean; keep it deterministic and dependency-free.
    hist = prepared.histogram()
    total = sum(hist) or 1
    mean = sum(i * n for i, n in enumerate(hist)) / total
    threshold = int(max(105, min(205, mean * 0.90)))
    return prepared.point(lambda px: 255 if px >= threshold else 0)


def _ocr_multi_pass_conflicts(*texts: str):
    """Report disagreement only when there is no 2-pass majority; keep 2/3 outliers diagnostic."""
    maps = [_ocr_critical_signal_map(t) for t in texts]
    labels = {
        "weldProcess": "proces spawania",
        "weldSize": "wymiar spoiny",
        "paintColour": "RAL",
        "dft": "DFT",
        "holes": "otwory/tolerancje",
    }
    conflicts = []
    for key in sorted(set().union(*(m.keys() for m in maps))):
        vals = [m[key] for m in maps if key in m]
        if len(vals) < 2:
            continue
        counts = {}
        for value in vals:
            counts[value] = counts.get(value, 0) + 1
        best = max(counts.values())
        if len(counts) > 1 and best < 2:
            conflicts.append(f"{labels.get(key,key)}: brak konsensusu OCR: {vals}")
    return conflicts[:12]


def _ocr_consensus_lines(*texts: str):
    """Synthesize critical signals only when at least two OCR passes agree exactly."""
    maps = [_ocr_critical_signal_map(t) for t in texts]
    lines = []
    scalar_formats = {
        "weldProcess": lambda v: f"WELD {v}",
        "weldSize": lambda v: f"WELD {v}",
        "paintColour": lambda v: str(v),
        "dft": lambda v: f"DFT {v} um",
    }
    for key, formatter in scalar_formats.items():
        vals = [m[key] for m in maps if key in m]
        if len(vals) < 2:
            continue
        counts = {}
        for value in vals:
            counts[value] = counts.get(value, 0) + 1
        value, count = max(counts.items(), key=lambda kv: kv[1])
        if count >= 2:
            lines.append(formatter(value))

    hole_vals = [m.get("holes") for m in maps if m.get("holes")]
    counts = {}
    for value in hole_vals:
        counts[value] = counts.get(value, 0) + 1
    if counts:
        value, count = max(counts.items(), key=lambda kv: kv[1])
        if count >= 2:
            for dia, fit, thread, operation in value:
                if thread:
                    lines.append(f"THREAD {thread}")
                elif dia > 0:
                    suffix = f" {fit}" if fit else ""
                    if operation and "REAM" in str(operation).upper():
                        suffix += " REAMED"
                    lines.append(f"HOLE Ø{dia:g}{suffix}")
    return list(dict.fromkeys(lines))

def _ocr_confidence_summary(pytesseract, image, kwargs):
    try:
        data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT, **kwargs)
        confidences = []
        critical = []
        critical_tokens = []
        for token, raw_conf in zip(data.get("text", []), data.get("conf", [])):
            token = (token or "").strip()
            if not token:
                continue
            try:
                conf = float(raw_conf)
            except Exception:
                continue
            if conf < 0:
                continue
            confidences.append(conf)
            normalized = token.upper().replace("Ø", "DIA")
            if (
                any(ch.isdigit() for ch in token)
                or re.fullmatch(r"[A-Z]{1,2}\d{1,2}", normalized)
                or normalized in {"RAL", "DFT", "H7", "H8", "MT", "UT", "PT", "RT"}
            ):
                critical.append(conf)
                if conf < 65:
                    critical_tokens.append(token[:40])
        mean = sum(confidences) / len(confidences) if confidences else None
        critical_mean = sum(critical) / len(critical) if critical else None
        return mean, critical_mean, critical_tokens[:20]
    except Exception:
        return None, None, []


def run_technical_ocr(pytesseract, image, lang_string, config, ImageOps, ImageEnhance, timeout_seconds=28):
    kwargs = {"config": config, "timeout": timeout_seconds}
    if lang_string:
        kwargs["lang"] = lang_string

    # Adaptive OCR R9.3.0. Two passes are the default. Sparse OCR is decided per
    # manufacturing category, so finding an easy RAL note cannot hide a missed H7,
    # weld or mass callout elsewhere on the page.
    text_primary = pytesseract.image_to_string(image, **kwargs)

    prepared = preprocess_for_technical_ocr(image, ImageOps, ImageEnhance)
    psm6_config = (config + " --psm 6").strip()
    kwargs_second = {"config": psm6_config, "timeout": timeout_seconds}
    if lang_string:
        kwargs_second["lang"] = lang_string
    text_secondary = pytesseract.image_to_string(prepared, **kwargs_second)

    two_pass_text = merge_ocr_texts(text_primary, text_secondary)
    probe = result_from_text(two_pass_text)
    resolved_categories = set()
    if probe.get("holeRequirements"):
        resolved_categories.add("holes")
    if probe.get("dimensionalTolerances") or probe.get("geometricTolerances"):
        resolved_categories.add("tolerances")
    if probe.get("weldSizeMm") or probe.get("weldProcessCode"):
        resolved_categories.add("weld")
    if probe.get("paintColour") or probe.get("totalDftMicron"):
        resolved_categories.add("paint")
    if probe.get("documentMassKg"):
        resolved_categories.add("mass")
    upper_probe = two_pass_text.upper()
    cue_categories = set()
    if re.search(r"[Ø⌀Φ]|\bH[3-9]\b|\bH1[01]\b|THREAD|GEWINDE|GWINT|OTW[ÓO]R|HOLE", upper_probe):
        cue_categories.add("holes")
    if re.search(r"TOLER|[±]|GD&T|GEOMETRIC", upper_probe):
        cue_categories.add("tolerances")
    if re.search(r"WELD|SCHWEI|SPAW|SOUD", upper_probe):
        cue_categories.add("weld")
    if re.search(r"RAL|DFT|PAINT|LACKIER|MALOW", upper_probe):
        cue_categories.add("paint")
    if re.search(r"WEIGHT|GEWICHT|MASA|MASS|\bKG\b", upper_probe):
        cue_categories.add("mass")
    unresolved_categories = cue_categories - resolved_categories
    sparse_page = len(two_pass_text.strip()) < 1800
    # A short page with only one recovered category still deserves the sparse pass:
    # isolated symbols often disappear while a large title-block note survives.
    need_sparse_pass = bool(unresolved_categories) or (sparse_page and len(resolved_categories) < 2)

    text_tertiary = ""
    binary = None
    kwargs_third = None
    pass_count = 2
    if need_sparse_pass:
        binary = preprocess_binary_technical_ocr(image, ImageOps, ImageEnhance)
        psm11_config = (config + " --psm 11").strip()
        kwargs_third = {"config": psm11_config, "timeout": timeout_seconds}
        if lang_string:
            kwargs_third["lang"] = lang_string
        text_tertiary = pytesseract.image_to_string(binary, **kwargs_third)
        pass_count = 3

    table_probe = (text_primary + "\n" + text_secondary + "\n" + text_tertiary).upper()
    table_text = ""
    if re.search(r"\b(?:MENGE|GEWICHT|QTY|QUANTITY|WEIGHT|MASA|MASS|MASSE|WERKSTOFF|MATERIAL|MATI[ÈE]RE)\b", table_probe):
        psm4_config = (config + " --psm 4").strip()
        kwargs_table = {"config": psm4_config, "timeout": timeout_seconds}
        if lang_string:
            kwargs_table["lang"] = lang_string
        table_text = pytesseract.image_to_string(prepared, **kwargs_table)
        pass_count += 1

    # One confidence pass is normally sufficient. Run sparse confidence only when
    # sparse OCR actually ran. This removes another hidden Tesseract invocation.
    conf2 = _ocr_confidence_summary(pytesseract, prepared, kwargs_second)
    conf3 = (None, None, [])
    if text_tertiary and binary is not None and kwargs_third is not None:
        conf3 = _ocr_confidence_summary(pytesseract, binary, kwargs_third)
    means = [x for x in (conf2[0], conf3[0]) if x is not None]
    criticals = [x for x in (conf2[1], conf3[1]) if x is not None]
    mean_conf = sum(means) / len(means) if means else None
    critical_conf = sum(criticals) / len(criticals) if criticals else None
    low_tokens = list(dict.fromkeys(conf2[2] + conf3[2]))[:20]
    conflicts = _ocr_multi_pass_conflicts(text_primary, text_secondary, text_tertiary, table_text)

    return merge_ocr_texts(text_primary, text_secondary, text_tertiary, table_text), pass_count, mean_conf, critical_conf, low_tokens, conflicts

def analyze_image(path: Path):
    result = result_from_text("")
    if os.environ.get("DSE_HISTORY_FAST_PDF", "").strip() == "1":
        result["warnings"].append("HISTORY_FAST_IMAGE: OCR obrazu pominięto w szybkim imporcie historii.")
        return result

    try:
        from PIL import Image, ImageOps, ImageEnhance
        import pytesseract
    except Exception as exc:
        result["warnings"].append(f"Brak Pillow/pytesseract: {exc}")
        return result

    try:
        executable, config = configure_tesseract(pytesseract)

        if executable is None:
            result["warnings"].append(
                "OCR_ENGINE_NOT_FOUND: nie znaleziono tesseract.exe. "
                "Uruchom ponownie setup_environment.ps1."
            )
            return result

        result["ocrEnginePath"] = str(executable)
        image = Image.open(path)
        max_megapixels = float(os.environ.get("DSE_OCR_MAX_MEGAPIXELS", "16") or "16")
        max_pixels = max(4_000_000, int(max_megapixels * 1_000_000))
        pixels = max(1, image.width * image.height)
        if pixels > max_pixels:
            scale = (max_pixels / pixels) ** 0.5
            resized = image.resize((max(1, int(image.width * scale)), max(1, int(image.height * scale))))
            image.close()
            image = resized
            result["warnings"].append(f"OCR_IMAGE_DOWNSCALE: obraz zmniejszono do {image.width}x{image.height}, limit {max_megapixels:g} MP.")

        lang_string, selected = choose_ocr_languages(pytesseract, config)

        if not selected:
            result["warnings"].append(
                "OCR_LANGUAGES_NOT_FOUND: Tesseract jest zainstalowany, "
                "ale nie znaleziono modeli językowych."
            )

        text, pass_count, mean_conf, critical_conf, low_tokens, ocr_conflicts = run_technical_ocr(
            pytesseract,
            image,
            lang_string,
            config,
            ImageOps,
            ImageEnhance,
            max(8, min(60, int(os.environ.get("DSE_TESSERACT_TIMEOUT_SECONDS", "28") or "28")))
        )

        result = result_from_text(text)
        result["ocrMeanConfidence"] = mean_conf
        result["ocrCriticalConfidence"] = critical_conf
        result["ocrLowConfidenceSignals"] = low_tokens
        result["ocrCriticalConflicts"] = ocr_conflicts
        if ocr_conflicts:
            result["warnings"].append(
                "OCR_CROSSCHECK_CONFLICT: przebiegi OCR zwróciły sprzeczne dane krytyczne bez większości: " + "; ".join(ocr_conflicts[:4])
            )
        if critical_conf is not None and critical_conf < 70:
            result["warnings"].append(
                f"OCR_LOW_CONFIDENCE: krytyczne oznaczenia techniczne mają średnią pewność {critical_conf:.0f}%. "
                "Średnice, tolerancje, RAL i DFT wymagają weryfikacji."
            )
        result["ocrEnginePath"] = str(executable)
        result["ocrLanguagesUsed"] = "+".join(selected) if selected else "default"

        if selected:
            result["findings"].append(
                "OCR: " + "+".join(selected)
            )

        result["findings"].append(
            f"OCR przebiegi: {pass_count}"
        )

        if os.environ.get("TESSDATA_PREFIX"):
            result["findings"].append(
                "TESSDATA_PREFIX: " + os.environ["TESSDATA_PREFIX"]
            )

        return result
    except Exception as exc:
        result["warnings"].append(
            f"OCR_RUNTIME_ERROR: {type(exc).__name__}: {exc}"
        )
        return result


def main():
    if len(sys.argv) != 2:
        print(json.dumps(result_from_text(""), ensure_ascii=True))
        return 0

    path = Path(sys.argv[1])
    ext = path.suffix.lower()

    if ext == ".pdf":
        result = analyze_pdf(path)
    elif ext in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}:
        result = analyze_image(path)
    else:
        result = result_from_text("")
        result["warnings"].append(
            f"Format dokumentu nieobsługiwany przez OCR: {ext}"
        )

    print(json.dumps(result, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
