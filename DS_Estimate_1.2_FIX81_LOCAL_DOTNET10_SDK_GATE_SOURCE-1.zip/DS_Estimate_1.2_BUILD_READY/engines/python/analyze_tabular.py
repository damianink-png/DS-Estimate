#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
import xml.etree.ElementTree as ET
import unicodedata
from pathlib import Path

from analyze_document import result_from_text, _looks_like_material_reference


MATERIAL_RE = re.compile(r"(?i)\b(?:S(?:235|275|355|420|460|500|550|620|690|700|890|960)[A-Z0-9+.-]*|1\.\d{4}|AISI\s*(?:304|316)|EN\s*AW[- ]?\d+|(?:ALUMIN(?:UM|IUM)\s+(?:ALLOY\s+)?)?(?:5052|5754|6060|6061|6082|7075)|ST52[- ]?3|A36|A572|A514|A516|ABS|PLA|PA6|PA12|POM|POLYCARBONATE)\b")
HEADER_WORDS = {
    "poz", "pos", "item", "position", "nr", "no", "part", "partnumber", "part number",
    "teil", "teilenr", "repere", "article", "qty", "quantity", "menge", "ilosc", "ilość",
    "description", "opis", "bezeichnung", "designation", "material", "materiał"
}


def _tokens_from_line(line: str):
    if " | " in line or line.startswith("|") or line.endswith("|"):
        # Preserve leading/trailing empty spreadsheet cells.  ``strip()`` on the
        # full line must not turn an empty first cell into a literal pipe token.
        parts = re.split(r"\s*\|\s*", line)
    elif "\t" in line:
        parts = line.split("\t")
    elif ";" in line:
        parts = line.split(";")
    else:
        # CSV fallback. Preserve empty cells: deleting an empty column shifts all
        # following semantic columns (e.g. Cut Length blank before Mass kg).
        try:
            parts = next(csv.reader([line]))
        except Exception:
            parts = [line]
    return [str(p).strip() if p is not None else "" for p in parts]


def _norm_header(value: str):
    value = (value or "").strip().lower().replace("ł", "l")
    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


PART_HEADERS = {
    "nr czesci", "numer czesci", "part number", "part no", "part nr", "partnumber", "part name",
    "drawing number", "drawing no", "dwg no", "dwg number", "detail number", "detail no",
    "file name", "filename", "cad file", "step file", "model file", "component file",
    "specification model", "specification", "model", "spec model",
    "teilenr", "teile nr", "teil nummer", "artikelnummer", "artikel nr",
    "doknr", "dok nr", "doknr index", "dok nr index", "dokument nr", "dokumentnummer", "zeichnungsnummer", "zeichnung nr",
    "komponente", "komponent", "komponente zeichnung", "komponente zeichnungsnummer", "component drawing",
    "reference", "ref", "repere", "article", "designation no",
    "component", "component id", "component no", "component number", "component name",
}
QTY_HEADERS = {
    "qty", "quantity", "ilosc", "szt", "sztuk", "menge", "anzahl", "quantite", "qte", "pcs", "pieces",
    "stuckzahl", "stuck zahl", "stueckzahl", "stueck zahl", "stuck", "stueck", "anz", "anzahl st",
    "quantity pcs", "quantity ea", "piece count", "part count", "liczba sztuk",
}
DESC_HEADERS = {
    "description", "opis", "nazwa", "name", "part description", "bezeichnung", "designation",
    "description article", "benennung", "kurztext", "text", "component description", "teilbezeichnung",
}
MAT_HEADERS = {
    "material", "material standard", "material grade", "materialgatunek", "material gatunek", "werkstoff", "matiere", "mat",
    "material specification", "material spec", "grade", "gatunek", "werkstoffbezeichnung",
}
POS_HEADERS = {
    "poz", "pos", "position", "item", "item no", "lp", "l p", "laufende nr", "positionsnr", "positionsnummer", "pos nr",
}
LEVEL_HEADERS = {
    "ebene", "level", "bom level", "structure level", "struktur ebene", "stufe", "hierarchy level", "poziom", "niveau",
}
UNIT_HEADERS = {"unit", "uom", "eh", "einheit", "jm", "jednostka", "unite"}
MASS_HEADERS = {
    "mass", "mass kg", "weight", "weight kg", "masa", "masa kg",
    "gewicht", "gewicht kg", "masse", "masse kg", "unit mass", "unit mass kg",
    "piece weight", "stuckgewicht", "stueckgewicht", "einzelgewicht", "net weight",
}
TOTAL_MASS_HEADERS = {
    "total mass", "total mass kg", "total weight", "total weight kg", "masa calkowita",
    "masa calkowita kg", "masa laczna", "masa laczna kg", "gesamtgewicht", "gesamtgewicht kg",
    "gesamtmasse", "gesamtmasse kg", "masse totale", "masse totale kg", "gross weight", "assembly weight",
}

_BOM_SUMMARY_MARKER_PHRASES = {
    "total", "grand total", "subtotal", "sub total", "total general", "total geral",
    "sum", "suma", "suma calkowita", "razem", "ogolem",
    "gesamt", "gesamtsumme", "gesamt summe", "summe", "zwischensumme",
    "totale", "totale generale", "sous total", "total general",
    "итого", "всего", "合计", "合計", "総計",
}
_BOM_SUMMARY_MARKER_WORDS = {
    "total", "grand", "subtotal", "sub", "general", "geral", "sum", "suma",
    "calkowita", "razem", "ogolem", "gesamt", "gesamtsumme", "summe",
    "zwischensumme", "totale", "generale", "sous", "итого", "всего", "合计",
    "合計", "総計",
}


def _is_bom_summary_row(tokens) -> bool:
    """Reject totals/subtotals before they can become manufactured BOM items.

    Some localized headers (notably French ``Repère``) are also valid part-number
    headers.  A row such as ``TOTAL / SUMA / GESAMT / TOTAL | ... | 45.13`` can
    therefore look like a part with an implied quantity of one unless it is
    recognized before the normal row parser runs.
    """
    first_text = next((str(token).strip() for token in tokens if str(token).strip()), "")
    if not first_text:
        return False
    unicode_normalized = re.sub(r"[\s/\\|;,:_\-]+", " ", first_text.casefold()).strip()
    if unicode_normalized in _BOM_SUMMARY_MARKER_PHRASES:
        return True
    normalized = _norm_header(first_text)
    if normalized in _BOM_SUMMARY_MARKER_PHRASES:
        return True
    words = normalized.split()
    return bool(words) and len(words) <= 8 and all(word in _BOM_SUMMARY_MARKER_WORDS for word in words)


def _header_role(token: str):
    """Return a semantic BOM column role for a supplier/CAD/ERP header.

    This intentionally uses both exact aliases and conservative keyword matching.
    The goal is to accept BOMs from different CAD/ERP systems without teaching the
    application one vendor-specific column layout at a time.
    """
    h = _norm_header(token)
    if not h:
        return None

    if h in TOTAL_MASS_HEADERS or any(x in h for x in ("total weight", "total mass", "gesamtgewicht", "gesamtmasse", "masse totale", "masa calkowita", "masa laczna")):
        return "total_mass"
    if h in LEVEL_HEADERS or h.startswith("ebene ") or h.endswith(" level"):
        return "level"
    if h in POS_HEADERS or h.startswith("pos ") or h.startswith("position "):
        return "position"
    if h in UNIT_HEADERS:
        return "unit"

    # Description must win over generic "component" matching when both words
    # appear in a localized descriptive header.
    if h in DESC_HEADERS or any(x in h for x in ("bezeichnung", "benennung", "description", "designation", "teilbezeichnung")):
        return "description"
    if h in MAT_HEADERS or any(x in h for x in ("werkstoff", "material grade", "material spec", "gatunek")):
        return "material"

    # "Nettomenge" in ERP exports is often an area/length material quantity, not
    # a piece count. Prefer a true Stückzahl/Qty column when present.
    if h in QTY_HEADERS or any(x in h for x in ("stuckzahl", "stueckzahl", "stuck zahl", "stueck zahl", "piece count", "part count")):
        return "qty"
    if (h == "menge" or h.startswith("menge ") or h in {"qty", "quantity", "anzahl", "ilosc", "liczba sztuk"}
            or h.startswith("qty ") or h.endswith(" qty") or h.startswith("quantity ") or h.endswith(" quantity")):
        return "qty"

    # Match whole technical words.  Substring matching turned ordinary product
    # descriptions such as "Lightweight aluminium component" into a Weight
    # header and later interpreted RS485/5000mAh digits as kilograms.
    if h in MASS_HEADERS or re.search(
        r"(?:^|\s)(?:gewicht|weight|masse|mass|masa|einzelgewicht|stuckgewicht|stueckgewicht)(?:\s|$)",
        h,
    ):
        return "mass"

    if h in PART_HEADERS:
        return "part"
    part_cues = (
        "part number", "part no", "drawing number", "drawing no", "zeichnungsnummer",
        "zeichnung nr", "artikelnummer", "artikel nr",
        "teilenr", "teil nummer", "dokumentnummer", "dok nr", "cad file", "step file", "model file",
    )
    if any(x in h for x in part_cues) and not any(x in h for x in ("description", "bezeichnung", "benennung")):
        return "part"
    return None


def _header_map(tokens):
    mapping = {}
    # Prefer the first strong column for each role. In odd exports duplicate
    # labels are common (e.g. two Weight columns); later duplicates must not move
    # all following rows onto a less useful column.
    for i, token in enumerate(tokens):
        normalized = _norm_header(token)
        role = _header_role(token)
        if role and role not in mapping:
            mapping[role] = i
        elif role == "qty" and "qty" in mapping:
            # Prefer an explicit total quantity over "qty per limb/side" in
            # installation schedules embedded below a purchasing BOM.
            current = _norm_header(tokens[mapping["qty"]])
            if normalized.startswith("total ") and not current.startswith("total "):
                mapping["qty"] = i

    recognized = len(mapping)
    identity = "part" in mapping or "description" in mapping
    quantitative = any(k in mapping for k in ("qty", "mass", "total_mass"))
    structural = any(k in mapping for k in ("position", "level"))

    # A real BOM header does not have to contain Qty. ERP structure lists often
    # imply quantity=1 for component rows and provide only Part/Description +
    # Weight + Position/Level. This still needs strong semantic evidence.
    if recognized >= 2 and identity and (quantitative or structural):
        return mapping
    return None


def _header_signal_count(tokens):
    return sum(1 for token in tokens if _header_role(token) is not None)


def _combine_header_rows(rows):
    width = max((len(r) for r in rows), default=0)
    combined = []
    for i in range(width):
        values = []
        for row in rows:
            if i < len(row):
                v = str(row[i] or "").strip()
                if v:
                    values.append(v)
        combined.append(" ".join(values))
    return combined


def _engineering_number(token, prefer_decimal_comma=False):
    raw = str(token or "").strip().replace("\u00a0", "").replace(" ", "")
    raw = raw.rstrip("+")
    if not raw:
        return None
    raw = re.sub(r"[^0-9+.,-]", "", raw)
    if not raw or raw in {"-", "+"}:
        return None

    if "," in raw and "." in raw:
        # The right-most punctuation is the decimal separator: 2.926,073 or 2,926.073.
        decimal = "," if raw.rfind(",") > raw.rfind(".") else "."
        thousands = "." if decimal == "," else ","
        raw = raw.replace(thousands, "").replace(decimal, ".")
    elif "," in raw:
        parts = raw.split(",")
        # German/Polish ERP exports commonly write quantity 1,000 = 1.000 and
        # weight 236,974 = 236.974. Treat one comma as decimal by default.
        raw = "".join(parts[:-1]) + "." + parts[-1] if len(parts) > 1 else raw
    elif raw.count(".") > 1:
        parts = raw.split(".")
        raw = "".join(parts[:-1]) + "." + parts[-1]

    try:
        return float(raw)
    except ValueError:
        return None


def _parse_qty(token):
    raw = str(token or "").strip().lower().replace("\u00a0", " ")
    raw = re.sub(r"\s*(?:pcs?|pieces?|ea|szt(?:uk)?|stk|st)\s*$", "", raw)
    raw = raw.replace(" ", "").replace("'", "").replace("’", "")
    raw = raw.rstrip("+")
    if re.search(r"[a-z]", raw) or "://" in raw:
        return None
    if not re.fullmatch(r"[+\-]?[0-9][0-9.,]*", raw):
        return None
    value = _engineering_number(raw, prefer_decimal_comma=True)
    if value is None or not (0 < value <= 100000):
        return None
    return value


def _parse_mass_kg(token):
    raw = str(token or "").strip().lower().replace("\u00a0", "").replace(" ", "")
    if not raw or raw in {"-", "—", "n/a", "na"}:
        return None
    factor = 1.0
    if raw.endswith("kg"):
        raw = raw[:-2]
    elif raw.endswith("tonnes"):
        raw = raw[:-6]; factor = 1000.0
    elif raw.endswith("tonne"):
        raw = raw[:-5]; factor = 1000.0
    elif raw.endswith("tons"):
        raw = raw[:-4]; factor = 1000.0
    elif raw.endswith("ton"):
        raw = raw[:-3]; factor = 1000.0
    elif raw.endswith("lbs"):
        raw = raw[:-3]; factor = 0.45359237
    elif raw.endswith("lb"):
        raw = raw[:-2]; factor = 0.45359237
    elif raw.endswith("mg"):
        raw = raw[:-2]; factor = 0.000001
    elif raw.endswith("g"):
        raw = raw[:-1]; factor = 0.001
    elif raw.endswith("t"):
        raw = raw[:-1]; factor = 1000.0
    # A mass cell must be numeric after removing a known unit.  Do not harvest
    # arbitrary digits from URLs, prices or specifications (RS485, 5000mAh,
    # M12x30), even if a malformed table happened to select that column.
    if re.search(r"[a-z]", raw) or "://" in raw:
        return None
    raw = raw.replace("'", "").replace("’", "")
    if not re.fullmatch(r"[~≈<>+\-]?[0-9][0-9.,]*", raw):
        return None
    value = _engineering_number(raw, prefer_decimal_comma=True)
    if value is None:
        return None
    result = value * factor
    if not (0 <= result <= 1e9):
        return None
    return result


def _clean_material_token(token: str):
    raw = str(token or "").strip()
    if not raw or _norm_header(raw) in {"-", "n a", "none", "brak"}:
        return ""
    m = MATERIAL_RE.search(raw)
    if m:
        return m.group(0).upper()
    # A Material/Werkstoff column may actually contain a customer material
    # specification or internal CAD code (e.g. LH350CAT2-LH11657002). Such a
    # reference must not become the physical steel grade used for density/cost.
    if _looks_like_material_reference(raw):
        return ""
    # Preserve genuinely unknown material names for BOM rows; only obviously
    # reference-like identifiers are filtered out.
    return raw[:120]


def _parse_level(token):
    raw = str(token or "").strip()
    if not raw:
        return None
    m = re.search(r"(?<!\d)(\d{1,3})(?!\d)", raw)
    if not m:
        return None
    value = int(m.group(1))
    return value if 0 <= value <= 99 else None


def _explicit_total_mass_from_preamble(text: str):
    """Find an assembly/workbook total weight in the metadata above a BOM table.

    CAD/ERP exports frequently print ``Gewicht 1871,000`` or ``Total weight`` in
    a title block before the actual rows. That value is more authoritative than
    summing a hierarchical BOM, where parent and child weights would double count.
    """
    candidates = []
    rows_seen_in_sheet = 0
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.upper().startswith("SHEET:"):
            rows_seen_in_sheet = 0
            continue
        rows_seen_in_sheet += 1
        if rows_seen_in_sheet > 60:
            continue
        # First try a raw-line title-block pattern. This catches merged-cell ERP
        # exports where tokenisation does not keep the label and value in adjacent
        # cells, e.g. "Gewicht .... 1.871,000".
        raw_total = re.search(
            r"(?i)(?:gesamtgewicht|gesamtmasse|total\s+(?:weight|mass)|assembly\s+weight|masa\s+(?:calkowita|laczna)|gewicht)"
            r"[^0-9]{0,80}([0-9][0-9 .,'’]*[0-9]|[0-9]+(?:[.,][0-9]+)?)",
            line)
        if raw_total:
            raw_value = _parse_mass_kg(raw_total.group(1).replace("'", "").replace("’", ""))
            if raw_value is not None and raw_value > 0:
                label = _norm_header(raw_total.group(0).split(raw_total.group(1))[0])
                explicit_rank = 2 if any(x in label for x in ("gesamtgewicht", "gesamtmasse", "total weight", "total mass", "assembly weight", "masa calkowita", "masa laczna")) else 1
                candidates.append((explicit_rank, rows_seen_in_sheet, raw_value))

        tokens = _tokens_from_line(line)
        # Once a clear BOM header starts, remaining Gewichte are row values.
        if _header_map(tokens) is not None:
            rows_seen_in_sheet = 9999
            continue
        norms = [_norm_header(x) for x in tokens]
        for i, h in enumerate(norms):
            explicit = (
                h in TOTAL_MASS_HEADERS
                or any(x in h for x in ("gesamtgewicht", "gesamtmasse", "total weight", "total mass", "assembly weight", "masa calkowita", "masa laczna"))
            )
            generic_title_weight = h in {"gewicht", "weight", "mass", "masse", "masa"}
            if not (explicit or generic_title_weight):
                continue
            # Search the next few cells because title blocks often leave one or
            # two empty columns between label and value.
            for value_token in tokens[i + 1:i + 5]:
                value = _parse_mass_kg(value_token)
                if value is not None and value > 0:
                    candidates.append((2 if explicit else 1, rows_seen_in_sheet, value))
                    break
    if not candidates:
        return None
    candidates.sort(key=lambda x: (-x[0], x[1], -x[2]))
    return candidates[0][2]


def extract_bom_items(text: str, source_file: str):
    """Extract a BOM from heterogeneous CAD/ERP tables.

    The parser is schema-adaptive: headers can be localized, multi-line or
    spread across up to three rows. It deliberately prefers semantic evidence
    over a filename so an arbitrary customer export can still be recognized.
    """
    items = []
    fallback_items = []
    seen = set()
    fallback_seen = set()
    active_header = None
    semantic_header_seen = False
    header_buffer = []
    source_norm = _norm_header(Path(source_file).stem)
    bom_name_hint = Path(source_file).suffix.lower() == ".bom" or any(h in source_norm for h in (
        "bom", "sbom", "bill of materials", "parts list", "part list", "partslist",
        "lista materialowa", "lista czesci", "stukliste", "stuckliste", "stueckliste",
        "strukturstuckliste", "strukturstueckliste", "nomenclature", "piece list", "teileliste",
        "material list", "materialliste", "parts catalogue", "parts catalog"
    ))

    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.upper().startswith("SHEET:"):
            active_header = None
            header_buffer = []
            continue
        tokens = _tokens_from_line(line)
        if len(tokens) < 2:
            continue

        detected_header = _header_map(tokens)
        if detected_header is None and active_header is None:
            # Multi-row ERP/CAD header: combine the current row with one/two
            # preceding likely-header rows by column. This covers exports where
            # "Komponente / Zeichnung" or "Stück / zahl" is split vertically.
            possible_rows = header_buffer[-2:] + [tokens]
            for count in (2, 3):
                if len(possible_rows) < count:
                    continue
                rows = possible_rows[-count:]
                if sum(_header_signal_count(r) for r in rows) < 2:
                    continue
                combined = _combine_header_rows(rows)
                candidate = _header_map(combined)
                if candidate is not None:
                    detected_header = candidate
                    break

        if detected_header is not None:
            active_header = detected_header
            semantic_header_seen = True
            header_buffer = []
            continue

        if active_header is None:
            # Keep only a tiny rolling window; data rows without header cues are
            # not useful for multi-row header construction.
            if _header_signal_count(tokens) > 0 or len(header_buffer) < 2:
                header_buffer.append(tokens)
                header_buffer = header_buffer[-2:]
        else:
            if _is_bom_summary_row(tokens):
                continue
            max_idx = max(active_header.values()) if active_header else -1
            if len(tokens) > max_idx:
                qty_token = tokens[active_header["qty"]] if "qty" in active_header else ""
                mass_token = tokens[active_header["mass"]] if "mass" in active_header else ""
                if active_header.get("qty") == active_header.get("mass") and "qty" in active_header and "mass" in active_header:
                    pieces = [x.strip() for x in re.split(r"(?:[\r\n]+|\s*⏎\s*)", qty_token) if x.strip()]
                    qty_token = pieces[0] if pieces else qty_token
                    mass_token = pieces[-1] if len(pieces) >= 2 else mass_token

                part = tokens[active_header["part"]].strip() if "part" in active_header else ""
                description = tokens[active_header["description"]].strip() if "description" in active_header else ""
                material_token = tokens[active_header["material"]].strip() if "material" in active_header else ""
                material = _clean_material_token(material_token)
                mass_each = _parse_mass_kg(mass_token) if "mass" in active_header else None
                total_mass = _parse_mass_kg(tokens[active_header["total_mass"]]) if "total_mass" in active_header else None
                level = _parse_level(tokens[active_header["level"]]) if "level" in active_header else None
                position = tokens[active_header["position"]].strip() if "position" in active_header else ""

                qty = _parse_qty(qty_token) if "qty" in active_header else None
                # Structural CAD/ERP BOMs often leave Stückzahl blank when one
                # component is implied by a position/level row. Do not discard it.
                if qty is None and (part or description) and (
                    mass_each is not None or total_mass is not None or position or level is not None
                ):
                    qty = 1.0

                if not part and description:
                    part = description
                    description = ""

                if qty is not None and mass_each is None and total_mass is not None and qty > 0:
                    mass_each = total_mass / qty
                if qty is not None and total_mass is None and mass_each is not None:
                    total_mass = mass_each * qty

                if part and qty is not None:
                    if not material:
                        for token in tokens:
                            m = MATERIAL_RE.search(token)
                            if m:
                                material = m.group(0).upper()
                                break
                    # Position/level is part of identity in hierarchical BOMs;
                    # otherwise identical codes in different branches disappear.
                    key = (
                        part.upper(), round(qty, 3), description.upper(), material.upper(),
                        position.upper(), level if level is not None else -1,
                    )
                    if key not in seen:
                        seen.add(key)
                        item = {
                            "partNumber": part,
                            "description": description,
                            "quantity": qty,
                            "material": material,
                            "sourceFile": source_file,
                        }
                        if position:
                            item["position"] = position
                        if level is not None:
                            item["level"] = level
                        if mass_each is not None:
                            item["massKgEach"] = mass_each
                        if total_mass is not None:
                            item["totalMassKg"] = total_mass
                        items.append(item)
                        if len(items) >= 5000:
                            break
                    continue

        # Headerless/irregular fallback: preserve the conservative heuristic.
        if _is_bom_summary_row(tokens):
            continue
        lowered = {_norm_header(t) for t in tokens}
        if len(lowered & {_norm_header(x) for x in HEADER_WORDS}) >= 2:
            continue

        qty_idx = None
        qty = None
        for i, token in enumerate(tokens[1:], start=1):
            value = _parse_qty(token)
            if value is not None:
                qty_idx = i
                qty = value
                break
        if qty_idx is None:
            continue

        candidates = [t for i, t in enumerate(tokens) if i != qty_idx]
        if not candidates:
            continue

        part = ""
        part_candidate_index = None
        for ci, candidate in enumerate(candidates):
            value = candidate.strip()
            if len(value) < 2:
                continue
            if re.fullmatch(r"[0-9.,]+", value):
                if not (bom_name_hint and re.fullmatch(r"[0-9]{3,20}", value)):
                    continue
            if _norm_header(value) in {_norm_header(x) for x in HEADER_WORDS}:
                continue
            part = value
            part_candidate_index = ci
            break
        if not part:
            continue

        material = ""
        for token in tokens:
            m = MATERIAL_RE.search(token)
            if m:
                material = m.group(0).upper()
                break

        desc_parts = []
        for ci, token in enumerate(candidates):
            if ci == part_candidate_index:
                continue
            if re.fullmatch(r"[0-9.,]+", token.strip()):
                continue
            if material and material.lower() in token.lower():
                continue
            desc_parts.append(token)
        description = " ".join(desc_parts).strip()

        part_clean = part.strip()
        qty_value = qty or 1
        code_like = (
            len(part_clean) <= 64
            and "\\" not in part_clean and "/" not in part_clean
            and not part_clean.startswith("=")
            and any(ch.isdigit() for ch in part_clean)
            and (bom_name_hint or len(part_clean.split()) <= 4)
        )
        integer_qty = abs(qty_value - round(qty_value)) <= 1e-9
        compact_row = len(tokens) <= 16
        if not code_like or not compact_row or (not bom_name_hint and not integer_qty):
            continue

        key = (part_clean.upper(), round(qty_value, 3), description.upper(), material.upper())
        if key in fallback_seen:
            continue
        fallback_seen.add(key)
        fallback_items.append({
            "partNumber": part_clean,
            "description": description,
            "quantity": qty_value,
            "material": material,
            "sourceFile": source_file,
        })
        if len(fallback_items) >= 5000:
            break

    if semantic_header_seen:
        return items[:5000]
    if bom_name_hint:
        return fallback_items[:5000]
    return []


def _text_without_bom_data_rows(text: str):
    """Remove recognized BOM data rows before drawing-note semantics are parsed."""
    output = []
    active_header = None
    header_buffer = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            output.append(raw)
            continue
        if line.upper().startswith("SHEET:"):
            active_header = None
            header_buffer = []
            output.append(raw)
            continue
        tokens = _tokens_from_line(line)
        detected = _header_map(tokens) if len(tokens) >= 2 else None
        if detected is None and active_header is None and len(tokens) >= 2:
            possible = header_buffer[-2:] + [tokens]
            for count in (2, 3):
                if len(possible) < count:
                    continue
                rows = possible[-count:]
                if sum(_header_signal_count(r) for r in rows) < 2:
                    continue
                detected = _header_map(_combine_header_rows(rows))
                if detected is not None:
                    break
        if detected is not None:
            active_header = detected
            header_buffer = []
            continue
        if active_header is None:
            if len(tokens) >= 2 and (_header_signal_count(tokens) > 0 or len(header_buffer) < 2):
                header_buffer.append(tokens)
                header_buffer = header_buffer[-2:]
            output.append(raw)
            continue

        if _is_bom_summary_row(tokens):
            continue

        max_idx = max(active_header.values()) if active_header else -1
        if len(tokens) > max_idx:
            part = tokens[active_header["part"]].strip() if "part" in active_header else ""
            desc = tokens[active_header["description"]].strip() if "description" in active_header else ""
            qty = _parse_qty(tokens[active_header["qty"]]) if "qty" in active_header else None
            has_structural_data = (
                ("mass" in active_header and _parse_mass_kg(tokens[active_header["mass"]]) is not None)
                or ("total_mass" in active_header and _parse_mass_kg(tokens[active_header["total_mass"]]) is not None)
                or ("position" in active_header and bool(tokens[active_header["position"]].strip()))
                or ("level" in active_header and _parse_level(tokens[active_header["level"]]) is not None)
            )
            if qty is None and (part or desc) and has_structural_data:
                qty = 1.0
            if qty is not None and (part or desc):
                continue
        output.append(raw)
    return "\n".join(output)


# High-confidence technical-note cues used when a spreadsheet/table could not be
# recognized as a BOM. Bare M3/M4/M6 or random numbers are deliberately absent:
# those are common part names / fasteners and must not become machining holes.
_TABULAR_TECH_CUE_RE = re.compile(
    r"(?ix)(?:"
    r"\b(?:WELD|WELDING|SPAW|SCHWEISS|SOUD|PAINT|PAINTING|MALOW|LACKIER|PEINT|"
    r"REAM|REAMED|ROZWIERC|GEWINDE|TAPPED|THREAD|GWINT|TARAUD|"
    r"HOLE|BORE|OTW[ÓO]R|BOHRUNG|TROU|"
    r"SHOT\s*BLAST|ŚRUT|SRUT|SANDBLAST|RAL|NDT|UT|MT|PT|RT)\b"
    r"|\bISO\s*5817\b|\bISO\s*8501(?:-1)?\b|\bISO\s*12944\b"
    r"|(?:[Ø⌀]\s*\d+(?:[.,]\d+)?\s*(?:H[3-9]|H1[0-1]|JS\d+))"
    r"|(?:\bRA\s*\d+(?:[.,]\d+)?)"
    r")"
)


def _technical_notes_from_unrecognized_table(text: str) -> str:
    """Keep only explicit manufacturing notes from an unrecognized table.

    Feeding every spreadsheet cell to the drawing-note parser caused electronic
    BOMs and part descriptions (M3/M4/M6 etc.) to create false hole requirements.
    A table that is not recognized as a BOM is therefore treated as data first;
    only cells/rows carrying an explicit manufacturing cue reach the semantics
    engine.
    """
    notes = []
    seen = set()
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.upper().startswith("SHEET:"):
            continue
        tokens = _tokens_from_line(line)
        candidates = tokens if len(tokens) >= 2 else [line]
        for token in candidates:
            value = str(token or "").strip()
            if len(value) < 3 or not _TABULAR_TECH_CUE_RE.search(value):
                continue
            key = value.upper()
            if key in seen:
                continue
            seen.add(key)
            notes.append(value)
            if len(notes) >= 250:
                return "\n".join(notes)
    return "\n".join(notes)


def decode_bytes(data: bytes) -> str:
    for enc in ("utf-8-sig", "utf-8", "cp1250", "cp1252", "latin1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            pass
    return data.decode("latin1", errors="replace")


def read_plain(path: Path):
    text = decode_bytes(path.read_bytes())
    rows = [line for line in text.splitlines() if line.strip()]
    return text, {"sheetCount": 0, "rowCount": len(rows), "sourceType": path.suffix.lower().lstrip(".")}


def read_csv_file(path: Path):
    raw = decode_bytes(path.read_bytes())
    # Keep all textual content; parser does not depend on delimiter correctness.
    rows = [r for r in raw.splitlines() if r.strip()]
    return raw, {"sheetCount": 1, "rowCount": len(rows), "sourceType": "csv"}


def _xlsx_col_index(ref: str):
    letters = re.match(r"[A-Za-z]+", str(ref or ""))
    if not letters:
        return 0
    value = 0
    for ch in letters.group(0).upper():
        value = value * 26 + (ord(ch) - 64)
    return max(0, value - 1)


def read_xlsx_ooxml_fallback(path: Path):
    """Read OOXML directly when a vendor XLSX trips openpyxl.

    CAD/ERP generators occasionally emit workbooks with unusual styles, links or
    metadata. The sheet XML itself is usually valid, so a standard-library reader
    is a valuable second engine and also consumes cached formula values (<v>).
    """
    ns_main = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    ns_rel = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    pkg_rel = "{http://schemas.openxmlformats.org/package/2006/relationships}"
    lines = []
    row_count = 0
    with zipfile.ZipFile(path, "r") as z:
        names = set(z.namelist())
        shared = []
        if "xl/sharedStrings.xml" in names:
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.findall(ns_main + "si"):
                shared.append("".join((t.text or "") for t in si.iter(ns_main + "t")))

        wb_root = ET.fromstring(z.read("xl/workbook.xml"))
        rel_root = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        rels = {r.attrib.get("Id", ""): r.attrib.get("Target", "") for r in rel_root.findall(pkg_rel + "Relationship")}
        sheets = []
        sheets_node = wb_root.find(ns_main + "sheets")
        if sheets_node is not None:
            for sheet in sheets_node.findall(ns_main + "sheet"):
                title = sheet.attrib.get("name", "Sheet")
                rid = sheet.attrib.get(ns_rel + "id", "")
                target = rels.get(rid, "")
                if target.startswith("/"):
                    target = target.lstrip("/")
                elif target and not target.startswith("xl/"):
                    target = "xl/" + target.lstrip("./")
                if target in names:
                    sheets.append((title, target))

        for title, target in sheets:
            lines.append(f"SHEET: {title}")
            root = ET.fromstring(z.read(target))
            sheet_data = root.find(ns_main + "sheetData")
            if sheet_data is None:
                continue
            for row in sheet_data.findall(ns_main + "row"):
                cells = {}
                max_col = -1
                for c in row.findall(ns_main + "c"):
                    idx = _xlsx_col_index(c.attrib.get("r", ""))
                    max_col = max(max_col, idx)
                    kind = c.attrib.get("t", "")
                    value = ""
                    if kind == "inlineStr":
                        value = "".join((t.text or "") for t in c.iter(ns_main + "t"))
                    else:
                        v = c.find(ns_main + "v")
                        raw = "" if v is None or v.text is None else v.text
                        if kind == "s" and raw:
                            try:
                                value = shared[int(raw)]
                            except Exception:
                                value = raw
                        else:
                            value = raw
                    cells[idx] = re.sub(r"[\r\n]+", " ⏎ ", str(value)).strip()
                if max_col < 0:
                    continue
                vals = [cells.get(i, "") for i in range(max_col + 1)]
                while vals and not vals[-1]:
                    vals.pop()
                if any(vals):
                    row_count += 1
                    lines.append(" | ".join(vals))
    return "\n".join(lines), {
        "sheetCount": len(sheets), "rowCount": row_count,
        "sourceType": path.suffix.lower().lstrip(".") + "-ooxml-recovery",
    }


def read_xlsx(path: Path):
    import openpyxl
    formula_wb = value_wb = None
    try:
        # Two synchronized views solve a frequent vendor-export problem: one view
        # tells us which cells are formulas, the other returns Excel's last cached
        # result. We never feed raw formulas into manufacturing-note semantics.
        formula_wb = openpyxl.load_workbook(
            path, read_only=True, data_only=False, keep_links=False
        )
        value_wb = openpyxl.load_workbook(
            path, read_only=True, data_only=True, keep_links=False
        )
        lines = []
        row_count = 0
        sheet_count = len(formula_wb.worksheets)
        value_by_title = {ws.title: ws for ws in value_wb.worksheets}

        for ws in formula_wb.worksheets:
            lines.append(f"SHEET: {ws.title}")
            value_ws = value_by_title.get(ws.title)
            formula_rows = ws.iter_rows()
            value_rows = value_ws.iter_rows() if value_ws is not None else iter(())
            for frow in formula_rows:
                try:
                    vrow = next(value_rows)
                except StopIteration:
                    vrow = ()
                vals = []
                for i, cell in enumerate(frow):
                    cached = vrow[i].value if i < len(vrow) else None
                    if getattr(cell, "data_type", "") == "f":
                        v = cached
                    else:
                        v = cell.value
                    if v is None:
                        vals.append("")
                    else:
                        vals.append(re.sub(r"[\r\n]+", " ⏎ ", str(v)).strip())
                while vals and not vals[-1]:
                    vals.pop()
                if any(vals):
                    row_count += 1
                    lines.append(" | ".join(vals))
        return "\n".join(lines), {
            "sheetCount": sheet_count, "rowCount": row_count,
            "sourceType": path.suffix.lower().lstrip("."),
        }
    except Exception as primary_exc:
        try:
            text, meta = read_xlsx_ooxml_fallback(path)
            meta["readerWarning"] = f"openpyxl fallback: {type(primary_exc).__name__}: {primary_exc}"
            return text, meta
        except Exception:
            raise primary_exc
    finally:
        for wb in (formula_wb, value_wb):
            if wb is not None:
                try:
                    wb.close()
                except Exception:
                    pass


def read_spreadsheetml_or_html(path: Path, data: bytes):
    text = decode_bytes(data)
    # Old ERP exports with .xls are often SpreadsheetML or HTML, not BIFF.
    if not (text.lstrip().startswith("<?xml") or "<Workbook" in text or "<table" in text.lower()):
        return None
    # Preserve table-cell and row boundaries so BOM extraction still works.
    prepared = re.sub(r"(?i)</(?:td|th)>", " | ", text)
    prepared = re.sub(r"(?i)</tr>", "\n", prepared)
    stripped = re.sub(r"<[^>]+>", " ", prepared)
    stripped = re.sub(r"[ \t]+", " ", stripped)
    stripped = re.sub(r" *\| *", " | ", stripped)
    stripped = re.sub(r"\n\s*\n+", "\n", stripped)
    rows = [line for line in stripped.splitlines() if line.strip()]
    return stripped, {"sheetCount": 1, "rowCount": len(rows), "sourceType": "xls-xml/html"}


def read_xls(path: Path):
    data = path.read_bytes()
    fallback = read_spreadsheetml_or_html(path, data)
    if fallback is not None:
        return fallback

    try:
        import xlrd
    except Exception as exc:
        raise RuntimeError(
            "Stary binarny XLS wymaga pakietu xlrd. Uruchom ponownie setup_environment.ps1."
        ) from exc

    wb = xlrd.open_workbook(file_contents=data, on_demand=True)
    lines = []
    row_count = 0
    for sheet in wb.sheets():
        lines.append(f"SHEET: {sheet.name}")
        for r in range(sheet.nrows):
            vals = []
            for c in range(sheet.ncols):
                value = sheet.cell_value(r, c)
                vals.append(re.sub(r"[\r\n]+", " ⏎ ", str(value)).strip() if value not in (None, "") else "")
            while vals and not vals[-1]:
                vals.pop()
            if any(vals):
                row_count += 1
                lines.append(" | ".join(vals))
    return "\n".join(lines), {"sheetCount": wb.nsheets, "rowCount": row_count, "sourceType": "xls-biff"}


def read_docx(path: Path):
    # DOCX is a ZIP of WordprocessingML. Use the standard library so this works
    # even before optional python-docx is installed.
    with zipfile.ZipFile(path, "r") as z:
        if "word/document.xml" not in z.namelist():
            raise RuntimeError("DOCX nie zawiera word/document.xml")
        root = ET.fromstring(z.read("word/document.xml"))

    ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    lines = []
    row_count = 0

    # Preserve table rows because BOMs are commonly delivered as Word tables.
    for tr in root.iter(ns + "tr"):
        cells = []
        for tc in tr.findall(".//" + ns + "tc"):
            text = " ".join(
                (node.text or "").strip()
                for node in tc.iter(ns + "t")
                if (node.text or "").strip()
            ).strip()
            cells.append(text)
        while cells and not cells[-1]:
            cells.pop()
        if any(cells):
            row_count += 1
            lines.append(" | ".join(cells))

    # Also keep normal paragraphs that are not necessarily part of a BOM table.
    for para in root.iter(ns + "p"):
        text = " ".join(
            (node.text or "").strip()
            for node in para.iter(ns + "t")
            if (node.text or "").strip()
        ).strip()
        if text and text not in lines:
            lines.append(text)

    text = "\n".join(lines)
    return text, {
        "sheetCount": 0,
        "rowCount": row_count or len(lines),
        "sourceType": "docx",
    }


def _strip_rtf(text: str):
    # Best-effort RTF reader for .doc files that are actually RTF exports.
    text = re.sub(r"\\par[d]?\b", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"\\'[0-9a-fA-F]{2}", " ", text)
    text = re.sub(r"\\[a-zA-Z]+-?\d* ?", " ", text)
    text = text.replace("{", " ").replace("}", " ")
    return re.sub(r"[ \t]+", " ", text)


def _extract_printable_legacy_doc(data: bytes):
    # Legacy binary DOC is OLE/Compound File. Without Word/antiword we cannot
    # perfectly reconstruct its layout, but technical notes/BOM labels often
    # survive as printable ANSI or UTF-16 strings. Recover both conservatively.
    chunks = []
    ansi = re.findall(rb"[\x20-\x7e\x80-\xff]{4,}", data)
    for raw in ansi:
        value = decode_bytes(raw).strip()
        if value:
            chunks.append(value)

    try:
        utf16 = data.decode("utf-16le", errors="ignore")
        chunks.extend(x.strip() for x in re.findall(r"[\w\s.,;:/+()\-]{6,}", utf16) if x.strip())
    except Exception:
        pass

    # De-duplicate and cap junk volume.
    out = []
    seen = set()
    for value in chunks:
        value = re.sub(r"\s+", " ", value).strip()
        if len(value) < 4:
            continue
        key = value.upper()
        if key in seen:
            continue
        seen.add(key)
        out.append(value)
        if len(out) >= 5000:
            break
    return "\n".join(out)


def read_doc_legacy(path: Path):
    data = path.read_bytes()
    head = data[:256].lstrip()

    # Some ERP systems use .doc extension for RTF or HTML.
    decoded = decode_bytes(data)
    if head.startswith(b"{\\rtf"):
        text = _strip_rtf(decoded)
        return text, {"sheetCount": 0, "rowCount": len(text.splitlines()), "sourceType": "doc-rtf"}
    if b"<html" in data[:4096].lower() or b"<table" in data[:4096].lower():
        prepared = re.sub(r"(?i)</(?:td|th)>", " | ", decoded)
        prepared = re.sub(r"(?i)</tr>", "\n", prepared)
        text = re.sub(r"<[^>]+>", " ", prepared)
        text = re.sub(r"[ \t]+", " ", text)
        return text, {"sheetCount": 0, "rowCount": len(text.splitlines()), "sourceType": "doc-html"}

    # Prefer antiword if the workstation already has it.
    antiword = shutil.which("antiword")
    if antiword:
        try:
            proc = subprocess.run(
                [antiword, str(path)], capture_output=True, timeout=30
            )
            if proc.returncode == 0 and proc.stdout:
                text = decode_bytes(proc.stdout)
                return text, {"sheetCount": 0, "rowCount": len(text.splitlines()), "sourceType": "doc-antiword"}
        except Exception:
            pass

    # LibreOffice fallback, if present.
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if soffice:
        try:
            with tempfile.TemporaryDirectory(prefix="dse_doc_") as tmp:
                proc = subprocess.run(
                    [soffice, "--headless", "--convert-to", "txt:Text", "--outdir", tmp, str(path)],
                    capture_output=True, timeout=45
                )
                converted = Path(tmp) / (path.stem + ".txt")
                if proc.returncode == 0 and converted.exists():
                    text = decode_bytes(converted.read_bytes())
                    if text.strip():
                        return text, {"sheetCount": 0, "rowCount": len(text.splitlines()), "sourceType": "doc-libreoffice"}
        except Exception:
            pass

    # Microsoft Word COM fallback on Windows. This gives proper legacy .doc
    # extraction on many company workstations that already have Office.
    if sys.platform == "win32":
        try:
            import win32com.client
            word = win32com.client.DispatchEx("Word.Application")
            word.Visible = False
            word.DisplayAlerts = 0
            doc = None
            try:
                doc = word.Documents.Open(
                    str(path.resolve()),
                    ReadOnly=True,
                    AddToRecentFiles=False,
                    Visible=False,
                )
                text = str(doc.Content.Text or "")
                if text.strip():
                    return text, {"sheetCount": 0, "rowCount": len(text.splitlines()), "sourceType": "doc-word-com"}
            finally:
                if doc is not None:
                    try:
                        doc.Close(False)
                    except Exception:
                        pass
                try:
                    word.Quit()
                except Exception:
                    pass
        except Exception:
            pass

    text = _extract_printable_legacy_doc(data)
    return text, {"sheetCount": 0, "rowCount": len(text.splitlines()), "sourceType": "doc-binary-recovery"}


def read_rtf(path: Path):
    text = _strip_rtf(decode_bytes(path.read_bytes()))
    return text, {"sheetCount": 0, "rowCount": len(text.splitlines()), "sourceType": "rtf"}


def try_docling_enrichment(path: Path):
    """Optional MIT-licensed Docling structure extraction.

    It is deliberately an enrichment layer: portable/offline DS Estimate keeps
    working with its lightweight readers when Docling or its models are absent.
    Enable with DSE_ENABLE_DOCLING=1 on a prepared workstation.
    """
    if os.environ.get("DSE_ENABLE_DOCLING", "").strip() != "1":
        return "", "disabled"
    try:
        from docling.document_converter import DocumentConverter
        converted = DocumentConverter().convert(path)
        markdown = converted.document.export_to_markdown()
        return str(markdown or ""), "docling"
    except ModuleNotFoundError:
        return "", "not-installed"
    except Exception as exc:
        return "", f"error:{type(exc).__name__}:{exc}"


def analyze(path: Path):
    ext = path.suffix.lower()
    if ext in {".txt", ".bom", ".log", ".md"}:
        text, meta = read_plain(path)
    elif ext == ".docx":
        text, meta = read_docx(path)
    elif ext == ".doc":
        text, meta = read_doc_legacy(path)
    elif ext == ".rtf":
        text, meta = read_rtf(path)
    elif ext == ".csv":
        text, meta = read_csv_file(path)
    elif ext in {".xlsx", ".xlsm"}:
        text, meta = read_xlsx(path)
    elif ext == ".xls":
        text, meta = read_xls(path)
    else:
        raise ValueError(f"Nieobsługiwany dokument tabelaryczny/tekstowy: {ext}")

    docling_text, docling_state = try_docling_enrichment(path)
    if docling_text.strip():
        # Preserve native table separators for BOM parsing and append Docling's
        # reading-order view for notes/headings that OOXML readers can miss.
        native_lines = {line.strip() for line in text.splitlines() if line.strip()}
        extra = [line for line in docling_text.splitlines() if line.strip() and line.strip() not in native_lines]
        if extra:
            text = text + "\nDOCLING STRUCTURE:\n" + "\n".join(extra)

    bom_items = extract_bom_items(text, path.name)
    if bom_items:
        semantic_text = _text_without_bom_data_rows(text)
    elif ext in {".csv", ".xlsx", ".xlsm", ".xls"}:
        semantic_text = _technical_notes_from_unrecognized_table(text)
    else:
        semantic_text = text
    result = result_from_text(semantic_text)
    result.update(meta)
    result["sourceFile"] = path.name
    result["documentStructureEngine"] = docling_state
    if docling_state == "docling":
        result.setdefault("findings", []).append("Docling: lokalna analiza struktury i kolejności tekstu została dołączona.")
    elif docling_state.startswith("error:"):
        result.setdefault("warnings", []).append("DOCLING_OPTIONAL: " + docling_state)
    result["bomItems"] = bom_items
    if meta.get("readerWarning"):
        result.setdefault("warnings", []).append(str(meta["readerWarning"]))

    # If the BOM itself carries one unambiguous material family, preserve that as
    # a low-noise material hint even though its data rows were intentionally kept
    # out of the drawing-note semantic pass. Mixed-material BOMs remain unset.
    if not result.get("materialHint") and bom_items:
        materials = [str(x.get("material") or "").strip() for x in bom_items]
        known = []
        for value in materials:
            m = MATERIAL_RE.search(value)
            if m:
                known.append(m.group(0).upper())
        unique = list(dict.fromkeys(known))
        if len(unique) == 1:
            result["materialHint"] = unique[0]
            result.setdefault("findings", []).append(f"Materiał z BOM: {unique[0]}")
        elif len(unique) > 1:
            result["materialHint"] = "MIXED: " + " / ".join(unique[:12])
            result.setdefault("findings", []).append(
                "BOM wielomateriałowy: " + ", ".join(unique[:12]) + ". Masa/koszt nie wymagają jednego globalnego gatunku."
            )

    # Spreadsheet rows use ASCII pipes as cell separators. Never let a delimiter
    # pair such as "| |" masquerade as the GD&T parallelism symbol. Keep a
    # tolerance only when the row contains an explicit textual GD&T keyword or a
    # genuine Unicode drawing symbol. An ASCII // or || is accepted only for
    # realistically small tolerance values.
    explicit_geo_words = re.compile(
        r"(?i)parallelism|parallelit|rownoleg|parallelisme|flatness|ebenheit|plask|planeit|"
        r"perpendicular|rechtwink|prostopad|position(?:al)?\s+tolerance|positionstoleranz|"
        r"straightness|geradheit|prostolini|circularity|rundheit|cylindricity|runout|rundlauf|bicie")
    sanitized_geo = []
    for g in result.get("geometricTolerances", []) or []:
        src = str(g.get("sourceText") or "")
        val = g.get("valueMm")
        has_real_symbol = any(sym in src for sym in ("∥", "⏥", "⟂", "⊥", "⌖"))
        has_word = explicit_geo_words.search(src) is not None
        has_ascii_symbol = "//" in src or "||" in src
        if has_real_symbol or has_word or (has_ascii_symbol and val is not None and 0 < float(val) <= 2.0):
            sanitized_geo.append(g)
    result["geometricTolerances"] = sanitized_geo

    mass_rows = [x for x in bom_items if x.get("totalMassKg") is not None]
    positive_mass_rows = [x for x in mass_rows if float(x.get("totalMassKg") or 0) > 0]
    explicit_total_mass = _explicit_total_mass_from_preamble(text)
    if mass_rows:
        result["bomMassRowCount"] = len(mass_rows)
        result["bomPositiveMassRowCount"] = len(positive_mass_rows)

    if explicit_total_mass is not None:
        result["bomTotalMassKg"] = explicit_total_mass
        result.setdefault("findings", []).append(
            f"BOM/ERP: masa całego złożenia {explicit_total_mass:.3f} kg z metadanych arkusza; "
            "nie sumowano hierarchicznie mas rodziców i dzieci."
        )
    elif positive_mass_rows:
        # If hierarchy levels are available, only the highest (minimum numeric)
        # level contributes to project mass. Summing all levels double-counts
        # assemblies and their children. Flat BOMs keep the historical sum.
        leveled = [x for x in positive_mass_rows if x.get("level") is not None]
        if leveled:
            min_level = min(int(x.get("level") or 0) for x in leveled)
            selected = [x for x in positive_mass_rows if int(x.get("level") or -999) == min_level]
        else:
            selected = positive_mass_rows
        result["bomTotalMassKg"] = sum(float(x.get("totalMassKg") or 0) for x in selected)
        result.setdefault("findings", []).append(
            f"BOM: masa łączna {result['bomTotalMassKg']:.3f} kg z {len(selected)} pozycji "
            + (f"najwyższego poziomu {min_level}." if leveled else "z kolumną masy.")
        )
    return result


def main():
    if len(sys.argv) < 2:
        print(json.dumps({"fatal": "Brak ścieżki pliku"}, ensure_ascii=True))
        return 2
    path = Path(sys.argv[1])
    if not path.exists():
        print(json.dumps({"fatal": "Plik nie istnieje"}, ensure_ascii=True))
        return 2
    try:
        print(json.dumps(analyze(path), ensure_ascii=True))
        return 0
    except Exception as exc:
        print(json.dumps({
            "materialHint": "",
            "keywords": [],
            "norms": [],
            "findings": [],
            "warnings": [f"{type(exc).__name__}: {exc}"],
            "detectedLanguages": [],
            "ocrLanguagesUsed": "",
            "ocrEnginePath": "",
            "extractedTextLength": 0,
            "fatal": str(exc),
        }, ensure_ascii=True))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
