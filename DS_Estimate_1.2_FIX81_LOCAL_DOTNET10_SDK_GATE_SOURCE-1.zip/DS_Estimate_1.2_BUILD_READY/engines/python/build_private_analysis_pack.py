#!/usr/bin/env python3
import argparse, csv, hashlib, json, os, re, sys, tempfile, zipfile
from pathlib import Path

TECH_RE = re.compile(r"(?i)(mass|weight|gewicht|masa|material|werkstoff|s355|s690|hardox|weld|schwei|spaw|iso\s*58|iso\s*40|iso\s*17|paint|coat|beschicht|malow|ral|dft|sa\s*2|machin|bearbeit|cnc|toler|h7|h8|f8|h9|ra\s*\d|surface|oberfl|hole|bohr|otwor|thread|gewinde|m\d+|qty|quantity|menge|stück|szt|thick|dicke|grub|plate|blech|profile|profil|cut|laser|plasma|thermal|forming|bend|bieg|ndt|ut\b|mt\b|pt\b|rt\b|drawing\s*no|part\s*no|pos\.?\s*\d)")
EMAIL_RE = re.compile(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", re.I)
LONG_ID_RE = re.compile(r"(?<![\d.,])\d{7,}(?![\d.,])")
PHONE_RE = re.compile(r"(?<!\d)(?:\+?\d[\s().-]*){8,}(?!\d)")
PHONE_CUE_RE = re.compile(r"(?i)\b(?:tel(?:efon)?|phone|mobile|mobil|fax|kontakt|contact)\b")
ENTITY_RE = re.compile(r"(?<!\d)\d{8,14}(?!\d)")


def sha(s: bytes) -> str: return hashlib.sha256(s).hexdigest()


def source_signature(stat_result):
    # FIX75: source metadata and the SHA256 must refer to the same stable
    # file. Include identity to catch same-size replacements, not just edits.
    return (stat_result.st_dev, stat_result.st_ino,
            stat_result.st_size, stat_result.st_mtime_ns)


class SourceChangedDuringPack(Exception):
    pass


def write_private_entry(archive: zipfile.ZipFile, name: str, content: str):
    # FIX69: ZipFile.writestr(name, ...) silently embeds the current local
    # clock in each member. A stable manifest alone is not enough for stable
    # ZIP bytes / SHA256. Set canonical DOS timestamp and portable attributes.
    member = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    member.create_system = 3
    member.external_attr = 0o600 << 16
    archive.writestr(member, content, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
def token(text: str, prefix='ID') -> str: return f"<{prefix}_{hashlib.sha256(text.encode('utf-8','ignore')).hexdigest()[:10]}>"
def redact(s: str) -> str:
    s = EMAIL_RE.sub(lambda m: token(m.group(0),'EMAIL'), s)
    # FIX12D: do not turn prices/hours/percentages into fake phone numbers. A phone
    # is redacted only when the line has a contact cue or the candidate starts with
    # an explicit international '+'. Long numeric identifiers are still hashed.
    if PHONE_CUE_RE.search(s):
        s = PHONE_RE.sub(lambda m: token(m.group(0),'PHONE'), s)
    else:
        s = re.sub(r"(?<!\d)\+\d(?:[\s().-]*\d){7,}(?!\d)", lambda m: token(m.group(0),'PHONE'), s)
    s = LONG_ID_RE.sub(lambda m: token(m.group(0),'NUM'), s)
    return s

def entity_ids(*values: str):
    out=[]
    for value in values:
        for m in ENTITY_RE.finditer(value or ''):
            t=token(m.group(0),'ENTITY')
            if t not in out: out.append(t)
    return out[:80]

def technical_lines(text: str, limit=220):
    out=[]
    for raw in text.splitlines():
        line=' '.join(raw.strip().split())
        if not line or not TECH_RE.search(line): continue
        line=redact(line)[:600]
        if line not in out: out.append(line)
        if len(out)>=limit: break
    return out

def read_text(path: Path):
    ext=path.suffix.lower()
    try:
        if ext in {'.txt','.csv','.log','.xml'}:
            # FIX76: Path.read_text() loads the ENTIRE document before slicing.
            # A multi-GB customer CSV/log could exhaust the Python worker.
            # Read at most the same five million decoded characters instead.
            with path.open('r', encoding='utf-8', errors='replace') as stream:
                return stream.read(5_000_000)
        if ext=='.pdf':
            from pypdf import PdfReader
            # FIX73: PdfReader(path-string) may retain its own file handle until
            # garbage collection. Own the stream and close it deterministically
            # after all lazy page extraction, including when a page raises.
            with path.open('rb') as pdf_stream:
                r = PdfReader(pdf_stream)
                return '\n'.join((page.extract_text() or '') for page in r.pages[:80])
        if ext=='.dxf':
            import ezdxf
            doc=ezdxf.readfile(str(path)); vals=[]
            for e in doc.modelspace():
                t=e.dxftype()
                if t in ('TEXT','MTEXT'):
                    try: vals.append(e.plain_text() if t=='MTEXT' else e.dxf.text)
                    except Exception: pass
            return '\n'.join(vals)
        if ext in {'.xlsx','.xlsm'}:
            import openpyxl
            wb=openpyxl.load_workbook(path, read_only=True, data_only=True)
            try:
                vals=[]
                for ws in wb.worksheets[:12]:
                    for row in ws.iter_rows(values_only=True):
                        vals.append(' | '.join(str(v) for v in row if v is not None))
                        if len(vals)>12000: break
                return '\n'.join(vals)
            finally:
                # FIX72: read_only workbooks hold an open ZIP/file handle.
                # Release it on success AND when a worksheet fails mid-read.
                # This matters for repeated packs and Windows file locks.
                wb.close()
        if ext=='.docx':
            import docx
            d=docx.Document(str(path)); return '\n'.join(p.text for p in d.paragraphs)
        if ext in {'.stp','.step'}:
            # STEP is not copied. Only header / textual metadata is sampled.
            with path.open('r',encoding='latin-1',errors='replace') as f:
                return ''.join(f.readline() for _ in range(5000))
    except Exception as ex:
        # FIX68: exception messages may contain absolute paths, customer names,
        # and proprietary document text. Never place them in a private pack.
        return f"EXTRACT_ERROR: {type(ex).__name__}"
    return ''

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('payload'); ap.add_argument('output', nargs='?')
    args=ap.parse_args()
    if args.output is None:
        cfg=json.loads(args.payload)
        source=cfg['source']; output=cfg['output']
    else:
        source=args.payload; output=args.output
    root=Path(source).resolve(); out=Path(output).resolve()
    if not root.is_dir(): raise SystemExit('SOURCE_NOT_FOLDER')
    entries=[]; snippets={}; total=0
    # FIX80: retain the snapshot of every processed file. A file verified
    # early in a large folder may change while later files or ZIP members
    # are processed, after its individual FIX75 check has already passed.
    source_snapshots=[]
    supported={'.pdf','.dxf','.dwg','.stp','.step','.xlsx','.xlsm','.xls','.csv','.txt','.docx','.doc','.jpg','.jpeg','.png','.tif','.tiff','.zip'}
    # FIX67: filesystem traversal order is unspecified (and differs across
    # filesystems). Stable ordering makes manifests/snippets and the resulting
    # private ZIP reproducible for identical inputs, including after retries.
    for p in sorted(root.rglob('*'), key=lambda p: (p.relative_to(root).as_posix().casefold(),
                                                    p.relative_to(root).as_posix())):
        # Never ingest the pack being written (including a previous run in the
        # source tree), or symlinked files that may point outside this folder.
        # Both would make a supposedly source-only private pack misleading.
        # FIX71: a previous interrupted run (or a concurrent run) may leave
        # an in-progress .<output-name>.<random>.tmp in the source folder.
        # Such internal ZIP fragments must not affect source counts, hashes,
        # or reproducibility. Only exclude this generator's output-specific
        # temporary names in the output directory, not unrelated .tmp files.
        pack_temp = (p.parent == out.parent
                     and p.name.startswith(f'.{out.name}.')
                     and p.name.endswith('.tmp'))
        if p.is_symlink() or p.resolve() == out or pack_temp or not p.is_file():
            continue
        try:
            before = p.stat()
        except OSError:
            # Do not emit an apparently complete inventory after a stat error.
            raise SystemExit('SOURCE_STAT_FAILED') from None
        size = before.st_size
        total+=size
        rel=p.relative_to(root)
        group=token(str(rel.parent).lower(),'GROUP')
        family=token(re.sub(r'([_-](?:rev|r|index)?[a-z0-9]+)$','',p.stem.lower()),'FAMILY')
        try:
            with p.open('rb') as fh:
                if source_signature(os.fstat(fh.fileno())) != source_signature(before):
                    raise SourceChangedDuringPack()
                h=hashlib.sha256()
                for chunk in iter(lambda:fh.read(1024*1024),b''): h.update(chunk)
                if source_signature(os.fstat(fh.fileno())) != source_signature(before):
                    raise SourceChangedDuringPack()
            content_sha=h.hexdigest()
        except SourceChangedDuringPack:
            raise SystemExit('SOURCE_CHANGED_DURING_PACK') from None
        except Exception:
            # FIX74: an empty SHA256 silently claims a successful inventory
            # even though the source bytes were never verified. Abort without
            # touching the previous atomic ZIP; never expose source paths or
            # exception messages in diagnostics.
            raise SystemExit('SOURCE_HASH_FAILED') from None
        text=read_text(p)
        # FIX75: the extractor reopens documents after hashing. If a source
        # was edited/replaced during either pass, the size and digest may no
        # longer describe the same version. Never publish a mixed snapshot.
        try:
            stable = source_signature(p.stat()) == source_signature(before)
        except OSError:
            stable = False
        if not stable:
            raise SystemExit('SOURCE_CHANGED_DURING_PACK') from None
        source_snapshots.append((p, source_signature(before)))
        entities=entity_ids(str(rel), text[:1_000_000])
        rec={'group_id':group,'family_id':family,'entity_ids':entities,'extension':p.suffix.lower(),'size_bytes':size,'sha256':content_sha,'depth':len(rel.parts)-1,'supported':p.suffix.lower() in supported}
        entries.append(rec)
        lines=technical_lines(text)
        if lines: snippets[content_sha[:16] or family]={'extension':p.suffix.lower(),'group_id':group,'family_id':family,'entity_ids':entities,'technical_lines':lines}
    manifest={
      'format':'DS_ESTIMATE_PRIVATE_ANALYSIS_PACK_V2',
      'privacy':'NO_RAW_SOURCE_FILES; technical text snippets are redacted but may still contain confidential engineering facts. Review before sharing.',
      'source_total_bytes':total,'file_count':len(entries),'files':entries,
      'notes':['Original files are never stored in this ZIP.','Long numeric identifiers and e-mails are replaced by stable hashes; phone-like strings require contact context so engineering/cost numbers are preserved.','Folder/file names are replaced by stable GROUP/FAMILY ids; ENTITY ids correlate drawing numbers across documents without exposing the original number.']
    }
    out.parent.mkdir(parents=True,exist_ok=True)
    # FIX66: never destroy the last valid private pack when writing a new one
    # fails (disk full, interrupted ZIP write, denied replacement, etc.).
    # Create a closed temporary file in the destination directory so os.replace
    # is atomic on the same filesystem, including on Windows.
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(prefix=f'.{out.name}.', suffix='.tmp',
                                         dir=out.parent, delete=False) as tmp:
            temporary = Path(tmp.name)
        with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            write_private_entry(z, 'MANIFEST.json', json.dumps(manifest,ensure_ascii=False,indent=2))
            write_private_entry(z, 'TECHNICAL_SNIPPETS.json', json.dumps(snippets,ensure_ascii=False,indent=2))
            write_private_entry(z, 'README_PRIVACY.txt', 'DS Estimate Private Analysis Pack v2\n\nNie zawiera oryginalnych PDF/DXF/STEP/XLSX ani obrazów.\nZawiera metadane, hashe i zredagowane linie techniczne.\nUWAGA: dane techniczne nadal mogą być poufne. Przejrzyj zawartość ZIP przed wysłaniem.\n')
        # FIX80: fail closed before replacing the last known-good archive if
        # any previously verified source has since changed, disappeared, or
        # become a symlink. This is a metadata consistency check, not a
        # filesystem snapshot/lock (adversarial mtime restoration is outside
        # its guarantees). Never include source paths in errors.
        for source_path, expected in source_snapshots:
            try:
                if source_path.is_symlink() or source_signature(source_path.stat()) != expected:
                    raise SourceChangedDuringPack()
            except (OSError, SourceChangedDuringPack):
                raise SystemExit('SOURCE_CHANGED_DURING_PACK') from None
        os.replace(temporary, out)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    print(json.dumps({'ok':True,'files':len(entries),'source_bytes':total,'zip_bytes':out.stat().st_size,'output':str(out)},ensure_ascii=False))
if __name__=='__main__': main()
