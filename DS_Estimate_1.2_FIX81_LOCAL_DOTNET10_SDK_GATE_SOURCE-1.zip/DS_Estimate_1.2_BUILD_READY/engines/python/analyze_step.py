﻿#!/usr/bin/env python3
from __future__ import annotations

import json
import math
import hashlib
import os
import sys
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path


def _progress(percent, message):
    if os.environ.get("DSE_PROGRESS_STREAM", "") != "1":
        return
    try:
        print(f"DSEPROGRESS|{int(max(0, min(100, percent)))}|{message}", file=sys.stderr, flush=True)
    except Exception:
        pass


def empty_result():
    return {
        "available": False,
        "solidCount": 0,
        "uniquePartGroups": 0,
        "contactPairs": 0,
        "contactPairsTight": 0,
        "contactPairsNominal": 0,
        "contactCandidatePairs": 0,
        "contactExactChecks": 0,
        "contactLimitReached": False,
        "holeEngineVersion": "3.0",
        "holeAnalysisState": "unknown",
        "holeFallbackCount": 0,
        "analysisMode": "full",
        "jointEngineVersion": "2.0",
        "surfaceEngineVersion": "4.0",
        "volumeMm3": 0.0,
        "surfaceMm2": 0.0,
        "exposedSurfaceMm2": 0.0,
        "paintableSurfaceMm2": 0.0,
        "planarMatingAreaMm2": 0.0,
        "hiddenMatingSurfaceMm2": 0.0,
        "internalPaintExcludedMm2": 0.0,
        "sealedCavitySurfaceMm2": 0.0,
        "surfaceAccessibilityCheckedFaces": 0,
        "surfaceAccessibilityLimitReached": False,
        "weldCandidatePairs": 0,
        "possibleBoltedJointPairs": 0,
        "weldCandidateLengthMm": 0.0,
        "jointAnalysisLimitReached": False,
        "jointFaceChecks": 0,
        "jointCandidates": [],
        "boundingXmm": 0.0,
        "boundingYmm": 0.0,
        "boundingZmm": 0.0,
        "totalHoleCount": 0,
        "totalPocketCandidateCount": 0,
        "pocketEngineVersion": "1.0-openmill-brep",
        "totalBevelFaces": 0,
        "parts": [],
        "warnings": [],
    }


def vec_tuple(v):
    try:
        return tuple(float(x) for x in v.toTuple())
    except Exception:
        return (float(v.x), float(v.y), float(v.z))


def unit(v):
    x, y, z = vec_tuple(v)
    length = math.sqrt(x*x + y*y + z*z)
    if length <= 1e-12:
        return None
    return (x/length, y/length, z/length)


def acute_angle(a, b):
    dot = abs(a[0]*b[0] + a[1]*b[1] + a[2]*b[2])
    dot = max(0.0, min(1.0, dot))
    return math.degrees(math.acos(dot))


def dot3(a, b):
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]


def sub3(a, b):
    return (a[0]-b[0], a[1]-b[1], a[2]-b[2])


def add3(a, b):
    return (a[0]+b[0], a[1]+b[1], a[2]+b[2])


def mul3(a, s):
    return (a[0]*s, a[1]*s, a[2]*s)


def cross3(a, b):
    return (
        a[1]*b[2] - a[2]*b[1],
        a[2]*b[0] - a[0]*b[2],
        a[0]*b[1] - a[1]*b[0],
    )


def length3(a):
    return math.sqrt(dot3(a, a))


def normalize3(a):
    n = length3(a)
    if n <= 1e-12:
        return None
    return (a[0]/n, a[1]/n, a[2]/n)


def canonical_axis(direction):
    d = normalize3(direction)
    if d is None:
        return None

    for value in d:
        if abs(value) > 1e-9:
            if value < 0:
                return (-d[0], -d[1], -d[2])
            break

    return d


def classify_stock(dims, volume, bbox_volume, cyl_count, internal_hole_count, internal_planar_count=0):
    a, b, c = sorted(float(x) for x in dims)

    if a <= 1e-9:
        return "Detal", 25, "Niepełny gabaryt bryły."

    fill = volume / bbox_volume if bbox_volume > 1e-9 else 0.0
    thin_ratio = a / max(b, 1e-9)
    long_ratio = c / max(b, 1e-9)
    section_ratio = a / max(b, 1e-9)

    # Plate / sheet: one clearly dominant small thickness and not a very long bar.
    if thin_ratio <= 0.25 and a <= 80.0 and long_ratio <= 6.0:
        confidence = int(max(65, min(96, 96 - thin_ratio * 120)))
        return (
            "Blacha / płyta",
            confidence,
            f"Mała grubość względem szerokości ({a:.1f}/{b:.1f} mm), wypełnienie bbox {fill:.2f}."
        )

    # Long stock.  The old 7x rule missed short but perfectly normal cut lengths
    # (e.g. 20x20x100 profiles or OD50x200 tubes).
    if long_ratio >= 3.5 and c >= a * 3.5:
        if cyl_count > 0 and section_ratio >= 0.72:
            if internal_hole_count > 0 or fill < 0.62:
                return (
                    "Rura / tuleja",
                    84,
                    f"Element długi, przekrój zbliżony do kołowego i wykryta geometria wewnętrzna; fill={fill:.2f}."
                )
            return (
                "Pręt / wałek",
                82,
                f"Element długi z dominującą powierzchnią cylindryczną; fill={fill:.2f}."
            )

        if thin_ratio <= 0.22:
            return (
                "Płaskownik / profil płaski",
                86,
                f"Długi element o małej grubości ({a:.1f} mm) i stosunku długość/szerokość {long_ratio:.1f}."
            )

        if fill < 0.72:
            if cyl_count == 0 and internal_planar_count >= 4:
                return (
                    "Profil zamknięty / RHS-SHS",
                    90,
                    f"Długi element o pustym zamkniętym przekroju; "
                    f"wewnętrzne ściany planarne: {internal_planar_count}, fill={fill:.2f}."
                )
            return (
                "Profil / element długi",
                82,
                f"Długi element, stosunek długość/szerokość {long_ratio:.1f}, fill={fill:.2f}."
            )

        return (
            "Pręt / profil pełny",
            78,
            f"Długi pełny element, stosunek długość/szerokość {long_ratio:.1f}, fill={fill:.2f}."
        )

    # Short hollow structural stock is common in weldments (stubs, sleeves,
    # spacers). Do not require a 3.5x length ratio when the cross-section itself
    # provides strong hollow-profile evidence.
    if fill < 0.72 and cyl_count == 0 and internal_planar_count >= 4:
        return (
            "Profil zamknięty / RHS-SHS",
            84,
            f"Pusty zamknięty przekrój niezależnie od długości; "
            f"wewnętrzne ściany planarne: {internal_planar_count}, fill={fill:.2f}."
        )

    # Medium-length rotational stock. A 2-3x diameter cut piece is still
    # much more likely to be round bar/tube stock than a generic machined block.
    rotational_ratio = c / max(a, 1e-9)
    if cyl_count > 0 and section_ratio >= 0.72 and rotational_ratio >= 2.0:
        if internal_hole_count > 0 or fill < 0.62:
            return (
                "Rura / tuleja",
                76,
                f"Bryła obrotowa o długości {rotational_ratio:.1f}× średnicy/przekroju; fill={fill:.2f}."
            )
        return (
            "Pręt / wałek",
            74,
            f"Pełna bryła obrotowa o długości {rotational_ratio:.1f}× średnicy/przekroju; fill={fill:.2f}."
        )

    if fill >= 0.82:
        return "Bryła pełna", 78, f"Wysokie wypełnienie gabarytu: {fill:.2f}."

    if fill >= 0.60:
        return "Detal obrabiany", 72, f"Średnie wypełnienie gabarytu: {fill:.2f}."

    return "Detal złożony geometrycznie", 62, f"Niskie wypełnienie gabarytu: {fill:.2f}."


def circular_radius(edge):
    try:
        if edge.geomType() != "CIRCLE":
            return None
        radius = float(edge.radius())
        return radius if radius > 0 else None
    except Exception:
        return None


def _cylinder_axis(face):
    try:
        cylinder = face._geomAdaptor().Cylinder()
        axis = cylinder.Axis()
        loc = axis.Location()
        direction = axis.Direction()
        point = (float(loc.X()), float(loc.Y()), float(loc.Z()))
        d = canonical_axis((float(direction.X()), float(direction.Y()), float(direction.Z())))
        radius = abs(float(cylinder.Radius()))
        if d is None or radius <= 1e-9:
            return None
        return point, d, radius
    except Exception:
        return None



def _cylinder_angular_coverage(face):
    """Fraction of full circumference represented by a trimmed cylindrical face."""
    try:
        u0, u1, _v0, _v1 = face._uvBounds()
        span = abs(float(u1) - float(u0))
        if span <= 1e-9:
            return 0.0
        return max(0.0, min(1.0, span / (2.0 * math.pi)))
    except Exception:
        return 0.0


def _cylinder_angular_bins(face, axis_point, axis_dir, bin_count=24):
    """Global angular occupancy of a trimmed cylindrical face.

    Summing U spans is unsafe because two STEP faces can describe the same 180°
    patch at different axial positions. Sampling into a common global angular
    basis lets a cluster distinguish overlapping halves from complementary halves.
    """
    try:
        d = canonical_axis(axis_dir)
        if d is None:
            return set()
        helper = (1.0, 0.0, 0.0) if abs(d[0]) < 0.75 else (0.0, 1.0, 0.0)
        basis_u = normalize3(cross3(d, helper))
        if basis_u is None:
            basis_u = normalize3(cross3(d, (0.0, 0.0, 1.0)))
        if basis_u is None:
            return set()
        basis_v = normalize3(cross3(d, basis_u))
        if basis_v is None:
            return set()

        u0, u1, v0, v1 = face._uvBounds()
        span = abs(float(u1) - float(u0))
        if span <= 1e-9:
            return set()
        coverage = max(0.0, min(1.0, span / (2.0 * math.pi)))
        samples = max(4, int(math.ceil(bin_count * coverage)) + 2)
        vmid = (float(v0) + float(v1)) / 2.0
        out = set()
        for i in range(samples):
            frac = (i + 0.5) / samples
            uu = float(u0) + (float(u1) - float(u0)) * frac
            point = vec_tuple(face.positionAt(uu, vmid))
            along = dot3(sub3(point, axis_point), d)
            nearest = add3(axis_point, mul3(d, along))
            radial = sub3(point, nearest)
            if length3(radial) <= 1e-8:
                continue
            angle = math.atan2(dot3(radial, basis_v), dot3(radial, basis_u))
            if angle < 0:
                angle += 2.0 * math.pi
            idx = int((angle / (2.0 * math.pi)) * bin_count) % bin_count
            out.add(idx)
        return out
    except Exception:
        return set()


def _cone_axis_and_radii(face):
    """Return robust trimmed-cone geometry.

    STEP exporters do not always encode the circular limits of a countersink
    as CIRCLE edges.  V5 relied mostly on circular boundary edges, which made
    countersinks disappear for some diameters/angles/exporters.  V5.1 first
    measures every face vertex relative to the cone axis and only then falls
    back to circular edges / reference radius.
    """
    try:
        cone = face._geomAdaptor().Cone()
        axis = cone.Axis()
        loc = axis.Location()
        direction = axis.Direction()
        axis_point = (float(loc.X()), float(loc.Y()), float(loc.Z()))
        axis_dir = canonical_axis(
            (float(direction.X()), float(direction.Y()), float(direction.Z()))
        )
        if axis_dir is None:
            return None

        radii = []

        # Most robust for trimmed conical STEP faces: use actual vertices.
        try:
            for vertex in face.Vertices():
                p = vec_tuple(vertex.Center())
                along = dot3(sub3(p, axis_point), axis_dir)
                nearest = add3(axis_point, mul3(axis_dir, along))
                radius = length3(sub3(p, nearest))
                if radius > 1e-7:
                    radii.append(radius)
        except Exception:
            pass

        # Some faces have useful circular boundary edges even when vertices
        # are duplicated/split by the exporter.
        try:
            for edge in face.Edges():
                radius = circular_radius(edge)
                if radius is not None and radius > 1e-7:
                    radii.append(radius)
        except Exception:
            pass

        # Reference radius is only a last resort because on a trimmed cone it
        # is not guaranteed to be the entrance diameter of the countersink.
        if not radii:
            ref_radius = abs(float(cone.RefRadius()))
            if ref_radius > 1e-9:
                radii = [ref_radius]

        u0, u1, v0, v1 = face._uvBounds()
        point = vec_tuple(
            face.positionAt((u0 + u1) / 2.0, (v0 + v1) / 2.0)
        )
        normal = unit(face.normalAt())
        if normal is None:
            return None

        along = dot3(sub3(point, axis_point), axis_dir)
        nearest = add3(axis_point, mul3(axis_dir, along))
        radial = sub3(point, nearest)
        radial_len = length3(radial)
        if radial_len <= 1e-9:
            return None

        orientation = dot3(normal, radial) / radial_len
        internal = orientation < -0.12

        unique_radii = sorted(
            {round(float(r), 6) for r in radii if float(r) > 1e-7}
        )

        return {
            "axisPoint": axis_point,
            "axisDir": axis_dir,
            "minRadius": min(unique_radii) if unique_radii else 0.0,
            "maxRadius": max(unique_radii) if unique_radii else 0.0,
            "internal": internal,
            "orientationScore": orientation,
            "semiAngleDeg": abs(math.degrees(float(cone.SemiAngle()))),
        }
    except Exception:
        return None


def _axis_matches(point_a, dir_a, point_b, dir_b, tol=0.75):
    distance = _parallel_axis_distance(point_a, dir_a, point_b, dir_b)
    return distance is not None and distance <= tol

def _face_axial_interval(face, axis_point, axis_dir):
    values = []
    try:
        for vertex in face.Vertices():
            p = vec_tuple(vertex.Center())
            values.append(dot3(sub3(p, axis_point), axis_dir))
    except Exception:
        values = []

    if len(values) >= 2:
        return min(values), max(values)

    # Fallback from side area = 2*pi*r*depth.
    axis = _cylinder_axis(face)
    radius = axis[2] if axis else 0.0
    try:
        depth = abs(float(face.Area())) / max(2.0 * math.pi * radius, 1e-9)
    except Exception:
        depth = 0.0
    return -depth / 2.0, depth / 2.0


def _cylinder_internal_orientation(face, axis_point, axis_dir):
    try:
        u0, u1, v0, v1 = face._uvBounds()
        point = vec_tuple(face.positionAt((u0 + u1) / 2.0, (v0 + v1) / 2.0))
        normal = unit(face.normalAt())
        if normal is None:
            return None, 0.0

        along = dot3(sub3(point, axis_point), axis_dir)
        nearest = add3(axis_point, mul3(axis_dir, along))
        radial = sub3(point, nearest)
        radial_len = length3(radial)
        if radial_len <= 1e-8:
            return None, 0.0

        orientation = dot3(normal, radial) / radial_len
        if orientation < -0.15:
            return True, orientation
        if orientation > 0.15:
            return False, orientation
        return None, orientation
    except Exception:
        return None, 0.0


def _axis_signature(axis_point, axis_dir):
    d = canonical_axis(axis_dir)
    if d is None:
        return None

    projection = dot3(axis_point, d)
    perpendicular = sub3(axis_point, mul3(d, projection))

    return (
        round(d[0], 3), round(d[1], 3), round(d[2], 3),
        round(perpendicular[0], 1),
        round(perpendicular[1], 1),
        round(perpendicular[2], 1),
    )


def _merge_axial_clusters(features, gap_tol=0.35):
    if not features:
        return []

    ordered = sorted(features, key=lambda f: (f["tmin"], f["tmax"]))
    clusters = []
    current = [ordered[0]]
    end = ordered[0]["tmax"]

    for feature in ordered[1:]:
        if feature["tmin"] <= end + gap_tol:
            current.append(feature)
            end = max(end, feature["tmax"])
        else:
            clusters.append(current)
            current = [feature]
            end = feature["tmax"]

    clusters.append(current)
    return clusters


def _through_likely(solid, cq, axis_point, axis_dir, tmin, tmax, diameter):
    epsilon = max(0.05, min(0.30, max(diameter, 1.0) * 0.02))

    before = add3(axis_point, mul3(axis_dir, tmin - epsilon))
    after = add3(axis_point, mul3(axis_dir, tmax + epsilon))

    try:
        before_inside = bool(solid.isInside(cq.Vector(*before), 1e-5))
        after_inside = bool(solid.isInside(cq.Vector(*after), 1e-5))
        return (not before_inside and not after_inside), before_inside, after_inside
    except Exception:
        return False, None, None


def detect_holes_v2(solid, cq):
    internal_features = []
    internal_cones = []
    external_cylinders = 0
    uncertain_cylinders = 0

    for face in solid.Faces():
        try:
            geom_type = face.geomType()

            if geom_type == "CONE":
                cone_info = _cone_axis_and_radii(face)
                if cone_info and cone_info["internal"]:
                    internal_cones.append(cone_info)
                continue

            if geom_type != "CYLINDER":
                continue

            axis = _cylinder_axis(face)
            if axis is None:
                uncertain_cylinders += 1
                continue

            axis_point, axis_dir, radius = axis
            is_internal, orientation = _cylinder_internal_orientation(face, axis_point, axis_dir)

            if is_internal is False:
                external_cylinders += 1
                continue

            if is_internal is None:
                uncertain_cylinders += 1
                # Conservative rule: do not promote uncertain cylinders to holes.
                continue

            tmin, tmax = _face_axial_interval(face, axis_point, axis_dir)
            if tmax < tmin:
                tmin, tmax = tmax, tmin

            internal_features.append({
                "axisPoint": axis_point,
                "axisDir": axis_dir,
                "axisKey": _axis_signature(axis_point, axis_dir),
                "radius": radius,
                "diameter": radius * 2.0,
                "tmin": tmin,
                "tmax": tmax,
                "depth": max(0.0, tmax - tmin),
                "orientationScore": orientation,
                "angularCoverage": _cylinder_angular_coverage(face),
                "angularBins": _cylinder_angular_bins(face, axis_point, axis_dir),
                "circularBoundaryCount": sum(
                    1 for edge in face.Edges()
                    if edge.geomType() == "CIRCLE"
                    and (circular_radius(edge) is not None)
                    and abs(float(circular_radius(edge)) - radius) <= max(0.05, radius * 0.01)
                ),
            })
        except Exception:
            uncertain_cylinders += 1
            continue

    by_axis = defaultdict(list)
    for feature in internal_features:
        if feature["axisKey"] is not None:
            by_axis[feature["axisKey"]].append(feature)

    physical_holes = []
    rejected_hole_candidates = 0
    hole_candidate_count = 0

    for _, same_axis in by_axis.items():
        for cluster in _merge_axial_clusters(same_axis):
            hole_candidate_count += 1
            axis_point = cluster[0]["axisPoint"]
            axis_dir = cluster[0]["axisDir"]
            tmin = min(x["tmin"] for x in cluster)
            tmax = max(x["tmax"] for x in cluster)

            # Split STEP faces often duplicate the same cylindrical stage.
            radii = sorted({round(float(x["radius"]), 3) for x in cluster})
            diameters = [r * 2.0 for r in radii]
            main_diameter = min(diameters) if diameters else 0.0
            max_diameter = max(diameters) if diameters else main_diameter
            depth = max(0.0, tmax - tmin)

            # Manufacturing hole validation 2.3:
            # require nearly full cylindrical circumference. Partial concave
            # cylinders from gear roots, fillets and edge scallops are rejected
            # before expensive point-in-solid queries.
            main_radius = min(radii) if radii else 0.0
            main_features = [
                x for x in cluster
                if abs(float(x.get("radius", 0.0)) - main_radius) <= 0.002
            ]
            angular_bins = set()
            circular_boundaries = 0
            for feature in main_features:
                angular_bins.update(feature.get("angularBins", set()) or set())
                circular_boundaries += int(feature.get("circularBoundaryCount", 0) or 0)
            angular_coverage = len(angular_bins) / 24.0 if angular_bins else 0.0

            # Full circular boundaries are the strongest evidence, but real STEP
            # exporters often split/intersect a bore so that its boundary becomes
            # BSPLINE/LINE. 1.1 keeps those candidates when the cylinder is virtually
            # complete AND its axis is confirmed to run through void. This is a
            # conservative fallback, not a promotion based on topology alone.
            if angular_coverage < 0.82:
                rejected_hole_candidates += 1
                continue

            center_void = False
            if main_features:
                ref = max(main_features, key=lambda x: float(x.get("depth", 0.0)))
                mid_t = (float(ref.get("tmin", 0.0)) + float(ref.get("tmax", 0.0))) / 2.0
                mid_axis = add3(ref["axisPoint"], mul3(ref["axisDir"], mid_t))
                try:
                    center_void = not bool(solid.isInside(cq.Vector(*mid_axis), 1e-5))
                except Exception:
                    center_void = False

            if not center_void:
                rejected_hole_candidates += 1
                continue

            boundary_fallback = circular_boundaries <= 0
            if boundary_fallback:
                min_depth = max(0.6, main_diameter * 0.10)
                if angular_coverage < 0.96 or depth < min_depth:
                    rejected_hole_candidates += 1
                    continue

            through, before_inside, after_inside = _through_likely(
                solid, cq, axis_point, axis_dir, tmin, tmax, main_diameter
            )

            if through:
                hole_type = "przelotowy"
            elif before_inside is True or after_inside is True:
                hole_type = "nieprzelotowy"
            else:
                hole_type = "wewnętrzny"

            stage_count = len(radii)
            counterbore = stage_count > 1 and max_diameter > main_diameter + 0.15
            max_stage_depth = max(
                (float(x.get("depth", 0.0)) for x in cluster
                 if abs(float(x.get("diameter", 0.0)) - max_diameter) <= 0.15),
                default=0.0,
            )
            # Spotfaces and counterbores are topologically similar. A very shallow
            # large-diameter cylindrical stage is much more likely a spotface.
            spotface = counterbore and max_stage_depth > 0 and (
                max_stage_depth <= 1.5 or
                max_stage_depth <= max(0.5, main_diameter * 0.12)
            )
            confidence = (76 if boundary_fallback else (94 if through else 90 if hole_type == "nieprzelotowy" else 82))

            physical_holes.append({
                "diameterMm": main_diameter,
                "maxDiameterMm": max_diameter,
                "depthMm": depth,
                "throughLikely": through,
                "counterboreLikely": counterbore and not spotface,
                "spotfaceLikely": spotface,
                "counterboreDepthMm": max_stage_depth,
                "stageCount": stage_count,
                "type": hole_type,
                "confidence": confidence,
                "angularCoverage": round(angular_coverage, 3),
                "circularBoundaryCount": circular_boundaries,
                "centerVoidConfirmed": bool(center_void),
                "boundaryFallback": bool(boundary_fallback),
                "axisPoint": axis_point,
                "axisDir": axis_dir,
            })


    # Associate internal conical faces with a physical hole on the same axis.
    # A cone does not create a second physical hole; it decorates the hole as
    # a countersink and expands the maximum entrance diameter.
    for hole in physical_holes:
        hole["countersinkLikely"] = False
        hole["countersinkAngleDeg"] = 0.0

        for cone in internal_cones:
            if not _axis_matches(
                hole.get("axisPoint"), hole.get("axisDir"),
                cone.get("axisPoint"), cone.get("axisDir"),
            ):
                continue

            cone_max_diameter = float(cone.get("maxRadius", 0.0)) * 2.0
            if cone_max_diameter <= float(hole.get("diameterMm", 0.0)) + 0.15:
                continue

            hole["countersinkLikely"] = True
            hole["countersinkAngleDeg"] = round(float(cone.get("semiAngleDeg", 0.0)) * 2.0, 2)
            hole["maxDiameterMm"] = max(
                float(hole.get("maxDiameterMm", 0.0)),
                cone_max_diameter,
            )

    # Group equal physical holes for compact UI, but count each axis only once.
    grouped = defaultdict(list)
    for hole in physical_holes:
        key = (
            round(hole["diameterMm"], 1),
            round(hole["maxDiameterMm"], 1),
            round(hole["depthMm"], 1),
            bool(hole["throughLikely"]),
            bool(hole["counterboreLikely"]),
            bool(hole.get("spotfaceLikely", False)),
            bool(hole.get("countersinkLikely", False)),
            round(float(hole.get("countersinkAngleDeg", 0.0)), 1),
            int(hole["stageCount"]),
            hole["type"],
        )
        grouped[key].append(hole)

    result = []
    for _, items in grouped.items():
        first = items[0]
        result.append({
            "diameterMm": first["diameterMm"],
            "maxDiameterMm": first["maxDiameterMm"],
            "depthMm": first["depthMm"],
            "throughLikely": first["throughLikely"],
            "counterboreLikely": first["counterboreLikely"],
            "spotfaceLikely": first.get("spotfaceLikely", False),
            "counterboreDepthMm": first.get("counterboreDepthMm", 0.0),
            "countersinkLikely": first.get("countersinkLikely", False),
            "countersinkAngleDeg": first.get("countersinkAngleDeg", 0.0),
            "stageCount": first["stageCount"],
            "type": first["type"],
            "confidence": first["confidence"],
            "count": len(items),
        })

    result.sort(key=lambda x: (x["diameterMm"], x["depthMm"], x["type"]))

    return {
        "holes": result,
        "physicalCount": len(physical_holes),
        "fallbackHoleCount": sum(1 for h in physical_holes if h.get("boundaryFallback")),
        "manufacturingHoleCount": len(physical_holes),
        "holeCandidateCount": hole_candidate_count,
        "rejectedHoleCandidates": rejected_hole_candidates,
        "externalCylindricalFaces": external_cylinders,
        "uncertainCylindricalFaces": uncertain_cylinders,
        "internalCylindricalFaces": len(internal_features),
        "internalConicalFaces": len(internal_cones),
        "physicalHolesDetailed": physical_holes,
    }


def detect_bevels(solid):
    planar = []

    for face in solid.Faces():
        try:
            if face.geomType() != "PLANE":
                continue

            normal = unit(face.normalAt())
            if normal is None:
                continue

            area = float(face.Area())
            if area <= 1e-6:
                continue

            planar.append((area, normal))
        except Exception:
            continue

    if len(planar) < 3:
        return {"count": 0, "minAngleDeg": 0.0, "maxAngleDeg": 0.0}

    planar.sort(key=lambda x: x[0], reverse=True)
    max_area = planar[0][0]
    major = planar[: min(8, len(planar))]
    angles = []

    for area, normal in planar:
        if area > max_area * 0.30:
            continue

        candidate = []

        for major_area, major_normal in major:
            if major_area <= area * 1.25:
                continue

            angle = acute_angle(normal, major_normal)

            if 20.0 <= angle <= 70.0:
                candidate.append(angle)

        if candidate:
            angles.append(min(candidate))

    if not angles:
        return {"count": 0, "minAngleDeg": 0.0, "maxAngleDeg": 0.0}

    return {
        "count": len(angles),
        "minAngleDeg": min(angles),
        "maxAngleDeg": max(angles),
    }


def detect_pocket_candidates(solid):
    """Conservative BREP pocket-floor detector inspired by OpenMill.

    OpenMill finds upward-facing mesh floors below the model top.  DS Estimate
    has exact CadQuery/OCC faces. Like OpenMill, the conservative automatic pass
    uses one principal machining axis (the thinnest stock direction) and exact
    face area/bounding depth. Side features remain for a future multi-setup pass.
    Results are candidates for costing, never definitive CAM operations.
    """
    try:
        bb = solid.BoundingBox()
        bounds = ((float(bb.xmin), float(bb.xmax)),
                  (float(bb.ymin), float(bb.ymax)),
                  (float(bb.zmin), float(bb.zmax)))
        spans = tuple(hi - lo for lo, hi in bounds)
        primary_axis = min(range(3), key=lambda i: (spans[i], -i))
        faces = list(solid.Faces())
        max_planar_area = max(
            (abs(float(f.Area())) for f in faces if f.geomType() == "PLANE"),
            default=0.0,
        )
    except Exception:
        return {"count": 0, "areaMm2": 0.0, "maxDepthMm": 0.0, "candidates": []}

    candidates = []
    for face in faces:
        try:
            if face.geomType() != "PLANE":
                continue
            area = abs(float(face.Area()))
            if area < 4.0 or (max_planar_area > 0 and area > max_planar_area * 0.92):
                continue
            normal = unit(face.normalAt())
            if normal is None:
                continue
            axis = max(range(3), key=lambda i: abs(normal[i]))
            if axis != primary_axis:
                continue
            alignment = abs(normal[axis])
            if alignment < 0.94:
                continue
            center = vec_tuple(face.Center())
            lo, hi = bounds[axis]
            depth = (hi - center[axis]) if normal[axis] > 0 else (center[axis] - lo)
            span = max(hi - lo, 1e-9)
            if depth < 0.5 or depth > span * 0.90:
                continue
            candidates.append({
                "axis": "XYZ"[axis] + ("+" if normal[axis] > 0 else "-"),
                "areaMm2": area,
                "depthMm": depth,
                "centerMm": [center[0], center[1], center[2]],
                "confidence": 72,
            })
        except Exception:
            continue

    candidates.sort(key=lambda x: (-x["areaMm2"], -x["depthMm"], x["axis"]))
    return {
        "count": len(candidates),
        "areaMm2": sum(x["areaMm2"] for x in candidates),
        "maxDepthMm": max((x["depthMm"] for x in candidates), default=0.0),
        "candidates": candidates[:24],
    }


def fingerprint(dims, volume, area, face_count, cyl_count, cone_count):
    ordered = sorted(round(x, 1) for x in dims)

    return "|".join([
        *(f"{x:.1f}" for x in ordered),
        f"V{round(volume, 0):.0f}",
        f"A{round(area, 0):.0f}",
        f"F{face_count}",
        f"C{cyl_count}",
        f"N{cone_count}",
    ])



def planar_internal_metrics(solid):
    """Conservative concave/internal planar-face heuristic.

    It is used to recognize closed RHS/SHS stock, not to blindly remove
    concave faces from every manufactured part.
    """
    try:
        solid_center = vec_tuple(solid.Center())
    except Exception:
        solid_center = vec_tuple(solid.CenterOfBoundBox())

    count = 0
    area = 0.0

    for face in solid.Faces():
        try:
            if face.geomType() != "PLANE":
                continue

            normal = unit(face.normalAt())
            if normal is None:
                continue

            face_center = vec_tuple(face.Center())
            radial = sub3(face_center, solid_center)

            if dot3(normal, radial) < -1e-4:
                count += 1
                area += abs(float(face.Area()))
        except Exception:
            continue

    return count, area


def confident_internal_paint_area(solid, classification):
    """Area excluded from default external painting only when confidence is high.

    First handle topologically closed internal shells (sealed cavities) directly.
    A valid B-Rep solid has one outer shell and may have one or more inner closed
    shells. This is more reliable than ray-casting for a single solid containing a
    completely sealed cavity. Open holes/channels remain part of the outer shell.

    Then use profile-specific rules for open-ended tubes/RHS where the internal
    surfaces belong to the same shell as the exterior.
    """
    area = 0.0

    try:
        shells = list(solid.Shells())
        if len(shells) > 1:
            def shell_extent(sh):
                bb = sh.BoundingBox()
                return max(0.0, bb.xlen) * max(0.0, bb.ylen) * max(0.0, bb.zlen)
            outer = max(shells, key=shell_extent)
            closed_internal = sum(abs(float(sh.Area())) for sh in shells if sh is not outer)
            if closed_internal > 1e-6:
                return closed_internal
    except Exception:
        pass

    if classification == "Rura / tuleja":
        for face in solid.Faces():
            try:
                if face.geomType() != "CYLINDER":
                    continue
                axis = _cylinder_axis(face)
                if axis is None:
                    continue
                is_internal, _ = _cylinder_internal_orientation(
                    face, axis[0], axis[1]
                )
                if is_internal is True:
                    area += abs(float(face.Area()))
            except Exception:
                continue

    elif classification == "Profil zamknięty / RHS-SHS":
        _, area = planar_internal_metrics(solid)

    return area



def _ray_directions(normal):
    n = normalize3(normal)
    if n is None:
        return []

    reference = (1.0, 0.0, 0.0) if abs(n[0]) < 0.8 else (0.0, 1.0, 0.0)
    t1 = normalize3(cross3(n, reference))
    t2 = normalize3(cross3(n, t1)) if t1 else None

    if t1 is None or t2 is None:
        return [n]

    raw = [
        n,
        add3(mul3(n, 0.25), t1),
        add3(mul3(n, 0.25), mul3(t1, -1.0)),
        add3(mul3(n, 0.25), t2),
        add3(mul3(n, 0.25), mul3(t2, -1.0)),
        add3(mul3(n, 0.20), add3(mul3(t1, 0.70), mul3(t2, 0.70))),
        add3(mul3(n, 0.20), add3(mul3(t1, 0.70), mul3(t2, -0.70))),
        add3(mul3(n, 0.20), add3(mul3(t1, -0.70), mul3(t2, 0.70))),
        add3(mul3(n, 0.20), add3(mul3(t1, -0.70), mul3(t2, -0.70))),
    ]
    return [d for d in (normalize3(x) for x in raw) if d is not None]


def _ray_escapes_shape(raw_shape, start, direction, max_distance):
    try:
        from OCP.BRepIntCurveSurface import BRepIntCurveSurface_Inter
        from OCP.gp import gp_Lin, gp_Pnt, gp_Dir

        inter = BRepIntCurveSurface_Inter()
        inter.Init(
            raw_shape,
            gp_Lin(gp_Pnt(*start), gp_Dir(*direction)),
            1e-6,
        )

        while inter.More():
            w = float(inter.W())
            if 1e-4 < w < max_distance:
                return False
            inter.Next()

        return True
    except Exception:
        # Fail open: never delete paint area if accessibility could not be proven.
        return True


def _triangle_area(a, b, c):
    return 0.5 * length3(cross3(sub3(b, a), sub3(c, a)))


def _point_escapes_from_face(face, raw_shape, point, max_distance, cq, epsilon=0.20):
    try:
        normal = unit(face.normalAt(cq.Vector(*point)))
    except Exception:
        try:
            normal = unit(face.normalAt())
        except Exception:
            normal = None

    if normal is None:
        return True

    start = add3(point, mul3(normal, epsilon))

    for direction in _ray_directions(normal):
        if _ray_escapes_shape(raw_shape, start, direction, max_distance):
            return True

    return False


def face_inaccessible_fraction(face, raw_shape, max_distance, cq, sample_cap=24):
    """Estimate what fraction of a trimmed face is not connected to outside air.

    Tessellation is used instead of Face.Center()/UV-center because the latter
    can lie inside a trimmed hole and caused entire perforated plate faces to be
    incorrectly marked inaccessible when a bolt crossed the center.
    """
    try:
        bb = face.BoundingBox()
        diag = math.sqrt(bb.xlen**2 + bb.ylen**2 + bb.zlen**2)
        tolerance = max(0.2, min(2.0, diag / 60.0 if diag > 0 else 0.5))
        vertices, triangles = face.tessellate(tolerance, 0.15)
    except Exception:
        vertices, triangles = [], []

    samples = []

    for tri in triangles:
        try:
            a = vec_tuple(vertices[tri[0]])
            b = vec_tuple(vertices[tri[1]])
            c = vec_tuple(vertices[tri[2]])
            area = _triangle_area(a, b, c)
            if area <= 1e-8:
                continue
            centroid = (
                (a[0] + b[0] + c[0]) / 3.0,
                (a[1] + b[1] + c[1]) / 3.0,
                (a[2] + b[2] + c[2]) / 3.0,
            )
            samples.append((area, centroid))
        except Exception:
            continue

    if not samples:
        try:
            point = vec_tuple(face.Center())
            return 0.0 if _point_escapes_from_face(face, raw_shape, point, max_distance, cq=cq) else 1.0
        except Exception:
            return 0.0

    # Large triangles carry most of the surface area and provide a stable,
    # inexpensive approximation for curved faces.
    samples.sort(key=lambda x: x[0], reverse=True)
    selected = samples[:sample_cap]

    total_weight = sum(area for area, _ in selected)
    inaccessible_weight = 0.0

    for area, point in selected:
        if not _point_escapes_from_face(face, raw_shape, point, max_distance, cq=cq):
            inaccessible_weight += area

    if total_weight <= 1e-12:
        return 0.0

    return max(0.0, min(1.0, inaccessible_weight / total_weight))


def _contact_graph_has_cycle(contact_pairs, solid_count, actual_tol=0.02):
    parent = list(range(solid_count))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra == rb:
            return False
        parent[rb] = ra
        return True

    for pair in contact_pairs or []:
        if float(pair.get("distanceMm", 999.0)) > actual_tol:
            continue
        a = int(pair.get("a", -1))
        b = int(pair.get("b", -1))
        if a < 0 or b < 0 or a >= solid_count or b >= solid_count:
            continue
        if not union(a, b):
            return True

    return False


def _assembly_bbox_intervals_vary_3d(solids, precision=3):
    """Cheap proof that an assembly actually has layered geometry in X/Y/Z.

    If every solid has exactly the same bounding interval on one axis, the
    assembly is effectively a single slab in that direction and separate
    solids cannot close a 3-D chamber there.  This safely skips expensive ray
    casting for large planar grids/chains without suppressing volumetric
    enclosures such as six-plate boxes.
    """
    intervals = [set(), set(), set()]
    for solid in solids:
        try:
            bb = solid.BoundingBox()
            vals = (
                (float(bb.xmin), float(bb.xmax)),
                (float(bb.ymin), float(bb.ymax)),
                (float(bb.zmin), float(bb.zmax)),
            )
            for axis in range(3):
                intervals[axis].add((round(vals[axis][0], precision), round(vals[axis][1], precision)))
        except Exception:
            return True
    return all(len(axis_intervals) > 1 for axis_intervals in intervals)


def _contact_components_with_cycles(contact_pairs, solid_count, actual_tol=0.02):
    """Return connected solid-index components whose contact graph contains a cycle.

    Surface Engine 4.0 uses these local regions instead of treating the whole
    assembly as one ray-casting problem. Open chains/stars cannot form a sealed
    chamber and are intentionally ignored.
    """
    adjacency = [set() for _ in range(solid_count)]
    edges = set()
    for pair in contact_pairs or []:
        try:
            if float(pair.get("distanceMm", 999.0)) > actual_tol:
                continue
            a = int(pair.get("a", -1))
            b = int(pair.get("b", -1))
        except Exception:
            continue
        if a < 0 or b < 0 or a >= solid_count or b >= solid_count or a == b:
            continue
        edge = (min(a, b), max(a, b))
        if edge in edges:
            continue
        edges.add(edge)
        adjacency[a].add(b)
        adjacency[b].add(a)

    visited = set()
    components = []
    for root in range(solid_count):
        if root in visited or not adjacency[root]:
            continue
        stack = [root]
        nodes = set()
        while stack:
            node = stack.pop()
            if node in nodes:
                continue
            nodes.add(node)
            visited.add(node)
            stack.extend(adjacency[node] - nodes)
        edge_count = sum(1 for a, b in edges if a in nodes and b in nodes)
        # An undirected connected component contains a cycle iff E >= V.
        if len(nodes) >= 3 and edge_count >= len(nodes):
            components.append(sorted(nodes))
    return components


def _analyze_surface_component(component_solids, cq, hard_face_cap):
    # First use the cheap topology/bounding-box proof.  A large planar grid can
    # contain thousands of faces and many graph cycles, but it cannot enclose a
    # 3-D chamber when every solid shares the same interval on one axis.  The
    # prefilter must therefore run *before* the face cap; otherwise harmless
    # planar assemblies are incorrectly reported as a Surface Engine limit.
    if not _assembly_bbox_intervals_vary_3d(component_solids):
        return {"checkedFaces": 0, "inaccessibleSurfaceMm2": 0.0, "limitReached": False}
    total_faces = sum(len(solid.Faces()) for solid in component_solids)
    if total_faces > hard_face_cap:
        return {"checkedFaces": 0, "inaccessibleSurfaceMm2": 0.0, "limitReached": True}

    try:
        compound = cq.Compound.makeCompound(component_solids)
        bb = compound.BoundingBox()
        diagonal = math.sqrt(bb.xlen**2 + bb.ylen**2 + bb.zlen**2)
        max_distance = max(100.0, diagonal * 3.0)
        raw_shape = compound.wrapped
    except Exception:
        return {"checkedFaces": 0, "inaccessibleSurfaceMm2": 0.0, "limitReached": True}

    inaccessible = 0.0
    checked = 0
    for solid in component_solids:
        for face in solid.Faces():
            checked += 1
            try:
                area = abs(float(face.Area()))
            except Exception:
                continue
            if area <= 1e-8:
                continue
            inaccessible_fraction = face_inaccessible_fraction(face, raw_shape, max_distance, cq)
            inaccessible += area * inaccessible_fraction

    return {"checkedFaces": checked, "inaccessibleSurfaceMm2": inaccessible, "limitReached": False}


def analyze_surface_accessibility(
    solids, cq, hidden_mating_surface_mm2, contact_pairs=None, hard_face_cap=1600
):
    """Surface Engine 4.0: analyze only local contact components that can enclose space.

    A large assembly is no longer rejected merely because the *global* face count
    exceeds a cap. Each cyclic 3-D contact component is checked independently.
    Oversized components are flagged, while smaller components are still analyzed.
    This makes large frames/grids much faster and keeps a conservative fallback.
    """
    if len(solids) < 3:
        return {
            "checkedFaces": 0,
            "inaccessibleSurfaceMm2": 0.0,
            "sealedCavitySurfaceMm2": 0.0,
            "limitReached": False,
        }

    components = _contact_components_with_cycles(contact_pairs, len(solids))
    if not components:
        return {
            "checkedFaces": 0,
            "inaccessibleSurfaceMm2": 0.0,
            "sealedCavitySurfaceMm2": 0.0,
            "limitReached": False,
        }

    inaccessible = 0.0
    checked = 0
    limit_reached = False
    analyzed_components = 0
    for indexes in components:
        component_solids = [solids[i] for i in indexes]
        local = _analyze_surface_component(component_solids, cq, hard_face_cap)
        checked += int(local["checkedFaces"])
        inaccessible += float(local["inaccessibleSurfaceMm2"])
        limit_reached = limit_reached or bool(local["limitReached"])
        if local["checkedFaces"] > 0:
            analyzed_components += 1

    # Inaccessible includes mating faces. Subtract the global mating area only once.
    # If some very large component was skipped this may over-subtract, which is a
    # deliberately conservative behaviour: uncertain internal area remains paintable.
    sealed_extra = max(0.0, inaccessible - max(0.0, hidden_mating_surface_mm2))
    return {
        "checkedFaces": checked,
        "inaccessibleSurfaceMm2": inaccessible,
        "sealedCavitySurfaceMm2": sealed_extra,
        "limitReached": limit_reached,
        "analyzedComponents": analyzed_components,
        "candidateComponents": len(components),
    }

def _bbox_overlap_for_faces(face_a, face_b, tol=0.10):
    try:
        a = face_a.BoundingBox()
        b = face_b.BoundingBox()
        return (
            float(a.xmin) <= float(b.xmax) + tol and
            float(b.xmin) <= float(a.xmax) + tol and
            float(a.ymin) <= float(b.ymax) + tol and
            float(b.ymin) <= float(a.ymax) + tol and
            float(a.zmin) <= float(b.zmax) + tol and
            float(b.zmin) <= float(a.zmax) + tol
        )
    except Exception:
        return True


def _wire_length(wire):
    try:
        return sum(abs(float(edge.Length())) for edge in wire.Edges())
    except Exception:
        return 0.0


def _outer_perimeter_of_common(common):
    lengths = []

    try:
        for face in common.Faces():
            for wire in face.Wires():
                value = _wire_length(wire)
                if value > 1e-6:
                    lengths.append(value)
    except Exception:
        pass

    if lengths:
        # For RHS contact this intentionally chooses the outside loop and
        # ignores the inside loop, which is the better weld candidate.
        return max(lengths)

    try:
        edges = list(common.Edges())
        if edges:
            return sum(abs(float(edge.Length())) for edge in edges)
    except Exception:
        pass

    return 0.0



def _parallel_axis_distance(point_a, dir_a, point_b, dir_b):
    da = normalize3(dir_a)
    db = normalize3(dir_b)
    if da is None or db is None:
        return None

    if abs(dot3(da, db)) < 0.995:
        return None

    return length3(cross3(sub3(point_b, point_a), da))


def matching_through_holes(rec_a, rec_b, axis_tol=1.0, diameter_tol=1.5):
    holes_a = rec_a.get("hole_analysis", {}).get("physicalHolesDetailed", []) or []
    holes_b = rec_b.get("hole_analysis", {}).get("physicalHolesDetailed", []) or []

    matches = []
    used_b = set()

    for ha in holes_a:
        if not ha.get("throughLikely"):
            continue

        for index_b, hb in enumerate(holes_b):
            if index_b in used_b or not hb.get("throughLikely"):
                continue

            if abs(float(ha.get("diameterMm", 0)) - float(hb.get("diameterMm", 0))) > diameter_tol:
                continue

            distance = _parallel_axis_distance(
                ha.get("axisPoint"), ha.get("axisDir"),
                hb.get("axisPoint"), hb.get("axisDir"),
            )

            if distance is None or distance > axis_tol:
                continue

            matches.append({
                "diameterMm": min(float(ha.get("diameterMm", 0)), float(hb.get("diameterMm", 0))),
                "axisDistanceMm": distance,
            })
            used_b.add(index_b)
            break

    return matches


def _common_face_planar_dimensions(common):
    try:
        bb = common.BoundingBox()
        values = sorted(
            [abs(float(bb.xlen)), abs(float(bb.ylen)), abs(float(bb.zlen))],
            reverse=True,
        )
        positive = [x for x in values if x > 1e-4]
        if len(positive) >= 2:
            return positive[0], positive[1]
    except Exception:
        pass
    return 0.0, 0.0


def _candidate_seam_length(common, class_a, class_b):
    perimeter = _outer_perimeter_of_common(common)
    major, minor = _common_face_planar_dimensions(common)

    a = (class_a or "").lower()
    b = (class_b or "").lower()
    both_plate = ("blacha" in a or "płyta" in a) and ("blacha" in b or "płyta" in b)

    # Narrow plate-to-plate mating faces are typical butt/T-joint interfaces.
    # Geometry cannot know whether welding is one- or two-sided, therefore use
    # the longest seam as a one-side base instead of the full rectangle perimeter.
    if both_plate and major > 0 and minor > 0 and minor / major <= 0.25:
        return major, "butt/T one-side base"

    return perimeter, "outer contact perimeter"

def _is_structural_stock(name):
    value = (name or "").lower()
    tokens = (
        "blacha", "płyta", "profil", "płaskownik",
        "pręt", "wałek", "rura", "tuleja"
    )
    return any(token in value for token in tokens)


def _joint_type(class_a, class_b):
    a = (class_a or "").lower()
    b = (class_b or "").lower()

    is_plate_a = "blacha" in a or "płyta" in a
    is_plate_b = "blacha" in b or "płyta" in b
    is_long_a = any(x in a for x in ("profil", "płaskownik", "pręt", "wałek", "rura"))
    is_long_b = any(x in b for x in ("profil", "płaskownik", "pręt", "wałek", "rura"))

    if (is_plate_a and is_long_b) or (is_plate_b and is_long_a):
        return "profil-płyta", 74

    if is_plate_a and is_plate_b:
        return "blacha-blacha", 68

    if _is_structural_stock(class_a) and _is_structural_stock(class_b):
        return "styk konstrukcyjny", 64

    return "styk montażowy", 38


def analyze_joint_surfaces(
    solids,
    solid_records,
    contact_pairs,
    total_surface_mm2,
    cq,
    nominal_tol=0.10,
    actual_mating_tol=0.02,
    hard_face_check_cap=40000,
):
    mating_area = 0.0
    weld_length = 0.0
    weld_pairs = 0
    possible_bolted_pairs = 0
    face_checks = 0
    limit_reached = False
    candidates = []

    for contact_index, contact in enumerate(contact_pairs, start=1):
        if contact_index % 100 == 0:
            _progress(78, f"STEP: spoiny/styki powierzchni {contact_index}/{len(contact_pairs)} par")
        distance = float(contact.get("distanceMm", 999.0))
        if distance > nominal_tol:
            continue

        i = int(contact["a"])
        j = int(contact["b"])
        solid_a = solids[i]
        solid_b = solids[j]
        rec_a = solid_records[i]
        rec_b = solid_records[j]

        pair_projected_area = 0.0
        pair_actual_mating_area = 0.0
        pair_weld_length = 0.0
        pair_weld_modes = []
        patch_count = 0

        infos_a = rec_a.get("_planar_face_infos", [])
        infos_b = rec_b.get("_planar_face_infos", [])

        if not infos_a or not infos_b:
            def build_infos(solid):
                result_infos = []
                try:
                    for face in solid.Faces():
                        if face.geomType() != "PLANE":
                            continue
                        try:
                            nrm = unit(face.normalAt())
                            ctr = vec_tuple(face.Center())
                            if nrm is not None:
                                result_infos.append((face, nrm, ctr))
                        except Exception:
                            continue
                except Exception:
                    pass
                return result_infos
            infos_a = build_infos(solid_a)
            infos_b = build_infos(solid_b)

        for face_a, normal_a, center_a in infos_a:
            for face_b, normal_b, center_b in infos_b:
                # Normals and centers are cached per solid; reject orientation first.
                if dot3(normal_a, normal_b) > -0.985:
                    continue

                # Cheap spatial rejection before counting an expensive joint candidate.
                if not _bbox_overlap_for_faces(face_a, face_b, nominal_tol):
                    continue

                face_checks += 1
                if face_checks > hard_face_check_cap:
                    limit_reached = True
                    break

                try:
                    signed_gap = dot3(sub3(center_b, center_a), normal_a)
                    plane_gap = abs(signed_gap)

                    if plane_gap > nominal_tol + 1e-4:
                        continue

                    # Exact mating faces intersect directly. For a small fit-up gap
                    # project the second face onto the first plane. This allows
                    # a weld candidate without pretending the surfaces are hidden
                    # from painting when they are not actually touching.
                    if plane_gap <= actual_mating_tol:
                        common = face_a.intersect(face_b)
                        actual_mating = True
                    else:
                        shift = mul3(normal_a, -signed_gap)
                        moved_b = face_b.translate(cq.Vector(*shift))
                        common = face_a.intersect(moved_b)
                        actual_mating = False

                    area = abs(float(common.Area()))

                    if area <= 0.05:
                        continue

                    candidate_length, weld_mode = _candidate_seam_length(
                        common, rec_a["class"], rec_b["class"]
                    )

                    pair_projected_area += area
                    if actual_mating:
                        pair_actual_mating_area += area
                    pair_weld_length += candidate_length
                    pair_weld_modes.append(weld_mode)
                    patch_count += 1

                except Exception:
                    continue

            if limit_reached:
                break

        # Defensive cap for STEP files that split/duplicate coincident faces.
        max_pair_area = min(
            abs(float(solid_a.Area())),
            abs(float(solid_b.Area())),
        )
        pair_projected_area = min(pair_projected_area, max_pair_area)
        pair_actual_mating_area = min(pair_actual_mating_area, pair_projected_area)

        if pair_projected_area <= 0.05:
            if limit_reached:
                break
            continue

        mating_area += pair_actual_mating_area

        class_a = rec_a["class"]
        class_b = rec_b["class"]
        joint_type, confidence = _joint_type(class_a, class_b)
        structural = (
            _is_structural_stock(class_a) and
            _is_structural_stock(class_b) and
            pair_weld_length >= 5.0
        )

        matching_holes = matching_through_holes(rec_a, rec_b)
        possible_bolted = len(matching_holes) > 0 and pair_projected_area >= 50.0

        # A coaxial through-hole pattern is a strong fastening signal. Geometry
        # alone should then NOT infer welding. Explicit WELD info in PDF/DXF can
        # still enable welding in CostEngine.
        if possible_bolted:
            structural = False
            possible_bolted_pairs += 1

        candidate_length = pair_weld_length if structural else 0.0

        if structural:
            weld_pairs += 1
            weld_length += candidate_length

        candidates.append({
            "bodyA": i + 1,
            "bodyB": j + 1,
            "type": joint_type,
            "distanceMm": distance,
            "contactAreaMm2": pair_actual_mating_area,
            "projectedJointAreaMm2": pair_projected_area,
            "candidateWeldLengthMm": candidate_length,
            "confidence": (
                30 if possible_bolted
                else confidence if structural
                else min(confidence, 45)
            ),
            "structuralCandidate": structural,
            "possibleBoltedJoint": possible_bolted,
            "matchingThroughHoles": len(matching_holes),
            "weldLengthBasis": ", ".join(sorted(set(pair_weld_modes))),
            "patchCount": patch_count,
            "basis": (
                f"{class_a} + {class_b}; rzeczywiste doleganie "
                f"{pair_actual_mating_area:.1f} mm2; obszar po projekcji "
                f"{pair_projected_area:.1f} mm2; baza długości {pair_weld_length:.1f} mm"
                + (f"; zgodne otwory przelotowe: {len(matching_holes)} -> możliwe połączenie śrubowe." if possible_bolted else ".")
            ),
        })

        if limit_reached:
            break

    # Every shared mating patch occurs once in pair_area, but exists as a
    # non-paintable surface on BOTH parts.
    hidden_surface = min(
        max(0.0, total_surface_mm2),
        max(0.0, mating_area * 2.0),
    )
    exposed_surface = max(0.0, total_surface_mm2 - hidden_surface)

    internal_excluded = sum(
        max(0.0, float(rec.get("internal_paint_area", 0.0)))
        for rec in solid_records
    )
    internal_excluded = min(internal_excluded, exposed_surface)
    paintable_surface = max(0.0, exposed_surface - internal_excluded)

    return {
        "planarMatingAreaMm2": mating_area,
        "hiddenMatingSurfaceMm2": hidden_surface,
        "exposedSurfaceMm2": exposed_surface,
        "internalPaintExcludedMm2": internal_excluded,
        "paintableSurfaceMm2": paintable_surface,
        "weldCandidatePairs": weld_pairs,
        "weldCandidateLengthMm": weld_length,
        "possibleBoltedJointPairs": possible_bolted_pairs,
        "jointCandidates": candidates,
        "faceChecks": face_checks,
        "limitReached": limit_reached,
    }

def boxes_may_touch(a, b, tol):
    ax, ay, az, arx, ary, arz = a
    bx, by, bz, brx, bry, brz = b

    return (
        abs(ax - bx) <= arx + brx + tol and
        abs(ay - by) <= ary + bry + tol and
        abs(az - bz) <= arz + brz + tol
    )


def analyze_contacts(solids, centers_and_half_extents, tol=0.25, nominal_tol=0.10, tight_tol=0.05, hard_pair_cap=60000):
    # Sweep-and-prune on X. This avoids the full O(n^2) exact-distance loop
    # for sparse assemblies while preserving the same geometric criterion.
    intervals = []
    for idx, item in enumerate(centers_and_half_extents):
        cx, cy, cz, hx, hy, hz = item
        intervals.append((cx - hx, cx + hx, idx))
    intervals.sort(key=lambda x: x[0])

    contacts = 0
    tight_contacts = 0
    nominal_contacts = 0
    candidates = 0
    exact_checks = 0
    limit_reached = False
    contact_pair_details = []

    n = len(intervals)
    for pos in range(n):
        xmin_i, xmax_i, i = intervals[pos]
        jpos = pos + 1

        while jpos < n:
            xmin_j, xmax_j, j = intervals[jpos]
            if xmin_j > xmax_i + tol:
                break

            if boxes_may_touch(
                centers_and_half_extents[i],
                centers_and_half_extents[j],
                tol
            ):
                candidates += 1
                exact_checks += 1
                if exact_checks % 1500 == 0:
                    _progress(66, f"STEP: styki {exact_checks}/{hard_pair_cap} dokładnych sprawdzeń")

                if exact_checks > hard_pair_cap:
                    limit_reached = True
                    return {
                        "contactPairs": contacts,
                        "tightContactPairs": tight_contacts,
                        "nominalContactPairs": nominal_contacts,
                        "candidatePairs": candidates,
                        "exactChecks": exact_checks - 1,
                        "limitReached": limit_reached,
                        "pairs": contact_pair_details,
                    }

                try:
                    distance = float(solids[i].distance(solids[j]))
                    if distance <= tol:
                        contacts += 1
                        contact_pair_details.append({
                            "a": i,
                            "b": j,
                            "distanceMm": distance,
                        })
                    if distance <= nominal_tol:
                        nominal_contacts += 1
                    if distance <= tight_tol:
                        tight_contacts += 1
                except Exception:
                    pass

            jpos += 1

    return {
        "contactPairs": contacts,
        "tightContactPairs": tight_contacts,
        "nominalContactPairs": nominal_contacts,
        "candidatePairs": candidates,
        "exactChecks": exact_checks,
        "limitReached": limit_reached,
        "pairs": contact_pair_details,
    }



def load_step_solids(path, cq):
    warnings = []
    shape = None
    solids = []

    # Large multi-body STEP files can become pathologically slow in
    # CadQuery importStep()/Workplane.solids() because the high-level wrapper
    # rebuilds a large object graph.  For large files use the underlying OCP
    # STEP reader first and cast only SOLID objects back to CadQuery Shapes.
    # Small/normal files keep the existing CadQuery-first path for maximum
    # compatibility with ordinary supplier STEP exports.
    try:
        large_step_threshold = int(os.environ.get("DSE_LARGE_STEP_OCP_BYTES", str(4 * 1024 * 1024)))
    except Exception:
        large_step_threshold = 4 * 1024 * 1024
    prefer_ocp_large = os.environ.get("DSE_FORCE_OCP_STEP", "") == "1" or path.stat().st_size >= large_step_threshold

    if prefer_ocp_large:
        try:
            from OCP.STEPControl import STEPControl_Reader
            from OCP.IFSelect import IFSelect_RetDone
            from OCP.TopExp import TopExp_Explorer
            from OCP.TopAbs import TopAbs_SOLID

            reader = STEPControl_Reader()
            status = reader.ReadFile(str(path))
            if status == IFSelect_RetDone and int(reader.TransferRoots()) > 0:
                raw_shape = reader.OneShape()
                explorer = TopExp_Explorer(raw_shape, TopAbs_SOLID)
                solids = []
                while explorer.More():
                    try:
                        solids.append(cq.Shape.cast(explorer.Current()))
                    except Exception as exc:
                        warnings.append(f"OCP large STEP cast SOLID: {type(exc).__name__}: {exc}")
                    explorer.Next()
                if solids:
                    try:
                        shape = cq.Shape.cast(raw_shape)
                    except Exception:
                        shape = None
                    warnings.append(
                        f"Duży STEP: użyto szybkiego importu OCP ({len(solids)} brył, "
                        f"plik {path.stat().st_size / (1024*1024):0.1f} MB)."
                    )
                    return shape, solids, "OCP-large", warnings
            warnings.append("Szybki import OCP dużego STEP nie zwrócił brył; próba CadQuery.")
        except Exception as exc:
            warnings.append(f"Szybki import OCP dużego STEP: {type(exc).__name__}: {exc}; próba CadQuery.")

    # 1) Standard CadQuery importer.
    try:
        wp = cq.importers.importStep(str(path))
        # IMPORTANT: importStep() may return several top-level objects.
        # wp.val() returns only the first object, so using shape.Solids() first
        # silently dropped the remaining solids in legitimate multi-body STEP
        # files (e.g. FreeCAD 623ZZ bearing: 3 solids -> previously 1).
        # Always collect solids from the whole Workplane/import result first.
        try:
            solids = list(wp.solids().vals())
        except Exception:
            solids = []

        try:
            shape = wp.val()
        except Exception:
            shape = None

        if not solids and shape is not None:
            try:
                solids = list(shape.Solids())
            except Exception:
                solids = []

        if solids:
            if len(solids) > 1:
                warnings.append(
                    f"STEP: CadQuery zwrócił {len(solids)} brył z całego wyniku importu; "
                    "uwzględniono wszystkie obiekty, nie tylko pierwszy."
                )
            return shape, solids, "CadQuery", warnings

        warnings.append(
            "CadQuery otworzył STEP, ale nie zwrócił brył SOLID; "
            "uruchamiam fallback OpenCascade/OCP."
        )
    except Exception as exc:
        warnings.append(
            f"CadQuery importStep: {type(exc).__name__}: {exc}; "
            "uruchamiam fallback OpenCascade/OCP."
        )

    # 2) Direct OpenCascade STEPControl fallback.
    # CadQuery already ships the OCP bindings, so no new dependency is needed.
    try:
        from OCP.STEPControl import STEPControl_Reader
        from OCP.IFSelect import IFSelect_RetDone
        from OCP.TopExp import TopExp_Explorer
        from OCP.TopAbs import TopAbs_SOLID

        reader = STEPControl_Reader()
        status = reader.ReadFile(str(path))

        if status != IFSelect_RetDone:
            warnings.append(
                f"OCP STEPControl_Reader.ReadFile status: {status}"
            )
            return None, [], "OCP", warnings

        transferred = int(reader.TransferRoots())

        if transferred <= 0:
            warnings.append(
                "OCP STEPControl_Reader nie przeniósł żadnych rootów."
            )
            return None, [], "OCP", warnings

        raw_shape = reader.OneShape()

        explorer = TopExp_Explorer(raw_shape, TopAbs_SOLID)
        solids = []

        while explorer.More():
            try:
                solids.append(cq.Shape.cast(explorer.Current()))
            except Exception as exc:
                warnings.append(
                    f"OCP cast SOLID: {type(exc).__name__}: {exc}"
                )
            explorer.Next()

        if not solids:
            warnings.append(
                "OCP otworzył STEP, ale nie znalazł żadnych TopAbs_SOLID."
            )
            return None, [], "OCP", warnings

        try:
            shape = cq.Shape.cast(raw_shape)
        except Exception:
            shape = None

        warnings.append(
            f"STEP zaimportowany fallbackiem OCP: {len(solids)} brył."
        )

        return shape, solids, "OCP", warnings

    except Exception as exc:
        warnings.append(
            f"OCP STEPControl fallback: {type(exc).__name__}: {exc}"
        )
        return None, [], "OCP", warnings


def solids_union_bbox(solids):
    mins = [float("inf"), float("inf"), float("inf")]
    maxs = [float("-inf"), float("-inf"), float("-inf")]

    for solid in solids:
        bb = solid.BoundingBox()

        mins[0] = min(mins[0], float(bb.xmin))
        mins[1] = min(mins[1], float(bb.ymin))
        mins[2] = min(mins[2], float(bb.zmin))

        maxs[0] = max(maxs[0], float(bb.xmax))
        maxs[1] = max(maxs[1], float(bb.ymax))
        maxs[2] = max(maxs[2], float(bb.zmax))

    return (
        max(0.0, maxs[0] - mins[0]),
        max(0.0, maxs[1] - mins[1]),
        max(0.0, maxs[2] - mins[2]),
    )

def main():
    result = empty_result()

    if len(sys.argv) != 2:
        result["warnings"].append("Brak ścieżki do pliku STEP.")
        print(json.dumps(result, ensure_ascii=True))
        return 0

    path = Path(sys.argv[1])

    try:
        import cadquery as cq
    except Exception as exc:
        result["warnings"].append(f"CadQuery niedostępny: {exc}")
        print(json.dumps(result, ensure_ascii=True))
        return 0

    try:
        _progress(3, "STEP: wczytywanie modelu")
        shape, solids, importer_name, import_warnings = load_step_solids(path, cq)
        result["warnings"].extend(import_warnings)

        if not solids:
            result["warnings"].append(
                "STEP nie zawiera rozpoznawalnych brył zamkniętych "
                "ani przez CadQuery, ani przez fallback OCP."
            )
            print(json.dumps(result, ensure_ascii=True))
            return 0

        result["available"] = True
        result["solidCount"] = len(solids)
        result["importer"] = importer_name

        bbox_x, bbox_y, bbox_z = solids_union_bbox(solids)
        result["boundingXmm"] = bbox_x
        result["boundingYmm"] = bbox_y
        result["boundingZmm"] = bbox_z
        _progress(12, f"STEP: zaimportowano {len(solids)} brył")

        # R9.0.7 assembly performance: split cheap topology scan from expensive
        # manufacturing-feature analysis. Repeated component instances are common in
        # real assemblies; analyzing holes/bevels/internal surfaces for every instance
        # was the main source of 10-20+ minute runtimes.
        groups = defaultdict(list)
        centers = []
        solid_records = []
        quick_groups = defaultdict(list)

        for solid_index, solid in enumerate(solids):
            bb = solid.BoundingBox()
            center = solid.CenterOfBoundBox()
            cx, cy, cz = vec_tuple(center)

            centers.append((
                cx, cy, cz,
                float(bb.xlen) / 2.0,
                float(bb.ylen) / 2.0,
                float(bb.zlen) / 2.0,
            ))

            dims = (float(bb.xlen), float(bb.ylen), float(bb.zlen))
            raw_volume = float(solid.Volume())
            volume = abs(raw_volume)
            if raw_volume < -1e-9:
                result["warnings"].append(
                    "Bryła miała ujemną orientowaną objętość; do masy/kosztu użyto wartości bezwzględnej."
                )

            area = abs(float(solid.Area()))
            faces = list(solid.Faces())
            edges = list(solid.Edges())
            face_types = [face.geomType() for face in faces]
            cyl_count = sum(1 for t in face_types if t == "CYLINDER")
            cone_count = sum(1 for t in face_types if t == "CONE")
            plane_count = sum(1 for t in face_types if t == "PLANE")

            # Stable, rotation-independent quick key. Face-area signature prevents
            # different parts with identical bbox/volume from being merged merely to
            # gain speed. Expensive hole detection is intentionally NOT part of it.
            face_area_sig = tuple(sorted(
                (face.geomType(), round(abs(float(face.Area())), 1))
                for face in faces
            ))
            quick_key = (
                tuple(sorted(round(v, 1) for v in dims)),
                round(volume, 1), round(area, 1), len(faces), len(edges),
                cyl_count, cone_count, plane_count, face_area_sig,
            )
            # Stable pre-feature key used only for progressive checkpoint resume.
            # It intentionally excludes detected holes, so a partially analysed group
            # can be matched before hole analysis starts on the next run.
            resume_key = hashlib.sha256(repr(quick_key).encode("utf-8")).hexdigest()[:24]

            record = {
                "solid_index": solid_index,
                "solid": solid,
                "dims": dims,
                "volume": volume,
                "area": area,
                "face_count": len(faces),
                "edge_count": len(edges),
                "cyl_count": cyl_count,
                "cone_count": cone_count,
                "plane_count": plane_count,
                "resume_key": resume_key,
                "_planar_face_infos": [],
            }
            solid_records.append(record)
            quick_groups[quick_key].append(record)

        _progress(22, f"STEP: grupowanie {len(solids)} → {len(quick_groups)} unikalnych geometrii")

        # R9.2.3C REAL DATA HARDENING: persist a usable geometry checkpoint from
        # the SAME STEP import before expensive feature/contact analysis.  This is
        # intentionally not a second pre-scan process: real supplier STEP files can
        # spend most of their time in STEP transfer itself.  If the watchdog later
        # stops enrichment, the application can still recover solids/groups/bbox,
        # volume and surface without re-importing the model.
        checkpoint_path = os.environ.get("DSE_STEP_CHECKPOINT_PATH", "").strip()
        checkpoint_seed = None
        checkpoint_parts_template = []
        # FIX10K / B2: preserve a previous feature checkpoint before replacing the
        # topology seed.  The file is version/content keyed by the host, so it is safe
        # to resume only when solid/group counts still match this fresh import.
        resume_checkpoint_data = None
        if checkpoint_path and os.environ.get("DSE_STEP_RESUME", "") == "1":
            try:
                cp_existing = Path(checkpoint_path)
                if cp_existing.exists():
                    candidate = json.loads(cp_existing.read_text(encoding="utf-8"))
                    if str(candidate.get("analysisMode", "")).startswith("checkpoint") and int(candidate.get("fullyAnalyzedUniqueSolids", 0) or 0) > 0:
                        resume_checkpoint_data = candidate
            except Exception as exc:
                result["warnings"].append(f"STEP resume checkpoint read: {type(exc).__name__}: {exc}")

        if checkpoint_path:
            try:
                checkpoint_parts = []
                total_volume = 0.0
                total_area = 0.0
                for idx, quick_items in enumerate(quick_groups.values(), start=1):
                    item = quick_items[0]
                    qty = len(quick_items)
                    total_volume += item["volume"] * qty
                    total_area += item["area"] * qty
                    x, y, z = item["dims"]
                    checkpoint_parts.append({
                        "groupKey": f"CHK-{idx:04d}",
                        "resumeKey": item.get("resume_key", ""),
                        "featureAnalyzed": False,
                        "name": f"Checkpoint {idx:03d}",
                        "sourceFile": path.name,
                        "classification": "Checkpoint",
                        "quantity": qty,
                        "xmm": x, "ymm": y, "zmm": z,
                        "volumeMm3Each": item["volume"],
                        "surfaceMm2Each": item["area"],
                        "faceCount": item["face_count"],
                        "edgeCount": item["edge_count"],
                        "cylindricalFaceCount": item["cyl_count"],
                        "conicalFaceCount": item["cone_count"],
                        "planarFaceCount": item["plane_count"],
                        "holes": [],
                        "massKgEach": 0.0,
                    })
                checkpoint = dict(result)
                checkpoint["available"] = True
                checkpoint["analysisMode"] = "checkpoint"
                checkpoint["parts"] = checkpoint_parts
                checkpoint["uniquePartGroups"] = len(checkpoint_parts)
                checkpoint["volumeMm3"] = total_volume
                checkpoint["surfaceMm2"] = total_area
                checkpoint["paintableSurfaceMm2"] = total_area
                checkpoint["exposedSurfaceMm2"] = total_area
                checkpoint["fullyAnalyzedUniqueSolids"] = 0
                checkpoint["holeAnalysisState"] = "unknown"
                checkpoint["reusedSolidAnalyses"] = 0
                checkpoint.setdefault("warnings", []).append(
                    "STEP checkpoint R9.2.3C: zapisano podstawową geometrię przed analizą cech/styków."
                )
                checkpoint_seed = checkpoint
                checkpoint_parts_template = [dict(part) for part in checkpoint_parts]
                cp = Path(checkpoint_path)
                cp.parent.mkdir(parents=True, exist_ok=True)
                tmp = cp.with_suffix(cp.suffix + ".tmp")
                tmp.write_text(json.dumps(checkpoint, ensure_ascii=True), encoding="utf-8")
                os.replace(tmp, cp)
                _progress(24, f"STEP: checkpoint zapisany ({len(solids)} brył / {len(quick_groups)} grup)")
            except Exception as exc:
                result["warnings"].append(f"STEP checkpoint write: {type(exc).__name__}: {exc}")

        # Lightweight cross-file pre-scan used by the application to identify the
        # dominant assembly before doing expensive feature/joint analysis.
        if os.environ.get("DSE_STEP_PRESCAN", "") == "1":
            prescan_parts = []
            total_volume = 0.0
            total_area = 0.0
            for idx, quick_items in enumerate(quick_groups.values(), start=1):
                item = quick_items[0]
                qty = len(quick_items)
                total_volume += item["volume"] * qty
                total_area += item["area"] * qty
                x, y, z = item["dims"]
                prescan_parts.append({
                    "groupKey": f"PRE-{idx:04d}",
                    "resumeKey": item.get("resume_key", ""),
                    "featureAnalyzed": False,
                    "name": f"Pre-scan {idx:03d}",
                    "sourceFile": path.name,
                    "classification": "Pre-scan",
                    "quantity": qty,
                    "xmm": x, "ymm": y, "zmm": z,
                    "volumeMm3Each": item["volume"],
                    "surfaceMm2Each": item["area"],
                    "faceCount": item["face_count"],
                    "edgeCount": item["edge_count"],
                    "cylindricalFaceCount": item["cyl_count"],
                    "conicalFaceCount": item["cone_count"],
                    "planarFaceCount": item["plane_count"],
                    "holes": [],
                    "massKgEach": 0.0,
                })
            result["analysisMode"] = "prescan"
            result["parts"] = prescan_parts
            result["uniquePartGroups"] = len(prescan_parts)
            result["volumeMm3"] = total_volume
            result["surfaceMm2"] = total_area
            result["paintableSurfaceMm2"] = total_area
            result["exposedSurfaceMm2"] = total_area
            result["fullyAnalyzedUniqueSolids"] = 0
            result["reusedSolidAnalyses"] = 0
            print(json.dumps(result, ensure_ascii=True))
            return 0

        # R9.2.0: independent unique-part feature analysis can use a small thread pool.
        # OCP/CadQuery shapes remain in-process (no expensive BREP re-serialization), while
        # the worker cap stays deliberately low to protect memory and native-kernel stability.
        unique_items = list(quick_groups.values())
        requested_workers = max(1, min(2, int(os.environ.get("DSE_STEP_WORKERS", "1") or "1")))
        # Benchmarks on CadQuery/OCP show that two workers help only when the unique-part
        # feature workload is genuinely heavy. Many simple boxes are faster sequentially,
        # because native-kernel scheduling overhead can exceed the useful work.
        feature_work = sum(
            max(1, items[0]["face_count"])
            + 3 * items[0]["cyl_count"]
            + 2 * items[0]["cone_count"]
            for items in unique_items
        )
        workers = requested_workers if len(unique_items) >= 64 and feature_work >= 1200 else 1

        resumed_unique = []
        if resume_checkpoint_data is not None:
            try:
                saved_parts = list(resume_checkpoint_data.get("parts") or [])
                saved_count = int(resume_checkpoint_data.get("fullyAnalyzedUniqueSolids", 0) or 0)
                compatible = (
                    int(resume_checkpoint_data.get("solidCount", 0) or 0) == len(solids)
                    and int(resume_checkpoint_data.get("uniquePartGroups", 0) or 0) == len(unique_items)
                    and len(saved_parts) == len(unique_items)
                    and 0 < saved_count <= len(unique_items)
                )
                if compatible:
                    # Parallel feature analysis completes groups out of order, so
                    # "first N parts" is not a safe resume rule. Match only groups
                    # explicitly marked featureAnalyzed using a stable pre-feature key.
                    saved_by_resume_key = {
                        str(part.get("resumeKey") or ""): part
                        for part in saved_parts
                        if part.get("featureAnalyzed") is True and str(part.get("resumeKey") or "")
                    }
                    for idx, quick_items in enumerate(unique_items):
                        resume_key = str(quick_items[0].get("resume_key") or "")
                        base = saved_by_resume_key.get(resume_key)
                        if base is None:
                            continue
                        holes = list(base.get("holes") or [])
                        physical_count = sum(max(1, int(h.get("count", 1) or 1)) for h in holes)
                        hole_analysis = {
                            "holes": holes,
                            "physicalCount": physical_count,
                            "manufacturingHoleCount": int(base.get("manufacturingHoleCount", physical_count) or 0),
                            "holeCandidateCount": int(base.get("holeCandidateCount", physical_count) or 0),
                            "rejectedHoleCandidates": int(base.get("rejectedHoleCandidates", 0) or 0),
                            "internalCylindricalFaces": int(base.get("internalCylindricalFaceCount", 0) or 0),
                            "externalCylindricalFaces": int(base.get("externalCylindricalFaceCount", 0) or 0),
                            "uncertainCylindricalFaces": int(base.get("uncertainCylindricalFaceCount", 0) or 0),
                            "physicalHolesDetailed": list(base.get("physicalHolesDetailed") or []),
                            "fallbackHoleCount": int(base.get("holeFallbackCount", 0) or 0),
                        }
                        bevel = base.get("bevel") or {"count": 0, "minAngleDeg": 0.0, "maxAngleDeg": 0.0}
                        expensive = {
                            "holes": holes,
                            "hole_analysis": hole_analysis,
                            "bevel": bevel,
                            "pockets": base.get("pockets") or {"count": int(base.get("pocketCandidateCount", 0) or 0), "areaMm2": float(base.get("pocketCandidateAreaMm2", 0.0) or 0.0), "maxDepthMm": float(base.get("pocketMaxDepthMm", 0.0) or 0.0), "candidates": []},
                            "class": str(base.get("classification") or "Detal"),
                            "class_confidence": int(base.get("classificationConfidence", 0) or 0),
                            "class_basis": str(base.get("classificationBasis") or "Wznowiono z checkpointu."),
                            "internal_planar_count": int(base.get("internalPlanarFaceCount", 0) or 0),
                            "internal_planar_area": 0.0,
                            "internal_paint_area": float(base.get("internalPaintExcludedMm2Each", 0.0) or 0.0),
                            "group_fp": str(base.get("groupKey") or f"RESUME-{idx:04d}"),
                        }
                        resumed_unique.append((idx, quick_items, expensive))
                    if resumed_unique:
                        result["warnings"].append(
                            f"STEP resume 1.1: wznowiono {len(resumed_unique)}/{len(unique_items)} unikalnych grup po resumeKey; nie liczono ich cech ponownie."
                        )
                        _progress(24, f"STEP: resume {len(resumed_unique)}/{len(unique_items)} grup")
                    else:
                        result["warnings"].append("STEP resume 1.1: checkpoint nie zawiera zgodnych ukończonych grup; rozpoczęto cechy od zera.")
                else:
                    result["warnings"].append("STEP resume 1.1: checkpoint nie pasuje do świeżo zaimportowanej geometrii; rozpoczęto cechy od zera.")
            except Exception as exc:
                result["warnings"].append(f"STEP resume 1.1: {type(exc).__name__}: {exc}")
                resumed_unique = []

        def analyze_unique(index, quick_items):
            rep = quick_items[0]
            solid = rep["solid"]
            dims = rep["dims"]
            volume = rep["volume"]
            area = rep["area"]
            bbox_volume = max(dims[0] * dims[1] * dims[2], 1e-9)

            hole_analysis = detect_holes_v2(solid, cq)
            holes = hole_analysis["holes"]
            bevel = detect_bevels(solid)
            internal_planar_count, internal_planar_area = planar_internal_metrics(solid)
            stock_class, stock_confidence, stock_basis = classify_stock(
                dims, volume, bbox_volume, rep["cyl_count"],
                hole_analysis["physicalCount"], internal_planar_count,
            )
            internal_paint_area = confident_internal_paint_area(solid, stock_class)
            pockets = detect_pocket_candidates(solid)
            if stock_class in {"Rura / tuleja", "Profil zamknięty / RHS-SHS"}:
                pockets = {"count": 0, "areaMm2": 0.0, "maxDepthMm": 0.0, "candidates": []}

            fp = fingerprint(
                dims, volume, area, rep["face_count"],
                hole_analysis["physicalCount"], rep["cone_count"]
            )
            expensive = {
                "holes": holes,
                "hole_analysis": hole_analysis,
                "bevel": bevel,
                "pockets": pockets,
                "class": stock_class,
                "class_confidence": stock_confidence,
                "class_basis": stock_basis,
                "internal_planar_count": internal_planar_count,
                "internal_planar_area": internal_planar_area,
                "internal_paint_area": internal_paint_area,
                "group_fp": fp,
            }
            return index, quick_items, expensive

        # FIX10J: progressively enrich the live checkpoint while unique-part feature
        # analysis is running. Real-world assemblies may hit the external watchdog
        # after several minutes; previously that discarded every hole/bevel/classification
        # already computed because only the initial 0%-feature checkpoint existed.
        # Atomic snapshots every ~5% retain completed work without materially slowing
        # the normal path. Contact/joint/surface analysis still remains a later stage.
        checkpoint_refresh_every = max(4, len(unique_items) // 20) if unique_items else 4

        def refresh_feature_checkpoint(partial_results, force=False):
            if not checkpoint_path or checkpoint_seed is None or not checkpoint_parts_template:
                return
            if not partial_results:
                return
            if not force and len(partial_results) % checkpoint_refresh_every != 0:
                return
            try:
                by_index = {entry[0]: entry[2] for entry in partial_results}
                snapshot = dict(checkpoint_seed)
                snapshot["warnings"] = list(checkpoint_seed.get("warnings", []))
                snapshot_parts = []
                total_holes_partial = 0
                total_bevels_partial = 0
                total_pockets_partial = 0
                reused_partial = 0
                for idx, quick_items in enumerate(unique_items):
                    base = dict(checkpoint_parts_template[idx])
                    expensive = by_index.get(idx)
                    if expensive is not None:
                        rep = quick_items[0]
                        qty = len(quick_items)
                        base.update({
                            "groupKey": expensive["group_fp"],
                            "resumeKey": rep.get("resume_key", base.get("resumeKey", "")),
                            "featureAnalyzed": True,
                            "name": f"Detal {idx + 1:03d}",
                            "classification": expensive["class"],
                            "classificationConfidence": expensive["class_confidence"],
                            "classificationBasis": expensive["class_basis"],
                            "internalCylindricalFaceCount": expensive["hole_analysis"]["internalCylindricalFaces"],
                            "holeCandidateCount": expensive["hole_analysis"].get("holeCandidateCount", 0),
                            "rejectedHoleCandidates": expensive["hole_analysis"].get("rejectedHoleCandidates", 0),
                            "manufacturingHoleCount": expensive["hole_analysis"].get("manufacturingHoleCount", expensive["hole_analysis"]["physicalCount"]),
                            "physicalHolesDetailed": expensive["hole_analysis"].get("physicalHolesDetailed", []),
                            "holeFallbackCount": expensive["hole_analysis"].get("fallbackHoleCount", 0),
                            "externalCylindricalFaceCount": expensive["hole_analysis"]["externalCylindricalFaces"],
                            "uncertainCylindricalFaceCount": expensive["hole_analysis"]["uncertainCylindricalFaces"],
                            "internalPlanarFaceCount": expensive["internal_planar_count"],
                            "internalPaintExcludedMm2Each": expensive["internal_paint_area"],
                            "bevel": expensive["bevel"],
                            "pocketCandidateCount": expensive["pockets"]["count"],
                            "pocketCandidateAreaMm2": expensive["pockets"]["areaMm2"],
                            "pocketMaxDepthMm": expensive["pockets"]["maxDepthMm"],
                            "pocketCandidates": expensive["pockets"]["candidates"],
                            "holes": expensive["holes"],
                        })
                        total_holes_partial += sum(h["count"] for h in expensive["holes"]) * qty
                        total_bevels_partial += expensive["bevel"]["count"] * qty
                        total_pockets_partial += expensive["pockets"]["count"] * qty
                        reused_partial += max(0, qty - 1)
                    snapshot_parts.append(base)
                snapshot["analysisMode"] = "checkpoint-features"
                snapshot["parts"] = snapshot_parts
                snapshot["fullyAnalyzedUniqueSolids"] = len(by_index)
                snapshot["holeAnalysisState"] = "complete" if len(by_index) >= len(unique_items) else "partial"
                snapshot["reusedSolidAnalyses"] = reused_partial
                snapshot["totalHoleCount"] = total_holes_partial
                snapshot["totalBevelFaces"] = total_bevels_partial
                snapshot["totalPocketCandidateCount"] = total_pockets_partial
                snapshot["warnings"].append(
                    f"STEP checkpoint DS 1.1: zachowano częściową analizę cech {len(by_index)}/{len(unique_items)} unikalnych grup przed analizą styków/spoin/powierzchni."
                )
                cp = Path(checkpoint_path)
                tmp = cp.with_suffix(cp.suffix + ".tmp")
                tmp.write_text(json.dumps(snapshot, ensure_ascii=True), encoding="utf-8")
                os.replace(tmp, cp)
            except Exception as exc:
                result["warnings"].append(f"STEP feature checkpoint write: {type(exc).__name__}: {exc}")

        analyzed_unique = list(resumed_unique)
        resumed_indices = {entry[0] for entry in resumed_unique}
        pending_unique = [(i, items) for i, items in enumerate(unique_items) if i not in resumed_indices]
        if workers > 1 and pending_unique:
            result["warnings"].append(
                f"Parallel STEP Engine: analiza cech {len(pending_unique)} pozostałych z {len(unique_items)} unikalnych geometrii używa {workers} workerów."
            )
            try:
                with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="dse-step") as pool:
                    futures = [pool.submit(analyze_unique, i, items) for i, items in pending_unique]
                    done = len(analyzed_unique)
                    for future in as_completed(futures):
                        analyzed_unique.append(future.result())
                        done += 1
                        refresh_feature_checkpoint(analyzed_unique, force=(done == len(unique_items)))
                        _progress(22 + 38 * done / max(1, len(unique_items)),
                                  f"STEP: cechy detali {done}/{len(unique_items)} ({workers} workery)")
                analyzed_unique.sort(key=lambda x: x[0])
                pending_unique = []
            except Exception as exc:
                result["warnings"].append(
                    f"Parallel STEP Engine fallback: {type(exc).__name__}: {exc}; dokończono pozostałe grupy sekwencyjnie."
                )
                # Keep resumed/completed unique groups and only fill missing indices.
                completed = {entry[0] for entry in analyzed_unique}
                pending_unique = [(i, items) for i, items in enumerate(unique_items) if i not in completed]

        if pending_unique:
            for i, items in pending_unique:
                analyzed_unique.append(analyze_unique(i, items))
                analyzed_unique.sort(key=lambda x: x[0])
                refresh_feature_checkpoint(analyzed_unique, force=(len(analyzed_unique) == len(unique_items)))
                _progress(22 + 38 * len(analyzed_unique) / max(1, len(unique_items)),
                          f"STEP: cechy detali {len(analyzed_unique)}/{len(unique_items)}")

        # Ensure a 100%-feature checkpoint exists before contact/joint/surface stages.
        # If those later stages hit the watchdog, holes/bevels/stock classification are
        # still preserved instead of falling all the way back to the topology-only seed.
        refresh_feature_checkpoint(analyzed_unique, force=True)

        for _, quick_items, expensive in analyzed_unique:
            fp = expensive["group_fp"]
            for record in quick_items:
                record.update(expensive)
                groups[fp].append(record)

        result["fullyAnalyzedUniqueSolids"] = len(quick_groups)
        result["reusedSolidAnalyses"] = max(0, len(solids) - len(quick_groups))
        if len(solids) - len(quick_groups) > 0:
            result["warnings"].append(
                f"Assembly Performance: pełną analizę cech wykonano dla {len(quick_groups)} "
                f"unikalnych geometrii zamiast {len(solids)} instancji; "
                f"ponownie użyto {len(solids) - len(quick_groups)} wyników."
            )

        parts = []
        total_volume = 0.0
        total_area = 0.0
        total_holes = 0
        total_hole_fallbacks = 0
        total_bevels = 0
        total_pockets = 0

        for idx, (fp, items) in enumerate(groups.items(), start=1):
            item = items[0]
            quantity = len(items)

            total_volume += item["volume"] * quantity
            total_area += item["area"] * quantity
            total_holes += sum(h["count"] for h in item["holes"]) * quantity
            total_hole_fallbacks += int(item["hole_analysis"].get("fallbackHoleCount", 0) or 0) * quantity
            total_bevels += item["bevel"]["count"] * quantity
            total_pockets += item["pockets"]["count"] * quantity

            x, y, z = item["dims"]

            parts.append({
                "groupKey": fp,
                "resumeKey": item.get("resume_key", ""),
                "featureAnalyzed": True,
                "name": f"Detal {idx:03d}",
                "sourceFile": path.name,
                "classification": item["class"],
                "classificationConfidence": item["class_confidence"],
                "classificationBasis": item["class_basis"],
                "quantity": quantity,
                "xmm": x,
                "ymm": y,
                "zmm": z,
                "volumeMm3Each": item["volume"],
                "surfaceMm2Each": item["area"],
                "faceCount": item["face_count"],
                "edgeCount": item["edge_count"],
                "cylindricalFaceCount": item["cyl_count"],
                "internalCylindricalFaceCount": item["hole_analysis"]["internalCylindricalFaces"],
                "holeCandidateCount": item["hole_analysis"].get("holeCandidateCount", 0),
                "rejectedHoleCandidates": item["hole_analysis"].get("rejectedHoleCandidates", 0),
                "manufacturingHoleCount": item["hole_analysis"].get("manufacturingHoleCount", item["hole_analysis"]["physicalCount"]),
                "physicalHolesDetailed": item["hole_analysis"].get("physicalHolesDetailed", []),
                "holeFallbackCount": item["hole_analysis"].get("fallbackHoleCount", 0),
                "externalCylindricalFaceCount": item["hole_analysis"]["externalCylindricalFaces"],
                "uncertainCylindricalFaceCount": item["hole_analysis"]["uncertainCylindricalFaces"],
                "conicalFaceCount": item["cone_count"],
                "planarFaceCount": item["plane_count"],
                "internalPlanarFaceCount": item["internal_planar_count"],
                "internalPaintExcludedMm2Each": item["internal_paint_area"],
                "bevel": item["bevel"],
                "pocketCandidateCount": item["pockets"]["count"],
                "pocketCandidateAreaMm2": item["pockets"]["areaMm2"],
                "pocketMaxDepthMm": item["pockets"]["maxDepthMm"],
                "pocketCandidates": item["pockets"]["candidates"],
                "holes": item["holes"],
                "massKgEach": 0.0,
            })

        parts.sort(key=lambda p: (-p["quantity"], -p["volumeMm3Each"]))

        result["parts"] = parts
        result["uniquePartGroups"] = len(parts)
        result["volumeMm3"] = total_volume
        result["surfaceMm2"] = total_area
        result["totalHoleCount"] = total_holes
        result["holeFallbackCount"] = total_hole_fallbacks
        result["holeAnalysisState"] = "complete"
        result["totalBevelFaces"] = total_bevels
        result["totalPocketCandidateCount"] = total_pockets
        core_only = os.environ.get("DSE_STEP_CORE_ONLY", "") == "1"
        priority_accurate = os.environ.get("DSE_STEP_PRIORITY_ACCURATE", "") == "1"
        large_assembly = len(solids) >= 300 or len(parts) >= 120
        if core_only:
            result["analysisMode"] = "core-fallback"
            contact_analysis = {
                "contactPairs": 0, "tightContactPairs": 0, "nominalContactPairs": 0,
                "candidatePairs": 0, "exactChecks": 0, "limitReached": True, "pairs": []
            }
            result["warnings"].append(
                "Tryb awaryjny STEP: pominięto kosztowną analizę styków, spoin i dostępności powierzchni; "
                "zachowano bryły, grupy części, gabaryt, objętość i zwalidowane otwory."
            )
        else:
            _progress(64, "STEP: analiza styków")
            contact_analysis = analyze_contacts(
                solids, centers,
                hard_pair_cap=(100000 if priority_accurate else 60000),
            )
        result["contactPairs"] = contact_analysis["contactPairs"]
        result["contactPairsTight"] = contact_analysis["tightContactPairs"]
        result["contactPairsNominal"] = contact_analysis["nominalContactPairs"]
        result["contactCandidatePairs"] = contact_analysis["candidatePairs"]
        result["contactExactChecks"] = contact_analysis["exactChecks"]
        result["contactLimitReached"] = contact_analysis["limitReached"]

        # 1.1 stage cache: contacts are valuable independently from later weld/surface
        # work. Persist them so a watchdog/cancel never falls back to feature-only data.
        if checkpoint_path and not core_only:
            try:
                snapshot = dict(result)
                snapshot["analysisMode"] = "checkpoint-contacts"
                snapshot["warnings"] = list(result.get("warnings", [])) + [
                    f"STEP 1.1 stage cache: zachowano Contact Engine ({contact_analysis['exactChecks']} sprawdzeń)."
                ]
                cp = Path(checkpoint_path)
                tmp = cp.with_suffix(cp.suffix + ".tmp")
                tmp.write_text(json.dumps(snapshot, ensure_ascii=True), encoding="utf-8")
                os.replace(tmp, cp)
            except Exception as exc:
                result["warnings"].append(f"STEP contact checkpoint write: {type(exc).__name__}: {exc}")

        if core_only:
            joint_analysis = {
                "planarMatingAreaMm2": 0.0,
                "hiddenMatingSurfaceMm2": 0.0,
                "exposedSurfaceMm2": total_area,
                "internalPaintExcludedMm2": 0.0,
                "paintableSurfaceMm2": total_area,
                "weldCandidatePairs": 0,
                "weldCandidateLengthMm": 0.0,
                "possibleBoltedJointPairs": 0,
                "jointCandidates": [],
                "faceChecks": 0,
                "limitReached": True,
            }
        else:
            # For very large assemblies keep the expensive exact face-pair work
            # bounded. A partial, explicitly flagged weld/contact result is preferable
            # to keeping the user waiting 20+ minutes.
            _progress(76, "STEP: styki powierzchni i kandydaci spoin")
            joint_analysis = analyze_joint_surfaces(
                solids,
                solid_records,
                contact_analysis.get("pairs", []),
                total_area,
                cq,
                hard_face_check_cap=(
                    24000 if large_assembly and priority_accurate
                    else 12000 if large_assembly
                    else 40000
                ),
            )

        for joint in joint_analysis["jointCandidates"]:
            joint["sourceFile"] = path.name

        if checkpoint_path and not core_only:
            try:
                snapshot = dict(result)
                snapshot.update({
                    "analysisMode": "checkpoint-joints",
                    "planarMatingAreaMm2": joint_analysis["planarMatingAreaMm2"],
                    "hiddenMatingSurfaceMm2": joint_analysis["hiddenMatingSurfaceMm2"],
                    "exposedSurfaceMm2": joint_analysis["exposedSurfaceMm2"],
                    "internalPaintExcludedMm2": joint_analysis["internalPaintExcludedMm2"],
                    "paintableSurfaceMm2": joint_analysis["paintableSurfaceMm2"],
                    "weldCandidatePairs": joint_analysis["weldCandidatePairs"],
                    "weldCandidateLengthMm": joint_analysis["weldCandidateLengthMm"],
                    "possibleBoltedJointPairs": joint_analysis["possibleBoltedJointPairs"],
                    "jointCandidates": joint_analysis["jointCandidates"],
                    "jointAnalysisLimitReached": joint_analysis["limitReached"],
                    "jointFaceChecks": joint_analysis.get("faceChecks", 0),
                })
                snapshot["warnings"] = list(result.get("warnings", [])) + [
                    f"STEP 1.1 stage cache: zachowano Joint/Weld Engine ({joint_analysis.get('faceChecks', 0)} sprawdzeń ścian)."
                ]
                cp = Path(checkpoint_path)
                tmp = cp.with_suffix(cp.suffix + ".tmp")
                tmp.write_text(json.dumps(snapshot, ensure_ascii=True), encoding="utf-8")
                os.replace(tmp, cp)
            except Exception as exc:
                result["warnings"].append(f"STEP joint checkpoint write: {type(exc).__name__}: {exc}")

        fast_history = os.environ.get("DSE_HISTORY_FAST_STEP", "") == "1"
        # Legacy rule was: fast_history or core_only or large_assembly. FIX10D keeps
        # that bounded behaviour for ordinary/reference work, but a small set of
        # selected production STEP files may opt into local-component cavity analysis.
        if fast_history or core_only or (large_assembly and not priority_accurate):
            surface_access = {
                "checkedFaces": 0,
                "inaccessibleSurfaceMm2": 0.0,
                "sealedCavitySurfaceMm2": 0.0,
                "limitReached": False,
            }
            if fast_history and not core_only:
                result["warnings"].append(
                    "Szybki tryb historii: pominięto kosztowną analizę dostępności zamkniętych komór; "
                    "powierzchnia malowania pozostaje konserwatywna."
                )
            elif large_assembly and not core_only:
                result["warnings"].append(
                    "Duże złożenie: pominięto globalną analizę zamkniętych komór, aby ograniczyć czas; "
                    "powierzchnia malowania jest konserwatywna i opiera się na powierzchniach zewnętrznych/stykach."
                )
        else:
            _progress(88, "STEP: dostępność powierzchni do malowania")
            surface_access = analyze_surface_accessibility(
                solids,
                cq,
                joint_analysis["hiddenMatingSurfaceMm2"],
                contact_analysis.get("pairs", []),
                hard_face_cap=(2400 if priority_accurate else 1600),
            )
            if priority_accurate and large_assembly:
                result["warnings"].append(
                    "DS 1.0 Accuracy Priority: dla głównego złożenia produkcyjnego zwiększono limity styków/spoin "
                    "i uruchomiono lokalną analizę dostępności powierzchni; watchdog nadal ogranicza czas."
                )

        exposed_after_mating = joint_analysis["exposedSurfaceMm2"]
        internal_excluded = min(
            joint_analysis["internalPaintExcludedMm2"],
            exposed_after_mating,
        )
        sealed_excluded = min(
            surface_access["sealedCavitySurfaceMm2"],
            max(0.0, exposed_after_mating - internal_excluded),
        )
        final_paintable = max(
            0.0,
            exposed_after_mating - internal_excluded - sealed_excluded,
        )

        result["planarMatingAreaMm2"] = joint_analysis["planarMatingAreaMm2"]
        result["hiddenMatingSurfaceMm2"] = joint_analysis["hiddenMatingSurfaceMm2"]
        result["exposedSurfaceMm2"] = exposed_after_mating
        result["internalPaintExcludedMm2"] = internal_excluded
        result["sealedCavitySurfaceMm2"] = sealed_excluded
        result["surfaceAccessibilityCheckedFaces"] = surface_access["checkedFaces"]
        result["surfaceAccessibilityLimitReached"] = surface_access["limitReached"]
        result["paintableSurfaceMm2"] = final_paintable
        result["weldCandidatePairs"] = joint_analysis["weldCandidatePairs"]
        result["weldCandidateLengthMm"] = joint_analysis["weldCandidateLengthMm"]
        result["possibleBoltedJointPairs"] = joint_analysis["possibleBoltedJointPairs"]
        result["jointCandidates"] = joint_analysis["jointCandidates"]
        result["jointAnalysisLimitReached"] = joint_analysis["limitReached"]
        result["jointFaceChecks"] = joint_analysis.get("faceChecks", 0)

        if joint_analysis["limitReached"] and not core_only:
            result["warnings"].append(
                "Joint/Surface Engine osiągnął limit analizy par ścian; "
                "powierzchnia dolegania i długość kandydatów spoin mogą być częściowe."
            )

        if surface_access["limitReached"]:
            result["warnings"].append(
                "Surface Accessibility Engine pominął analizę zamkniętych komór "
                "z powodu dużej liczby ścian; powierzchnia malowania jest konserwatywna."
            )

        if contact_analysis["limitReached"] and not core_only:
            result["warnings"].append(
                "Analiza styków osiągnęła limit dokładnych sprawdzeń; "
                "wynik styków jest częściowy."
            )
        elif len(solids) > 250:
            result["warnings"].append(
                "Duże złożenie: zastosowano sweep-and-prune przed dokładnym "
                "sprawdzeniem odległości brył."
            )

    except Exception as exc:
        result["warnings"].append(
            f"Geometry Engine: {type(exc).__name__}: {exc}"
        )

    _progress(99, "STEP: finalizacja wyniku")
    print(json.dumps(result, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    rc = main()
    # The JSON result and progress stream are complete.  Avoid replacing the
    # real analyzer status with a CadQuery/OCP shutdown crash on Windows.
    try:
        sys.stdout.flush(); sys.stderr.flush()
    finally:
        os._exit(rc)
