@echo off
cd /d "%~dp0"
echo.
echo ============================================================
echo  DS Estimate 1.2 MINIMAL UI + OFFLINE
echo ============================================================
echo.
if not exist ".venv\Scripts\python.exe" (
  echo Pierwsze uruchomienie - przygotowuje srodowisko Python/OCR...
  powershell -NoProfile -ExecutionPolicy Bypass -File ".\setup_environment.ps1"
  if errorlevel 1 goto :error
)
set "DSE_ENABLE_DOCLING=0"
".venv\Scripts\python.exe" -c "import docling" >nul 2>nul
if not errorlevel 1 set "DSE_ENABLE_DOCLING=1"
where dotnet >nul 2>nul
if errorlevel 1 (
  echo BLAD: Nie znaleziono dotnet. Zainstaluj .NET 10 SDK.
  goto :error
)
dotnet run --project ".\src\DSEstimate.App\DSEstimate.App.csproj"
exit /b %errorlevel%
:error
echo.
echo Nie udalo sie uruchomic DS Estimate.
echo Uruchom check_environment.ps1 aby zobaczyc szczegoly.
pause
exit /b 1
