# DS Estimate 1.2 FIX70 — pełna regresja wydania

Punkt wyjścia: pełna zweryfikowana paczka FIX69.

Błąd: `RUN_FULL_RELEASE_TESTS.cmd` kończył listę testów na FIX61,
a `BUILD_FULL_PORTABLE_ZIP.ps1` na FIX62. Testy FIX63–FIX69
były wykonywane oddzielnie, ale mogły zostać pominięte przez
pełną bramkę wydania Windows.

Poprawka: obie bramki uruchamiają FIX62–FIX70 i zatrzymują
wydanie po niezerowym kodzie procesu. Nowy test FIX70 sprawdza
obecność wszystkich testów w obu bramkach oraz rejestrację w CI.

Bez zmian: src/ (C#), engines/python/ (silniki), algorytmy OCR,
PDF, STEP, BOM, CNC, raporty, cache i licencje.

Weryfikacja lokalna Python nie jest kompilacją .NET 10 ani
wykonaniem skryptów Windows CMD/PowerShell. Do potwierdzenia
pozostają: build Windows, launcher, Avalonia, xUnit, TRX i discovery.
