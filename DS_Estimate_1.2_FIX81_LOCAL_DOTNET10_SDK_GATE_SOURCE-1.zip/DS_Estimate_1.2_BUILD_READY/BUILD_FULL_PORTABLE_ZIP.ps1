﻿param(
    [switch]$FastBuild,
    [switch]$RunFullRegression,
    [switch]$NoBuildCache
)

$ErrorActionPreference = "Stop"
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
Set-Location $PSScriptRoot
try { chcp 65001 > $null } catch {}
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = New-Object System.Text.UTF8Encoding($false)

$AppVersion = "1.2 MINIMAL UI"
$PythonVersion = "3.12.10"
$Project = Join-Path $PSScriptRoot "src\DSEstimate.App\DSEstimate.App.csproj"
$LauncherProject = Join-Path $PSScriptRoot "src\DSEstimate.Launcher\DSEstimate.Launcher.csproj"
$CoreTestsProject = Join-Path $PSScriptRoot "tests\DSEstimate.Core.Tests\DSEstimate.Core.Tests.csproj"
$PublishRoot = Join-Path $PSScriptRoot "publish"
$Zip = Join-Path $PublishRoot "DS_Estimate_1_2_FULL_PORTABLE_win-x64.zip"
$Installer = Join-Path $PublishRoot "DS_Estimate_1_2_URUCHOM.exe"
# Build in a deliberately short TEMP path. OCP/VTK contain native DLLs and
# Windows may still reject deeply nested DLL paths even when normal file I/O works.
$StageRoot = Join-Path $env:TEMP "DSE_1_2"
$Out = Join-Path $StageRoot "app"
$CacheBase = if ($env:LOCALAPPDATA) { $env:LOCALAPPDATA } else { $env:TEMP }
$BuildCache = if ($env:DSE_BUILD_CACHE_ROOT) { $env:DSE_BUILD_CACHE_ROOT } else { Join-Path $CacheBase "DSEstimate\build_cache" }
$EmbeddedZip = Join-Path $BuildCache "python-$PythonVersion-embed-amd64.zip"
$EmbeddedUrl = "https://www.python.org/ftp/python/$PythonVersion/python-$PythonVersion-embed-amd64.zip"
$CacheSchema = "fix18-v1"
$OcrModelCache = Join-Path $BuildCache "tessdata_fast"
$BuildReportJson = Join-Path $PublishRoot "BUILD_REPORT_FIX17.json"
$BuildReportText = Join-Path $PublishRoot "BUILD_REPORT_FIX17.txt"
$BuildReportJsonFix18 = Join-Path $PublishRoot "BUILD_REPORT_FIX18.json"
$BuildReportTextFix18 = Join-Path $PublishRoot "BUILD_REPORT_FIX18.txt"
$BuildStartedAt = Get-Date
$BuildStopwatch = [Diagnostics.Stopwatch]::StartNew()
$BuildStages = New-Object System.Collections.ArrayList
$BuildCacheEvents = New-Object System.Collections.ArrayList
$CurrentStage = $null
$CurrentStageWatch = $null
$BuildOutcome = "IN_PROGRESS"
$BuildError = ""
$buildPyExe = ""
$buildPyPrefix = @()
$tesseractRoot = ""
$zipHash = ""
$installerHash = ""

function Get-TextSha256([string]$Text) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes($Text)
        return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace("-", "").ToLowerInvariant()
    } finally {
        $sha.Dispose()
    }
}

function Get-InputTreeHash([string[]]$Roots, [string]$Salt) {
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add($Salt)
    foreach ($root in $Roots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        $item = Get-Item -LiteralPath $root
        $files = if ($item.PSIsContainer) {
            Get-ChildItem -LiteralPath $root -Recurse -File -Force | Where-Object {
                $_.FullName -notmatch "[\\/](bin|obj|publish|__pycache__)[\\/]" -and
                $_.Extension -notin @(".pyc", ".pyo")
            }
        } else { @($item) }
        foreach ($file in $files | Sort-Object FullName) {
            $relative = $file.FullName.Substring($PSScriptRoot.Length).TrimStart([IO.Path]::DirectorySeparatorChar)
            $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $file.FullName).Hash.ToLowerInvariant()
            $lines.Add("$relative|$hash")
        }
    }
    return Get-TextSha256 ($lines -join "`n")
}

function Write-DirectoryCacheManifest([string]$Root, [string]$Key) {
    $manifestPath = Join-Path $Root ".dse_cache_manifest.sha256"
    $entries = Get-ChildItem -LiteralPath $Root -Recurse -File -Force |
        Where-Object { $_.FullName -ne $manifestPath -and $_.Name -ne ".dse_cache_ready" } |
        Sort-Object FullName |
        ForEach-Object {
            $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash.ToLowerInvariant()
            $relative = $_.FullName.Substring($Root.Length).TrimStart([IO.Path]::DirectorySeparatorChar)
            "$hash  $relative"
        }
    Set-Content -LiteralPath $manifestPath -Value $entries -Encoding ASCII
    Set-Content -LiteralPath (Join-Path $Root ".dse_cache_ready") -Value $Key -Encoding ASCII
}

function Test-DirectoryCache([string]$Root, [string]$Key, [switch]$IgnoreDisabled) {
    if ((-not $IgnoreDisabled -and $NoBuildCache) -or -not (Test-Path -LiteralPath $Root)) { return $false }
    $ready = Join-Path $Root ".dse_cache_ready"
    $manifestPath = Join-Path $Root ".dse_cache_manifest.sha256"
    if (-not (Test-Path -LiteralPath $ready) -or -not (Test-Path -LiteralPath $manifestPath)) { return $false }
    if ((Get-Content -LiteralPath $ready -Raw).Trim() -ne $Key) { return $false }
    try {
        foreach ($line in Get-Content -LiteralPath $manifestPath) {
            if ([string]::IsNullOrWhiteSpace($line) -or $line.Length -lt 67) { return $false }
            $expected = $line.Substring(0, 64)
            $relative = $line.Substring(66)
            $path = Join-Path $Root $relative
            if (-not (Test-Path -LiteralPath $path)) { return $false }
            $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash.ToLowerInvariant()
            if ($actual -ne $expected) { return $false }
        }
        return $true
    } catch {
        return $false
    }
}

function Test-BuildCacheProtocol {
    $testRoot = Join-Path $env:TEMP ("DSE_FIX18_CACHE_PROTOCOL_" + [Guid]::NewGuid().ToString("N"))
    try {
        New-Item -ItemType Directory -Force -Path $testRoot | Out-Null
        $key = Get-TextSha256 "fix18-cache-protocol"
        if (Test-DirectoryCache $testRoot $key -IgnoreDisabled) { throw "stan zimny rozpoznany jako HIT" }
        Set-Content -LiteralPath (Join-Path $testRoot "payload.bin") -Value "cache-payload-v1" -Encoding ASCII
        Write-DirectoryCacheManifest $testRoot $key
        if (-not (Test-DirectoryCache $testRoot $key -IgnoreDisabled)) { throw "stan ciepły nie został rozpoznany" }
        Set-Content -LiteralPath (Join-Path $testRoot "payload.bin") -Value "cache-corrupted" -Encoding ASCII
        if (Test-DirectoryCache $testRoot $key -IgnoreDisabled) { throw "uszkodzona zawartość rozpoznana jako HIT" }
        Set-Content -LiteralPath (Join-Path $testRoot "payload.bin") -Value "cache-payload-v1" -Encoding ASCII
        Write-DirectoryCacheManifest $testRoot $key
        if (Test-DirectoryCache $testRoot (Get-TextSha256 "changed-key") -IgnoreDisabled) { throw "zmieniony klucz rozpoznany jako HIT" }
        return $true
    } finally {
        if (Test-Path -LiteralPath $testRoot) { Remove-Item -LiteralPath $testRoot -Recurse -Force }
    }
}

function Add-CacheEvent([string]$Component, [bool]$Hit, [string]$Key) {
    [void]$BuildCacheEvents.Add([pscustomobject]@{
        Component = $Component
        Result = if ($Hit) { "HIT" } else { if ($NoBuildCache) { "DISABLED" } else { "MISS" } }
        Key = $Key.Substring(0, [Math]::Min(16, $Key.Length))
    })
    $label = if ($Hit) { "CACHE HIT" } else { if ($NoBuildCache) { "CACHE OFF" } else { "CACHE MISS" } }
    $colour = if ($Hit) { "Green" } else { "DarkGray" }
    Write-Host "[$label] $Component" -ForegroundColor $colour
}

function Start-BuildStage([string]$Name) {
    $script:CurrentStage = $Name
    $script:CurrentStageWatch = [Diagnostics.Stopwatch]::StartNew()
}

function Complete-BuildStage([string]$Status = "PASS", [string]$Detail = "") {
    if ($null -eq $script:CurrentStageWatch -or [string]::IsNullOrWhiteSpace($script:CurrentStage)) { return }
    $script:CurrentStageWatch.Stop()
    [void]$BuildStages.Add([pscustomobject]@{
        Name = $script:CurrentStage
        Status = $Status
        Seconds = [Math]::Round($script:CurrentStageWatch.Elapsed.TotalSeconds, 2)
        Detail = $Detail
    })
    $script:CurrentStage = $null
    $script:CurrentStageWatch = $null
}

function Write-BuildReport {
    try {
        New-Item -ItemType Directory -Force -Path $PublishRoot | Out-Null
        $dotnetVersion = try { (& dotnet --version 2>$null | Out-String).Trim() } catch { "niedostępny" }
        $pythonBuildVersion = try { (& $buildPyExe @buildPyPrefix --version 2>&1 | Out-String).Trim() } catch { "niedostępny" }
        $driveName = [IO.Path]::GetPathRoot($StageRoot).TrimEnd([char[]]@(':','\'))
        $driveInfo = try { Get-PSDrive -Name $driveName -ErrorAction Stop } catch { $null }
        $memory = try { Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } catch { $null }
        $report = [ordered]@{
            Schema = "ds-estimate-build-report-v1"
            Version = $AppVersion
            Outcome = $BuildOutcome
            Error = $BuildError
            StartedAt = $BuildStartedAt.ToString("o")
            FinishedAt = (Get-Date).ToString("o")
            TotalSeconds = [Math]::Round($BuildStopwatch.Elapsed.TotalSeconds, 2)
            FullReleaseGate = (-not $FastBuild -or $RunFullRegression)
            BuildCacheEnabled = (-not $NoBuildCache)
            DotnetSdk = $dotnetVersion
            BuildPython = $pythonBuildVersion
            TesseractSource = $tesseractRoot
            StageRoot = $StageRoot
            FreeDiskGb = if ($driveInfo) { [Math]::Round($driveInfo.Free / 1GB, 2) } else { $null }
            FreeMemoryGb = if ($memory) { [Math]::Round($memory.FreePhysicalMemory / 1MB, 2) } else { $null }
            Zip = if (Test-Path -LiteralPath $Zip) { [IO.Path]::GetFileName($Zip) } else { "" }
            ZipSha256 = $zipHash
            Launcher = if (Test-Path -LiteralPath $Installer) { [IO.Path]::GetFileName($Installer) } else { "" }
            LauncherSha256 = $installerHash
            Cache = @($BuildCacheEvents)
            Stages = @($BuildStages)
        }
        $reportJson = $report | ConvertTo-Json -Depth 6
        $reportJson | Set-Content -LiteralPath $BuildReportJson -Encoding UTF8
        $reportJson | Set-Content -LiteralPath $BuildReportJsonFix18 -Encoding UTF8
        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add("DS Estimate FIX18 - raport techniczny builda")
        $lines.Add("Wynik: $BuildOutcome")
        if ($BuildError) { $lines.Add("Błąd: $BuildError") }
        $lines.Add("Czas: $([Math]::Round($BuildStopwatch.Elapsed.TotalMinutes, 2)) min")
        $lines.Add("Pełna bramka wydania: $(if (-not $FastBuild -or $RunFullRegression) { 'TAK' } else { 'NIE (-FastBuild)' })")
        $lines.Add(".NET SDK: $dotnetVersion")
        $lines.Add("Python builda: $pythonBuildVersion")
        $lines.Add("Wolne miejsce / RAM: $($report.FreeDiskGb) GB / $($report.FreeMemoryGb) GB")
        $lines.Add("")
        $lines.Add("CACHE")
        foreach ($item in $BuildCacheEvents) { $lines.Add("- $($item.Component): $($item.Result) [$($item.Key)]") }
        $lines.Add("")
        $lines.Add("ETAPY")
        foreach ($item in $BuildStages) { $lines.Add("- $($item.Status) $($item.Name): $($item.Seconds) s $($item.Detail)") }
        if ($zipHash) { $lines.Add("SHA256 ZIP: $zipHash") }
        if ($installerHash) { $lines.Add("SHA256 launchera: $installerHash") }
        Set-Content -LiteralPath $BuildReportText -Value $lines -Encoding UTF8
        Set-Content -LiteralPath $BuildReportTextFix18 -Value $lines -Encoding UTF8
    } catch {
        Write-Host ("UWAGA: nie udało się zapisać raportu builda: " + $_.Exception.Message) -ForegroundColor Yellow
    }
}

function Fail([string]$Message) {
    Complete-BuildStage "FAIL" $Message
    $script:BuildOutcome = "FAIL"
    $script:BuildError = $Message
    Write-BuildReport
    Write-Host "";
    Write-Host "BŁĄD: $Message" -ForegroundColor Red
    Write-Host "Raport: $BuildReportText" -ForegroundColor Yellow
    exit 1
}

trap {
    if ($BuildOutcome -eq "IN_PROGRESS") {
        Complete-BuildStage "FAIL" $_.Exception.Message
        $script:BuildOutcome = "FAIL"
        $script:BuildError = $_.Exception.Message
        Write-BuildReport
    }
    Write-Host ("BŁĄD NIEOCZEKIWANY: " + $_.Exception.Message) -ForegroundColor Red
    Write-Host "Raport: $BuildReportText" -ForegroundColor Yellow
    exit 1
}

function Remove-PythonBytecode([string]$Root) {
    if (-not (Test-Path -LiteralPath $Root)) { return }
    $cacheDirs = @(Get-ChildItem -LiteralPath $Root -Directory -Recurse -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -eq "__pycache__" } |
        Sort-Object { $_.FullName.Length } -Descending)
    foreach ($dir in $cacheDirs) {
        if (Test-Path -LiteralPath $dir.FullName) {
            Remove-Item -LiteralPath $dir.FullName -Recurse -Force
        }
    }
    $bytecodeFiles = @(Get-ChildItem -LiteralPath $Root -File -Recurse -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in @(".pyc", ".pyo") })
    foreach ($file in $bytecodeFiles) {
        Remove-Item -LiteralPath $file.FullName -Force
    }
}

function Remove-PackageTestTrees([string]$Root) {
    if (-not (Test-Path -LiteralPath $Root)) { return }
    $before = (Get-ChildItem -LiteralPath $Root -File -Recurse -Force -ErrorAction SilentlyContinue |
        Measure-Object -Property Length -Sum).Sum
    if ($null -eq $before) { $before = 0 }
    $noiseDirs = @(Get-ChildItem -LiteralPath $Root -Directory -Recurse -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match "^(test|tests|benchmarks|examples)$" } |
        Sort-Object { $_.FullName.Length } -Descending)
    foreach ($dir in $noiseDirs) {
        if (Test-Path -LiteralPath $dir.FullName) {
            Remove-Item -LiteralPath $dir.FullName -Recurse -Force
        }
    }
    Remove-PythonBytecode $Root
    $after = (Get-ChildItem -LiteralPath $Root -File -Recurse -Force -ErrorAction SilentlyContinue |
        Measure-Object -Property Length -Sum).Sum
    if ($null -eq $after) { $after = 0 }
    $savedMb = [math]::Round(($before - $after) / 1MB, 1)
    Write-Host ("Usunięto testy/cache Pythona z runtime: " + $noiseDirs.Count + " katalogów; oszczędzono " + $savedMb + " MB") -ForegroundColor DarkGray
}

function Find-BuildPython312 {
    $candidates = @()
    if (Test-Path ".\.venv\Scripts\python.exe") { $candidates += ,@((Resolve-Path ".\.venv\Scripts\python.exe").Path) }
    if (Get-Command py -ErrorAction SilentlyContinue) { $candidates += ,@("py", "-3.12") }
    if (Get-Command python -ErrorAction SilentlyContinue) { $candidates += ,@("python") }

    foreach ($candidate in $candidates) {
        $exe = $candidate[0]
        $prefix = @($candidate | Select-Object -Skip 1)
        try {
            $version = (& $exe @prefix -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null | Out-String).Trim()
            if ($version -eq "3.12") {
                return [pscustomobject]@{
                    Exe = $exe
                    PrefixArgs = @($prefix)
                }
            }
        } catch {}
    }
    return $null
}

function Find-TesseractRoot {
    $candidates = @()
    if (Test-Path ".\tools\ocr\tesseract.exe") { $candidates += (Resolve-Path ".\tools\ocr").Path }
    $cmd = Get-Command tesseract -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source) { $candidates += (Split-Path $cmd.Source -Parent) }
    $candidates += @(
        "C:\Program Files\Tesseract-OCR",
        "C:\Program Files (x86)\Tesseract-OCR",
        (Join-Path $env:LOCALAPPDATA "Programs\Tesseract-OCR")
    )
    foreach ($candidate in $candidates | Select-Object -Unique) {
        if ($candidate -and (Test-Path (Join-Path $candidate "tesseract.exe"))) { return $candidate }
    }
    return $null
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " DS Estimate $AppVersion - FULL PORTABLE BUILD" -ForegroundColor Cyan
Write-Host " .NET + Python/CadQuery + OCR/Tesseract -> launcher EXE + ZIP" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-BuildCacheProtocol)) { Fail "Test protokołu cache FIX18 nie przeszedł." }
Write-Host "[PASS] Cache builda: cold / warm / corrupt / key-change." -ForegroundColor Green

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { Fail "Nie znaleziono dotnet SDK." }
if (-not (Test-Path $Project)) { Fail "Brak projektu: $Project" }
if (-not (Test-Path $LauncherProject)) { Fail "Brak projektu automatycznego launchera: $LauncherProject" }
if (-not (Test-Path $CoreTestsProject)) { Fail "Brak projektu testów C#: $CoreTestsProject" }

$buildPy = Find-BuildPython312
if (-not $buildPy) { Fail "Do ZBUDOWANIA paczki potrzebny jest Python 3.12. Finalny komputer nie będzie go potrzebował." }
$buildPyExe = $buildPy.Exe
$buildPyPrefix = @($buildPy.PrefixArgs)
Write-Host "Build Python 3.12: $buildPyExe $($buildPyPrefix -join ' ')" -ForegroundColor Green
# FIX81: require selected .NET 10 SDK before touching existing publish outputs.
& $buildPyExe @buildPyPrefix (Join-Path $PSScriptRoot "tests\verify_dotnet_sdk.py")
if ($LASTEXITCODE -ne 0) { Fail "Wymagany .NET SDK 10 nie jest dostepny lub nie zostal wybrany." }

$tesseractRoot = Find-TesseractRoot
if (-not $tesseractRoot) {
    Fail "Nie znaleziono Tesseract OCR na komputerze budującym. Zainstaluj/umieść Tesseract w tools\ocr i uruchom build ponownie. Finalny komputer nie będzie go potrzebował."
}
Write-Host "Tesseract source: $tesseractRoot" -ForegroundColor Green

New-Item -ItemType Directory -Force -Path $PublishRoot, $BuildCache, $OcrModelCache | Out-Null
if (Test-Path $StageRoot) { Remove-Item $StageRoot -Recurse -Force }
if (Test-Path $Zip) { Remove-Item $Zip -Force }
if (Test-Path $Installer) { Remove-Item $Installer -Force }
if (Test-Path ($Installer + ".sha256.txt")) { Remove-Item ($Installer + ".sha256.txt") -Force }
New-Item -ItemType Directory -Force -Path $Out | Out-Null
Write-Host "Krótki katalog builda: $Out" -ForegroundColor DarkGray

Write-Host "[1/8] Publikacja .NET self-contained..." -ForegroundColor Yellow
Start-BuildStage "1/8 Publikacja .NET self-contained"
$dotnetSdkVersion = (& dotnet --version | Out-String).Trim()
$dotnetCacheKey = Get-InputTreeHash @(
    (Join-Path $PSScriptRoot "src"),
    (Join-Path $PSScriptRoot "engines\python"),
    (Join-Path $PSScriptRoot "config"),
    (Join-Path $PSScriptRoot "LICENCJE")
) "$CacheSchema|dotnet|$dotnetSdkVersion|Release|win-x64|self-contained"
$dotnetCacheDir = Join-Path $BuildCache ("dotnet\" + $dotnetCacheKey)
$dotnetCacheHit = Test-DirectoryCache $dotnetCacheDir $dotnetCacheKey
Add-CacheEvent ".NET publish" $dotnetCacheHit $dotnetCacheKey
if ($dotnetCacheHit) {
    Copy-Item (Join-Path $dotnetCacheDir "*") $Out -Recurse -Force
    Remove-Item -LiteralPath (Join-Path $Out ".dse_cache_ready") -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath (Join-Path $Out ".dse_cache_manifest.sha256") -Force -ErrorAction SilentlyContinue
} else {
    & dotnet publish $Project -c Release -r win-x64 --self-contained true -p:PublishTrimmed=false -p:PublishSingleFile=false -o $Out
    if ($LASTEXITCODE -ne 0) { Fail "dotnet publish nie powiódł się." }
    if (-not (Test-Path -LiteralPath (Join-Path $Out "DSEstimate.exe"))) {
        Fail "Publikacja .NET nie zawiera DSEstimate.exe; wynik nie trafi do cache."
    }
    if (-not $NoBuildCache) {
        if (Test-Path -LiteralPath $dotnetCacheDir) { Remove-Item -LiteralPath $dotnetCacheDir -Recurse -Force }
        New-Item -ItemType Directory -Force -Path $dotnetCacheDir | Out-Null
        Copy-Item (Join-Path $Out "*") $dotnetCacheDir -Recurse -Force
        Write-DirectoryCacheManifest $dotnetCacheDir $dotnetCacheKey
    }
}
if (-not (Test-Path -LiteralPath (Join-Path $Out "DSEstimate.exe"))) { Fail "Cache .NET nie zawiera DSEstimate.exe." }
Complete-BuildStage "PASS" $(if ($dotnetCacheHit) { "CACHE HIT" } else { "zbudowano i zweryfikowano" })

Write-Host "[2/8] Test DWG -> DXF na prawdziwym sample_AC1032.dwg..." -ForegroundColor Yellow
Start-BuildStage "2/8 Rzeczywisty test DWG do DXF"
$dwgSmokeSample = Join-Path $BuildCache "sample_AC1032.dwg"
if (-not (Test-Path $dwgSmokeSample)) {
    $dwgSmokeUrl = "https://raw.githubusercontent.com/DomCR/ACadSharp/master/samples/sample_AC1032.dwg"
    Write-Host "Pobieranie oficjalnego pliku testowego ACadSharp (cache builda)..."
    Invoke-WebRequest -Uri $dwgSmokeUrl -OutFile $dwgSmokeSample -UseBasicParsing
}
$dwgSmokeProject = Join-Path $PSScriptRoot "tests\DSEstimate.DwgSmoke\DSEstimate.DwgSmoke.csproj"
if (-not (Test-Path $dwgSmokeProject)) { Fail "Brak projektu testu DWG." }
& dotnet run --project $dwgSmokeProject -c Release -- $dwgSmokeSample
if ($LASTEXITCODE -ne 0) { Fail "Test DWG->DXF nie przeszedł. ZIP nie zostanie utworzony." }
Complete-BuildStage

Write-Host "[3/8] Wbudowany CPython $PythonVersion..." -ForegroundColor Yellow
Start-BuildStage "3/8 Wbudowany CPython"
if (-not (Test-Path $EmbeddedZip)) {
    Write-Host "Pobieranie oficjalnego CPython embeddable z python.org (tylko podczas budowania)..."
    Invoke-WebRequest -Uri $EmbeddedUrl -OutFile $EmbeddedZip -UseBasicParsing
}
$runtimeDir = Join-Path $Out "py"
$requirements = Join-Path $PSScriptRoot "engines\python\requirements.txt"
if (-not (Test-Path $requirements)) { Fail "Brak requirements.txt." }
$embeddedHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $EmbeddedZip).Hash.ToLowerInvariant()
$requirementsHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $requirements).Hash.ToLowerInvariant()
$pythonRuntimeKey = Get-TextSha256 "$CacheSchema|python|$PythonVersion|$embeddedHash|$requirementsHash"
$pythonRuntimeCacheDir = Join-Path $BuildCache ("python-runtime\" + $pythonRuntimeKey)
$pythonRuntimeCacheHit = Test-DirectoryCache $pythonRuntimeCacheDir $pythonRuntimeKey
Add-CacheEvent "Python/CAD runtime" $pythonRuntimeCacheHit $pythonRuntimeKey
if (Test-Path -LiteralPath $runtimeDir) { Remove-Item -LiteralPath $runtimeDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $runtimeDir | Out-Null
if ($pythonRuntimeCacheHit) {
    Copy-Item (Join-Path $pythonRuntimeCacheDir "*") $runtimeDir -Recurse -Force
    Remove-Item -LiteralPath (Join-Path $runtimeDir ".dse_cache_ready") -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath (Join-Path $runtimeDir ".dse_cache_manifest.sha256") -Force -ErrorAction SilentlyContinue
} else {
    Expand-Archive -Path $EmbeddedZip -DestinationPath $runtimeDir -Force
}

$pth = Get-ChildItem $runtimeDir -Filter "python312._pth" | Select-Object -First 1
if (-not $pth) { Fail "Brak python312._pth w runtime embeddable." }
@(
    "python312.zip",
    ".",
    "p",
    "..\engines\python",
    "import site"
) | Set-Content -Path $pth.FullName -Encoding ASCII
Complete-BuildStage "PASS" $(if ($pythonRuntimeCacheHit) { "CACHE HIT" } else { "runtime bazowy przygotowany" })

Write-Host "[4/8] Biblioteki Python/CAD do środka paczki..." -ForegroundColor Yellow
Start-BuildStage "4/8 Biblioteki Python i CAD"
$sitePackages = Join-Path $runtimeDir "p"
New-Item -ItemType Directory -Force -Path $sitePackages | Out-Null
if (-not $pythonRuntimeCacheHit) {
    & $buildPyExe @buildPyPrefix -m pip install --disable-pip-version-check --upgrade --no-compile --prefer-binary --target $sitePackages -r $requirements
    if ($LASTEXITCODE -ne 0) { Fail "Nie udało się przygotować bibliotek Python do portable runtime." }
}

# CasADi (dependency CadQuery) ships C/C++ development headers. They are not
# needed by DS Estimate at runtime, but their Eigen paths can exceed MAX_PATH
# when the source project itself is stored in a long Desktop folder. Remove
# only development headers, then verify the real embedded runtime imports.
$casadiInclude = Join-Path $sitePackages "casadi\include"
if (Test-Path -LiteralPath $casadiInclude) {
    Write-Host "Usuwanie niepotrzebnych nagłówków CasADi/Eigen (ochrona MAX_PATH)..." -ForegroundColor DarkGray
    Remove-Item -LiteralPath $casadiInclude -Recurse -Force
}

# Końcowy program nie korzysta z testów, benchmarków ani przykładów dołączanych
# przez zależności (np. matplotlib/mpl_toolkits). To właśnie taki niepotrzebny
# plik test_axes_grid1.cpython-312.pyc wywołał błąd 0x80010135 w Explorerze.
# Bytecode będzie tworzony dopiero dla faktycznie użytych modułów w krótkim,
# zewnętrznym cache użytkownika zamiast wewnątrz folderu aplikacji.
Remove-PackageTestTrees $sitePackages
Remove-PythonBytecode $Out
$env:PYTHONDONTWRITEBYTECODE = "1"

$embeddedPython = Join-Path $runtimeDir "python.exe"
& $embeddedPython -c "import cadquery,casadi,pypdf,pymupdf,PIL,pytesseract,ezdxf,openpyxl,xlrd,docx; print('DS_ESTIMATE_EMBEDDED_PYTHON_OK')"
if ($LASTEXITCODE -ne 0) { Fail "Wbudowany Python nie przeszedł testu importów." }
if (-not $pythonRuntimeCacheHit -and -not $NoBuildCache) {
    # Promote only a runtime that passed the real embedded-python import smoke.
    # A failed/incomplete pip result must never become a valid warm-build source.
    if (Test-Path -LiteralPath $pythonRuntimeCacheDir) { Remove-Item -LiteralPath $pythonRuntimeCacheDir -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $pythonRuntimeCacheDir | Out-Null
    Copy-Item (Join-Path $runtimeDir "*") $pythonRuntimeCacheDir -Recurse -Force
    Write-DirectoryCacheManifest $pythonRuntimeCacheDir $pythonRuntimeKey
}
Complete-BuildStage "PASS" $(if ($pythonRuntimeCacheHit) { "CACHE HIT + test importów PASS" } else { "pip + test importów PASS" })

Write-Host "[5/8] Tesseract OCR + modele językowe..." -ForegroundColor Yellow
Start-BuildStage "5/8 Tesseract OCR i modele językowe"
$ocrOut = Join-Path $Out "tools\ocr"
New-Item -ItemType Directory -Force -Path $ocrOut | Out-Null
Copy-Item (Join-Path $tesseractRoot "*") $ocrOut -Recurse -Force
$ocrExe = Join-Path $ocrOut "tesseract.exe"
if (-not (Test-Path $ocrExe)) { Fail "Po kopiowaniu brak tesseract.exe." }
$tessdata = Join-Path $ocrOut "tessdata"
New-Item -ItemType Directory -Force -Path $tessdata | Out-Null

# Jeżeli lokalna instalacja nie ma któregoś języka, pobierz oficjalny model
# tessdata_fast (Apache-2.0) podczas budowania. Finalny komputer nie pobiera nic.
foreach ($lang in @("pol","eng","deu","fra")) {
    $model = Join-Path $tessdata "$lang.traineddata"
    if (-not (Test-Path $model)) {
        $cachedModel = Join-Path $OcrModelCache "$lang.traineddata"
        if (Test-Path -LiteralPath $cachedModel) {
            Write-Host "[CACHE HIT] Model OCR: $lang" -ForegroundColor Green
            Copy-Item -LiteralPath $cachedModel -Destination $model -Force
        } else {
            $url = "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/$lang.traineddata"
            $download = $cachedModel + ".download"
            Write-Host "Pobieranie modelu OCR do cache: $lang"
            Invoke-WebRequest -Uri $url -OutFile $download -UseBasicParsing
            if ((Get-Item -LiteralPath $download).Length -lt 100000) { Fail "Pobrany model OCR $lang jest niekompletny." }
            Move-Item -LiteralPath $download -Destination $cachedModel -Force
            Copy-Item -LiteralPath $cachedModel -Destination $model -Force
        }
    }
}
$ocrCachedLanguages = @("pol","eng","deu","fra") | Where-Object {
    Test-Path -LiteralPath (Join-Path $OcrModelCache "$_.traineddata")
}
[void]$BuildCacheEvents.Add([pscustomobject]@{
    Component = "OCR language models"
    Result = if ($ocrCachedLanguages.Count -eq 4) { "HIT" } else { "PARTIAL" }
    Key = ($ocrCachedLanguages -join ",")
})
$env:TESSDATA_PREFIX = $tessdata + [IO.Path]::DirectorySeparatorChar
& $ocrExe --list-langs | Out-Host
if ($LASTEXITCODE -ne 0) { Fail "Tesseract w paczce nie przeszedł testu --list-langs." }
Complete-BuildStage

if (-not $FastBuild -or $RunFullRegression) {
    Write-Host "[6/8] DS Estimate 1.2 - bramka wydania..." -ForegroundColor Yellow
    Start-BuildStage "6/8 Pełna bramka wydania"
    Write-Host "Uruchamianie testów jednostkowych .NET..." -ForegroundColor DarkGray
    # FIX78: dotnet test can return 0 with no discovered/executed tests.
    # Clear old TRX, capture a fresh report, and fail closed on SKIP/partial runs.
    $trxResultsDir = Join-Path $PSScriptRoot "TestResults"
    New-Item -ItemType Directory -Force -Path $trxResultsDir | Out-Null
    & $buildPyExe @buildPyPrefix (Join-Path $PSScriptRoot "tests\clear_stale_trx.py")
    if ($LASTEXITCODE -ne 0) { Fail "Nie udało się usunąć starego TRX przed testami .NET." }
    & dotnet test $CoreTestsProject -c Release --nologo --logger "trx;LogFileName=ds-estimate-xunit.trx" --results-directory $trxResultsDir
    if ($LASTEXITCODE -ne 0) { Fail "Testy jednostkowe .NET nie przeszły." }
    & $buildPyExe @buildPyPrefix (Join-Path $PSScriptRoot "tests\verify_dotnet_trx.py") (Join-Path $trxResultsDir "ds-estimate-xunit.trx") --require-results --min-executed 60 --reject-skipped
    if ($LASTEXITCODE -ne 0) { Fail "Brak świeżego TRX z co najmniej 60 zaliczonymi testami xUnit bez SKIP." }
    $baselineFunctionalTests = @(
        "tests\run_r7_regression.py",
        "tests\run_r7_parametric.py",
        "tests\run_r8_weak_links.py",
        "tests\run_r9_0_3_public_bom_interop.py",
        "tests\run_r9_0_6b_2d_document_hardening.py",
        "tests\run_r9_0_7_step_assembly_performance.py",
        "tests\run_r9_2_3d_adaptive_scheduler_source_hierarchy.py",
        "tests\run_r9_3_0_fix5_minimal_ui_fast_import.py",
        "tests\run_r9_3_0_fix7_report_findings.py",
        "tests\run_r9_3_0_fix8_dependency_cache.py",
        "tests\run_r9_3_0_fix9_report_correctness.py",
        "tests\run_fix11_technology_scope.py",
        "tests\run_fix12a_shadow_graph.py",
        "tests\run_fix12a_titleblock_semantics.py",
        "tests\run_fix12b_cost_reality.py",
        "tests\run_fix12c_manual_override_private_pack.py",
        "tests\run_fix12d_resolver_scope.py",
        "tests\run_fix12e_hybrid_surface.py",
        "tests\run_fix13_historical_intelligence.py",
        "tests\run_fix13a_hardening.py",
        "tests\run_fix14_all_in.py",
        "tests\run_fix15_trust_foundation.py",
        "tests\run_fix16_decision_support.py",
        "tests\run_fix16a_reliability.py",
        "tests\run_fix16b_compile_guard.py",
        "tests\run_fix16c_embedded_exit_guard.py",
        "tests\run_fix16d_native_exit_guard.py",
        "tests\run_fix16e_worker_shutdown_guard.py",
        "tests\run_fix17_build_runtime_calibration.py",
        "tests\run_fix18_release_safety.py",
        "tests\run_fix19_document_intelligence.py",
        "tests\run_fix20_open_source_integrations.py",
        "tests\run_fix21_pdf_raster_budget.py",
        "tests\run_fix22_pdf_mixed_scans.py",
        "tests\run_fix23_tiled_inline_pdf.py",
        "tests\run_fix24_titleblock_raster_pdf.py",
        "tests\run_fix25_large_tiled_pdf.py",
        "tests\run_fix26_pdf_page_evidence.py",
        "tests\run_fix27_pdf_text_layer_provenance.py",
        "tests\run_fix28_pdf_drawing_number_layout.py",
        "tests\run_fix29_pdf_exact_bom_links.py",
        "tests\run_fix30_pdf_bom_step_links.py",
        "tests\run_fix31_step_path_identity.py",
        "tests\run_fix32_empty_step_guard.py",
        "tests\run_fix33_ci_trx_guard.py",
        "tests\run_fix34_trx_partial_pass_guard.py",
        "tests\run_fix35_trx_result_discovery_guard.py",
        "tests\run_fix36_launcher_compile_coverage.py",
        "tests\run_fix37_trx_minimum_discovery.py",
        "tests\run_fix38_xunit_discovery_evidence.py",
        "tests\run_fix39_ci_build_log_evidence.py",
        "tests\run_fix40_xunit_execution_evidence.py",
        "tests\run_fix41_ci_python_engine_gate.py",
        "tests\run_fix42_ci_real_pdf_dependency.py",
        "tests\run_fix43_real_pdf_skip_guard.py",
        "tests\run_fix44_trx_freshness_guard.py",
        "tests\run_fix45_dotnet_first_ci_gate.py",
        "tests\run_fix46_dotnet_sdk_evidence.py",
        "tests\run_fix47_launcher_pe_evidence.py",
        "tests\run_fix48_trx_skip_guard.py",
        "tests\run_fix49_trx_nonpass_counter_guard.py",
        "tests\run_fix50_trx_duplicate_identity_guard.py",
        "tests\run_fix51_trx_verification_evidence.py",
        "tests\run_fix52_dotnet_solution_output_evidence.py",
        "tests\run_fix53_managed_dll_metadata_guard.py",
        "tests\run_fix54_metadata_stream_directory_guard.py",
        "tests\run_fix55_metadata_stream_overlap_guard.py",
        "tests\run_fix56_xunit_nonempty_discovery.py",
        "tests\run_fix57_xunit_discovery_minimum_gate.py",
        "tests\run_fix58_xunit_duplicate_discovery_guard.py",
        "tests\run_fix59_xunit_qualified_name_guard.py",
        "tests\run_fix60_xunit_namespace_scope_guard.py",
        "tests\run_fix61_xunit_discovery_fatal_diagnostics_guard.py",
        "tests\run_fix62_dscompare_desktop_ui.py",
        "tests\run_fix63_local_storage_dnd_guard.py",
        "tests\run_fix64_local_export_uri_guard.py",
        "tests\run_fix65_private_pack_input_isolation.py",
        "tests\run_fix66_private_pack_atomic_output.py",
        "tests\run_fix67_private_pack_deterministic_order.py",
        "tests\run_fix68_private_pack_exception_privacy.py",
        "tests\run_fix69_private_pack_zip_metadata_determinism.py",
        "tests\run_fix70_release_gate_recent_regressions.py",
        "tests\run_fix71_private_pack_temp_isolation.py",
        "tests\run_fix72_xlsx_workbook_cleanup.py",
        "tests\run_fix73_pdf_reader_cleanup.py",
        "tests\run_fix74_private_pack_hash_fail_closed.py",
        "tests\run_fix75_private_pack_source_mutation_guard.py",
        "tests\run_fix76_private_pack_bounded_text_read.py",
        "tests\run_fix77_release_real_pdf_gate.py",
        "tests\run_fix78_local_release_trx_gate.py",
        "tests\run_fix79_ci_release_script_triggers.py",
        "tests\run_fix80_private_pack_final_snapshot_guard.py",
        "tests\run_fix81_local_dotnet_sdk_gate.py",
        "tests\run_ds_estimate_1_2_minimal_ui.py",
        "tests\run_ds_estimate_1_2_powershell_encoding.py"
    )
    foreach ($relTest in $baselineFunctionalTests) {
        $testPath = Join-Path $PSScriptRoot $relTest
        if (-not (Test-Path $testPath)) { Fail ("Brak testu bazowego: " + $relTest) }
        # FIX77: never accept a green full release after the real two-page
        # PDF/BOM checks were silently skipped because PyMuPDF is missing.
        # Preserve the existing test list and pass the strict flag only to
        # the two tests which support it.
        if ($relTest -in @("tests\run_fix29_pdf_exact_bom_links.py", "tests\run_fix30_pdf_bom_step_links.py")) {
            & $embeddedPython $testPath --require-real-pdf
        } else {
            & $embeddedPython $testPath
        }
        $testExit = $LASTEXITCODE
        if ($testExit -ne 0) {
            Fail ("Bramka DS Estimate 1.2 nie przeszła: " + $relTest + " (kod procesu: " + $testExit + ")")
        }
    }

    $systemStress = Join-Path $PSScriptRoot "tests\run_r9_0_system_stress.py"
    if (-not (Test-Path $systemStress)) { Fail "Brak tests\run_r9_0_system_stress.py." }
    $env:DSE_STRESS_FULL = "1"
    & $embeddedPython $systemStress
    $stressExit = $LASTEXITCODE
    Remove-Item Env:DSE_STRESS_FULL -ErrorAction SilentlyContinue
    if ($stressExit -ne 0) { Fail "Systemowe stress-testy DS Estimate 1.2 nie przeszły." }
    Complete-BuildStage "PASS" "pełna regresja + stress PASS"
} else {
    Write-Host "[6/8] Szybka kontrola silników (bez pełnej regresji)..." -ForegroundColor Yellow
    Start-BuildStage "6/8 Szybka kontrola silników"
    $engineScripts = @(
        (Join-Path $Out "engines\python\analyze_step.py"),
        (Join-Path $Out "engines\python\step_worker.py"),
        (Join-Path $Out "engines\python\analyze_document.py"),
        (Join-Path $Out "engines\python\analyze_dxf.py")
    )
    foreach ($engineScript in $engineScripts) {
        if (-not (Test-Path $engineScript)) { Fail ("Brak silnika Python w portable: " + $engineScript) }
        & $embeddedPython -m py_compile $engineScript
        if ($LASTEXITCODE -ne 0) { Fail ("Błąd składni silnika Python: " + $engineScript) }
    }
    Write-Host "[PASS] Silniki Python: składnia OK. Pełna bramka 1.2 została jawnie pominięta przez -FastBuild." -ForegroundColor Green
    Write-Host "       Build wydania uruchom bez -FastBuild albo użyj RUN_FULL_RELEASE_TESTS.cmd." -ForegroundColor DarkGray
    Complete-BuildStage "PASS" "tryb deweloperski -FastBuild"
}

# Narzędzia developerskie/testowe nie są kopiowane do portable 1.2.
# Gotowa aplikacja zawiera wyłącznie runtime potrzebny do analizy i uruchomienia.

Write-Host "[7/8] Test kompletności offline..." -ForegroundColor Yellow
Start-BuildStage "7/8 Kompletność offline i manifest"
$required = @(
    (Join-Path $Out "DSEstimate.exe"),
    (Join-Path $Out "engines\python\analyze_step.py"),
    (Join-Path $Out "engines\python\step_worker.py"),
    (Join-Path $Out "engines\python\analyze_document.py"),
    (Join-Path $Out "engines\python\analyze_dxf.py"),
    (Join-Path $Out "config\golden_set_company.json"),
    (Join-Path $Out "ACadSharp.dll"),
    $embeddedPython,
    $ocrExe,
    (Join-Path $tessdata "pol.traineddata"),
    (Join-Path $tessdata "eng.traineddata"),
    (Join-Path $tessdata "deu.traineddata"),
    (Join-Path $tessdata "fra.traineddata")
)
$missing = @($required | Where-Object { -not (Test-Path $_) })
if ($missing.Count -gt 0) { Fail ("Brak plików w portable: " + ($missing -join "; ")) }

# Explicit target-PC offline mode. PythonRunner sees this marker and never
# attempts pip/venv/system-Python fallback in a full portable release.
Set-Content -Path (Join-Path $Out "OFFLINE_PORTABLE.flag") -Value @(
    "DS Estimate $AppVersion",
    "Runtime mode: FULL OFFLINE PORTABLE",
    "Do not remove py or tools\ocr."
) -Encoding ASCII

$portableReadmeLines = @(
    "DS Estimate $AppVersion - FULL PORTABLE",
    "",
    "Ta paczka zawiera:",
    "- .NET self-contained win-x64,",
    "- CPython $PythonVersion embeddable w krótkiej ścieżce py\,",
    "- biblioteki CAD/OCR/BOM z requirements.txt,",
    "- Tesseract OCR,",
    "- modele pol/eng/deu/fra,",
    "- ACadSharp do lokalnej konwersji DWG -> DXF przed analizą.",
    "",
    "Na komputerze docelowym nie trzeba instalować .NET, Pythona ani Tesseracta.",
    "Najprościej uruchomić DS_Estimate_1_2_URUCHOM.exe z folderu publish — sam wypakuje aplikację do krótkiej ścieżki LOCALAPPDATA i ją otworzy.",
    "Przy kolejnym uruchomieniu tego samego wydania launcher pomija wypakowywanie.",
    "OFFLINE_PORTABLE.flag blokuje automatyczne pip/venv — aplikacja nie pobiera bibliotek na komputerze docelowym.",
    "DWG jest lokalnie konwertowany do tymczasowego DXF przez ACadSharp; oryginalny DWG pozostaje bez zmian.",
    "",
    "WINDOWS / SmartScreen:",
    "- Najlepiej przenosić gotowy ZIP przez USB lub zaufany zasób firmowy.",
    "- Gdy ZIP został pobrany z Internetu: przed rozpakowaniem kliknij ZIP prawym przyciskiem > Właściwości > Odblokuj (jeżeli ta opcja jest widoczna).",
    "- W folderze portable jest też ODBLOKUJ_I_URUCHOM.cmd, który używa systemowego Unblock-File i uruchamia aplikację.",
    "- Pełne wyeliminowanie ostrzeżeń reputacji SmartScreen przy dystrybucji internetowej wymaga zaufanego podpisu kodu; build pozostaje użyteczny bez certyfikatu."
)
Set-Content -Path (Join-Path $Out "PORTABLE_README.txt") -Value $portableReadmeLines -Encoding UTF8

$selfTestLines = @(
    '@echo off',
    'setlocal',
    'cd /d "%~dp0"',
    'echo === DS Estimate portable self-test ===',
    'if not exist "py\python.exe" (',
    '  echo [FAIL] Python runtime',
    '  exit /b 1',
    ')',
    'if not exist "tools\ocr\tesseract.exe" (',
    '  echo [FAIL] Tesseract',
    '  exit /b 1',
    ')',
    'if not exist "OFFLINE_PORTABLE.flag" (',
    '  echo [FAIL] Brak OFFLINE_PORTABLE.flag',
    '  exit /b 1',
    ')',
    'if not exist "ACadSharp.dll" (',
    '  echo [FAIL] Brak ACadSharp.dll',
    '  exit /b 1',
    ')',
    'set "PYTHONDONTWRITEBYTECODE=1"',
    'py\python.exe -c "import cadquery,pypdf,pymupdf,PIL,pytesseract,ezdxf,openpyxl,xlrd,docx; print(''[PASS] Python/CAD/OCR modules'')"',
    'if errorlevel 1 exit /b 1',
    'set "TESSDATA_PREFIX=%CD%\tools\ocr\tessdata\"',
    'tools\ocr\tesseract.exe --list-langs > "%TEMP%\ds_estimate_langs.txt" 2>&1',
    'if errorlevel 1 (',
    '  type "%TEMP%\ds_estimate_langs.txt"',
    '  exit /b 1',
    ')',
    'for %%L in (pol eng deu fra) do findstr /x /c:"%%L" "%TEMP%\ds_estimate_langs.txt" >nul || (echo [FAIL] OCR language %%L & exit /b 1)',
    'echo [PASS] Tesseract pol/eng/deu/fra',
    'echo [PASS] Portable runtime kompletny.',
    'exit /b 0'
)
Set-Content -Path (Join-Path $Out "CHECK_PORTABLE.cmd") -Value $selfTestLines -Encoding ASCII

$startLines = @(
    '@echo off',
    'setlocal',
    'cd /d "%~dp0"',
    'if not exist "DSEstimate.exe" (',
    '  echo [FAIL] Brak DSEstimate.exe',
    '  pause',
    '  exit /b 1',
    ')',
    'start "" "DSEstimate.exe"',
    'exit /b 0'
)
Set-Content -Path (Join-Path $Out "URUCHOM_DS_ESTIMATE.cmd") -Value $startLines -Encoding ASCII

$unblockLines = @(
    '@echo off',
    'setlocal',
    'cd /d "%~dp0"',
    'echo DS Estimate - odblokowanie plikow pobranych z Internetu',
    'powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath ''%CD%'' -Recurse -File | Unblock-File -ErrorAction SilentlyContinue"',
    'echo.',
    'echo Gotowe. Uruchamiam DS Estimate...',
    'start "" "DSEstimate.exe"',
    'exit /b 0'
)
Set-Content -Path (Join-Path $Out "ODBLOKUJ_I_URUCHOM.cmd") -Value $unblockLines -Encoding ASCII

# Publiczne benchmarki nie są częścią czystej paczki produkcyjnej 1.0.
# Testy publiczne pozostają wyłącznie narzędziem deweloperskim w katalogu tests/tools.

# Ostatnia kontrola po regresji: żaden test nie może odtworzyć w produkcie
# katalogów __pycache__ ani plików .pyc/.pyo. Zostają wyłącznie źródła modułów,
# a używany bytecode trafi na komputerze docelowym do krótkiego cache LOCALAPPDATA.
Remove-PythonBytecode $Out
$leftoverBytecode = @(Get-ChildItem -LiteralPath $Out -File -Recurse -Force -ErrorAction SilentlyContinue |
    Where-Object { $_.Extension -in @(".pyc", ".pyo") })
if ($leftoverBytecode.Count -gt 0) {
    Fail ("W portable pozostał bytecode Pythona: " + $leftoverBytecode[0].FullName)
}
$leftoverPackageTests = @(Get-ChildItem -LiteralPath $sitePackages -Directory -Recurse -Force -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match "^(test|tests|benchmarks|examples)$" })
if ($leftoverPackageTests.Count -gt 0) {
    Fail ("W runtime pozostał niepotrzebny katalog testowy: " + $leftoverPackageTests[0].FullName)
}

# Integrity manifest helps compare transfers between computers.
$manifest = Get-ChildItem $Out -Recurse -File |
    Where-Object { $_.Name -ne "SHA256SUMS.txt" } |
    Sort-Object FullName |
    ForEach-Object {
        $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash
        $rel = $_.FullName.Substring($Out.Length).TrimStart([IO.Path]::DirectorySeparatorChar)
        "$hash  $rel"
    }
Set-Content -Path (Join-Path $Out "SHA256SUMS.txt") -Value $manifest -Encoding ASCII
Complete-BuildStage

Write-Host "[8/8] Test gotowego folderu portable + ZIP..." -ForegroundColor Yellow
Start-BuildStage "8/8 Test portable, ZIP i launcher"
# IMPORTANT: do NOT copy the whole Python/CAD tree back under the (possibly
# very long) source-project path. Windows PowerShell 5.1 Copy-Item can hit the
# classic 260-character MAX_PATH limit. The exact staging tree is already the
# portable product; test it in the deliberately short TEMP path and package
# directly from there.
$finalSelfTest = Join-Path $Out "CHECK_PORTABLE.cmd"
if (-not (Test-Path $finalSelfTest)) { Fail "Brak CHECK_PORTABLE.cmd w gotowym folderze." }
& cmd /c $finalSelfTest
if ($LASTEXITCODE -ne 0) { Fail "Gotowy folder portable nie przeszedł CHECK_PORTABLE.cmd." }

# Guard future dependencies against excessively deep archive paths. This is a
# relative-path budget: extraction to C:\DS_Estimate remains comfortably below
# MAX_PATH even on machines where long-path support is disabled.
$pathAudit = Get-ChildItem -LiteralPath $Out -Recurse -File | ForEach-Object {
    $rel = $_.FullName.Substring($Out.Length).TrimStart([IO.Path]::DirectorySeparatorChar)
    [pscustomobject]@{ RelativePath=$rel; RelativeLength=$rel.Length }
} | Sort-Object RelativeLength -Descending
$longestPath = $pathAudit | Select-Object -First 1
if ($longestPath -and $longestPath.RelativeLength -gt 180) {
    Fail ("Zbyt długa ścieżka wewnątrz paczki (" + $longestPath.RelativeLength + " znaków): " + $longestPath.RelativePath)
}
if ($longestPath) { Write-Host ("Najdłuższa ścieżka względna: " + $longestPath.RelativeLength + " znaków") -ForegroundColor DarkGray }

Write-Host "Pakowanie finalnego ZIP (bez dodatkowego testu 9/9)..." -ForegroundColor Yellow
Compress-Archive -Path (Join-Path $Out "*") -DestinationPath $Zip -Force
if (-not (Test-Path $Zip)) { Fail "Nie utworzono ZIP." }

# Na prośbę użytkownika usunięto dawny etap 9/9: ponowne rozpakowanie całego ZIP-a
# i drugi CHECK_PORTABLE. Integralność plików nadal zabezpiecza SHA256SUMS.txt,
# a gotowy folder portable jest testowany bezpośrednio w etapie 8/8.

$sizeMb = [math]::Round((Get-Item $Zip).Length / 1MB, 1)
$zipHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Zip).Hash
Set-Content -Path ($Zip + ".sha256.txt") -Value "$zipHash  $([IO.Path]::GetFileName($Zip))" -Encoding ASCII

# Jednoplikowy launcher zawiera zweryfikowany ZIP jako zasób. Użytkownik uruchamia
# EXE bez ręcznego rozpakowywania; aplikacja trafia do krótkiej ścieżki
# %LOCALAPPDATA%\DSE\1_2\<hash>, co omija błąd Explorera 0x80010135.
Write-Host "Tworzenie automatycznego launchera EXE..." -ForegroundColor Yellow
$launcherOut = Join-Path $StageRoot "launcher"
if (Test-Path $launcherOut) { Remove-Item $launcherOut -Recurse -Force }
New-Item -ItemType Directory -Force -Path $launcherOut | Out-Null
& dotnet publish $LauncherProject -c Release -r win-x64 --self-contained true `
    -p:PublishSingleFile=true -p:PublishTrimmed=false `
    "-p:PayloadZip=$Zip" "-p:PayloadHash=$($Zip + '.sha256.txt')" `
    -o $launcherOut
if ($LASTEXITCODE -ne 0) { Fail "Nie udało się zbudować automatycznego launchera EXE." }
$builtInstaller = Join-Path $launcherOut "DS_Estimate_1_2_URUCHOM.exe"
if (-not (Test-Path $builtInstaller)) { Fail "Build launchera nie utworzył DS_Estimate_1_2_URUCHOM.exe." }
Copy-Item -LiteralPath $builtInstaller -Destination $Installer -Force
$installerHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Installer).Hash
Set-Content -Path ($Installer + ".sha256.txt") -Value "$installerHash  $([IO.Path]::GetFileName($Installer))" -Encoding ASCII
$installerSizeMb = [math]::Round((Get-Item $Installer).Length / 1MB, 1)
Complete-BuildStage "PASS" "CHECK_PORTABLE + ZIP + launcher PASS"
$BuildOutcome = "PASS"
Write-BuildReport

Write-Host ""
Write-Host "GOTOWE — ZALECANE: $Installer ($installerSizeMb MB)" -ForegroundColor Green
Write-Host "SHA256 launchera: $installerHash" -ForegroundColor Green
Write-Host "Kopia awaryjna ZIP: $Zip ($sizeMb MB)" -ForegroundColor Green
Write-Host "SHA256 ZIP: $zipHash" -ForegroundColor Green
Write-Host "Raport techniczny: $BuildReportText" -ForegroundColor Green
Write-Host "Na komputerze docelowym uruchom dwuklikiem DS_Estimate_1_2_URUCHOM.exe." -ForegroundColor Green
Write-Host "Launcher sam wypakuje program do krótkiej ścieżki LOCALAPPDATA i otworzy aplikację; nie rozpakowuj ręcznie dużego ZIP-a." -ForegroundColor Green

try { if (Test-Path $StageRoot) { Remove-Item $StageRoot -Recurse -Force } } catch {}
