# DS Estimate FIX62 — desktop shell adapted from DS Compare

Based on latest verified DS Estimate FIX61. DS Compare reference: https://github.com/damianink-png/test (RC9/RC10 UI refinements, `scripts/r10_gui_patch.py`, caddiff palette).

## Implemented
- Persistent result tabs in the desktop window header, not lost while scrolling through reports.
- Graphite/slate theme, blue focus accent, subtle hover interactions, compact left navigation.
- Persistent status bar on the desktop window.
- Drag-and-drop visually blocked while import/analysis is busy. The domain view-model guard remains in place.
- Existing Avalonia/C# frontend, C# quotation engines and Python STEP/PDF/OCR/BOM engines all preserved.

## Architectural decision
DS Compare's geometry engine (PySide6 + OCP and assembly-difference semantics) is **not** a price estimation engine and therefore has NOT replaced DS Estimate's costing engine. Only UI/interaction concepts have been adapted; no Qt code or third-party GPL code copied.

## Evidence limits
Structural XML/UI regression scripts can run on Linux. Real .NET 10, Avalonia graphical smoke test, Windows launcher build and xUnit require an environment with the .NET 10 SDK and Windows CI. Their PASS is not asserted here.

## Windows desktop build (requires .NET SDK 10; not executed in this environment)

From the extracted `DS_Estimate_1.2_BUILD_READY` directory:

```powershell
dotnet restore DS_Estimate.sln
dotnet build DS_Estimate.sln -c Release --no-restore
dotnet test tests/DSEstimate.Core.Tests/DSEstimate.Core.Tests.csproj -c Release --no-build --logger "trx;LogFileName=ds-estimate-xunit.trx"
dotnet run --project src/DSEstimate.App/DSEstimate.App.csproj -c Release
```

For a complete portable Windows release with offline Python/CAD dependencies, use the existing `BUILD_FULL_PORTABLE_ZIP.cmd` only on an authorized, properly provisioned Windows machine. The SDK-only `dotnet run` can start an UI while Python/CAD services are absent; that is not a production-ready valuation. Check engine health and package diagnostics before quoting.
