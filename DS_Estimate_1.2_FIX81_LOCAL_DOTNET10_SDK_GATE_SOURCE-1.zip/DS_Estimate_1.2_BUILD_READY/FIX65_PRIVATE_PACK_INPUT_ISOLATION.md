# DS Estimate 1.2 FIX65 — izolacja wejść pakietu prywatnego

Baza: pełna zweryfikowana paczka FIX64.

## Potwierdzony błąd (przed zmianą)

Uruchomienie `engines/python/build_private_analysis_pack.py` z plikiem wynikowym wewnątrz katalogu źródłowego powodowało, że drugi przebieg dołączał do manifestu **własny wcześniejszy ZIP**: `file_count` wzrastał z 1 do 2. Manifest i suma bajtów źródeł nie były więc stabilne. Ponadto symlink do pliku poza katalogiem źródłowym mógł spowodować niezamierzone przetworzenie zewnętrznego pliku.

## Zmiana

Generator pomija symlinki oraz plik wyjściowy po rozwiązaniu ścieżki (`p.resolve() == out`). Bez zmian w strukturze paczki, ekstrakcji tekstu, redakcji danych, OCR, BOM, STEP, kosztach, C# i launcherze. Dodano rzeczywisty test `tests/run_fix65_private_pack_input_isolation.py` i wpis w Windows CI. Nie wprowadzono zmian w zależnościach ani licencjach.

## Dowody i ograniczenia

Test regresyjny uruchamia generator jako osobny proces, sprawdza `exit=0`, CRC ZIP, brak surowych plików w ZIP, stałą liczbę dokumentów i rozmiar źródeł po powtórzeniu oraz (gdy host zezwala) odrzucenie symlinka prowadzącego poza źródło. Jeśli Windows zabrania tworzenia symlinków, test wymaga obecności strażnika w kodzie, lecz nie potwierdza na Windows zachowania symlinka w runtime.

Nie wykonano kompilacji .NET 10, launchera Windows ani xUnit: lokalny SDK niedostępny; brak dedykowanego prywatnego repo DS Estimate. Testy źródłowe C# nie zastępują kompilacji ani testów UI Avalonia.
