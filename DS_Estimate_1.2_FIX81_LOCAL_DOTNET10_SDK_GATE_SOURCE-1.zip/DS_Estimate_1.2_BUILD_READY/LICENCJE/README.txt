DS Estimate — informacje licencyjne

Ten folder jest dołączany do wydania portable i zawiera informacje o komponentach zewnętrznych.
Przy dystrybucji programu należy zachować wymagane informacje/licencje komponentów użytych w konkretnym buildzie.
