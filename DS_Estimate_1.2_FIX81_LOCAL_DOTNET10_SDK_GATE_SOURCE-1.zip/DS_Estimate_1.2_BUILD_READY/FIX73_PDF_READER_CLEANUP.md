# DS Estimate 1.2 FIX73 — prywatny pakiet: zamykanie PDF

Punkt wyjścia: pełna zweryfikowana paczka FIX72.

Zmiana: `engines/python/build_private_analysis_pack.py` otwiera plik PDF przez
`with path.open('rb')`, przekazuje uchwyt do `pypdf.PdfReader` i odczytuje
maksymalnie 80 stron w tym bloku. Uchwyt jest zamykany natychmiast po odczycie
albo po wyjątku (w tym przy błędzie `extract_text`), zamiast polegać na
zwolnieniu uchwytu przez garbage collector.

Test: `tests/run_fix73_pdf_reader_cleanup.py` wstrzykuje czytnik wymagający
otwartego strumienia, kontroluje zamknięcie uchwytu po sukcesie i awarii,
sprawdza brak ujawniania treści wyjątku oraz tworzy i przetwarza rzeczywisty
2-stronicowy PDF. Test jest dodany do bramek CMD, PowerShell i Windows CI.

Nie zmieniono logiki kosztów, OCR, analizy złożeń STEP, BOM, CNC, cache,
ani licencji. To jest poprawka dotycząca wyłącznie zasobów podczas tworzenia
prywatnych paczek diagnostycznych. Testy Python nie zastępują kompilacji
.NET 10, uruchomienia Avalonia/launchera ani testów xUnit z TRX.

Przy przeglądzie Windows CI stwierdzono dodatkowo brak instalacji `pypdf`
i `openpyxl`, mimo że istniejące testy prywatnego pakietu importują te
biblioteki. Workflow instaluje teraz przypięte wersje `pypdf==5.9.0`
i `openpyxl==3.1.5` razem z istniejącym `PyMuPDF==1.26.7` i weryfikuje
ich import. To przygotowanie CI, **nie** dowód uruchomienia Windows CI.
