@echo off
setlocal
cd /d "%~dp0"
set "DSE_BUILD_ROOT=%~dp0"

rem IMPORTANT: Windows Explorer can execute a CMD directly from inside a ZIP.
rem In that mode Explorer extracts only the clicked CMD into %%TEMP%%, so the
rem sibling PS1/project files do not exist. Detect that before BOM/syntax checks.
if not exist "%DSE_BUILD_ROOT%BUILD_FULL_PORTABLE_ZIP.ps1" (
  echo.
  echo ============================================================
  echo  NIE URUCHAMIAJ BUILD'A BEZPOSREDNIO Z PLIKU ZIP
  echo ============================================================
  echo.
  echo Nie znaleziono pliku:
  echo   %DSE_BUILD_ROOT%BUILD_FULL_PORTABLE_ZIP.ps1
  echo.
  echo Windows uruchomil prawdopodobnie tylko ten plik CMD z wnetrza ZIP-a.
  echo Najpierw wypakuj CALA paczke do zwyklego folderu, np. na Pulpit,
  echo a dopiero potem uruchom BUILD_FULL_PORTABLE_ZIP.cmd.
  echo.
  echo Ten komunikat NIE oznacza bledu kodowania PowerShell.
  echo.
  pause
  exit /b 2
)

if not exist "%DSE_BUILD_ROOT%src\DSEstimate.App\DSEstimate.App.csproj" (
  echo.
  echo [PACKAGE FAIL] Brakuje src\DSEstimate.App\DSEstimate.App.csproj.
  echo Wypakuj CALA paczke FIX12A, zachowujac strukture katalogow.
  pause
  exit /b 2
)

echo === DS Estimate 1.2 MINIMAL UI - FULL PORTABLE BUILD + RELEASE GATE ===
echo [PRECHECK] Sprawdzanie skladni BUILD_FULL_PORTABLE_ZIP.ps1...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=Join-Path $env:DSE_BUILD_ROOT 'BUILD_FULL_PORTABLE_ZIP.ps1'; if(-not (Test-Path -LiteralPath $p)){Write-Host '[PS FILE FAIL] Brak BUILD_FULL_PORTABLE_ZIP.ps1. Najpierw wypakuj cala paczke ZIP.' -ForegroundColor Red; exit 2}; $b=[IO.File]::ReadAllBytes($p); if($b.Length -lt 3 -or $b[0] -ne 239 -or $b[1] -ne 187 -or $b[2] -ne 191){Write-Host '[PS ENCODING FAIL] BUILD_FULL_PORTABLE_ZIP.ps1 musi byc zapisany jako UTF-8 z BOM dla Windows PowerShell 5.1.' -ForegroundColor Red; exit 1} else {Write-Host '[PS ENCODING PASS] UTF-8 BOM' -ForegroundColor Green}"
if errorlevel 2 (
  echo.
  echo BRAK PELNEJ PACZKI BUILD. NAJPIERW WYPakuj CALY ZIP DO FOLDERU.
  pause
  exit /b 2
)
if errorlevel 1 (
  echo.
  echo BUILD SCRIPT MA NIEPRAWIDLOWE KODOWANIE. LAUNCHER EXE I ZIP NIE ZOSTALY UTWORZONE.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=Join-Path $env:DSE_BUILD_ROOT 'BUILD_FULL_PORTABLE_ZIP.ps1'; if(-not (Test-Path -LiteralPath $p)){Write-Host '[PS FILE FAIL] Brak BUILD_FULL_PORTABLE_ZIP.ps1.' -ForegroundColor Red; exit 2}; $tokens=$null; $errors=$null; [void][System.Management.Automation.Language.Parser]::ParseFile($p,[ref]$tokens,[ref]$errors); if($errors.Count -gt 0){$errors | ForEach-Object { Write-Host ('[PS SYNTAX FAIL] ' + $_.Message) -ForegroundColor Red }; exit 1} else {Write-Host '[PS SYNTAX PASS]' -ForegroundColor Green}"
if errorlevel 2 (
  echo.
  echo BRAK PELNEJ PACZKI BUILD. NAJPIERW WYPakuj CALY ZIP DO FOLDERU.
  pause
  exit /b 2
)
if errorlevel 1 (
  echo.
  echo BUILD SCRIPT MA BLAD SKLADNI. LAUNCHER EXE I ZIP NIE ZOSTALY UTWORZONE.
  pause
  exit /b 1
)

echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%DSE_BUILD_ROOT%BUILD_FULL_PORTABLE_ZIP.ps1"
if errorlevel 1 (
  echo.
  echo BUILD LAUNCHERA EXE I FULL PORTABLE NIE POWIODL SIE.
  pause
  exit /b 1
)

echo.
echo BUILD ZAKONCZONY POWODZENIEM. ZALECANY PLIK: DS_Estimate_1_2_URUCHOM.exe
if exist "%DSE_BUILD_ROOT%publish" explorer "%DSE_BUILD_ROOT%publish"
exit /b 0
