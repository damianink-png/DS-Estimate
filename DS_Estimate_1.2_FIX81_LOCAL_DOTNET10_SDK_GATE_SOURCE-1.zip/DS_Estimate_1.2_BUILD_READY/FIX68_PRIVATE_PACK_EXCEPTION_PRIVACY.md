# DS Estimate FIX68 — bezpieczne komunikaty błędów ekstrakcji

Baza: FIX67 (zweryfikowany pełny ZIP).

## Problem

`build_private_analysis_pack.py` zwracał w przypadku wyjątku tekst
`EXTRACT_ERROR: <typ>: <pełny komunikat>`. Komunikat biblioteki może zawierać
ścieżkę bezwzględną, dane klienta lub poufny fragment dokumentu. Ponieważ
wynik przechodzi przez filtr linii technicznych, tekst zawierający np. `CNC`
mógł trafić do prywatnego ZIP.

## Poprawka

Zachowujemy wyłącznie typ wyjątku, bez tekstu błędu. Nie zmieniamy normalnej
ekstrakcji, manifestu, danych wyceny ani logiki OCR/PDF/STEP/BOM/CNC.

## Weryfikacja

`python tests/run_fix68_private_pack_exception_privacy.py` — wstrzyknięta
awaria XLSX z poufną ścieżką i identyfikatorem, rzeczywisty ZIP i CRC,
ponowna ekstrakcja poprawnego XLSX. Przed poprawką test kończył się exit 1.

Brak kompilacji .NET i xUnit bez dedykowanego prywatnego CI.
