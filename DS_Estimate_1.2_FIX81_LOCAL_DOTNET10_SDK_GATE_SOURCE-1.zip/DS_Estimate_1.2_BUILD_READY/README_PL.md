﻿# DS Estimate 1.2 — MINIMAL UI

Wersja 1.2 rozwija silnik 1.1 bez zmiany jego logiki geometrii. Główna zmiana to uproszczony workflow wyceny.

## FIX21 — bezpieczny limit OCR dużych arkuszy PDF

- Rasteryzacja OCR respektuje limit megapikseli także dla ponadwymiarowych arkuszy.
- Nie zmieniono rozdzielczości OCR dla zwykłych rysunków mieszczących się w limicie.
- Test: `python tests/run_fix21_pdf_raster_budget.py`.

## FIX20 — integracje open-source zweryfikowane w kodzie

- STEP wykrywa teraz kandydatów kieszeni na podstawie dokładnych ścian BREP w głównym kierunku obróbki, według wzorca przeanalizowanego w OpenMill.
- Liczba kieszeni wpływa na ocenę złożoności CNC i jest widoczna w raporcie jako kandydat wymagający potwierdzenia technologa.
- Opcjonalny Docling wzbogaca lokalny odczyt struktury dokumentów po ustawieniu `DSE_ENABLE_DOCLING=1`.
- Brak opcjonalnych bibliotek nie blokuje zwykłej analizy ani pracy portable.

## FIX19 — dokładniejsza analiza wielostronicowych PDF

- OCR zachowuje dotychczasowy limit zasobów, ale wybiera strony z całego dokumentu zamiast wyłącznie jego początku.
- Pierwsza i ostatnia strona zawsze są objęte próbą; raport podaje dokładne numery przeanalizowanych stron.
- Naprawiono fałszywe zatrzymanie bramki FIX18 i usunięto zdublowaną funkcję silnika STEP.
- Nowa kontrola: `python tests/run_fix19_document_intelligence.py`.

## FIX18 — bezpieczne wydanie oferty
- Pojedyncze zadanie STEP ma aktywnie monitorowany limit pamięci; po zatrzymaniu można wznowić analizę z checkpointu/cache.
- Eksport oferty XLSX wymaga kompletnego wyniku albo jawnego wyjątku z powodem, osobą, czasem i odciskiem stanu.
- Każdy eksport zapisuje snapshot SHA-256 dokumentów, analizy, ustawień, kalibracji i silników.
- Walidacja historii jest chronologiczna, nie rozdziela rewizji rodziny i pokazuje MAPE, bias, P90 oraz rolling backtest od 20 projektów.
- Ustawienia mają panel stanu lokalnych silników i RAM oraz bezpieczny restart bezczynnych workerów STEP.
- Golden set firmy ma gotowy walidator i pusty szablon 20–50 realnych projektów; nie wprowadzono danych sztucznych ani zmian współczynników.
- Build sam testuje protokół cache; pełny test trzech buildów uruchamia `VERIFY_FIX18_BUILD_CACHE_CYCLE.cmd`.

## FIX17 — Build Resume & Runtime Health
- Build używa weryfikowanego cache dla publikacji .NET i runtime Python/CAD; do cache trafiają wyłącznie wyniki po kontroli pliku EXE/importów, a pełna bramka wydania nadal uruchamia się zawsze.
- Każdy build zapisuje `publish\BUILD_REPORT_FIX17.txt` i `.json`, także po błędzie.
- Workery STEP są automatycznie recyklingowane między zadaniami po limicie zadań, czasu lub pamięci.
- Kalibracja historii od 6 projektów korzysta z niezależnego holdoutu; pogorszenie MAPE blokuje zmianę profilu.
- Kompaktowa karta „Gotowość wyceny” prowadzi bezpośrednio do brakujących danych, procesów lub stawek i nie akceptuje nierozpoznanego gatunku materiału jako gotowej podstawy.
- Pełna bramka przed wydaniem uruchamia zarówno regresje Python, jak i testy jednostkowe C# przez `dotnet test`.

## FIX16 — decyzje i wiarygodność
- Karta scenariuszy pokazuje wpływ zmiany ceny materiału i czasów procesów na koszt oraz P50. Nie uruchamia ponownie STEP/OCR i nie zmienia zapisanej wyceny.
- Jawne gięcie lub walcowanie z dokumentacji trafia do routingu jako operacja bez stawki, dopóki nie zostaną uzupełnione dane technologiczne.
- Kalibracja plikowa jest stosowana po modelu historycznym, nie składa się wielokrotnie i obejmuje procesy oraz materiał.
- Raport diagnostyczny zapisuje patch i hashe użytych silników.
- DS Estimate nie udaje systemu CAM: true-shape nesting i automatyczne rozwijanie blach wymagają osobnej, zweryfikowanej integracji.

### FIX16E — stabilne zamykanie STEP workera

- persistent worker kończy się poprawnie po `__quit__`, bez zawieszenia w OCP,
- samodzielny analizator STEP i batch pre-scan mają tę samą ochronę,
- test cold-start + dwa zadania + quit ma realistyczny limit 60 sekund i nadal
  zatrzymuje build przy rzeczywistym błędzie.

### FIX16D — stabilna bramka CadQuery/OCP

- usuwa `0xC0000005` występujący po prawidłowym wyniku 17/17 testu R9.0.7,
- zabezpiecza wszystkie testy ładujące CadQuery/OCP, także pełny stress-test,
- nadal zatrzymuje build przy rzeczywistym FAIL, timeoutie lub awarii przed
  ukończeniem kontroli.

### FIX16C — poprawne zakończenie testu parametrycznego

- usuwa fałszywe zatrzymanie builda po komunikacie `PARAMETRIC PASS=61 FAIL=0`,
- omija wyłącznie niestabilne finalizatory CadQuery/OCP w embedded Python,
- nadal zatrzymuje build przy każdym rzeczywistym błędzie testu.

### FIX16B — poprawka kompilacji

- usuwa błędy CS0136 (`label`, `family`) zgłoszone przez `dotnet publish`,
- zachowuje wszystkie usprawnienia FIX16A i FIX16,
- dodaje kontrolę regresji do bramki wydania i budowania FULL PORTABLE.

### FIX16A — utwardzenie
- Profile kalibracji są odporne na puste mapy i różną wielkość liter w kodach.
- Mieszane gatunki materiału są kalibrowane według udziału kosztowego, więc droższy gatunek nie jest zaniżany przez prostą średnią masową.
- Scenariusze what-if nie mogą wprowadzić `NaN`/`Infinity` do wyniku.
- Niemieckie `Kanten` nie jest już samo w sobie uznawane za gięcie.

## Główny workflow
1. Dodaj pliki / ZIP / folder.
2. Kliknij **LICZ WYCENĘ**.
3. Zakładka **Wycena** pokazuje cenę, masę, otwory, spoiny, malowanie i procesy.
4. Proces możesz zaznaczyć/odznaczyć lub poprawić czas; przeliczany jest koszt, bez pełnego restartu analizy.
5. **Szczegóły** zawierają detale i ryzyka tylko wtedy, gdy są potrzebne.

## Ustawienia
Na pierwszym ekranie pozostają najważniejsze stawki i narzut. Parametry modelu technologicznego oraz limity stanowisk są schowane w **Trybie eksperckim**.

## Silnik 1.1 zachowany
- staged STEP checkpoints i resume,
- progress-aware watchdog dla głównego złożenia,
- Hole Engine 3.0,
- topology-only CNC wyłączone,
- inkrementalne przeliczanie malowania i procesów,
- Source Guard / Protected Data Fusion,
- maks. dwa workery OCP.

## Build
```powershell
.\BUILD_FULL_PORTABLE_ZIP.cmd
```

Po udanym buildzie: `publish\DS_Estimate_1_2_URUCHOM.exe`.

Kolejne uruchomienie wykorzysta bezpieczny cache. Świeży build diagnostyczny można wymusić poleceniem:
```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\BUILD_FULL_PORTABLE_ZIP.ps1 -NoBuildCache
```

Autor: Damian Szymczyk

## FIX14 — bezpieczeństwo dużych analiz
- Duże bazy historyczne są domyślnie skanowane bez OCR skanów PDF.
- Resource Governor ogranicza ciężkie silniki przy małym zapasie RAM.
- Skan historii można anulować; pełne analizy kandydatów nie są trzymane wszystkie naraz w pamięci.
- Jeśli brakuje bezpiecznej masy lub istnieje ryzyko blokujące, aplikacja pokazuje **CENA OFERTOWA NIE WYZNACZONA** oraz osobno **koszt rozpoznanego zakresu**.
- Niepełny STEP nie blokuje liczenia: masa i powierzchnia mogą być rekonstruowane per rodzina z BOM/PDF/DXF/STEP, ale częściowy wynik nie jest automatycznie traktowany jako pełny projekt.
