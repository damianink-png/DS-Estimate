## FIX16A — Reliability Hardening
FIX16A utwardza dane brzegowe bez zmiany bazowych współczynników: normalizuje mapy `calibration.json`, waży korekty mieszanego materiału jego udziałem kosztowym, chroni what-if przed wartościami niefinitywnymi oraz usuwa fałszywe rozpoznanie niemieckiego słowa `Kanten` jako gięcia. Raport identyfikuje patch i obejmuje hashem także parser tabelaryczny.

## FIX16 — Decision Support / Trust Hardening
FIX16 domyka warstwę zaufania z FIX15: kalibracja materiału i procesów jest teraz rzeczywiście używana, idempotentna i stosowana dopiero po modelu historycznym. Dodano bezpieczne scenariusze wpływu ceny materiału i czasów procesów, widoczne w UI, XLSX i raporcie. Jawne gięcie/walcowanie jest wykrywane wielojęzycznie i pozostaje pozycją bez stawki, dopóki dokumentacja nie pozwala go policzyć. Aplikacja nie przedstawia uproszczonego bbox jako true-shape nestingu ani nie deklaruje automatycznego rozwinięcia blach.

## FIX14 — All-In Stability + Partial Quote
FIX14 wzmacnia odporność aplikacji na bardzo duże foldery, A0/A1 i niepełne modele. Ciężkie silniki są uruchamiane pod kontrolą zapasu RAM, OCR jest strumieniowany strona-po-stronie, a skan historii domyślnie pomija OCR skanów i może być anulowany. Przy niepełnym projekcie program rekonstruuje masę oraz koszt materiału per rodzina BOM, lecz nie udaje kompletnej oferty: zamiast `0 PLN` pokazuje `CENA OFERTOWA NIE WYZNACZONA` oraz koszt rozpoznanego zakresu. NDT, powłoki i wymagania pozostają lokalne per rodzina. Sanity Check Engine wyłapuje wyniki wewnętrznie niespójne przed pokazaniem ich jako wiarygodne.

## FIX12E — Hybrid Project Reconstruction
FIX12E usuwa zależność powierzchni malowania od jednego kompletnego modelu 3D. Dla root BOM powierzchnia jest rekonstruowana per rodzina z najlepszego źródła (jawna wartość, lokalny STEP, DXF z grubością, profil/BOM, fallback masowy), bez podwójnego liczenia. Przy braku bezpiecznej masy projektu koszt rozpoznanych operacji pozostaje widoczny, ale aplikacja nie nazywa go ceną rekomendowaną.

## FIX12D — Document Family Resolver
FIX12D rozwiązuje przypadek dużych pakietów z wieloma PDF/DXF/STEP i hierarchicznymi listami części. Root BOM jest rozwijany rekurencyjnie przez podzespoły, a dowody technologiczne są ograniczane do rodzin należących do wycenianego drzewa. Słabo rozpoznany lub wielokorzeniowy BOM pozostaje tylko audytem i nie może odciąć dokumentów. Częściowy STEP nie może być masą całego projektu, różne materiały pozycji nie tworzą globalnego konfliktu, a indeksy A20/A40/A41 w legendach norm/NDT nie są już rozpoznawane jako rozmiar spoiny. Pakiet prywatny V2 zachowuje potrzebne liczby kosztowe bez dołączania plików źródłowych.

## FIX12A Shadow CAPP — 2026-08-23
FIX12A dodaje bezinwazyjny Dual-Run pod przyszły CAPP. Nowe kontrakty grafu technologicznego analizują wynik FIX11 równolegle, ale nie mają prawa zmiany ceny. Raport diagnostyczny pokazuje stany geometrii, zależności procesów, EvidenceBinding i wielowymiarową pewność. Pełny resolver FaceSignature/Contour/BOM↔STEP pozostaje zakresem FIX12B.

# DS Estimate 1.2 — MINIMAL UI

1.2 upraszcza obsługę bez cofania zmian silnika 1.1. Główna wycena ma tylko `Wycena` i `Szczegóły`. Najważniejsze ustawienia są widoczne od razu; parametry eksperckie pozostają dostępne, ale schowane.

## FIX19 — Document Intelligence & Release Gate Repair

FIX19 zwiększa szansę znalezienia uwag produkcyjnych, rewizji i danych z tabelek w wielostronicowych PDF bez zwiększania zużycia pamięci. OCR obejmuje reprezentatywną próbę całego dokumentu i zawsze pierwszą oraz ostatnią stronę. Diagnostyka pokazuje numery faktycznie sprawdzonych stron. Naprawiono również fałszywy błąd testu bezpiecznego wyjątku FIX18 oraz usunięto zdublowaną funkcję pomocniczą w analizatorze STEP.

## FIX18 — Release Safety

FIX18 zabezpiecza ostatni metr procesu ofertowania: pojedynczy STEP jest monitorowany także podczas aktywnego zadania, niekompletnej oferty nie można wyeksportować bez jawnego uzasadnienia, a gotowy XLSX otrzymuje zamrożony odcisk dokumentów, analizy, ustawień, kalibracji i silników. Kalibracja używa chronologicznego podziału rodzin bez przecieku rewizji, mierzy MAPE/bias/P90 i od 20 projektów wykonuje rolling backtest. Dodano lokalny panel zdrowia silników, rzeczywisty test cyklu cache oraz uczciwy, pusty szablon golden setu firmy.

## FIX17 — Build Resume & Runtime Health

FIX17 skraca ponowne buildy przez cache kontrolowany hashami, ale nie osłabia pełnej bramki. Dodaje raport techniczny po sukcesie i błędzie, bezpieczny recykling procesów CadQuery/OCP, niezależny holdout dla kalibracji oraz kompaktową kontrolę gotowości wyceny. Profil firmy nie jest automatycznie zmieniany, jeżeli wynik na niewykorzystanych do uczenia projektach pogarsza MAPE ponad bezpieczny próg.

## FIX11 — korekta logiki technologicznej

FIX11 nie zmienia prostego UI 1.2. Poprawia logikę wyceny dla obróbki po spawaniu, częściowego pokrycia DXF, szacunkowego nestingu oraz automatycznie wyznaczanej powierzchni malowania. W przypadkach, gdzie dokument potwierdza proces, ale program nie zna wystarczająco dokładnie jego zakresu, wynik pozostaje policzony, lecz z niższą pewnością i szerszym zakresem ceny.

### FIX12B COST REALITY
FIX12B wzmacnia realność kosztową dużych konstrukcji: ogranicza wpływ uproszczonego nestingu na materiał, rozdziela przygotowanie i ręczne operacje obróbcze, rozszerza czas montażu o złożoność fabrykacji oraz nie pozwala przedstawiać ceny jako kompletnej, jeśli wymagana kooperacja nie ma stawki. Masa z dokumentu o nieznanym zakresie nie konkuruje już z masą całego STEP.

### FIX13 Historical Intelligence
DS Estimate może teraz kalibrować planowane czasy na podobnych zakończonych realizacjach, ale nie nadpisuje ręcznych decyzji operatora. BOM jest wykorzystywany do rozbicia materiałów i półfabrykatów, spawanie może być liczone per rodzina dokumentu, a CNC otrzymało strukturalny model cech. W UI pojawiła się pewność poszczególnych składników ceny wraz z informacją, jakie dane najbardziej podniosą jakość wyceny. Przycisk prywatnego eksportu został usunięty z głównego interfejsu.
