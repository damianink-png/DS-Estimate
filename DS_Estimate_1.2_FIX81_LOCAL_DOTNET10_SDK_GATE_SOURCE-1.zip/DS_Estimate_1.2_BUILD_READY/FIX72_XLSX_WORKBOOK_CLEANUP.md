# DS Estimate 1.2 FIX72 — zamykanie XLSX

Baza: FIX71 (311 plików). Zmiana w `engines/python/build_private_analysis_pack.py`:
po `openpyxl.load_workbook(..., read_only=True)` zawsze wykonuj `wb.close()`
w `finally`, także przy błędzie odczytu arkusza. Eliminuje pozostawianie
uchwytów plików XLSX/XLSM (szczególnie istotne na Windows).

Test FIX72 uruchamia rzeczywisty ekstraktor, prawdziwy plik XLSX oraz
kontrolowane awarie arkusza i zamykania. Test jest dołączony do CMD,
PowerShell i przygotowanego prywatnego Windows CI. Brak zmian C#,
kalkulacji kosztów, OCR, PDF, STEP, BOM, CNC ani licencji.

Uwaga: testy Python nie zastępują kompilacji .NET 10 / Avalonia / xUnit.
