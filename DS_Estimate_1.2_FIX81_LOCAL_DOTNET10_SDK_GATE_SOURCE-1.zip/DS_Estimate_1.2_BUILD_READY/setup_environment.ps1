﻿$ErrorActionPreference = "Stop"

try { chcp 65001 > $null } catch {}
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = New-Object System.Text.UTF8Encoding($false)

Set-Location $PSScriptRoot

Write-Host ""
Write-Host "=== DS Estimate 1.2 MINIMAL UI - przygotowanie środowiska ===" -ForegroundColor Cyan

Write-Host "`n[1/9] .NET 10"
$dotnetVersion = dotnet --version
Write-Host "OK: dotnet $dotnetVersion" -ForegroundColor Green

if (-not $dotnetVersion.StartsWith("10.")) {
    Write-Host "UWAGA: projekt jest przeznaczony dla .NET 10." -ForegroundColor Yellow
}

Write-Host "`n[2/9] Python"
$pythonCmd = $null

if (Get-Command python -ErrorAction SilentlyContinue) {
    $pythonCmd = "python"
} elseif (Get-Command py -ErrorAction SilentlyContinue) {
    $pythonCmd = "py"
}

if (-not $pythonCmd) {
    Write-Host "BŁĄD: Python nie został znaleziony." -ForegroundColor Red
    exit 1
}

$pyVersion = (& $pythonCmd -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')").Trim()
Write-Host "Python $pyVersion"

$parts = $pyVersion.Split('.')
$major = [int]$parts[0]
$minor = [int]$parts[1]

if ($major -ne 3 -or $minor -gt 12 -or $minor -lt 9) {
    Write-Host "BŁĄD: dla instalacji CadQuery przez pip użyj Python 3.9-3.12. Wykryto $pyVersion." -ForegroundColor Red
    exit 1
}

Write-Host "`n[3/9] Wirtualne środowisko .venv"

if (-not (Test-Path ".\.venv\Scripts\python.exe")) {
    & $pythonCmd -m venv ".venv"
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}

$venvPython = ".\.venv\Scripts\python.exe"

& $venvPython -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "`n[4/9] Geometry Engine + PDF/OCR"

& $venvPython -m pip install -r ".\engines\python\requirements.txt"
if ($LASTEXITCODE -ne 0) {
    Write-Host "BŁĄD: instalacja bibliotek Python nie powiodła się." -ForegroundColor Red
    exit $LASTEXITCODE
}


Write-Host "`n[5/9] Silnik OCR Tesseract"

function Find-TesseractExe {
    $candidates = @()

    $fromPath = Get-Command tesseract -ErrorAction SilentlyContinue
    if ($fromPath) {
        $candidates += $fromPath.Source
    }

    $candidates += @(
        (Join-Path $PSScriptRoot "tools\ocr\tesseract.exe"),
        "C:\Program Files\Tesseract-OCR\tesseract.exe",
        "C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        (Join-Path $env:LOCALAPPDATA "Programs\Tesseract-OCR\tesseract.exe")
    )

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path $candidate)) {
            return (Resolve-Path $candidate).Path
        }
    }

    return $null
}

$tesseractExe = Find-TesseractExe

if (-not $tesseractExe) {
    Write-Host "Tesseract nie jest zainstalowany. Próba instalacji przez winget..." -ForegroundColor Yellow

    if (Get-Command winget -ErrorAction SilentlyContinue) {
        winget install --id UB-Mannheim.TesseractOCR --exact --silent --accept-package-agreements --accept-source-agreements

        if ($LASTEXITCODE -ne 0) {
            Write-Host "UWAGA: winget nie zainstalował Tesseract automatycznie." -ForegroundColor Yellow
        }

        Start-Sleep -Seconds 2
        $tesseractExe = Find-TesseractExe
    }
}

if (-not $tesseractExe) {
    Write-Host "" 
    Write-Host "BŁĄD OCR: nie znaleziono tesseract.exe." -ForegroundColor Red
    Write-Host "Zainstaluj Tesseract OCR dla Windows (build UB Mannheim), a potem uruchom setup ponownie." -ForegroundColor Yellow
    Write-Host "Możesz również użyć:" -ForegroundColor Yellow
    Write-Host "winget install --id UB-Mannheim.TesseractOCR --exact" -ForegroundColor Yellow
    exit 1
}

Write-Host "Tesseract: $tesseractExe" -ForegroundColor Green

Write-Host "`n[6/9] Języki OCR: PL + EN + DE + FR"

$tessdataDir = Join-Path $PSScriptRoot "tools\ocr\tessdata"
New-Item -ItemType Directory -Force -Path $tessdataDir | Out-Null

$ocrLanguages = @("pol", "eng", "deu", "fra")
foreach ($lang in $ocrLanguages) {
    $target = Join-Path $tessdataDir "$lang.traineddata"

    if (-not (Test-Path $target)) {
        $url = "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/$lang.traineddata"

        try {
            Write-Host "Pobieranie modelu OCR: $lang"
            Invoke-WebRequest -Uri $url -OutFile $target -UseBasicParsing
        } catch {
            Write-Host "BŁĄD: nie udało się pobrać modelu OCR '$lang'." -ForegroundColor Red
            if (Test-Path $target) {
                Remove-Item $target -Force -ErrorAction SilentlyContinue
            }
            exit 1
        }
    }
}

foreach ($lang in $ocrLanguages) {
    $target = Join-Path $tessdataDir "$lang.traineddata"
    if (-not (Test-Path $target)) {
        Write-Host "BŁĄD: brak $lang.traineddata" -ForegroundColor Red
        exit 1
    }
}

Write-Host "Modele OCR: pol + eng + deu + fra" -ForegroundColor Green

Write-Host "`n[7/9] Kontrola OCR bez plików testowych"

$env:TESSDATA_PREFIX = $tessdataDir
Write-Host "TESSDATA_PREFIX: $env:TESSDATA_PREFIX"

$langOutput = @(& $tesseractExe --list-langs 2>&1)
$missingLangs = @()
foreach ($lang in $ocrLanguages) {
    if (-not ($langOutput -contains $lang)) {
        $missingLangs += $lang
    }
}

if ($missingLangs.Count -gt 0) {
    Write-Host "BŁĄD: Tesseract nie widzi języków: $($missingLangs -join ', ')" -ForegroundColor Red
    exit 1
}

& $venvPython -c "import pytesseract, PIL, pypdf, fitz, ezdxf; print('OCR/PDF/DXF Python: OK')"
if ($LASTEXITCODE -ne 0) {
    Write-Host "BŁĄD: biblioteki OCR/PDF nie działają." -ForegroundColor Red
    exit $LASTEXITCODE
}

Write-Host "OCR/PDF/DXF: OK; języki pol + eng + deu + fra" -ForegroundColor Green

Write-Host "`n[8/9] Test CadQuery"

& $venvPython -c "import cadquery as cq; b=cq.Workplane('XY').box(10,20,30).val(); print('CadQuery OK, volume=', b.Volume())"
if ($LASTEXITCODE -ne 0) {
    Write-Host "BŁĄD: CadQuery nie działa poprawnie." -ForegroundColor Red
    exit $LASTEXITCODE
}

Write-Host "`n[9/9] NuGet restore"


dotnet restore ".\DS_Estimate.sln"
if ($LASTEXITCODE -ne 0) {
    Write-Host "BŁĄD: dotnet restore zakończył się niepowodzeniem." -ForegroundColor Red
    exit $LASTEXITCODE
}

Write-Host ""
Write-Host "GOTOWE." -ForegroundColor Green
Write-Host "Uruchom: .\START_DS_ESTIMATE.cmd" -ForegroundColor Green
