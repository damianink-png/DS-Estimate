@echo off
setlocal
cd /d "%~dp0"
set "PY=python"
where py >nul 2>&1 && set "PY=py -3.12"
echo === DS Estimate 1.2 BASELINE - FULL RELEASE GATE ===
where dotnet >nul 2>&1 || (echo [FAIL] Brak dotnet SDK & exit /b 1)
rem FIX81: require the selected .NET 10 SDK, not just any dotnet host.
%PY% tests\verify_dotnet_sdk.py || exit /b 1
rem FIX78: local Windows release must prove fresh executed xUnit tests, not just dotnet exit 0.
%PY% tests\clear_stale_trx.py || exit /b 1
dotnet test tests\DSEstimate.Core.Tests\DSEstimate.Core.Tests.csproj -c Release --nologo --logger "trx;LogFileName=ds-estimate-xunit.trx" --results-directory TestResults || exit /b 1
%PY% tests\verify_dotnet_trx.py TestResults\ds-estimate-xunit.trx --require-results --min-executed 60 --reject-skipped || exit /b 1
%PY% tests\run_r7_regression.py || exit /b 1
%PY% tests\run_r7_parametric.py || exit /b 1
%PY% tests\run_r8_weak_links.py || exit /b 1
%PY% tests\run_r9_0_3_public_bom_interop.py || exit /b 1
%PY% tests\run_r9_0_6b_2d_document_hardening.py || exit /b 1
%PY% tests\run_r9_0_7_step_assembly_performance.py || exit /b 1
%PY% tests\run_r9_2_3d_adaptive_scheduler_source_hierarchy.py || exit /b 1
%PY% tests\run_r9_3_0_fix5_minimal_ui_fast_import.py || exit /b 1
%PY% tests\run_r9_3_0_fix7_report_findings.py || exit /b 1
%PY% tests\run_r9_3_0_fix8_dependency_cache.py || exit /b 1
%PY% tests\run_r9_3_0_fix9_report_correctness.py || exit /b 1
%PY% tests\run_fix11_technology_scope.py || exit /b 1
%PY% tests\run_fix12a_shadow_graph.py || exit /b 1
%PY% tests\run_fix12a_titleblock_semantics.py || exit /b 1
%PY% tests\run_fix12b_cost_reality.py || exit /b 1
%PY% tests\run_fix12c_manual_override_private_pack.py || exit /b 1
%PY% tests\run_fix12d_resolver_scope.py || exit /b 1
%PY% tests\run_fix12e_hybrid_surface.py || exit /b 1
%PY% tests\run_fix13_historical_intelligence.py || exit /b 1
%PY% tests\run_fix13a_hardening.py || exit /b 1
%PY% tests\run_fix14_all_in.py || exit /b 1
%PY% tests\run_fix15_trust_foundation.py || exit /b 1
%PY% tests\run_fix16_decision_support.py || exit /b 1
%PY% tests\run_fix16a_reliability.py || exit /b 1
%PY% tests\run_fix16b_compile_guard.py || exit /b 1
%PY% tests\run_fix16c_embedded_exit_guard.py || exit /b 1
%PY% tests\run_fix16d_native_exit_guard.py || exit /b 1
%PY% tests\run_fix16e_worker_shutdown_guard.py || exit /b 1
%PY% tests\run_fix17_build_runtime_calibration.py || exit /b 1
%PY% tests\run_fix18_release_safety.py || exit /b 1
%PY% tests\run_fix19_document_intelligence.py || exit /b 1
%PY% tests\run_fix20_open_source_integrations.py || exit /b 1
%PY% tests\run_fix21_pdf_raster_budget.py || exit /b 1
%PY% tests\run_fix22_pdf_mixed_scans.py || exit /b 1
%PY% tests\run_fix23_tiled_inline_pdf.py || exit /b 1
%PY% tests\run_fix24_titleblock_raster_pdf.py || exit /b 1
%PY% tests\run_fix25_large_tiled_pdf.py || exit /b 1
%PY% tests\run_fix26_pdf_page_evidence.py || exit /b 1
%PY% tests\run_fix27_pdf_text_layer_provenance.py || exit /b 1
%PY% tests\run_fix28_pdf_drawing_number_layout.py || exit /b 1
%PY% tests\run_fix29_pdf_exact_bom_links.py --require-real-pdf || exit /b 1
%PY% tests\run_fix30_pdf_bom_step_links.py --require-real-pdf || exit /b 1
%PY% tests\run_fix31_step_path_identity.py || exit /b 1
%PY% tests\run_fix32_empty_step_guard.py || exit /b 1
%PY% tests\run_fix33_ci_trx_guard.py || exit /b 1
%PY% tests\run_fix34_trx_partial_pass_guard.py || exit /b 1
%PY% tests\run_fix35_trx_result_discovery_guard.py || exit /b 1
%PY% tests\run_fix36_launcher_compile_coverage.py || exit /b 1
%PY% tests\run_fix37_trx_minimum_discovery.py || exit /b 1
%PY% tests\run_fix38_xunit_discovery_evidence.py || exit /b 1
%PY% tests\run_fix39_ci_build_log_evidence.py || exit /b 1
%PY% tests\run_fix40_xunit_execution_evidence.py || exit /b 1
%PY% tests\run_fix41_ci_python_engine_gate.py || exit /b 1
%PY% tests\run_fix42_ci_real_pdf_dependency.py || exit /b 1
%PY% tests\run_fix43_real_pdf_skip_guard.py || exit /b 1
%PY% tests\run_fix44_trx_freshness_guard.py || exit /b 1
%PY% tests\run_fix45_dotnet_first_ci_gate.py || exit /b 1
%PY% tests\run_fix46_dotnet_sdk_evidence.py || exit /b 1
%PY% tests\run_fix47_launcher_pe_evidence.py || exit /b 1
%PY% tests\run_fix48_trx_skip_guard.py || exit /b 1
%PY% tests\run_fix49_trx_nonpass_counter_guard.py || exit /b 1
%PY% tests\run_fix50_trx_duplicate_identity_guard.py || exit /b 1
%PY% tests\run_fix51_trx_verification_evidence.py || exit /b 1
%PY% tests\run_fix52_dotnet_solution_output_evidence.py || exit /b 1
%PY% tests\run_fix53_managed_dll_metadata_guard.py || exit /b 1
%PY% tests\run_fix54_metadata_stream_directory_guard.py || exit /b 1
%PY% tests\run_fix55_metadata_stream_overlap_guard.py || exit /b 1
%PY% tests\run_fix56_xunit_nonempty_discovery.py || exit /b 1
%PY% tests\run_fix57_xunit_discovery_minimum_gate.py || exit /b 1
%PY% tests\run_fix58_xunit_duplicate_discovery_guard.py || exit /b 1
%PY% tests\run_fix59_xunit_qualified_name_guard.py || exit /b 1
%PY% tests\run_fix60_xunit_namespace_scope_guard.py || exit /b 1
%PY% tests\run_fix61_xunit_discovery_fatal_diagnostics_guard.py || exit /b 1
%PY% tests\run_fix62_dscompare_desktop_ui.py || exit /b 1
%PY% tests\run_fix63_local_storage_dnd_guard.py || exit /b 1
%PY% tests\run_fix64_local_export_uri_guard.py || exit /b 1
%PY% tests\run_fix65_private_pack_input_isolation.py || exit /b 1
%PY% tests\run_fix66_private_pack_atomic_output.py || exit /b 1
%PY% tests\run_fix67_private_pack_deterministic_order.py || exit /b 1
%PY% tests\run_fix68_private_pack_exception_privacy.py || exit /b 1
%PY% tests\run_fix69_private_pack_zip_metadata_determinism.py || exit /b 1
%PY% tests\run_fix70_release_gate_recent_regressions.py || exit /b 1
%PY% tests\run_fix71_private_pack_temp_isolation.py || exit /b 1
%PY% tests\run_fix72_xlsx_workbook_cleanup.py || exit /b 1
%PY% tests\run_fix73_pdf_reader_cleanup.py || exit /b 1
%PY% tests\run_fix74_private_pack_hash_fail_closed.py || exit /b 1
%PY% tests\run_fix75_private_pack_source_mutation_guard.py || exit /b 1
%PY% tests\run_fix76_private_pack_bounded_text_read.py || exit /b 1
%PY% tests\run_fix77_release_real_pdf_gate.py || exit /b 1
%PY% tests\run_fix78_local_release_trx_gate.py || exit /b 1
%PY% tests\run_fix79_ci_release_script_triggers.py || exit /b 1
%PY% tests\run_fix80_private_pack_final_snapshot_guard.py || exit /b 1
%PY% tests\run_fix81_local_dotnet_sdk_gate.py || exit /b 1
%PY% tests\run_fix12a_build_launcher_guard.py || exit /b 1
%PY% tests\run_ds_estimate_1_2_minimal_ui.py || exit /b 1
py -3.12 tests\run_ds_estimate_1_2_powershell_encoding.py
if errorlevel 1 exit /b 1
set DSE_STRESS_FULL=1
%PY% tests\run_r9_0_system_stress.py || exit /b 1
set DSE_STRESS_FULL=
echo.
echo [PASS] DS Estimate 1.2 BASELINE - FULL RELEASE GATE
exit /b 0

