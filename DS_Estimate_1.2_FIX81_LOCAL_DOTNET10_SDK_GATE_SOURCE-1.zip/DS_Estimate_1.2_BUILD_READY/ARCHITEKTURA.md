# DS Estimate 1.2 — architektura

Silnik analizy pozostaje zgodny z 1.1. Zmiana 1.2 dotyczy przede wszystkim warstwy prezentacji i workflow.

## UI
- `Wycena` — wynik, kluczowe cechy, procesy i kompaktowe podsumowanie kosztu.
- `Szczegóły` — detale i ryzyka; informacje pomocnicze nie konkurują z ceną.
- `Ustawienia` — kilka najważniejszych stawek + narzut.
- `Tryb ekspercki` — pozostałe parametry technologiczne/stanowiska.

## Pipeline
Produkcja: Import → Source Guard → STEP/PDF/DXF/BOM → Data Fusion → model fizyczny kosztu → kalibracja historyczna → calibration.json → AutoQuote/Trust → scenariusze what-if.
STEP: import/grouping → features → contacts → joints → surface, z checkpointami i resume.

## FIX16 — warstwa decyzyjna
- `CalibrationLayer.Reset/Apply` oddziela bazowy model fizyczny od korekt historycznych i zewnętrznych; ponowne zastosowanie nie składa mnożników.
- `QuoteScenarioEngine` działa na gotowych liniach kosztowych i wylicza tylko delty materiału/procesu. Nie ma prawa odblokować ceny ani nadpisać P50.
- `SheetMetalReadinessEngine` rozpoznaje jawne wymaganie procesu, ale nie wyznacza geometrii rozwinięcia. Bez parametrów i stawki tworzy nieblokujące ryzyko oraz zewnętrzną operację bez ceny.
- `TrustFoundationEngine` rozróżnia zakres kompletny/częściowy oraz authority źródła; raport dołącza identyfikatory wersji skryptów.

## FIX12A — Shadow CAPP / Dual-Run
Po Evidence Orchestrator wynik FIX11 jest równolegle projektowany do kontraktu:
`Evidence → UniquePartGroup → AssemblyState → ProcessNode → ConfidenceVector`.

Graf FIX12A jest audytowy (`HasPriceAuthority=false`) i nie może nadpisać procesu, godzin, stawek ani ceny FIX11.
Stan geometrii jest jawny w czasie (m.in. `WELDED_ASSEMBLY` i `POST_MACHINED`), dzięki czemu operacja po spawaniu korzysta z gabarytu i masy aktualnego złożenia.
Dowód bez jednoznacznego celu pozostaje kandydatem do rozwiązania w FIX12B zamiast być globalnie przypisywanym do projektu.

## Zasada UX
Użytkownik ma najpierw odpowiedzieć na trzy pytania: ile kosztuje, czy dane są wiarygodne i jakie procesy są wymagane. Diagnostyka jest drugorzędna.
