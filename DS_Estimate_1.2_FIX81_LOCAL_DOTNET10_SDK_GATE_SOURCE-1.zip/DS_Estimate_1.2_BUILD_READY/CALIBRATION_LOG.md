# DS Estimate calibration log

## 1.0.0 — 2026-08-26
- Utworzono oddzielną warstwę `calibration.json`.
- Wszystkie mnożniki są neutralne (1.0 / brak wpisu).
- Brak strojenia pod TEST19/TEST49.

## FIX16 — korekta wykonania warstwy (bez zmiany mnożników)
- `MaterialMultipliers` są teraz rzeczywiście stosowane do kosztu materiału.
- Profil jest stosowany po kalibracji historycznej i jest idempotentny przy ponownym przeliczeniu.
- Profil przyszły, niepoprawny lub nie-neutralny bez wskazania golden set jest odrzucany.
- Wersja danych pozostaje `1.0.0`, a wszystkie mnożniki pozostają neutralne.

## FIX16A — utwardzenie danych (bez zmiany mnożników)
- Klucze są normalizowane bez względu na wielkość liter, a puste mapy są neutralne.
- Mieszane gatunki są ważone udziałem kosztowym przy wyznaczaniu wspólnego mnożnika.
- Nieobsługiwany profil pozostaje widoczny jako odrzucony zamiast być cicho zastępowany.
- Wersja danych nadal wynosi `1.0.0`; wartości mnożników nie zostały zmienione.

Każda przyszła zmiana współczynnika musi wskazać golden case / realizację i metrykę biasu, która ją uzasadnia.
