# Kwantflow → DS Estimate — status po FIX23

## Zweryfikowane źródła

- DS Estimate 1.2 FIX22, baza FIX20; `src/DSEstimate.Core/`, `src/DSEstimate.Infrastructure/`, `engines/python/`, `tests/`.
- Kwantflow `kwantflow-main.zip` z 15.10.2026: `LICENSE` i `package.json` określają **GPL-3.0-only**, wersja `0.13.0`; projekt Tauri/Svelte/TypeScript/Rust.
- Poprawka `DS_Estimate_Kwantflow_PDF_coverage_R1.zip`: osobny kod TypeScript; nie jest włączony do uruchomienia DS Estimate.

## Przeniesione w tym etapie

Nie kopiowano żadnych plików GPL z Kwantflow. FIX23 to niezależna implementacja wykrywania skanów w silniku Python DS Estimate. Pozostają nienaruszone źródła i licencje istniejących komponentów.

## Wartościowe moduły do następnego etapu (wymagają integracji i testów)

| Funkcja Kwantflow | Istniejący punkt integracji DS Estimate | Uwagi |
| --- | --- | --- |
| `src/lib/services/ai-cad-evidence.ts` | `engines/python/analyze_document.py`, `analyze_step.py` | Rozdzielić dane dowodowe od niepewnych sugestii AI; walidować w testach regresyjnych. |
| `src/lib/services/estimate-ai-context.ts` | `src/DSEstimate.Core/ProjectIntelligenceEngines.cs` | Nie zastępować obliczeń CNC odpowiedziami modelu językowego. |
| `src/lib/services/cad-loader.ts` | `engines/python/analyze_step.py`, `analyze_dxf.py` | Ocenić różnice w pokryciu formatów i złożeń, nie dodawać drugiego kernela bez korzyści. |
| `src/lib/services/quote-pdf-document.ts` | `src/DSEstimate.Infrastructure/ExcelExportService.cs` i raporty | Wymaga osobnego adaptera do eksportu; TypeScript nie jest natywnym modułem Avalonia. |
| `src/lib/services/quote-excel-export.ts` | `ExcelExportService.cs` | Porównać kompletność danych i ochronę sum przed integracją. |

## Licencja

GPL-3.0-only zezwala na prywatne modyfikacje i użytkowanie. Przy rozpowszechnianiu połączonego programu obowiązują warunki GPL dotyczące udostępnienia odpowiednich źródeł i zachowania informacji o prawach autorskich. Nie należy przedstawiać obecnego FIX23 jako aplikacji zawierającej Kwantflow.

## Weryfikacja

- 36 osobnych zestawów regresyjnych Python zakończyło się kodem 0 (wykaz w raporcie FIX23); 14/14 asercji w nowym teście.
- Nie wykonano `dotnet test`, kompilacji Avalonia ani pełnego testu stresowego; w środowisku nie ma SDK .NET.
