# DS Estimate 1.2 FIX71 — izolacja plików tymczasowych pakietu prywatnego

Silnik `engines/python/build_private_analysis_pack.py` pomija teraz własne pliki
`.<nazwa-zip>.<losowy-ciąg>.tmp`, jeśli znajdują się w katalogu wyjściowym.
Poprzednia wersja mogła włączyć taki fragment ZIP do manifestu przy ponownym
uruchomieniu po awarii lub podczas równoległego tworzenia paczki.

Wykluczenie jest wąskie: nie pomija zwykłych plików `.tmp` ani plików
przypominających tymczasowe wyniki innych pakietów. Ochrona przed ponownym
wczytaniem gotowego ZIP (FIX65), atomowy zapis (FIX66), kolejność (FIX67),
prywatność (FIX68) i deterministyczne metadane ZIP (FIX69) pozostają.

Test: `python tests/run_fix71_private_pack_temp_isolation.py`.
Dodatkowo test podłączony do pełnej bramki CMD, PowerShell i przygotowanego
prywatnego workflow Windows. Wynik lokalnych testów Python nie stanowi
dowodu kompilacji .NET 10, uruchomienia Avalonia, launchera ani xUnit/TRX.
