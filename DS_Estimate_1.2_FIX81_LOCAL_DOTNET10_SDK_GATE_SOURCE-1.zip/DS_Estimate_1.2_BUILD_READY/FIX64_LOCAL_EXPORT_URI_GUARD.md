# DS Estimate 1.2 FIX64 — local export destination guard

Baseline: full verified FIX63 source package (2026-11-01).

The Avalonia `SaveFilePickerAsync` can return a non-file URI (virtual/cloud
storage). The existing Excel and diagnostic-report exporters require a local
filesystem path. Previously, both handlers unconditionally accessed
`file.Path.LocalPath`, potentially throwing before the exporter was called.

The two handlers now use `LocalSavePath(IStorageFile?)`, which checks
`file.Path.IsFile` before accessing `LocalPath`. Cancelling the picker is
silent; selecting a non-local destination shows a user-facing status message.
The diagnostic exporter now also catches I/O exceptions, as Excel already did.

This change is confined to Avalonia event handlers, one structural regression
script, this note, and the private Windows workflow. No pricing, OCR, PDF,
STEP, assembly, BOM, CNC, cache, licensing or engine algorithms are changed.

The FIX64 test is structural, not proof of Avalonia runtime execution. A
Windows .NET 10 build and actual UI test are still required.
