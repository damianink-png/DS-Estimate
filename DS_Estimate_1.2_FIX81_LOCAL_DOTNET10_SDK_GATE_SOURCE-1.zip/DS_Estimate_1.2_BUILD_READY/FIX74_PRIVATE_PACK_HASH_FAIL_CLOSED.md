# DS Estimate 1.2 — FIX74: fail-closed source SHA256

## Zmiana

`engines/python/build_private_analysis_pack.py` nie może generować pozornie
poprawnego `MANIFEST.json`, jeżeli nie udało się odczytać bajtów pliku do
SHA-256. W FIX73 wyjątek podczas hashowania był ignorowany, a pole `sha256`
pozostawało puste. FIX74 przerywa generowanie komunikatem
`SOURCE_HASH_FAILED` bez ujawniania ścieżki ani treści wyjątku.

Poprzedni wynikowy ZIP pozostaje nienaruszony, ponieważ hashowanie odbywa się
przed atomową zamianą pliku wprowadzaną w FIX66. Dotychczasowa izolacja
symlinków, deterministyczna kolejność, czyszczenie XLSX/PDF i filtrowanie
fragmentów technicznych pozostają bez zmian.

## Weryfikacja

`python tests/run_fix74_private_pack_hash_fail_closed.py`

Test wykonuje prawdziwy generator CLI, sprawdza manifest i CRC, następnie
wstrzykuje błąd odczytu pliku, sprawdza niezerowy exit, zachowanie poprzedniego
ZIP oraz brak wycieku danych w komunikacie. Test jest włączony do bramek
CMD, PowerShell i przygotowanego workflow Windows.

Testy Pythona i testy strukturalne NIE są dowodem kompilacji .NET, uruchomienia
Avalonia, Windows launchera, xUnit ani Windows CI. Do tych dowodów nadal
potrzebne jest autoryzowane prywatne środowisko Windows z .NET 10.
