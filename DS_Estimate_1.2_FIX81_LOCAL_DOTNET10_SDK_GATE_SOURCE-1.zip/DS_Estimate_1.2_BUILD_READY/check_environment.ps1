﻿$ErrorActionPreference = "Continue"

try { chcp 65001 > $null } catch {}
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = New-Object System.Text.UTF8Encoding($false)

Set-Location $PSScriptRoot

Write-Host ""
Write-Host "=== DS Estimate - kontrola środowiska ===" -ForegroundColor Cyan

try {
    Write-Host "dotnet: $(dotnet --version)"
} catch {
    Write-Host "dotnet: BRAK" -ForegroundColor Red
}

if (Test-Path ".\.venv\Scripts\python.exe") {
    & ".\.venv\Scripts\python.exe" --version
    & ".\.venv\Scripts\python.exe" -c "import cadquery, pypdf, fitz, ezdxf, PIL, pytesseract, openpyxl, xlrd; print('Python engines: OK')"
} else {
    Write-Host ".venv: BRAK" -ForegroundColor Yellow
}

if (Get-Command tesseract -ErrorAction SilentlyContinue) {
    tesseract --version | Select-Object -First 1
} elseif (Test-Path "C:\Program Files\Tesseract-OCR\tesseract.exe") {
    & "C:\Program Files\Tesseract-OCR\tesseract.exe" --version | Select-Object -First 1
} else {
    Write-Host "Tesseract: nie znaleziono (STEP i PDF tekstowy nadal działają)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Projekt:"
Test-Path ".\src\DSEstimate.App\DSEstimate.App.csproj"


Write-Host ""
Write-Host "OCR szczegóły:" -ForegroundColor Cyan

$tessCandidates = @(
    (Get-Command tesseract -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source -ErrorAction SilentlyContinue),
    "C:\Program Files\Tesseract-OCR\tesseract.exe",
    "C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
    (Join-Path $env:LOCALAPPDATA "Programs\Tesseract-OCR\tesseract.exe")
) | Where-Object { $_ }

$tess = $tessCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1

if ($tess) {
    Write-Host "tesseract.exe: $tess" -ForegroundColor Green
    & $tess --version | Select-Object -First 1

    $localTessdata = Join-Path $PSScriptRoot "tools\ocr\tessdata"
    if (Test-Path $localTessdata) {
        Write-Host "Lokalne modele:"
        Get-ChildItem $localTessdata -Filter *.traineddata |
            Select-Object -ExpandProperty BaseName |
            Sort-Object |
            ForEach-Object { Write-Host "  - $_" }
    }
} else {
    Write-Host "tesseract.exe: BRAK" -ForegroundColor Red
}

Write-Host "TESSDATA_PREFIX: $env:TESSDATA_PREFIX"
