@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Najpierw przygotowuje podstawowe srodowisko DS Estimate...
  powershell -NoProfile -ExecutionPolicy Bypass -File ".\setup_environment.ps1"
  if errorlevel 1 exit /b 1
)
echo Instaluje opcjonalny lokalny silnik Docling. To moze zajac kilka minut.
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r ".\engines\python\requirements-optional-docling.txt"
if errorlevel 1 (
  echo Instalacja Docling nie powiodla sie. Podstawowy DS Estimate nadal dziala normalnie.
  exit /b 1
)
echo Docling gotowy. START_DS_ESTIMATE.cmd wykryje go automatycznie.
exit /b 0
