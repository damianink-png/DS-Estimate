# FIX63 — Bezpieczne ścieżki lokalne w UI desktopowym

Baza: FIX62. Interfejs Avalonia obsługuje drag-and-drop i wybór plików/folderów. Wirtualne zasoby mogą zwracać URI inne niż file://, dla których `Uri.LocalPath` nie jest prawidłową ścieżką dyskową. FIX63 filtruje wyłącznie lokalne istniejące ścieżki, usuwa duplikaty i odrzuca puste importy. Drop jest oznaczany jako obsłużony, a asynchroniczne selektory plików/folderów ponownie sprawdzają stan zajętości po powrocie.

Bez zmian w silniku wyceny, OCR, PDF, STEP, BOM, CNC, cache, raportach i licencjach. Nowy test jest strukturalny; rzeczywista kompilacja .NET 10 i uruchomienie Avalonia pozostają konieczne do potwierdzenia zgodności runtime.
