@echo off
cd /d "%~dp0"
echo.
echo === DS Estimate 1.2 - OCR / Environment Check ===
powershell -NoProfile -ExecutionPolicy Bypass -File ".\check_environment.ps1"
pause
