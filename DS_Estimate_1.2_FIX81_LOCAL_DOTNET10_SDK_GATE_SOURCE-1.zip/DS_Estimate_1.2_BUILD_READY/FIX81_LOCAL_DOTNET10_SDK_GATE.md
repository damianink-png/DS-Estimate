# DS Estimate 1.2 FIX81 — local .NET 10 SDK release preflight

- Base: verified full FIX80 source ZIP.
- Scope: release/test gates only; no change to C# src/, Python engines/python/, OCR, STEP, BOM, CNC, costs, cache or licensing.
- `tests/verify_dotnet_sdk.py` invokes the real selected `dotnet --version` and rejects missing CLI, nonzero exit, invalid/multiline version and SDK major other than 10.
- `RUN_FULL_RELEASE_TESTS.cmd` invokes the preflight before `dotnet test`, propagating a nonzero exit.
- `BUILD_FULL_PORTABLE_ZIP.ps1` invokes the preflight with the validated build Python 3.12 before removing existing publish ZIP/launcher outputs. Nonzero exit aborts packaging.
- `tests/run_fix81_local_dotnet_sdk_gate.py` exercises the real preflight in independent subprocesses using fake dotnet commands and verifies both Windows release entry points and CI wiring. The test is run by both local gates and private CI.
- These tests **do not prove** a .NET build, Avalonia launch, Windows launcher compilation or xUnit execution. A real private Windows runner with .NET 10 is still required.
- No source publication to unrelated or public repositories is authorized.
