@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0VERIFY_FIX18_BUILD_CACHE_CYCLE.ps1"
if errorlevel 1 (
  echo.
  echo [FAIL] Test cyklu cache FIX18 nie przeszedl.
  pause
  exit /b 1
)
echo.
echo [PASS] Test cyklu cache FIX18 zakonczony.
pause
exit /b 0
