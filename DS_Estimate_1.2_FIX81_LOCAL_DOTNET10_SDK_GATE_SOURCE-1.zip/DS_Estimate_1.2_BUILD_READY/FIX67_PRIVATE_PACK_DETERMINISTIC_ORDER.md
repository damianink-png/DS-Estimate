# DS Estimate FIX67 — powtarzalny prywatny pakiet analityczny

Baza: FIX66. Zmiana ograniczona do kolejności enumeracji wejść w `engines/python/build_private_analysis_pack.py`; dodano test runtime i krok w prywatnym workflow Windows.

## Przyczyna
`Path.rglob()` nie gwarantuje kolejności zwracania plików. W rezultacie identyczne dane wejściowe mogły tworzyć inne kolejności w `MANIFEST.json` i `TECHNICAL_SNIPPETS.json`, a tym samym różne bajty i SHA256 ZIP.

## Poprawka
Przed przetwarzaniem lista ścieżek jest sortowana deterministycznie według względnej nazwy (Unicode casefold, a następnie pełna nazwa jako rozstrzygnięcie remisu). Nie zmienia to sposobu odczytu, redakcji, hashowania, atomowego zapisu ani algorytmów kosztowych.

## Test
`python tests/run_fix67_private_pack_deterministic_order.py` — rzeczywisty zapis ZIP w normalnej i odwróconej kolejności wejść; porównanie bajtowe archiwów, manifestu, fragmentów, CRC oraz ponowny zapis z ZIP w katalogu źródłowym. Test przed poprawką kończył się `exit 1` na porównaniu bajtów.

## Ograniczenia
Nie wykonano kompilacji .NET 10, launchera Windows, xUnit ani Windows CI. Przeniesienie źródeł do autoryzowanego prywatnego repozytorium DS-Estimate pozostaje warunkiem uruchomienia tej ścieżki.
