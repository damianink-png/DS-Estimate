#!/usr/bin/env python3
"""FIX25: large tiled raster PDFs are not lost at the former 512-image cutoff."""
from __future__ import annotations
import importlib.util
import io
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('dse_fix25_document', ROOT / 'engines/python/analyze_document.py')
document = importlib.util.module_from_spec(spec)
spec.loader.exec_module(document)
passed = failed = skipped = 0


def check(label, condition, detail=''):
    global passed, failed
    if condition:
        passed += 1
        print('PASS', label)
    else:
        failed += 1
        print('FAIL', label, detail)


class Rect:
    x0 = y0 = 0
    x1 = y1 = 100


class Page:
    rect = Rect()

    def __init__(self, boxes):
        self.boxes = boxes

    def get_image_info(self, xrefs=False):
        return [{'bbox': box} for box in self.boxes]


def tiles(n, columns=None):
    return [(x * 100 / n, y * 100 / n, (x + 1) * 100 / n, (y + 1) * 100 / n)
            for x in range(n) for y in range(n) if columns is None or x < columns]


full = tiles(32)
check('1024 tiles covering full page detected at 70%',
      document._page_has_scanned_drawing(Page(full), .70))
check('1024 tiles covering full page detected at 30%',
      document._page_has_scanned_drawing(Page(full), .30))
check('512 tiles covering only half page do not reach 70%',
      not document._page_has_scanned_drawing(Page(tiles(32, 16)), .70))
check('overlaid copies do not inflate union area',
      not document._page_has_scanned_drawing(Page(tiles(32, 12) * 3), .70))
check('tiled full page with searchable titleblock selected',
      document.find_sparse_raster_pdf_pages(
          ['DRAWING: 120-200\nMATERIAL: S355\n' + 'x' * 125], [Page(full)]) == [0])
check('tiled half page with searchable titleblock ignored',
      document.find_sparse_raster_pdf_pages(
          ['DRAWING: 120-200\nMATERIAL: S355\n' + 'x' * 125], [Page(tiles(32, 16))]) == [])
check('OCR cap and priority preserved',
      document.select_ocr_page_indices(12, 1, [9]) == [9])
check('cache version includes FIX25',
      'fix25-large-tile-union-v1' in
      (ROOT / 'src/DSEstimate.Infrastructure/DocumentAnalyzers.cs').read_text(encoding='utf-8-sig'))
check('FIX25 registered in release test gate',
      'run_fix25_large_tiled_pdf.py' in
      (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='utf-8-sig'))
check('FIX25 registered in portable build gate',
      'run_fix25_large_tiled_pdf.py' in
      (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig'))

try:
    import pymupdf as fitz
    from PIL import Image
except ImportError:
    skipped += 1
    print('SKIP real 1024-tile PDF (PyMuPDF/Pillow unavailable)')
else:
    with tempfile.TemporaryDirectory() as temp:
        pdf_path = Path(temp) / '1024-tile-10-sheets.pdf'
        pdf = fitz.open()
        tiny = Image.new('RGB', (2, 2), 'white')
        out = io.BytesIO()
        tiny.save(out, format='PNG')
        stream = out.getvalue()
        for page_index in range(10):
            page = pdf.new_page(width=320, height=320)
            if page_index == 8:
                # Reuse the image XObject; 1024 placements still have 1024 boxes.
                xref = 0
                for x in range(32):
                    for y in range(32):
                        rect = fitz.Rect(x * 10, y * 10, (x + 1) * 10, (y + 1) * 10)
                        xref = page.insert_image(rect, stream=stream if not xref else None,
                                                 xref=xref)
            else:
                page.insert_text((15, 20), 'TECHNICAL SPECIFICATION ' * 10, fontsize=8)
        pdf.save(pdf_path)
        pdf.close()
        with fitz.open(pdf_path) as pdf:
            info = pdf[8].get_image_info(xrefs=False)
            check('real PDF contains 1024 raster placements', len(info) == 1024, str(len(info)))
            check('real 1024-tile PDF detected on sheet 9',
                  document.find_sparse_raster_pdf_pages([p.get_text('text') for p in pdf], pdf) == [8])

print(f'\nSUMMARY PASS={passed} FAIL={failed} SKIP={skipped}')
sys.exit(1 if failed else 0)
