#!/usr/bin/env python3
"""FIX38: static CI discovery-evidence checks (NOT a .NET or xUnit run)."""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
checks: list[tuple[str, bool]] = []


def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))
    print(("PASS " if condition else "FAIL ") + name, flush=True)


discovery_step = workflow.find("- name: Capture C# xUnit discovery listing")
test_step = workflow.find("- name: Run C# xUnit tests")
verify_step = workflow.find("- name: Verify xUnit TRX contains executed tests")
check("discovery listing precedes xUnit and TRX verification",
      0 <= discovery_step < test_step < verify_step)
check("discovery uses actual .NET test project and --list-tests",
      "dotnet test tests/DSEstimate.Core.Tests/DSEstimate.Core.Tests.csproj -c Release --no-build --no-restore --list-tests" in workflow)
check("discovery listing is persisted in TestResults",
      "> TestResults/xunit-discovery.txt 2>&1" in workflow)
check("discovery command exit status is checked",
      "$discoveryExit = $LASTEXITCODE" in workflow and
      "if ($discoveryExit -ne 0) { exit $discoveryExit }" in workflow)
check("discovery output is printed for Actions logs",
      "Get-Content TestResults/xunit-discovery.txt" in workflow)
check("CI artifacts include discovery listing",
      re.search(r"path:\s*\|\s*\n\s*TestResults/\*\*/\*\.trx\s*\n\s*TestResults/xunit-discovery\.txt", workflow) is not None)
check("real xUnit TRX execution is still present",
      '--logger "trx;LogFileName=ds-estimate-xunit.trx"' in workflow)
check("strict TRX guard still requires at least 60 executed tests",
      "verify_dotnet_trx.py TestResults/ds-estimate-xunit.trx --require-results --min-executed 60" in workflow)
check("launcher compilation remains present",
      "dotnet build src/DSEstimate.Launcher/DSEstimate.Launcher.csproj" in workflow)
check("CI does not publish the dummy launcher fixture",
      "dotnet publish src/DSEstimate.Launcher" not in workflow)
for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{gate} includes FIX38", "run_fix38_xunit_discovery_evidence.py" in
          (ROOT / gate).read_text(encoding="utf-8-sig"))

passed = sum(ok for _, ok in checks)
failed = len(checks) - passed
print(f"SUMMARY PASS={passed} FAIL={failed} SKIP=0", flush=True)
raise SystemExit(1 if failed else 0)
