from pathlib import Path
import ast
import json
import re
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
ENGINES = ROOT / "engines" / "python"


def text(relative_path):
    return (ROOT / relative_path).read_text(encoding="utf-8-sig")


def check(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print("PASS ", name)
    else:
        failed += 1
        print("FAIL ", name, "::", detail)


def probe_analyzer_exit(expected_code):
    path = str((ENGINES / "analyze_step.py").resolve())
    driver = f'''\npath = {path!r}\nsource = open(path, encoding="utf-8-sig").read()\nif "rc = main()" not in source:\n    raise RuntimeError("analyzer exit marker missing")\nsource = source.replace("rc = main()", "rc = {expected_code}", 1)\nexec(compile(source, path, "exec"), {{"__name__": "__main__", "__file__": path}})\n'''
    return subprocess.run(
        [sys.executable, "-c", driver],
        check=False,
        capture_output=True,
        text=True,
    ).returncode


passed = failed = 0
worker = text("engines/python/step_worker.py")
analyzer = text("engines/python/analyze_step.py")
prescan = text("engines/python/prescan_step_batch.py")
minimal = text("tests/run_ds_estimate_1_2_minimal_ui.py")
report = text("src/DSEstimate.Infrastructure/DiagnosticReportService.cs")
release = text("RUN_FULL_RELEASE_TESTS.cmd")
build = text("BUILD_FULL_PORTABLE_ZIP.ps1")

native_entry = re.compile(
    r"(?:^|\s)(?:import cadquery|from OCP|import analyze_step)",
    re.MULTILINE,
)
native_entrypoints = {
    path.name
    for path in ENGINES.glob("*.py")
    if native_entry.search(path.read_text(encoding="utf-8-sig"))
}
expected_entrypoints = {"analyze_step.py", "prescan_step_batch.py", "step_worker.py"}

check("all production native entrypoints identified", native_entrypoints == expected_entrypoints, str(native_entrypoints))
for file_name in sorted(native_entrypoints):
    source = (ENGINES / file_name).read_text(encoding="utf-8-sig")
    check(f"production native shutdown guarded: {file_name}", "os._exit(rc)" in source)

check("worker preserves main status", "rc = main()" in worker)
check("worker flushes protocol streams", "sys.stdout.flush(); sys.stderr.flush()" in worker)
check("minimal UI worker test has bounded cold-start", "subprocess.run(" in minimal and "timeout=60" in minimal)
check("minimal UI worker test sends two jobs and quit together", "for _ in range(2)" in minimal and "+ '__quit__\\n'" in minimal)
check("minimal UI worker test has no blocking readline", "proc.stdout.readline()" not in minimal)
check("obsolete five-second shutdown wait removed", "proc.wait(timeout=5)" not in minimal)
check("diagnostic identifies FIX16E", "FIX16E STEP WORKER SHUTDOWN FIX" in report)
check("FIX16E wired into release gate", "run_fix16e_worker_shutdown_guard.py" in release)
check("FIX16E wired into portable build gate", "run_fix16e_worker_shutdown_guard.py" in build)

missing_step = str((ROOT / "tests/data/fix16e_missing.step").resolve())
worker_input = "".join(
    json.dumps({"Path": missing_step, "Env": {}}) + "\n"
    for _ in range(2)
) + "__quit__\n"
try:
    process = subprocess.run(
        [sys.executable, "-u", str(ENGINES / "step_worker.py")],
        input=worker_input,
        capture_output=True,
        text=True,
        cwd=str(ENGINES),
        timeout=20,
    )
    response_lines = [line for line in process.stdout.splitlines() if line.strip()]
    responses = [json.loads(line) for line in response_lines]
    check("worker protocol returns two responses", len(responses) == 2, process.stdout[-500:])
    check("worker quits with process code 0", process.returncode == 0, f"rc={process.returncode}; {process.stderr[-500:]}")
except Exception as ex:
    check("worker protocol returns two responses", False, str(ex))
    check("worker quits with process code 0", False, str(ex))

check("standalone analyzer preserves PASS exit code 0", probe_analyzer_exit(0) == 0)
check("standalone analyzer preserves FAIL exit code 1", probe_analyzer_exit(1) == 1)

for name, source in [("worker", worker), ("analyzer", analyzer), ("prescan", prescan), ("minimal", minimal)]:
    try:
        ast.parse(source)
        check(f"{name} Python syntax", True)
    except SyntaxError as ex:
        check(f"{name} Python syntax", False, str(ex))

print(f"\nSUMMARY PASS={passed} FAIL={failed}")
sys.exit(1 if failed else 0)
