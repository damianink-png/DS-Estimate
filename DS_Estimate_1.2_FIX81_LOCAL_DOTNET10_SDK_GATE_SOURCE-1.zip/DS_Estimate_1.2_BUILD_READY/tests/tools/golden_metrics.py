import json,sys,math
from pathlib import Path

root=Path(sys.argv[1] if len(sys.argv)>1 else "tests/golden")
keys=["mass_kg","material_cost_pln","cut_h","cnc_h","weld_h","assembly_h"]
rows=[]
for exp in root.glob("*/expected.json"):
    act=exp.with_name("actual.json")
    if not act.exists(): continue
    e=json.loads(exp.read_text(encoding="utf-8")); a=json.loads(act.read_text(encoding="utf-8"))
    for k in keys:
        if k in e and k in a and isinstance(e[k],(int,float)) and e[k]!=0:
            err=(a[k]-e[k])/e[k]*100.0
            rows.append((k,err,abs(err),exp.parent.name))
print("metric\tn\tbias%\tMAPE%")
for k in keys:
    r=[x for x in rows if x[0]==k]
    if not r: print(f"{k}\t0\t—\t—"); continue
    print(f"{k}\t{len(r)}\t{sum(x[1] for x in r)/len(r):+.2f}\t{sum(x[2] for x in r)/len(r):.2f}")
