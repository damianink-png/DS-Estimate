#!/usr/bin/env python3
"""FIX42: CI must execute real two-page PDF tests, not silently skip them.

Static CI wiring checks only; this script does not install dependencies or run
.NET. FIX29/FIX30 separately exercise real PDFs when PyMuPDF is available.
"""
from __future__ import annotations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
workflow = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text(encoding='utf-8')
checks: list[tuple[str, bool]] = []


def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))
    print(('PASS ' if condition else 'FAIL ') + name, flush=True)


def step(name: str) -> str:
    marker = f'      - name: {name}\n'
    check(f'unique step: {name}', workflow.count(marker) == 1)
    if workflow.count(marker) != 1:
        return ''
    start = workflow.index(marker)
    end = workflow.find('\n      - ', start + len(marker))
    return workflow[start:end if end >= 0 else len(workflow)]


setup = step('Install real PDF regression dependency')
regression = step('Check Python engine syntax and PDF BOM contracts')
upload = step('Save test results')
check('CI-only PyMuPDF is pinned', 'python -m pip install --disable-pip-version-check "PyMuPDF==1.26.7"' in setup)
check('dependency is imported after installation', 'python -c "import pymupdf;' in setup)
check('installation and import preserve native exit status',
      setup.count('if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }') == 2)
check('dependency diagnostics saved even on failure',
      setup.count('Tee-Object -FilePath TestResults/python-pdf-dependency.log') == 2
      and 'if: always()' in upload and 'TestResults/python-pdf-dependency.log' in upload)
check('dependency installation precedes real PDF regressions',
      bool(setup and regression) and workflow.index('      - name: Install real PDF regression dependency')
      < workflow.index('      - name: Check Python engine syntax'))
for test in ('run_fix29_pdf_exact_bom_links.py', 'run_fix30_pdf_bom_step_links.py'):
    check(f'{test} executed by CI', f'python tests/{test}' in regression)
    source = (ROOT / 'tests' / test).read_text(encoding='utf-8')
    check(f'{test} contains actual PDF test', 'fitz.open()' in source and 'pdf.new_page(' in source)
check('no private source or PDF payload uploaded',
      all(x not in upload for x in ('src/', 'engines/python/', 'tests/data/', 'launcher-smoke')))
check('Windows release gate runs FIX42 check',
      'run_fix42_ci_real_pdf_dependency.py' in (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='ascii'))
check('portable release gate runs FIX42 check',
      'run_fix42_ci_real_pdf_dependency.py' in (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig'))
passed = sum(ok for _, ok in checks)
print(f'SUMMARY PASS={passed} FAIL={len(checks)-passed} SKIP=0', flush=True)
raise SystemExit(0 if passed == len(checks) else 1)
