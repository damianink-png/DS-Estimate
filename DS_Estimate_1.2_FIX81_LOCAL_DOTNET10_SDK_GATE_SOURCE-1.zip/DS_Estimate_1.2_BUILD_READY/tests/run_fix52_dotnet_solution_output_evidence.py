#!/usr/bin/env python3
"""FIX52: synthetic PE fixture + CI wiring checks; does NOT build .NET."""
from __future__ import annotations

import hashlib
import importlib.util
import struct
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERIFY = ROOT / "tests/verify_dotnet_solution_outputs.py"
spec = importlib.util.spec_from_file_location("verify_dotnet_solution_outputs", VERIFY)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
checks: list[bool] = []


def check(name: str, condition: bool) -> None:
    checks.append(bool(condition))
    print(("PASS " if condition else "FAIL ") + name, flush=True)


def synthetic_pe() -> bytes:
    """Synthetic PE32 with a mapped CLI header and .NET metadata marker."""
    data = bytearray(4096)
    data[:2] = b"MZ"
    struct.pack_into("<I", data, 0x3C, 0x80)
    data[0x80:0x84] = b"PE\x00\x00"
    struct.pack_into("<H", data, 0x86, 1)  # sections
    struct.pack_into("<H", data, 0x94, 0xE0)  # optional header size
    struct.pack_into("<H", data, 0x98, 0x10B)  # PE32
    struct.pack_into("<I", data, 0x98 + 92, 16)  # data directory count
    struct.pack_into("<II", data, 0x98 + 96 + 14 * 8, 0x2000, 0x48)
    section = 0x98 + 0xE0
    struct.pack_into("<IIII", data, section + 8, 0x1000, 0x2000, 0x1000, 0x400)
    struct.pack_into("<I", data, 0x400, 0x48)  # IMAGE_COR20_HEADER cb
    struct.pack_into("<II", data, 0x408, 0x2100, 0x20)  # metadata RVA and size
    data[0x500:0x504] = b"BSJB"
    return bytes(data)


with tempfile.TemporaryDirectory(prefix="dse-fix52-") as directory:
    root = Path(directory) / "source"
    log = Path(directory) / "evidence" / "solution-output-evidence.log"
    for _, relative in mod.OUTPUTS:
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(synthetic_pe())
    check("four exact solution output paths", len(mod.OUTPUTS) == 4)
    check("synthetic outputs accepted by verifier", len(mod.verify_outputs(root)) == 5)
    code = subprocess.run([sys.executable, str(VERIFY), "--root", str(root),
                           "--output", str(log)], capture_output=True, text=True, timeout=15)
    check("synthetic CLI returns success", code.returncode == 0)
    content = log.read_text(encoding="utf-8")
    check("four SHA-256 hashes recorded", content.count("sha256=") == 4)
    check("SHA-256 matches fixture bytes", hashlib.sha256(synthetic_pe()).hexdigest() in content)
    check("log does not contain DLL bytes", "MZPE" not in content)
    first = root / mod.OUTPUTS[0][1]
    first.write_bytes(b"NO" + synthetic_pe()[2:])
    code = subprocess.run([sys.executable, str(VERIFY), "--root", str(root),
                           "--output", str(log)], capture_output=True, text=True, timeout=15)
    check("corrupt MZ fails closed", code.returncode == 1 and "FAIL" in log.read_text(encoding="utf-8"))
    first.write_bytes(synthetic_pe()[:100])
    check("truncated output fails closed", subprocess.run(
        [sys.executable, str(VERIFY), "--root", str(root), "--output", str(log)],
        capture_output=True, text=True, timeout=15).returncode == 1)
    first.unlink()
    check("missing output fails closed", subprocess.run(
        [sys.executable, str(VERIFY), "--root", str(root), "--output", str(log)],
        capture_output=True, text=True, timeout=15).returncode == 1)
    first.write_bytes(synthetic_pe())
    check("all four required after recovery", len(mod.verify_outputs(root)) == 5)

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
check("solution build precedes evidence verification", workflow.index(
    "dotnet build DS_Estimate.sln") < workflow.index("python tests/verify_dotnet_solution_outputs.py"))
check("solution evidence before launcher compilation", workflow.index(
    "python tests/verify_dotnet_solution_outputs.py") < workflow.index(
    "dotnet build src/DSEstimate.Launcher/"))
check("solution evidence before xUnit discovery", workflow.index(
    "python tests/verify_dotnet_solution_outputs.py") < workflow.index(
    "--list-tests"))
check("private CI artifact includes evidence log", "TestResults/solution-output-evidence.log" in
      workflow.split("      - name: Save test results", 1)[-1])
check("CI does not upload DLLs", "**/*.dll" not in
      workflow.split("      - name: Save test results", 1)[-1])
for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{gate} invokes FIX52", "run_fix52_dotnet_solution_output_evidence.py" in
          (ROOT / gate).read_text(encoding="utf-8-sig"))
check(".NET SDK 10 pin preserved", "dotnet-version: '10.0.x'" in workflow)
check("strict xUnit gate preserved", "--require-results --min-executed 60 --reject-skipped" in workflow)
check("real PDF gate preserved", "--require-real-pdf" in workflow)
print(f"SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0", flush=True)
raise SystemExit(0 if all(checks) else 1)
