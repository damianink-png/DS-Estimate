#!/usr/bin/env python3
"""FIX49: exercise additional strict VSTest non-PASS counters (synthetic TRX).

These checks do not compile C#, run xUnit or produce real TRX evidence.
"""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERIFY = ROOT / "tests/verify_dotnet_trx.py"
spec = importlib.util.spec_from_file_location("dse_verify_trx_fix49", VERIFY)
assert spec and spec.loader
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
checks: list[bool] = []


def check(label: str, result: bool) -> None:
    checks.append(bool(result))
    print(("PASS " if result else "FAIL ") + label, flush=True)


def sample(extra: str = "") -> str:
    records = "".join(f'<UnitTestResult testId="t{i}" outcome="Passed" />' for i in range(60))
    return ("<TestRun><Results>" + records + "</Results>"
            '<ResultSummary outcome="Completed"><Counters '
            'total="60" executed="60" passed="60" failed="0" error="0" '
            f'{extra}/></ResultSummary></TestRun>')


with tempfile.TemporaryDirectory(prefix="dse-fix49-") as temp:
    path = Path(temp) / "synthetic.trx"

    def accepted(strict: bool) -> bool:
        try:
            module.verify_trx(path, min_executed=60, require_results=True,
                              reject_skipped=strict)
        except module.TrxValidationError:
            return False
        return True

    path.write_text(sample(), encoding="utf-8")
    check("complete 60/60 baseline accepted in strict mode", accepted(True))
    for counter in ("inconclusive", "passedButRunAborted", "disconnected",
                    "warning", "inProgress", "pending"):
        path.write_text(sample(f'{counter}="1"'), encoding="utf-8")
        check(f"strict mode rejects {counter}=1", not accepted(True))
        check(f"legacy mode keeps {counter}=1 compatibility", accepted(False))
    path.write_text(sample('pending="-1"'), encoding="utf-8")
    check("strict mode rejects negative pending counter", not accepted(True))
    path.write_text(sample('inconclusive="oops"'), encoding="utf-8")
    check("strict mode rejects malformed inconclusive counter", not accepted(True))
    path.write_text(sample('inProgress="0" pending="0"'), encoding="utf-8")
    check("strict mode accepts zero-valued extra counters", accepted(True))
    path.write_text(sample('pending="1"'), encoding="utf-8")
    result = subprocess.run([sys.executable, str(VERIFY), str(path), "--require-results",
                             "--min-executed", "60", "--reject-skipped"],
                            capture_output=True, text=True, timeout=15, check=False)
    check("strict CLI fails on pending", result.returncode == 1 and "pending" in result.stderr)

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
check("private CI invokes strict TRX mode",
      "verify_dotnet_trx.py TestResults/ds-estimate-xunit.trx --require-results --min-executed 60 --reject-skipped" in workflow)
for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{gate} runs FIX49 regression",
          "run_fix49_trx_nonpass_counter_guard.py" in (ROOT / gate).read_text(encoding="utf-8-sig"))

passed = sum(checks)
print(f"SUMMARY PASS={passed} FAIL={len(checks) - passed} SKIP=0", flush=True)
raise SystemExit(0 if passed == len(checks) else 1)
