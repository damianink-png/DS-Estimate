#!/usr/bin/env python3
"""FIX79: changes to Windows release scripts must trigger private Windows CI.

This is a structural workflow regression test, not a GitHub Actions execution.
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = ROOT / '.github/workflows/ds-estimate-dotnet10.yml'
CMD = ROOT / 'RUN_FULL_RELEASE_TESTS.cmd'
PS1 = ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1'
text = WORKFLOW.read_text(encoding='utf-8')
checks: list[bool] = []


def check(label: str, condition: bool) -> None:
    checks.append(bool(condition))
    print(('PASS' if condition else 'FAIL') + ' | ' + label, flush=True)


def event_paths(event: str) -> list[str]:
    match = re.search(
        rf'^  {re.escape(event)}:\s*\n    paths:\s*\n((?:      (?:- [^\n]+|\#[^\n]*)\n)+)',
        text, re.M,
    )
    if not match:
        return []
    return [line.strip().removeprefix('- ').strip("'\"")
            for line in match.group(1).splitlines() if line.strip().startswith('- ')]


release_scripts = (
    'RUN_FULL_RELEASE_TESTS.cmd',
    'BUILD_FULL_PORTABLE_ZIP.ps1',
    'BUILD_FULL_PORTABLE_ZIP.cmd',
)
for event in ('push', 'pull_request'):
    paths = event_paths(event)
    check(f'{event} has an explicit paths filter', bool(paths))
    for script in release_scripts:
        check(f'{event} triggers on {script}', script in paths)
    for source in ('src/**', 'engines/python/**', 'tests/**', 'DS_Estimate.sln'):
        check(f'{event} still triggers on {source}', source in paths)
    check(f'{event} path patterns are not duplicated', len(paths) == len(set(paths)))

check('CMD invokes FIX79 regression with nonzero exit propagation',
      '%PY% tests\\run_fix79_ci_release_script_triggers.py || exit /b 1' in
      CMD.read_text(encoding='ascii'))
check('PowerShell invokes FIX79 regression',
      '"tests\\run_fix79_ci_release_script_triggers.py",' in
      PS1.read_text(encoding='utf-8-sig'))
check('private CI invokes FIX79 regression',
      'run: python tests/run_fix79_ci_release_script_triggers.py' in text)
check('workflow remains manual-dispatch capable',
      bool(re.search(r'^  workflow_dispatch:\s*$', text, re.M)))

print(f'SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0', flush=True)
raise SystemExit(0 if all(checks) else 1)
