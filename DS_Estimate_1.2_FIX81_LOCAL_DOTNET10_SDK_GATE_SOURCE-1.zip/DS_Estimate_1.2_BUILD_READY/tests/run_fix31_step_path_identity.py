#!/usr/bin/env python3
"""FIX31 checks: C# source contracts + actual Python PDF/STEP engine smoke.

This is NOT a C# compile or execution of DrawingStepEvidenceResolver.
The CAD fixture is generated locally by CadQuery, not a customer assembly.
"""
from __future__ import annotations

import importlib.util
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
passed = failed = skipped = 0


def check(label, ok):
    global passed, failed
    if ok:
        passed += 1
        print('PASS', label, flush=True)
    else:
        failed += 1
        print('FAIL', label, flush=True)


def source(path):
    return (ROOT / path).read_text(encoding='utf-8-sig')


resolver = source('src/DSEstimate.Infrastructure/DrawingStepEvidenceResolver.cs')
cs_tests = source('tests/DSEstimate.Core.Tests/Fix31DrawingStepPhysicalPathTests.cs')
service = source('src/DSEstimate.Infrastructure/ProjectAnalysisService.cs')
report = source('src/DSEstimate.Infrastructure/DiagnosticReportService.cs')

check('actual disk path supplies the STEP identifier (static C#)',
      '.Select(x => Path.GetFileName(x.Path))' in resolver)
check('display name cannot supply the STEP identifier (static C#)',
      'x.Name' not in resolver and 'Path.GetFileNameWithoutExtension(name)' in resolver)
check('physical extension .step/.stp is required (static C#)',
      'Path.GetExtension(name)' in resolver and '".step"' in resolver and '".stp"' in resolver)
check('existing active, nonexcluded STEP is still required (static C#)',
      all(x in resolver for x in ('DocumentKind.Step', 'x.IsActiveRevision',
                                 '!x.ExcludeFromAnalysis', 'File.Exists(x.Path)')))
check('duplicate physical basename remains ambiguous (static C#)',
      'stepMatches.Count != 1' in resolver and 'AmbiguousIdentifiers.Add(id)' in resolver)
check('link remains filename-only, not geometry authority (static C#)',
      'exact-pdf-bom-step-filename-only' in resolver and 'geometria niezweryfikowana' in report)
check('new C# xUnit cases cover alias spoof, conflict and duplicate paths (source only)',
      all(x in cs_tests for x in ('Display_name_cannot_spoof',
                                  'Import_conflict_display_suffix',
                                  'Same_physical_basename_in_two_folders',
                                  'Display_step_extension_cannot_override')))
check('no STEP evidence used by CostEngine (static C#)',
      service.index('drawing.DrawingStepLinks = stepEvidence.Links;') < service.index('var result = _cost.Build(')
      and '_cost' not in resolver)
check('Windows and portable release gates include FIX31',
      'run_fix31_step_path_identity.py' in source('RUN_FULL_RELEASE_TESTS.cmd')
      and 'run_fix31_step_path_identity.py' in source('BUILD_FULL_PORTABLE_ZIP.ps1'))

# Actual file-level smoke for Python engines, not execution of the C# resolver.
if not (importlib.util.find_spec('pymupdf') and importlib.util.find_spec('cadquery')):
    skipped += 1
    print('SKIP real PDF/STEP smoke: PyMuPDF or CadQuery unavailable')
else:
    import pymupdf as fitz
    spec = importlib.util.spec_from_file_location('dse_fix31_pdf', ROOT / 'engines/python/analyze_document.py')
    document = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(document)
    with tempfile.TemporaryDirectory(prefix='dse-fix31-') as folder:
        folder = Path(folder)
        pdf_path = folder / 'drawings-bom.pdf'
        step_path = folder / 'PART-001.step'
        pdf = fitz.open()
        for page_text in (
            'DRAWING NO\nPART-001\nMATERIAL: S355J2',
            'POS DOKNR MENGE GEWICHT\nPART-001\n2 ST\n20 KG',
        ):
            page = pdf.new_page(width=595, height=842)
            page.insert_text((40, 50), page_text, fontsize=12)
        pdf.save(pdf_path)
        pdf.close()
        old_ocr = os.environ.get('DSE_SKIP_PDF_OCR')
        os.environ['DSE_SKIP_PDF_OCR'] = '1'
        try:
            pdf_result = document.analyze_pdf(pdf_path)
        finally:
            if old_ocr is None:
                os.environ.pop('DSE_SKIP_PDF_OCR', None)
            else:
                os.environ['DSE_SKIP_PDF_OCR'] = old_ocr
        links = pdf_result.get('drawingBomLinks', [])
        check('actual two-sheet PDF yields one unambiguous PDF↔BOM link',
              len(links) == 1 and links[0]['drawingNumber'] == 'PART-001'
              and links[0]['drawingPageNumber'] == 1 and links[0]['bomPageNumber'] == 2)
        check('actual PDF evidence does not carry price or quantity authority',
              len(links) == 1 and all(not any(k in item for k in ('price', 'cost', 'quantity'))
                                      for item in links))
        # Export two solids through the same CadQuery/OCCT stack used by STEP analysis.
        export_script = '''import cadquery as cq, sys
assembly = cq.Assembly(name="PART-001")
assembly.add(cq.Workplane("XY").box(20, 30, 40), name="Body")
assembly.add(cq.Workplane("XY").cylinder(20, 5).translate((60, 0, 0)), name="Pin")
assembly.save(sys.argv[1])
'''
        try:
            exported = subprocess.run([sys.executable, '-c', export_script, str(step_path)],
                                      capture_output=True, text=True, timeout=60)
            check('real two-solid STEP assembly exported by CadQuery',
                  exported.returncode == 0 and step_path.is_file()
                  and b'ISO-10303-21' in step_path.read_bytes()[:256])
            if exported.returncode == 0 and step_path.is_file():
                env = dict(os.environ, DSE_STEP_CORE_ONLY='1')
                analyzed = subprocess.run([sys.executable, str(ROOT / 'engines/python/analyze_step.py'),
                                           str(step_path)], capture_output=True, text=True,
                                          timeout=120, env=env)
                try:
                    data = json.loads(analyzed.stdout)
                except (ValueError, TypeError):
                    data = {}
                check('real STEP engine reads two solids and positive volume',
                      analyzed.returncode == 0 and data.get('available') is True
                      and data.get('solidCount') == 2 and data.get('volumeMm3', 0) > 0)
                check('real STEP engine identifies distinct part groups',
                      data.get('uniquePartGroups') == 2)
        except (OSError, subprocess.TimeoutExpired) as exc:
            check(f'actual STEP assembly smoke: {type(exc).__name__}', False)

print(f'\nSUMMARY PASS={passed} FAIL={failed} SKIP={skipped}')
raise SystemExit(1 if failed else 0)
