﻿#!/usr/bin/env python3
from pathlib import Path
import importlib.util, subprocess, sys, tempfile, json, math, re

ROOT=Path(__file__).resolve().parents[1]
ENG=ROOT/'engines'/'python'
PASS=FAIL=0
failures=[]
def check(name, cond, detail=''):
    global PASS,FAIL
    if cond:
        PASS+=1; print('PASS ',name)
    else:
        FAIL+=1; failures.append(f'{name}: {detail}'); print('FAIL ',name,'::',detail)

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def run_json(script,path):
    cp=subprocess.run([sys.executable,str(script),str(path)],capture_output=True,text=True,check=True)
    return json.loads(cp.stdout)

doc=load('dsdoc_r8',ENG/'analyze_document.py')

# Paint: real coating passes + stripe coat.
s=doc.detect_structured_technical_signals('''PAINT SYSTEM\nPRIMER 2x80 um\nTOPCOAT 1x60 um\nSTRIPE COAT on welds and edges\nRAL 9005''')
check('paint multiplicity parsed', len(s['paintLayers'])>=2 and any(x.get('coatCount')==2 and abs(x['dftMicron']-80)<.1 for x in s['paintLayers']), s)
check('paint total DFT includes multiplicity', abs((s.get('totalDftMicron') or 0)-220)<.1, s)
check('paint stripe coat parsed', s.get('paintStripeCoatRequired') is True, s)
check('paint RAL retained', s.get('paintColour')=='RAL 9005', s)

# Groove-weld physical inputs.
g=doc.detect_structured_technical_signals('''GROOVE WELD PROCESS 135\nGROOVE ANGLE 60 deg\nROOT GAP 2 mm\nBOTH SIDES''')
check('groove type', g.get('weldTypeHint')=='GROOVE',g)
check('groove angle', abs((g.get('weldGrooveAngleDeg') or 0)-60)<.1,g)
check('groove root gap', abs((g.get('weldRootGapMm') or 0)-2)<.1,g)
check('groove process', g.get('weldProcessCode')=='135',g)
check('groove sides', g.get('weldSideCount')==2 and g.get('weldSideCountConfirmed'),g)

# OCR majority-vote: one bad pass must not override 2 agreeing passes.
a='HOLE Ø50 H7 REAMED\nRAL 9005\nDFT 120 um\nWELD 135 a6'
b='HOLE Ø50 H7 REAMED\nRAL 9005\nDFT 120 um\nWELD 135 a6'
c='HOLE Ø80 H8 REAMED\nRAL 8005\nDFT 170 um\nWELD 136 a8'
merged=doc.merge_ocr_texts(a,b,c)
conf=doc._ocr_multi_pass_conflicts(a,b,c)
check('OCR 2-of-3 consensus RAL first', merged.splitlines()[0:8].count('RAL 9005')>=1, merged)
check('OCR 2-of-3 consensus hole', 'HOLE Ø50 H7' in merged,merged)
check('OCR single outlier not hard conflict', len(conf)==0,conf)
check('OCR three-way disagreement conflicts', len(doc._ocr_multi_pass_conflicts('RAL 9005','RAL 8005','RAL 7016'))>=1)
check('OCR legacy false weld-hole still blocked', not doc.detect_structured_technical_signals('WELD 135 a6')['holeRequirements'])

# Mixed PDF: searchable title text + raster-only technical callouts. This verifies
# the new OCR supplementation path, not just an empty/scanned PDF fallback.
try:
    import pymupdf as fitz
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        src=fitz.open(); pg=src.new_page(width=900,height=330)
        pg.insert_text((40,70),'HOLE D=50 H7 REAMED',fontsize=28)
        pg.insert_text((40,140),'WELD 135 a6 BOTH SIDES',fontsize=28)
        pg.insert_text((40,210),'RAL 9005   DFT 120 um',fontsize=28)
        pix=pg.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False)
        img=td/'technical.png'; pix.save(str(img)); src.close()
        target=fitz.open(); pg=target.new_page(width=842,height=595)
        pg.insert_text((35,45),'PROJECT DRAWING GENERAL INFORMATION CUSTOMER REFERENCE DOCUMENT CONTROL APPROVED RELEASED FOR PRODUCTION NOTES IMAGE BELOW',fontsize=11)
        pg.insert_image(fitz.Rect(35,90,807,380),filename=str(img))
        mixed=td/'mixed.pdf'; target.save(str(mixed)); target.close()
        rr=run_json(ENG/'analyze_document.py',mixed)
        check('mixed PDF OCR supplement weld',rr.get('weldProcessCode')=='135' and rr.get('weldSizeMm')==6.0,rr)
        check('mixed PDF OCR supplement H7',any(abs((h.get('nominalDiameterMm') or 0)-50)<.1 and h.get('fitCode')=='H7' for h in rr.get('holeRequirements',[])),rr)
        check('mixed PDF OCR supplement coating',rr.get('paintColour')=='RAL 9005' and abs((rr.get('totalDftMicron') or 0)-120)<.1,rr)
except Exception as e:
    print('SKIP  mixed PDF OCR supplement ::',e)

# DXF geometry/process drivers.
try:
    import ezdxf
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        path=td/'two_parts.dxf'; d=ezdxf.new('R2010'); d.units=4; m=d.modelspace()
        # two 100x50 rectangles separated by 100 mm; 2 starts and non-zero rapid travel.
        for ox in (0,200):
            pts=[(ox,0),(ox+100,0),(ox+100,50),(ox,50)]
            for x,y in zip(pts,pts[1:]+pts[:1]): m.add_line(x,y,dxfattribs={'layer':'CUT'})
        m.add_line((0,80),(100,80),dxfattribs={'layer':'ETCH'})
        m.add_line((0,100),(100,100),dxfattribs={'layer':'DIM'})
        d.saveas(path)
        r=run_json(ENG/'analyze_dxf.py',path)
        check('DXF two contours => two starts',r.get('cutStartCount')==2,r)
        check('DXF rapid travel estimated',r.get('estimatedRapidTravelMm',0)>50,r)
        check('DXF cut length only CUT',abs(r.get('cutLengthMm',0)-600)<.5,r)
        check('DXF ETCH separate',abs(r.get('markingLengthMm',0)-100)<.5,r)
        check('DXF DIM ignored',r.get('ignoredNonCutLengthMm',0)>=99,r)
        check('DXF cut bbox',r.get('cutBoundingXmm',0)>=299 and 49<=r.get('cutBoundingYmm',0)<=51,r)
except Exception as e:
    check('DXF weak-link suite',False,str(e))

# C# integration/static contract checks where .NET SDK is not guaranteed in the test runtime.
infra=(ROOT/'src/DSEstimate.Infrastructure/DSEstimate.Infrastructure.csproj').read_text(encoding='utf-8')
dwg=(ROOT/'src/DSEstimate.Infrastructure/DwgConversionService.cs').read_text(encoding='utf-8')
pa=(ROOT/'src/DSEstimate.Infrastructure/ProjectAnalysisService.cs').read_text(encoding='utf-8')
cost=(ROOT/'src/DSEstimate.Core/CostEngine.cs').read_text(encoding='utf-8')
domain=(ROOT/'src/DSEstimate.Core/Domain.cs').read_text(encoding='utf-8')
check('DWG ACadSharp package pinned', 'ACadSharp' in infra and '3.6.51' in infra,infra)
check('DWG reads with DwgReader', 'new DwgReader' in dwg,dwg[:500])
check('DWG writes DXF with DxfWriter', 'new DxfWriter' in dwg,dwg[:500])
check('DWG ProjectAnalysis uses converter', '_dwg.ConvertToDxfAsync' in pa, '')
check('DWG converted DXF analyzed', '_dxf.AnalyzeAsync(converted.DxfPath' in pa,'')
check('cut model uses rapid travel', 'EstimatedRapidTravelMm' in cost,'')
check('cut model uses marking length', 'MarkingLengthMm' in cost,'')
check('cut model uses starts', 'CutStartCount' in cost,'')
check('cut model has technology profiles', 'CuttingProfiles' in cost and 'Matches(result.Material' in cost,'')
check('CNC uses feature depth', 'h.DepthMm' in cost and 'CncDrillFeedMmMin' in cost,'')
check('CNC distinguishes ream', 'reamMinutes' in cost and 'CncReamFeedMmMin' in cost,'')
check('CNC distinguishes tap', 'tapMinutes' in cost and 'CncTapFeedMmMin' in cost,'')
check('CNC distinguishes secondary features', 'secondaryMinutes' in cost and 'CncSecondaryFeedMmMin' in cost,'')
check('paint cost uses coat count', 'layer.CoatCount' in cost and 'coatPasses' in cost,'')
check('paint cost uses stripe length', 'stripeCoatHours' in cost and 'WeldCandidateLengthMm' in cost,'')
check('groove cost uses angle', 'WeldGrooveAngleDeg' in cost and 'Math.Tan(angleRad / 2.0)' in cost,'')
check('groove fields persisted', 'WeldGrooveAngleDeg' in domain and 'WeldRootGapMm' in domain,'')
build=(ROOT/'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8')
smoke=(ROOT/'tests/DSEstimate.DwgSmoke/Program.cs').read_text(encoding='utf-8')
check('portable build gates on real DWG smoke', 'sample_AC1032.dwg' in build and 'Test DWG -> DXF' in build and 'dotnet run --project $dwgSmokeProject' in build, '')
check('DWG smoke reopens converted DXF', 'DxfReader.Read(converted.DxfPath)' in smoke and 'entityCount <= 0' in smoke, '')
check('portable requires ACadSharp assembly', 'ACadSharp.dll' in build, '')

# Crude static guards for accidental patch corruption.
for name,text in [('CostEngine.cs',cost),('ProjectAnalysisService.cs',pa),('Domain.cs',domain),('DwgConversionService.cs',dwg)]:
    check(f'{name} braces balanced', text.count('{')==text.count('}'), f"{{={text.count('{')} }}={text.count('}')}")

print(f'\nSUMMARY\nPASS={PASS} FAIL={FAIL}')
if failures:
    print('FAILURES:')
    for x in failures: print(' -',x)
    raise SystemExit(1)
