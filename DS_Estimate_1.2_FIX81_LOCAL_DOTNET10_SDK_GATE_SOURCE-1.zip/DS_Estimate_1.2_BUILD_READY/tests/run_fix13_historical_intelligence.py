#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name, cond, detail=''):
    ok=bool(cond); checks.append(ok)
    print(('PASS  ' if ok else 'FAIL  ')+name+(f' :: {detail}' if detail else ''))
def text(rel, enc='utf-8-sig'):
    return (ROOT/rel).read_text(encoding=enc)

domain=text('src/DSEstimate.Core/Domain.cs')
intel=text('src/DSEstimate.Core/ProjectIntelligenceEngines.cs')
cost=text('src/DSEstimate.Core/CostEngine.cs')
merge=text('src/DSEstimate.Infrastructure/ProjectAnalysisService.cs')
hier=text('src/DSEstimate.Core/AssemblyHierarchyEngine.cs')
conf=text('src/DSEstimate.Core/AdvancedCostEngines.cs')
report=text('src/DSEstimate.Infrastructure/DiagnosticReportService.cs')
settings=text('src/DSEstimate.Infrastructure/SettingsRepository.cs')
view=text('src/DSEstimate.App/Views/MainWindow.axaml')
cb=text('src/DSEstimate.App/Views/MainWindow.axaml.cs')
vm=text('src/DSEstimate.App/ViewModels/MainViewModel.cs')
xunit=text('tests/DSEstimate.Core.Tests/Fix13HistoricalIntelligenceTests.cs')
release=(ROOT/'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='ascii')
build=(ROOT/'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig')

check('material breakdown domain', 'class MaterialBreakdownItem' in domain and 'MaterialBreakdown' in domain)
check('semi-finished domain', 'class SemiFinishedProductItem' in domain and 'SemiFinishedProducts' in domain)
check('material breakdown engine', 'class MaterialBreakdownEngine' in intel)
check('hierarchical mass avoids parent plus child double count', 'mass-bearing leaves branch-by-branch' in intel and 'HasMassBearingDescendant' in intel)
check('unassigned mass stays visible', 'NIEPRZYPISANE' in intel)
check('RHS SHS classification', 'RHS/SHS' in intel)
check('beam classification', 'DWUTEOWNIK' in intel)
check('channel classification', 'CEOWNIK' in intel)
check('angle classification', 'KĄTOWNIK' in intel)
check('pipe classification', 'RURA' in intel)
check('forging and casting classification', 'ODKUWKA' in intel and 'ODLEW' in intel)
check('per-grade material rate overrides optional', 'MaterialPriceOverridesPlnKg' in domain and 'MaterialPriceOverridesPlnKg' in cost)
check('empty material overrides retain base price path', 'MaterialPriceOverridesPlnKg is { Count: > 0 }' in cost)
check('settings migration initializes material overrides', 'MaterialPriceOverridesPlnKg ??=' in settings)

check('weld family signal domain', 'class WeldFamilySignal' in domain)
check('weld family estimate domain', 'class WeldFamilyEstimate' in domain and 'FamilyBreakdown' in domain)
check('drawing preserves weld families', 'WeldFamilySignals' in domain)
check('merge builds family weld signals', 'merged.WeldFamilySignals = items' in merge)
check('weld explicit length uses BOM quantity per family', 'ExplicitLengthMm' in merge and 'WeldFamilyQuantity(g.Key)' in merge and 'ExplicitLengthMm!.Value * Math.Max(1, x.Quantity)' in merge)
check('weld costing supports family scope', 'FamilyScoped = familyScoped' in cost and 'familyBreakdown' in cost)
check('different weld families not collapsed into max-only rule', 'FIX13 family-scoped' in cost)

check('CNC feature summary domain', 'class CncFeatureSummary' in domain)
check('CNC feature engine', 'class CncFeatureSummaryEngine' in intel)
check('CNC separates drill ream tap bore', all(x in intel for x in ['DrilledHoleCount','ReamedHoleCount','ThreadedHoleCount','BoredHoleCount']))
check('CNC includes tolerances and bevels', 'TightGeometricToleranceCount' in intel and 'BevelFaceCount' in intel)
check('analysis gets CNC feature summary', 'result.CncFeatures = CncFeatureSummaryEngine.Build(result)' in cost)

check('historical calibration domain', 'class HistoricalCalibrationSummary' in domain and 'HistoricalProcessAdjustment' in domain)
check('similarity aware calibration method', 'ApplySimilarityAwareCalibration' in cost)
check('history requires at least two completed neighbors', 'neighbors.Count < 2' in cost)
check('similarity squared weighting', 'normalized * normalized' in cost)
check('weighted median calibration', 'WeightedMedian' in cost)
check('manual overrides protected from history', '!x.ManualOverride' in cost)
check('3401 weld assembly learned together', 'SSK 3401 uczone łącznie' in cost)
check('3205 manual CNC mapping', '"3205"' in cost and 'CNC_MANUAL' in cost)
check('3302 and 3303 prep mappings', '"3302"' in cost and '"3303"' in cost)
check('3402 surface mapping', '"3402"' in cost and 'SURF' in cost)
check('external cost history is diagnostic hint only', 'ExternalCostHintPln' in cost and 'diagnost' in report.lower())
check('history price uses similarity weighted reference', 'PriceWeight' in cost and 'WeightedHistoricalPricePln' in cost)
check('historical blend remains explicit setting', 'HistoricalBlendPercent' in cost)
check('project analysis invokes local calibration before history price', merge.find('_cost.ApplySimilarityAwareCalibration') < merge.find('_cost.ApplyHistory'))

check('assembly hierarchy preserves BOM levels', 'lastNodeAtLevel' in hier and 'item.Level' in hier and 'HasNestedChildren' in hier)
check('assembly hierarchy binds STEP to BOM nodes', 'MatchBasis' in hier and 'STEP' in hier)

check('cost confidence exposes share', 'SharePercent' in domain and 'SharePercent =' in conf)
check('cost confidence exposes next action', 'NextAction' in domain and 'NextAction =' in conf)
check('cost confidence material next action', 'jawną masę całego zespołu' in conf.lower())
check('cost confidence CNC next action', 'CncFeatures.NextAction' in conf)
check('cost confidence paint completeness next action', 'SystemCompletenessPercent' in conf)

check('paint system completeness domain', 'SystemCompletenessPercent' in domain)
check('paint completeness calculated', 'paintCompleteness' in cost)
check('paint report shows completeness', 'Kompletność systemu powłok' in report)
check('material report section', 'FIX13 / MATERIAŁY I PÓŁFABRYKATY' in report)
check('CNC report section', 'FIX13 / CNC FEATURE MODEL' in report)
check('weld family report', 'FIX13 spoiny per rodzina' in report)
check('historical calibration report', 'FIX13 / KALIBRACJA HISTORYCZNA PODOBNYMI REALIZACJAMI' in report)
check('cost confidence report', 'FIX13 / PEWNOŚĆ SKŁADNIKÓW KOSZTU' in report)
check('similar project basis audited', 'SimilarityBasis' in report)

check('private export button removed', 'Pakiet prywatny do analizy' not in view)
check('private export callback removed', 'OnBuildPrivateAnalysisPackClick' not in cb)
check('private export viewmodel flow removed', 'BuildPrivateAnalysisPackAsync' not in vm and '_privatePack' not in vm)

check('xunit behavior tests included', all(x in xunit for x in [
    'Hierarchical_material_breakdown_prefers_leaf_mass',
    'Semi_finished_classifier_understands_common_manufacturing_stock',
    'Similar_completed_projects_calibrate_combined_weld_and_assembly',
    'Historical_calibration_never_overrides_manual_process_decision',
    'Cnc_feature_summary_keeps_operation_types_separate']))

try:
    ET.parse(ROOT/'src/DSEstimate.App/Views/MainWindow.axaml'); xmlok=True
except Exception as e:
    xmlok=False
check('MainWindow XAML parses', xmlok)
for name,blob in [('domain',domain),('intel',intel),('cost',cost),('merge',merge),('hier',hier),('confidence',conf),('report',report),('xunit',xunit)]:
    check(name+' braces balanced', blob.count('{')==blob.count('}'), f"{blob.count('{')}/{blob.count('}')}")
check('FIX13 wired into release gate', 'run_fix13_historical_intelligence.py' in release)
check('FIX13 wired into portable build gate', 'run_fix13_historical_intelligence.py' in build)
print(f'\nSUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)}')
raise SystemExit(0 if all(checks) else 1)
