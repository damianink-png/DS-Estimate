#!/usr/bin/env python3
"""FIX8 regression: imported parser dependencies must invalidate engine caches."""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PASS = 0
FAIL = 0


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8-sig")


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"PASS  {name}")
    else:
        FAIL += 1
        print(f"FAIL  {name} :: {detail}")


def test_real_tabular_parser() -> None:
    with tempfile.TemporaryDirectory() as temp:
        sample = Path(temp) / "ASTM_A36.txt"
        sample.write_text("MATERIAL ASTM A36\nWELD PROCESS 135\n", encoding="utf-8")
        run = subprocess.run(
            [sys.executable, str(ROOT / "engines/python/analyze_tabular.py"), str(sample)],
            cwd=ROOT,
            text=True,
            capture_output=True,
            timeout=30,
        )
        try:
            result = json.loads(run.stdout)
        except Exception:
            result = {}
        check("tabular parser executes", run.returncode == 0 and bool(result), run.stderr or run.stdout)
        check("tabular parser keeps ASTM A36 material", result.get("materialHint") == "ASTM A36", repr(result))
        check("tabular parser rejects cached-style false a36", result.get("weldSizeMm") is None, repr(result))
        check("tabular parser keeps weld process 135", result.get("weldProcessCode") == "135", repr(result))


def test_dependency_fingerprints() -> None:
    cache = read("src/DSEstimate.Infrastructure/EngineResultCache.cs")
    analyzers = read("src/DSEstimate.Infrastructure/DocumentAnalyzers.cs")
    build = read("BUILD_FULL_PORTABLE_ZIP.ps1")
    full = read("RUN_FULL_RELEASE_TESTS.cmd")

    check("cache supports dependency sets", all(token in cache for token in [
        "VersionForScripts", "scriptNames", "dependencies", "SHA256.HashData(payload)",
    ]))
    check("dependency names are canonicalized", "Distinct(StringComparer.OrdinalIgnoreCase)" in cache and
          "OrderBy(x => x, StringComparer.OrdinalIgnoreCase)" in cache)
    check("tabular cache fingerprints semantic parser", all(token in analyzers for token in [
        '"r930-tabular-v3", "analyze_tabular.py", "analyze_document.py"',
        "EngineResultCache.VersionForScripts",
    ]))
    check("DXF cache fingerprints semantic parser", all(token in analyzers for token in [
        '"r930-dxf-v2", "analyze_dxf.py", "analyze_document.py"',
        "EngineResultCache.VersionForScripts",
    ]))
    check("batch STEP cache fingerprints imported STEP engine", all(token in analyzers for token in [
        '"r930-prescan-v2", "prescan_step_batch.py", "analyze_step.py"',
        "EngineResultCache.VersionForScripts",
    ]))
    check("FIX8 regression wired into Windows build", "run_r9_3_0_fix8_dependency_cache.py" in build)
    check("FIX8 regression wired into full gate", "run_r9_3_0_fix8_dependency_cache.py" in full)
    check("EngineResultCache braces balanced", cache.count("{") == cache.count("}"),
          f"{cache.count('{')} / {cache.count('}')}")


if __name__ == "__main__":
    test_real_tabular_parser()
    test_dependency_fingerprints()
    print(f"\nSUMMARY\nPASS={PASS} FAIL={FAIL}")
    raise SystemExit(1 if FAIL else 0)
