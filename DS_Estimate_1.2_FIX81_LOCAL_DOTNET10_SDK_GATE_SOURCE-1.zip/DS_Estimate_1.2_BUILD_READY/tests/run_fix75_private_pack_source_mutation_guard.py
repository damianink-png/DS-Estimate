#!/usr/bin/env python3
"""FIX75: refuse a private pack if a source changes between hashing and extraction."""
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / 'engines/python/build_private_analysis_pack.py'
spec = importlib.util.spec_from_file_location('dse_private_pack_fix75', ENGINE)
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
checks = 0


def check(label, condition):
    global checks
    if not condition:
        print('FAIL | ' + label, flush=True)
        raise AssertionError(label)
    checks += 1
    print('PASS | ' + label, flush=True)


def invoke(source, output, reader=None):
    old = sys.argv
    sys.argv = [str(ENGINE), str(source), str(output)]
    try:
        with patch.object(engine, 'read_text', reader) if reader else patch.object(engine, 'read_text', engine.read_text):
            try:
                engine.main()
            except SystemExit as ex:
                return str(ex.code)
            return '0'
    finally:
        sys.argv = old


with tempfile.TemporaryDirectory(prefix='dse_fix75_') as temp:
    root = Path(temp)
    source = root / 'source'
    source.mkdir()
    document = source / 'drawing.txt'
    document.write_text('Material S355 CNC\n', encoding='utf-8')
    output = source / 'private.zip'
    good = subprocess.run([sys.executable, str(ENGINE), str(source), str(output)],
                          capture_output=True, text=True, timeout=30)
    check('real CLI returns exit 0 for stable input', good.returncode == 0)
    check('real CLI reports success', json.loads(good.stdout)['ok'] is True)
    with zipfile.ZipFile(output) as archive:
        check('real ZIP has valid CRC', archive.testzip() is None)
        manifest = json.loads(archive.read('MANIFEST.json'))
        check('real manifest contains exactly one source', manifest['file_count'] == 1)
        check('real manifest SHA256 matches source',
              manifest['files'][0]['sha256'] == hashlib.sha256(document.read_bytes()).hexdigest())
    saved_zip = output.read_bytes()
    saved_sha = hashlib.sha256(saved_zip).hexdigest()

    # A same-length edit after hashing previously produced a green pack whose
    # SHA256 referred to a different revision than its extracted technical text.
    mtime = document.stat().st_mtime_ns
    original_reader = engine.read_text
    def mutate_after_hash(path):
        if path == document:
            document.write_text('Material S690 CNC\n', encoding='utf-8')
            os.utime(document, ns=(mtime + 10_000_000_000, mtime + 10_000_000_000))
        return original_reader(path)

    status = invoke(source, output, mutate_after_hash)
    check('same-size mutation aborts pack', status != '0')
    check('same-size mutation has stable sanitized error', status == 'SOURCE_CHANGED_DURING_PACK')
    check('source was actually modified', document.read_text() == 'Material S690 CNC\n')
    check('previous ZIP bytes survive mutation', output.read_bytes() == saved_zip)
    check('previous ZIP SHA256 survives mutation', hashlib.sha256(output.read_bytes()).hexdigest() == saved_sha)
    check('no temporary ZIP left after mutation', not list(source.glob('.private.zip.*.tmp')))

    # A source can also change while its bytes are being hashed. Check the
    # file descriptor state after reading, not only the path before extraction.
    document.write_text('Material S355 CNC\n', encoding='utf-8')
    mtime = document.stat().st_mtime_ns
    original_open = Path.open
    class ChangingRead:
        def __init__(self, stream):
            self.stream = stream
            self.changed = False
        def __enter__(self):
            self.stream.__enter__()
            return self
        def __exit__(self, *args):
            return self.stream.__exit__(*args)
        def fileno(self):
            return self.stream.fileno()
        def read(self, *args, **kwargs):
            value = self.stream.read(*args, **kwargs)
            if not self.changed:
                self.changed = True
                document.write_text('Material S690 CNC\n', encoding='utf-8')
                os.utime(document, ns=(mtime + 10_000_000_000, mtime + 10_000_000_000))
            return value

    def changing_open(self, mode='r', *args, **kwargs):
        stream = original_open(self, mode, *args, **kwargs)
        if self == document and mode == 'rb':
            return ChangingRead(stream)
        return stream

    with patch.object(Path, 'open', changing_open):
        status = invoke(source, output)
    check('mutation during hash aborts pack', status == 'SOURCE_CHANGED_DURING_PACK')
    check('hash-time mutation really changed file', document.read_text() == 'Material S690 CNC\n')
    check('hash-time mutation preserves prior ZIP', output.read_bytes() == saved_zip)
    check('hash-time mutation leaves no temporary ZIP', not list(source.glob('.private.zip.*.tmp')))

    # After a failed attempt, a stable retry should work normally.
    retry = subprocess.run([sys.executable, str(ENGINE), str(source), str(output)],
                           capture_output=True, text=True, timeout=30)
    check('stable retry exits 0', retry.returncode == 0)
    check('stable retry reports success', json.loads(retry.stdout)['ok'] is True)
    with zipfile.ZipFile(output) as archive:
        check('stable retry ZIP CRC valid', archive.testzip() is None)
        manifest = json.loads(archive.read('MANIFEST.json'))
        check('stable retry source count correct', manifest['file_count'] == 1)
        check('stable retry SHA256 correct', manifest['files'][0]['sha256'] == hashlib.sha256(document.read_bytes()).hexdigest())
    check('stable retry replaces stale ZIP', output.read_bytes() != saved_zip)

cmd = (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text('utf-8-sig')
ps1 = (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text('utf-8-sig')
workflow = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text('utf-8')
name = 'run_fix75_private_pack_source_mutation_guard.py'
check('CMD release gate includes FIX75', ('%PY% tests\\' + name + ' || exit /b 1') in cmd)
check('PowerShell release gate includes FIX75', ('"tests\\' + name + '",') in ps1)
check('private Windows CI includes FIX75', ('run: python tests/' + name) in workflow)
print(f'FIX75: {checks}/{checks} PASS; FAIL=0 SKIP=0 TIMEOUT=0', flush=True)
