from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parents[1]


def text(relative_path):
    return (ROOT / relative_path).read_text(encoding="utf-8-sig")


def check(name, condition):
    global passed, failed
    if condition:
        passed += 1
        print("PASS ", name)
    else:
        failed += 1
        print("FAIL ", name)


passed = failed = 0
analysis = text("src/DSEstimate.Infrastructure/ProjectAnalysisService.cs")
report = text("src/DSEstimate.Infrastructure/DiagnosticReportService.cs")
release = text("RUN_FULL_RELEASE_TESTS.cmd")
build = text("BUILD_FULL_PORTABLE_ZIP.ps1")

customer_branch = re.search(
    r"if \(customerMatch\.Success\)\s*\{(?P<body>.*?)\n\s*\}",
    analysis,
    flags=re.DOTALL,
)
customer_body = customer_branch.group("body") if customer_branch else ""

check("customer revision branch exists", customer_branch is not None)
check("customer revision label has a distinct local name", "var customerLabel" in customer_body)
check("customer revision family has a distinct local name", "var customerFamily" in customer_body)
check("customer revision rank has a distinct local name", "var customerRank" in customer_body)
check("conflicting label declaration removed from nested branch", "var label" not in customer_body)
check("conflicting family declaration removed from nested branch", "var family" not in customer_body)
check("customer token uses renamed locals", "new RevisionToken(customerFamily, customerLabel, customerRank" in customer_body)
check("standard revision branch remains present", "var label = (match.Groups" in analysis and "var family = rx.Replace" in analysis)
check("diagnostic identifies FIX16B", "FIX16B COMPILE FIX" in report)
check("FIX16B wired into release gate", "run_fix16b_compile_guard.py" in release)
check("FIX16B wired into portable build gate", "run_fix16b_compile_guard.py" in build)
check("ProjectAnalysisService braces balanced", analysis.count("{") == analysis.count("}"))

print(f"\nSUMMARY PASS={passed} FAIL={failed}")
sys.exit(1 if failed else 0)
