﻿#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
paths={
    'cost':ROOT/'src/DSEstimate.Core/CostEngine.cs',
    'domain':ROOT/'src/DSEstimate.Core/Domain.cs',
    'auto':ROOT/'src/DSEstimate.Core/AutoQuoteEngine.cs',
    'merge':ROOT/'src/DSEstimate.Infrastructure/ProjectAnalysisService.cs',
    'shadow':ROOT/'src/DSEstimate.Infrastructure/AssemblyStateGraphBuilder.cs',
    'report':ROOT/'src/DSEstimate.Infrastructure/DiagnosticReportService.cs',
    'ui':ROOT/'src/DSEstimate.App/Views/MainWindow.axaml',
    'settings':ROOT/'src/DSEstimate.Infrastructure/SettingsRepository.cs',
    'xunit':ROOT/'tests/DSEstimate.Core.Tests/Fix12BCostRealityTests.cs',
}
text={k:p.read_text(encoding='utf-8-sig') for k,p in paths.items()}
checks=[]
def check(name,cond):
    checks.append((name,bool(cond))); print(('PASS  ' if cond else 'FAIL  ')+name)

check('nesting has explicit price authority flag','UsedForMaterialCost' in text['domain'])
check('extreme nesting falls back to shop waste','NestingPriceAuthorityMaxFactor' in text['domain'] and 'nestingTrustedForPrice' in text['cost'] and 'UsedForMaterialCost = false' in text['cost'])
check('material basis says diagnostic nesting not used','NIE użyto go do ceny' in text['cost'])
check('unknown mass scope does not create project conflict','comparableProjectScope' in text['cost'] and 'lokalnym kandydatem' in text['cost'])
check('unknown mass not bound globally in shadow','unknownMassScope' in text['shadow'] and 'nie może zostać automatycznie przypięta do całego projektu' in text['shadow'])
check('same S355 family variation downgraded','Materiał — różne pozycje/rysunki' in text['merge'] and 'Level = RiskLevel.Low' in text['merge'])
check('material resolver uses distinct local variable names','var chosenSpecific = specific[0];' in text['merge'] and 'var chosenDominant = groups[0].Key;' in text['merge'])
check('manual preparation process exists','Code = "PREP_MANUAL"' in text['cost'])
check('machine preparation process exists','Code = "PREP_MACHINE"' in text['cost'])
check('cnc unique-group programming exists','CncProgrammingMinutesPerUniqueGroup' in text['domain'] and 'programmingGroupCount' in text['cost'])
check('manual cnc operations cost centre exists','Code = "CNC_MANUAL"' in text['cost'] and 'CNC_MANUAL_3205' in text['domain'])
check('fabrication complexity uses parts contacts mass envelope','AssemblyMinutesPerPart' in text['domain'] and 'AssemblyMinutesPerContact' in text['domain'] and 'assemblyEnvelopeMinutes' in text['cost'])
check('unpriced external makes quote incomplete','Status = status' in text['auto'] and ('IsPriceComplete = externalUnpriced == 0' in text['auto'] or 'IsPriceComplete = offerPriceAvailable && externalUnpriced == 0' in text['auto']) and '"NIEPEŁNA"' in text['auto'])
check('partial price gets explicit UI label','Analysis.AutoQuote.PriceLabel' in text['ui'])
check('partial price appears in diagnostic report','UWAGA CENOWA' in text['report'])
check('settings migration enables 3205 3302 3303','WorkstationDefaultsVersion < 4' in text['settings'] and 'PREP_MACHINE' in text['settings'])
check('behavior xunit tests added',paths['xunit'].exists() and 'Extreme_bbox_nesting_is_diagnostic_not_material_price_multiplier' in text['xunit'])
for k in ('cost','domain','auto','merge','shadow','report','settings','xunit'):
    check(f'{k} braces balanced', text[k].count('{')==text[k].count('}'))
passed=sum(v for _,v in checks); failed=len(checks)-passed
print(f'\nSUMMARY PASS={passed} FAIL={failed}')
sys.exit(1 if failed else 0)
