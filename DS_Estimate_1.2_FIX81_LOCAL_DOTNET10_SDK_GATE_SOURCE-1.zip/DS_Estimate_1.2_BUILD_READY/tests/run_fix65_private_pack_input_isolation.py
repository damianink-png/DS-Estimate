"""FIX65: runtime privacy-pack isolation checks; no .NET execution implied."""
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "engines/python/build_private_analysis_pack.py"


def check(label, ok):
    print(("PASS" if ok else "FAIL") + " | " + label, flush=True)
    if not ok:
        raise AssertionError(label)


def run(source, output):
    result = subprocess.run(
        [sys.executable, str(SCRIPT), str(source), str(output)],
        capture_output=True, text=True, timeout=40,
    )
    check("generator exits 0", result.returncode == 0)
    with zipfile.ZipFile(output) as archive:
        check("archive CRC is valid", archive.testzip() is None)
        names = set(archive.namelist())
        check("no raw input files are packed", names == {
            "MANIFEST.json", "TECHNICAL_SNIPPETS.json", "README_PRIVACY.txt"
        })
        return json.loads(archive.read("MANIFEST.json"))


with tempfile.TemporaryDirectory(prefix="dse_fix65_") as tmp:
    root = Path(tmp) / "client"
    root.mkdir()
    (root / "S355_part.txt").write_text("S355, CNC 3 sztuki", encoding="utf-8")
    out = root / "private_pack.zip"
    first = run(root, out)
    check("initial pack contains only input document", first["file_count"] == 1)
    check("initial input is txt", first["files"][0]["extension"] == ".txt")
    second = run(root, out)
    check("repeat pack does not ingest previous ZIP", second["file_count"] == 1)
    check("repeat source byte count is stable", second["source_total_bytes"] == first["source_total_bytes"])
    check("repeat source file hash is stable", second["files"][0]["sha256"] == first["files"][0]["sha256"])
    check("repeat pack contains no ZIP source record", all(
        entry["extension"] != ".zip" for entry in second["files"]
    ))

    # Real symlink regression on hosts that permit creating symlinks. The
    # mandatory self-inclusion checks above work on all Windows/Linux hosts.
    external = Path(tmp) / "external_confidential.txt"
    external.write_text("S960QL confidential external geometry", encoding="utf-8")
    link = root / "external_link.txt"
    try:
        link.symlink_to(external)
    except (OSError, NotImplementedError):
        # Windows may prohibit unprivileged symlink creation. The code-level
        # is_symlink guard is still mandatory on every platform.
        check("symlink guard remains in source", "if p.is_symlink() or p.resolve() == out" in SCRIPT.read_text("utf-8"))
    else:
        third = run(root, out)
        check("external symlink does not enter private pack", third["file_count"] == 1)
        check("external symlink bytes are not counted", third["source_total_bytes"] == first["source_total_bytes"])

print("FIX65: private pack input isolation PASS (runtime)")
