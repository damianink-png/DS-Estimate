#!/usr/bin/env python3
"""FIX40: static verification of xUnit console-log retention in Windows CI.

This script DOES NOT run .NET, xUnit or GitHub Actions. Real TRX remains mandatory.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
workflow = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text(encoding='utf-8')
checks = []


def check(label, condition):
    checks.append((label, bool(condition)))
    print(('PASS ' if condition else 'FAIL ') + label, flush=True)


def step(name):
    marker = f'      - name: {name}\n'
    count = workflow.count(marker)
    check(f'unique CI step {name}', count == 1)
    if count != 1:
        return ''
    start = workflow.index(marker)
    end = workflow.find('\n      - ', start + len(marker))
    return workflow[start:end if end >= 0 else len(workflow)]


runner = step('Run C# xUnit tests')
verify = step('Verify xUnit TRX contains executed tests')
upload = step('Save test results')
check('real C# xUnit project remains the execution target',
      'dotnet test tests/DSEstimate.Core.Tests/DSEstimate.Core.Tests.csproj' in runner)
check('runner keeps Release/no-build/no-restore',
      all(flag in runner for flag in ('-c Release', '--no-build', '--no-restore')))
check('real TRX output remains enabled',
      '--logger "trx;LogFileName=ds-estimate-xunit.trx"' in runner)
check('runner uses Windows PowerShell', 'shell: pwsh' in runner)
check('runner redirects stderr and stdout into CI log',
      '2>&1 | Tee-Object -FilePath TestResults/xunit-execution.log' in runner)
check('runner propagates dotnet native exit code',
      'if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }' in runner)
check('TRX guard still requires actual results and 60 executed tests',
      '--require-results --min-executed 60' in verify)
check('xUnit log uploaded even after CI failure',
      'if: always()' in upload and 'TestResults/xunit-execution.log' in upload)
check('artifact upload does not include source or test fixture',
      'src/' not in upload and 'launcher-smoke' not in upload)
check('runner precedes TRX verification and artifact upload',
      workflow.index('      - name: Run C# xUnit tests') <
      workflow.index('      - name: Verify xUnit TRX contains executed tests') <
      workflow.index('      - name: Save test results'))
for gate in ('RUN_FULL_RELEASE_TESTS.cmd', 'BUILD_FULL_PORTABLE_ZIP.ps1'):
    check(f'{gate} includes FIX40 regression',
          'run_fix40_xunit_execution_evidence.py' in
          (ROOT / gate).read_text(encoding='utf-8-sig'))
passed = sum(ok for _, ok in checks)
print(f'SUMMARY PASS={passed} FAIL={len(checks)-passed} SKIP=0', flush=True)
raise SystemExit(0 if passed == len(checks) else 1)
