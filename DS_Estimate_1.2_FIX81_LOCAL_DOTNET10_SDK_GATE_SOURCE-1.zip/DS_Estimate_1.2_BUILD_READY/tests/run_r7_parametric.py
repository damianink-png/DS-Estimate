﻿#!/usr/bin/env python3
from __future__ import annotations

import contextlib
import io
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENGINES = ROOT / "engines" / "python"
sys.path.insert(0, str(ENGINES))

try:
    import cadquery as cq
    import analyze_step
except Exception as exc:
    print(f"SKIP: CadQuery/STEP engine unavailable: {exc}")
    raise SystemExit(2)

PASS = 0
FAIL = 0
FAILURES: list[tuple[str, str]] = []


def run_step(path: Path):
    old_argv = sys.argv
    sys.argv = [str(ENGINES / "analyze_step.py"), str(path)]
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            analyze_step.main()
    finally:
        sys.argv = old_argv
    return json.loads(buf.getvalue().strip().splitlines()[-1])


def check(name: str, condition: bool, detail: str = ""):
    global PASS, FAIL
    if condition:
        PASS += 1
    else:
        FAIL += 1
        FAILURES.append((name, detail))
        print(f"FAIL {name}: {detail}")


def export(path: Path, obj):
    cq.exporters.export(obj, str(path))
    return path


def main():
    with tempfile.TemporaryDirectory(prefix="ds_estimate_parametric_") as td:
        td = Path(td)

        for dia in [6, 10, 12, 20, 30, 45]:
            obj = cq.Workplane("XY").box(120, 100, 24).faces(">Z").workplane().hole(dia)
            r = run_step(export(td / f"through_{dia}.step", obj))
            holes = r["parts"][0]["holes"]
            check(f"through {dia} count", r["totalHoleCount"] == 1, str(holes))
            check(f"through {dia} diameter", len(holes) == 1 and abs(holes[0]["diameterMm"] - dia) < 0.25, str(holes))
            check(f"through {dia} flag", len(holes) == 1 and holes[0]["throughLikely"], str(holes))

        for dia, depth in [(6, 4), (10, 8), (14, 12), (20, 18)]:
            obj = cq.Workplane("XY").box(120, 100, 24).faces(">Z").workplane().hole(dia, depth=depth)
            r = run_step(export(td / f"blind_{dia}_{depth}.step", obj))
            h = r["parts"][0]["holes"][0]
            check(f"blind {dia}x{depth} diameter", abs(h["diameterMm"] - dia) < 0.25, str(h))
            check(f"blind {dia}x{depth} depth", abs(h["depthMm"] - depth) < 0.25, str(h))
            check(f"blind {dia}x{depth} flag", not h["throughLikely"], str(h))

        for angle in [60, 82, 90, 100, 120]:
            obj = cq.Workplane("XY").box(120, 100, 24).faces(">Z").workplane().cskHole(10, 20, angle)
            r = run_step(export(td / f"csk_{angle}.step", obj))
            h = r["parts"][0]["holes"][0]
            check(f"csk {angle} class", h["countersinkLikely"], str(h))
            check(f"csk {angle} angle", abs(h["countersinkAngleDeg"] - angle) < 0.8, str(h))

        for hole, cbore, depth in [(8, 14, 3), (10, 20, 5), (16, 28, 6)]:
            obj = cq.Workplane("XY").box(120, 100, 24).faces(">Z").workplane().cboreHole(hole, cbore, depth)
            r = run_step(export(td / f"cb_{hole}_{cbore}_{depth}.step", obj))
            h = r["parts"][0]["holes"][0]
            check(f"cbore {hole}/{cbore} count", r["totalHoleCount"] == 1, str(h))
            check(f"cbore {hole}/{cbore} diameter", abs(h["diameterMm"] - hole) < 0.25 and abs(h["maxDiameterMm"] - cbore) < 0.3, str(h))
            check(f"cbore {hole}/{cbore} stage", h["counterboreLikely"] or h["spotfaceLikely"], str(h))

        # Base top is Z=10. Rib height in world Z is 50, so centre Z=35 gives exact contact.
        for length, width in [(40, 6), (80, 8), (120, 10), (160, 12)]:
            base = cq.Workplane("XY").box(220, 160, 10).translate((0, 0, 5))
            rib = cq.Workplane("XZ").box(length, 50, width).translate((0, 0, 35))
            compound = cq.Compound.makeCompound([base.val(), rib.val()])
            r = run_step(export(td / f"t_{length}_{width}.step", compound))
            check(f"T {length}x{width} pair", r["weldCandidatePairs"] == 1, str(r["jointCandidates"]))
            check(f"T {length}x{width} length", abs(r["weldCandidateLengthMm"] - length) < 1.0, str(r["jointCandidates"]))
            check(f"T {length}x{width} contact", abs(r["planarMatingAreaMm2"] - length * width) < 2.0, str(r["jointCandidates"]))

    print(f"PARAMETRIC PASS={PASS} FAIL={FAIL}")
    for name, detail in FAILURES:
        print(f" - {name}: {detail}")
    return 1 if FAIL else 0


if __name__ == "__main__":
    # CadQuery/OCP can report a native shutdown failure after all assertions
    # and TemporaryDirectory cleanup have already completed.  The main R7
    # regression uses the same guard.  Flush the report, then return exactly
    # the status produced by the test suite (0 for PASS, 1 for real failures).
    rc = main()
    try:
        sys.stdout.flush(); sys.stderr.flush()
    finally:
        os._exit(rc)
