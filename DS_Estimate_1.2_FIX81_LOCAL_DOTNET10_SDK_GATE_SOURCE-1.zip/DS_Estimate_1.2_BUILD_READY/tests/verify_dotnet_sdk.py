#!/usr/bin/env python3
"""Fail closed unless the dotnet CLI selects an SDK from the .NET 10 family.

This is a local Windows release preflight, not evidence of a compiled binary.
"""
from __future__ import annotations

import re
import subprocess
import sys


def selected_sdk_major() -> int:
    try:
        result = subprocess.run(
            ["dotnet", "--version"], capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=20, check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ValueError("dotnet --version could not complete") from exc
    if result.returncode != 0:
        raise ValueError("dotnet --version returned a nonzero exit code")
    version = result.stdout.strip()
    # dotnet --version prints only the selected SDK version, not the runtime.
    # Reject diagnostic text, multiple lines, or an empty response.
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?", version):
        raise ValueError("dotnet --version returned an invalid SDK version")
    return int(version.split(".", 1)[0])


def main() -> int:
    try:
        major = selected_sdk_major()
        if major != 10:
            raise ValueError("selected SDK is not .NET 10")
    except ValueError as exc:
        print(f"FAIL .NET 10 SDK preflight: {exc}", file=sys.stderr)
        return 1
    print("PASS .NET 10 SDK preflight: selected SDK major=10")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
