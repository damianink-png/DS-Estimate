#!/usr/bin/env python3
"""FIX26: per-sheet traceability, BOM boundaries and backward compatibility."""
from __future__ import annotations
import importlib.util
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('dse_fix26_document', ROOT / 'engines/python/analyze_document.py')
document = importlib.util.module_from_spec(spec)
spec.loader.exec_module(document)
passed = failed = skipped = 0


def check(name, value):
    global passed, failed
    if value:
        passed += 1
        print('PASS', name)
    else:
        failed += 1
        print('FAIL', name)


first = 'DRAWING: 120-200\nMATERIAL: S355J2\nISO 5817\n'
second = 'DRAWING: 120-201\nMATERIAL: S960QL\nISO 2768-m\n'
bom = 'POS DOKNR MENGE GEWICHT\nPART-001\n2 ST\n20 KG\nPART-002\n3 ST\n9 KG\n'
rows = document._pdf_page_evidence([first, second, bom], source_file='parts.pdf')
check('three separate sheets have evidence', len(rows) == 3)
check('page numbers are 1-based', [r['pageNumber'] for r in rows] == [1, 2, 3])
check('drawing IDs stay on their original sheets', rows[0]['drawingNumbers'] == ['120-200'] and rows[1]['drawingNumbers'] == ['120-201'])
check('different materials are not merged in page metadata', rows[0]['materialHint'] == 'S355J2' and rows[1]['materialHint'] == 'S960QL')
check('BOM rows only on sheet 3', rows[0]['bomRowCount'] == rows[1]['bomRowCount'] == 0 and rows[2]['bomRowCount'] == 2)
check('BOM part numbers retained', rows[2]['bomPartNumbers'] == ['PART-001', 'PART-002'])
check('BOM part numbers are not mistaken for drawing IDs', rows[2]['drawingNumbers'] == [])
check('OCR evidence stays on its sheet', document._pdf_page_evidence([first, second], {1: 'DRAWING: 120-201\nISO 5817'}, source_file='x.pdf')[1]['ocrApplied'])
check('OCR does not leak across pages', not document._pdf_page_evidence([first, second], {1: 'PART-001\n2 ST\n20 KG'}, source_file='x.pdf')[0]['bomPartNumbers'])
check('header on previous sheet does not synthesize BOM rows', not any(x['bomRowCount'] for x in document._pdf_page_evidence(['POS DOKNR MENGE GEWICHT', 'PART-001\n2 ST\n20 KG'])))
check('blank pages without signals are omitted', document._pdf_page_evidence(['', first])[0]['pageNumber'] == 2)
check('scanned page with no OCR text remains visible', document._pdf_page_evidence([''], scanned_indices=[0])[0]['suspectedRaster'])
check('OCR attempt with empty result is distinguished', document._pdf_page_evidence([''], {0: ''})[0]['ocrApplied'] and not document._pdf_page_evidence([''], {0: ''})[0]['ocrTextPresent'])
check('timed-out OCR attempt remains auditable', document._pdf_page_evidence([''], ocr_attempted={0})[0]['ocrApplied'])
check('references remain references not steel grades', document._pdf_page_evidence(['MATERIAL: AA1234-BB5678'])[0]['materialHint'] == '')
check('C# DTO for page evidence exists', 'public sealed class DrawingPageEvidence' in (ROOT / 'src/DSEstimate.Core/Domain.cs').read_text(encoding='utf-8-sig'))
check('C# report shows page evidence', 'Dowody wg arkuszy PDF' in (ROOT / 'src/DSEstimate.Infrastructure/DiagnosticReportService.cs').read_text(encoding='utf-8-sig'))
check('PDF cache invalidated', 'fix26-page-evidence-v1' in (ROOT / 'src/DSEstimate.Infrastructure/DocumentAnalyzers.cs').read_text(encoding='utf-8-sig'))
check('release gate includes test', 'run_fix26_pdf_page_evidence.py' in (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='utf-8-sig'))
check('portable gate includes test', 'run_fix26_pdf_page_evidence.py' in (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig'))

try:
    import pymupdf as fitz
except ImportError:
    skipped += 1
    print('SKIP real multi-page PDF (PyMuPDF unavailable)')
else:
    with tempfile.TemporaryDirectory() as tmp:
        pdf_path = Path(tmp) / 'real-multi-sheet.pdf'
        pdf = fitz.open()
        for text in (first, second, bom):
            page = pdf.new_page(width=650, height=600)
            page.insert_text((40, 40), text, fontsize=11)
        pdf.save(pdf_path)
        pdf.close()
        previous = os.environ.get('DSE_SKIP_PDF_OCR')
        os.environ['DSE_SKIP_PDF_OCR'] = '1'
        try:
            output = document.analyze_pdf(pdf_path)
        finally:
            if previous is None:
                os.environ.pop('DSE_SKIP_PDF_OCR', None)
            else:
                os.environ['DSE_SKIP_PDF_OCR'] = previous
        check('real PDF has correct page count', output.get('pdfPageCount') == 3)
        ev = output.get('pageEvidence') or []
        check('real PDF has 3 evidence entries', len(ev) == 3)
        check('real PDF preserves drawing IDs by sheet', [x['drawingNumbers'] for x in ev[:2]] == [['120-200'], ['120-201']])
        check('real PDF preserves materials by sheet', [x['materialHint'] for x in ev[:2]] == ['S355J2', 'S960QL'])
        check('real PDF identifies BOM parts on sheet 3', ev[2]['bomPartNumbers'] == ['PART-001', 'PART-002'])
        check('real PDF warns about mixed materials', any('PDF_MULTI_SHEET_MATERIALS' in x for x in output['warnings']))
        check('real PDF keeps legacy global signals', bool(output.get('materialHint')) and bool(output.get('findings')))
        check('real PDF carries its source file', all(x['sourceFile'] == pdf_path.name for x in ev))

# Optional real OCR integration. This verifies provenance with the actual
# Tesseract binary, not a fake result. Skip on clean build hosts without OCR.
try:
    import io
    from PIL import Image, ImageDraw, ImageFont
    import pymupdf as fitz
    ocr_exe = document.resolve_tesseract_executable()
    font = ImageFont.truetype('DejaVuSans.ttf', 48)
except (ImportError, OSError) as exc:
    skipped += 1
    print('SKIP real OCR integration:', exc)
else:
    if not ocr_exe:
        skipped += 1
        print('SKIP real OCR integration: Tesseract not installed')
    else:
        with tempfile.TemporaryDirectory() as tmp:
            pdf_path = Path(tmp) / 'real-ocr-two-sheets.pdf'
            pdf = fitz.open()
            pdf.new_page(width=595, height=842).insert_text(
                (40, 50), 'DRAWING: 111-222\nMATERIAL: S355J2', fontsize=15)
            raster = Image.new('RGB', (900, 1000), 'white')
            drawer = ImageDraw.Draw(raster)
            drawer.text((70, 90), 'DRAWING: 222-333', fill='black', font=font)
            drawer.text((70, 220), 'MATERIAL: S960QL', fill='black', font=font)
            stream = io.BytesIO()
            raster.save(stream, format='PNG')
            pdf.new_page(width=595, height=842).insert_image(
                fitz.Rect(0, 0, 595, 842), stream=stream.getvalue())
            pdf.save(pdf_path)
            pdf.close()
            old_env = {key: os.environ.get(key) for key in ('DSE_SKIP_PDF_OCR', 'DSE_OCR_MAX_PAGES')}
            os.environ.pop('DSE_SKIP_PDF_OCR', None)
            os.environ['DSE_OCR_MAX_PAGES'] = '1'
            try:
                result = document.analyze_pdf(pdf_path)
            finally:
                for key, value in old_env.items():
                    if value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = value
            ev = result.get('pageEvidence', [])
            check('real OCR selected raster sheet 2',
                  len(ev) == 2 and ev[1]['ocrApplied'] and ev[1]['suspectedRaster'])
            check('real OCR did not mark vector sheet 1',
                  len(ev) == 2 and not ev[0]['ocrApplied'])
            check('real OCR produced page-specific text',
                  len(ev) == 2 and ev[1]['ocrTextPresent'])
            check('real OCR page 2 did not inherit material from sheet 1',
                  len(ev) == 2 and ev[1]['materialHint'] != 'S355J2')

print(f'\nSUMMARY PASS={passed} FAIL={failed} SKIP={skipped}')
sys.exit(1 if failed else 0)
