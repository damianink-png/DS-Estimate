#!/usr/bin/env python3
"""Validate an actual xUnit/VSTest TRX before treating CI as successful.

This is an independent post-test guard. It does NOT execute .NET tests itself.
Usage: python tests/verify_dotnet_trx.py TestResults/ds-estimate-xunit.trx
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from xml.etree import ElementTree as ET


class TrxValidationError(ValueError):
    """Missing, malformed, empty or unsuccessful .NET test results."""


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def verify_trx(path: Path, *, require_results: bool = False, min_executed: int = 1,
               reject_skipped: bool = False) -> dict[str, int]:
    if reject_skipped:
        require_results = True  # A strict gate must inspect actual result records.
    if min_executed < 1:
        raise TrxValidationError("min_executed must be at least 1")
    if not path.is_file():
        raise TrxValidationError(f"TRX does not exist: {path}")
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError) as exc:
        raise TrxValidationError(f"Cannot read TRX: {exc}") from exc
    if _local_name(root.tag) != "TestRun":
        raise TrxValidationError("Expected TRX TestRun root")
    summaries = [element for element in root if _local_name(element.tag) == "ResultSummary"]
    if len(summaries) != 1:
        raise TrxValidationError("Expected exactly one TRX ResultSummary")
    counters = [element for element in summaries[0] if _local_name(element.tag) == "Counters"]
    if len(counters) != 1:
        raise TrxValidationError("Missing or duplicate TRX Counters")
    required = ("total", "executed", "passed", "failed", "error")
    values: dict[str, int] = {}
    for name in required:
        raw = counters[0].get(name)
        try:
            value = int(raw) if raw is not None else -1
        except ValueError as exc:
            raise TrxValidationError(f"Invalid TRX {name}={raw!r}") from exc
        if value < 0:
            raise TrxValidationError(f"Missing or negative TRX counter: {name}")
        values[name] = value
    if values["total"] < 1 or values["executed"] < 1 or values["passed"] < 1:
        raise TrxValidationError("No passing tests executed (empty/discovery-only test run)")
    # FIX37: a small green subset is not proof that the expected xUnit suite
    # was discovered. The CI workflow sets a conservative project-specific floor.
    if values["executed"] < min_executed:
        raise TrxValidationError(
            f"Too few discovered/executed tests: {values['executed']} < {min_executed}"
        )
    if values["executed"] > values["total"] or values["passed"] > values["executed"]:
        raise TrxValidationError("Inconsistent TRX counters")
    # FIX48: the default remains compatible with historical reports, but CI
    # must not present a run with skipped/not-executed tests as fully green.
    if reject_skipped:
        for counter in ("notExecuted", "skipped"):
            raw = counters[0].get(counter, "0")
            try:
                count = int(raw)
            except ValueError as exc:
                raise TrxValidationError(f"Invalid TRX {counter}={raw!r}") from exc
            if count != 0:
                raise TrxValidationError(f"Skipped/not-executed TRX counter {counter}={count}")
    if reject_skipped and values["total"] != values["executed"]:
        raise TrxValidationError(
            f"Skipped or not-executed tests in TRX: total={values['total']}, "
            f"executed={values['executed']}"
        )
    # FIX34: zero explicit failures alone is insufficient. VSTest can report
    # an executed test as inconclusive (or another non-pass outcome), leaving
    # passed < executed while the checked failed/error counters stay at zero.
    # Skipped tests remain allowed: they increase total, not executed.
    if values["passed"] != values["executed"]:
        raise TrxValidationError(
            f"Not all executed tests passed: passed={values['passed']}, "
            f"executed={values['executed']}"
        )
    # FIX49: VSTest exposes additional non-PASS states. A synthetic or
    # inconsistent TRX could otherwise claim passed == executed while also
    # reporting inconclusive/pending/disconnected cases. In strict CI mode,
    # reject these counters explicitly rather than trusting only the five
    # historical failure counters. Keep legacy non-strict behavior unchanged.
    nonpass_counters = ["failed", "error", "timeout", "aborted", "notRunnable"]
    if reject_skipped:
        nonpass_counters.extend(("inconclusive", "passedButRunAborted", "disconnected",
                                 "warning", "inProgress", "pending"))
    for name in nonpass_counters:
        raw = counters[0].get(name, "0")
        try:
            value = int(raw)
        except ValueError as exc:
            raise TrxValidationError(f"Invalid TRX {name}={raw!r}") from exc
        if value < 0 or value > 0:
            raise TrxValidationError(f"Unsuccessful TRX counter {name}={value}")
    if summaries[0].get("outcome", "").lower() not in {"completed", "passed"}:
        raise TrxValidationError(f"TRX outcome is not completed: {summaries[0].get('outcome')!r}")
    # FIX35: CI must prove discovery from actual UnitTestResult records, not
    # merely trust a Counters element (which can exist without any test cases).
    # Optional to retain compatibility with earlier, counters-only guard tests.
    if require_results:
        result_sections = [child for child in root if _local_name(child.tag) == "Results"]
        if len(result_sections) != 1:
            raise TrxValidationError("Expected exactly one TRX Results section")
        records = list(result_sections[0])
        if not records or any(_local_name(record.tag) != "UnitTestResult" for record in records):
            raise TrxValidationError("TRX has no valid UnitTestResult records")
        passed_records = 0
        # FIX50: in strict CI mode, a duplicated result must not inflate the
        # apparent discovery count.  The same testId can legitimately appear
        # for parameterized/retried cases, so compare the complete available
        # identity (testId, executionId, testName), not testId alone.
        seen_result_identities: set[tuple[str, str, str]] = set()
        for record in records:
            outcome = record.get("outcome", "").lower()
            test_id = (record.get("testId") or "").strip()
            if not test_id:
                raise TrxValidationError("UnitTestResult is missing its testId")
            if reject_skipped:
                identity = (test_id, (record.get("executionId") or "").strip(),
                            (record.get("testName") or "").strip())
                if identity in seen_result_identities:
                    raise TrxValidationError(
                        "Duplicate UnitTestResult identity in strict TRX: "
                        f"testId={test_id!r}"
                    )
                seen_result_identities.add(identity)
            if outcome == "passed":
                passed_records += 1
            elif outcome in {"notexecuted", "skipped"} and reject_skipped:
                raise TrxValidationError(f"Skipped UnitTestResult is forbidden in CI: {outcome!r}")
            elif outcome not in {"notexecuted", "skipped"}:
                raise TrxValidationError(f"Unsuccessful UnitTestResult outcome: {outcome!r}")
        if passed_records != values["passed"] or len(records) > values["total"]:
            raise TrxValidationError(
                "TRX UnitTestResult records disagree with counters: "
                f"records={len(records)}, passed_records={passed_records}, "
                f"total={values['total']}, passed={values['passed']}"
            )
    return values


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trx", type=Path)
    parser.add_argument("--require-results", action="store_true",
                        help="Require real UnitTestResult records matching the TRX counters")
    parser.add_argument("--reject-skipped", action="store_true",
                        help="Fail if any test was skipped/not executed (strict CI gate)")
    parser.add_argument("--min-executed", type=int, default=1, metavar="N",
                        help="Reject partial test discovery if fewer than N tests executed")
    args = parser.parse_args(argv)
    try:
        values = verify_trx(args.trx, require_results=args.require_results,
                            min_executed=args.min_executed,
                            reject_skipped=args.reject_skipped)
    except TrxValidationError as exc:
        print(f"FAIL xUnit TRX verification: {exc}", file=sys.stderr)
        return 1
    print(f"PASS xUnit TRX verification: {values}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
