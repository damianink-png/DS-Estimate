#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
paths={
    'contract': ROOT/'src/DSEstimate.Core/TechnologyGraph.cs',
    'domain': ROOT/'src/DSEstimate.Core/Domain.cs',
    'builder': ROOT/'src/DSEstimate.Infrastructure/AssemblyStateGraphBuilder.cs',
    'service': ROOT/'src/DSEstimate.Infrastructure/ProjectAnalysisService.cs',
    'report': ROOT/'src/DSEstimate.Infrastructure/DiagnosticReportService.cs',
    'tests': ROOT/'tests/DSEstimate.Core.Tests/Fix12ShadowGraphTests.cs',
    'csproj': ROOT/'tests/DSEstimate.Core.Tests/DSEstimate.Core.Tests.csproj',
    'gate': ROOT/'RUN_FULL_RELEASE_TESTS.cmd',
    'build': ROOT/'BUILD_FULL_PORTABLE_ZIP.ps1',
}
text={k:p.read_text(encoding='utf-8-sig') for k,p in paths.items()}
checks=[]
def check(name, cond):
    checks.append((name,bool(cond)))
    print(('PASS  ' if cond else 'FAIL  ')+name)

check('contract file exists', paths['contract'].exists())
for typ in ['UniquePartGroup','AssemblyState','ProcessNode','EvidenceBinding','ConfidenceVector','ShadowTechnologyGraph']:
    check(f'contract {typ}', f'class {typ}' in text['contract'])
check('multi-factor cost confidence formula', '0.35 * Clamp(Binding)' in text['contract'] and '0.35 * Clamp(Geometry)' in text['contract'] and '0.30 * Clamp(Parameters)' in text['contract'])
check('shadow graph no price authority by default', 'public bool HasPriceAuthority { get; set; }' in text['contract'] and 'HasPriceAuthority = false' in text['builder'])
check('analysis result stores separate shadow graph', 'ShadowTechnologyGraph ShadowTechnologyGraph' in text['domain'])
check('builder creates UniquePartGroup from STEP groups', 'BuildUniqueGroups' in text['builder'] and 'analysis.Geometry.Parts' in text['builder'])
check('builder creates assembly geometry state', 'AssemblyGeometry(analysis)' in text['builder'] and 'ManufacturingStateKind.WeldedAssembly' in text['builder'])
check('post-weld uses state not part bbox', 'STATE-WELDED-ASSEMBLY' in text['builder'] and 'TechnologyProcessKind.PostMachining' in text['builder'])
check('post-weld state inherits assembly mass', 'current.Geometry.MassKg = assemblyGeometry.MassKg' in text['builder'])
check('evidence canonical contract', 'Source -> Observation -> Candidate targets -> Geometry filter -> Process constraint' in text['contract'])
check('evidence unresolved instead of forced global target', 'brak jednoznacznego celu geometrycznego' in text['builder'])
check('partial dxf is shadow warning', 'DXF scope:' in text['builder'])
check('paint low-ratio reality check is shadow warning', 'Reality-check shadow' in text['builder'])
check('project service invokes shadow after evidence', 'result.Evidence = EvidenceOrchestrator.Build' in text['service'] and 'AssemblyStateGraphBuilder.Build(project, result)' in text['service'])
check('shadow timing visible', 'FIX12A Shadow Technology Graph' in text['service'])
check('diagnostic dual-run section', 'FIX12A / SHADOW TECHNOLOGY GRAPH — DUAL-RUN' in text['report'])
check('diagnostic says no price authority', 'Prawo zmiany ceny' in text['report'])
check('diagnostic prints four confidence factors', 'existence {node.Confidence.ExistencePercent}' in text['report'] and 'parameters {node.Confidence.ParametersPercent}' in text['report'])
check('behavior tests added', 'Post_weld_machining_uses_welded_assembly_state_and_whole_assembly_geometry' in text['tests'])
check('tests can reference infrastructure', 'DSEstimate.Infrastructure' in text['csproj'])
check('FIX12A wired into full release gate', 'run_fix12a_shadow_graph.py' in text['gate'])
check('FIX12A wired into portable build gate', 'run_fix12a_shadow_graph.py' in text['build'])
check('shadow does not call CostEngine', 'new CostEngine' not in text['builder'] and '.Build(' not in text['builder'].split('public static ShadowTechnologyGraph Build',1)[1].split('{',1)[0])

# Minimal structural checks available without .NET SDK in this environment.
for key in ('contract','builder','service','report','tests'):
    src=text[key]
    check(f'{key} braces balanced', src.count('{') == src.count('}'))

passed=sum(v for _,v in checks)
failed=len(checks)-passed
print(f'\nSUMMARY PASS={passed} FAIL={failed}')
sys.exit(1 if failed else 0)
