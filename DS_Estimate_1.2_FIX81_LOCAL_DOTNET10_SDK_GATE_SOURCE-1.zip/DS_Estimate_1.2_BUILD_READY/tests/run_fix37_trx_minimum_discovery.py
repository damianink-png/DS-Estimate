#!/usr/bin/env python3
"""FIX37: synthetic TRX regression for minimum discovered xUnit tests.

This does not execute .NET or claim a real TRX. Tests the verifier and CI wiring.
"""
from __future__ import annotations

import importlib.util
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERIFY = ROOT / 'tests/verify_dotnet_trx.py'
spec = importlib.util.spec_from_file_location('verify_dotnet_trx', VERIFY)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
checks: list[tuple[str, bool]] = []


def check(label: str, condition: bool) -> None:
    checks.append((label, bool(condition)))
    print(('PASS ' if condition else 'FAIL ') + label, flush=True)


def trx(n: int, skipped: int = 0) -> str:
    records = ''.join(f'<UnitTestResult testId="t{i}" outcome="Passed" />'
                      for i in range(n))
    records += ''.join(f'<UnitTestResult testId="s{i}" outcome="NotExecuted" />'
                       for i in range(skipped))
    return ('<TestRun xmlns="http://microsoft.com/schemas/VisualStudio/TeamTest/2010">'
            f'<Results>{records}</Results>'
            '<ResultSummary outcome="Completed">'
            f'<Counters total="{n + skipped}" executed="{n}" passed="{n}" '
            'failed="0" error="0" timeout="0" aborted="0" notRunnable="0" />'
            '</ResultSummary></TestRun>')


with tempfile.TemporaryDirectory(prefix='dse-fix37-') as temp:
    path = Path(temp) / 'synthetic.trx'
    for label, n, skipped, minimum, expected in [
        ('default accepts 2 passing tests for backward compatibility', 2, 0, 1, True),
        ('minimum 60 rejects 2 passing tests', 2, 0, 60, False),
        ('minimum 60 rejects 59 passing tests', 59, 0, 60, False),
        ('minimum 60 accepts 60 passing tests', 60, 0, 60, True),
        ('minimum 60 accepts 78 passing tests', 78, 0, 60, True),
        ('skipped do not count as executed', 59, 20, 60, False),
        ('60 executed and 20 skipped accepted', 60, 20, 60, True),
        ('invalid zero threshold rejected', 2, 0, 0, False),
        ('negative threshold rejected', 2, 0, -1, False),
    ]:
        path.write_text(trx(n, skipped), encoding='utf-8')
        try:
            mod.verify_trx(path, require_results=True, min_executed=minimum)
            accepted = True
        except mod.TrxValidationError:
            accepted = False
        check(label, accepted == expected)
    path.write_text(trx(59), encoding='utf-8')
    p = subprocess.run([sys.executable, str(VERIFY), str(path), '--require-results',
                        '--min-executed', '60'], capture_output=True, text=True)
    check('CLI rejects partial discovery', p.returncode == 1 and 'Too few' in p.stderr)
    path.write_text(trx(60), encoding='utf-8')
    p = subprocess.run([sys.executable, str(VERIFY), str(path), '--require-results',
                        '--min-executed', '60'], capture_output=True, text=True)
    check('CLI accepts expected discovery floor', p.returncode == 0 and 'PASS' in p.stdout)

workflow = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text(encoding='utf-8')
check('CI enforces minimum 60 with strict records',
      'verify_dotnet_trx.py TestResults/ds-estimate-xunit.trx --require-results --min-executed 60' in workflow)
methods = sum(len(re.findall(r'^\s*\[(?:Fact|Theory)(?:\(|\])', p.read_text(encoding='utf-8'), re.M))
              for p in (ROOT / 'tests/DSEstimate.Core.Tests').rglob('*.cs'))
check(f'C# test declarations ({methods}) exceed CI minimum 60', methods >= 60)
for gate in ('RUN_FULL_RELEASE_TESTS.cmd', 'BUILD_FULL_PORTABLE_ZIP.ps1'):
    check(f'{gate} includes FIX37', 'run_fix37_trx_minimum_discovery.py' in
          (ROOT / gate).read_text(encoding='utf-8-sig'))

passed = sum(ok for _, ok in checks)
failed = len(checks) - passed
print(f'SUMMARY PASS={passed} FAIL={failed} SKIP=0', flush=True)
raise SystemExit(1 if failed else 0)
