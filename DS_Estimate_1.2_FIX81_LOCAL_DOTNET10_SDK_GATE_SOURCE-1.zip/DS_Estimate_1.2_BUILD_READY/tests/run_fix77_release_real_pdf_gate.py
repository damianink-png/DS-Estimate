#!/usr/bin/env python3
"""FIX77: full Windows release gates must fail closed when PyMuPDF is absent.

Checks actual FIX29/FIX30 subprocess behavior and static CMD/PS1/CI wiring.
This is NOT evidence of a Windows/.NET execution.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CMD = (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='ascii')
PS1 = (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig')
CI = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text(encoding='utf-8')
checks = []


def check(label: str, condition: bool) -> None:
    ok = bool(condition)
    checks.append(ok)
    print(('PASS' if ok else 'FAIL') + ' | ' + label, flush=True)


names = ('run_fix29_pdf_exact_bom_links.py', 'run_fix30_pdf_bom_step_links.py')
for name in names:
    check(name + ' CMD release strict flag',
          CMD.count('%PY% tests\\' + name + ' --require-real-pdf || exit /b 1') == 1)
    check(name + ' PS1 listed exactly once',
          PS1.split('$baselineFunctionalTests = @(', 1)[1].split('\n    )', 1)[0].count('\"tests\\' + name + '\",') == 1)
    check(name + ' PS1 strict selection',
          '"tests\\' + name + '"' in PS1.split('if ($relTest -in @(', 1)[1].split('))', 1)[0])
    # Simulate a missing PyMuPDF in a fresh process, without changing the
    # machine's environment or removing installed packages.
    script = ("import runpy,sys; sys.modules['pymupdf']=None; "
              "sys.argv=[sys.argv[1],'--require-real-pdf']; "
              "runpy.run_path(sys.argv[0],run_name='__main__')")
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    p = subprocess.run([sys.executable, '-c', script, str(ROOT / 'tests' / name)],
                       cwd=ROOT, capture_output=True, text=True,
                       encoding='utf-8', errors='replace', timeout=90, env=env)
    check(name + ' missing PyMuPDF fails closed',
          p.returncode != 0 and 'FAIL real PDF required' in p.stdout
          and 'FAIL=1' in p.stdout and 'SKIP=0' in p.stdout)
    p = subprocess.run([sys.executable, str(ROOT / 'tests' / name), '--require-real-pdf'],
                       cwd=ROOT, capture_output=True, text=True,
                       encoding='utf-8', errors='replace', timeout=90, env=env)
    check(name + ' actual two-page PDF executes (not SKIP)',
          p.returncode == 0 and 'FAIL=0' in p.stdout and 'SKIP=0' in p.stdout
          and ('real two-page PDF creates one link' in p.stdout if name.startswith('run_fix29')
               else 'real PDF page numbers are correct' in p.stdout))

check('PowerShell strict switch passed to actual embedded Python',
      '& $embeddedPython $testPath --require-real-pdf' in PS1)
check('PowerShell preserves nonzero exit failure gate',
      '$testExit = $LASTEXITCODE' in PS1 and 'if ($testExit -ne 0)' in PS1)
check('CMD release executes FIX77 and propagates failure',
      '%PY% tests\\run_fix77_release_real_pdf_gate.py || exit /b 1' in CMD)
check('PowerShell release executes FIX77',
      '"tests\\run_fix77_release_real_pdf_gate.py",' in PS1)
check('Windows CI executes FIX77',
      'run: python tests/run_fix77_release_real_pdf_gate.py' in CI)
check('Windows CI still requires both real PDFs',
      all('python tests/' + name + ' --require-real-pdf' in CI for name in names))
print(f'SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0', flush=True)
raise SystemExit(0 if all(checks) else 1)
