﻿from __future__ import annotations
import argparse, json, os, subprocess, sys, tempfile, time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ENGINE=ROOT/'engines'/'python'/'analyze_step.py'

def run_engine(path:Path, fast=False, timeout=180):
    env=os.environ.copy()
    if fast: env['DSE_HISTORY_FAST_STEP']='1'
    t=time.perf_counter()
    cp=subprocess.run([sys.executable,str(ENGINE),str(path)],cwd=str(ROOT),env=env,capture_output=True,text=True,timeout=timeout)
    sec=time.perf_counter()-t
    if cp.returncode!=0:
        raise RuntimeError(f'engine rc={cp.returncode}: {cp.stderr[-1200:]}')
    lines=[x for x in cp.stdout.splitlines() if x.strip()]
    return json.loads(lines[-1]),sec

def export(cq,solids,path):
    cq.exporters.export(cq.Compound.makeCompound(solids),str(path))

def child_case(case:str)->int:
    try: import cadquery as cq
    except Exception as exc:
        print(f'SKIP cadquery unavailable: {exc}'); return 0
    checks=[]
    def check(name,ok,detail=''):
        checks.append(bool(ok)); print(('PASS' if ok else 'FAIL'),name,('' if ok else f':: {detail}'),flush=True)
    with tempfile.TemporaryDirectory(prefix=f'dse_{case}_') as td:
        td=Path(td)
        if case.startswith('sparse'):
            n=int(case.replace('sparse',''))
            solids=[cq.Workplane('XY').box(50,40,10).translate(((i%100)*60,(i//100)*60,0)).val() for i in range(n)]
            p=td/f'{case}.step'; export(cq,solids,p); r,sec=run_engine(p,timeout=180)
            check('all solids',r.get('solidCount')==n,r.get('solidCount'))
            check('one repeated group',r.get('uniquePartGroups')==1,r.get('uniquePartGroups'))
            check('no contact limit',not r.get('contactLimitReached',False),r.get('warnings'))
            check('no joint limit',not r.get('jointAnalysisLimitReached',False),r.get('warnings'))
            if n>=1000: check('OCP large importer',r.get('importer')=='OCP-large',r.get('importer'))
            check('runtime <90s',sec<90,f'{sec:.2f}s')
        elif case=='chain500':
            n=500; solids=[cq.Workplane('XY').box(50,40,10).translate((i*50,0,0)).val() for i in range(n)]
            p=td/'chain500.step'; export(cq,solids,p); r,sec=run_engine(p,fast=True,timeout=180)
            check('499 contacts',r.get('contactPairs')==499,r.get('contactPairs'))
            check('499 weld candidates',r.get('weldCandidatePairs')==499,r.get('weldCandidatePairs'))
            check('no joint limit',not r.get('jointAnalysisLimitReached',False),r.get('warnings'))
        elif case=='grid400':
            solids=[cq.Workplane('XY').box(50,40,10).translate((ix*50,iy*40,0)).val() for iy in range(20) for ix in range(20)]
            p=td/'grid400.step'; export(cq,solids,p); r,sec=run_engine(p,timeout=180)
            check('400 solids',r.get('solidCount')==400,r.get('solidCount'))
            check('>1000 contacts',r.get('contactPairs',0)>1000,r.get('contactPairs'))
            check('>500 weld candidates',r.get('weldCandidatePairs',0)>500,r.get('weldCandidatePairs'))
            check('no joint limit',not r.get('jointAnalysisLimitReached',False),r.get('warnings'))
            check('surface planar/local prefilter',r.get('surfaceAccessibilityCheckedFaces')==0 and not r.get('surfaceAccessibilityLimitReached',False),r.get('warnings'))
            check('surface engine v4',r.get('surfaceEngineVersion')=='4.0',r.get('surfaceEngineVersion'))
            check('runtime <90s',sec<90,f'{sec:.2f}s')
        elif case=='holes200':
            proto=(cq.Workplane('XY').box(80,80,20).faces('>Z').workplane().pushPoints([(-20,-20),(20,-20),(-20,20),(20,20)]).hole(10)).val()
            solids=[proto.moved(cq.Location(cq.Vector((i%40)*100,(i//40)*100,0))) for i in range(200)]
            p=td/'holes200.step'; export(cq,solids,p); r,sec=run_engine(p,timeout=180)
            check('200 solids',r.get('solidCount')==200,r.get('solidCount'))
            check('800 holes',r.get('totalHoleCount')==800,r.get('totalHoleCount'))
            check('no contact limit',not r.get('contactLimitReached',False),r.get('warnings'))
        elif case=='sealed':
            s=[
                cq.Workplane('XY').box(100,100,10).translate((0,0,5)).val(),
                cq.Workplane('XY').box(100,100,10).translate((0,0,95)).val(),
                cq.Workplane('YZ').box(100,80,10).translate((-45,0,50)).val(),
                cq.Workplane('YZ').box(100,80,10).translate((45,0,50)).val(),
                cq.Workplane('XZ').box(80,80,10).translate((0,-45,50)).val(),
                cq.Workplane('XZ').box(80,80,10).translate((0,45,50)).val(),
            ]
            p=td/'sealed.step'; export(cq,s,p); r,sec=run_engine(p,timeout=120)
            check('surface checks faces',r.get('surfaceAccessibilityCheckedFaces',0)>0,r.get('surfaceAccessibilityCheckedFaces'))
            check('sealed cavity excluded',r.get('sealedCavitySurfaceMm2',0)>10000,r.get('sealedCavitySurfaceMm2'))
            check('no surface limit',not r.get('surfaceAccessibilityLimitReached',False),r.get('warnings'))
            check('surface engine v4',r.get('surfaceEngineVersion')=='4.0',r.get('surfaceEngineVersion'))
        else:
            print('Unknown case',case); return 2
    print(f'TIMING {case}: {sec:.2f}s',flush=True)
    print(f'SUMMARY {case}: PASS={sum(checks)} FAIL={len(checks)-sum(checks)}',flush=True)
    return 1 if not all(checks) else 0

def master()->int:
    full=os.environ.get('DSE_STRESS_FULL','1')=='1'
    cases=['sparse100','sparse500','sparse1000']
    if full: cases.append('sparse2000')
    cases += ['chain500','grid400','holes200','sealed']
    failed=[]
    for case in cases:
        print(f'\n===== STRESS {case} =====',flush=True)
        try:
            cp=subprocess.run([sys.executable,'-u',str(Path(__file__).resolve()),'--case',case],cwd=str(ROOT),timeout=240)
            if cp.returncode!=0: failed.append(case)
        except subprocess.TimeoutExpired:
            print(f'FAIL {case}: timeout >240s',flush=True); failed.append(case)
    print(f'\nSYSTEM STRESS SUMMARY: CASES={len(cases)} FAIL={len(failed)}',flush=True)
    if failed: print('FAILED:',', '.join(failed),flush=True)
    return 1 if failed else 0

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--case')
    args=ap.parse_args()
    rc=child_case(args.case) if args.case else master()
    if args.case:
        # Child cases load CadQuery/OCP directly.  Their checks and temporary
        # cleanup are complete, so return the exact test status without running
        # unstable native finalizers.  The master process still evaluates every
        # child return code and fails on a real error or timeout.
        try:
            sys.stdout.flush(); sys.stderr.flush()
        finally:
            os._exit(rc)
    raise SystemExit(rc)
