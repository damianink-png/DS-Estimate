#!/usr/bin/env python3
"""FIX39 static checks: preserve private CI restore/build logs on failures.

These tests do NOT compile .NET, execute xUnit, or produce real build logs.
Uses only the Python standard library so it can run in the release gate.
"""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
workflow = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text(encoding='utf-8')
checks: list[tuple[str, bool]] = []


def check(label: str, condition: bool) -> None:
    checks.append((label, bool(condition)))
    print(('PASS ' if condition else 'FAIL ') + label, flush=True)


def step(name: str) -> str:
    marker = f'      - name: {name}\n'
    count = workflow.count(marker)
    check(f'exactly one step: {name}', count == 1)
    if count != 1:
        return ''
    start = workflow.index(marker)
    end = workflow.find('\n      - ', start + len(marker))
    return workflow[start:end if end >= 0 else len(workflow)]


restore = step('Restore .NET solution')
solution = step('Compile solution C# projects (including Avalonia app)')
launcher = step('Compile Windows launcher C# (not a release)')
upload = step('Save test results')
for body, command, log in (
    (restore, 'dotnet restore DS_Estimate.sln --nologo', 'dotnet-restore.log'),
    (solution, 'dotnet build DS_Estimate.sln -c Release --no-restore --nologo', 'solution-build.log'),
    (launcher, 'dotnet build src/DSEstimate.Launcher/DSEstimate.Launcher.csproj', 'launcher-build.log'),
):
    check(f'{log}: original build/restore command retained', command in body)
    check(f'{log}: uses PowerShell', 'shell: pwsh' in body)
    check(f'{log}: output streamed to disk and CI console',
          f'2>&1 | Tee-Object -FilePath TestResults/{log}' in body)
    check(f'{log}: native command failure propagated',
          'if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }' in body)
    check(f'{log}: included in always-uploaded private evidence',
          f'TestResults/{log}' in upload)

check('restore creates output directory before logging',
      'New-Item -ItemType Directory -Force -Path TestResults' in restore)
check('upload happens after build and xUnit verification',
      bool(restore and solution and launcher and upload) and
      workflow.index('python tests/verify_dotnet_trx.py') < workflow.index('      - name: Save test results') and
      workflow.index('      - name: Restore .NET solution') < workflow.index('      - name: Save test results') and
      workflow.index('      - name: Compile Windows launcher C#') < workflow.index('      - name: Save test results'))
check('artifact upload executes after failures', 'if: always()' in upload)
check('artifact upload contains no source or CI-only launcher fixture',
      'src/' not in upload and 'launcher-smoke' not in upload)
check('xUnit discovery and strict TRX guard retained',
      '--list-tests' in workflow and '--require-results --min-executed 60' in workflow)
for gate in ('RUN_FULL_RELEASE_TESTS.cmd', 'BUILD_FULL_PORTABLE_ZIP.ps1'):
    check(f'{gate} invokes FIX39 regression',
          'run_fix39_ci_build_log_evidence.py' in (ROOT / gate).read_text(encoding='utf-8-sig'))

ok = sum(passed for _, passed in checks)
print(f'SUMMARY PASS={ok} FAIL={len(checks)-ok} SKIP=0', flush=True)
raise SystemExit(0 if ok == len(checks) else 1)
