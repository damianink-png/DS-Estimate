#!/usr/bin/env python3
"""FIX74: source hashing errors must abort a private pack, not emit empty SHA256.

Actual private-pack CLI is exercised for a normal document. A targeted read
failure is injected into the engine while preserving the previous valid ZIP.
"""
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / 'engines/python/build_private_analysis_pack.py'
spec = importlib.util.spec_from_file_location('dse_private_pack_fix74', ENGINE)
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
checks = 0


def check(label, condition):
    global checks
    if not condition:
        print('FAIL | ' + label, flush=True)
        raise AssertionError(label)
    checks += 1
    print('PASS | ' + label, flush=True)


with tempfile.TemporaryDirectory(prefix='dse_fix74_') as folder:
    base = Path(folder)
    source = base / 'source'
    source.mkdir()
    good = source / 'drawing.txt'
    good.write_text('Material S355 CNC\n', encoding='utf-8')
    output = source / 'private.zip'

    run = subprocess.run([sys.executable, str(ENGINE), str(source), str(output)],
                         capture_output=True, text=True, timeout=30)
    check('real private-pack CLI exit 0', run.returncode == 0)
    check('real private-pack CLI reports success', json.loads(run.stdout)['ok'] is True)
    with zipfile.ZipFile(output) as z:
        check('initial ZIP CRC valid', z.testzip() is None)
        manifest = json.loads(z.read('MANIFEST.json'))
        check('initial manifest has one document', manifest['file_count'] == 1)
        check('initial manifest has real SHA256', manifest['files'][0]['sha256'] == hashlib.sha256(good.read_bytes()).hexdigest())
    original_bytes = output.read_bytes()
    original_sha = hashlib.sha256(original_bytes).hexdigest()

    locked = source / 'locked.txt'
    locked.write_text('Customer private CNC material S690QL', encoding='utf-8')
    original_open = Path.open

    def deny_hash_open(self, mode='r', *args, **kwargs):
        if self == locked and mode == 'rb':
            raise PermissionError('CUSTOMER_PRIVATE_PATH_OR_IDENTIFIER')
        return original_open(self, mode, *args, **kwargs)

    old_argv = sys.argv
    try:
        sys.argv = [str(ENGINE), str(source), str(output)]
        with patch.object(Path, 'open', deny_hash_open):
            try:
                engine.main()
            except SystemExit as exc:
                status = exc.code
            else:
                status = 0
    finally:
        sys.argv = old_argv

    check('hash read failure aborts pack', status != 0)
    check('failure is sanitized and stable', str(status) == 'SOURCE_HASH_FAILED')
    check('error does not expose customer text', 'CUSTOMER_PRIVATE' not in str(status))
    check('previous valid ZIP bytes preserved', output.read_bytes() == original_bytes)
    check('previous valid ZIP SHA256 preserved', hashlib.sha256(output.read_bytes()).hexdigest() == original_sha)
    check('no private-pack temporary output remains', not list(source.glob('.private.zip.*.tmp')))
    with zipfile.ZipFile(output) as z:
        check('previous ZIP still passes CRC', z.testzip() is None)
        manifest = json.loads(z.read('MANIFEST.json'))
        check('failed document was not added to old manifest', manifest['file_count'] == 1)
        check('old document hash still present', manifest['files'][0]['sha256'] == hashlib.sha256(good.read_bytes()).hexdigest())

cmd = (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text('utf-8-sig')
ps1 = (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text('utf-8-sig')
workflow = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text('utf-8')
name = 'run_fix74_private_pack_hash_fail_closed.py'
check('CMD release gate includes FIX74', ('%PY% tests\\' + name + ' || exit /b 1') in cmd)
check('PowerShell release gate includes FIX74', ('"tests\\' + name + '",') in ps1)
check('private Windows CI includes FIX74', ('run: python tests/' + name) in workflow)
print(f'FIX74: {checks}/{checks} PASS; FAIL=0 SKIP=0 TIMEOUT=0', flush=True)
