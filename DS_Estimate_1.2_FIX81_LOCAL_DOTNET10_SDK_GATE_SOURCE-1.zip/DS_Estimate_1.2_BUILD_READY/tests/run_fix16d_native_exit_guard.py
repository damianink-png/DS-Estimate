from pathlib import Path
import ast
import re
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
TESTS = ROOT / "tests"


def text(relative_path):
    return (ROOT / relative_path).read_text(encoding="utf-8-sig")


def check(name, condition):
    global passed, failed
    if condition:
        passed += 1
        print("PASS ", name)
    else:
        failed += 1
        print("FAIL ", name)


def probe(source_relative, substitutions, arguments):
    path = str((ROOT / source_relative).resolve())
    driver = f'''\nimport sys, types\nsys.modules["cadquery"] = types.ModuleType("cadquery")\npath = {path!r}\nsource = open(path, encoding="utf-8-sig").read()\nfor old, new in {substitutions!r}:\n    if old not in source:\n        raise RuntimeError("probe substitution not found: " + old)\n    source = source.replace(old, new, 1)\nsys.argv = [path] + {arguments!r}\nexec(compile(source, path, "exec"), {{"__name__": "__main__", "__file__": path}})\n'''
    return subprocess.run(
        [sys.executable, "-c", driver],
        check=False,
        capture_output=True,
        text=True,
    ).returncode


passed = failed = 0
performance = text("tests/run_r9_0_7_step_assembly_performance.py")
stress = text("tests/run_r9_0_system_stress.py")
report = text("src/DSEstimate.Infrastructure/DiagnosticReportService.cs")
release = text("RUN_FULL_RELEASE_TESTS.cmd")
build = text("BUILD_FULL_PORTABLE_ZIP.ps1")

native_import = re.compile(r"(?:^|\s)(?:import cadquery|from cadquery|import OCP|from OCP)", re.MULTILINE)
native_tests = {
    path.name
    for path in TESTS.glob("*.py")
    if native_import.search(path.read_text(encoding="utf-8-sig"))
}
expected_native_tests = {
    "run_fix20_open_source_integrations.py",
    "run_r7_regression.py",
    "run_r7_parametric.py",
    "run_r9_0_7_step_assembly_performance.py",
    "run_r9_0_system_stress.py",
}

check("all direct CadQuery/OCP tests identified", native_tests == expected_native_tests)
for file_name in sorted(native_tests):
    source = (TESTS / file_name).read_text(encoding="utf-8-sig")
    check(f"native shutdown guarded: {file_name}", "os._exit(rc)" in source)

check("performance test computes real status before native exit", "rc = 1 if fail else 0" in performance)
check("performance test flushes report", "sys.stdout.flush(); sys.stderr.flush()" in performance)
check("stress master still checks child return codes", "if cp.returncode!=0: failed.append(case)" in stress)
check("stress guard applies only to native child cases", "if args.case:" in stress and "os._exit(rc)" in stress)
check("stress master retains ordinary SystemExit", "raise SystemExit(rc)" in stress)
check("diagnostic identifies FIX16D", "FIX16D NATIVE TEST SHUTDOWN FIX" in report)
check("FIX16D wired into release gate", "run_fix16d_native_exit_guard.py" in release)
check("FIX16D wired into portable build gate", "run_fix16d_native_exit_guard.py" in build)

check(
    "performance native shutdown preserves PASS code 0",
    probe(
        "tests/run_r9_0_7_step_assembly_performance.py",
        [("rc = 1 if fail else 0", "rc = 0")],
        [],
    ) == 0,
)
check(
    "performance native shutdown preserves FAIL code 1",
    probe(
        "tests/run_r9_0_7_step_assembly_performance.py",
        [("rc = 1 if fail else 0", "rc = 1")],
        [],
    ) == 1,
)
check(
    "stress child native shutdown preserves PASS code 0",
    probe(
        "tests/run_r9_0_system_stress.py",
        [("rc=child_case(args.case) if args.case else master()", "rc=0")],
        ["--case", "probe"],
    ) == 0,
)
check(
    "stress child native shutdown preserves FAIL code 1",
    probe(
        "tests/run_r9_0_system_stress.py",
        [("rc=child_case(args.case) if args.case else master()", "rc=1")],
        ["--case", "probe"],
    ) == 1,
)

for name, source in [("performance", performance), ("stress", stress)]:
    try:
        ast.parse(source)
        check(f"{name} Python syntax", True)
    except SyntaxError as ex:
        check(f"{name} Python syntax: {ex}", False)

print(f"\nSUMMARY PASS={passed} FAIL={failed}")
sys.exit(1 if failed else 0)
