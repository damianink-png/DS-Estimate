# DS Estimate 1.2 — aktywne testy wydania

Katalog zawiera testy potrzebne do bramki builda. Nie są kopiowane do gotowego portable.

- `run_ds_estimate_1_2_minimal_ui.py` — tożsamość 1.2, minimal UI i zachowanie silnika 1.1,
- `run_ds_estimate_1_2_powershell_encoding.py` — zgodność z Windows PowerShell 5.1,
- regresje geometrii/dokumentów, stress i DWG smoke,
- `DSEstimate.Core.Tests` — xUnit logiki wyceny.
