"""FIX67 runtime regression: stable private-pack bytes regardless of input traversal order."""
import contextlib
import importlib.util
import io
import json
import sys
import tempfile
import zipfile
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / 'engines/python/build_private_analysis_pack.py'
spec = importlib.util.spec_from_file_location('ds_private_pack_fix67', ENGINE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
checks = 0

def check(label, condition):
    global checks
    if not condition:
        raise AssertionError(label)
    checks += 1
    print('PASS | ' + label, flush=True)

def generate(source, target, reverse=False):
    original = Path.rglob
    def reordered(self, pattern):
        paths = list(original(self, pattern))
        return iter(reversed(paths)) if reverse and self == source else iter(paths)
    with mock.patch.object(module.Path, 'rglob', reordered), mock.patch.object(sys, 'argv', [str(ENGINE), str(source), str(target)]):
        with contextlib.redirect_stdout(io.StringIO()) as stdout:
            module.main()
    return json.loads(stdout.getvalue())

with tempfile.TemporaryDirectory(prefix='dse_fix67_') as d:
    base = Path(d)
    source = base / 'source'
    (source / 'subfolder').mkdir(parents=True)
    (source / 'Z_s355.txt').write_text('S355 CNC 2 szt.\nmasa 17 kg', encoding='utf-8')
    (source / 'a_material.csv').write_text('material;S690QL\nmasa;40', encoding='utf-8')
    (source / 'subfolder' / 'B_WELD.txt').write_text('ISO 5817, weld 3 mm', encoding='utf-8')
    first_zip = base / 'first.zip'
    reversed_zip = base / 'reversed.zip'
    first = generate(source, first_zip)
    second = generate(source, reversed_zip, reverse=True)
    check('normal traversal succeeds', first['ok'] is True)
    check('reversed traversal succeeds', second['ok'] is True)
    check('normal file count', first['files'] == 3)
    check('reversed file count', second['files'] == 3)
    check('same reported source bytes', first['source_bytes'] == second['source_bytes'])
    check('byte-identical ZIP regardless of traversal order', first_zip.read_bytes() == reversed_zip.read_bytes())
    with zipfile.ZipFile(first_zip) as z1, zipfile.ZipFile(reversed_zip) as z2:
        check('first ZIP CRC', z1.testzip() is None)
        check('reversed ZIP CRC', z2.testzip() is None)
        check('only sanitized entries', set(z1.namelist()) == {'MANIFEST.json', 'TECHNICAL_SNIPPETS.json', 'README_PRIVACY.txt'})
        m1 = json.loads(z1.read('MANIFEST.json'))
        m2 = json.loads(z2.read('MANIFEST.json'))
        check('manifest bytes identical', z1.read('MANIFEST.json') == z2.read('MANIFEST.json'))
        check('snippet bytes identical', z1.read('TECHNICAL_SNIPPETS.json') == z2.read('TECHNICAL_SNIPPETS.json'))
        check('manifest file count', m1['file_count'] == m2['file_count'] == 3)
        check('file identities stable', [f['sha256'] for f in m1['files']] == [f['sha256'] for f in m2['files']])
    # A repeat build must remain stable even when the source folder contains the output ZIP.
    in_source = source / 'private_pack.zip'
    generate(source, in_source)
    original_bytes = in_source.read_bytes()
    repeated = generate(source, in_source, reverse=True)
    check('self-output excluded on retry', repeated['files'] == 3)
    check('repeat output bytes unchanged', in_source.read_bytes() == original_bytes)
    check('no temporary leftovers', not list(source.glob('.private_pack.zip.*.tmp')))

print(f'FIX67: {checks}/{checks} PASS (runtime)')
