"""FIX63 static guard regression. Not a .NET or Avalonia runtime test."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
s = (root / "src/DSEstimate.App/Views/MainWindow.axaml.cs").read_text(encoding="utf-8-sig")
checks = {
    "shared local-path helper": "LocalExistingPaths(IEnumerable<IStorageItem> items)" in s,
    "only file:// URIs": ".Where(uri => uri.IsFile)" in s,
    "existing files or directories": ".Where(path => File.Exists(path) || Directory.Exists(path))" in s,
    "case-insensitive duplicate paths": ".Distinct(StringComparer.OrdinalIgnoreCase)" in s,
    "drop is handled": "e.Handled = true;" in s[s.index("private async void OnDrop"):s.index("private async void OnAddFilesClick")],
    "drop uses shared helper": "LocalExistingPaths(files)" in s[s.index("private async void OnDrop"):s.index("private async void OnAddFilesClick")],
    "file picker checks before open": bool(re.search(r"OnAddFilesClick.*?if \(!_vm.CanModifyDocuments\).*?OpenFilePickerAsync", s, re.S)),
    "file picker rechecks after await": "if (_vm.CanModifyDocuments)\n            await _vm.AddInputsAsync(LocalExistingPaths(files));".replace("\n", "\n") in s,
    "history folder checks local URI": "folder.Path.IsFile" in s,
    "history folder rechecks busy": "_vm.CanModifyDocuments && folder is not null" in s,
    "old unsafe path enumeration removed": ".Select(x => x.Path.LocalPath)" not in s,
    "old unsafe picker import removed": "_vm.AddInputsAsync(files.Select(x => x.Path.LocalPath))" not in s,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + label)
assert all(checks.values()), "FIX63 source guard regression failed"
print(f"FIX63: {len(checks)}/{len(checks)} PASS (static only)")
