#!/usr/bin/env python3
"""FIX70: full Windows release gates must run every recent regression.

This is a source/wiring regression, NOT proof of a Windows/.NET build.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(label, condition):
    ok = bool(condition)
    checks.append(ok)
    print(('PASS' if ok else 'FAIL') + ' | ' + label, flush=True)

cmd = (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='utf-8-sig')
ps1 = (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig')
workflow = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text(encoding='utf-8')
# Check only the full-release functional-test list, not a filename in a comment.
ps_start = ps1.index('$baselineFunctionalTests = @(')
ps_end = ps1.index('\n    )', ps_start)
ps_gate = ps1[ps_start:ps_end]
cmd_gate = cmd[:cmd.index('set DSE_STRESS_FULL=1')]
for number, name in (
    (62, 'dscompare_desktop_ui'),
    (63, 'local_storage_dnd_guard'),
    (64, 'local_export_uri_guard'),
    (65, 'private_pack_input_isolation'),
    (66, 'private_pack_atomic_output'),
    (67, 'private_pack_deterministic_order'),
    (68, 'private_pack_exception_privacy'),
    (69, 'private_pack_zip_metadata_determinism'),
    (70, 'release_gate_recent_regressions'),
):
    filename = f'run_fix{number}_{name}.py'
    check(f'FIX{number}: test file exists', (ROOT / 'tests' / filename).is_file())
    check(f'FIX{number}: CMD full release gate',
          len(re.findall(r'(?m)^%PY% tests\\' + re.escape(filename) + r' \|\| exit /b 1\s*$', cmd_gate)) == 1)
    check(f'FIX{number}: PowerShell full release gate',
          ps_gate.count('"tests\\' + filename + '"') == 1)
check('CMD checks run before full stress', 'run_fix70_release_gate_recent_regressions.py' in cmd_gate)
check('PowerShell fail-closed on nonzero test exit',
      'if ($testExit -ne 0)' in ps1 and 'Fail ("Bramka DS Estimate 1.2 nie przeszła:' in ps1)
check('Windows CI executes FIX70 wiring regression',
      'python tests/run_fix70_release_gate_recent_regressions.py' in workflow)
print(f'SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0', flush=True)
raise SystemExit(0 if all(checks) else 1)
