#!/usr/bin/env python3
"""FIX53: test CLR/BSJB gate on synthetic PE files (NOT a real .NET build)."""
from __future__ import annotations

import importlib.util
import struct
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("solution_evidence", ROOT / "tests/verify_dotnet_solution_outputs.py")
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
checks = []


def check(label: str, condition: bool) -> None:
    checks.append(bool(condition))
    print(("PASS " if condition else "FAIL ") + label, flush=True)


def managed_pe(magic: int = 0x10B) -> bytes:
    data = bytearray(4096)
    data[:2] = b"MZ"
    struct.pack_into("<I", data, 0x3C, 0x80)
    data[0x80:0x84] = b"PE\x00\x00"
    struct.pack_into("<H", data, 0x86, 1)
    optional = 0x98
    opt_size = 0xE0 if magic == 0x10B else 0xF0
    struct.pack_into("<H", data, 0x94, opt_size)
    struct.pack_into("<H", data, optional, magic)
    count_offset, directory_offset = (92, 96) if magic == 0x10B else (108, 112)
    struct.pack_into("<I", data, optional + count_offset, 16)
    struct.pack_into("<II", data, optional + directory_offset + 14 * 8, 0x2000, 0x48)
    section = optional + opt_size
    struct.pack_into("<IIII", data, section + 8, 0x1000, 0x2000, 0x1000, 0x400)
    struct.pack_into("<I", data, 0x400, 0x48)
    struct.pack_into("<II", data, 0x408, 0x2100, 0x20)
    data[0x500:0x504] = b"BSJB"
    return bytes(data)


with tempfile.TemporaryDirectory(prefix="dse-fix53-") as folder:
    root = Path(folder) / "root"
    output = Path(folder) / "logs" / "solution-output-evidence.log"
    for _, relative in mod.OUTPUTS:
        file = root / relative
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_bytes(managed_pe())
    first = root / mod.OUTPUTS[0][1]
    check("PE32 managed fixture accepted", len(mod.verify_outputs(root)) == 5)
    first.write_bytes(managed_pe(0x20B))
    check("PE32+ managed fixture accepted", len(mod.verify_outputs(root)) == 5)
    first.write_bytes(managed_pe())
    valid = managed_pe()

    def rejected(label: str, value: bytes) -> None:
        first.write_bytes(value)
        try:
            mod.inspect_output(first)
        except mod.SolutionOutputError:
            check(label, True)
        else:
            check(label, False)

    def corrupt(offset: int, payload: bytes) -> bytes:
        b = bytearray(valid)
        b[offset:offset + len(payload)] = payload
        return bytes(b)

    rejected("native PE without CLR directory rejected", corrupt(0x98 + 96 + 14 * 8, b"\0" * 8))
    rejected("CLR directory count below 15 rejected", corrupt(0x98 + 92, struct.pack("<I", 14)))
    rejected("CLR RVA outside sections rejected", corrupt(0x98 + 96 + 14 * 8, struct.pack("<I", 0x9000)))
    rejected("CLR header shorter than 0x48 rejected", corrupt(0x98 + 96 + 14 * 8 + 4, struct.pack("<I", 0x20)))
    rejected("CLR cb smaller than 0x48 rejected", corrupt(0x400, struct.pack("<I", 0x20)))
    rejected("metadata RVA outside sections rejected", corrupt(0x408, struct.pack("<I", 0x9000)))
    rejected("missing BSJB metadata signature rejected", corrupt(0x500, b"XXXX"))
    rejected("missing section table rejected", corrupt(0x86, b"\0\0"))
    rejected("invalid optional header size rejected", corrupt(0x94, b"\x20\x00"))
    first.write_bytes(valid)
    cli = subprocess.run([sys.executable, str(ROOT / "tests/verify_dotnet_solution_outputs.py"),
                          "--root", str(root), "--output", str(output)],
                         capture_output=True, text=True, timeout=15)
    check("valid synthetic CLI reports PASS", cli.returncode == 0 and "PASS" in output.read_text())
    first.write_bytes(corrupt(0x500, b"XXXX"))
    cli = subprocess.run([sys.executable, str(ROOT / "tests/verify_dotnet_solution_outputs.py"),
                          "--root", str(root), "--output", str(output)],
                         capture_output=True, text=True, timeout=15)
    check("invalid CLI reports FAIL and writes evidence", cli.returncode == 1 and
          "FAIL" in output.read_text())

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
check("CI still verifies DLLs after actual build", workflow.index("dotnet build DS_Estimate.sln") <
      workflow.index("python tests/verify_dotnet_solution_outputs.py"))
check("CI still requires strict xUnit TRX", "--min-executed 60 --reject-skipped" in workflow)
check("CI still requires real PDF", "--require-real-pdf" in workflow)
for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{gate} runs FIX53", "run_fix53_managed_dll_metadata_guard.py" in
          (ROOT / gate).read_text(encoding="utf-8-sig"))
print(f"SUMMARY PASS={sum(checks)} FAIL={len(checks) - sum(checks)} SKIP=0", flush=True)
raise SystemExit(0 if all(checks) else 1)
