#!/usr/bin/env python3
"""Fail closed on an empty VSTest --list-tests transcript.

This checks captured discovery text, not test execution. Real execution and
minimum executed count remain the responsibility of verify_dotnet_trx.py.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

ANSI = re.compile(r"\x1b\[[0-9;]*m")
HEADER = re.compile(r"^\s*The following Tests are available:\s*$", re.I)
NO_TESTS = re.compile(r"\bNo test is available\b|\bNo tests? found\b", re.I)
# FIX61: --list-tests can contain a plausible list followed by a fatal
# VSTest/testhost diagnostic. A nonempty listing is not proof of success.
# Match complete diagnostic lines, not substrings inside theory arguments.
FATAL_DISCOVERY = re.compile(
    r"^\s*(?:Test Run Failed\.?|Test run aborted\.?|"
    r"(?:The )?test host process crashed\b.*|"
    r"Testhost process exited with error\b.*|"
    r"Unhandled exception(?:\b|[.:]).*|"
    r"Fatal error:.*)\s*$",
    re.I,
)
# FIX59: VSTest test identities are qualified names, not arbitrary indented
# diagnostics containing a dot (e.g. "Warning: Runtime.Some.Type").
# Allow nested C# types (+), generic arity (`1) and theory argument suffixes.
TEST_CASE = re.compile(
    r"^\s{2,}(?:[A-Za-z_][\w`+]*\.){2,}[A-Za-z_][\w`+]*(?:\(.*\))?\s*$"
)


class DiscoveryError(ValueError):
    pass


def verify_discovery(path: Path, *, min_discovered: int = 1,
                     require_prefix: str | None = None) -> int:
    if min_discovered < 1:
        raise DiscoveryError("min_discovered must be >= 1")
    if require_prefix is not None and (not require_prefix or not require_prefix.endswith(".")):
        raise DiscoveryError("require_prefix must be a nonempty namespace ending in a dot")
    try:
        raw = path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeError) as exc:
        raise DiscoveryError(f"Cannot read discovery transcript: {exc}") from exc
    lines = ANSI.sub("", raw).splitlines()
    if any(NO_TESTS.search(line) for line in lines):
        raise DiscoveryError("VSTest reported no available tests")
    # Inspect the whole transcript, including diagnostics after the last
    # discovered identity; stopping at an unindented line is not sufficient.
    for line in lines:
        if FATAL_DISCOVERY.fullmatch(line):
            raise DiscoveryError(f"Fatal VSTest discovery diagnostic: {line.strip()}")
    headers = [i for i, line in enumerate(lines) if HEADER.fullmatch(line)]
    if len(headers) != 1:
        raise DiscoveryError("Expected exactly one VSTest discovery header")
    discovered = 0
    seen_tests: set[str] = set()
    for line in lines[headers[0] + 1:]:
        if not line.strip():
            continue
        if not line[0].isspace():
            break
        if TEST_CASE.fullmatch(line):
            # FIX58: repeated transcript lines cannot establish independent
            # discoveries. Fail closed rather than inflate the 60-case floor.
            identity = line.strip()
            # FIX60: a qualified diagnostic from another assembly/namespace
            # must never count towards the project-specific discovery floor.
            if require_prefix is not None and not identity.startswith(require_prefix):
                raise DiscoveryError(f"Discovered identity outside required namespace: {identity}")
            if identity in seen_tests:
                raise DiscoveryError(f"Duplicate discovered test name: {identity}")
            seen_tests.add(identity)
            discovered += 1
    if discovered < min_discovered:
        raise DiscoveryError(f"Too few listed tests: {discovered} < {min_discovered}")
    return discovered


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("transcript", type=Path)
    parser.add_argument("--min-discovered", type=int, default=1)
    parser.add_argument("--require-prefix", default=None,
                        help="Require each discovered test to begin with this namespace prefix")
    args = parser.parse_args(argv)
    try:
        count = verify_discovery(args.transcript, min_discovered=args.min_discovered,
                                 require_prefix=args.require_prefix)
    except DiscoveryError as exc:
        print(f"FAIL xUnit discovery evidence: {exc}", file=sys.stderr)
        return 1
    print(f"PASS xUnit discovery evidence: listed={count} (not execution)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
