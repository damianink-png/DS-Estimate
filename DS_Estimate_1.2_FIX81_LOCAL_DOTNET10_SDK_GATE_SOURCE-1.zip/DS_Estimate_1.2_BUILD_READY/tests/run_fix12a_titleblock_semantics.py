#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / "engines" / "python"
sys.path.insert(0, str(ENGINE))

from analyze_document import result_from_text  # noqa: E402

passed = 0
failed = 0

def check(name: str, ok: bool, detail: str = ""):
    global passed, failed
    if ok:
        passed += 1
        print(f"[PASS] {name}")
    else:
        failed += 1
        print(f"[FAIL] {name}: {detail}")

mass_text = """CAD Masse
CAD mass (Kg)
Masse CAO
inkl. / incl. / incl.
Schweissnähte / Welds / Cordons de soudure
0.000 %
138
Datum / Date
"""
r = result_from_text(mass_text)
check("CAD mass header unit + separate value", abs((r.get("documentMassKg") or 0) - 138.0) < 1e-9, str(r))
check("CAD mass confidence guarded", (r.get("documentMassConfidence") or 0) >= 90, str(r.get("documentMassEvidence")))
check("weld percentage is not mass", (r.get("documentMassKg") or 0) != 0.0, str(r))

reference_text = """Oberflächenbeschaffenheit / Surface texture / Etat de surface
Werkstoff / Material / Matière
LH350CAT2-LH11657002
***
Zeichnungs Nr. / Drawing No.
1000 024 0120 01 07
"""
r = result_from_text(reference_text)
check("internal material code rejected as grade", not r.get("materialHint"), str(r))
check("internal material code preserved as reference", r.get("materialReference") == "LH350CAT2-LH11657002", str(r))

s355_text = """Gewicht / Weight kg
-
Werkstoff/Material
S355
Zeichnungs-Nr. / Drawing no.
30000101
"""
r = result_from_text(s355_text)
check("S355 title-block grade", r.get("materialHint") == "S355", str(r))
check("dash weight does not create mass", r.get("documentMassKg") is None, str(r))

noisy_generic_weight = """Gewicht / Weight kg
-
Geprüft / Reviewed
03.06.2026
Gezeichnet / Design
27.05.2026
2
Werkstoff/Material
S355
"""
r = result_from_text(noisy_generic_weight)
check("generic Weight kg does not steal later revision digit", r.get("documentMassKg") is None, str(r))

r = result_from_text("Material\n42CrMo4\n")
check("common alloy grade 42CrMo4", r.get("materialHint") == "42CRMO4", str(r))

fit_text = "Ø90 F8/h9\nGeneral tolerances ISO 13920-AE"
r = result_from_text(fit_text)
holes = r.get("holeRequirements") or []
check("F8/h9 fit pair keeps hole fit F8", any(abs(float(x.get("nominalDiameterMm") or 0) - 90) < 0.01 and x.get("fitCode") == "F8" for x in holes), str(holes))

# Integration: DXF block/text entities may put the label and value in separate entities.
try:
    import ezdxf
    with tempfile.TemporaryDirectory(prefix="dse_titleblock_") as td:
        dxf_path = Path(td) / "titleblock.dxf"
        doc = ezdxf.new("R2018")
        msp = doc.modelspace()
        for y, text in enumerate([
            "CAD Masse", "CAD mass (Kg)", "Masse CAO", "Schweissnaehte / Welds", "0.000 %", "138",
            "Werkstoff / Material / Matiere", "LH350CAT2-LH11657002", "Ø90 F8/h9"
        ]):
            msp.add_text(text, dxfattribs={"height": 3}).set_placement((0, 100-y*5))
        doc.saveas(dxf_path)
        cp = subprocess.run([sys.executable, str(ENGINE / "analyze_dxf.py"), str(dxf_path)], capture_output=True, text=True, timeout=45)
        payload = json.loads(cp.stdout[cp.stdout.find("{"):])
        check("DXF title-block mass 138", abs(float(payload.get("documentMassKg") or 0) - 138) < 1e-9, cp.stdout[-1200:])
        check("DXF material reference not grade", not payload.get("materialHint") and payload.get("materialReference") == "LH350CAT2-LH11657002", cp.stdout[-1200:])
        check("DXF F8 fit", any(x.get("fitCode") == "F8" for x in payload.get("holeRequirements") or []), cp.stdout[-1200:])
except Exception as exc:
    check("DXF integration available", False, repr(exc))

# Integration: vector PDF title blocks frequently put unit in the header and numeric
# value in a lower cell. This verifies the actual PDF analyzer, not just regexes.
try:
    import pymupdf as fitz
    with tempfile.TemporaryDirectory(prefix="dse_pdf_titleblock_") as td:
        pdf_path = Path(td) / "titleblock.pdf"
        doc = fitz.open()
        page = doc.new_page(width=595, height=842)
        y = 80
        for text in [
            "CAD Masse / CAD mass / Masse CAO (Kg)",
            "inkl. / incl. / incl. Schweissnaehte / Welds 0.000 %",
            "138",
            "Werkstoff / Material / Matiere",
            "LH350CAT2-LH11657002",
            "Drawing No. 1000 024 0120 01 07",
        ]:
            page.insert_text((60, y), text, fontsize=11)
            y += 28
        doc.save(pdf_path)
        doc.close()
        cp = subprocess.run([sys.executable, str(ENGINE / "analyze_document.py"), str(pdf_path)], capture_output=True, text=True, timeout=75)
        payload = json.loads(cp.stdout[cp.stdout.find("{"):])
        check("PDF title-block mass 138", abs(float(payload.get("documentMassKg") or 0) - 138) < 1e-9, cp.stdout[-1600:])
        check("PDF reference not grade", not payload.get("materialHint") and payload.get("materialReference") == "LH350CAT2-LH11657002", cp.stdout[-1600:])
except Exception as exc:
    check("PDF integration available", False, repr(exc))

print(f"FIX12A TITLEBLOCK SEMANTICS: {passed}/{passed+failed} PASS")
raise SystemExit(0 if failed == 0 else 1)
