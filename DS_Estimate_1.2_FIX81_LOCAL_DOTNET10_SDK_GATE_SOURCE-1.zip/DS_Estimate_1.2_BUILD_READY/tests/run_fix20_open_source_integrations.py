#!/usr/bin/env python3
from pathlib import Path
import importlib.util
import os
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
passed = failed = 0


def check(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print("PASS ", name)
    else:
        failed += 1
        print("FAIL ", name, "::", detail)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


step = load("dse_fix20_step", ROOT / "engines/python/analyze_step.py")
sys.path.insert(0, str(ROOT / "engines/python"))
tabular = load("dse_fix20_tabular", ROOT / "engines/python/analyze_tabular.py")


class Vec:
    def __init__(self, values): self.values = values
    def toTuple(self): return self.values


class Face:
    def __init__(self, area, normal, center):
        self._area, self._normal, self._center = area, normal, center
    def geomType(self): return "PLANE"
    def Area(self): return self._area
    def normalAt(self): return Vec(self._normal)
    def Center(self): return Vec(self._center)


class Box:
    xmin = ymin = zmin = 0.0
    xmax = ymax = zmax = 10.0


class Solid:
    def BoundingBox(self): return Box()
    def Faces(self):
        return [
            Face(100.0, (0, 0, 1), (5, 5, 10)),
            Face(100.0, (0, 0, -1), (5, 5, 0)),
            Face(16.0, (0, 0, 1), (5, 5, 6)),
        ]


pockets = step.detect_pocket_candidates(Solid())
check("BREP pocket candidate detected", pockets["count"] == 1, str(pockets))
check("BREP pocket depth exact", abs(pockets["maxDepthMm"] - 4.0) < 1e-9, str(pockets))
check("BREP pocket area exact", abs(pockets["areaMm2"] - 16.0) < 1e-9, str(pockets))
check("principal machining axis retained", pockets["candidates"][0]["axis"] == "Z+", str(pockets))

native_loaded = False
try:
    import cadquery as cq
    native_loaded = True
    plain = cq.Workplane("XY").box(40, 30, 10).val()
    pocketed = cq.Workplane("XY").box(40, 30, 10).faces(">Z").workplane().rect(16, 10).cutBlind(-4).val()
    plain_result = step.detect_pocket_candidates(plain)
    pocket_result = step.detect_pocket_candidates(pocketed)
    check("real CadQuery box has no false pocket", plain_result["count"] == 0, str(plain_result))
    check("real CadQuery rectangular pocket counted once", pocket_result["count"] == 1, str(pocket_result))
    check("real CadQuery pocket dimensions", abs(pocket_result["areaMm2"] - 160.0) < 0.01 and abs(pocket_result["maxDepthMm"] - 4.0) < 0.01, str(pocket_result))
except ModuleNotFoundError:
    print("SKIP  real CadQuery pocket geometry (cadquery unavailable)")

os.environ.pop("DSE_ENABLE_DOCLING", None)
text, state = tabular.try_docling_enrichment(Path("dummy.docx"))
check("Docling is optional by default", text == "" and state == "disabled", state)

domain = (ROOT / "src/DSEstimate.Core/Domain.cs").read_text(encoding="utf-8-sig")
engine = (ROOT / "src/DSEstimate.Core/ProjectIntelligenceEngines.cs").read_text(encoding="utf-8-sig")
infra = (ROOT / "src/DSEstimate.Infrastructure/DocumentAnalyzers.cs").read_text(encoding="utf-8-sig")
check("pocket schema wired", all(x in domain for x in ["PocketCandidateCount", "PocketCandidateAreaMm2", "PocketMaxDepthMm"]))
check("pockets affect CNC complexity", "pockets * 4" in engine and "kieszenie-kandydaci" in engine)
check("STEP cache invalidated", "surface4-cnc5-pocket1-hole3-dse12-fix20" in infra)

notice = (ROOT / "LICENCJE/00_DS_ESTIMATE_THIRD_PARTY_NOTICE.txt").read_text(encoding="utf-8-sig")
check("integration provenance recorded", all(x in notice for x in ["Docling", "OpenMill", "PDFMathTranslate-next"]))

print(f"\nSUMMARY PASS={passed} FAIL={failed}")
rc = 1 if failed else 0
if native_loaded:
    # FIX23: CadQuery/OCP native destructors can crash on interpreter shutdown.
    # Preserve the computed test status while skipping only native teardown.
    sys.stdout.flush(); sys.stderr.flush()
    os._exit(rc)
sys.exit(rc)
