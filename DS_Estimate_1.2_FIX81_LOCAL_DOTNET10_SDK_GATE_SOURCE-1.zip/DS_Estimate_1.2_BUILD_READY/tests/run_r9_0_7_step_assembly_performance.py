﻿from pathlib import Path
import json, os, subprocess, sys, tempfile

ROOT=Path(__file__).resolve().parents[1]
ENGINE=ROOT/'engines'/'python'/'analyze_step.py'
checks=[]

def check(name, cond):
    checks.append((name,bool(cond)))
    print(('PASS' if cond else 'FAIL'), name)

src=ENGINE.read_text(encoding='utf-8')
svc=(ROOT/'src/DSEstimate.Infrastructure/ProjectAnalysisService.cs').read_text(encoding='utf-8-sig')
doc=(ROOT/'src/DSEstimate.Infrastructure/DocumentAnalyzers.cs').read_text(encoding='utf-8-sig')
dom=(ROOT/'src/DSEstimate.Core/Domain.cs').read_text(encoding='utf-8-sig')
build=(ROOT/'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig')

check('STEP pre-scan mode exists', 'DSE_STEP_PRESCAN' in src)
check('expensive analysis per quick unique geometry', ('for quick_items in quick_groups.values()' in src) or ('unique_items = list(quick_groups.values())' in src and 'def analyze_unique' in src))
check('reused instance analysis exposed', 'reusedSolidAnalyses' in src)
check('large assembly bounded joint checks', ('12000 if large_assembly else 40000' in src) or ('else 12000 if large_assembly' in src and '24000 if large_assembly and priority_accurate' in src))
check('large assembly skips global cavity pass', 'fast_history or core_only or large_assembly' in src)
check('geometry analyzer exposes pre-scan', 'PreScanAsync' in doc and 'DSE_STEP_PRESCAN' in doc)
check('project pre-scans multiple STEP files', 'stepPrescans' in svc and 'stepDocuments.Count > 1' in svc)
check('STEP prioritizes assembly root before child STEP', 'SelectStrongAssemblyRoot' in svc and 'scan.SolidCount' in svc and '.ThenByDescending(x => x.SizeBytes)' in svc)
check('contained standalone STEP avoids duplicate totals', 'IsContainedInAssembly' in svc and 'EnrichAssemblyFromContainedStep' in svc and 'bez dublowania masy' in svc)
check('containment consumes quantities', 'remaining[i] -= needed' in svc)
check('geometry summary exposes reuse metrics', 'ReusedSolidAnalyses' in dom and 'FullyAnalyzedUniqueSolids' in dom)
check('build runs R9.0.7 performance gate', 'run_r9_0_7_step_assembly_performance.py' in build)

# Small real CadQuery smoke: repeated instances must keep physical counts while
# reusing expensive feature analysis. Skip only when CadQuery is unavailable.
try:
    import cadquery as cq
    with tempfile.TemporaryDirectory(prefix='dse_r907_') as td:
        p=Path(td)/'repeat.step'
        solids=[]
        # 6 unique plates, each repeated 4x => 24 bodies, each with two holes.
        for i in range(6):
            L=80+i*7
            base=(cq.Workplane('XY').box(L,40+i,6)
                  .faces('>Z').workplane()
                  .pushPoints([(-L*.25,0),(L*.25,0)]).hole(8).val())
            for q in range(4):
                solids.append(base.translate(cq.Vector(i*150,q*70,0)))
        cq.exporters.export(cq.Compound.makeCompound(solids),str(p))
        cp=subprocess.run([sys.executable,str(ENGINE),str(p)],capture_output=True,text=True,timeout=90)
        data=json.loads(cp.stdout[cp.stdout.rfind('{'):]) if False else json.loads(cp.stdout.strip().splitlines()[-1])
        check('repeat smoke 24 solids retained', data.get('solidCount')==24)
        check('repeat smoke holes retained', data.get('totalHoleCount')==48)
        check('repeat smoke reuses analyses', data.get('reusedSolidAnalyses',0)>=12)
        env=os.environ.copy(); env['DSE_STEP_PRESCAN']='1'
        cp2=subprocess.run([sys.executable,str(ENGINE),str(p)],capture_output=True,text=True,timeout=90,env=env)
        scan=json.loads(cp2.stdout.strip().splitlines()[-1])
        check('pre-scan returns geometry', scan.get('available') and scan.get('solidCount')==24)
        check('pre-scan avoids manufacturing holes', scan.get('totalHoleCount',0)==0)
except Exception as exc:
    print('SKIP CadQuery smoke:', exc)

fail=sum(1 for _,ok in checks if not ok)
print(f'\nSUMMARY PASS={len(checks)-fail} FAIL={fail}')
rc = 1 if fail else 0
# The assertions and temporary-file cleanup are complete.  Avoid a Windows
# access violation in CadQuery/OCP finalizers from replacing the real result.
try:
    sys.stdout.flush(); sys.stderr.flush()
finally:
    os._exit(rc)
