#!/usr/bin/env python3
"""FIX44: exercise stale-TRX removal and verify CI wiring (no .NET execution)."""
from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLEAR = ROOT / "tests/clear_stale_trx.py"
VERIFY = ROOT / "tests/verify_dotnet_trx.py"
WORKFLOW = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
checks: list[tuple[str, bool]] = []
skipped = 0


def check(name: str, result: bool) -> None:
    checks.append((name, bool(result)))
    print(("PASS " if result else "FAIL ") + name, flush=True)


def clear(root: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run([sys.executable, str(CLEAR)], cwd=root, capture_output=True,
                          text=True, timeout=15)


with tempfile.TemporaryDirectory(prefix="dse-fix44-") as temp:
    root = Path(temp)
    results = root / "TestResults"
    results.mkdir()
    trx = results / "ds-estimate-xunit.trx"
    unrelated = results / "keep-this.txt"
    unrelated.write_text("keep", encoding="utf-8")

    empty = clear(root)
    check("missing TRX is harmless", empty.returncode == 0 and "No previous" in empty.stdout)
    trx.write_text("STALE", encoding="utf-8")
    removed = clear(root)
    check("stale TRX is actually deleted", removed.returncode == 0 and not trx.exists())
    check("unrelated artifact is preserved", unrelated.read_text(encoding="utf-8") == "keep")
    missing = subprocess.run([sys.executable, str(VERIFY), str(trx), "--require-results",
                              "--min-executed", "60"], capture_output=True, text=True, timeout=15)
    check("strict verifier rejects missing fresh TRX", missing.returncode != 0 and "does not exist" in missing.stderr)
    check("second cleanup remains idempotent", clear(root).returncode == 0)

    # A fake green summary must not be mistaken for a real xUnit run.
    trx.write_text('<TestRun><ResultSummary outcome="Completed"><Counters total="60" '
                   'executed="60" passed="60" failed="0" error="0" />'
                   '</ResultSummary></TestRun>', encoding="utf-8")
    bogus = subprocess.run([sys.executable, str(VERIFY), str(trx), "--require-results",
                            "--min-executed", "60"], capture_output=True, text=True, timeout=15)
    check("counter-only TRX is rejected", bogus.returncode != 0)
    check("cleanup removes bogus TRX", clear(root).returncode == 0 and not trx.exists())

    trx.mkdir()
    directory = clear(root)
    check("directory at TRX path fails closed", directory.returncode != 0 and trx.is_dir())
    trx.rmdir()
    try:
        trx.symlink_to(unrelated)
    except (NotImplementedError, OSError):
        skipped += 1
        print("SKIP symlink safety (host disallows creating symlinks)", flush=True)
    else:
        symlink = clear(root)
        check("symlink TRX fails closed", symlink.returncode != 0 and trx.is_symlink())
        trx.unlink()

marker = "      - name: Run C# xUnit tests\n"
check("unique xUnit execution step", WORKFLOW.count(marker) == 1)
if marker in WORKFLOW:
    start = WORKFLOW.index(marker)
    end = WORKFLOW.find("\n      - ", start + len(marker))
    runner = WORKFLOW[start:end if end >= 0 else len(WORKFLOW)]
    cleanup = "python tests/clear_stale_trx.py"
    test = "dotnet test tests/DSEstimate.Core.Tests/DSEstimate.Core.Tests.csproj"
    check("stale TRX cleared before real dotnet test", cleanup in runner and test in runner
          and runner.index(cleanup) < runner.index(test))
    check("cleanup failure propagates before dotnet test", runner.count(
          "if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }") >= 2
          and runner.index("if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }") < runner.index(test))
    check("strict TRX verifier remains enabled", "--require-results --min-executed 60" in WORKFLOW)
else:
    check("stale TRX cleared before real dotnet test", False)
    check("cleanup failure propagates before dotnet test", False)
    check("strict TRX verifier remains enabled", False)

for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{gate} includes FIX44 regression", "run_fix44_trx_freshness_guard.py" in
          (ROOT / gate).read_text(encoding="utf-8-sig"))

passed = sum(ok for _, ok in checks)
print(f"SUMMARY PASS={passed} FAIL={len(checks) - passed} SKIP={skipped}", flush=True)
raise SystemExit(1 if passed != len(checks) else 0)
