#!/usr/bin/env python3
from pathlib import Path
import ast
import json
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
passed = failed = 0


def read(relative):
    return (ROOT / relative).read_text(encoding="utf-8-sig")


def check(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print("PASS ", name)
    else:
        failed += 1
        print("FAIL ", name, "::", detail)


runner = read("src/DSEstimate.Infrastructure/PythonRunner.cs")
release_service = read("src/DSEstimate.Infrastructure/QuoteReleaseService.cs")
health = read("src/DSEstimate.Infrastructure/EngineHealthService.cs")
golden = read("src/DSEstimate.Infrastructure/FirmGoldenSetService.cs")
history = read("src/DSEstimate.Infrastructure/HistoryImportService.cs")
domain = read("src/DSEstimate.Core/Domain.cs")
vm = read("src/DSEstimate.App/ViewModels/MainViewModel.cs")
ui = read("src/DSEstimate.App/Views/MainWindow.axaml")
excel = read("src/DSEstimate.Infrastructure/ExcelExportService.cs")
diagnostic = read("src/DSEstimate.Infrastructure/DiagnosticReportService.cs")
build = read("BUILD_FULL_PORTABLE_ZIP.ps1")
cycle = read("VERIFY_FIX18_BUILD_CACHE_CYCLE.ps1")
xunit = read("tests/DSEstimate.Core.Tests/Fix18ReleaseSafetyTests.cs")

# One-job STEP containment and operator visibility.
check("STEP active-job memory ceiling", "DSE_STEP_JOB_MAX_PRIVATE_MB" in runner and "MaxSingleJobPrivateMemoryMb" in runner)
check("STEP memory polled during response", "while (!responseTask.IsCompleted)" in runner and "TryGetPrivateMemoryMb" in runner)
check("STEP resource stop preserves resume instruction", "RESOURCE_LIMIT" in runner and "checkpoint" in runner and "cache" in runner)
check("STEP lifecycle status available", "GetStepWorkerHealth" in runner and "StepWorkerHealthInfo" in runner)
check("idle STEP workers can be restarted", "RestartIdleStepWorkers" in runner and "RestartFromHealthPanel" in runner)

# Offer release gate and immutable evidence snapshot.
check("release gate blocks incomplete offer", "BuildBlockers" in release_service and "brak kompletnej ceny" in release_service)
check("override has reason user time fingerprint", all(x in domain for x in ["Reason", "ApprovedBy", "ApprovedAt", "ApprovedFingerprint"]))
check(
    "override bound to exact fingerprint",
    re.search(r"FixedEquals\(approval\.ApprovedFingerprint\s*(?:\?\?\s*\"\")?\s*,\s*fingerprint\)", release_service) is not None,
)
check("snapshot hashes all evidence layers", all(x in domain for x in ["AnalysisHash", "SettingsHash", "CalibrationHash", "EngineHash", "DocumentHashes"]))
check("export freezes before writing", vm.find("FreezeForExport") < vm.find("_excel.Export"))
check("offer release visible in minimal UI", "Wydanie oferty" in ui and "Eksport oferty XLSX" in ui)
check("audited exception visible", "Wyjątek audytowany" in ui and "ApproveOfferOverrideCommand" in ui)
check("snapshot exported to XLSX", "Odcisk wydanej oferty SHA-256" in excel and "WYJĄTEK AUDYTOWANY" in excel)
check("snapshot exported to diagnostic", "zamrożony snapshot" in diagnostic and "Odcisk zatwierdzenia" in diagnostic)

# Calibration is chronological, grouped and measures central/tail/systematic error.
check("calibration has completion date", "CalibrationDate" in history)
check("calibration family removes revisions", "CalibrationRevisionSuffix" in history and "CalibrationFamilyKey" in history)
check("chronological family holdout", "OrderBy(x => x.LastDate)" in history and "validationGroups" in history)
check("holdout never splits family", "validationKeys" in history and "TrainingSourceKeys" in history)
check("bias metric", "BaselineBiasPercent" in history and "ProposedBiasPercent" in history)
check("P90 metric", "BaselineP90Percent" in history and "Percentile90" in history)
check("rolling validation at 20", "< 20" in history and "RollingFoldCount" in history)
check("new calibration tests", all(x in xunit for x in ["keeps_revision_family_together", "uses_newest_projects", "Rolling_backtest"]))

# Engine health and honest firm golden-set framework.
check("engine health covers STEP OCR DWG docs RAM", all(x in health for x in ["STEP / CadQuery", "Tesseract OCR", "DWG / ACadSharp", "Dokumenty PDF/BOM", "Pamięć"]))
check("engine health panel", "Stan silników lokalnych" in ui and "EngineHealthItems" in ui)
check("golden set requires 20-50 real jobs", "Math.Clamp(document.MinimumProjects, 20, 50)" in golden)
check("golden set rejects duplicates/incomplete", "rekordy niepełne lub zduplikowane" in golden)
check("golden set has MAPE bias P90 gates", all(x in golden for x in ["PriceMapePercent", "PriceBiasPercent", "PriceP90Percent"]))
golden_json = json.loads(read("config/golden_set_company.json"))
check("golden template has no fabricated projects", golden_json.get("projects") == [])
check("golden config shipped by app", "golden_set_company.json" in read("src/DSEstimate.App/DSEstimate.App.csproj"))

# Build cache protocol and actual optional cycle.
check("cache protocol self-test", "Test-BuildCacheProtocol" in build)
check("cache self-test covers cold warm corrupt key", all(x in build for x in ["stan zimny", "stan ciepły", "uszkodzona zawartość", "zmieniony klucz"]))
check("cache root can be isolated", "DSE_BUILD_CACHE_ROOT" in build)
check("real cache cycle has three builds", all(x in cycle for x in ["1/3 COLD", "2/3 WARM", "3/3 CORRUPT"]))
check("real cache cycle asserts miss hit miss", cycle.count('"MISS"') >= 3 and cycle.count('"HIT"') >= 2)
check("FIX18 build reports emitted", "BUILD_REPORT_FIX18.json" in build and "BUILD_REPORT_FIX18.txt" in build)

for relative in [
    "src/DSEstimate.App/Views/MainWindow.axaml",
    "src/DSEstimate.App/DSEstimate.App.csproj",
]:
    try:
        ET.parse(ROOT / relative)
        check(f"XML parses: {relative}", True)
    except Exception as exc:
        check(f"XML parses: {relative}", False, str(exc))


def balanced_csharp(source):
    stripped = re.sub(r'@?"(?:""|\\.|[^"\\])*"', '""', source)
    stripped = re.sub(r"//.*", "", stripped)
    return stripped.count("{") == stripped.count("}")


for relative in [
    "src/DSEstimate.Core/Domain.cs",
    "src/DSEstimate.Infrastructure/PythonRunner.cs",
    "src/DSEstimate.Infrastructure/HistoryImportService.cs",
    "src/DSEstimate.Infrastructure/QuoteReleaseService.cs",
    "src/DSEstimate.Infrastructure/EngineHealthService.cs",
    "src/DSEstimate.Infrastructure/FirmGoldenSetService.cs",
    "src/DSEstimate.App/ViewModels/MainViewModel.cs",
    "tests/DSEstimate.Core.Tests/Fix18ReleaseSafetyTests.cs",
]:
    check(f"C# braces balanced: {relative}", balanced_csharp(read(relative)))

try:
    ast.parse(Path(__file__).read_text(encoding="utf-8-sig"))
    check("FIX18 test Python syntax", True)
except SyntaxError as exc:
    check("FIX18 test Python syntax", False, str(exc))

print(f"\nSUMMARY PASS={passed} FAIL={failed}")
sys.exit(1 if failed else 0)
