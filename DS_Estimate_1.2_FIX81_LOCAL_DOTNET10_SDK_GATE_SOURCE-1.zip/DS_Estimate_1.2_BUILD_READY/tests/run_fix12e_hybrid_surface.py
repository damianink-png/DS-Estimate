#!/usr/bin/env python3
from pathlib import Path
import re, xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name, cond, detail=''):
    ok=bool(cond); checks.append(ok)
    print(('PASS  ' if ok else 'FAIL  ')+name+(f' :: {detail}' if detail else ''))

def text(rel, enc='utf-8-sig'):
    return (ROOT/rel).read_text(encoding=enc)

resolver=text('src/DSEstimate.Infrastructure/HybridSurfaceAreaResolver.cs')
merge=text('src/DSEstimate.Infrastructure/ProjectAnalysisService.cs')
domain=text('src/DSEstimate.Core/Domain.cs')
cost=text('src/DSEstimate.Core/CostEngine.cs')
auto=text('src/DSEstimate.Core/AutoQuoteEngine.cs')
unc=text('src/DSEstimate.Core/QuoteUncertaintyModel.cs')
report=text('src/DSEstimate.Infrastructure/DiagnosticReportService.cs')
ui=text('src/DSEstimate.App/Views/MainWindow.axaml')
vm=text('src/DSEstimate.App/ViewModels/MainViewModel.cs')
xunit=text('tests/DSEstimate.Core.Tests/Fix12EHybridSurfaceTests.cs')
release=(ROOT/'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='ascii')
build=(ROOT/'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig')

check('FIX12E resolver exists', 'class HybridSurfaceAreaResolver' in resolver)
check('surface contribution domain exists', 'class SurfaceAreaContribution' in domain)
check('hybrid surface metadata in drawing', all(x in domain for x in ['HybridSurfaceAreaM2','HybridSurfaceAreaConfidence','HybridSurfaceAreaCoveragePercent','HybridSurfaceAreaContributions']))
check('resolver wired before Cost Engine', merge.find('HybridSurfaceAreaResolver.Apply') < merge.find('var result = _cost.Build'))
check('resolver requires authoritative scoped root', '!resolution.HasAuthoritativeRootBom || !resolution.ScopeEnforced' in resolver)
check('root explicit area has project-total priority', 'DOCUMENT_TOTAL' in resolver and 'rootExplicit' in resolver)
check('one best source per family priority explicit', 'explicitByFamily.TryGetValue' in resolver)
check('one best source per family priority STEP', 'stepByFamily.TryGetValue' in resolver)
check('one best source per family priority DXF', 'dxfByFamily.TryGetValue' in resolver)
check('DXF uses two faces', '2.0 * dxf.ClosedProfileAreaMm2' in resolver)
check('DXF adds edge area when thickness known', 'dxf.CutLengthMm * thickness.Value' in resolver)
check('thickness can come from local STEP', 'Classification.Contains("Blacha"' in resolver)
check('thickness can come from BOM text', 'ThicknessRx' in resolver and 'PLATE|BLECH' in resolver)
check('common RHS SHS profile fallback', 'RhsRx' in resolver and 'BOM_PROFILE' in resolver)
check('common pipe profile fallback', 'PipeRx' in resolver)
check('mass fallback is per family not project', 'TryMassArea' in resolver and 'FamilyKey = family' in resolver)
check('mass+thickness uses physical A=2m/rho/t', '2.0 / (7850.0 * (thickness / 1000.0))' in resolver)
check('OCR huge fractional quantity guarded', 'q > 100 && Math.Abs(q - Math.Round(q))' in resolver)
check('81t style false mass hard guarded', 'x is > 0.001 and < 25_000' in resolver)
check('same family STEP and DXF not added together', 'continue;' in resolver and 'stepByFamily.TryGetValue' in resolver and 'dxfByFamily.TryGetValue' in resolver)
check('surface coverage is audited', 'HybridSurfaceAreaCoveragePercent' in resolver and 'coverage' in resolver)
check('partial STEP cannot own project coating area', 'stepCoversWholeRoot' in cost and 'projectGeometrySurfaceUsable' in cost)
check('hybrid surface feeds paint model', 'drawing.HybridSurfaceAreaM2' in cost and 'FIX12E hybrydowo' in cost)
check('paint estimate exposes area source', 'AreaSource' in domain and 'AreaCoveragePercent' in domain)
check('partial hybrid surface creates risk', 'FIX12E_SURFACE_PARTIAL_COVERAGE' in cost)
check('local material mix is not project conflict', 'IsLocalVariation' in domain and 'Count(x => !x.IsLocalVariation)' in unc)
check('local material mix not emitted as data risk', 'Conflicts.Where(x => !x.IsLocalVariation)' in cost)
check('weld dimensions across families use modal not max', 'localFamilyVariation' in merge and '.GroupBy(x => $"{x.WeldSizeKind.ToUpperInvariant()}' in merge)
check('weld family variation is local', 'Wymiary spoin — różne złącza/rodziny' in merge and 'IsLocalVariation = localFamilyVariation' in merge)
check('missing mass blocks recommended offer', 'CENA OFERTOWA NIE WYZNACZONA' in auto and 'displayedRecommendedPrice = offerPriceAvailable ? r.FinalPricePln : 0' in auto)
check('recognized process cost remains diagnostic', 'Koszt rozpoznanych operacji' in auto)
check('UI main price uses safe AutoQuote price', ui.count('Analysis.AutoQuote.RecommendedPricePln') >= 3, str(ui.count('Analysis.AutoQuote.RecommendedPricePln')))
check('report has FIX12E audit section', 'FIX12E / HYBRYDOWA REKONSTRUKCJA POWIERZCHNI' in report)
check('report shows surface source and coverage', 'Źródło powierzchni' in report and 'Pokrycie rodzin BOM' in report)
check('xunit behavior coverage included', all(x in xunit for x in ['Surface_is_resolved_per_family_without_step_dxf_double_count','Dxf_surface_adds_edge_area_when_bom_thickness_is_known','Partial_step_uses_hybrid_project_area_for_paint_not_local_step_area','Missing_project_mass_never_becomes_recommended_offer_price']))

try:
    ET.fromstring(ui)
    check('MainWindow XAML parses', True)
except Exception as e:
    check('MainWindow XAML parses', False, str(e))

for name,blob in [('resolver',resolver),('merge',merge),('domain',domain),('cost',cost),('autoquote',auto),('uncertainty',unc),('report',report),('xunit',xunit)]:
    check(name+' braces balanced', blob.count('{')==blob.count('}'), f"{blob.count('{')}/{blob.count('}')}")

check('FIX12E wired into release gate', 'run_fix12e_hybrid_surface.py' in release)
check('FIX12E wired into portable build gate', 'run_fix12e_hybrid_surface.py' in build)

print(f'\nSUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)}')
raise SystemExit(0 if all(checks) else 1)
