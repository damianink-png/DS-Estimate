"""FIX66 runtime regression: ZIP writes are atomic and preserve previous pack."""
import contextlib
import importlib.util
import io
import json
import sys
import tempfile
import zipfile
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / 'engines/python/build_private_analysis_pack.py'
spec = importlib.util.spec_from_file_location('ds_private_pack_fix66', ENGINE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
count = 0


def check(label, condition):
    global count
    if not condition:
        raise AssertionError(label)
    count += 1
    print('PASS | ' + label, flush=True)


def generate(source, target):
    with mock.patch.object(sys, 'argv', [str(ENGINE), str(source), str(target)]):
        with contextlib.redirect_stdout(io.StringIO()) as stdout:
            module.main()
    return json.loads(stdout.getvalue())


def temp_files(directory, output):
    return list(directory.glob('.' + output.name + '.*.tmp'))


with tempfile.TemporaryDirectory(prefix='ds_fix66_') as d:
    root = Path(d) / 'source'
    root.mkdir()
    (root / 'S355.txt').write_text('S355, CNC 3 sztuki', encoding='utf-8')
    target = root / 'private_pack.zip'
    result = generate(root, target)
    check('successful generation returns ok', result['ok'] is True)
    check('initial source file count', result['files'] == 1)
    check('ZIP created at requested destination', target.is_file())
    with zipfile.ZipFile(target) as z:
        check('initial archive CRC', z.testzip() is None)
        check('archive contains only sanitized outputs', set(z.namelist()) == {
            'MANIFEST.json', 'TECHNICAL_SNIPPETS.json', 'README_PRIVACY.txt'})
        check('initial manifest file count', json.loads(z.read('MANIFEST.json'))['file_count'] == 1)
    original = target.read_bytes()
    check('successful run leaves no temp files', not temp_files(root, target))

    # Fail during the ZIP payload write, after the destination was created.
    with mock.patch.object(module.zipfile.ZipFile, 'writestr', side_effect=OSError('injected ZIP write error')):
        try:
            generate(root, target)
        except OSError as exc:
            check('ZIP write error is propagated', 'injected ZIP write error' in str(exc))
        else:
            raise AssertionError('ZIP write failure was swallowed')
    check('failed ZIP write preserves previous bytes', target.read_bytes() == original)
    check('failed ZIP write removes temp file', not temp_files(root, target))
    with zipfile.ZipFile(target) as z:
        check('previous ZIP still passes CRC', z.testzip() is None)

    # Fail at the final atomic replacement: the old pack must survive.
    with mock.patch.object(module.os, 'replace', side_effect=PermissionError('injected rename denial')):
        try:
            generate(root, target)
        except PermissionError as exc:
            check('replace error is propagated', 'injected rename denial' in str(exc))
        else:
            raise AssertionError('rename failure was swallowed')
    check('failed replace preserves previous bytes', target.read_bytes() == original)
    check('failed replace removes temp file', not temp_files(root, target))

    result = generate(root, target)
    check('retry succeeds', result['ok'] is True)
    check('retry does not ingest previous ZIP', result['files'] == 1)
    check('retry leaves no temp files', not temp_files(root, target))
    with zipfile.ZipFile(target) as z:
        check('retry ZIP CRC', z.testzip() is None)

print(f'FIX66: {count}/{count} PASS (runtime)')
