#!/usr/bin/env python3
"""FIX41 CI wiring checks. These are static; they do NOT run .NET or xUnit.

The CI runs compileall and PDF/BOM regression scripts. Real PDF checks run
strictly after the .NET/launcher/xUnit gates.
"""
from __future__ import annotations

from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text(encoding='utf-8')
checks: list[tuple[str, bool]] = []


def check(label: str, ok: bool) -> None:
    checks.append((label, bool(ok)))
    print(('PASS ' if ok else 'FAIL ') + label, flush=True)


def step(name: str) -> str:
    marker = f'      - name: {name}\n'
    count = WORKFLOW.count(marker)
    check(f'unique CI step: {name}', count == 1)
    if count != 1:
        return ''
    begin = WORKFLOW.index(marker)
    end = WORKFLOW.find('\n      - ', begin + len(marker))
    return WORKFLOW[begin:end if end >= 0 else len(WORKFLOW)]


check('Python engine edits trigger push and pull_request CI',
      len(re.findall(r"^\s+- 'engines/python/\*\*'$", WORKFLOW, re.M)) == 2)
check('workflow still supports manual dispatch', '  workflow_dispatch:' in WORKFLOW)
smoke = step('Check Python engine syntax and PDF BOM contracts')
setup = step('Check launcher fixture and workflow wiring')
runner = step('Run C# xUnit tests')
upload = step('Save test results')
check('Python source and tests compile syntax on CI',
      'python -m compileall -q engines/python tests' in smoke)
for test in ('run_fix29_pdf_exact_bom_links.py', 'run_fix30_pdf_bom_step_links.py'):
    check(f'CI executes existing {test}', f'python tests/{test}' in smoke)
check('all Python commands preserve native exit codes',
      smoke.count('if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }') == 3)
check('Python output is logged for CI diagnostics',
      smoke.count('Tee-Object -FilePath TestResults/python-engine-regression.log') == 3)
check('CI logs are always uploaded, without uploading source',
      'if: always()' in upload and 'TestResults/python-engine-regression.log' in upload
      and 'engines/python/' not in upload and 'src/' not in upload)
check('launcher and xUnit/TRX verification precede Python PDF gate',
      bool(smoke and setup and runner) and
      WORKFLOW.index('      - name: Check launcher fixture') <
      WORKFLOW.index('      - name: Run C# xUnit tests') <
      WORKFLOW.index('      - name: Verify xUnit TRX contains executed tests') <
      WORKFLOW.index('      - name: Check Python engine syntax'))
check('actual C# xUnit command and strict TRX check remain',
      'dotnet test tests/DSEstimate.Core.Tests/DSEstimate.Core.Tests.csproj' in runner
      and '--require-results --min-executed 60' in WORKFLOW)
check('Windows release gate invokes FIX41 regression',
      'run_fix41_ci_python_engine_gate.py' in
      (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='ascii'))
check('portable release gate invokes FIX41 regression',
      'run_fix41_ci_python_engine_gate.py' in
      (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig'))
passed = sum(ok for _, ok in checks)
print(f'SUMMARY PASS={passed} FAIL={len(checks) - passed} SKIP=0', flush=True)
raise SystemExit(0 if passed == len(checks) else 1)
