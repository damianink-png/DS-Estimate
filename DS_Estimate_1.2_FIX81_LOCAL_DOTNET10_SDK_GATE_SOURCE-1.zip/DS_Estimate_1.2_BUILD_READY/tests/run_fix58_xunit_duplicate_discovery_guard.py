#!/usr/bin/env python3
"""FIX58: synthetic discovery transcript checks (NOT actual xUnit execution)."""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "tests/verify_xunit_discovery.py"
spec = importlib.util.spec_from_file_location("dse_fix58_discovery", TARGET)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
checks: list[bool] = []


def check(name: str, condition: bool) -> None:
    checks.append(bool(condition))
    print(("PASS " if condition else "FAIL ") + name, flush=True)


def transcript(names: list[str]) -> str:
    return ("Test run for DSEstimate.Core.Tests.dll (.NETCoreApp,Version=v10.0)\n"
            "The following Tests are available:\n" +
            "".join("    " + name + "\n" for name in names))


names = [f"DSEstimate.Core.Tests.Fix58.Case{i:03d}" for i in range(60)]
with tempfile.TemporaryDirectory(prefix="dse-fix58-") as tmp:
    file = Path(tmp) / "xunit-discovery.txt"

    def verify(text: str, minimum: int = 60) -> tuple[bool, str]:
        file.write_text(text, encoding="utf-8")
        try:
            count = mod.verify_discovery(file, min_discovered=minimum)
            return True, str(count)
        except mod.DiscoveryError as exc:
            return False, str(exc)

    ok, msg = verify(transcript(names))
    check("60 unique test names accepted", ok and msg == "60")
    ok, msg = verify(transcript(names + [names[0]]))
    check("repeated 61st line rejected", not ok and "Duplicate" in msg)
    ok, msg = verify(transcript(names[:59] + [names[0]]))
    check("59 unique plus duplicate cannot reach 60", not ok and "Duplicate" in msg)
    ok, msg = verify(transcript(names + [names[0]]).replace("    " + names[0] + "\n", "    " + names[0] + "\n", 1))
    check("duplicate even with 60 otherwise unique names rejected", not ok)
    ok, msg = verify(transcript(names + [names[0]]).replace("    " + names[0] + "\n", "  " + names[0] + "\n", 1))
    check("different indentation cannot hide duplicate", not ok and "Duplicate" in msg)
    ok, msg = verify(transcript(names + [names[0]]).replace("    " + names[0] + "\n", "    \x1b[32m" + names[0] + "\x1b[0m\n", 1))
    check("ANSI styling cannot hide duplicate", not ok and "Duplicate" in msg)
    parametrized = names[:59] + ["DSEstimate.Core.Tests.Fix58.Theory(value: 1)",
                                 "DSEstimate.Core.Tests.Fix58.Theory(value: 2)"]
    ok, msg = verify(transcript(parametrized))
    check("distinct theory argument cases accepted", ok and msg == "61")
    ok, msg = verify(transcript(names[:59]))
    check("59 unique test names still rejected", not ok and "59 < 60" in msg)
    file.write_text(transcript(names + [names[0]]), encoding="utf-8")
    cli = subprocess.run([sys.executable, str(TARGET), str(file), "--min-discovered", "60"],
                         capture_output=True, text=True)
    check("CLI rejects duplicate with exit 1", cli.returncode == 1 and "Duplicate" in cli.stderr)
    file.write_text(transcript(names), encoding="utf-8")
    cli = subprocess.run([sys.executable, str(TARGET), str(file), "--min-discovered", "60"],
                         capture_output=True, text=True)
    check("CLI accepts unique list with exit 0", cli.returncode == 0 and "listed=60" in cli.stdout)

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
check("workflow retains real discovery guard", "--min-discovered 60" in workflow)
check("workflow invokes FIX58 regression", "python tests/run_fix58_xunit_duplicate_discovery_guard.py" in workflow)
for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{gate} includes FIX58", "run_fix58_xunit_duplicate_discovery_guard.py" in
          (ROOT / gate).read_text(encoding="utf-8-sig"))
print(f"SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0", flush=True)
raise SystemExit(0 if all(checks) else 1)
