﻿#!/usr/bin/env python3
"""FIX7 regressions derived from the user's real diagnostic reports."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "engines" / "python"))

import analyze_document as document

PASS = 0
FAIL = 0


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8-sig")


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"PASS  {name}")
    else:
        FAIL += 1
        print(f"FAIL  {name} :: {detail}")


def signals(text: str) -> dict:
    return document.result_from_text(text)


def test_weld_grade_guard() -> None:
    separate = signals("WELD 135\nMATERIAL ASTM A36")
    same_line = signals("WELD 135 MATERIAL ASTM A36")
    z_quality = signals("ISO 5817\nMATERIAL S355J2+Z25")
    explicit = signals("WELD 135 a=6")
    spaced = signals("WELD 135 a 36")

    check("ASTM A36 is not a weld size on a separate line", separate["weldSizeMm"] is None, repr(separate))
    check("ASTM A36 is not a weld size in weld context", same_line["weldSizeMm"] is None, repr(same_line))
    check("+Z25 steel quality is not a weld size", z_quality["weldSizeMm"] is None, repr(z_quality))
    check("explicit a=6 remains a weld size", explicit["weldSizeKind"] == "a" and explicit["weldSizeMm"] == 6, repr(explicit))
    check("unambiguous spaced a 36 remains supported", spaced["weldSizeKind"] == "a" and spaced["weldSizeMm"] == 36, repr(spaced))


def test_source_guards() -> None:
    analyzers = read("src/DSEstimate.Infrastructure/DocumentAnalyzers.cs")
    fusion = read("src/DSEstimate.Infrastructure/ProjectAnalysisService.cs")
    cost = read("src/DSEstimate.Core/CostEngine.cs")
    build = read("BUILD_FULL_PORTABLE_ZIP.ps1")
    full = read("RUN_FULL_RELEASE_TESTS.cmd")

    batch_method = analyzers[
        analyzers.index("PreScanBatchAsync"):
        analyzers.index("public async Task<GeometrySummary> PreScanAsync")
    ]
    check("batch pre-scan accepts single-file fallback cache", all(token in batch_method for token in [
        'singleCacheVersion = EngineResultCache.VersionForScript("r930-prescan-v2", "analyze_step.py")',
        'batchCacheVersion = EngineResultCache.VersionForScripts(',
        '"prescan_step_batch.py", "analyze_step.py"',
        '"step-prescan", singleCacheVersion, path, "prescan"',
        "if (missing.Count == 0)",
    ]))
    check("batch results keep their own cache version", '"step-prescan", batchCacheVersion, pair.Key' in batch_method)

    check("density resolution returns confidence", "(double DensityKgM3, bool Assumed) ResolveDensity" in cost and
          "result.DensityAssumed = resolvedDensity.Assumed" in cost)
    check("PLA density is explicit", 'normalized.Contains("PLA")' in cost and "return (1240, false)" in cost)
    check("unknown and mixed material use assumed density", "return (steelDefault, true)" in cost and
          'normalized.StartsWith("MIXED:"' in cost)

    check("unscoped BOM material guard is active", "GuardUnscopedBomMaterial(drawing, drawingsForFusion, activeDocuments)" in fusion)
    check("material guard requires several STEP families", "if (stepDocuments.Count < 4)" in fusion)
    check("material guard preserves BOM row materials", "pozostawiono na pozycjach BOM" in fusion)
    check("identical complete BOMs are canonicalized", all(token in fusion for token in [
        "BomDocumentSignature", "canonicalBomDocuments", "identyczne zestawienia do jednego widoku",
    ]))

    check("FIX7 regression wired into Windows build", "run_r9_3_0_fix7_report_findings.py" in build)
    check("FIX7 regression wired into full release gate", "run_r9_3_0_fix7_report_findings.py" in full)
    check("ProjectAnalysisService braces balanced", fusion.count("{") == fusion.count("}"),
          f"{fusion.count('{')} / {fusion.count('}')}")
    check("CostEngine braces balanced", cost.count("{") == cost.count("}"),
          f"{cost.count('{')} / {cost.count('}')}")


if __name__ == "__main__":
    test_weld_grade_guard()
    test_source_guards()
    print(f"\nSUMMARY\nPASS={PASS} FAIL={FAIL}")
    raise SystemExit(1 if FAIL else 0)
