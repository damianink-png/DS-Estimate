#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
cmd_bytes = (ROOT / 'BUILD_FULL_PORTABLE_ZIP.cmd').read_bytes()
cmd = cmd_bytes.decode('ascii')
passed = failed = 0

def check(name, cond, detail=''):
    global passed, failed
    if cond:
        passed += 1; print('PASS ', name)
    else:
        failed += 1; print('FAIL ', name, '::', detail)

check('CMD stays ASCII/BOM-free', not cmd_bytes.startswith(b'\xef\xbb\xbf') and all(x < 128 for x in cmd_bytes))
check('launcher anchors root to own directory', 'cd /d "%~dp0"' in cmd and 'set "DSE_BUILD_ROOT=%~dp0"' in cmd)
check('missing PS1 is detected before encoding precheck', cmd.find('if not exist "%DSE_BUILD_ROOT%BUILD_FULL_PORTABLE_ZIP.ps1"') < cmd.find('[PRECHECK]'))
check('ZIP direct-run guidance is present', 'NIE URUCHAMIAJ BUILD' in cmd and 'wypakuj CALA paczke' in cmd)
check('PowerShell precheck uses absolute launcher root', "Join-Path $env:DSE_BUILD_ROOT 'BUILD_FULL_PORTABLE_ZIP.ps1'" in cmd)
check('missing file has distinct exit code', 'exit /b 2' in cmd)
check('project structure is guarded', 'src\\DSEstimate.App\\DSEstimate.App.csproj' in cmd)
check('PS1 still has UTF-8 BOM', (ROOT/'BUILD_FULL_PORTABLE_ZIP.ps1').read_bytes().startswith(b'\xef\xbb\xbf'))
check('extraction notice exists', (ROOT/'00_NAJPIERW_WYPAKUJ_CALY_ZIP.txt').is_file())
print(f'\nSUMMARY PASS={passed} FAIL={failed}')
raise SystemExit(1 if failed else 0)
