#!/usr/bin/env python3
"""FIX71: runtime check that generator-internal temporary ZIPs are not inputs.

Runs the actual Python pack engine. Does not claim .NET, Windows, or xUnit coverage.
"""
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / 'engines/python/build_private_analysis_pack.py'
checks = 0


def check(label, ok):
    global checks
    if not ok:
        print('FAIL | ' + label, flush=True)
        raise AssertionError(label)
    checks += 1
    print('PASS | ' + label, flush=True)


def generate(source, output):
    result = subprocess.run([sys.executable, str(ENGINE), str(source), str(output)],
                            capture_output=True, text=True, timeout=45)
    check('generator exits 0', result.returncode == 0)
    check('generator reports success', json.loads(result.stdout)['ok'] is True)
    with zipfile.ZipFile(output) as archive:
        check('ZIP CRC', archive.testzip() is None)
        check('no original documents in ZIP', set(archive.namelist()) == {
            'MANIFEST.json', 'TECHNICAL_SNIPPETS.json', 'README_PRIVACY.txt'})
        return json.loads(archive.read('MANIFEST.json')), output.read_bytes()


with tempfile.TemporaryDirectory(prefix='dse_fix71_') as tmp:
    root = Path(tmp) / 'source'
    root.mkdir()
    source = root / 'S355.txt'
    source.write_text('S355 CNC 3 sztuki', encoding='utf-8')
    output = root / 'private_pack.zip'
    original, _ = generate(root, output)
    check('baseline contains one real document', original['file_count'] == 1)

    # These are real input files, and must NOT be dropped just because the
    # extension is .tmp or the filename resembles a different pack's temp.
    unrelated = root / 'notes.tmp'
    unrelated.write_text('CNC fixture notes', encoding='utf-8')
    other_pack = root / '.other_pack.zip.random.tmp'
    other_pack.write_text('S690QL', encoding='utf-8')
    # Mimic a previous crashed run and an in-progress concurrent run.
    stale = root / '.private_pack.zip.abcd1234.tmp'
    stale.write_bytes(b'old interrupted ZIP fragment')
    with tempfile.NamedTemporaryFile(prefix='.' + output.name + '.', suffix='.tmp',
                                     dir=root, delete=False) as handle:
        live = Path(handle.name)
        handle.write(b'in-progress private ZIP fragment')
    try:
        with_temps, first_bytes = generate(root, output)
        check('internal temporary ZIPs are excluded', with_temps['file_count'] == 3)
        check('only real files contribute to source size', with_temps['source_total_bytes'] ==
              source.stat().st_size + unrelated.stat().st_size + other_pack.stat().st_size)
        check('unrelated temporary files are preserved as inputs',
              sorted(rec['extension'] for rec in with_temps['files']) == ['.tmp', '.tmp', '.txt'])
        check('real document hash remains unchanged',
              any(rec['sha256'] == hashlib.sha256(source.read_bytes()).hexdigest()
                  for rec in with_temps['files']))
        stale.write_bytes(b'changed old ZIP bytes')
        live.write_bytes(b'changed live ZIP bytes')
        with_temps_again, second_bytes = generate(root, output)
        check('temporary changes do not affect manifest', with_temps_again == with_temps)
        check('temporary changes do not affect ZIP bytes', second_bytes == first_bytes)
        check('generator does not delete other runs temporary files',
              stale.exists() and live.exists())
    finally:
        live.unlink(missing_ok=True)
        stale.unlink(missing_ok=True)

    without_temps, third_bytes = generate(root, output)
    check('removing internal temps does not change manifest', without_temps == with_temps)
    check('removing internal temps does not change ZIP bytes', third_bytes == first_bytes)

cmd = (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text('utf-8-sig')
ps1 = (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text('utf-8-sig')
workflow = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text('utf-8')
name = 'run_fix71_private_pack_temp_isolation.py'
check('Windows CMD full release gate runs FIX71',
      ('%PY% tests\\' + name + ' || exit /b 1') in cmd)
check('PowerShell full release gate runs FIX71',
      ('"tests\\' + name + '",') in ps1)
check('private Windows CI runs FIX71',
      ('run: python tests/' + name) in workflow)
print(f'FIX71: {checks}/{checks} PASS; SKIP=0', flush=True)
