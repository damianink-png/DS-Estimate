#!/usr/bin/env python3
"""FIX35 regression of strict TRX discovery. Synthetic XML, not xUnit execution."""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERIFY = ROOT / "tests/verify_dotnet_trx.py"
spec = importlib.util.spec_from_file_location("verify_dotnet_trx", VERIFY)
assert spec is not None and spec.loader is not None
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def trx(*, total=2, executed=2, passed=2, outcomes=("Passed", "Passed"),
        missing_id=False, namespace=True, duplicate_results=False) -> str:
    ns = ' xmlns="http://microsoft.com/schemas/VisualStudio/TeamTest/2010"' if namespace else ""
    records = "".join(
        f'<UnitTestResult testId="{i + 1 if not missing_id else ""}" outcome="{outcome}" />'
        for i, outcome in enumerate(outcomes)
    )
    section = f"<Results>{records}</Results>"
    if duplicate_results:
        section += "<Results/>"
    return (f"<TestRun{ns}>{section}<ResultSummary outcome=\"Completed\">"
            f'<Counters total="{total}" executed="{executed}" passed="{passed}" '
            'failed="0" error="0" timeout="0" aborted="0" notRunnable="0" />'
            '</ResultSummary></TestRun>')


cases = [
    ("real result entries accepted", trx(), True),
    ("namespaceless result entries accepted", trx(namespace=False), True),
    ("skipped record allowed", trx(total=3, outcomes=("Passed", "Passed", "NotExecuted")), True),
    ("skipped without result record allowed", trx(total=3), True),
    ("no Results section rejected", trx().replace('<Results>', '<Missing>').replace('</Results>', '</Missing>'), False),
    ("empty Results rejected", trx(outcomes=()), False),
    ("claimed pass with missing records rejected", trx(outcomes=("Passed",)), False),
    ("claimed pass with skipped record rejected", trx(outcomes=("Passed", "NotExecuted")), False),
    ("failed result with forged green counters rejected", trx(outcomes=("Passed", "Failed")), False),
    ("inconclusive result with forged green counters rejected", trx(outcomes=("Passed", "Inconclusive")), False),
    ("missing test ID rejected", trx(missing_id=True), False),
    ("duplicate Results sections rejected", trx(duplicate_results=True), False),
    ("more results than total rejected", trx(total=2, outcomes=("Passed", "Passed", "NotExecuted")), False),
    ("unknown record tag rejected", trx().replace("UnitTestResult", "OtherResult"), False),
    ("zero executed tests rejected", trx(total=1, executed=0, passed=0, outcomes=()), False),
]

ok = bad = 0
with tempfile.TemporaryDirectory(prefix="dse-fix35-") as d:
    path = Path(d) / "test.trx"
    for label, xml, expected in cases:
        path.write_text(xml, encoding="utf-8")
        try:
            module.verify_trx(path, require_results=True)
            accepted = True
        except module.TrxValidationError:
            accepted = False
        success = accepted == expected
        print(("PASS " if success else "FAIL ") + label, flush=True)
        ok += success
        bad += not success

    path.write_text(trx(), encoding="utf-8")
    cli = subprocess.run([sys.executable, str(VERIFY), str(path), "--require-results"],
                         capture_output=True, text=True)
    success = cli.returncode == 0 and "PASS" in cli.stdout
    print(("PASS " if success else "FAIL ") + "strict CLI accepts result records", flush=True)
    ok += success
    bad += not success
    path.write_text(trx(outcomes=()), encoding="utf-8")
    cli = subprocess.run([sys.executable, str(VERIFY), str(path), "--require-results"],
                         capture_output=True, text=True)
    success = cli.returncode == 1 and "FAIL" in cli.stderr
    print(("PASS " if success else "FAIL ") + "strict CLI rejects empty result records", flush=True)
    ok += success
    bad += not success

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
success = "python tests/verify_dotnet_trx.py TestResults/ds-estimate-xunit.trx --require-results" in workflow
print(("PASS " if success else "FAIL ") + "CI requires strict TRX discovery", flush=True)
ok += success
bad += not success

for name in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    content = (ROOT / name).read_text(encoding="utf-8-sig")
    success = "run_fix35_trx_result_discovery_guard.py" in content
    print(("PASS " if success else "FAIL ") + f" {name} includes FIX35", flush=True)
    ok += success
    bad += not success

print(f"SUMMARY PASS={ok} FAIL={bad} SKIP=0", flush=True)
raise SystemExit(1 if bad else 0)
