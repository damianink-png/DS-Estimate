#!/usr/bin/env python3
"""FIX81: real subprocess checks plus structural Windows release gate checks.

Fake dotnet executables test the preflight's exit behavior on any OS. They do
not constitute a .NET build, Avalonia launch, or xUnit execution.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
checks: list[bool] = []


def check(label: str, ok: bool) -> None:
    checks.append(bool(ok))
    print(('PASS' if ok else 'FAIL') + ' | ' + label, flush=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-root', type=Path, default=ROOT)
    args = parser.parse_args()
    root = args.source_root
    cmd = (root / 'RUN_FULL_RELEASE_TESTS.cmd').read_bytes()
    ps_bytes = (root / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_bytes()
    ps = ps_bytes.decode('utf-8-sig')
    ci = (root / '.github/workflows/ds-estimate-dotnet10.yml').read_text(encoding='utf-8')
    helper = ROOT / 'tests/verify_dotnet_sdk.py'

    check('CMD preflight runs before dotnet test',
          cmd.find(b'%PY% tests\\verify_dotnet_sdk.py || exit /b 1') > 0 and
          cmd.find(b'%PY% tests\\verify_dotnet_sdk.py || exit /b 1') < cmd.find(b'dotnet test '))
    check('CMD keeps ASCII without BOM', cmd.startswith(b'@echo off') and b'\xef\xbb\xbf' not in cmd[:3])
    check('PS1 preflight runs before any publish output deletion',
          ps.find('"tests\\verify_dotnet_sdk.py")') >= 0 and
          ps.find('"tests\\verify_dotnet_sdk.py")') < ps.find('if (Test-Path $Zip) { Remove-Item $Zip'))
    check('PS1 preflight propagates failure',
          'if ($LASTEXITCODE -ne 0) { Fail "Wymagany .NET SDK 10' in ps)
    check('PS1 keeps UTF-8 BOM', ps_bytes.startswith(b'\xef\xbb\xbf'))
    check('Windows CI includes FIX81 regression',
          'run: python tests/run_fix81_local_dotnet_sdk_gate.py' in ci)
    check('Windows CI itself selects SDK 10',
          "dotnet-version: '10.0.x'" in ci and "-notmatch '^10\\.'" in ci)
    check('preflight helper exists', helper.is_file())

    # Linux/macOS use an executable shell stub. Windows has no POSIX shell,
    # so test the same real Python process via a mock of subprocess.run there.
    if os.name == 'nt':
        from unittest.mock import patch
        import importlib.util
        spec = importlib.util.spec_from_file_location('sdk_preflight', helper)
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        for version, exit_code, expected in (
            ('10.0.100', 0, 0), ('10.0.100-preview.7', 0, 0),
            ('9.0.306', 0, 1), ('11.0.100', 0, 1),
            ('10.0.100', 1, 1), ('', 0, 1), ('10.0.100\n9.0.300', 0, 1),
        ):
            fake = subprocess.CompletedProcess(['dotnet', '--version'], exit_code, version, '')
            with patch.object(module.subprocess, 'run', return_value=fake):
                check(f'selected SDK {version!r} exit={exit_code}', module.main() == expected)
    else:
        with tempfile.TemporaryDirectory(prefix='dse-fix81-sdk-') as temp:
            stub = Path(temp) / 'dotnet'
            env = dict(os.environ)
            env['PATH'] = temp + os.pathsep + env.get('PATH', '')
            for version, exit_code, expected in (
                ('10.0.100', 0, 0), ('10.0.100-preview.7', 0, 0),
                ('9.0.306', 0, 1), ('11.0.100', 0, 1),
                ('10.0.100', 1, 1), ('', 0, 1), ('10.0.100\n9.0.300', 0, 1),
                ('dotnet SDK 10.0.100', 0, 1),
            ):
                stub.write_text('#!/bin/sh\nprintf "%s\\n" "' +
                                version.replace('"', '\\"').replace('\n', '" "') +
                                '"\nexit ' + str(exit_code) + '\n', encoding='ascii')
                stub.chmod(0o755)
                result = subprocess.run([sys.executable, str(helper)], env=env,
                                        capture_output=True, text=True, timeout=15)
                check(f'actual preflight process SDK {version!r} exit={exit_code}',
                      result.returncode == expected)
            # A missing dotnet executable must also be rejected (PATH isolated).
            stub.unlink()
            result = subprocess.run([sys.executable, str(helper)], env=env,
                                    capture_output=True, text=True, timeout=15)
            check('actual preflight process missing dotnet fails closed', result.returncode == 1)

    print(f'SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0', flush=True)
    return 0 if all(checks) else 1


if __name__ == '__main__':
    raise SystemExit(main())
