#!/usr/bin/env python3
"""FIX61: fail closed on fatal VSTest diagnostics even after 60 listed tests.

All transcripts are synthetic. This is NOT a real .NET/xUnit execution.
"""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "tests/verify_xunit_discovery.py"
PREFIX = "DSEstimate.Core.Tests."
spec = importlib.util.spec_from_file_location("fix61_verify_discovery", TARGET)
assert spec and spec.loader
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
checks: list[bool] = []


def check(label: str, ok: bool) -> None:
    checks.append(bool(ok))
    print(("PASS " if ok else "FAIL ") + label, flush=True)


names = [f"    {PREFIX}Fix61.Case{i:03d}\n" for i in range(60)]
listing = "Test run for DSEstimate.Core.Tests.dll\nThe following Tests are available:\n" + "".join(names)
with tempfile.TemporaryDirectory(prefix="dse-fix61-") as directory:
    path = Path(directory) / "discovery.txt"

    def accepted(transcript: str) -> tuple[bool, str]:
        path.write_text(transcript, encoding="utf-8")
        try:
            count = module.verify_discovery(path, min_discovered=60, require_prefix=PREFIX)
            return True, str(count)
        except module.DiscoveryError as exc:
            return False, str(exc)

    ok, value = accepted(listing)
    check("60 valid identities still accepted", ok and value == "60")
    fatal_lines = [
        "Test Run Failed.",
        "Test run aborted.",
        "The test host process crashed unexpectedly.",
        "Testhost process exited with error 1.",
        "Unhandled exception: System.InvalidOperationException",
        "Fatal error: testhost terminated",
    ]
    for diagnostic in fatal_lines:
        ok, value = accepted(listing + diagnostic + "\n")
        check(f"fatal after 60 rejected: {diagnostic}", not ok and "Fatal VSTest" in value)
    for diagnostic in fatal_lines:
        ok, value = accepted(diagnostic + "\n" + listing)
        check(f"fatal before header rejected: {diagnostic}", not ok and "Fatal VSTest" in value)
    ok, value = accepted(listing + "Warning: Adapter loaded with reduced verbosity.\n")
    check("nonfatal warning after listing accepted", ok and value == "60")
    ok, value = accepted(listing + "    " + PREFIX + 'Fix61.Theory(value: "Test Run Failed.")\n')
    check("diagnostic text inside theory arguments not fatal", ok and value == "61")
    ok, value = accepted(listing.replace(names[-1], ""))
    check("59 discoveries still rejected", not ok and "59 < 60" in value)
    ok, value = accepted(listing + names[0])
    check("duplicate discovery still rejected", not ok and "Duplicate" in value)
    ok, value = accepted(listing + "    Other.Project.Tests.Class.Method\n")
    check("foreign namespace still rejected", not ok and "outside" in value)
    path.write_text(listing + "Test Run Failed.\n", encoding="utf-8")
    proc = subprocess.run([sys.executable, str(TARGET), str(path), "--min-discovered", "60",
                           "--require-prefix", PREFIX], capture_output=True, text=True, timeout=15)
    check("CLI propagates fatal diagnostic exit 1", proc.returncode == 1 and "Fatal VSTest" in proc.stderr)
    path.write_text(listing, encoding="utf-8")
    proc = subprocess.run([sys.executable, str(TARGET), str(path), "--min-discovered", "60",
                           "--require-prefix", PREFIX], capture_output=True, text=True, timeout=15)
    check("CLI accepts healthy listing exit 0", proc.returncode == 0 and "listed=60" in proc.stdout)

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
check("workflow uses strict discovery verifier", "--min-discovered 60 --require-prefix DSEstimate.Core.Tests." in workflow)
check("workflow runs FIX61 regression", "python tests/run_fix61_xunit_discovery_fatal_diagnostics_guard.py" in workflow)
for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"release gate includes FIX61: {gate}",
          "run_fix61_xunit_discovery_fatal_diagnostics_guard.py" in
          (ROOT / gate).read_text(encoding="utf-8-sig"))
print(f"SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0", flush=True)
raise SystemExit(0 if all(checks) else 1)
