#!/usr/bin/env python3
"""FIX50: strict TRX duplicate-result identity checks (synthetic XML only).

No .NET build, xUnit execution or real TRX is claimed by these tests.
"""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERIFY = ROOT / "tests/verify_dotnet_trx.py"
spec = importlib.util.spec_from_file_location("dse_verify_trx_fix50", VERIFY)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
checks: list[bool] = []


def check(label: str, ok: bool) -> None:
    checks.append(bool(ok))
    print(("PASS " if ok else "FAIL ") + label, flush=True)


def sample(*, duplicate: bool = False, varied_execution: bool = False,
           varied_name: bool = False, namespaced: bool = False) -> str:
    rows = []
    for i in range(60):
        test_id = "t0" if duplicate and i == 59 else f"t{i}"
        execution = f' executionId="e{i}"' if varied_execution else ""
        name = f' testName="case{i}"' if varied_name else ""
        rows.append(f'<UnitTestResult testId="{test_id}"{execution}{name} outcome="Passed" />')
    ns = ' xmlns="http://microsoft.com/schemas/VisualStudio/TeamTest/2010"' if namespaced else ""
    return (f'<TestRun{ns}><Results>' + "".join(rows) + '</Results>'
            '<ResultSummary outcome="Completed"><Counters total="60" '
            'executed="60" passed="60" failed="0" error="0" />'
            '</ResultSummary></TestRun>')


with tempfile.TemporaryDirectory(prefix="dse-fix50-") as tmp:
    path = Path(tmp) / "synthetic.trx"

    def accepted(strict: bool) -> bool:
        try:
            mod.verify_trx(path, require_results=True, min_executed=60,
                           reject_skipped=strict)
            return True
        except mod.TrxValidationError:
            return False

    for label, content, strict, expected in (
        ("baseline 60 distinct records accepted", sample(), True, True),
        ("namespaced TRX accepted", sample(namespaced=True), True, True),
        ("same testId and empty identity rejected", sample(duplicate=True), True, False),
        ("legacy behavior unchanged", sample(duplicate=True), False, True),
        ("same testId with different executionId accepted", sample(duplicate=True, varied_execution=True), True, True),
        ("same testId with different testName accepted", sample(duplicate=True, varied_name=True), True, True),
        ("different test IDs with same execution/name accepted", sample(), True, True),
    ):
        path.write_text(content, encoding="utf-8")
        check(label, accepted(strict) == expected)

    path.write_text(sample(duplicate=True), encoding="utf-8")
    cli = subprocess.run([sys.executable, str(VERIFY), str(path), "--require-results",
                          "--min-executed", "60", "--reject-skipped"],
                         capture_output=True, text=True, timeout=15)
    check("strict CLI rejects duplicate identity", cli.returncode == 1 and "Duplicate" in cli.stderr)
    path.write_text(sample(duplicate=True, varied_execution=True), encoding="utf-8")
    cli = subprocess.run([sys.executable, str(VERIFY), str(path), "--require-results",
                          "--min-executed", "60", "--reject-skipped"],
                         capture_output=True, text=True, timeout=15)
    check("strict CLI accepts distinct execution IDs", cli.returncode == 0 and "PASS" in cli.stdout)

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
check("CI runs strict TRX verifier", "--min-executed 60 --reject-skipped" in workflow)
for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{gate} includes FIX50", "run_fix50_trx_duplicate_identity_guard.py" in
          (ROOT / gate).read_text(encoding="utf-8-sig"))
check("no production C# touched by test", (ROOT / "src/DSEstimate.Core/CostEngine.cs").exists())

print(f"SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0", flush=True)
raise SystemExit(0 if all(checks) else 1)
