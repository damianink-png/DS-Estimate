#!/usr/bin/env python3
"""FIX60: validate project-scoped VSTest discovery; synthetic text, not xUnit."""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "tests/verify_xunit_discovery.py"
PREFIX = "DSEstimate.Core.Tests."
spec = importlib.util.spec_from_file_location("dse_fix60_discovery", TARGET)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
checks: list[bool] = []


def check(label: str, ok: bool) -> None:
    checks.append(bool(ok))
    print(("PASS " if ok else "FAIL ") + label, flush=True)


def transcript(names: list[str]) -> str:
    return ("Test run for DSEstimate.Core.Tests.dll (.NETCoreApp,Version=v10.0)\n"
            "The following Tests are available:\n" +
            "".join(f"    {name}\n" for name in names))


names = [f"{PREFIX}Fix60.Case{i:03d}" for i in range(60)]
with tempfile.TemporaryDirectory(prefix="dse-fix60-") as tmp:
    path = Path(tmp) / "discovery.txt"

    def verify(test_names: list[str], prefix: str | None = PREFIX, minimum: int = 60):
        path.write_text(transcript(test_names), encoding="utf-8")
        try:
            return True, mod.verify_discovery(path, min_discovered=minimum,
                                               require_prefix=prefix)
        except mod.DiscoveryError as exc:
            return False, str(exc)

    ok, value = verify(names)
    check("60 DS Estimate identities accepted", ok and value == 60)
    ok, value = verify(names + [f"{PREFIX}Fix60.Theory(value: 1)"])
    check("DS Estimate theory accepted", ok and value == 61)
    ok, value = verify(names[:59] + ["Microsoft.TestPlatform.ObjectModel"])
    check("qualified diagnostic cannot inflate 59 to 60", not ok and "outside" in value)
    ok, value = verify(names + ["Other.Project.Tests.Class.Method"])
    check("unrelated test cannot pass even after floor reached", not ok and "outside" in value)
    ok, value = verify(names[:59] + ["Other.Project.Tests.Class.Method"], prefix=None)
    check("legacy validator behavior preserved without prefix", ok and value == 60)
    ok, value = verify(names[:59])
    check("59 actual DS Estimate tests rejected", not ok and "59 < 60" in value)
    ok, value = verify(names + [names[0]])
    check("duplicate rejection retained", not ok and "Duplicate" in value)
    ok, value = verify(names[:59] + ["Warning: Runtime.Some.Type"])
    check("indented warning still ignored", not ok and "59 < 60" in value)
    ok, value = verify(names, prefix="")
    check("empty namespace requirement rejected", not ok and "require_prefix" in value)
    ok, value = verify(names, prefix="DSEstimate.Core.Tests")
    check("namespace missing trailing dot rejected", not ok and "require_prefix" in value)
    path.write_text(transcript(names), encoding="utf-8")
    proc = subprocess.run([sys.executable, str(TARGET), str(path), "--min-discovered", "60",
                           "--require-prefix", PREFIX], capture_output=True, text=True)
    check("CLI accepts scoped listing with exit 0", proc.returncode == 0 and "listed=60" in proc.stdout)
    path.write_text(transcript(names[:59] + ["Microsoft.TestPlatform.ObjectModel"]), encoding="utf-8")
    proc = subprocess.run([sys.executable, str(TARGET), str(path), "--min-discovered", "60",
                           "--require-prefix", PREFIX], capture_output=True, text=True)
    check("CLI rejects foreign identity with exit 1", proc.returncode == 1 and "outside" in proc.stderr)

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
check("workflow enables namespace scope", "--min-discovered 60 --require-prefix DSEstimate.Core.Tests." in workflow)
check("workflow invokes FIX60 regression", "python tests/run_fix60_xunit_namespace_scope_guard.py" in workflow)
for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{gate} includes FIX60", "run_fix60_xunit_namespace_scope_guard.py" in
          (ROOT / gate).read_text(encoding="utf-8-sig"))
ns = set()
for file in (ROOT / "tests/DSEstimate.Core.Tests").glob("*.cs"):
    for line in file.read_text(encoding="utf-8-sig").splitlines():
        if line.startswith("namespace "):
            ns.add(line.split()[1].rstrip(";"))
check("checked-in xUnit namespaces agree with scope", ns == {PREFIX.rstrip(".")})
print(f"SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0", flush=True)
raise SystemExit(0 if all(checks) else 1)
