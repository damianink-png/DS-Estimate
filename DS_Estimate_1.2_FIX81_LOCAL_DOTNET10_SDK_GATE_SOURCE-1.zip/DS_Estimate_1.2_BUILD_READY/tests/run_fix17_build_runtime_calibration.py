#!/usr/bin/env python3
from pathlib import Path
import ast
import hashlib
import re
import sys
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parents[1]
passed = failed = 0


def read(relative):
    return (ROOT / relative).read_text(encoding="utf-8-sig")


def check(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print("PASS ", name)
    else:
        failed += 1
        print("FAIL ", name, "::", detail)


build = read("BUILD_FULL_PORTABLE_ZIP.ps1")
runner = read("src/DSEstimate.Infrastructure/PythonRunner.cs")
history = read("src/DSEstimate.Infrastructure/HistoryImportService.cs")
domain = read("src/DSEstimate.Core/Domain.cs")
autoquote = read("src/DSEstimate.Core/AutoQuoteEngine.cs")
vm = read("src/DSEstimate.App/ViewModels/MainViewModel.cs")
ui = read("src/DSEstimate.App/Views/MainWindow.axaml")
diagnostic = read("src/DSEstimate.Infrastructure/DiagnosticReportService.cs")
crash = read("src/DSEstimate.Infrastructure/CrashDiagnosticService.cs")
release = read("RUN_FULL_RELEASE_TESTS.cmd")
xunit = read("tests/DSEstimate.Core.Tests/Fix17BuildRuntimeCalibrationTests.cs")


# Resumable, integrity-checked build cache. A cache hit may skip immutable
# assembly work, but never the release gate, runtime import or portable checks.
check("build cache can be explicitly disabled", "[switch]$NoBuildCache" in build)
check("build inputs are content addressed", "Get-InputTreeHash" in build and "Get-FileHash -Algorithm SHA256" in build)
check("directory cache has integrity manifest", "Write-DirectoryCacheManifest" in build and ".dse_cache_manifest.sha256" in build)
check("cache validates every stored file", "Test-DirectoryCache" in build and "$actual -ne $expected" in build)
check("dotnet publish cache exists", 'Add-CacheEvent ".NET publish"' in build and "$dotnetCacheHit" in build)
publish_at = build.find("& dotnet publish $Project")
publish_verify_at = build.find("Publikacja .NET nie zawiera DSEstimate.exe", publish_at)
dotnet_cache_write_at = build.find("Write-DirectoryCacheManifest $dotnetCacheDir", publish_at)
check("dotnet cache promoted only after output validation", publish_at >= 0 and publish_at < publish_verify_at < dotnet_cache_write_at)
check("python CAD runtime cache exists", 'Add-CacheEvent "Python/CAD runtime"' in build and "$pythonRuntimeCacheHit" in build)
import_smoke_at = build.find("DS_ESTIMATE_EMBEDDED_PYTHON_OK")
python_cache_write_at = build.find("Write-DirectoryCacheManifest $pythonRuntimeCacheDir", import_smoke_at)
check("python cache promoted only after import smoke", import_smoke_at >= 0 and python_cache_write_at > import_smoke_at)
check("OCR model download cache exists", "$OcrModelCache" in build and "[CACHE HIT] Model OCR" in build)
check("OCR cache is included in build report", 'Component = "OCR language models"' in build)
check("embedded runtime imports always tested", "DS_ESTIMATE_EMBEDDED_PYTHON_OK" in build and build.find("DS_ESTIMATE_EMBEDDED_PYTHON_OK") > build.find("$pythonRuntimeCacheHit"))
check("full release gate not conditional on cache hit", "if (-not $FastBuild -or $RunFullRegression)" in build and "if ($dotnetCacheHit)" in build)
check("portable gate executes .NET unit tests", "dotnet test $CoreTestsProject" in build and "Testy jednostkowe .NET nie przeszły" in build)
check("source gate executes .NET unit tests", "dotnet test tests\\DSEstimate.Core.Tests\\DSEstimate.Core.Tests.csproj" in release)
check("stress gate retained", 'DSE_STRESS_FULL' in build and 'run_r9_0_system_stress.py' in build)
check("portable completeness gate retained", "Test kompletności offline" in build and "CHECK_PORTABLE.cmd" in build)
check("technical build report json", "BUILD_REPORT_FIX17.json" in build and 'Schema = "ds-estimate-build-report-v1"' in build)
check("technical build report text", "BUILD_REPORT_FIX17.txt" in build and 'ETAPY' in build and 'CACHE' in build)
check("failure writes build report", build.find("Write-BuildReport", build.find("function Fail")) > build.find("function Fail"))
check("success writes build report", '$BuildOutcome = "PASS"' in build and build.rfind("Write-BuildReport") > build.find('$BuildOutcome = "PASS"'))


# Persistent STEP worker health: recycle only after a complete protocol response.
response_at = runner.find("var combinedStderr")
job_at = runner.find("_completedJobs++")
recycle_at = runner.find("await RecycleAsync")
check("worker counts completed jobs", 0 <= response_at < job_at < recycle_at)
check("worker job limit configurable", "DSE_STEP_WORKER_MAX_JOBS" in runner and "20" in runner)
check("worker memory limit configurable", "DSE_STEP_WORKER_MAX_PRIVATE_MB" in runner and "PrivateMemorySize64" in runner)
check("worker lifetime configurable", "DSE_STEP_WORKER_MAX_MINUTES" in runner and "MaxLifetimeMinutes" in runner)
check("worker graceful quit", 'WriteLineAsync("__quit__".AsMemory()' in runner and "WaitForExitAsync(quit.Token)" in runner)
check("worker forced kill fallback", "process.Kill(entireProcessTree: true)" in runner)
check("worker lifecycle log bounded", "step_worker_lifecycle.log" in runner and "1024 * 1024" in runner and ".previous" in runner)
check("crash package carries lifecycle tail", "step_worker_lifecycle.txt" in crash and "TakeLast(100)" in crash)


# Independent calibration holdout.
check("calibration validation model", "class CalibrationValidationReport" in history and "class CalibrationValidationMetric" in history)
check("stable deterministic split", "StableCalibrationOrder" in history and "SHA256.HashData" in history)
check("holdout never learns factors", "TrainingSuggestions" in history and "TrainingSourceKeys" in history)
check("validation compares baseline and proposal MAPE", "BaselineMapePercent" in history and "ProposedMapePercent" in history)
check("per-process regression threshold", "CalibrationValidationMaxRegressionPercentPoints" in history and "report.Metrics.All(x => x.Passed)" in history)
check("profile update has hard validation block", "validation.BlocksProfileUpdate" in history and "Applied = false" in history)
check("class profiles use training source", "foreach (var cls in profileSource" in history)
check("validation settings persisted", "CompanyProfileValidationStatus" in domain and "CompanyProfileValidationProjects" in domain)
check("validation visible in history UI", "Niezależna walidacja kalibracji" in ui and "CalibrationValidation.Summary" in ui)
check("blocked profile avoids recalculation", "if (profile.Applied && HasAnalysis)" in vm)
check("holdout behavior tests included", "Holdout_passes_when_training_factor_improves_unseen_projects" in xunit and "Holdout_blocks_profile_when_training_factor_regresses_unseen_projects" in xunit)


# Quote readiness remains compact and routes to existing expert details.
check("quote readiness domain", "class QuoteReadinessItem" in domain and "ReadinessItems" in domain)
check("readiness covers core areas", all(f'"{code}"' in history + domain + autoquote for code in ["MASS", "MATERIAL", "RATES", "CUT", "CNC", "WELD", "PAINT", "NDT", "BEND"]))
check("readiness main UI card", "Gotowość wyceny" in ui and "ReadinessItems" in ui)
check("readiness action command", "OpenReadinessItem" in vm and "OpenReadinessItemCommand" in ui)
check("readiness exported in diagnostic", "Gotowość wyceny" in diagnostic and "ReadinessItems" in diagnostic)
check("readiness behavior tests included", "Quote_readiness_exposes_blocking_mass_material_and_risks" in xunit)
check("unknown material cannot be marked ready", "materialNamed" in autoquote and "Quote_readiness_requires_review_when_material_cost_uses_unknown_grade" in xunit)


# A tiny executable mirror verifies the intended MAPE gate semantics: a useful
# factor passes, while a factor that makes holdout worse beyond tolerance blocks.
def mape(points, factor):
    return sum(abs(model * factor - actual) / actual * 100.0 for model, actual in points) / len(points)


holdout = [(10.0, 12.0), (20.0, 24.0), (8.0, 9.6)]
baseline = mape(holdout, 1.0)
check("MAPE useful calibration passes", mape(holdout, 1.2) <= baseline + 2.0)
check("MAPE harmful calibration blocks", not (mape(holdout, 0.7) <= baseline + 2.0))


for relative in [
    "src/DSEstimate.App/Views/MainWindow.axaml",
    "src/DSEstimate.App/App.axaml",
    "src/DSEstimate.App/DSEstimate.App.csproj",
]:
    try:
        ET.parse(ROOT / relative)
        check(f"XML parses: {relative}", True)
    except Exception as exc:
        check(f"XML parses: {relative}", False, str(exc))


def balanced_csharp(source):
    # Existing suite also performs a coarse brace guard. Ignore comments/strings
    # enough for this patch's structural smoke check.
    stripped = re.sub(r'@?"(?:""|\\.|[^"\\])*"', '""', source)
    stripped = re.sub(r"//.*", "", stripped)
    return stripped.count("{") == stripped.count("}")


for relative in [
    "src/DSEstimate.Infrastructure/PythonRunner.cs",
    "src/DSEstimate.Infrastructure/HistoryImportService.cs",
    "src/DSEstimate.Infrastructure/CrashDiagnosticService.cs",
    "src/DSEstimate.Core/Domain.cs",
    "src/DSEstimate.Core/AutoQuoteEngine.cs",
    "src/DSEstimate.App/ViewModels/MainViewModel.cs",
    "tests/DSEstimate.Core.Tests/Fix17BuildRuntimeCalibrationTests.cs",
]:
    check(f"C# braces balanced: {relative}", balanced_csharp(read(relative)))

check("FIX17 in source release gate", "run_fix17_build_runtime_calibration.py" in release)
check("FIX17 in portable build gate", "run_fix17_build_runtime_calibration.py" in build)

try:
    ast.parse(Path(__file__).read_text(encoding="utf-8-sig"))
    check("FIX17 test Python syntax", True)
except SyntaxError as exc:
    check("FIX17 test Python syntax", False, str(exc))

print(f"\nSUMMARY PASS={passed} FAIL={failed}")
sys.exit(1 if failed else 0)
