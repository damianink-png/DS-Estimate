"""FIX69: private pack must be byte-identical even when the build clock changes."""
import contextlib
import hashlib
import importlib.util
import io
import json
import sys
import tempfile
import zipfile
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / 'engines/python/build_private_analysis_pack.py'
spec = importlib.util.spec_from_file_location('ds_private_pack_fix69', ENGINE)
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
checks = 0


def check(label, ok):
    global checks
    if not ok:
        raise AssertionError(label)
    checks += 1
    print('PASS | ' + label, flush=True)


def generate(source, destination, year):
    # Simulate builds in different calendar years without sleeping or depending
    # on the machine's clock. The old zipfile.writestr(str, ...) path stores
    # time.localtime() in each entry and therefore produces different ZIPs.
    fake_clock = (year, 3, 17, 12, 34, 56, 0, 0, -1)
    with mock.patch.object(engine.zipfile.time, 'localtime', return_value=fake_clock), \
         mock.patch.object(sys, 'argv', [str(ENGINE), str(source), str(destination)]), \
         contextlib.redirect_stdout(io.StringIO()) as captured:
        engine.main()
    return json.loads(captured.getvalue())


with tempfile.TemporaryDirectory(prefix='dse_fix69_') as temp:
    base = Path(temp)
    source = base / 'source'
    source.mkdir()
    document = source / 'drawing_s355.txt'
    document.write_text('S355\nCNC 4 szt.\nISO 5817\n', encoding='utf-8')
    first, second, third = (base / n for n in ('2024.zip', '2026.zip', '2029.zip'))
    a = generate(source, first, 2024)
    b = generate(source, second, 2026)
    c = generate(source, third, 2029)
    check('first build succeeds', a['ok'] and a['files'] == 1)
    check('second build succeeds', b['ok'] and b['files'] == 1)
    check('third build succeeds', c['ok'] and c['files'] == 1)
    check('source byte counts agree', a['source_bytes'] == b['source_bytes'] == c['source_bytes'])
    check('ZIP bytes independent of wall-clock time', first.read_bytes() == second.read_bytes() == third.read_bytes())
    check('SHA256 independent of wall-clock time', len({hashlib.sha256(p.read_bytes()).hexdigest() for p in (first, second, third)}) == 1)
    expected_names = ['MANIFEST.json', 'TECHNICAL_SNIPPETS.json', 'README_PRIVACY.txt']
    for p in (first, second, third):
        with zipfile.ZipFile(p) as z:
            check(f'{p.stem}: CRC valid', z.testzip() is None)
            check(f'{p.stem}: expected private entries', z.namelist() == expected_names)
            check(f'{p.stem}: canonical timestamp for every entry', all(i.date_time == (1980, 1, 1, 0, 0, 0) for i in z.infolist()))
            check(f'{p.stem}: stable creator platform', all(i.create_system == 3 for i in z.infolist()))
            check(f'{p.stem}: no original document', 'drawing_s355.txt' not in z.namelist())
            manifest = json.loads(z.read('MANIFEST.json'))
            check(f'{p.stem}: manifest count', manifest['file_count'] == 1)
    # A legitimate document change must still change the private pack.
    document.write_text('S355\nCNC 5 szt.\nISO 5817\n', encoding='utf-8')
    changed = base / 'changed.zip'
    d = generate(source, changed, 2024)
    check('changed input still succeeds', d['ok'] and d['files'] == 1)
    check('changed input changes pack hash', hashlib.sha256(first.read_bytes()).digest() != hashlib.sha256(changed.read_bytes()).digest())
    check('changed ZIP CRC valid', zipfile.ZipFile(changed).testzip() is None)

print(f'FIX69: {checks}/{checks} PASS (runtime)')
