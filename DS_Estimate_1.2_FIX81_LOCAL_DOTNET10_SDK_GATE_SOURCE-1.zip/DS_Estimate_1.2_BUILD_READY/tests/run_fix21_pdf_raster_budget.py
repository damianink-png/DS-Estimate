#!/usr/bin/env python3
"""FIX21 regression: large technical PDF pages must respect OCR memory cap."""
from pathlib import Path
import importlib.util
import math
import sys

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(
    "dse_fix21_document", ROOT / "engines/python/analyze_document.py"
)
document = importlib.util.module_from_spec(spec)
spec.loader.exec_module(document)
passed = failed = skipped = 0


def check(label, ok, detail=""):
    global passed, failed
    if ok:
        passed += 1
        print("PASS ", label)
    else:
        failed += 1
        print("FAIL ", label, detail)


budget = 4_000_000
zoom = document.bounded_pdf_ocr_zoom(3000, 2000, 2.05, budget)
check("oversized drawing zoom below former hard minimum", 0 < zoom < 1.15, str(zoom))
check("oversized drawing projected pixels within cap", 3000 * 2000 * zoom * zoom <= budget, str(zoom))
check("A4 normal OCR quality preserved", document.bounded_pdf_ocr_zoom(595, 842, 2.55, 16_000_000) == 2.55)
check("higher pixel budget allows higher resolution", document.bounded_pdf_ocr_zoom(3000, 2000, 2.05, 16_000_000) > zoom)

try:
    import pymupdf as fitz
except ImportError:
    skipped += 1
    print("SKIP  real MuPDF raster cap (optional PyMuPDF unavailable)")
else:
    pdf = fitz.open()
    try:
        page = pdf.new_page(width=3000, height=2000)
        pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), colorspace=fitz.csRGB, alpha=False)
        check("actual MuPDF pixmap stays within 4 MP", pix.width * pix.height <= budget,
              f"{pix.width}x{pix.height}={pix.width * pix.height}")
        del pix
    finally:
        pdf.close()

check("OCR sample still includes first and last sheet", document.select_ocr_page_indices(100, 12)[::11] == [0, 99])
print(f"\nSUMMARY PASS={passed} FAIL={failed} SKIP={skipped}")
sys.exit(1 if failed else 0)
