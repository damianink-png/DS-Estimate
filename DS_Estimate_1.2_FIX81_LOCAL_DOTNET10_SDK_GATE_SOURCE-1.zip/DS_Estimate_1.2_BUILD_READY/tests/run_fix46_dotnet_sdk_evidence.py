#!/usr/bin/env python3
"""FIX46 static regression for .NET 10 SDK selection/evidence (not a .NET run)."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text(encoding='utf-8')
checks: list[tuple[str, bool]] = []


def check(label: str, result: bool) -> None:
    checks.append((label, bool(result)))
    print(('PASS ' if result else 'FAIL ') + label, flush=True)


step = '      - name: Verify .NET 10 SDK and capture environment\n'
check('unique .NET SDK preflight step', WORKFLOW.count(step) == 1)
if step in WORKFLOW:
    start = WORKFLOW.index(step)
    end = WORKFLOW.find('\n      - ', start + len(step))
    block = WORKFLOW[start:end if end >= 0 else len(WORKFLOW)]
else:
    block = ''

check('preflight explicitly uses PowerShell', 'shell: pwsh' in block)
check('SDK version read from dotnet itself', 'dotnet --version' in block)
check('selected SDK must be major version 10', "-notmatch '^10\\.'" in block)
check('SDK mismatch fails closed', 'throw "Expected .NET 10 SDK' in block)
check('dotnet --version failure propagates',
      block.index('if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }') > block.index('dotnet --version')
      if 'dotnet --version' in block and 'if ($LASTEXITCODE -ne 0)' in block else False)
check('environment output preserved', 'TestResults/dotnet-environment.log' in block)
check('dotnet --info captured', 'dotnet --info 2>&1 | Tee-Object' in block)
check('solution project list captured', 'dotnet sln DS_Estimate.sln list 2>&1 | Tee-Object' in block)
check('all three dotnet commands have exit-code checks',
      block.count('if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }') == 3)
check('SDK preflight precedes restore/build',
      WORKFLOW.find(step) >= 0 and WORKFLOW.find(step) < WORKFLOW.find('      - name: Restore .NET solution'))
check('workflow still pins setup-dotnet to 10.x',
      "dotnet-version: '10.0.x'" in WORKFLOW)
check('artifact upload includes SDK evidence',
      'TestResults/dotnet-environment.log' in WORKFLOW.split('      - name: Save test results', 1)[-1])
check('artifact upload unconditional',
      '      - name: Save test results\n        if: always()' in WORKFLOW)
check('xUnit TRX strict guard remains',
      '--require-results --min-executed 60' in WORKFLOW)
check('real PDF tests still required',
      '--require-real-pdf' in WORKFLOW and 'PyMuPDF==1.26.7' in WORKFLOW)
for gate in ('RUN_FULL_RELEASE_TESTS.cmd', 'BUILD_FULL_PORTABLE_ZIP.ps1'):
    check(f'{gate} includes FIX46',
          'run_fix46_dotnet_sdk_evidence.py' in (ROOT / gate).read_text(encoding='utf-8-sig'))

passed = sum(ok for _, ok in checks)
print(f'SUMMARY PASS={passed} FAIL={len(checks)-passed} SKIP=0', flush=True)
raise SystemExit(0 if passed == len(checks) else 1)
