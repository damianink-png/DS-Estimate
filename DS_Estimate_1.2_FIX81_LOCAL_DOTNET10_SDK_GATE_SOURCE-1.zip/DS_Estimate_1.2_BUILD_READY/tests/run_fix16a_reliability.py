from pathlib import Path
import ast
import sys

ROOT = Path(__file__).resolve().parents[1]

def text(rel):
    return (ROOT / rel).read_text(encoding="utf-8-sig")

def check(name, condition):
    global passed, failed
    if condition:
        passed += 1
        print("PASS ", name)
    else:
        failed += 1
        print("FAIL ", name)

passed = failed = 0
decision = text("src/DSEstimate.Core/DecisionSupportEngine.cs")
trust = text("src/DSEstimate.Core/TrustFoundation.cs")
repo = text("src/DSEstimate.Infrastructure/CalibrationRepository.cs")
report = text("src/DSEstimate.Infrastructure/DiagnosticReportService.cs")
docpy = text("engines/python/analyze_document.py")
release = text("RUN_FULL_RELEASE_TESTS.cmd")
build = text("BUILD_FULL_PORTABLE_ZIP.ps1")
xunit = text("tests/DSEstimate.Core.Tests/Fix16AReliabilityTests.cs")

check("calibration factor maps are null-safe", "NormalizeFactors" in trust and "factors is null" in trust)
check("calibration keys are case-insensitive", "StringComparer.OrdinalIgnoreCase" in trust and "pair.Key?.Trim()" in trust)
check("repository normalizes deserialized dictionaries", "return Normalize(loaded)" in repo and "profile.ProcessMultipliers = Copy" in repo)
check("unsupported valid profile is preserved for visible rejection", "if (loaded is not null) return Normalize(loaded)" in repo)
check("material calibration is cost-weighted", "costWeight" in trust and "MaterialPriceOverridesPlnKg" in trust)
check("what-if rejects non-finite inputs", "double.IsFinite" in decision and "FiniteClamp" in decision)
check("what-if uses signed markup", "1.0 + markupPercent / 100.0" in decision)
check("what-if sanitizes cost deltas", "safeDeltaCost" in decision)
check("generic German Kanten signal removed from core", '"KANTEN"' not in decision)
check("generic German Kanten regex removed from parser", r"\bKANT(?:EN|UNG)" not in docpy)
check("precise German bending signals retained", "ABKANT" in docpy and "BIEG" in docpy)
check("diagnostic hash includes tabular parser", '"analyze_tabular.py"' in report)
check("diagnostic identifies FIX16A", "FIX16A RELIABILITY HARDENING" in report)
check("behavior tests cover FIX16A", "cost_weighted" in xunit and "German_edge_note" in xunit)
check("FIX16A wired into release gate", "run_fix16a_reliability.py" in release)
check("FIX16A wired into portable build gate", "run_fix16a_reliability.py" in build)

try:
    ast.parse(docpy)
    check("document analyzer parses", True)
except SyntaxError as ex:
    check(f"document analyzer parses: {ex}", False)

for name, source in [("decision", decision), ("trust", trust), ("repo", repo), ("report", report), ("xunit", xunit)]:
    check(f"{name} braces balanced", source.count("{") == source.count("}"))

print(f"\nSUMMARY PASS={passed} FAIL={failed}")
sys.exit(1 if failed else 0)
