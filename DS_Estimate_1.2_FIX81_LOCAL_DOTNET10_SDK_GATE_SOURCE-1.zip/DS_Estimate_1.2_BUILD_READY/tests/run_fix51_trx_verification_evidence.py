#!/usr/bin/env python3
"""FIX51: strict TRX verdict logging in private Windows CI (synthetic TRX).

Does NOT build .NET, run xUnit or produce an actual CI artifact.
"""
from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text(encoding='utf-8')
VERIFY = ROOT / 'tests/verify_dotnet_trx.py'
checks: list[bool] = []


def check(label: str, condition: bool) -> None:
    checks.append(bool(condition))
    print(('PASS ' if condition else 'FAIL ') + label, flush=True)


def step(name: str) -> str:
    marker = f'      - name: {name}\n'
    check(f'unique CI step: {name}', WORKFLOW.count(marker) == 1)
    if WORKFLOW.count(marker) != 1:
        return ''
    start = WORKFLOW.index(marker)
    end = WORKFLOW.find('\n      - ', start + len(marker))
    return WORKFLOW[start:end if end >= 0 else len(WORKFLOW)]


verify = step('Verify xUnit TRX contains executed tests')
upload = step('Save test results')
command = ('python tests/verify_dotnet_trx.py TestResults/ds-estimate-xunit.trx '
           '--require-results --min-executed 60 --reject-skipped')
check('strict verifier command and flags unchanged', command in verify)
check('Windows PowerShell used for logging', 'shell: pwsh' in verify)
check('stdout/stderr streamed to CI log',
      '2>&1 | Tee-Object -FilePath TestResults/trx-verification.log' in verify)
check('native verifier failure is propagated',
      'if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }' in verify)
check('evidence directory created before verifier runs',
      verify.index('New-Item -ItemType Directory') < verify.index(command))
check('TRX verdict included in always-uploaded artifacts',
      'if: always()' in upload and 'TestResults/trx-verification.log' in upload)
check('artifact upload excludes source and CI fixture',
      'src/' not in upload and 'engines/python/' not in upload and 'launcher-smoke' not in upload)
check('xUnit execution and strict verification precede upload',
      WORKFLOW.index('      - name: Run C# xUnit tests') <
      WORKFLOW.index('      - name: Verify xUnit TRX contains executed tests') <
      WORKFLOW.index('      - name: Save test results'))


def sample(passed: int) -> str:
    records = ''.join(f'<UnitTestResult testId="id{i}" outcome="Passed" />'
                      for i in range(passed))
    return ('<TestRun><Results>' + records + '</Results>'
            '<ResultSummary outcome="Completed"><Counters '
            f'total="{passed}" executed="{passed}" passed="{passed}" '
            'failed="0" error="0" /></ResultSummary></TestRun>')


with tempfile.TemporaryDirectory(prefix='dse-fix51-') as directory:
    path = Path(directory) / 'synthetic.trx'
    for label, content, expected_code, expected_text in (
        ('strict synthetic 60/60 PASS verdict', sample(60), 0, 'PASS xUnit TRX verification'),
        ('strict synthetic 59/59 FAIL verdict', sample(59), 1, 'Too few discovered/executed'),
        ('missing TRX FAIL verdict', None, 1, 'TRX does not exist'),
    ):
        if content is None:
            path.unlink(missing_ok=True)
        else:
            path.write_text(content, encoding='utf-8')
        result = subprocess.run([sys.executable, str(VERIFY), str(path), '--require-results',
                                 '--min-executed', '60', '--reject-skipped'],
                                capture_output=True, text=True, timeout=15)
        check(label, result.returncode == expected_code and
              expected_text in result.stdout + result.stderr)

for gate in ('RUN_FULL_RELEASE_TESTS.cmd', 'BUILD_FULL_PORTABLE_ZIP.ps1'):
    check(f'{gate} includes FIX51 regression',
          'run_fix51_trx_verification_evidence.py' in
          (ROOT / gate).read_text(encoding='utf-8-sig'))

print(f'SUMMARY PASS={sum(checks)} FAIL={len(checks) - sum(checks)} SKIP=0', flush=True)
raise SystemExit(0 if all(checks) else 1)
