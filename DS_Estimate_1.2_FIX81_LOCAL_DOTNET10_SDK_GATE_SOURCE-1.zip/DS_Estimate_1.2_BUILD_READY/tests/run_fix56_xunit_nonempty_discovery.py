#!/usr/bin/env python3
"""FIX56 synthetic discovery transcript checks (NOT .NET/xUnit execution)."""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "tests/verify_xunit_discovery.py"
spec = importlib.util.spec_from_file_location("dse_fix56", TARGET)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
checks: list[bool] = []


def check(label: str, condition: bool) -> None:
    checks.append(bool(condition))
    print(("PASS " if condition else "FAIL ") + label, flush=True)


with tempfile.TemporaryDirectory(prefix="dse-fix56-") as directory:
    file = Path(directory) / "discovery.txt"
    good = ("Test run for DSEstimate.Core.Tests.dll (.NETCoreApp,Version=v10.0)\n"
            "The following Tests are available:\n"
            "    DSEstimate.Core.Tests.FirstTests.Passes\n"
            "    DSEstimate.Core.Tests.SecondTests.Accepts(value: 2)\n")

    def accepts(content: str, minimum: int = 1) -> bool:
        file.write_text(content, encoding="utf-8")
        try:
            mod.verify_discovery(file, min_discovered=minimum)
        except mod.DiscoveryError:
            return False
        return True

    check("valid two-case VSTest listing accepted", accepts(good, 2))
    check("minimum 3 rejects two cases", not accepts(good, 3))
    check("minimum 0 rejected", not accepts(good, 0))
    check("empty transcript rejected", not accepts(""))
    check("empty listing rejected", not accepts("The following Tests are available:\n"))
    check("VSTest no-tests diagnostic rejected", not accepts(good + "No test is available\n"))
    check("missing discovery header rejected", not accepts("    DSEstimate.Core.Tests.A.Passes\n"))
    check("duplicate discovery headers rejected", not accepts(good + "The following Tests are available:\n"))
    check("unindented build diagnostics not counted", not accepts("The following Tests are available:\nBuild succeeded.\n  DSEstimate.Core.Tests.A.Passes\n"))
    check("UTF-8 BOM accepted", accepts("\ufeff" + good))
    check("ANSI colored listing accepted", accepts("\x1b[32m" + good.replace("The following Tests are available:", "\x1b[0mThe following Tests are available:")))
    # Use the actual CLI to verify exit codes (not just exception behavior).
    file.write_text(good, encoding="utf-8")
    proc = subprocess.run([sys.executable, str(TARGET), str(file), "--min-discovered", "2"],
                          capture_output=True, text=True)
    check("CLI passes with exit 0", proc.returncode == 0 and "listed=2" in proc.stdout)
    proc = subprocess.run([sys.executable, str(TARGET), str(file), "--min-discovered", "3"],
                          capture_output=True, text=True)
    check("CLI rejects insufficient listing with exit 1", proc.returncode == 1 and "FAIL" in proc.stderr)
    file.unlink()
    proc = subprocess.run([sys.executable, str(TARGET), str(file)], capture_output=True, text=True)
    check("CLI rejects missing transcript", proc.returncode == 1)

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
check("CI checks captured real discovery before xUnit execution",
      workflow.index("python tests/verify_xunit_discovery.py TestResults/xunit-discovery.txt") <
      workflow.index("- name: Run C# xUnit tests"))
check("CI retains strict real TRX execution gate",
      "--min-executed 60 --reject-skipped" in workflow)
for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{gate} includes FIX56", "run_fix56_xunit_nonempty_discovery.py" in
          (ROOT / gate).read_text(encoding="utf-8-sig"))
print(f"SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0", flush=True)
raise SystemExit(0 if all(checks) else 1)
