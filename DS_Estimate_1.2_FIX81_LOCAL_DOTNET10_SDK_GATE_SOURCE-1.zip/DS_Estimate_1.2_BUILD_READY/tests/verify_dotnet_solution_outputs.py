#!/usr/bin/env python3
"""Fail-closed evidence of compiled .NET solution outputs in private Windows CI.

Checks exact Release/net10.0 managed PE files, including the CLR
metadata directory and BSJB signature. Private CI also validates metadata
stream headers and bounds, not source code compilation itself. The actual `dotnet build` exit code is independently required by CI.
Only paths, sizes and SHA-256 hashes are recorded; no DLLs are uploaded.
"""
from __future__ import annotations

import argparse
import hashlib
import struct
import sys
from pathlib import Path

OUTPUTS = (
    ("Core", "src/DSEstimate.Core/bin/Release/net10.0/DSEstimate.Core.dll"),
    ("Infrastructure", "src/DSEstimate.Infrastructure/bin/Release/net10.0/DSEstimate.Infrastructure.dll"),
    ("Avalonia app", "src/DSEstimate.App/bin/Release/net10.0/DSEstimate.dll"),
    ("xUnit tests", "tests/DSEstimate.Core.Tests/bin/Release/net10.0/DSEstimate.Core.Tests.dll"),
)


class SolutionOutputError(ValueError):
    pass


def _file_offset_for_rva(data: bytes, section_table: int, count: int,
                         rva: int, length: int) -> int:
    """Resolve a CLR RVA through the PE section table; reject unmapped bytes."""
    if rva == 0 or length <= 0:
        raise SolutionOutputError("empty CLR RVA or length")
    for index in range(count):
        pos = section_table + index * 40
        virtual_size, virtual_address, raw_size, raw_offset = struct.unpack_from(
            "<IIII", data, pos + 8
        )
        delta = rva - virtual_address
        if 0 <= delta < max(virtual_size, raw_size):
            if delta + length > raw_size or raw_offset + delta + length > len(data):
                raise SolutionOutputError("CLR RVA points beyond section file data")
            return raw_offset + delta
    raise SolutionOutputError("CLR RVA is not mapped by any PE section")



def _verify_metadata_streams(data: bytes, start: int, size: int) -> None:
    """Check the ECMA-335 metadata root and stream directory (not assembly execution).

    The legacy BSJB-only check remains available to old synthetic-fixture tests.
    CI enables this stronger check explicitly; it rejects a fabricated BSJB marker
    without a structurally plausible metadata stream table.
    """
    end = start + size
    if size < 32 or end > len(data):
        raise SolutionOutputError("CLR metadata root is truncated")
    major, minor, reserved, version_length = struct.unpack_from("<HHII", data, start + 4)
    if major < 1 or major > 2 or minor > 2 or reserved != 0:
        raise SolutionOutputError("invalid CLR metadata root version")
    if not 4 <= version_length <= 128 or version_length % 4:
        raise SolutionOutputError("invalid CLR metadata version length")
    pos = start + 16
    if pos + version_length + 4 > end:
        raise SolutionOutputError("CLR metadata version extends beyond root")
    version = data[pos:pos + version_length].split(b"\0", 1)[0]
    if not version.startswith(b"v") or not all(32 <= byte < 127 for byte in version):
        raise SolutionOutputError("invalid CLR metadata version string")
    pos += version_length
    flags, stream_count = struct.unpack_from("<HH", data, pos)
    if flags != 0 or not 3 <= stream_count <= 32:
        raise SolutionOutputError("invalid CLR metadata stream count or flags")
    pos += 4
    streams: dict[str, tuple[int, int]] = {}
    for _ in range(stream_count):
        if pos + 9 > end:
            raise SolutionOutputError("truncated CLR metadata stream header")
        offset, length = struct.unpack_from("<II", data, pos)
        name_start = pos + 8
        name_end = data.find(b"\0", name_start, min(name_start + 32, end))
        if name_end < 0:
            raise SolutionOutputError("unterminated CLR metadata stream name")
        try:
            name = data[name_start:name_end].decode("ascii")
        except UnicodeDecodeError as exc:
            raise SolutionOutputError("non-ASCII CLR metadata stream name") from exc
        if not name.startswith("#") or name in streams:
            raise SolutionOutputError("invalid or duplicate CLR metadata stream name")
        padded_name_size = (name_end - name_start + 4) & ~3
        pos = name_start + padded_name_size
        if pos > end or length == 0 or offset > size or length > size - offset:
            raise SolutionOutputError("CLR metadata stream extends beyond root")
        streams[name] = (offset, length)
    if not ({"#Strings", "#Blob"} <= streams.keys() and
            ("#~" in streams or "#-" in streams)):
        raise SolutionOutputError("required CLR metadata streams are missing")
    if streams.get("#~", streams.get("#-"))[1] < 24:
        raise SolutionOutputError("CLR metadata tables stream is too small")
    header_size = pos - start
    # A plausible stream directory must describe disjoint byte ranges.  The
    # old bounds check accepted two streams claiming the same bytes, which
    # cannot be a valid ECMA-335 metadata layout.  Adjacent ranges are fine.
    ranges = []
    for name, (offset, length) in streams.items():
        if offset < header_size:
            raise SolutionOutputError("CLR metadata stream overlaps root headers")
        ranges.append((offset, offset + length, name))
    ranges.sort()
    for previous, current in zip(ranges, ranges[1:]):
        if current[0] < previous[1]:
            raise SolutionOutputError(
                f"CLR metadata streams overlap: {previous[2]} and {current[2]}"
            )


def inspect_output(path: Path, *, require_metadata_streams: bool = False) -> tuple[int, str]:
    if not path.is_file() or path.is_symlink():
        raise SolutionOutputError(f"missing/non-regular output: {path}")
    data = path.read_bytes()
    if len(data) < 1024 or data[:2] != b"MZ":
        raise SolutionOutputError(f"missing MZ header or implausibly small output: {path}")
    pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
    if pe_offset < 0x40 or pe_offset + 24 > len(data):
        raise SolutionOutputError(f"invalid PE header offset: {path}")
    if data[pe_offset:pe_offset + 4] != b"PE\x00\x00":
        raise SolutionOutputError(f"missing PE signature: {path}")

    sections = struct.unpack_from("<H", data, pe_offset + 6)[0]
    optional_size = struct.unpack_from("<H", data, pe_offset + 20)[0]
    optional = pe_offset + 24
    section_table = optional + optional_size
    if not 1 <= sections <= 96 or section_table + 40 * sections > len(data):
        raise SolutionOutputError(f"invalid PE section table: {path}")
    if optional_size < 2:
        raise SolutionOutputError(f"missing PE optional header: {path}")
    magic = struct.unpack_from("<H", data, optional)[0]
    if magic == 0x10B:  # PE32: common for .NET AnyCPU assemblies
        directory_offset, count_offset = 96, 92
    elif magic == 0x20B:  # PE32+: 64-bit managed assemblies
        directory_offset, count_offset = 112, 108
    else:
        raise SolutionOutputError(f"invalid PE optional header: {path}")
    cli_directory = directory_offset + 14 * 8  # IMAGE_DIRECTORY_ENTRY_COM_DESCRIPTOR
    if optional_size < cli_directory + 8:
        raise SolutionOutputError(f"missing CLR data directory: {path}")
    directory_count = struct.unpack_from("<I", data, optional + count_offset)[0]
    if directory_count <= 14:
        raise SolutionOutputError(f"CLR directory not declared: {path}")
    cli_rva, cli_size = struct.unpack_from("<II", data, optional + cli_directory)
    if cli_size < 0x48:
        raise SolutionOutputError(f"missing/short CLR header: {path}")
    cli = _file_offset_for_rva(data, section_table, sections, cli_rva, 0x48)
    cb = struct.unpack_from("<I", data, cli)[0]
    if cb < 0x48 or cb > cli_size:
        raise SolutionOutputError(f"invalid CLR header size: {path}")
    metadata_rva, metadata_size = struct.unpack_from("<II", data, cli + 8)
    if metadata_size < 16:
        raise SolutionOutputError(f"missing CLR metadata: {path}")
    metadata = _file_offset_for_rva(data, section_table, sections, metadata_rva, 16)
    if data[metadata:metadata + 4] != b"BSJB":
        raise SolutionOutputError(f"missing .NET CLR metadata signature: {path}")
    if require_metadata_streams:
        metadata = _file_offset_for_rva(data, section_table, sections, metadata_rva, metadata_size)
        _verify_metadata_streams(data, metadata, metadata_size)
    return len(data), hashlib.sha256(data).hexdigest()


def verify_outputs(root: Path, *, require_metadata_streams: bool = False) -> list[str]:
    evidence = ["PASS .NET 10 Release solution output evidence (not runtime execution)"]
    for label, relative in OUTPUTS:
        size, digest = inspect_output(root / relative, require_metadata_streams=require_metadata_streams)
        evidence.append(f"{label}: {relative} bytes={size} sha256={digest}")
    return evidence


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("."))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--require-metadata-streams", action="store_true",
                        help="Fail closed if managed DLL metadata lacks valid stream headers")
    args = parser.parse_args(argv)
    try:
        lines = verify_outputs(args.root, require_metadata_streams=args.require_metadata_streams)
        status = 0
    except (OSError, SolutionOutputError) as exc:
        lines = [f"FAIL .NET 10 Release solution output evidence: {exc}"]
        status = 1
    report = "\n".join(lines) + "\n"
    print(report, end="", file=sys.stderr if status else sys.stdout)
    try:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(report, encoding="utf-8")
    except OSError as exc:
        print(f"FAIL writing solution output evidence: {exc}", file=sys.stderr)
        return 1
    return status


if __name__ == "__main__":
    raise SystemExit(main())
