from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
svc = (ROOT / 'src/DSEstimate.Infrastructure/ProjectAnalysisService.cs').read_text(encoding='utf-8-sig')
doc = (ROOT / 'src/DSEstimate.Infrastructure/DocumentAnalyzers.cs').read_text(encoding='utf-8-sig')
ps = (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig')

passed = failed = 0

def check(name, ok, detail=''):
    global passed, failed
    if ok:
        passed += 1
        print('PASS', name, detail)
    else:
        failed += 1
        print('FAIL', name, '::', detail)

check('adaptive boosted document cap exists', 'PdfDocumentsBoosted' in svc and 'initialDocumentWorkers' in svc)
check('no STEP starts document pool boosted', 'hasStepDocuments ? profile.PdfDocuments : profile.PdfDocumentsBoosted' in svc)
check('STEP completion releases document permits', 'STEP zakończony' in svc and 'pdfGate.Release(extra)' in svc)
check('OCR workers adapt after STEP', 'OcrWorkersBoosted' in svc and 'Volatile.Read(ref stepHeavyPhase)' in svc)
check('family pairing ignores export slot 1-4', 'DocumentFamilyKey' in svc and '[1-4]$' in svc)
check('DXF rich source can suppress raster OCR', 'Raster redundantny · użyto sparowanego DXF' in svc)
check('PDF rich source can suppress raster OCR', 'Raster redundantny · użyto sparowanego PDF' in svc)
check('raster remains fallback when rich source unavailable', 'OCR obrazu (fallback hierarchii źródeł)' in svc)
check('PDF still parses with DXF while OCR may be skipped', 'doc.Kind == DocumentKind.Pdf && pairedDxf is not null && IsRichTechnicalDxf' in svc)
check('PDF tasks registered before images', svc.find('RegisterPairTask(pdfTasks, doc.Name, task)') < svc.find('x.Kind == DocumentKind.Image'))
check('large STEP uses progress watchdog and high hard limit', 'DSE_PROGRESS_IDLE_WATCHDOG_SECONDS' in doc and 'largeStepTimeoutSeconds = fileSize >= 24L * 1024 * 1024 ? 1800 : 300' in doc)
check('large STEP still avoids second CORE restart', 'if (!checkpointRecommended)' in doc and 'nie uruchamiano ponownego importu/CORE' in doc)
check('adaptive diagnostics emitted', 'Adaptive Analysis Engine' in svc and 'Source Hierarchy' in svc and 'DOC×' in svc and 'OCR×' in svc)
check('new suite wired into build gate', 'run_r9_2_3d_adaptive_scheduler_source_hierarchy.py' in ps)

# Basic brace sanity on the main touched orchestration file.
text=(ROOT/'src/DSEstimate.Infrastructure/ProjectAnalysisService.cs').read_text(encoding='utf-8-sig')
check('brace balance ProjectAnalysisService.cs', text.count('{') == text.count('}'), f"{text.count('{')}/{text.count('}')}")

print(f'\nSUMMARY PASS={passed} FAIL={failed}')
raise SystemExit(1 if failed else 0)
