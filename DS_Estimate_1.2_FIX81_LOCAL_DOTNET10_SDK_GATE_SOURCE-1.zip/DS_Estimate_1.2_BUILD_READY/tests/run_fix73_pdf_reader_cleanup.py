#!/usr/bin/env python3
"""FIX73: PDF extraction releases its file handle on success and failure.

Exercises the actual private-pack engine with an instrumented PdfReader and
an actual two-page PDF. A non-zero exit is failure; no optional PDF skips.
"""
import importlib.util
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from unittest.mock import patch

import pypdf
import pymupdf

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / 'engines/python/build_private_analysis_pack.py'
spec = importlib.util.spec_from_file_location('dse_private_pack_fix73', ENGINE)
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
checks = 0


def check(label, condition):
    global checks
    if not condition:
        print('FAIL | ' + label, flush=True)
        raise AssertionError(label)
    checks += 1
    print('PASS | ' + label, flush=True)


class InstrumentedPage:
    def __init__(self, stream, text, fail=False):
        self.stream, self.text, self.fail = stream, text, fail

    def extract_text(self):
        check('PDF stream open during lazy page extraction', not self.stream.closed)
        if self.fail:
            raise RuntimeError('SECRET_CUSTOMER_PDF_PATH')
        return self.text


class InstrumentedReader:
    streams = []
    fail = False

    def __init__(self, source):
        # Path-string PdfReader can own an implicit handle until GC; explicitly
        # opening the PDF is needed to guarantee prompt close on Windows.
        check('PdfReader receives a readable stream', hasattr(source, 'read'))
        check('PDF stream open at reader construction', not source.closed)
        self.streams.append(source)
        self.pages = [InstrumentedPage(source, 'S355 CNC', self.fail)]


with tempfile.TemporaryDirectory(prefix='dse_fix73_') as folder:
    base = Path(folder)
    source = base / 'source'
    source.mkdir()
    document = source / 'drawing.pdf'
    document.write_bytes(b'fake bytes for injected reader')

    with patch.object(pypdf, 'PdfReader', InstrumentedReader):
        extracted = engine.read_text(document)
    check('instrumented PDF extracts technical text', extracted == 'S355 CNC')
    check('PDF stream closed on success', len(InstrumentedReader.streams) == 1 and InstrumentedReader.streams[-1].closed)

    InstrumentedReader.fail = True
    with patch.object(pypdf, 'PdfReader', InstrumentedReader):
        failure = engine.read_text(document)
    check('reader exception is safely classified', failure == 'EXTRACT_ERROR: RuntimeError')
    check('reader exception does not leak private message', 'SECRET_CUSTOMER' not in failure)
    check('PDF stream closed after page exception', len(InstrumentedReader.streams) == 2 and InstrumentedReader.streams[-1].closed)

    InstrumentedReader.fail = False
    pdf = pymupdf.open()
    for text in ('Material S355 CNC', 'Welding S690QL'):
        page = pdf.new_page(width=595, height=842)
        page.insert_text((50, 80), text)
    pdf.save(document)
    pdf.close()
    actual = engine.read_text(document)
    check('real two-page PDF extracts first page', 'Material S355 CNC' in actual)
    check('real two-page PDF extracts second page', 'Welding S690QL' in actual)

    output = base / 'private.zip'
    process = subprocess.run([sys.executable, str(ENGINE), str(source), str(output)],
                             capture_output=True, text=True, timeout=40)
    check('real PDF private-pack subprocess exit 0', process.returncode == 0)
    check('real PDF pack reports success', json.loads(process.stdout)['ok'] is True)
    with zipfile.ZipFile(output) as archive:
        check('real PDF pack CRC valid', archive.testzip() is None)
        manifest = json.loads(archive.read('MANIFEST.json'))
        snippets = json.loads(archive.read('TECHNICAL_SNIPPETS.json'))
        check('real PDF is counted once', manifest['file_count'] == 1 and manifest['files'][0]['extension'] == '.pdf')
        check('real PDF technical snippets retained', 'S355' in str(snippets) and 'S690QL' in str(snippets))
        check('original PDF not embedded', 'drawing.pdf' not in archive.namelist())

cmd = (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text('utf-8-sig')
ps1 = (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text('utf-8-sig')
workflow = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text('utf-8')
name = 'run_fix73_pdf_reader_cleanup.py'
check('CMD release gate includes FIX73', ('%PY% tests\\' + name + ' || exit /b 1') in cmd)
check('PowerShell release gate includes FIX73', ('"tests\\' + name + '",') in ps1)
check('private Windows CI includes FIX73', ('run: python tests/' + name) in workflow)
check('private Windows CI installs pypdf', '"pypdf==5.9.0"' in workflow)
check('private Windows CI installs openpyxl', '"openpyxl==3.1.5"' in workflow)
print(f'FIX73: {checks}/{checks} PASS; FAIL=0 SKIP=0 TIMEOUT=0', flush=True)
