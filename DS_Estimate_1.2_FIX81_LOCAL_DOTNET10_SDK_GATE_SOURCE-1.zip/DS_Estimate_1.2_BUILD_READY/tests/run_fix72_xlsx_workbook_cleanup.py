#!/usr/bin/env python3
"""FIX72: verify real XLSX extraction closes read-only workbook handles.

Runs the real engine and a real workbook, plus controlled worksheet exceptions.
No .NET/Windows runtime is claimed by this Python test.
"""
import importlib.util
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from unittest.mock import patch

import openpyxl

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / 'engines/python/build_private_analysis_pack.py'
spec = importlib.util.spec_from_file_location('dse_private_pack_fix72', ENGINE)
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
checks = 0


def check(label, condition):
    global checks
    if not condition:
        print('FAIL | ' + label, flush=True)
        raise AssertionError(label)
    checks += 1
    print('PASS | ' + label, flush=True)


class FakeSheet:
    def __init__(self, fail=False):
        self.fail = fail

    def iter_rows(self, values_only=False):
        check('engine requests values_only rows', values_only is True)
        yield ('S355', 'CNC')
        if self.fail:
            raise RuntimeError('CUSTOMER_SECRET_DO_NOT_EXPORT')
        yield ('S690QL', 12)


class FakeWorkbook:
    def __init__(self, fail=False, close_fail=False):
        self.worksheets = [FakeSheet(fail)]
        self.closed = 0
        self.close_fail = close_fail

    def close(self):
        self.closed += 1
        if self.close_fail:
            raise OSError('PRIVATE_CLIENT_PATH_DO_NOT_EXPORT')


with tempfile.TemporaryDirectory(prefix='dse_fix72_') as folder:
    root = Path(folder)
    for ext in ('.xlsx', '.xlsm'):
        doc = root / ('mock' + ext)
        doc.write_bytes(b'not used: mocked workbook')
        wb = FakeWorkbook()
        with patch.object(openpyxl, 'load_workbook', return_value=wb) as load:
            text = engine.read_text(doc)
        check(ext + ' reads technical content', 'S355 | CNC' in text and 'S690QL | 12' in text)
        check(ext + ' closes workbook on success', wb.closed == 1)
        check(ext + ' uses read_only mode', load.call_args.kwargs == {'read_only': True, 'data_only': True})

        wb = FakeWorkbook(fail=True)
        with patch.object(openpyxl, 'load_workbook', return_value=wb):
            text = engine.read_text(doc)
        check(ext + ' closes workbook on worksheet error', wb.closed == 1)
        check(ext + ' does not leak exception text', text == 'EXTRACT_ERROR: RuntimeError')

    wb = FakeWorkbook(close_fail=True)
    with patch.object(openpyxl, 'load_workbook', return_value=wb):
        text = engine.read_text(root / 'mock.xlsx')
    check('workbook close attempted exactly once', wb.closed == 1)
    check('close exception remains private', text == 'EXTRACT_ERROR: OSError')

    source = root / 'source'
    source.mkdir()
    book = openpyxl.Workbook()
    sheet = book.active
    sheet.append(['Material', 'CNC', 'Ilość'])
    sheet.append(['S355', 'Frezowanie', 3])
    sheet.append(['S690QL', 'Welding', 2])
    actual = source / 'part.xlsx'
    book.save(actual)
    book.close()
    extracted = engine.read_text(actual)
    check('real XLSX extracted', 'S355 | Frezowanie | 3' in extracted)
    check('real XLSX second row extracted', 'S690QL | Welding | 2' in extracted)
    output = root / 'private_pack.zip'
    result = subprocess.run([sys.executable, str(ENGINE), str(source), str(output)],
                            capture_output=True, text=True, timeout=40)
    check('real pack engine exit 0', result.returncode == 0)
    check('real pack reports success', json.loads(result.stdout)['ok'] is True)
    with zipfile.ZipFile(output) as archive:
        check('real pack ZIP CRC', archive.testzip() is None)
        manifest = json.loads(archive.read('MANIFEST.json'))
        snippets = json.loads(archive.read('TECHNICAL_SNIPPETS.json'))
        check('real pack contains one XLSX', manifest['file_count'] == 1 and manifest['files'][0]['extension'] == '.xlsx')
        check('real pack has technical snippets', any('S355' in str(v) for v in snippets.values()))
        check('original workbook not embedded', 'part.xlsx' not in archive.namelist())

cmd = (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text('utf-8-sig')
ps1 = (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text('utf-8-sig')
workflow = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text('utf-8')
name = 'run_fix72_xlsx_workbook_cleanup.py'
check('CMD release gate includes FIX72', ('%PY% tests\\' + name + ' || exit /b 1') in cmd)
check('PowerShell release gate includes FIX72', ('"tests\\' + name + '",') in ps1)
check('private Windows CI includes FIX72', ('run: python tests/' + name) in workflow)
print(f'FIX72: {checks}/{checks} PASS; SKIP=0', flush=True)
