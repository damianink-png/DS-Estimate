#!/usr/bin/env python3
"""FIX57 synthetic tests of the 60-case VSTest discovery floor (not .NET execution)."""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "tests/verify_xunit_discovery.py"
spec = importlib.util.spec_from_file_location("dse_fix57_discovery", TARGET)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
checks: list[bool] = []


def check(label: str, condition: bool) -> None:
    checks.append(bool(condition))
    print(("PASS " if condition else "FAIL ") + label, flush=True)


def transcript(n: int) -> str:
    return ("Test run for DSEstimate.Core.Tests.dll (.NETCoreApp,Version=v10.0)\n"
            "The following Tests are available:\n" +
            "".join(f"    DSEstimate.Core.Tests.Fix57Tests.Case{i:03d}\n" for i in range(n)))


with tempfile.TemporaryDirectory(prefix="dse-fix57-") as directory:
    path = Path(directory) / "discovery.txt"

    def verify(n: int, minimum: int = 60) -> bool:
        path.write_text(transcript(n), encoding="utf-8")
        try:
            return mod.verify_discovery(path, min_discovered=minimum) == n
        except mod.DiscoveryError:
            return False

    check("60 listed methods accepted", verify(60))
    check("61 listed methods accepted", verify(61))
    check("78 listed methods accepted", verify(78))
    check("59 listed methods rejected", not verify(59))
    check("1 listed method rejected", not verify(1))
    check("0 listed methods rejected", not verify(0))
    check("explicit 79 minimum rejects 78", not verify(78, 79))
    check("explicit 60 minimum accepts 78", verify(78, 60))
    path.write_text(transcript(60), encoding="utf-8")
    good = subprocess.run([sys.executable, str(TARGET), str(path), "--min-discovered", "60"],
                          capture_output=True, text=True)
    check("CLI 60 returns exit 0", good.returncode == 0 and "listed=60" in good.stdout)
    path.write_text(transcript(59), encoding="utf-8")
    bad = subprocess.run([sys.executable, str(TARGET), str(path), "--min-discovered", "60"],
                         capture_output=True, text=True)
    check("CLI 59 returns exit 1", bad.returncode == 1 and "59 < 60" in bad.stderr)

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
check("CI enforces discovery minimum 60", "verify_xunit_discovery.py TestResults/xunit-discovery.txt --min-discovered 60" in workflow)
check("CI still enforces 60 actually executed cases", "--min-executed 60 --reject-skipped" in workflow)
check("discovery remains before execution", workflow.index("--min-discovered 60") < workflow.index("- name: Run C# xUnit tests"))
for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{gate} invokes FIX57", "run_fix57_xunit_discovery_minimum_gate.py" in
          (ROOT / gate).read_text(encoding="utf-8-sig"))
print(f"SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0", flush=True)
raise SystemExit(0 if all(checks) else 1)
