"""FIX68 runtime: extractor exception messages must not enter a private pack."""
import contextlib
import importlib.util
import io
import json
import sys
import tempfile
import zipfile
from pathlib import Path
from unittest import mock

import openpyxl

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / 'engines/python/build_private_analysis_pack.py'
spec = importlib.util.spec_from_file_location('ds_private_pack_fix68', ENGINE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
checks = 0


def check(label, condition):
    global checks
    if not condition:
        raise AssertionError(label)
    checks += 1
    print('PASS | ' + label, flush=True)


def generate(source, target):
    with mock.patch.object(sys, 'argv', [str(ENGINE), str(source), str(target)]):
        with contextlib.redirect_stdout(io.StringIO()) as captured:
            module.main()
    return json.loads(captured.getvalue())


with tempfile.TemporaryDirectory(prefix='dse_fix68_') as tmp:
    base = Path(tmp)
    source = base / 'source'
    source.mkdir()
    input_path = source / 'drawing.xlsx'
    input_path.write_bytes(b'not a real xlsx')
    secret = 'CUSTOMER_CNC_CONFIDENTIAL_987654321'
    private_path = '/client/private/CNC/contracts/secret-file.xlsx'
    injected_message = f'Cannot parse {private_path}: {secret}'

    with mock.patch.object(openpyxl, 'load_workbook', side_effect=RuntimeError(injected_message)):
        failure = module.read_text(input_path)
        check('extractor reports only safe exception type', failure == 'EXTRACT_ERROR: RuntimeError')
        check('exception does not expose confidential identifier', secret not in failure)
        check('exception does not expose absolute source path', private_path not in failure)
        check('exception does not create technical snippets', module.technical_lines(failure) == [])
        output = base / 'private.zip'
        result = generate(source, output)

    check('private pack completes despite extraction failure', result['ok'] is True)
    check('manifest retains input file', result['files'] == 1)
    with zipfile.ZipFile(output) as archive:
        check('private pack passes CRC', archive.testzip() is None)
        check('archive contains only redacted metadata files', set(archive.namelist()) == {
            'MANIFEST.json', 'TECHNICAL_SNIPPETS.json', 'README_PRIVACY.txt'})
        contents = b'\n'.join(archive.read(name) for name in archive.namelist())
        check('no confidential exception string in private pack', secret.encode() not in contents)
        check('no partially redacted customer identifier in private pack', b'CUSTOMER_CNC_CONFIDENTIAL_' not in contents)
        check('no absolute path in private pack', private_path.encode() not in contents)
        check('no extractor diagnostic line leaked to snippets',
              json.loads(archive.read('TECHNICAL_SNIPPETS.json')) == {})

    # Successful extraction must still work; the fix must not hide useful facts.
    wb = openpyxl.Workbook()
    wb.active['A1'] = 'S355'
    wb.active['B1'] = 'CNC'
    wb.save(input_path)
    valid_text = module.read_text(input_path)
    check('normal XLSX extraction preserves technical content', 'S355' in valid_text and 'CNC' in valid_text)
    result = generate(source, output)
    check('successful extraction remains supported', result['ok'] is True and result['files'] == 1)
    with zipfile.ZipFile(output) as archive:
        snippets = json.loads(archive.read('TECHNICAL_SNIPPETS.json'))
        check('valid XLSX produces technical snippets', any('S355' in line for v in snippets.values() for line in v['technical_lines']))
        check('successful output ZIP passes CRC', archive.testzip() is None)

print(f'FIX68: {checks}/{checks} PASS (runtime)')
