#!/usr/bin/env python3
"""FIX9 regression: weld a/z equivalence, BOM summary rows and STEP risk wording."""
from __future__ import annotations

import json
import math
import subprocess
import sys
import tempfile
from pathlib import Path

from openpyxl import Workbook


ROOT = Path(__file__).resolve().parents[1]
PASS = 0
FAIL = 0


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8-sig")


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"PASS  {name}")
    else:
        FAIL += 1
        print(f"FAIL  {name} :: {detail}")


def build_multilingual_bom(path: Path) -> None:
    workbook = Workbook()
    workbook.remove(workbook.active)
    sheets = [
        (
            "BOM_PL",
            ("Poz.", "Nr części", "Opis", "Ilość", "Materiał", "Masa szt. kg", "Masa całkowita kg"),
            [
                (1, "PL-001", "Płyta boczna", 2, "S355J2+N", 12.5, 25.0),
                (2, "PL-002", "Wspornik", 4, "S355J2+N", 2.25, 9.0),
                (3, "PL-003", "Wał", 1, "42CrMo4", 8.4, 8.4),
                (4, "PL-004", "Śruba", 16, "8.8", 0.09, 1.44),
            ],
        ),
        (
            "BOM_EN",
            ("Item", "Part number", "Description", "Quantity", "Material", "Unit mass kg", "Total mass kg"),
            [
                (1, "EN-101", "Base plate", 1, "ASTM A36", 34.2, 34.2),
                (2, "EN-102", "Housing", 2, "6061-T6", 7.8, 15.6),
                (3, "EN-103", "Pin", 8, "AISI 304", 0.35, 2.8),
                (4, "EN-104", "Washer", 24, "AISI 304", 0.04, 0.96),
            ],
        ),
        (
            "BOM_DE",
            ("Pos.", "Teilenr", "Bezeichnung", "Menge", "Werkstoff", "Stückgewicht kg", "Gesamtgewicht kg"),
            [
                (1, "DE-201", "Rahmenplatte", 2, "S235JR", 18.75, 37.5),
                (2, "DE-202", "Lagerbock", 4, "S355J2", 5.1, 20.4),
                (3, "DE-203", "Welle", 2, "1.4301", 3.65, 7.3),
                (4, "DE-204", "Schraube", 32, "8.8", 0.055, 1.76),
            ],
        ),
        (
            "BOM_FR",
            ("Repère", "Article", "Désignation", "Quantité", "Matière", "Masse unitaire kg", "Masse totale kg"),
            [
                (1, "FR-301", "Plaque support", 2, "S355J2", 14.6, 29.2),
                (2, "FR-302", "Console", 6, "EN AW-6082", 1.95, 11.7),
                (3, "FR-303", "Axe", 3, "AISI 316", 1.2, 3.6),
                (4, "FR-304", "Écrou", 18, "8.8", 0.035, 0.63),
            ],
        ),
    ]
    for title, headers, rows in sheets:
        sheet = workbook.create_sheet(title)
        sheet.append(headers)
        for row in rows:
            sheet.append(row)
        sheet.append(("TOTAL / SUMA / GESAMT / TOTAL", None, None, None, None, None, sum(float(row[-1]) for row in rows)))
    workbook.save(path)
    workbook.close()


def test_real_bom_parser() -> None:
    with tempfile.TemporaryDirectory() as temp:
        workbook = Path(temp) / "BOM_MULTILANG_TOTALS.xlsx"
        build_multilingual_bom(workbook)
        run = subprocess.run(
            [sys.executable, str(ROOT / "engines/python/analyze_tabular.py"), str(workbook)],
            cwd=ROOT,
            text=True,
            capture_output=True,
            timeout=60,
        )
        try:
            result = json.loads(run.stdout)
        except Exception:
            result = {}
        items = result.get("bomItems") or []
        part_numbers = [str(item.get("partNumber") or "") for item in items]
        check("multilingual XLSX parser executes", run.returncode == 0 and bool(result), run.stderr or run.stdout)
        check("BOM contains 16 manufactured positions", len(items) == 16, repr(part_numbers))
        check("TOTAL/SUMA/GESAMT rows excluded", not any("TOTAL" in value.upper() or "SUMA" in value.upper() or "GESAMT" in value.upper() for value in part_numbers), repr(part_numbers))
        check("BOM mass excludes repeated summary rows", math.isclose(float(result.get("bomTotalMassKg") or 0), 209.49, abs_tol=0.001), repr(result.get("bomTotalMassKg")))
        check("BOM mass row count excludes summaries", result.get("bomMassRowCount") == 16, repr(result.get("bomMassRowCount")))


def test_weld_equivalence_source() -> None:
    source = read("src/DSEstimate.Infrastructure/ProjectAnalysisService.cs")
    z_throat = 6.35 / math.sqrt(2.0)
    check("z6.35 converts to throat a4.49", math.isclose(z_throat, 4.490128, abs_tol=0.0001), str(z_throat))
    check("a6 is conservatively larger than z6.35", 6.0 > z_throat, f"a6={6.0}, z6.35->a={z_throat}")
    check("fusion normalizes a/z before sorting", all(token in source for token in [
        "EquivalentWeldThroatMm", "value / Math.Sqrt(2.0)",
        ".OrderByDescending(x => x.EquivalentThroatMm)",
    ]))
    check("fusion reports equivalent throat basis", "największy równoważny przekrój spoiny" in source)


def test_step_risk_wording() -> None:
    source = read("src/DSEstimate.Core/CostEngine.cs")
    check("missing STEP differs from failed STEP", all(token in source for token in [
        "stepWasProvided", "Nie dostarczono modelu STEP",
        "Silnik CAD nie zwrócił poprawnej geometrii dostarczonego modelu",
    ]))


def test_release_gate_wiring() -> None:
    build = read("BUILD_FULL_PORTABLE_ZIP.ps1")
    full = read("RUN_FULL_RELEASE_TESTS.cmd")
    analyzers = read("src/DSEstimate.Infrastructure/DocumentAnalyzers.cs")
    name = "run_r9_3_0_fix9_report_correctness.py"
    check("BOM parser edit invalidates dependent cache", all(token in analyzers for token in [
        '"r930-tabular-v3", "analyze_tabular.py", "analyze_document.py"',
        "EngineResultCache.VersionForScripts",
    ]))
    check("FIX9 regression wired into Windows build", name in build)
    check("FIX9 regression wired into full release runner", name in full)


if __name__ == "__main__":
    test_real_bom_parser()
    test_weld_equivalence_source()
    test_step_risk_wording()
    test_release_gate_wiring()
    print(f"\nSUMMARY\nPASS={PASS} FAIL={FAIL}")
    raise SystemExit(1 if FAIL else 0)
