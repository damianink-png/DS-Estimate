from pathlib import Path
import ast, sys, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

def text(rel): return (ROOT / rel).read_text(encoding="utf-8-sig")
def check(name, condition):
    global passed, failed
    if condition:
        passed += 1; print("PASS ", name)
    else:
        failed += 1; print("FAIL ", name)

passed = failed = 0
decision = text("src/DSEstimate.Core/DecisionSupportEngine.cs")
trust = text("src/DSEstimate.Core/TrustFoundation.cs")
cost = text("src/DSEstimate.Core/CostEngine.cs")
auto = text("src/DSEstimate.Core/AutoQuoteEngine.cs")
domain = text("src/DSEstimate.Core/Domain.cs")
repo = text("src/DSEstimate.Infrastructure/CalibrationRepository.cs")
project = text("src/DSEstimate.Infrastructure/ProjectAnalysisService.cs")
report = text("src/DSEstimate.Infrastructure/DiagnosticReportService.cs")
excel = text("src/DSEstimate.Infrastructure/ExcelExportService.cs")
ui = text("src/DSEstimate.App/Views/MainWindow.axaml")
vm = text("src/DSEstimate.App/ViewModels/MainViewModel.cs")
docpy = text("engines/python/analyze_document.py")
csproj = text("src/DSEstimate.App/DSEstimate.App.csproj")
release = text("RUN_FULL_RELEASE_TESTS.cmd")
build = text("BUILD_FULL_PORTABLE_ZIP.ps1")

check("material calibration is implemented", "ResolveMaterialFactor" in trust and "MaterialCostBeforeCalibration" in trust)
check("calibration reset prevents compounding", "public static void Reset" in trust and "Reset(r);" in trust)
check("future calibration is rejected", "EffectiveFrom.Date > DateTime.Today" in trust)
check("workstation multipliers have priority", "process.WorkstationCode" in trust and "ResolveProcessFactor" in trust)
check("packaged calibration is runtime seed", "LoadPackagedDefault" in repo and "config" in repo and "calibration.json" in repo)
check("calibration config ships in portable", "config\\calibration.json" in csproj)
check("history uses physical model then external layer", "PrepareForHistoricalCalibration" in project and "FinalizeExternalCalibration" in project)
check("manual recalculation preserves history blend", "result.HistoricalPricePln is > 0" in cost and "result.FinalPricePln = historyShare > 0" in cost)
check("what-if engine exists", "class QuoteScenario" in decision and "class QuoteScenarioEngine" in decision)
check("what-if keeps unavailable offer unavailable", "HasOfferPrice = hasOffer" in decision and '"NIE WYZNACZONO"' in decision)
check("what-if labels partial offer honestly", "IsPriceComplete" in decision and "CZĘŚCIOWA" in decision)
check("scenario inputs configurable", "WhatIfMaterialPriceChangePercent" in domain and "WhatIfProcessTimeChangePercent" in domain)
check("scenario UI visible", "Scenariusze — co się stanie" in ui and "Analysis.QuoteScenarios" in ui)
check("scenario settings refresh without engine rerun", "QuoteScenarioEngine.Apply(Analysis)" in vm and "odświeżono bez STEP/OCR" in vm)
check("scenario Excel export", "Scenariusze what-if" in excel)
check("scenario diagnostic audit", "WHAT-IF" in report)
check("bending multilingual semantics", '"BENDING"' in docpy and '"FLAT_PATTERN"' in docpy)
check("bending is unpriced route", '"BEND"' in auto and "RequiresExternalRate" in auto)
check("bending UI and next action", "Analysis.SheetMetal.NextAction" in ui)
check("report includes patch and engine hashes", "FIX16 DECISION SUPPORT" in report and "Hash silnika STEP" in report)
check("xunit behavior tests included", (ROOT / "tests/DSEstimate.Core.Tests/Fix16DecisionSupportTests.cs").exists())

try:
    ET.parse(ROOT / "src/DSEstimate.App/Views/MainWindow.axaml")
    ET.parse(ROOT / "src/DSEstimate.App/DSEstimate.App.csproj")
    check("XML/XAML parses", True)
except Exception as ex:
    check(f"XML/XAML parses: {ex}", False)

try:
    ast.parse(docpy)
    check("document analyzer parses", True)
except SyntaxError as ex:
    check(f"document analyzer parses: {ex}", False)

for name, source in [("decision", decision), ("trust", trust), ("cost", cost), ("auto", auto), ("project", project), ("report", report), ("excel", excel)]:
    check(f"{name} braces balanced", source.count("{") == source.count("}"))

check("FIX16 in release gate", "run_fix16_decision_support.py" in release)
check("FIX16 in portable build gate", "run_fix16_decision_support.py" in build)

print(f"\nSUMMARY PASS={passed} FAIL={failed}")
sys.exit(1 if failed else 0)
