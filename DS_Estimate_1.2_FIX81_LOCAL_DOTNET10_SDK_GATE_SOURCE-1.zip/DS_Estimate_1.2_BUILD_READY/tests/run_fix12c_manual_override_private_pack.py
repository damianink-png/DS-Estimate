from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
checks=[]
def check(name, cond):
    print(('PASS' if cond else 'FAIL'), name); checks.append(bool(cond))
vm=(root/'src/DSEstimate.App/ViewModels/MainViewModel.cs').read_text(encoding='utf-8-sig')
view=(root/'src/DSEstimate.App/Views/MainWindow.axaml').read_text(encoding='utf-8-sig')
cb=(root/'src/DSEstimate.App/Views/MainWindow.axaml.cs').read_text(encoding='utf-8-sig')
svc=(root/'src/DSEstimate.Infrastructure/PrivateAnalysisPackService.cs').read_text(encoding='utf-8-sig')
py=(root/'engines/python/build_private_analysis_pack.py').read_text(encoding='utf-8')
check('process checkbox marks/persists manual override', 'OnProcessEnabledClick' in view and '_vm.RegisterProcessToggle(process)' in cb and 'process.ManualOverride = process.Enabled != process.AutomaticEnabled' in vm)
check('recalculate preserves persisted manual overrides', 'ProcessOverrides' in vm and 'ApplyPersistedProcessOverrides(result)' in vm and 'manualProcessOverrides' not in vm)
check('recalculate reapplies manual process edits', '_cost.ApplyManualProcessEdits(Analysis, Processes, Settings);' in vm)
# FIX13 product decision: private-analysis export is an internal compatibility utility only.
# It must not be exposed in the normal app UI or view-model workflow.
check('private pack button removed from UI', 'Pakiet prywatny do analizy' not in view)
check('private pack click handler removed', 'OnBuildPrivateAnalysisPackClick' not in cb)
check('private pack viewmodel action removed', 'BuildPrivateAnalysisPackAsync' not in vm and '_privatePack' not in vm)
check('private pack internal service retained for compatibility', 'class PrivateAnalysisPackService' in svc)
# FIX69 writes the same three sanitized entries through a canonical ZipInfo
# helper, rather than calling writestr with the entry name directly.
manifest_writer = ("writestr('MANIFEST.json'" in py or
                   "write_private_entry(z, 'MANIFEST.json'" in py)
check('private pack internal utility still excludes raw source files',
      'NO_RAW_SOURCE_FILES' in py and manifest_writer)
check('private pack internal utility redacts long ids', 'LONG_ID_RE' in py)
check('private pack internal utility keeps family correlation by hashes', 'family_id' in py and 'group_id' in py)
try:
    ET.parse(root/'src/DSEstimate.App/Views/MainWindow.axaml'); xmlok=True
except Exception: xmlok=False
check('MainWindow XAML parses', xmlok)
for name,text in [('vm',vm),('cb',cb),('svc',svc)]: check(name+' braces balanced', text.count('{')==text.count('}'))
print(f'SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)}')
raise SystemExit(0 if all(checks) else 1)
