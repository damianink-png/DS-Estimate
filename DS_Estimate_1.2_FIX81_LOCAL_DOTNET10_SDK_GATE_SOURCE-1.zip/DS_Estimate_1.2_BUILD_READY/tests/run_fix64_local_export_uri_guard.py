"""FIX64: source-level guard for save-picker URIs (not an Avalonia runtime test)."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "src/DSEstimate.App/Views/MainWindow.axaml.cs").read_text(encoding="utf-8-sig")
WORKFLOW = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")

def method(name: str, end: str) -> str:
    assert SOURCE.count(name) == 1, name
    return SOURCE.split(name, 1)[1].split(end, 1)[0]

diag = method("private async void OnExportDiagnosticReportClick", "private async void OnExportExcelClick")
excel = method("private async void OnExportExcelClick", "private void OnSaveSettingsClick")
helper = method("private static string? LocalSavePath", "private async void OnExportDiagnosticReportClick")
checks = {
    "nullable IStorageFile save helper": "(IStorageFile? file)" in helper,
    "save helper checks local URI": "file.Path.IsFile" in helper,
    "save helper rejects missing picker result": "file is not null" in helper,
    "save helper accesses LocalPath only after check": bool(re.search(r"file\.Path\.IsFile\s*\?\s*file\.Path\.LocalPath", helper)),
    "diagnostic picker cancellation is harmless": "if (file is null)" in diag and "return;" in diag,
    "offer picker cancellation is harmless": "if (file is null)" in excel and "return;" in excel,
    "diagnostic export uses safe local path": "var localPath = LocalSavePath(file);" in diag and "ExportDiagnosticReportAsync(localPath)" in diag,
    "offer export uses safe local path": "var localPath = LocalSavePath(file);" in excel and "ExportExcelAsync(localPath)" in excel,
    "diagnostic nonlocal URI reports error": "if (localPath is null)" in diag and "tylko w lokalnym folderze" in diag,
    "offer nonlocal URI reports error": "if (localPath is null)" in excel and "tylko w lokalnym folderze" in excel,
    "diagnostic I/O errors are caught": "catch (Exception ex)" in diag and "Nie wyeksportowano raportu:" in diag,
    "offer I/O errors remain caught": "catch (Exception ex)" in excel and "Nie wyeksportowano oferty:" in excel,
    "no direct unsafe save picker LocalPath": "file.Path.LocalPath" not in diag + excel,
    "original DnD local URI check retained": ".Where(uri => uri.IsFile)" in SOURCE,
    "Windows CI invokes FIX64 regression": "run: python tests/run_fix64_local_export_uri_guard.py" in WORKFLOW,
}
for label, passed in checks.items():
    print(("PASS" if passed else "FAIL") + " | " + label)
if not all(checks.values()):
    raise SystemExit(1)
print(f"FIX64: {len(checks)}/{len(checks)} PASS (static only; no .NET build claimed)")
