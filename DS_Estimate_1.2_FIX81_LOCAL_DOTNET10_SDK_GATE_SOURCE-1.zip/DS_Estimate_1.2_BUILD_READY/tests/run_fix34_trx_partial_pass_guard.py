#!/usr/bin/env python3
"""FIX34: ensure a TRX cannot be green with unaccounted executed tests.

These are Python tests of the TRX guard, NOT executed C# or xUnit tests.
"""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERIFY = ROOT / "tests" / "verify_dotnet_trx.py"
spec = importlib.util.spec_from_file_location("verify_dotnet_trx", VERIFY)
assert spec is not None and spec.loader is not None
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def trx(total: int, executed: int, passed: int, *, failed: int = 0,
        inconclusive: int = 0) -> str:
    return (
        '<TestRun xmlns="http://microsoft.com/schemas/VisualStudio/TeamTest/2010">'
        '<ResultSummary outcome="Completed">'
        f'<Counters total="{total}" executed="{executed}" passed="{passed}" '
        f'failed="{failed}" inconclusive="{inconclusive}" error="0" '
        'timeout="0" aborted="0" notRunnable="0"/>'
        '</ResultSummary></TestRun>'
    )


cases = [
    ("all executed tests passed", trx(3, 3, 3), True),
    ("skipped tests remain allowed", trx(4, 3, 3), True),
    ("one unaccounted executed test rejected", trx(3, 3, 2), False),
    ("inconclusive executed test rejected", trx(3, 3, 2, inconclusive=1), False),
    ("two unaccounted executed tests rejected", trx(4, 4, 2), False),
    ("failed test remains rejected", trx(3, 3, 2, failed=1), False),
]

passed_count = failed_count = 0
with tempfile.TemporaryDirectory(prefix="dse-fix34-") as directory:
    path = Path(directory) / "test.trx"
    for label, content, expected in cases:
        path.write_text(content, encoding="utf-8")
        try:
            module.verify_trx(path)
            accepted = True
        except module.TrxValidationError:
            accepted = False
        success = accepted == expected
        print(("PASS " if success else "FAIL ") + label, flush=True)
        passed_count += int(success)
        failed_count += int(not success)

    # Verify that the CLI used by GitHub Actions also fails closed.
    path.write_text(trx(3, 3, 2), encoding="utf-8")
    completed = subprocess.run([sys.executable, str(VERIFY), str(path)],
                               text=True, capture_output=True, check=False)
    success = completed.returncode == 1 and "FAIL" in completed.stderr
    print(("PASS " if success else "FAIL ") + "CI CLI rejects partial-pass TRX", flush=True)
    passed_count += int(success)
    failed_count += int(not success)

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
success = "python tests/verify_dotnet_trx.py" in workflow
print(("PASS " if success else "FAIL ") + "CI workflow invokes hardened verifier", flush=True)
passed_count += int(success)
failed_count += int(not success)

print(f"SUMMARY PASS={passed_count} FAIL={failed_count} SKIP=0", flush=True)
raise SystemExit(1 if failed_count else 0)
