#!/usr/bin/env python3
"""FIX76: cap decoded text/CSV/XML/log reads before allocating full files."""
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / 'engines/python/build_private_analysis_pack.py'
spec = importlib.util.spec_from_file_location('dse_private_pack_fix76', ENGINE)
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
checks = 0


def check(label, condition):
    global checks
    if not condition:
        print('FAIL | ' + label, flush=True)
        raise AssertionError(label)
    checks += 1
    print('PASS | ' + label, flush=True)


class ReadSpy:
    def __init__(self, stream, reads):
        self.stream = stream
        self.reads = reads

    def __enter__(self):
        self.stream.__enter__()
        return self

    def __exit__(self, *args):
        return self.stream.__exit__(*args)

    def read(self, *args, **kwargs):
        self.reads.append(args)
        return self.stream.read(*args, **kwargs)


with tempfile.TemporaryDirectory(prefix='dse_fix76_') as td:
    source = Path(td) / 'source'
    source.mkdir()
    # Multibyte characters near the 5M-character boundary prove that the
    # original character-based limit (not a 5M-byte limit) is preserved.
    contents = 'Material S355 CNC\n' + 'a' * (4_999_980) + 'żó' + 'b' * 1_100_000
    expected = contents[:5_000_000]
    original_open = Path.open
    for extension in ('.txt', '.csv', '.log', '.xml'):
        document = source / ('customer' + extension)
        document.write_text(contents, encoding='utf-8')
        reads = []

        def monitored_open(self, mode='r', *args, **kwargs):
            stream = original_open(self, mode, *args, **kwargs)
            if self == document and mode == 'r':
                return ReadSpy(stream, reads)
            return stream

        with patch.object(Path, 'open', monitored_open), patch.object(
            Path, 'read_text', side_effect=AssertionError('unbounded Path.read_text forbidden')
        ):
            extracted = engine.read_text(document)
        check(extension + ' exact decoded 5M character prefix', extracted == expected)
        check(extension + ' bounded read call', reads == [(5_000_000,)])
        check(extension + ' no accidental extraction error', not extracted.startswith('EXTRACT_ERROR:'))
        check(extension + ' Unicode boundary preserved', extracted.endswith('żó'))
        document.unlink()

    document = source / 'drawing.txt'
    document.write_text('Material S355 CNC\n' + 'A' * 5_500_000, encoding='utf-8')
    output = Path(td) / 'private.zip'
    result = subprocess.run([sys.executable, str(ENGINE), str(source), str(output)],
                            capture_output=True, text=True, timeout=40)
    check('real CLI exit 0', result.returncode == 0)
    check('real CLI reports success', json.loads(result.stdout)['ok'] is True)
    with zipfile.ZipFile(output) as archive:
        check('real private ZIP CRC valid', archive.testzip() is None)
        manifest = json.loads(archive.read('MANIFEST.json'))
        check('real manifest source count', manifest['file_count'] == 1)
        check('real manifest full source SHA256', manifest['files'][0]['sha256'] == hashlib.sha256(document.read_bytes()).hexdigest())
        snippets = json.loads(archive.read('TECHNICAL_SNIPPETS.json'))
        check('real ZIP includes technical snippets', bool(snippets))
        check('real ZIP does not embed original file', 'drawing.txt' not in archive.namelist())
    check('real ZIP source length is not truncated', json.loads(result.stdout)['source_bytes'] == document.stat().st_size)

cmd = (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text('utf-8-sig')
ps1 = (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text('utf-8-sig')
workflow = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text('utf-8')
name = 'run_fix76_private_pack_bounded_text_read.py'
check('CMD release gate includes FIX76', ('%PY% tests\\' + name + ' || exit /b 1') in cmd)
check('PowerShell release gate includes FIX76', ('"tests\\' + name + '",') in ps1)
check('private Windows CI includes FIX76', ('run: python tests/' + name) in workflow)
print(f'FIX76: {checks}/{checks} PASS; FAIL=0 SKIP=0 TIMEOUT=0', flush=True)
