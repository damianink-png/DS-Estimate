#!/usr/bin/env python3
"""Remove only the previous xUnit TRX before a new CI test execution.

This is not a test runner. A missing fresh TRX must still fail the strict
verify_dotnet_trx.py gate after dotnet test. Run from the repository root.
"""
from __future__ import annotations

import sys
from pathlib import Path

TRX_RELATIVE = Path("TestResults") / "ds-estimate-xunit.trx"


def clear_stale_trx(root: Path) -> bool:
    directory = root / "TestResults"
    path = root / TRX_RELATIVE
    if directory.is_symlink() or path.is_symlink():
        raise ValueError("Refusing to remove a symlinked TRX or TestResults directory")
    if not path.exists():
        return False
    if not path.is_file():
        raise ValueError("Expected a regular TRX file, not a directory or special file")
    path.unlink()  # Fail closed on permission errors; do not silently reuse old results.
    return True


def main() -> int:
    try:
        removed = clear_stale_trx(Path.cwd())
    except (OSError, ValueError) as exc:
        print(f"FAIL clearing stale xUnit TRX: {exc}", file=sys.stderr)
        return 1
    print("REMOVED stale xUnit TRX" if removed else "No previous xUnit TRX")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
