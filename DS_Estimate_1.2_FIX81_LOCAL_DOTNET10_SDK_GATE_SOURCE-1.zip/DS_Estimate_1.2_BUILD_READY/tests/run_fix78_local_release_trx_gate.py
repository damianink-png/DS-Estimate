#!/usr/bin/env python3
"""FIX78: both local Windows release gates require fresh, strict xUnit TRX.

The Python subprocesses exercise the real TRX verifier and stale-file cleaner
against synthetic XML. This does NOT claim a Windows/.NET build or xUnit run.
"""
from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CMD = (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='ascii')
PS1 = (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig')
CI = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text(encoding='utf-8')
VERIFY = ROOT / 'tests/verify_dotnet_trx.py'
CLEAR = ROOT / 'tests/clear_stale_trx.py'
checks: list[bool] = []


def check(label: str, value: bool) -> None:
    checks.append(bool(value))
    print(('PASS' if value else 'FAIL') + ' | ' + label, flush=True)


cmd_start = CMD.index('where dotnet >nul')
cmd_end = CMD.index('%PY% tests\\run_r7_regression.py', cmd_start)
cmd_gate = CMD[cmd_start:cmd_end]
ps_start = PS1.index('Write-Host "Uruchamianie testów jednostkowych .NET..."')
ps_end = PS1.index('$baselineFunctionalTests = @(', ps_start)
ps_gate = PS1[ps_start:ps_end]

check('CMD clears old TRX before xUnit',
      cmd_gate.find('tests\\clear_stale_trx.py') >= 0 and
      cmd_gate.index('tests\\clear_stale_trx.py') < cmd_gate.index('dotnet test'))
check('CMD records a real TRX',
      '--logger "trx;LogFileName=ds-estimate-xunit.trx"' in cmd_gate and
      '--results-directory TestResults' in cmd_gate)
check('CMD verifies TRX after xUnit',
      cmd_gate.find('tests\\verify_dotnet_trx.py') > cmd_gate.index('dotnet test'))
check('CMD enforces strict results and minimum 60',
      '--require-results --min-executed 60 --reject-skipped' in cmd_gate)
check('CMD propagates cleaner, runner and verifier errors',
      cmd_gate.count('|| exit /b 1') >= 3)
check('CMD has exactly one real xUnit execution', cmd_gate.count('dotnet test ') == 1)
check('CMD remains ASCII/BOM-free', (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_bytes().startswith(b'@echo off'))

check('PS1 clears old TRX before xUnit',
      ps_gate.find('tests\\clear_stale_trx.py') >= 0 and
      ps_gate.index('tests\\clear_stale_trx.py') < ps_gate.index('& dotnet test'))
check('PS1 records a real TRX',
      '--logger "trx;LogFileName=ds-estimate-xunit.trx"' in ps_gate and
      '--results-directory $trxResultsDir' in ps_gate)
check('PS1 verifies TRX after xUnit',
      ps_gate.find('tests\\verify_dotnet_trx.py') > ps_gate.index('& dotnet test'))
check('PS1 enforces strict results and minimum 60',
      '--require-results --min-executed 60 --reject-skipped' in ps_gate)
check('PS1 propagates cleaner, runner and verifier errors',
      ps_gate.count('if ($LASTEXITCODE -ne 0) { Fail ') >= 3)
check('PS1 uses build Python 3.12 for verification',
      ps_gate.count('& $buildPyExe @buildPyPrefix') >= 2)
check('PS1 keeps release-gate stage conditional',
      'if (-not $FastBuild -or $RunFullRegression)' in PS1)
check('PS1 preserves UTF-8 BOM',
      (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_bytes().startswith(b'\xef\xbb\xbf'))
check('CI strict TRX gate unchanged',
      '--require-results --min-executed 60 --reject-skipped' in CI and
      'python tests/clear_stale_trx.py' in CI)


def trx(*, count: int = 60, skip: int = 0, fail: int = 0) -> str:
    passed = count - skip - fail
    records = []
    for i in range(count):
        outcome = 'Skipped' if i < skip else ('Failed' if i < skip + fail else 'Passed')
        records.append(f'<UnitTestResult testId="t{i}" testName="DSEstimate.Core.Tests.Fixture.Test{i}" outcome="{outcome}" />')
    return ('<TestRun><Results>' + ''.join(records) + '</Results>'
            '<ResultSummary outcome="Completed"><Counters '
            f'total="{count}" executed="{count-skip}" passed="{passed}" '
            f'failed="{fail}" error="0" skipped="{skip}" />'
            '</ResultSummary></TestRun>')


with tempfile.TemporaryDirectory(prefix='dse-fix78-') as temporary:
    tmp = Path(temporary)
    results = tmp / 'TestResults'
    results.mkdir()
    file = results / 'ds-estimate-xunit.trx'
    args = [sys.executable, str(VERIFY), str(file), '--require-results',
            '--min-executed', '60', '--reject-skipped']

    def run_verify() -> subprocess.CompletedProcess[str]:
        return subprocess.run(args, cwd=tmp, capture_output=True, text=True, timeout=15)

    check('missing fresh TRX fails closed', run_verify().returncode != 0)
    file.write_text(trx(), encoding='utf-8')
    check('60 distinct passing records accepted', run_verify().returncode == 0)
    clear = subprocess.run([sys.executable, str(CLEAR)], cwd=tmp,
                           capture_output=True, text=True, timeout=15)
    check('real stale TRX cleanup removes old report', clear.returncode == 0 and not file.exists())
    check('after cleanup no old report can pass', run_verify().returncode != 0)
    for label, xml, expected in (
        ('59 executed tests rejected', trx(count=59), 1),
        ('60 tests with one SKIP rejected', trx(skip=1), 1),
        ('60 tests with one FAIL rejected', trx(fail=1), 1),
        ('60 fully passing tests accepted again', trx(), 0),
    ):
        file.write_text(xml, encoding='utf-8')
        check(label, (run_verify().returncode == 0) == (expected == 0))
    file.unlink()
    check('no stale TRX cleanup also succeeds', subprocess.run(
        [sys.executable, str(CLEAR)], cwd=tmp,
        capture_output=True, text=True, timeout=15).returncode == 0)

check('CMD executes FIX78 regression',
      '%PY% tests\\run_fix78_local_release_trx_gate.py || exit /b 1' in CMD)
check('PS1 executes FIX78 regression',
      '"tests\\run_fix78_local_release_trx_gate.py",' in PS1)
check('Windows CI executes FIX78 regression',
      'run: python tests/run_fix78_local_release_trx_gate.py' in CI)

print(f'SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0', flush=True)
raise SystemExit(0 if all(checks) else 1)
