#!/usr/bin/env python3
"""FIX33 regression of TRX verification and CI wiring; no C# execution."""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("verify_dotnet_trx", ROOT / "tests/verify_dotnet_trx.py")
assert spec and spec.loader
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
passed = failed = 0


def check(label: str, ok: bool) -> None:
    global passed, failed
    if ok:
        passed += 1
    else:
        failed += 1
    print(("PASS " if ok else "FAIL ") + label, flush=True)


def trx(total: int, executed: int, passed: int, failed: int = 0,
        outcome: str = "Completed", *, namespace: bool = True) -> str:
    ns = ' xmlns="http://microsoft.com/schemas/VisualStudio/TeamTest/2010"' if namespace else ""
    return (f'<TestRun{ns}><ResultSummary outcome="{outcome}">'
            f'<Counters total="{total}" executed="{executed}" passed="{passed}" '
            f'failed="{failed}" error="0" timeout="0" aborted="0" '
            f'notRunnable="0"/></ResultSummary></TestRun>')


with tempfile.TemporaryDirectory(prefix="dse-fix33-") as d:
    path = Path(d) / "test.trx"
    for label, xml, expected in [
        ("namespaced TRX with successful xUnit tests", trx(12, 12, 12), True),
        ("non-namespaced TRX supported", trx(3, 3, 3, namespace=False), True),
        ("skipped tests allowed when others passed", trx(4, 3, 3), True),
        ("zero discovered tests rejected", trx(0, 0, 0), False),
        ("no executed tests rejected", trx(2, 0, 0), False),
        ("failed test rejected", trx(3, 3, 2, 1), False),
        ("inconsistent counters rejected", trx(2, 3, 3), False),
        ("aborted run rejected", trx(2, 2, 2, outcome="Aborted"), False),
        ("malformed XML rejected", "<TestRun>", False),
        ("non-TRX XML rejected", "<results/>", False),
        ("missing Counters rejected", "<TestRun><ResultSummary outcome='Completed'/></TestRun>", False),
    ]:
        path.write_text(xml, encoding="utf-8")
        try:
            result = module.verify_trx(path)
            ok = bool(result)
        except module.TrxValidationError:
            ok = False
        check(label, ok == expected)
    path.unlink()
    try:
        module.verify_trx(path)
        missing_rejected = False
    except module.TrxValidationError:
        missing_rejected = True
    check("missing TRX rejected", missing_rejected)
    path.write_text(trx(1, 1, 1), encoding="utf-8")
    cli = subprocess.run([sys.executable, str(ROOT / "tests/verify_dotnet_trx.py"), str(path)],
                         capture_output=True, text=True)
    check("real CLI accepts valid TRX", cli.returncode == 0 and "PASS" in cli.stdout)
    path.write_text(trx(0, 0, 0), encoding="utf-8")
    cli = subprocess.run([sys.executable, str(ROOT / "tests/verify_dotnet_trx.py"), str(path)],
                         capture_output=True, text=True)
    check("real CLI fails closed on empty test run", cli.returncode == 1 and "FAIL" in cli.stderr)

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
check("CI actually builds solution and runs xUnit before TRX verification",
      workflow.index("dotnet build DS_Estimate.sln") < workflow.index("dotnet test tests/DSEstimate.Core.Tests")
      < workflow.index("python tests/verify_dotnet_trx.py"))
check("CI includes .NET SDK info and test-result upload on failure",
      "dotnet --info" in workflow and "if: always()" in workflow and "actions/upload-artifact@v4" in workflow)
check("Windows full release gate includes FIX33 regression",
      "run_fix33_ci_trx_guard.py" in (ROOT / "RUN_FULL_RELEASE_TESTS.cmd").read_text(encoding="utf-8-sig"))
check("portable build gate includes FIX33 regression",
      "run_fix33_ci_trx_guard.py" in (ROOT / "BUILD_FULL_PORTABLE_ZIP.ps1").read_text(encoding="utf-8-sig"))
try:
    import yaml
    data = yaml.safe_load(workflow)
    steps = data["jobs"]["dotnet-build-test"]["steps"]
    check("GitHub workflow YAML parses and references TRX guard",
          any("python tests/verify_dotnet_trx.py" in str(s.get("run", "")) for s in steps))
except ImportError:
    print("SKIP optional YAML parser unavailable", flush=True)
except (ValueError, KeyError, TypeError):
    check("GitHub workflow YAML parses and references TRX guard", False)

print(f"SUMMARY PASS={passed} FAIL={failed} SKIP=0")
raise SystemExit(1 if failed else 0)
