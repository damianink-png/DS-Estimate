﻿from pathlib import Path
import importlib.util
import json
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
ENGINE_DIR = ROOT / 'engines' / 'python'
sys.path.insert(0, str(ENGINE_DIR))

spec = importlib.util.spec_from_file_location('analyze_tabular', ENGINE_DIR / 'analyze_tabular.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

DOMAIN = (ROOT/'src/DSEstimate.Core/Domain.cs').read_text(encoding='utf-8')
COST = (ROOT/'src/DSEstimate.Core/CostEngine.cs').read_text(encoding='utf-8')
MERGE = (ROOT/'src/DSEstimate.Infrastructure/ProjectAnalysisService.cs').read_text(encoding='utf-8')
REPORT = (ROOT/'src/DSEstimate.Infrastructure/DiagnosticReportService.cs').read_text(encoding='utf-8')
BUILD = (ROOT/'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig')
RUNNER = (ROOT/'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='utf-8-sig')

checks=[]
def check(name, cond, detail=''):
    ok=bool(cond)
    checks.append((name,ok))
    print(('PASS ' if ok else 'FAIL ') + name + (f' :: {detail}' if detail and not ok else ''))

def analyze_csv(tmp: Path, name: str, content: str):
    p=tmp/name
    p.write_text(content, encoding='utf-8')
    return mod.analyze(p)

with tempfile.TemporaryDirectory(prefix='dse_public_bom_') as d:
    tmp=Path(d)

    # Autodesk AutoCAD Mechanical documentation example: exact public BOM rows
    # with Mass and Total Mass columns. Total = 12.434 kg.
    autodesk = analyze_csv(tmp, 'autodesk_mechanical_bom_mass.csv', '''Item,QTY,Part No,Description,Material / Standard,Cut Length (mm),Mass (kg),Total Mass (kg)\n1,2,10025,Mounting Plate,Flat Bar 50x6,175.0,0.413,0.826\n2,6,30531,Hex-Head Bolt,ISO 4014 - M6 x 45,,0.0,0.0\n3,1,20105,I-Shape,AISC - M8 x 6.5,1200.0,11.608,11.608\n''')
    check('Autodesk BOM: 3/3 rows', len(autodesk.get('bomItems',[]))==3, str(autodesk.get('bomItems')))
    check('Autodesk BOM: total mass 12.434 kg', abs(float(autodesk.get('bomTotalMassKg') or 0)-12.434)<1e-9, str(autodesk.get('bomTotalMassKg')))
    check('Autodesk BOM: per-row mass preserved', abs(autodesk['bomItems'][0].get('massKgEach',0)-0.413)<1e-12)
    check('Autodesk BOM: empty Cut Length does not shift mass', autodesk['bomItems'][1].get('massKgEach')==0.0 and autodesk['bomItems'][1].get('totalMassKg')==0.0)
    check('Purchased M6 bolt does not create M6 machining hole', len(autodesk.get('holeRequirements',[]))==0, str(autodesk.get('holeRequirements')))
    check('Purchased ISO 4014 does not become project manufacturing norm', 'ISO 4014' not in autodesk.get('norms',[]), str(autodesk.get('norms')))
    check('Material/Standard cell preserved', autodesk['bomItems'][0].get('material')=='Flat Bar 50x6')

    # Same Autodesk example in XLSX: interior blank cells must not shift Mass.
    import openpyxl
    xlsx_path = tmp/'autodesk_mechanical_bom_mass.xlsx'
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'BOM'
    ws.append(['Item','QTY','Part No','Description','Material / Standard','Cut Length (mm)','Mass (kg)','Total Mass (kg)'])
    ws.append([1,2,'10025','Mounting Plate','Flat Bar 50x6',175.0,0.413,0.826])
    ws.append([2,6,'30531','Hex-Head Bolt','ISO 4014 - M6 x 45',None,0.0,0.0])
    ws.append([3,1,'20105','I-Shape','AISC - M8 x 6.5',1200.0,11.608,11.608])
    # A second worksheet intentionally has a BOM-like row but no BOM header.
    # Header mapping from sheet 1 must never leak into it.
    ws2=wb.create_sheet('BAZA ZAŁOŻEŃ')
    ws2.append(['NOT_A_PART',99,'rate row','not material',None,None,999,999])
    wb.save(xlsx_path)
    wb.close()
    autodesk_xlsx = mod.analyze(xlsx_path)
    # Windows-specific regression: analyzer must release the XLSX file handle.
    # If read_only openpyxl workbook is not closed, this unlink raises WinError 32.
    xlsx_path.unlink()
    check('Autodesk XLSX: 3/3 BOM rows only', len(autodesk_xlsx.get('bomItems',[]))==3, str(autodesk_xlsx.get('bomItems')))
    check('Autodesk XLSX: blank interior cell preserved', autodesk_xlsx['bomItems'][1].get('massKgEach')==0.0)
    check('Autodesk XLSX: total mass 12.434 kg', abs(float(autodesk_xlsx.get('bomTotalMassKg') or 0)-12.434)<1e-9, str(autodesk_xlsx.get('bomTotalMassKg')))
    check('XLSX: BOM header does not leak to next sheet', all(x.get('partNumber')!='NOT_A_PART' for x in autodesk_xlsx.get('bomItems',[])))

    # Public purchasing BOM regression (NavBot-style). "Lightweight" is a
    # product adjective, Price is not mass, and RS485/5000mAh digits must never
    # become kilograms. A later installation schedule can provide Total Qty.
    purchasing_path = tmp/'public_purchasing_bom.xlsx'
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(['Part Name','Recommended Purchase Link','Specifications','Quantity','Price ($)'])
    ws.append(['Aluminum Tube','https://example.test/structural-component','Lightweight aluminum construction',1,12.5])
    ws.append(['Gyroscope','https://example.test/usb-can','High precision RS485 CAN USB',1,25])
    ws.append(['Battery','https://example.test/battery','5000mAh 6s 45C XT60',1,69.9])
    ws.append([])
    ws.append(['Installation Location','Qty. per Limb','Total Qty.','Specification'])
    ws.append(['Knee Joint',2,8,'Bearing 10 x 19 x 5 mm'])
    wb.save(purchasing_path)
    wb.close()
    purchasing = mod.analyze(purchasing_path)
    check('Purchasing XLSX: price/specification not mass', purchasing.get('bomTotalMassKg') is None, str(purchasing.get('bomTotalMassKg')))
    check('Purchasing XLSX: product and installation rows retained', len(purchasing.get('bomItems',[]))==4, str(purchasing.get('bomItems')))
    check('Purchasing XLSX: Total Qty preferred', purchasing['bomItems'][-1].get('quantity')==8, str(purchasing['bomItems'][-1]))

    # Public Fusion CSV-BOM Plus schema: Part name, Quantity, Mass kg, Material.
    fusion = analyze_csv(tmp, 'fusion_csv_bom_plus.csv', '''Part name,Quantity,Volume cm^3,Width,Length,Height,Area cm^2,Mass kg,Density kg/cm^3,Material,Description\nPart 1,1,98.322384,50.8,25.4,76.2,141.9352,0.7718307144,0.00785,Steel,Formlabs public cuboid reference\n''')
    check('CSV-BOM Plus: Part name accepted as identifier', len(fusion.get('bomItems',[]))==1 and fusion['bomItems'][0]['partNumber']=='Part 1')
    check('CSV-BOM Plus: Mass kg read', abs(float(fusion.get('bomTotalMassKg') or 0)-0.7718307144)<1e-12)
    check('CSV-BOM Plus: no false hole features', len(fusion.get('holeRequirements',[]))==0)

    # Seeed reBot CNC table shape copied from the public project table:
    # 21 unique rows / 31 required CNC pieces, all Aluminum Alloy 5052.
    seeed = analyze_csv(tmp, 'seeed_rebot_cnc_bom.csv', '''Part Description,Image,File Name,Material,Qty,Machining,Notes
Motor 1 Bearing Mount,,02_Base_Reinforcement_Part.step,Aluminum Alloy 5052,1,CNC,Can be 3D printed in ABS with high infill to reduce cost
Motor 1 Rotation Axis,,02_Arm_Yaw_Limit.step,Aluminum Alloy 5052,1,CNC,Added yaw angle motion limit
Motor 2–5 Front Spacer,,02_Motor_Front_Spacer.step,Aluminum Alloy 5052,4,CNC,Can be 3D printed in ABS with 30% infill
Motor 2–4 Rear Spacer,,02_Motor_Back_Spacer.step,Aluminum Alloy 5052,3,CNC,
Motor 2–4 Rear Flange,,02_FLANGE.step,Aluminum Alloy 5052,3,CNC,
Wrist Motor 5 Bracket,,02_Wrist_Bracket.step,Aluminum Alloy 5052,1,CNC,
Gripper Connector A,,02_Gripper_Connector_A.step,Aluminum Alloy 5052,1,CNC,
Gripper Connector B,,02_Gripper_Connector_B.step,Aluminum Alloy 5052,1,CNC,
Gripper Slider Metal Bracket,,02_Slider_Bracket.step,Aluminum Alloy 5052,1,CNC,Can be 3D printed in ABS with high infill
Slider to Gripper Extension,,02_Slider_Extension.step,Aluminum Alloy 5052,2,CNC,
Upper-Lower Arm Link Left,,02_Lower_Upper_Link_L.step,Aluminum Alloy 5052,1,CNC,
Upper-Lower Arm Link Right,,02_Lower_Upper_Link_R.step,Aluminum Alloy 5052,1,CNC,
Lower Arm-Wrist Link Left,,02_Lower_Wrist_Link_L.step,Aluminum Alloy 5052,1,CNC,
Lower Arm-Wrist Link Right,,02_Lower_Wrist_Link_R.step,Aluminum Alloy 5052,1,CNC,
Gear Connector,,02_Gear_Connector.step,Aluminum Alloy 5052,1,CNC,
Rack,,02_Rack.step,Aluminum Alloy 5052,2,CNC,
Link 1,,03_Link1.step,Aluminum Alloy 5052,1,CNC + Sheet Metal,
Link 2,,03_Link2.step,Aluminum Alloy 5052,2,CNC + Sheet Metal,
Link 3 Left,,03_Link3_L.step,Aluminum Alloy 5052,1,CNC + Sheet Metal,
Link 3 Right,,03_Link3_R.step,Aluminum Alloy 5052,1,CNC + Sheet Metal,
Link 5,,03_Link5.step,Aluminum Alloy 5052,1,CNC + Sheet Metal,
''')
    check('Seeed-style BOM: 21/21 rows', len(seeed.get('bomItems',[]))==21, str(len(seeed.get('bomItems',[]))))
    check('Seeed-style BOM: quantity total 31', abs(sum(float(x['quantity']) for x in seeed['bomItems'])-31)<1e-9)
    check('Seeed-style BOM: 5052 material recognized', seeed.get('materialHint')=='ALUMINUM ALLOY 5052', str(seeed.get('materialHint')))
    check('Seeed-style BOM: File Name accepted', seeed['bomItems'][0]['partNumber'].endswith('.step'))
    check('Seeed-style BOM: empty Image column does not shift File Name', seeed['bomItems'][0]['partNumber']=='02_Base_Reinforcement_Part.step')
    check('Seeed-style BOM: no false holes', len(seeed.get('holeRequirements',[]))==0)

    # Seeed public purchased-parts table: 19 rows, quantities with '+' denote
    # minimum required count. Numeric lower-bound sum = 268.
    purchased = analyze_csv(tmp, 'seeed_rebot_purchased_bom.csv', '''Name,Specification / Model,Quantity,Reference Price,Notes
Brushless motor,DM4310(V4),4,120 $/unit,
Brushless motor,DM4340P(V4),3,175 $/unit,
CAN-USB driver board,,1,15 $/unit,
Bearing,6707ZZ,1,13 $/unit,
Bearing,6803ZZ,3,13 $/unit,
Bearing,AXK5578,1,12 $/unit,
Linear rail,MGN9-170mm,1,23 $/unit,
Slider block,MGN9,2,10 $/unit,
Gear,"Module 1, boss type, 16 teeth, 6 mm bore",1,44 $/unit,
Silicone pad,30x9x2mm,1,10 $,
Screw,HM3-12mm screw,14+,,
Screw,HM3-25mm screw,14+,,
Screw,HM3-6mm screw,16+,,
Screw,HM4-75mm set screw,4+,,
Screw,KM3*12mm screw,30+,,
Screw,KM3*16mm screw,34+,,
Screw,KM3*7mm screw,76+,,
Screw,KM3*9mm screw,31+,,
Screw,KM3*8mm Socket Micro Profile Head Screw,31+,,
''')
    check('Seeed purchased BOM: 19/19 rows', len(purchased.get('bomItems',[]))==19, str(len(purchased.get('bomItems',[]))))
    check('Seeed purchased BOM: lower-bound quantity total 268', abs(sum(float(x['quantity']) for x in purchased['bomItems'])-268)<1e-9)
    check('Purchased BOM: M3/M4 model strings do not create machining holes', len(purchased.get('holeRequirements',[]))==0, str(purchased.get('holeRequirements')))

    # Unit parsing should be robust across common supplier BOM exports.
    check('mass unit grams -> kg', abs(mod._parse_mass_kg('125 g')-0.125)<1e-12)
    check('mass unit lb -> kg', abs(mod._parse_mass_kg('2 lb')-0.90718474)<1e-12)

# Cross-layer/static release contract (Linux container cannot compile Avalonia).
check('domain carries BOM mass fields', all(x in DOMAIN for x in ['MassKgEach','TotalMassKg','BomTotalMassKg','WeightSource']))
check('cost engine can select BOM mass', 'result.WeightSource = "BOM"' in COST and 'WEIGHT_BOM_DIFF' in COST)
check('cost engine rejects catastrophic BOM mass', all(x in COST for x in ['BOM_MASS_IMPLAUSIBLE','trustedBomWeight','suspiciousUrlMass','catastrophicStepRatio']))
check('merge never blindly sums different BOM totals', 'Nie sumowano ich automatycznie' in MERGE and 'max / Math.Max(0.001, min) <= 1.01' in MERGE)
check('diagnostic report exposes BOM mass/source', 'Masa z BOM:' in REPORT and 'Źródło masy:' in REPORT)
check('public BOM interop is in source release runner', 'run_r9_0_3_public_bom_interop.py' in RUNNER)
check('public BOM interop is in portable build gate', 'run_r9_0_3_public_bom_interop.py' in BUILD)

failed=[n for n,ok in checks if not ok]
print(f'\nSUMMARY PASS={len(checks)-len(failed)} FAIL={len(failed)}')
if failed:
    print('FAILED:', ', '.join(failed))
raise SystemExit(1 if failed else 0)
