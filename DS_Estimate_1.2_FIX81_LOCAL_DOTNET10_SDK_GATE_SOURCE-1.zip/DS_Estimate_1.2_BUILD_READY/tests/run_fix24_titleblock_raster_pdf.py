#!/usr/bin/env python3
"""FIX24 regression: scanned geometry with searchable title blocks gets OCR."""
from __future__ import annotations
import importlib.util
import io
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('dse_fix24_document', ROOT / 'engines/python/analyze_document.py')
document = importlib.util.module_from_spec(spec)
spec.loader.exec_module(document)
passed = failed = skipped = 0

def check(label, condition, detail=''):
    global passed, failed
    if condition:
        passed += 1
        print('PASS ', label)
    else:
        failed += 1
        print('FAIL ', label, detail)

class Rect:
    x0 = y0 = 0
    x1 = y1 = 100

class FakePage:
    rect = Rect()
    def __init__(self, boxes): self.boxes = boxes
    def get_image_info(self, xrefs=False): return [{'bbox': box} for box in self.boxes]

scan = FakePage([(5, 5, 95, 95)])
logo = FakePage([(0, 0, 20, 20)])
text = ('DRAWING: ASSEMBLY 1200-3000\nMATERIAL: -\nREVISION: A\nSCALE: 1:10\n'
        'CUSTOMER DOCUMENT AND TECHNICAL NOTES FOR MANUFACTURING COMPLEX\n')
check('title block length in target range', 120 <= len(text.strip()) < 900)
check('text-bearing raster drawing is selected', document.find_sparse_raster_pdf_pages([text], [scan]) == [0])
check('small logo is ignored', document.find_sparse_raster_pdf_pages([text], [logo]) == [])
check('60-percent photo does not trigger titleblock OCR',
      document.find_sparse_raster_pdf_pages([text], [FakePage([(0, 0, 60, 100)])]) == [])
check('Polish drawing titleblock recognized',
      document.find_sparse_raster_pdf_pages(['RYSUNEK: 2026-30\nMATERIAŁ: -\n' + 'x' * 125], [scan]) == [0])
check('German drawing titleblock recognized',
      document.find_sparse_raster_pdf_pages(['ZEICHNUNG: 2026-30\nWERKSTOFF: -\n' + 'x' * 125], [scan]) == [0])
check('generic image with same text length is ignored',
      document.find_sparse_raster_pdf_pages(['SPECIFICATION ' * 12], [scan]) == [])
check('long searchable technical page is ignored',
      document.find_sparse_raster_pdf_pages([text * 12], [scan]) == [])
check('old pure scan remains selected', document.find_sparse_raster_pdf_pages([''], [scan]) == [0])
check('text-only drawing is ignored', document.find_sparse_raster_pdf_pages([text], [FakePage([])]) == [])
check('OCR page cap unchanged', document.select_ocr_page_indices(10, 1, [7]) == [7])
check('cache namespace invalidated',
      'fix24-titleblock-raster-v1' in
      (ROOT / 'src/DSEstimate.Infrastructure/DocumentAnalyzers.cs').read_text(encoding='utf-8-sig'))
check('FIX24 wired into Windows release gate',
      'run_fix24_titleblock_raster_pdf.py' in
      (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='utf-8-sig'))
check('FIX24 wired into portable build gate',
      'run_fix24_titleblock_raster_pdf.py' in
      (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig'))

try:
    import pymupdf as fitz
    from PIL import Image
except ImportError:
    skipped += 1
    print('SKIP  real PDF integration (PyMuPDF/Pillow unavailable)')
else:
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / 'searchable-titleblock-scanned-geometry.pdf'
        image = Image.new('RGB', (100, 100), 'white')
        stream = io.BytesIO()
        image.save(stream, format='PNG')
        pdf = fitz.open()
        for i in range(10):
            page = pdf.new_page(width=400, height=400)
            if i == 7:
                page.insert_image(fitz.Rect(0, 0, 400, 400), stream=stream.getvalue())
                for n, line in enumerate(text.splitlines()):
                    page.insert_text((10, 20 + n * 12), line, fontsize=8)
            else:
                page.insert_text((10, 20), 'TECHNICAL SPECIFICATION ' * 12, fontsize=8)
        pdf.save(path)
        pdf.close()
        with fitz.open(path) as pdf:
            texts = [page.get_text('text') for page in pdf]
            found = document.find_sparse_raster_pdf_pages(texts, pdf)
            check('real PDF detects searchable title block + scanned drawing', found == [7], str(found))

        saved = {k: os.environ.get(k) for k in
                 ('DSE_SKIP_PDF_OCR', 'DSE_HISTORY_FAST_PDF', 'DSE_OCR_MAX_PAGES')}
        original_config = document.configure_tesseract
        original_lang = document.choose_ocr_languages
        original_ocr = document.run_technical_ocr
        try:
            for key in saved: os.environ.pop(key, None)
            os.environ['DSE_OCR_MAX_PAGES'] = '1'
            document.configure_tesseract = lambda module: ('fake-tesseract', '--psm 6')
            document.choose_ocr_languages = lambda module, config: ('eng', ['eng'])
            document.run_technical_ocr = lambda *args, **kwargs: ('S960QL', 1, 90., 90., [], [])
            result = document.analyze_pdf(path)
            warnings = '\n'.join(result['warnings'])
            check('OCR prioritizes page 8 under one-page cap', '(nr 8)' in warnings, warnings)
            check('OCR technical material is merged', result.get('materialHint') == 'S960QL', str(result.get('materialHint')))
            os.environ['DSE_SKIP_PDF_OCR'] = '1'
            skipped_result = document.analyze_pdf(path)
            check('fast path discloses skipped scanned page',
                  any('PDF_SCAN_PAGES_SKIPPED_FAST_PATH' in w and '8' in w for w in skipped_result['warnings']))
            os.environ.pop('DSE_SKIP_PDF_OCR')
            os.environ['DSE_HISTORY_FAST_PDF'] = '1'
            history_result = document.analyze_pdf(path)
            check('history fast path discloses skipped scanned page',
                  any('PDF_SCAN_PAGES_SKIPPED_HISTORY' in w and '8' in w for w in history_result['warnings']))
        finally:
            document.configure_tesseract = original_config
            document.choose_ocr_languages = original_lang
            document.run_technical_ocr = original_ocr
            for k, v in saved.items():
                if v is None: os.environ.pop(k, None)
                else: os.environ[k] = v

print(f'\nSUMMARY PASS={passed} FAIL={failed} SKIP={skipped}')
sys.exit(1 if failed else 0)
