#!/usr/bin/env python3
"""FIX29: exact, ambiguity-safe, informational drawing↔BOM evidence."""
from __future__ import annotations
import importlib.util
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('dse_fix29_document', ROOT / 'engines/python/analyze_document.py')
document = importlib.util.module_from_spec(spec)
spec.loader.exec_module(document)
passed = failed = skipped = 0
require_real_pdf = "--require-real-pdf" in sys.argv


def check(name, value):
    global passed, failed
    if value:
        passed += 1
        print('PASS', name)
    else:
        failed += 1
        print('FAIL', name)


def link(pages, source='test.pdf'):
    evidence = document._pdf_page_evidence(pages, source_file=source)
    return document._pdf_exact_drawing_bom_links(evidence)


draw = 'DRAWING NO\nPART-001\nMATERIAL: S355J2'
bom = 'POS DOKNR MENGE GEWICHT\nPART-001\n2 ST\n20 KG\nPART-002\n3 ST\n9 KG'
links, ambiguous = link([draw, bom])
check('exact ID across two sheets linked once', len(links) == 1 and links[0]['drawingNumber'] == 'PART-001')
check('link identifies drawing and BOM page', links[0]['drawingPageNumber'] == 1 and links[0]['bomPageNumber'] == 2)
check('link retains source filename', links[0]['sourceFile'] == 'test.pdf')
check('link carries diagnostic match type', links[0]['matchType'] == 'exact-within-pdf')
check('unique ID has no ambiguity', not ambiguous)
check('no fuzzy suffix matching', not link(['DRAWING: PART-001', bom.replace('PART-001', 'PART-001-A')])[0])
check('case insensitive exact matching', len(link(['DRAWING: part-001', bom])[0]) == 1)
check('punctuation not stripped', not link(['DRAWING: PART.001', bom])[0])
check('no match when BOM is absent', not link([draw])[0])
check('no match when drawing ID absent', not link([bom])[0])
check('multiple drawing pages are ambiguous', link([draw, draw, bom])[0] == [] and link([draw, draw, bom])[1] == ['PART-001'])
check('multiple BOM pages are ambiguous', link([draw, bom, bom])[0] == [] and link([draw, bom, bom])[1] == ['PART-001'])
check('multiple different matches sorted', [x['drawingNumber'] for x in link([
    'DRAWING: PART-002\nDRAWING: PART-001', bom])[0]] == ['PART-001', 'PART-002'])
check('empty evidence safe', document._pdf_exact_drawing_bom_links([]) == ([], []))

# Page-specific OCR must not leak across sheets; only actual OCR text on the
# correct sheet can supply the drawing number.
evidence = document._pdf_page_evidence(['', bom], {0: draw}, source_file='scan.pdf')
ocr_links, _ = document._pdf_exact_drawing_bom_links(evidence)
check('OCR-only drawing ID is linked to its own sheet', len(ocr_links) == 1 and ocr_links[0]['drawingPageNumber'] == 1)
check('OCR remains flagged in source evidence', evidence[0]['ocrApplied'] and evidence[0]['ocrTextPresent'])

try:
    import pymupdf as fitz
except ImportError as exc:
    if require_real_pdf:
        failed += 1
        print('FAIL real PDF required but PyMuPDF unavailable:', exc)
    else:
        skipped += 1
        print('SKIP real PDF:', exc)
else:
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / 'drawings-and-bom.pdf'
        pdf = fitz.open()
        for text in (draw, bom):
            page = pdf.new_page(width=595, height=842)
            page.insert_text((40, 50), text, fontsize=12)
        pdf.save(path)
        pdf.close()
        old = os.environ.get('DSE_SKIP_PDF_OCR')
        os.environ['DSE_SKIP_PDF_OCR'] = '1'
        try:
            result = document.analyze_pdf(path)
        finally:
            if old is None:
                os.environ.pop('DSE_SKIP_PDF_OCR', None)
            else:
                os.environ['DSE_SKIP_PDF_OCR'] = old
        real = result.get('drawingBomLinks', [])
        check('real two-page PDF creates one link', len(real) == 1)
        check('real PDF link pages correct', len(real) == 1 and real[0]['drawingPageNumber'] == 1 and real[0]['bomPageNumber'] == 2)
        check('legacy global signals remain', bool(result.get('materialHint')) and result.get('pdfPageCount') == 2)
        check('link does not inject cost or quantity', all('cost' not in x and 'quantity' not in x and 'materialHint' not in x for x in real))

# C# DTO and merge/report must preserve the evidence without assigning costs.
core = (ROOT / 'src/DSEstimate.Core/Domain.cs').read_text(encoding='utf-8-sig')
service = (ROOT / 'src/DSEstimate.Infrastructure/ProjectAnalysisService.cs').read_text(encoding='utf-8-sig')
report = (ROOT / 'src/DSEstimate.Infrastructure/DiagnosticReportService.cs').read_text(encoding='utf-8-sig')
check('C# link DTO exists', 'public sealed class DrawingBomLink' in core and 'public List<DrawingBomLink> DrawingBomLinks' in core)
check('C# merges links from each original PDF', 'items.SelectMany(x => x.DrawingBomLinks)' in service)
check('report labels links informational', 'Zgodne numery rysunków i pozycji BOM (wyłącznie informacyjne)' in report)
check('C# PDF cache version updated', 'fix29-pdf-exact-bom-links-v1' in (ROOT / 'src/DSEstimate.Infrastructure/DocumentAnalyzers.cs').read_text(encoding='utf-8-sig'))
check('Windows release gate includes FIX29', 'run_fix29_pdf_exact_bom_links.py' in (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='ascii'))
check('portable release gate includes FIX29', 'run_fix29_pdf_exact_bom_links.py' in (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig'))

print(f'\nSUMMARY PASS={passed} FAIL={failed} SKIP={skipped}')
sys.exit(1 if failed else 0)
