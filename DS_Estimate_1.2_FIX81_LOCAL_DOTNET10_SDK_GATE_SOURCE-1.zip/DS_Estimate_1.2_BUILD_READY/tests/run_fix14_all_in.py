from pathlib import Path
import ast, re, sys, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

def text(rel): return (ROOT/rel).read_text(encoding='utf-8-sig')
def check(name, cond, detail=''):
    global ok, bad
    if cond:
        ok += 1; print(f'PASS  {name}' + (f' :: {detail}' if detail else ''))
    else:
        bad += 1; print(f'FAIL  {name}' + (f' :: {detail}' if detail else ''))

ok=bad=0
domain=text('src/DSEstimate.Core/Domain.cs')
cost=text('src/DSEstimate.Core/CostEngine.cs')
auto=text('src/DSEstimate.Core/AutoQuoteEngine.cs')
adv=text('src/DSEstimate.Core/AdvancedCostEngines.cs')
intel=text('src/DSEstimate.Core/ProjectIntelligenceEngines.cs')
sanity=text('src/DSEstimate.Core/SanityCheckEngine.cs')
merge=text('src/DSEstimate.Infrastructure/ProjectAnalysisService.cs')
mass=text('src/DSEstimate.Infrastructure/HybridMassResolver.cs')
gov=text('src/DSEstimate.Infrastructure/ResourceGovernor.cs')
runner=text('src/DSEstimate.Infrastructure/PythonRunner.cs')
doc=text('src/DSEstimate.Infrastructure/DocumentAnalyzers.cs')
hist=text('src/DSEstimate.Infrastructure/HistoryImportService.cs')
crash=text('src/DSEstimate.Infrastructure/CrashDiagnosticService.cs')
report=text('src/DSEstimate.Infrastructure/DiagnosticReportService.cs')
excel=text('src/DSEstimate.Infrastructure/ExcelExportService.cs')
vm=text('src/DSEstimate.App/ViewModels/MainViewModel.cs')
ui=text('src/DSEstimate.App/Views/MainWindow.axaml')
py=text('engines/python/analyze_document.py')
release=text('RUN_FULL_RELEASE_TESTS.cmd')
build=text('BUILD_FULL_PORTABLE_ZIP.ps1')

check('resource governor exists', 'class ResourceGovernor' in gov)
check('resource governor uses physical memory on Windows', 'GlobalMemoryStatusEx' in gov and 'AvailablePhysicalBytes' in gov)
check('resource governor waits before heavy engine', 'WaitForHeadroomAsync' in runner and 'heavyEngine' in runner)
check('document engines globally bounded', 'DocumentEngineLock = new(2, 2)' in runner)
check('watchdog kills process tree', 'Kill(entireProcessTree: true)' in runner)
check('transient resource failure is not cached as document truth', 'RESOURCE_GOVERNOR' in doc and 'if (!transient)' in doc)

check('OCR streaming has no rendered_pages buffer', 'rendered_pages' not in py)
check('OCR megapixel ceiling', 'DSE_OCR_MAX_MEGAPIXELS' in py and 'max_megapixels' in py)
check('OCR per-pass timeout', 'DSE_TESSERACT_TIMEOUT_SECONDS' in py and '"timeout": timeout_seconds' in py)
check('history skips OCR by default safe path', 'DSE_HISTORY_FAST_PDF' in py and 'OCR pominięto' in py)
check('history max OCR pages fallback', 'DSE_OCR_MAX_PAGES' in py and 'history_safe' in py)
check('python parses', True)  # py_compile is run by the release wrapper/source validation below

check('history fast mode defaults true', 'bool fastMode = true' in hist and 'historyFastMode = true' in vm)
check('large history forces safe mode', 'projectFolders.Count >= 12' in hist and 'effectiveFastMode' in hist)
check('history cancellation token is real', '_historyScanCancellation.Token' in vm and 'cancellationToken.ThrowIfCancellationRequested' in hist)
check('history cancel command exists', 'CancelHistoryScanCommand' in ui and 'private void CancelHistoryScan()' in vm)
check('history snapshots release analysis graph', 'PersistPreparedSnapshot(candidate, project)' in hist and 'candidate.PreparedProject = null' in hist)
check('history cancellation cleans temporary imports', 'foreach (var pending in result.Candidates.Where(x => !x.Imported))' in hist)

check('crash package exists', 'class CrashDiagnosticService' in crash and 'ZipFile.Open' in crash)
check('crash package is source-free by design', 'contains no' in crash.lower() and 'analysis_summary.txt' in crash)
check('project crash invokes package', 'CrashDiagnosticService.Write(ex, "project-analysis"' in vm)
check('history crash invokes package', 'CrashDiagnosticService.Write(ex, "history-scan"' in vm)

check('hybrid mass domain', all(x in domain for x in ['HybridMassKg','HybridMassCoveragePercent','HybridMassProjectAuthoritative','HybridMassContributions']))
check('mass resolver exists', 'class HybridMassResolver' in mass)
check('mass priority BOM local', 'SourceKind = "BOM_MASS"' in mass)
check('mass priority drawing local', 'SourceKind = "DRAWING_MASS"' in mass)
check('mass priority STEP local', 'SourceKind = "STEP_LOCAL"' in mass)
check('mass from DXF area thickness', 'SourceKind = "DXF_AREA_THICKNESS"' in mass and 'ClosedProfileAreaMm2 * thickness.Value' in mass)
check('partial mass cannot unlock full offer', 'PARTIAL_ONLY' in mass and 'offerPriceAvailable = !materialBasisMissing && blocking == 0' in auto)
check('authoritative hybrid mass can become project mass', 'FIX14 rekonstrukcja BOM/DXF/STEP' in cost and 'reconstructedWeight' in cost)

check('partial material cost domain', 'RecognizedPartialMaterialCostPln' in domain)
check('partial material cost computed from family masses', 'BuildRecognizedPartialMaterialCost' in cost and 'HybridMassContributions' in cost)
check('partial material does not become material total silently', 'if (result.MaterialCostPln > 0 && result.HasWeight)' in cost)
check('autoquote exposes recognized cost', all(x in domain for x in ['RecognizedCostPln','RecognizedMaterialCostPln','RecognizedMaterialCoveragePercent','UnresolvedFamilyCount']))
check('autoquote says not determined instead of zero', 'RecommendedPriceDisplay' in domain and 'NIE WYZNACZONO' in domain)
check('UI renders display value', ui.count('RecommendedPriceDisplay') >= 3)
check('UI shows recognized range', 'RecognizedCostDisplay' in ui and 'HasRecognizedPartialCost' in ui)
check('Excel writes text instead of 0 offer', '"NIE WYZNACZONO"' in excel and 'RecognizedCostPln' in excel)

check('NDT per family domain', 'class NdtFamilySignal' in domain and 'NdtFamilySignals' in domain)
check('NDT family resolver', 'FIX14 NDT Scope Resolver' in merge)
check('quality cost uses scoped weld length', 'ScopedWeldLength' in adv and 'FIX14 scope MT' in adv and 'FIX14 scope UT' in adv)
check('unpriced NDT method remains external', 'unpricedMethods' in auto and 'requiresExternalRate: unpricedMethods.Count > 0' in auto)
check('paint zone domain', 'class PaintZoneSignal' in domain and 'PaintZoneSignals' in domain)
check('paint zones stay local', 'FIX14 Painting Zones' in merge)
check('paint model audits zones', 'zoneBasis' in cost and 'paintZoneClasses' in cost)

check('post-weld machining remains state-aware', 'POST_WELD_DRAWING' in cost and 'spawanie → CNC' in auto)
check('CNC programming clusters similar families', 'programmingClusterCount' in cost and 'klastrów' in cost)
check('CNC feature summary exposes clustering', 'klastry setup/program' in intel)
check('manipulation remains in weld/paint/assembly model', 'Manipulacja/obsługa' in cost and 'Fabrication Complexity' in cost)

check('customer revision letter parser', 'ALPHA_CUSTOMER' in merge and 'ZEZ|ZTL|ZTS' in merge)
check('sheet suffix not treated as revision comment', 'final _1/_2/_3 is a sheet/representation marker' in merge)
check('content dedupe retained', 'ContentDuplicates' in domain and 'DuplicateAliasCount' in domain)

check('sanity engine exists', 'class SanityCheckEngine' in sanity)
check('sanity mass scope', 'SANITY_MASS_SCOPE' in sanity)
check('sanity coating area', 'SANITY_SURFACE_TOO_LOW' in sanity)
check('sanity weld low', 'SANITY_WELD_TOO_LOW' in sanity)
check('sanity price per kg', 'SANITY_PRICE_PER_KG' in sanity)
check('sanity invoked before final autoquote', cost.find('SanityCheckEngine.Apply(result)') < cost.find('AutoQuoteEngine.Apply(result)', cost.find('SanityCheckEngine.Apply(result)')))

check('report audits FIX14 mass', 'FIX14 / REKONSTRUKCJA MASY I CZĘŚCIOWY KOSZT MATERIAŁU' in report)
check('report audits recognized cost', 'Koszt rozpoznanego zakresu' in report)
check('report audits NDT and paint zones', 'FIX14 / ZAKRES NDT I STREFY MALARSKIE' in report)
check('report audits sanity', 'FIX14 / SANITY CHECK' in report)
check('private export remains absent from UI', 'Pakiet prywatny' not in ui and 'PrivateAnalysisPack' not in ui)

try:
    ET.parse(ROOT/'src/DSEstimate.App/Views/MainWindow.axaml')
    check('MainWindow XAML parses', True)
except Exception as e:
    check('MainWindow XAML parses', False, str(e))

for name, src in [('domain',domain),('cost',cost),('auto',auto),('merge',merge),('history',hist),('runner',runner),('report',report),('crash',crash),('sanity',sanity)]:
    check(f'{name} braces balanced', src.count('{') == src.count('}'), f"{src.count('{')}/{src.count('}')}")

check('FIX14 wired into release gate', 'run_fix14_all_in.py' in release)
check('FIX14 wired into portable build gate', 'run_fix14_all_in.py' in build)

print(f'\nSUMMARY PASS={ok} FAIL={bad}')
sys.exit(1 if bad else 0)
