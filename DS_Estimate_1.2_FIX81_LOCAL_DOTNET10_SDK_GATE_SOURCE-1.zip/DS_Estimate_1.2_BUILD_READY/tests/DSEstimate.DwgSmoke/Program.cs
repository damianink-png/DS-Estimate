﻿using ACadSharp.IO;
using DSEstimate.Infrastructure;

if (args.Length != 1 || !File.Exists(args[0]))
{
    Console.Error.WriteLine("Usage: DSEstimate.DwgSmoke <sample.dwg>");
    return 2;
}

var source = Path.GetFullPath(args[0]);
using var converted = await new DwgConversionService().ConvertToDxfAsync(source);
if (!converted.Ok || string.IsNullOrWhiteSpace(converted.DxfPath) || !File.Exists(converted.DxfPath))
{
    Console.Error.WriteLine("DWG->DXF FAILED: " + string.Join(" | ", converted.Warnings));
    return 3;
}

try
{
    var dxf = DxfReader.Read(converted.DxfPath);
    var entityCount = dxf.Entities.Count();
    if (entityCount <= 0)
    {
        Console.Error.WriteLine("DWG->DXF FAILED: converted DXF contains no model-space entities.");
        return 4;
    }
    Console.WriteLine($"DWG_SMOKE_PASS source={Path.GetFileName(source)} dxfBytes={new FileInfo(converted.DxfPath).Length} entities={entityCount} engine={converted.Engine}");
    if (converted.Warnings.Count > 0)
        Console.WriteLine("DWG notifications: " + string.Join(" | ", converted.Warnings.Take(8)));
    return 0;
}
catch (Exception ex)
{
    Console.Error.WriteLine($"DWG->DXF FAILED: DxfReader cannot reopen conversion: {ex.GetType().Name}: {ex.Message}");
    return 5;
}
