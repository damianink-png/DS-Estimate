#!/usr/bin/env python3
from pathlib import Path
import ast
import importlib.util
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
passed = failed = 0


def check(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print("PASS ", name)
    else:
        failed += 1
        print("FAIL ", name, "::", detail)


engine_path = ROOT / "engines/python/analyze_document.py"
spec = importlib.util.spec_from_file_location("dse_fix19_document", engine_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

select = module.select_ocr_page_indices
check("empty PDF selection", select(0, 12) == [])
check("zero safety cap", select(10, 0) == [])
check("all short PDF pages", select(4, 12) == [0, 1, 2, 3])
check("single-page cap is deterministic", select(20, 1) == [0])

sample = select(100, 12)
check("long PDF respects cap", len(sample) == 12, str(sample))
check("long PDF includes first page", sample[0] == 0, str(sample))
check("long PDF includes last page", sample[-1] == 99, str(sample))
check("long PDF covers interior", len([x for x in sample if 0 < x < 99]) == 10, str(sample))
check("selection sorted and unique", sample == sorted(set(sample)), str(sample))

document_cs = (ROOT / "src/DSEstimate.Infrastructure/DocumentAnalyzers.cs").read_text(encoding="utf-8-sig")
check("document cache invalidated for FIX19", "fix19-doc-representative-ocr-v1" in document_cs)

step_source = (ROOT / "engines/python/analyze_step.py").read_text(encoding="utf-8-sig")
check("single normalize3 definition", len(re.findall(r"^def normalize3\(", step_source, re.MULTILINE)) == 1)

try:
    ast.parse(engine_path.read_text(encoding="utf-8-sig"))
    ast.parse(step_source)
    check("Python engines parse", True)
except SyntaxError as exc:
    check("Python engines parse", False, str(exc))

print(f"\nSUMMARY PASS={passed} FAIL={failed}")
sys.exit(1 if failed else 0)
