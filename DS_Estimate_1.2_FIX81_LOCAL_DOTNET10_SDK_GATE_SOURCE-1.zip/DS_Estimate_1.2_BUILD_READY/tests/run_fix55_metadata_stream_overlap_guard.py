#!/usr/bin/env python3
"""FIX55: reject overlapping CLR metadata streams (synthetic, not a .NET build)."""
from __future__ import annotations

import importlib.util
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(
    "dse_fix55_verify", ROOT / "tests/verify_dotnet_solution_outputs.py"
)
assert spec and spec.loader
verify = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verify)
checks: list[bool] = []


def check(label: str, condition: bool) -> None:
    checks.append(bool(condition))
    print(("PASS " if condition else "FAIL ") + label, flush=True)


def metadata_root(table=(0x60, 0x20), strings=(0x80, 0x10),
                  blob=(0x90, 0x10)) -> bytes:
    """Construct a bounded stream directory, with no real assembly IL."""
    data = bytearray(0x100)
    data[:4] = b"BSJB"
    struct.pack_into("<HHII", data, 4, 1, 1, 0, 12)
    data[16:28] = b"v4.0.30319\0\0"
    struct.pack_into("<HH", data, 28, 0, 3)
    for pos, name, (offset, size) in (
        (32, b"#~\0\0", table),
        (44, b"#Strings\0\0\0\0", strings),
        (64, b"#Blob\0\0\0", blob),
    ):
        struct.pack_into("<II", data, pos, offset, size)
        data[pos + 8:pos + 8 + len(name)] = name
    return bytes(data)


def accepted(**kwargs) -> bool:
    data = metadata_root(**kwargs)
    try:
        verify._verify_metadata_streams(data, 0, len(data))
    except verify.SolutionOutputError:
        return False
    return True


check("three disjoint adjacent metadata streams accepted", accepted())
check("metadata streams with gaps accepted", accepted(blob=(0xB0, 0x10)))
check("stream headers need not be sorted by data offset",
      accepted(table=(0xB0, 0x20), strings=(0x80, 0x10), blob=(0x90, 0x10)))
check("#Strings overlapping #~ rejected", not accepted(strings=(0x70, 0x10)))
check("#Blob overlapping #Strings rejected", not accepted(blob=(0x88, 0x10)))
check("#Blob contained in #~ rejected", not accepted(blob=(0x68, 0x10)))
check("identical ranges with distinct stream names rejected",
      not accepted(strings=(0x60, 0x20)))
check("one-byte overlap rejected", not accepted(strings=(0x7F, 0x10)))
check("out-of-bounds metadata stream rejected", not accepted(blob=(0xF8, 0x10)))
workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
check("Windows CI invokes real-output validator before FIX55 synthetic regression",
      workflow.index("python tests/verify_dotnet_solution_outputs.py") <
      workflow.index("python tests/run_fix55_metadata_stream_overlap_guard.py"))
check("Windows CI still requires xUnit TRX and real PDF gates",
      "--min-executed 60 --reject-skipped" in workflow and
      "--require-real-pdf" in workflow)
for name in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{name} includes FIX55", "run_fix55_metadata_stream_overlap_guard.py" in
          (ROOT / name).read_text(encoding="utf-8-sig"))
print(f"SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0", flush=True)
raise SystemExit(0 if all(checks) else 1)
