from pathlib import Path
import ast
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]


def text(relative_path):
    return (ROOT / relative_path).read_text(encoding="utf-8-sig")


def check(name, condition):
    global passed, failed
    if condition:
        passed += 1
        print("PASS ", name)
    else:
        failed += 1
        print("FAIL ", name)


passed = failed = 0
parametric = text("tests/run_r7_parametric.py")
regression = text("tests/run_r7_regression.py")
report = text("src/DSEstimate.Infrastructure/DiagnosticReportService.cs")
release = text("RUN_FULL_RELEASE_TESTS.cmd")
build = text("BUILD_FULL_PORTABLE_ZIP.ps1")


def probe_process_exit(expected_code):
    path = str((ROOT / "tests/run_r7_parametric.py").resolve())
    driver = f'''\nimport sys, types\nsys.modules["cadquery"] = types.ModuleType("cadquery")\nsys.modules["analyze_step"] = types.ModuleType("analyze_step")\npath = {path!r}\nsource = open(path, encoding="utf-8-sig").read()\nsource = source.replace("rc = main()", "rc = {expected_code}", 1)\nexec(compile(source, path, "exec"), {{"__name__": "__main__", "__file__": path}})\n'''
    return subprocess.run([sys.executable, "-c", driver,], check=False).returncode

check("parametric imports os", "import os" in parametric)
check("parametric keeps real PASS/FAIL status", "rc = main()" in parametric)
check("parametric flushes stdout and stderr", "sys.stdout.flush(); sys.stderr.flush()" in parametric)
check("parametric bypasses unstable OCP finalizers", "os._exit(rc)" in parametric)
check("parametric no longer exits through interpreter finalizers", "raise SystemExit(main())" not in parametric)
check("parametric uses established R7 shutdown pattern", "os._exit(rc)" in regression)
check("diagnostic identifies FIX16C", "FIX16C EMBEDDED PYTHON EXIT FIX" in report)
check("FIX16C wired into release gate", "run_fix16c_embedded_exit_guard.py" in release)
check("FIX16C wired into portable build gate", "run_fix16c_embedded_exit_guard.py" in build)
check("portable build reports native test exit code", "$testExit = $LASTEXITCODE" in build and "kod procesu:" in build)
check("embedded shutdown preserves PASS exit code 0", probe_process_exit(0) == 0)
check("embedded shutdown preserves real FAIL exit code 1", probe_process_exit(1) == 1)

try:
    ast.parse(parametric)
    check("parametric Python syntax", True)
except SyntaxError as ex:
    check(f"parametric Python syntax: {ex}", False)

print(f"\nSUMMARY PASS={passed} FAIL={failed}")
sys.exit(1 if failed else 0)
