#!/usr/bin/env python3
"""Create a tiny, deliberately non-production payload for compiling the launcher.

The launcher project validates that PayloadZip and PayloadHash exist at build
 time. This fixture permits CI to compile its C# code without publishing or
 creating a real portable application. Never use it to distribute DS Estimate.
"""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

MARKER = b"CI-ONLY LAUNCHER COMPILE FIXTURE. NOT A DS ESTIMATE RELEASE.\n"
ZIP_NAME = "ci-only-launcher-payload.zip"
HASH_NAME = "ci-only-launcher-payload.sha256"


def create_fixture(output_dir: Path) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = output_dir / ZIP_NAME
    digest_file = output_dir / HASH_NAME
    with ZipFile(archive, "w", compression=ZIP_DEFLATED) as zf:
        zf.writestr("NOT_A_RELEASE.txt", MARKER)
    digest_file.write_text(hashlib.sha256(archive.read_bytes()).hexdigest() + "\n", encoding="ascii")
    return archive, digest_file


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    archive, digest_file = create_fixture(args.output_dir)
    print(f"CI-ONLY launcher compilation fixture: {archive}")
    print(f"SHA256: {digest_file}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
