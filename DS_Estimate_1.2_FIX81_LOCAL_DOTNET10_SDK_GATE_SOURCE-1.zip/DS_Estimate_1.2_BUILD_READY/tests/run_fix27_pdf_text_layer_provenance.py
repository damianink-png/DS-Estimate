#!/usr/bin/env python3
"""FIX27: PDF page provenance must retain text extracted only by pypdf."""
from __future__ import annotations

import importlib.util
import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('dse_fix27_document', ROOT / 'engines/python/analyze_document.py')
document = importlib.util.module_from_spec(spec)
spec.loader.exec_module(document)
passed = failed = skipped = 0


def check(name, condition):
    global passed, failed
    if condition:
        passed += 1
        print('PASS', name)
    else:
        failed += 1
        print('FAIL', name)


# Unit tests run even on hosts without a PDF runtime.
check('pypdf-only page is retained', document._merge_pdf_page_text_layers(
    ['DRAWING: 120-200'], [''], [''], ['']) == ['DRAWING: 120-200'])
check('MuPDF-only page is retained', document._merge_pdf_page_text_layers(
    [''], ['MATERIAL: S960QL'], [''], ['']) == ['MATERIAL: S960QL'])
check('same page combines complementary sources', document._merge_pdf_page_text_layers(
    ['DRAWING: 120-200'], ['MATERIAL: S355J2'], ['ISO 5817'], ['']) ==
    ['DRAWING: 120-200\nMATERIAL: S355J2\nISO 5817'])
check('duplicate lines do not multiply', document._merge_pdf_page_text_layers(
    ['DRAWING: 120-200'], ['DRAWING: 120-200'], [''], ['']) == ['DRAWING: 120-200'])
check('mismatched page counts cannot shift pypdf evidence', document._merge_pdf_page_text_layers(
    ['DRAWING: 120-200', 'DRAWING: 120-201'], ['MATERIAL: S355J2'], [''], ['']) ==
    ['MATERIAL: S355J2'])
check('two pages cannot cross-contaminate', document._merge_pdf_page_text_layers(
    ['DRAWING: 120-200', 'DRAWING: 120-201'], ['MATERIAL: S355J2', 'MATERIAL: S960QL'], ['', ''], ['', '']) ==
    ['DRAWING: 120-200\nMATERIAL: S355J2', 'DRAWING: 120-201\nMATERIAL: S960QL'])

try:
    import pymupdf as fitz
    from pypdf import PdfReader
except ImportError as exc:
    skipped += 1
    print('SKIP real PDF integration:', exc)
else:
    with tempfile.TemporaryDirectory() as tmp:
        pdf_path = Path(tmp) / 'partial-extractor.pdf'
        pdf = fitz.open()
        texts = (
            'DRAWING: 120-200\nMATERIAL: S355J2',
            'DRAWING: 120-201\nMATERIAL: S960QL',
            'POS DOKNR MENGE GEWICHT\nPART-001\n2 ST\n20 KG',
        )
        for text in texts:
            page = pdf.new_page()
            page.insert_text((40, 50), text, fontsize=12)
        pdf.save(pdf_path)
        pdf.close()
        check('pypdf can extract all real pages', all(
            fragment in (PdfReader(str(pdf_path)).pages[i].extract_text() or '')
            for i, fragment in enumerate(('120-200', '120-201', 'PART-001'))))

        real_open = fitz.open
        real_doc = real_open(str(pdf_path))

        class PartialPage:
            def get_text(self, mode):
                return 'ISO 2768'  # MuPDF only recovers the general standard.

        class PartialDocument:
            page_count = 3
            def __iter__(self):
                return iter([PartialPage() for _ in range(3)])
            def close(self):
                real_doc.close()

        old_fast = os.environ.get('DSE_SKIP_PDF_OCR')
        os.environ['DSE_SKIP_PDF_OCR'] = '1'
        try:
            with patch.object(fitz, 'open', return_value=PartialDocument()), \
                 patch.object(document, '_mupdf_layout_text', return_value=''), \
                 patch.object(document, '_mupdf_titleblock_semantic_text', return_value=''), \
                 patch.object(document, 'find_sparse_raster_pdf_pages', return_value=[]):
                result = document.analyze_pdf(pdf_path)
        finally:
            if old_fast is None:
                os.environ.pop('DSE_SKIP_PDF_OCR', None)
            else:
                os.environ['DSE_SKIP_PDF_OCR'] = old_fast

        ev = result.get('pageEvidence', [])
        check('page evidence preserves pypdf-only drawing numbers',
              len(ev) == 3 and ev[0]['drawingNumbers'] == ['120-200'] and ev[1]['drawingNumbers'] == ['120-201'])
        check('page evidence preserves pypdf-only materials',
              len(ev) == 3 and ev[0]['materialHint'] == 'S355J2' and ev[1]['materialHint'] == 'S960QL')
        check('BOM stays on its original page',
              len(ev) == 3 and ev[2]['bomPartNumbers'] == ['PART-001'] and ev[0]['bomRowCount'] == ev[1]['bomRowCount'] == 0)
        check('global signals remain backwards-compatible', bool(result.get('findings')))

        # A page-count disagreement must not attach a BOM/material to the wrong
        # sheet, even though global extraction still contains the raw pypdf text.
        class ShortDocument:
            page_count = 2
            def __iter__(self):
                return iter([PartialPage() for _ in range(2)])
            def close(self):
                pass

        os.environ['DSE_SKIP_PDF_OCR'] = '1'
        try:
            with patch.object(fitz, 'open', return_value=ShortDocument()), \
                 patch.object(document, '_mupdf_layout_text', return_value=''), \
                 patch.object(document, '_mupdf_titleblock_semantic_text', return_value=''), \
                 patch.object(document, 'find_sparse_raster_pdf_pages', return_value=[]):
                mismatch = document.analyze_pdf(pdf_path)
            with patch.object(fitz, 'open', side_effect=RuntimeError('MuPDF unavailable')):
                pypdf_only = document.analyze_pdf(pdf_path)
        finally:
            if old_fast is None:
                os.environ.pop('DSE_SKIP_PDF_OCR', None)
            else:
                os.environ['DSE_SKIP_PDF_OCR'] = old_fast
        check('extractor page count mismatch is reported',
              any('PDF_PAGE_COUNT_MISMATCH' in w for w in mismatch.get('warnings', [])))
        check('mismatched pages are not assigned pypdf drawing numbers',
              not any(p['drawingNumbers'] for p in mismatch.get('pageEvidence', [])))
        check('pypdf page evidence survives MuPDF failure',
              [p['drawingNumbers'] for p in pypdf_only.get('pageEvidence', [])[:2]] ==
              [['120-200'], ['120-201']])

check('cache key invalidated', 'fix27-pdf-extractor-page-fusion-v1' in
      (ROOT / 'src/DSEstimate.Infrastructure/DocumentAnalyzers.cs').read_text(encoding='utf-8-sig'))
check('Windows release gate runs FIX27', 'run_fix27_pdf_text_layer_provenance.py' in
      (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='ascii'))
check('portable release gate runs FIX27', 'run_fix27_pdf_text_layer_provenance.py' in
      (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig'))

print(f'\nSUMMARY PASS={passed} FAIL={failed} SKIP={skipped}')
sys.exit(1 if failed else 0)
