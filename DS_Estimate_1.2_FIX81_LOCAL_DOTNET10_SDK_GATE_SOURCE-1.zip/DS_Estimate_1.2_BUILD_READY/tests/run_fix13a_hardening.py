#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name, cond, detail=''):
    ok=bool(cond); checks.append(ok); print(('PASS  ' if ok else 'FAIL  ')+name+(f' :: {detail}' if detail else ''))
def text(rel,enc='utf-8-sig'): return (ROOT/rel).read_text(encoding=enc)
domain=text('src/DSEstimate.Core/Domain.cs'); cost=text('src/DSEstimate.Core/CostEngine.cs'); vm=text('src/DSEstimate.App/ViewModels/MainViewModel.cs'); view=text('src/DSEstimate.App/Views/MainWindow.axaml'); cb=text('src/DSEstimate.App/Views/MainWindow.axaml.cs'); report=text('src/DSEstimate.Infrastructure/DiagnosticReportService.cs')
check('persistent override model', 'class ProcessManualOverride' in domain and 'ProcessOverrides' in domain)
check('automatic baseline model', all(x in domain for x in ['AutomaticEnabled','AutomaticHours','AutomaticRatePlnPerHour']))
check('origin AUTO DOC HISTORY MANUAL', all(x in domain for x in ['RĘCZNIE','HISTORIA','DOKUMENT','AUTO']))
check('manual edit clone preserves selective flag', 'ManualOverride = x.ManualOverride' in cost)
check('manual cost recalculation counts only manual rows', 'manualCount = edited.Count(x => x.ManualOverride)' in cost)
check('capture automatic baseline after history', vm.find('_analysisService.ApplyHistory') < vm.find('CaptureAutomaticProcessBaselines(result)'))
check('persisted overrides applied after automatic baseline', vm.find('CaptureAutomaticProcessBaselines(result)') < vm.find('ApplyPersistedProcessOverrides(result)'))
check('recalculate no transient override snapshot', 'manualProcessOverrides' not in vm)
check('recalculate preserves project overrides', 'Trwałe ręczne decyzje procesów zostały zachowane' in vm)
check('reset override command clears persisted state', 'ResetProcessOverridesAsync' in vm and '_project.ProcessOverrides.Clear()' in vm)
check('reset button uses reset command', 'ResetProcessOverridesCommand' in view)
check('process editor has source column', 'Text="ŹRÓDŁO"' in view and 'DecisionOrigin' in view)
check('toggle routed through viewmodel persistence', '_vm.RegisterProcessToggle(process)' in cb)
check('editor captures only differences', all(x in vm for x in ['enabledChanged = process.Enabled != process.AutomaticEnabled','hoursChanged = Math.Abs(process.Hours - process.AutomaticHours)','rateChanged = Math.Abs(process.RatePlnPerHour - process.AutomaticRatePlnPerHour)']))
check('resume state domain', 'class AnalysisResumeState' in domain and 'CompletedDocumentHashes' in domain)
check('analysis creates checkpoint', 'PersistAnalysisCheckpoint(force: true);' in vm and 'InProgress = true' in vm)
check('completed docs checkpoint by hash', 'CompletedDocumentHashes.Add(doc.ContentHash)' in vm)
check('checkpoint throttled', 'TimeSpan.FromSeconds(2)' in vm)
check('cancel keeps resumable state', 'WasInterrupted = true' in vm and 'ponowne LICZ użyje ich cache' in vm)
check('restored draft surfaces resume info', 'HasInterruptedAnalysis' in vm and 'ResumeSummary' in vm)
check('report audits overrides', 'FIX13A ręczne override procesów' in report)
check('report audits checkpoint', 'FIX13A checkpoint' in report)
try: ET.parse(ROOT/'src/DSEstimate.App/Views/MainWindow.axaml'); xmlok=True
except Exception: xmlok=False
check('MainWindow XAML parses', xmlok)
for n,b in [('domain',domain),('cost',cost),('vm',vm),('report',report),('codebehind',cb)]: check(n+' braces balanced',b.count('{')==b.count('}'),f"{b.count('{')}/{b.count('}')}")
print(f'\nSUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)}')
raise SystemExit(0 if all(checks) else 1)
