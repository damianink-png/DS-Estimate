#!/usr/bin/env python3
"""FIX28: drawing identifiers from CAD title blocks stay on their own PDF sheet."""
from __future__ import annotations

import importlib.util
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('dse_fix28_document', ROOT / 'engines/python/analyze_document.py')
document = importlib.util.module_from_spec(spec)
spec.loader.exec_module(document)
passed = failed = skipped = 0


def check(label, condition):
    global passed, failed
    if condition:
        passed += 1
        print('PASS', label)
    else:
        failed += 1
        print('FAIL', label)


def ids(text):
    evidence = document._pdf_page_evidence([text], source_file='drawing.pdf')
    return evidence[0]['drawingNumbers'] if evidence else []


check('original colon format retained', ids('DRAWING: 120-200') == ['120-200'])
check('original DWG format retained', ids('DWG NO: A-1234') == ['A-1234'])
check('drawing number separated by whitespace', ids('DRAWING NO 120-201') == ['120-201'])
check('drawing number in next titleblock row', ids('DRAWING NO\n120-202') == ['120-202'])
check('Polish number label', ids('NUMER RYSUNKU: ABC-203') == ['ABC-203'])
check('Polish abbreviated number label', ids('NR RYS.\nABC-204') == ['ABC-204'])
check('German titleblock number', ids('ZEICHNUNGS-NR.\nZ-205') == ['Z-205'])
check('numeric next-row ID requires >=5 digits', ids('DRAWING NO\n12345') == ['12345'])
check('CRLF titleblock rows', ids('DRAWING NO\r\n120-206\r\nMATERIAL: S355J2') == ['120-206'])
check('colon before next row', ids('DRAWING NO:\n120-207') == ['120-207'])
check('decimal dimension not a drawing ID', ids('DRAWING NO\n1200.5') == [])
check('next-row short dimension rejected', ids('DRAWING NO\n1200') == [])
check('next-row steel grade rejected', ids('DRAWING NO\nS355J2') == [])
check('next-row ISO standard rejected', ids('DRAWING NO\nISO 2768') == [])
check('next-row date rejected', ids('DRAWING NO\n2026-10-31') == [])
check('unlabelled BOM item not a drawing number', ids('POS DOKNR MENGE GEWICHT\nPART-001\n2 ST\n20 KG') == [])
check('same-page identifiers retain order and unique values', ids('DRAWING NO 120-201\nDRAWING: 120-200\nDRAWING NO\n120-201') == ['120-201', '120-200'])

pages = ['DRAWING NO\n120-201\nMATERIAL: S355J2',
         'NUMER RYSUNKU: ABC-203\nMATERIAL: S960QL',
         'POS DOKNR MENGE GEWICHT\nPART-001\n2 ST\n20 KG']
rows = document._pdf_page_evidence(pages, source_file='real.pdf')
check('page metadata does not cross sheets', [x['drawingNumbers'] for x in rows] == [['120-201'], ['ABC-203'], []])
check('page material hints remain separate', [x['materialHint'] for x in rows[:2]] == ['S355J2', 'S960QL'])
check('BOM remains on sheet 3', rows[2]['bomPartNumbers'] == ['PART-001'] and rows[0]['bomRowCount'] == rows[1]['bomRowCount'] == 0)

try:
    import pymupdf as fitz
except ImportError as exc:
    skipped += 1
    print('SKIP real PDF:', exc)
else:
    with tempfile.TemporaryDirectory() as temp:
        path = Path(temp) / 'titleblock-layouts.pdf'
        pdf = fitz.open()
        for text in pages:
            pdf.new_page(width=595, height=842).insert_text((45, 60), text, fontsize=12)
        pdf.save(path)
        pdf.close()
        previous = os.environ.get('DSE_SKIP_PDF_OCR')
        os.environ['DSE_SKIP_PDF_OCR'] = '1'
        try:
            result = document.analyze_pdf(path)
        finally:
            if previous is None:
                os.environ.pop('DSE_SKIP_PDF_OCR', None)
            else:
                os.environ['DSE_SKIP_PDF_OCR'] = previous
        real = result.get('pageEvidence', [])
        check('real PDF retains sheet count', result.get('pdfPageCount') == 3)
        check('real PDF keeps drawing numbers on proper sheets',
              len(real) == 3 and [r['drawingNumbers'] for r in real] == [['120-201'], ['ABC-203'], []])
        check('real PDF BOM still page-scoped',
              len(real) == 3 and real[2]['bomPartNumbers'] == ['PART-001'])

check('C# PDF cache invalidated', 'fix28-titleblock-drawing-id-v1' in
      (ROOT / 'src/DSEstimate.Infrastructure/DocumentAnalyzers.cs').read_text(encoding='utf-8-sig'))
check('Windows release gate includes FIX28', 'run_fix28_pdf_drawing_number_layout.py' in
      (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='ascii'))
check('portable release gate includes FIX28', 'run_fix28_pdf_drawing_number_layout.py' in
      (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig'))

print(f'\nSUMMARY PASS={passed} FAIL={failed} SKIP={skipped}')
sys.exit(1 if failed else 0)
