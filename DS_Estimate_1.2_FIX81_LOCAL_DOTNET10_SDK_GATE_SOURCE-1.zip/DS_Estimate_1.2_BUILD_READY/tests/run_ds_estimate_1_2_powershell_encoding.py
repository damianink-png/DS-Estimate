#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
passed = failed = 0

def check(name, cond, detail=''):
    global passed, failed
    if cond:
        passed += 1
        print('PASS ', name)
    else:
        failed += 1
        print('FAIL ', name, '::', detail)

ps_scripts = sorted(ROOT.rglob('*.ps1'))
check('PowerShell scripts found', bool(ps_scripts), str(ROOT))
for p in ps_scripts:
    b = p.read_bytes()
    # Windows PowerShell 5.1 treats UTF-8 without BOM as the active ANSI code page.
    # For scripts containing Polish text / Unicode punctuation this can even change
    # tokenization (e.g. mojibake smart quotes). Require BOM for every non-ASCII PS1.
    payload = b[3:] if b.startswith(b'\xef\xbb\xbf') else b
    has_non_ascii = any(x >= 0x80 for x in payload)
    if has_non_ascii:
        check(f'UTF-8 BOM: {p.relative_to(ROOT)}', b.startswith(b'\xef\xbb\xbf'))
    try:
        b.decode('utf-8-sig')
        check(f'UTF-8 decode: {p.relative_to(ROOT)}', True)
    except UnicodeDecodeError as exc:
        check(f'UTF-8 decode: {p.relative_to(ROOT)}', False, str(exc))

cmd = (ROOT/'BUILD_FULL_PORTABLE_ZIP.cmd').read_text(encoding='ascii')
check('CMD guards build PS1 BOM', '[PS ENCODING PASS] UTF-8 BOM' in cmd and '$b[0] -ne 239' in cmd)
release_cmd_bytes = (ROOT/'RUN_FULL_RELEASE_TESTS.cmd').read_bytes()
check('release CMD is BOM-free ASCII', not release_cmd_bytes.startswith(b'\xef\xbb\xbf') and all(x < 128 for x in release_cmd_bytes))

print(f'\nSUMMARY PASS={passed} FAIL={failed}')
raise SystemExit(1 if failed else 0)
