# Golden set FIX15

Każdy projekt ma katalog z `expected.json`. Po wygenerowaniu danych modelu zapisz obok `actual.json`.
Uruchom `python tests/tools/golden_metrics.py tests/golden`.
Raport pokazuje bias oraz MAPE osobno dla masy, materiału i godzin procesów.
Kalibracja kolejno: masa → materiał → cięcie/CNC → spawanie → montaż.
