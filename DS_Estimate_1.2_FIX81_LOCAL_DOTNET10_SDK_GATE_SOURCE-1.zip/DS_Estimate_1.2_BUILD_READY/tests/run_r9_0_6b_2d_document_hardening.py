﻿#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
import tempfile
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ENG = ROOT / "engines" / "python"
sys.path.insert(0, str(ENG))

from analyze_document import detect_structured_technical_signals, result_from_text, _mupdf_layout_text  # noqa: E402
from analyze_dxf import parse_with_ezdxf  # noqa: E402

PASS = 0
FAIL = 0

def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("PASS ", name)
    else:
        FAIL += 1
        print("FAIL ", name, detail)


def source(path):
    return (ROOT / path).read_text(encoding="utf-8-sig")

# 1) Realistic German ERP/BOM rows from the user's drawing layout.
erp = """DokNr Index   Menge Gewicht   ME GE
ZEZ 94763620012 L
1,000 ST
2.926,073 KG
ZEZ 94763657512 K
1,000 ST
2.916,971 KG
ZEZ 94763657412 E
1,000 ST
2.824,089 KG
ZTL 94749385540 J
1,960 M2
235,500 KG
ZEZ 94763614412 A
1,000 ST
19,515 KG
"""
sig = detect_structured_technical_signals(erp)
check("German ERP top mass 2926.073", abs((sig.get("documentMassKg") or 0) - 2926.073) < 1e-6)
check("German ERP rows recovered", len(sig.get("bomItems") or []) >= 5)
ztl = next((x for x in sig.get("bomItems", []) if str(x.get("partNumber", "")).startswith("ZTL")), None)
check("M2 column digit not swallowed by KG mass", ztl is not None and abs((ztl.get("totalMassKg") or 0) - 235.5) < 1e-6, str(ztl))

# 2) Split PDF/OCR callout: nominal diameter, deviation and GD&T on adjacent rows.
split = """4x Ø20
+0,025/+0,010
PARALLELITAET
0,05 A
ISO 2768-mK
"""
sig2 = detect_structured_technical_signals(split)
holes = sig2.get("holeRequirements") or []
check("split numeric tolerance binds to hole", any(abs((h.get("nominalDiameterMm") or 0)-20)<1e-6 and h.get("count")==4 and h.get("precisionMachined") for h in holes))
check("generic duplicate removed after precision binding", sum(1 for h in holes if abs((h.get("nominalDiameterMm") or 0)-20)<1e-6) == 1, str(holes))
check("one dimensional tolerance after window merge", len(sig2.get("dimensionalTolerances") or []) == 1, str(sig2.get("dimensionalTolerances")))
geo = sig2.get("geometricTolerances") or []
check("parallelism 0.05 A recovered", any(g.get("type")=="PARALLELISM" and abs((g.get("valueMm") or 0)-0.05)<1e-6 and g.get("datum")=="A" for g in geo), str(geo))
check("bare GD&T duplicate removed", len([g for g in geo if g.get("type")=="PARALLELISM"]) == 1, str(geo))

# 3) Plain hole callouts are detected but remain non-precision.
sig3 = detect_structured_technical_signals("6x Ø18 THRU")
plain = sig3.get("holeRequirements") or []
check("plain 6x diameter candidate", len(plain)==1 and plain[0].get("count")==6 and abs((plain[0].get("nominalDiameterMm") or 0)-18)<1e-6)
check("plain diameter does not pretend precision", plain and not plain[0].get("precisionMachined"))

# 4) Broader paint/weld wording.
paint_text = "OBERFLAECHENBEHANDLUNG: GRUNDIERUNG UND DECKLACK RAL 7035 ISO 12944 C4 SA 2.5"
sig4 = detect_structured_technical_signals(paint_text)
paint_result = result_from_text(paint_text)
check("German surface treatment triggers paint keyword", "PAINT" in (paint_result.get("keywords") or []))
check("paint RAL and prep retained", sig4.get("paintColour")=="RAL 7035" and sig4.get("surfacePreparation")=="SA 2.5")
sig5 = detect_structured_technical_signals("SCHWEISSNAHT a6 BEIDSEITIG ISO 2553 ISO 5817")
check("German weld drawing context", sig5.get("weldSizeMm")==6.0 and sig5.get("weldSideCount")==2)

# 5) MuPDF row-oriented text reconstructs table columns.
try:
    import pymupdf as fitz
    with tempfile.TemporaryDirectory(prefix="dse_r906b_pdf_") as td:
        pdf = Path(td) / "erp.pdf"
        doc = fitz.open()
        page = doc.new_page(width=600, height=300)
        page.insert_text((40, 40), "DokNr Index")
        page.insert_text((310, 40), "Menge Gewicht")
        page.insert_text((40, 80), "ZEZ 94763620012 L")
        page.insert_text((330, 80), "1,000 ST")
        page.insert_text((430, 80), "2.926,073 KG")
        doc.save(pdf)
        doc.close()
        rd = fitz.open(pdf)
        layout = _mupdf_layout_text(rd[0])
        rd.close()
        check("PDF layout row joins part qty weight", "ZEZ 94763620012 L" in layout and "1,000 ST" in layout and "2.926,073 KG" in layout, layout)
except Exception as exc:
    check("PDF layout row joins part qty weight", False, repr(exc))

# 6) Native DXF circle + diameter tolerance, no STEP required.
try:
    import ezdxf
    with tempfile.TemporaryDirectory(prefix="dse_r906b_dxf_") as td:
        path = Path(td) / "part.dxf"
        doc = ezdxf.new("R2010")
        doc.units = 4  # mm
        msp = doc.modelspace()
        msp.add_lwpolyline([(0,0),(100,0),(100,50),(0,50)], close=True, dxfattribs={"layer":"CUT"})
        msp.add_circle((20,20), 5, dxfattribs={"layer":"CUT"})
        msp.add_circle((40,20), 5, dxfattribs={"layer":"CUT"})
        ov = msp.add_diameter_dim(center=(20,20), radius=5, angle=45, override={"dimtol":1,"dimtp":0.02,"dimtm":0.01})
        ov.render()
        doc.saveas(path)
        d = parse_with_ezdxf(path)
        check("DXF circle candidates counted", d.get("geometryHoleCandidateCount")==2, str(d.get("geometryHoleCandidateCount")))
        check("DXF diameter tolerance becomes precision hole", any(h.get("precisionMachined") and abs((h.get("nominalDiameterMm") or 0)-10)<1e-6 for h in d.get("holeRequirements", [])), str(d.get("holeRequirements")))
        check("DXF closed area available for no-STEP coating fallback", (d.get("closedProfileAreaMm2") or 0) > 4000)
except Exception as exc:
    check("DXF circle candidates counted", False, repr(exc))
    check("DXF diameter tolerance becomes precision hole", False, repr(exc))
    check("DXF closed area available for no-STEP coating fallback", False, repr(exc))

# 7) Static contracts for ZIP-in-ZIP, duplicate names, CNC and UI visibility.
imp = source("src/DSEstimate.Infrastructure/ClientPackageImportService.cs")
vm = source("src/DSEstimate.App/ViewModels/MainViewModel.cs")
cost = source("src/DSEstimate.Core/CostEngine.cs")
domain = source("src/DSEstimate.Core/Domain.cs")
proj = source("src/DSEstimate.Infrastructure/ProjectAnalysisService.cs")
xaml = source("src/DSEstimate.App/Views/MainWindow.axaml")
docpy = source("engines/python/analyze_document.py")
dxfpy = source("engines/python/analyze_dxf.py")

check("nested ZIP recursion enabled", "MaxNestedZipDepth" in imp and "ExtractZip(result, nestedTarget" in imp and "NestedZipCount" in imp)
check("nested ZIP guarded by size and entry budgets", "ExtractionBudget" in imp and "MaxArchiveEntries" in imp and "budget.SeenBytes" in imp)
check("same visible filename deduplicated by SHA256", "DeduplicateByVisibleFileName" in imp and "SafeHash" in imp and "DuplicateNameCount" in imp)
check("different content same visible filename preserved", "[KONFLIKT" in vm and "ConflictingNameCount" in imp)
check("2D holes visible in result model", "EstimatedHoleCount2D" in domain and "DetectedHoleCount" in domain)
check("UI no longer shows STEP-only hole count", "Analysis.DetectedHoleCount" in xaml and "Analysis.Geometry.TotalHoleCount" not in xaml[xaml.find('Najważniejsze ustalenia'):xaml.find('Podobne projekty')])
check("UI shows precision and tolerance counts", "Analysis.PrecisionHoleCount" in xaml and "Analysis.DimensionalToleranceCount" in xaml and "Analysis.GeometricToleranceCount" in xaml)
check("UI exposes weight source", "Analysis.WeightSource" in xaml)
check("CNC uses drawing-only hole total", "EstimatedHoleCount2D" in cost and "drawingPrecisionEvidence" in cost and "Routing CNC wynika z PDF/DXF bez STEP" in cost)
check("painting has DXF and mass no-STEP fallbacks", "ClosedProfileAreaMm2" in cost and "0.025" in cost and "PAINT_AREA_MASS_ESTIMATE" in cost)
check("PDF uses coordinate layout reconstruction", "_mupdf_layout_text" in docpy and 'page.get_text("words")' in docpy)
check("PDF OCR has conditional table pass", "--psm 4" in docpy and "table_probe" in docpy)
check("DXF diameter DIMENSION is semantic", "dim_type == 3" in dxfpy and "DIAMETER Ø" in dxfpy)
check("DXF sparse outlined drawing OCR retained", "_recover_exploded_text_with_ocr" in dxfpy)
check("merge deduplicates tolerance representations", 'GroupBy(x => $"{x.Kind}|{x.PlusMm:0.###}|{x.MinusMm:0.###}|{x.SymmetricMm:0.###}"' in proj)
build = source("BUILD_FULL_PORTABLE_ZIP.ps1")
release = source("RUN_FULL_RELEASE_TESTS.cmd")
check("2D hardening is in portable build gate", "run_r9_0_6b_2d_document_hardening.py" in build)
check("2D hardening is in source release gate", "run_r9_0_6b_2d_document_hardening.py" in release)

try:
    ET.parse(ROOT / "src/DSEstimate.App/Views/MainWindow.axaml")
    check("MainWindow XML parses", True)
except Exception as exc:
    check("MainWindow XML parses", False, repr(exc))

print(f"\nSUMMARY PASS={PASS} FAIL={FAIL}")
sys.exit(1 if FAIL else 0)
