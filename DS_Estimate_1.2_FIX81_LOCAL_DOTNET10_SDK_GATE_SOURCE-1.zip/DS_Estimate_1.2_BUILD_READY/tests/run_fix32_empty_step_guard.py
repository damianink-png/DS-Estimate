#!/usr/bin/env python3
"""FIX32 static source-contract tests. NOT a .NET build or C# execution."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
read = lambda path: (root / path).read_text(encoding="utf-8-sig")
resolver = read("src/DSEstimate.Infrastructure/DrawingStepEvidenceResolver.cs")
cs_tests = read("tests/DSEstimate.Core.Tests/Fix32EmptyStepGuardTests.cs")
workflow = read(".github/workflows/ds-estimate-dotnet10.yml")
service = read("src/DSEstimate.Infrastructure/ProjectAnalysisService.cs")
checks = {
    "empty physical STEP file is excluded (static C#)": "file.Length > 0" in resolver and "HasNonEmptyFile(x.Path)" in resolver,
    "file metadata failure is handled conservatively (static C#)": all(x in resolver for x in ("catch (IOException)", "catch (UnauthorizedAccessException)", "catch (ArgumentException)")),
    "physical path identity remains enforced (static C#)": ".Select(x => Path.GetFileName(x.Path))" in resolver and "File.Exists(x.Path)" in resolver,
    "ambiguous candidates are still rejected (static C#)": "stepMatches.Count != 1" in resolver,
    "link is diagnostic only (static C#)": '"exact-pdf-bom-step-filename-only"' in resolver and "_cost" not in resolver,
    "cost engine is downstream and unchanged (static C#)": "var stepEvidence = DrawingStepEvidenceResolver.Resolve" in service and "var result = _cost.Build(" in service,
    "new C# tests include empty, nonempty and deleted file (not executed here)": all(x in cs_tests for x in ("Empty_step_placeholder", "Nonempty_step", "Disappeared_step")),
    "CI workflow configures .NET 10 and runs xUnit": "dotnet-version: '10.0.x'" in workflow and "dotnet test" in workflow and "dotnet build" in workflow,
    "CI saves TRX results even after failure": "actions/upload-artifact@v4" in workflow and "if: always()" in workflow,
    "Windows release gate includes FIX32": "run_fix32_empty_step_guard.py" in read("RUN_FULL_RELEASE_TESTS.cmd"),
    "portable release gate includes FIX32": "run_fix32_empty_step_guard.py" in read("BUILD_FULL_PORTABLE_ZIP.ps1"),
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " " + label, flush=True)
print(f"SUMMARY PASS={sum(checks.values())} FAIL={len(checks)-sum(checks.values())} SKIP=0")
raise SystemExit(0 if all(checks.values()) else 1)
