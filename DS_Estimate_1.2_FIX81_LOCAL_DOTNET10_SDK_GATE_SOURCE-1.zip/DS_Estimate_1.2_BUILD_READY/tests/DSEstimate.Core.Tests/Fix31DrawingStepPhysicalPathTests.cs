using DSEstimate.Core;
using DSEstimate.Infrastructure;
using Xunit;

namespace DSEstimate.Core.Tests;

/// <summary>FIX31: UI display aliases must never override physical STEP identity.</summary>
public sealed class Fix31DrawingStepPhysicalPathTests
{
    private static DrawingBomLink Link(string id) => new()
    {
        SourceFile = "package.pdf", DrawingNumber = id, BomPartNumber = id,
        DrawingPageNumber = 1, BomPageNumber = 2, MatchType = "exact-within-pdf"
    };

    private static ProjectDocument Step(string folder, string name)
    {
        var path = Path.Combine(folder, name);
        File.WriteAllText(path, "dummy file; filename-only resolver does not parse CAD");
        return new ProjectDocument
        {
            Path = path, Name = name, Kind = DocumentKind.Step,
            IsActiveRevision = true
        };
    }

    [Fact]
    public void Display_name_cannot_spoof_a_different_physical_step_file()
    {
        using var folder = new TempFolder();
        var physical = Step(folder.Path, "PART-002.step");
        physical.Name = "PART-001.step"; // UI alias is not the actual file.
        var result = DrawingStepEvidenceResolver.Resolve(
            [Link("PART-001"), Link("PART-002")], [physical]);
        var match = Assert.Single(result.Links);
        Assert.Equal("PART-002", match.DrawingNumber);
        Assert.Equal("PART-002.step", match.StepFile);
    }

    [Fact]
    public void Import_conflict_display_suffix_does_not_hide_a_unique_physical_step()
    {
        using var folder = new TempFolder();
        var physical = Step(folder.Path, "PART-001.step");
        physical.Name = "PART-001 [KONFLIKT 2].step";
        var match = Assert.Single(DrawingStepEvidenceResolver.Resolve(
            [Link("PART-001")], [physical]).Links);
        Assert.Equal("PART-001.step", match.StepFile);
    }

    [Fact]
    public void Same_physical_basename_in_two_folders_is_ambiguous_even_with_different_ui_names()
    {
        using var folder = new TempFolder();
        var firstDir = Directory.CreateDirectory(Path.Combine(folder.Path, "A"));
        var secondDir = Directory.CreateDirectory(Path.Combine(folder.Path, "B"));
        var first = Step(firstDir.FullName, "PART-001.step");
        var second = Step(secondDir.FullName, "PART-001.step");
        second.Name = "PART-001 [KONFLIKT 2].step";
        var result = DrawingStepEvidenceResolver.Resolve([Link("PART-001")], [first, second]);
        Assert.Empty(result.Links);
        Assert.Equal(new[] { "PART-001" }, result.AmbiguousIdentifiers);
    }

    [Fact]
    public void Display_step_extension_cannot_override_a_non_step_physical_path()
    {
        using var folder = new TempFolder();
        var fake = Step(folder.Path, "PART-001.txt");
        fake.Name = "PART-001.step";
        Assert.Empty(DrawingStepEvidenceResolver.Resolve(
            [Link("PART-001")], [fake]).Links);
    }

    private sealed class TempFolder : IDisposable
    {
        public string Path { get; } = Directory.CreateTempSubdirectory("dse-fix31-").FullName;
        public void Dispose() => Directory.Delete(Path, recursive: true);
    }
}
