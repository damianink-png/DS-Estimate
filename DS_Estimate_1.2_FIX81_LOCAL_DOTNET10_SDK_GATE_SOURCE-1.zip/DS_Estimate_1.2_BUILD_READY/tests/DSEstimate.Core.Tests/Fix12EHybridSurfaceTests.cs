using DSEstimate.Core;
using DSEstimate.Infrastructure;
using Xunit;

namespace DSEstimate.Core.Tests;

public sealed class Fix12EHybridSurfaceTests
{
    private static DocumentFamilyResolution Resolution(params string[] children)
    {
        var families = new HashSet<string>(children, StringComparer.OrdinalIgnoreCase) { "90000000001" };
        return new DocumentFamilyResolution
        {
            RootEntityKey = "90000000001",
            HasAuthoritativeRootBom = true,
            ScopeEnforced = true,
            ProductionFamilies = families,
            StepFamilyCount = 1,
            StepFamilyMatchCount = 1,
            DxfFamilyCount = children.Length,
            DxfFamilyMatchCount = children.Length,
            StepCoveragePartial = true
        };
    }

    [Fact]
    public void Surface_is_resolved_per_family_without_step_dxf_double_count()
    {
        var drawing = new DrawingIntelligence();
        drawing.BomItems.Add(new BomItemSignal { PartNumber = "90000000100", Quantity = 1 });
        drawing.BomItems.Add(new BomItemSignal { PartNumber = "90000000101", Quantity = 1 });
        var geometry = new GeometrySummary
        {
            Available = true,
            Parts =
            [
                new PartGroup
                {
                    SourceFile = "90000000100.step",
                    Classification = "Blacha / płyta",
                    Quantity = 1,
                    SurfaceMm2Each = 2_000_000
                }
            ]
        };
        var dxfs = new List<DxfSignals>
        {
            new() { SourceFile="90000000100.dxf", GeometryMeasurementReliable=true, ClosedProfileCount=1, ClosedProfileAreaMm2=900_000, CutLengthMm=4000 },
            new() { SourceFile="90000000101.dxf", GeometryMeasurementReliable=true, ClosedProfileCount=1, ClosedProfileAreaMm2=1_000_000, CutLengthMm=4000 }
        };

        HybridSurfaceAreaResolver.Apply(drawing, geometry, new List<DrawingIntelligence>(), dxfs, Resolution("90000000100", "90000000101"));

        Assert.Equal(4.0, drawing.HybridSurfaceAreaM2!.Value, 3); // STEP 2m² + DXF 2m²
        Assert.Equal(2, drawing.HybridSurfaceAreaContributions.Count);
        Assert.Contains(drawing.HybridSurfaceAreaContributions, x => x.FamilyKey == "90000000100" && x.SourceKind == "STEP");
        Assert.Contains(drawing.HybridSurfaceAreaContributions, x => x.FamilyKey == "90000000101" && x.SourceKind == "DXF");
    }

    [Fact]
    public void Dxf_surface_adds_edge_area_when_bom_thickness_is_known()
    {
        var drawing = new DrawingIntelligence();
        drawing.BomItems.Add(new BomItemSignal { PartNumber = "90000000100", Description = "PLATE t=10", Quantity = 2 });
        var dxf = new DxfSignals
        {
            SourceFile = "90000000100.dxf",
            GeometryMeasurementReliable = true,
            ClosedProfileCount = 1,
            ClosedProfileAreaMm2 = 1_000_000,
            CutLengthMm = 4_000
        };

        HybridSurfaceAreaResolver.Apply(drawing, new GeometrySummary(), new List<DrawingIntelligence>(), new[] { dxf }, Resolution("90000000100"));

        var c = Assert.Single(drawing.HybridSurfaceAreaContributions);
        Assert.Equal("DXF+THICKNESS", c.SourceKind);
        Assert.Equal(4.08, c.AreaM2, 3); // (2*1m² + 4m*0.01m) * qty2
    }

    [Fact]
    public void Partial_step_uses_hybrid_project_area_for_paint_not_local_step_area()
    {
        var geometry = new GeometrySummary
        {
            Available = true,
            SurfaceMm2 = 568_000,
            PaintableSurfaceMm2 = 568_000,
            ExposedSurfaceMm2 = 568_000,
            VolumeMm3 = 1_000_000,
            SolidCount = 1,
            UniquePartGroups = 1,
            FullyAnalyzedUniqueSolids = 1
        };
        var drawing = new DrawingIntelligence
        {
            MaterialHint = "S355",
            CorrosionClass = "C4",
            ResolvedFamilyScopeEnforced = true,
            ResolvedRootBomFamilyCount = 38,
            ResolvedStepFamilyMatchCount = 3,
            HybridSurfaceAreaM2 = 120,
            HybridSurfaceAreaConfidence = 82,
            HybridSurfaceAreaCoveragePercent = 89,
            HybridSurfaceAreaSource = "DXF 85%, STEP 15%"
        };

        var r = new CostEngine().Build(geometry, drawing, new DxfSignals(), 1000, new CostingSettings());

        Assert.Equal(120, r.Painting.PaintableAreaM2, 3);
        Assert.Contains("FIX12E hybrydowo", r.Painting.AreaSource);
        Assert.Contains(r.Risks, x => x.Code == "FIX12E_SURFACE_PARTIAL_COVERAGE");
    }

    [Fact]
    public void Missing_project_mass_never_becomes_recommended_offer_price()
    {
        var r = new AnalysisResult
        {
            ConfidencePercent = 60,
            RatesConfirmedByCompany = true,
            WeightKg = null,
            MaterialCostPln = 0,
            ProcessCostPln = 4215,
            CostTotalPln = 4215,
            TechnicalPricePln = 4594,
            FinalPricePln = 4594
        };
        r.Risks.Add(new RiskItem { Code="WEIGHT", Level=RiskLevel.High, Blocking=true, Title="Brak masy" });

        AutoQuoteEngine.Apply(r);

        Assert.Equal(0, r.AutoQuote.RecommendedPricePln);
        Assert.False(r.AutoQuote.IsPriceComplete);
        Assert.Contains("NIE WYZNACZONA", r.AutoQuote.PriceLabel);
        Assert.Contains("4215", r.AutoQuote.PriceCompletenessNote);
    }

    [Fact]
    public void Local_material_mix_does_not_count_as_project_conflict()
    {
        var r = new AnalysisResult
        {
            ConfidencePercent = 90,
            RatesConfirmedByCompany = true,
            WeightKg = 100,
            MaterialCostPln = 1000,
            CostTotalPln = 1500,
            FinalPricePln = 1700
        };
        r.Drawing.Conflicts.Add(new InformationConflict
        {
            Field = "Materiały — różne pozycje/rysunki",
            Values = "S690QL | S960QL",
            Level = RiskLevel.Low,
            IsLocalVariation = true
        });

        AutoQuoteEngine.Apply(r);

        Assert.Equal(0, r.AutoQuote.ConflictCount);
        Assert.DoesNotContain("konflikt", r.AutoQuote.MainAssumptions, StringComparison.OrdinalIgnoreCase);
    }
}
