using DSEstimate.Core;
using Xunit;

namespace DSEstimate.Core.Tests;

public class StagedAnalysisTests
{
    [Fact]
    public void Topology_alone_does_not_enable_cnc()
    {
        var geometry = new GeometrySummary
        {
            Available = true,
            SolidCount = 1,
            UniquePartGroups = 1,
            FullyAnalyzedUniqueSolids = 1,
            HoleAnalysisState = "complete",
            VolumeMm3 = 1_000_000,
            SurfaceMm2 = 100_000,
            Parts =
            [
                new PartGroup
                {
                    Quantity = 1,
                    FaceCount = 160,
                    CylindricalFaceCount = 20,
                    VolumeMm3Each = 1_000_000,
                    SurfaceMm2Each = 100_000,
                    Xmm = 100,
                    Ymm = 100,
                    Zmm = 100
                }
            ]
        };

        var result = new CostEngine().Build(geometry, new DrawingIntelligence(), new DxfSignals(), null, new CostingSettings());
        var cnc = result.Processes.Single(x => x.Code == "CNC");
        Assert.False(cnc.Enabled);
        Assert.Equal("NONE", cnc.Basis.Contains("Poziom dowodów CNC: NONE") ? "NONE" : "OTHER");
    }

    [Fact]
    public void Manual_paint_enable_recalculates_only_paint_model_from_cached_geometry()
    {
        var geometry = new GeometrySummary
        {
            Available = true,
            SolidCount = 1,
            UniquePartGroups = 1,
            FullyAnalyzedUniqueSolids = 1,
            HoleAnalysisState = "complete",
            VolumeMm3 = 2_000_000,
            SurfaceMm2 = 10_000_000,
            ExposedSurfaceMm2 = 9_000_000,
            PaintableSurfaceMm2 = 8_000_000,
            Parts = [new PartGroup { Quantity = 1, VolumeMm3Each = 2_000_000, SurfaceMm2Each = 10_000_000 }]
        };
        var settings = new CostingSettings();
        var engine = new CostEngine();
        var result = engine.Build(geometry, new DrawingIntelligence(), new DxfSignals(), null, settings);
        var beforeVolume = result.Geometry.VolumeMm3;
        var edited = result.Processes.Select(x => new ProcessEstimate
        {
            Code = x.Code, Name = x.Name, Enabled = x.Code == "SURF" || x.Enabled,
            Hours = x.Hours, RatePlnPerHour = x.RatePlnPerHour, BaseHours = x.BaseHours,
            CalibrationFactor = x.CalibrationFactor, WorkstationCode = x.WorkstationCode,
            WorkstationName = x.WorkstationName, Confidence = x.Confidence, Basis = x.Basis
        }).ToList();

        engine.ApplyManualProcessEdits(result, edited, settings);

        Assert.True(result.Painting.Enabled);
        Assert.True(result.Painting.CoatingRequired);
        Assert.True(result.Painting.PaintableAreaM2 > 0);
        Assert.True(result.Painting.PaintMaterialCostPln > 0);
        Assert.True(result.Processes.Single(x => x.Code == "SURF").Hours > 0);
        Assert.Equal(beforeVolume, result.Geometry.VolumeMm3);
    }

    [Fact]
    public void Hole_display_does_not_call_partial_zero_a_confirmed_zero()
    {
        var r = new AnalysisResult
        {
            Geometry = new GeometrySummary
            {
                Available = true,
                UniquePartGroups = 100,
                FullyAnalyzedUniqueSolids = 40,
                HoleAnalysisState = "partial",
                TotalHoleCount = 0
            }
        };
        Assert.Contains("nieustalone", r.DetectedHoleCountDisplay);

        r.Geometry.FullyAnalyzedUniqueSolids = 100;
        r.Geometry.HoleAnalysisState = "complete";
        Assert.Contains("potwierdzony brak", r.DetectedHoleCountDisplay);
    }
}
