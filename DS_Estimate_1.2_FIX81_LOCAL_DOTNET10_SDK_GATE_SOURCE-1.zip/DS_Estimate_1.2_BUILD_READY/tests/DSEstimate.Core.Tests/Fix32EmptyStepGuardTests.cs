using DSEstimate.Core;
using DSEstimate.Infrastructure;
using Xunit;

namespace DSEstimate.Core.Tests;

/// <summary>FIX32: filename-only evidence must not link empty or vanished files.</summary>
public sealed class Fix32EmptyStepGuardTests
{
    private static DrawingBomLink Link() => new()
    {
        SourceFile = "drawing.pdf", DrawingNumber = "PART-001", BomPartNumber = "PART-001",
        DrawingPageNumber = 1, BomPageNumber = 2, MatchType = "exact-within-pdf"
    };

    private static ProjectDocument Candidate(string path) => new()
    {
        Path = path, Name = "PART-001.step", Kind = DocumentKind.Step,
        IsActiveRevision = true
    };

    [Fact]
    public void Empty_step_placeholder_cannot_create_a_diagnostic_link()
    {
        using var folder = new TempFolder();
        var path = Path.Combine(folder.Path, "PART-001.step");
        File.WriteAllBytes(path, []);
        Assert.Empty(DrawingStepEvidenceResolver.Resolve([Link()], [Candidate(path)]).Links);
    }

    [Fact]
    public void Nonempty_step_remains_a_filename_only_diagnostic_candidate()
    {
        using var folder = new TempFolder();
        var path = Path.Combine(folder.Path, "PART-001.step");
        File.WriteAllText(path, "not a validated CAD model");
        var match = Assert.Single(DrawingStepEvidenceResolver.Resolve([Link()], [Candidate(path)]).Links);
        Assert.Equal("exact-pdf-bom-step-filename-only", match.MatchType);
    }

    [Fact]
    public void Disappeared_step_does_not_create_a_diagnostic_link()
    {
        using var folder = new TempFolder();
        var path = Path.Combine(folder.Path, "PART-001.step");
        File.WriteAllText(path, "temporary");
        File.Delete(path);
        Assert.Empty(DrawingStepEvidenceResolver.Resolve([Link()], [Candidate(path)]).Links);
    }

    private sealed class TempFolder : IDisposable
    {
        public string Path { get; } = Directory.CreateTempSubdirectory("dse-fix32-").FullName;
        public void Dispose() => Directory.Delete(Path, recursive: true);
    }
}
