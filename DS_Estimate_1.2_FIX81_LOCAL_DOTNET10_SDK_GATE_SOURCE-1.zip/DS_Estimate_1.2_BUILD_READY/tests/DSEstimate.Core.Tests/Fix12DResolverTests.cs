﻿using DSEstimate.Core;
using DSEstimate.Infrastructure;
using Xunit;

namespace DSEstimate.Core.Tests;

public sealed class Fix12DResolverTests
{
    private static DrawingIntelligence RootBom(int count = 12)
    {
        var root = new DrawingIntelligence { SourceFile = "STL_90000000001.pdf" };
        for (var i = 0; i < count; i++)
            root.BomItems.Add(new BomItemSignal
            {
                SourceFile = root.SourceFile,
                PartNumber = (90000000100L + i).ToString(),
                Quantity = 1,
                Material = i % 2 == 0 ? "S355" : "S690QL"
            });
        return root;
    }

    [Fact]
    public void Root_bom_limits_foreign_numbered_families_when_correlated()
    {
        var root = RootBom();
        var drawings = new List<DrawingIntelligence> { root };
        var dxfs = new List<DxfSignals>();
        for (var i = 0; i < 5; i++)
        {
            var id = (90000000100L + i).ToString();
            drawings.Add(new DrawingIntelligence { SourceFile = $"{id}_A_ZEZ_2.pdf" });
            dxfs.Add(new DxfSignals { SourceFile = $"{id}_A_ZEZ_1.dxf" });
        }
        drawings.Add(new DrawingIntelligence { SourceFile = "99999999999_X_ZEZ_2.pdf" });
        dxfs.Add(new DxfSignals { SourceFile = "99999999999_X_ZEZ_1.dxf" });

        var docs = new List<ProjectDocument>
        {
            new() { Name = "90000000100_A.step", Kind = DocumentKind.Step, IsActiveRevision = true }
        };
        var r = DocumentFamilyResolver.Resolve(drawings, dxfs, docs);

        Assert.True(r.HasAuthoritativeRootBom);
        Assert.True(r.ScopeEnforced);
        Assert.True(r.StepCoveragePartial);
        Assert.True(r.Allows("90000000100_A_ZEZ_2.pdf"));
        Assert.False(r.Allows("99999999999_X_ZEZ_2.pdf"));
    }

    [Fact]
    public void Weak_ocr_bom_is_audit_only_and_does_not_filter()
    {
        var root = RootBom();
        var drawings = new List<DrawingIntelligence>
        {
            root,
            new() { SourceFile = "99999999999_X_ZEZ_2.pdf" }
        };
        var r = DocumentFamilyResolver.Resolve(drawings, new List<DxfSignals>(), new List<ProjectDocument>());

        Assert.True(r.HasAuthoritativeRootBom);
        Assert.False(r.ScopeEnforced);
        Assert.False(r.StepCoveragePartial);
        Assert.True(r.Allows("99999999999_X_ZEZ_2.pdf"));
    }


    [Fact]
    public void Nested_authoritative_bom_expands_leaf_families()
    {
        var root = new DrawingIntelligence { SourceFile = "STL_90000001000.pdf" };
        root.BomItems.Add(new BomItemSignal { SourceFile = root.SourceFile, PartNumber = "90000002000", Quantity = 1 });
        root.BomItems.Add(new BomItemSignal { SourceFile = root.SourceFile, PartNumber = "90000003000", Quantity = 1 });
        root.BomItems.Add(new BomItemSignal { SourceFile = root.SourceFile, PartNumber = "90000004000", Quantity = 1 });

        var child = new DrawingIntelligence { SourceFile = "STL_90000002000.pdf" };
        for (var i = 0; i < 8; i++)
            child.BomItems.Add(new BomItemSignal { SourceFile = child.SourceFile, PartNumber = (90000002100L + i).ToString(), Quantity = 1 });

        var drawings = new List<DrawingIntelligence> { root, child };
        var dxfs = Enumerable.Range(0, 5)
            .Select(i => new DxfSignals { SourceFile = $"{90000002100L + i}_A_ZEZ_1.dxf" })
            .ToList();
        var r = DocumentFamilyResolver.Resolve(drawings, dxfs, new List<ProjectDocument>());

        Assert.Equal("90000001000", r.RootEntityKey);
        Assert.True(r.ProductionFamilies.Contains("90000002104"));
        Assert.True(r.ScopeEnforced);
        Assert.True(r.Allows("90000002104_A_ZEZ_2.pdf"));
    }

    [Fact]
    public void Routing_key_prefers_drawing_number_across_pdf_dxf_variants()
    {
        Assert.Equal("90000000100", DocumentFamilyResolver.RoutingKey("90000000100_C_ZEZ_1.dxf"));
        Assert.Equal("90000000100", DocumentFamilyResolver.RoutingKey("90000000100_C_ZEZ_2.pdf"));
    }
}
