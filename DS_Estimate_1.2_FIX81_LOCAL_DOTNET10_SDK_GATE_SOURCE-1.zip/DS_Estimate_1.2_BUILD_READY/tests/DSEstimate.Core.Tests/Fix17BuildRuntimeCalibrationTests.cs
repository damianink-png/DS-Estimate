using System.Security.Cryptography;
using System.Text;
using DSEstimate.Core;
using DSEstimate.Infrastructure;
using Xunit;

namespace DSEstimate.Core.Tests;

public sealed class Fix17BuildRuntimeCalibrationTests
{
    [Fact]
    public void Holdout_passes_when_training_factor_improves_unseen_projects()
    {
        var service = new HistoryImportService();
        var settings = ValidationSettings();
        var candidates = Enumerable.Range(0, 8)
            .Select(i => Candidate($"GOOD-{i}", modelCut: 10 + i, actualCut: (10 + i) * 1.2))
            .ToList();

        var report = service.BuildCalibrationValidation(candidates, settings);

        Assert.True(report.HasIndependentHoldout);
        Assert.True(report.Passed);
        Assert.False(report.BlocksProfileUpdate);
        Assert.True(report.ProposedMapePercent < report.BaselineMapePercent);
        Assert.Equal(2, report.ValidationProjects);
    }

    [Fact]
    public void Holdout_blocks_profile_when_training_factor_regresses_unseen_projects()
    {
        var service = new HistoryImportService();
        var settings = ValidationSettings();
        var keys = Enumerable.Range(0, 8).Select(i => $"BAD-{i}").ToList();
        var candidates = keys
            .Select((key, i) => Candidate(
                key,
                modelCut: 10 + i,
                actualCut: (10 + i) * (i >= 6 ? 2.0 : 0.7),
                calibrationDate: new DateTime(2026, 1, 1).AddDays(i)))
            .ToList();

        var report = service.BuildCalibrationValidation(candidates, settings);
        var beforeVersion = settings.CompanyProfileVersion;
        var profile = service.ApplyCompanyProfile(
            settings,
            candidates,
            service.BuildSuggestions(candidates, settings),
            [],
            []);

        Assert.True(report.BlocksProfileUpdate);
        Assert.False(profile.Applied);
        Assert.Equal(beforeVersion, settings.CompanyProfileVersion);
        Assert.Empty(settings.CompanyProcessFactors);
    }

    [Fact]
    public void Quote_readiness_exposes_blocking_mass_material_and_risks()
    {
        var result = new AnalysisResult
        {
            Material = "Nie rozpoznano",
            CostTotalPln = 120,
            FinalPricePln = 135,
            Risks =
            [
                new RiskItem { Code = "TEST_BLOCK", Title = "Brak danych", Blocking = true }
            ]
        };

        AutoQuoteEngine.Apply(result);

        Assert.True(result.AutoQuote.ReadinessItems.Single(x => x.Code == "MASS").IsBlocking);
        Assert.True(result.AutoQuote.ReadinessItems.Single(x => x.Code == "MATERIAL").IsBlocking);
        Assert.True(result.AutoQuote.ReadinessItems.Single(x => x.Code == "RISKS").IsBlocking);
        Assert.False(result.AutoQuote.HasRecommendedPrice);
    }

    [Fact]
    public void Quote_readiness_marks_unused_processes_as_not_applicable()
    {
        var result = new AnalysisResult
        {
            Material = "S355J2",
            WeightKg = 100,
            WeightSource = "BOM",
            MaterialCostPln = 700,
            CostTotalPln = 700,
            FinalPricePln = 784,
            RatesConfirmedByCompany = true,
            PricingProfileName = "Firmowy"
        };

        AutoQuoteEngine.Apply(result);

        Assert.Equal("GOTOWE", result.AutoQuote.ReadinessItems.Single(x => x.Code == "MASS").Status);
        Assert.Equal("GOTOWE", result.AutoQuote.ReadinessItems.Single(x => x.Code == "MATERIAL").Status);
        Assert.Equal("NIE DOTYCZY", result.AutoQuote.ReadinessItems.Single(x => x.Code == "CNC").Status);
    }

    [Fact]
    public void Quote_readiness_requires_review_when_material_cost_uses_unknown_grade()
    {
        var result = new AnalysisResult
        {
            Material = "Nie rozpoznano",
            WeightKg = 25,
            WeightSource = "STEP — gęstość założona",
            MaterialCostPln = 175,
            CostTotalPln = 175,
            FinalPricePln = 196,
            RatesConfirmedByCompany = true
        };

        AutoQuoteEngine.Apply(result);

        var material = result.AutoQuote.ReadinessItems.Single(x => x.Code == "MATERIAL");
        Assert.Equal("SPRAWDŹ", material.Status);
        Assert.True(material.NeedsReview);
    }

    private static CostingSettings ValidationSettings() => new()
    {
        CalibrationValidationEnabled = true,
        CalibrationValidationMinimumProjects = 6,
        CalibrationValidationHoldoutPercent = 25,
        CalibrationValidationMaxRegressionPercentPoints = 2,
        AutoCalibrationEnabled = true,
        AutoCalibrationMinSamples = 2,
        AutoCalibrationMinFactor = 0.5,
        AutoCalibrationMaxFactor = 2.5
    };

    private static HistoryImportCandidate Candidate(string key, double modelCut, double actualCut, DateTime calibrationDate = default) => new()
    {
        SourceKey = key,
        CalibrationDate = calibrationDate,
        Imported = true,
        Status = "Historia",
        ModelCutHours = modelCut,
        ActualCutHours = actualCut
    };
}
