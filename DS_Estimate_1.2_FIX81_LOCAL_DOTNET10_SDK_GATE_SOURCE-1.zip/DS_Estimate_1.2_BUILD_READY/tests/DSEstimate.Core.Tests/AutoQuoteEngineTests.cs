﻿using DSEstimate.Core;
using Xunit;

namespace DSEstimate.Core.Tests;

public class AutoQuoteEngineTests
{
    private static AnalysisResult BaseResult() => new()
    {
        ConfidencePercent = 92,
        RatesConfirmedByCompany = true,
        WeightKg = 250,
        MaterialCostPln = 8_000,
        ProcessCostPln = 12_000,
        CostTotalPln = 20_000,
        TechnicalPricePln = 26_000,
        FinalPricePln = 26_000
    };

    [Fact]
    public void Price_band_always_brackets_the_recommended_price()
    {
        var r = BaseResult();

        AutoQuoteEngine.Apply(r);

        Assert.True(r.AutoQuote.PriceLowPln <= r.AutoQuote.RecommendedPricePln);
        Assert.True(r.AutoQuote.RecommendedPricePln <= r.AutoQuote.PriceHighPln);
        Assert.True(r.AutoQuote.PriceLowPln >= 0);
    }

    [Fact]
    public void Status_is_one_of_the_three_supported_values()
    {
        var r = BaseResult();

        AutoQuoteEngine.Apply(r);

        Assert.Contains(r.AutoQuote.Status, new[] { "GOTOWA", "WSTĘPNA", "NIEPEŁNA", "WYMAGA UWAGI" });
    }

    [Fact]
    public void Blocking_risk_forces_attention_status()
    {
        var r = BaseResult();
        r.Risks.Add(new RiskItem { Code = "BLOCK", Level = RiskLevel.Critical, Blocking = true, Title = "Brak danych" });

        AutoQuoteEngine.Apply(r);

        Assert.Equal("WYMAGA UWAGI", r.AutoQuote.Status);
        Assert.True(r.AutoQuote.BlockingIssueCount > 0);
    }

    [Fact]
    public void Unconfirmed_company_rates_never_produce_a_ready_quote()
    {
        var r = BaseResult();
        r.RatesConfirmedByCompany = false;

        AutoQuoteEngine.Apply(r);

        Assert.NotEqual("GOTOWA", r.AutoQuote.Status);
        Assert.Equal("STAWKI ROBOCZE", r.AutoQuote.RatesStatus);
    }

    [Fact]
    public void Uncertainty_drivers_are_reported_for_audit()
    {
        var r = BaseResult();
        r.RatesConfirmedByCompany = false;
        r.ConfidencePercent = 60;

        AutoQuoteEngine.Apply(r);

        Assert.False(string.IsNullOrWhiteSpace(r.AutoQuote.UncertaintyDrivers));
    }

    [Fact]
    public void Per_kg_metrics_stay_finite_without_weight()
    {
        var r = BaseResult();
        r.WeightKg = null;

        AutoQuoteEngine.Apply(r);

        Assert.Equal(0d, r.AutoQuote.CostPerKg);
        Assert.Equal(0d, r.AutoQuote.PricePerKg);
    }

    [Fact]
    public void Historical_reference_difference_is_relative_to_history()
    {
        var r = BaseResult();
        r.HistoricalPricePln = 20_000;
        r.FinalPricePln = 25_000;

        AutoQuoteEngine.Apply(r);

        Assert.True(r.AutoQuote.HasHistoricalReference);
        Assert.Equal(25.0, r.AutoQuote.HistoricalDifferencePercent!.Value, 3);
    }
}
