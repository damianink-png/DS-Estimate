using DSEstimate.Core;
using DSEstimate.Infrastructure;
using Xunit;

namespace DSEstimate.Core.Tests;

public sealed class Fix30DrawingStepEvidenceTests
{
    private static DrawingBomLink Link(string id, string pdf = "package.pdf") => new()
    {
        SourceFile = pdf, DrawingNumber = id, BomPartNumber = id,
        DrawingPageNumber = 1, BomPageNumber = 2, MatchType = "exact-within-pdf"
    };

    private static ProjectDocument Step(string folder, string name, bool create = true)
    {
        var path = Path.Combine(folder, name);
        if (create) File.WriteAllText(path, "dummy STEP filename; no CAD parsing in this test");
        return new ProjectDocument
        {
            Path = path, Name = name, Kind = DocumentKind.Step,
            IsActiveRevision = true
        };
    }

    [Fact]
    public void Unique_exact_id_links_to_existing_step_filename_without_price_authority()
    {
        using var folder = new TempFolder();
        var result = DrawingStepEvidenceResolver.Resolve(
            [Link("PART-001")], [Step(folder.Path, "part-001.STEP")]);
        var match = Assert.Single(result.Links);
        Assert.Equal("package.pdf", match.SourcePdf);
        Assert.Equal("PART-001", match.DrawingNumber);
        Assert.Equal("part-001.STEP", match.StepFile);
        Assert.Equal("exact-pdf-bom-step-filename-only", match.MatchType);
        Assert.Empty(result.AmbiguousIdentifiers);
    }

    [Fact]
    public void Near_matches_are_not_merged_and_missing_or_excluded_steps_are_ignored()
    {
        using var folder = new TempFolder();
        var excluded = Step(folder.Path, "PART-001.step");
        excluded.ExcludeFromAnalysis = true;
        var inactive = Step(folder.Path, "PART-002.step");
        inactive.IsActiveRevision = false;
        var result = DrawingStepEvidenceResolver.Resolve(
            [Link("PART-001"), Link("PART-002"), Link("PART-003")],
            [excluded, inactive, Step(folder.Path, "PART-003-A.step"),
             Step(folder.Path, "PART-003.stp", create: false)]);
        Assert.Empty(result.Links);
    }

    [Fact]
    public void Repeated_pdf_ids_and_duplicate_step_candidates_are_ambiguous()
    {
        using var folder = new TempFolder();
        var step = Step(folder.Path, "PART-001.step");
        var other = Step(folder.Path, "PART-002.step");
        var duplicate = Step(folder.Path, "PART-002.stp");
        var result = DrawingStepEvidenceResolver.Resolve(
            [Link("PART-001", "a.pdf"), Link("PART-001", "b.pdf"), Link("PART-002")],
            [step, other, duplicate]);
        Assert.Empty(result.Links);
        Assert.Equal(new[] { "PART-001", "PART-002" }, result.AmbiguousIdentifiers);
    }

    [Fact]
    public void Unverified_pdf_bom_matches_cannot_become_step_links()
    {
        using var folder = new TempFolder();
        var wrong = Link("PART-001");
        wrong.MatchType = "fuzzy";
        var mismatch = Link("PART-001");
        mismatch.BomPartNumber = "PART-002";
        Assert.Empty(DrawingStepEvidenceResolver.Resolve(
            [wrong, mismatch], [Step(folder.Path, "PART-001.step")]).Links);
    }

    private sealed class TempFolder : IDisposable
    {
        public string Path { get; } = Directory.CreateTempSubdirectory("dse-fix30-").FullName;
        public void Dispose() => Directory.Delete(Path, recursive: true);
    }
}
