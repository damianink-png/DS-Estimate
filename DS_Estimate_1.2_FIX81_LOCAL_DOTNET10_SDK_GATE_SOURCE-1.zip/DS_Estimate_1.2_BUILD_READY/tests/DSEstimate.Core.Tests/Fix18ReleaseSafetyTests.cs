using DSEstimate.Core;
using DSEstimate.Infrastructure;
using Xunit;

namespace DSEstimate.Core.Tests;

public sealed class Fix18ReleaseSafetyTests
{
    [Fact]
    public void Chronological_holdout_keeps_revision_family_together()
    {
        var service = new HistoryImportService();
        var settings = ValidationSettings();
        var candidates = Enumerable.Range(0, 6)
            .Select(i => Candidate($"OLD-{i}", new DateTime(2026, 1, 1).AddDays(i), 1.2))
            .Concat(new[]
            {
                Candidate("PART-77-REV-A", new DateTime(2026, 2, 1), 1.2, "ACME", "PART-77-REV-A"),
                Candidate("PART-77-REV-B", new DateTime(2026, 2, 2), 1.2, "ACME", "PART-77-REV-B")
            })
            .ToList();

        var report = service.BuildCalibrationValidation(candidates, settings);

        Assert.True(report.HasIndependentHoldout);
        Assert.Equal(2, report.ValidationProjects);
        Assert.Equal(1, report.ValidationGroups);
        Assert.Equal(6, report.TrainingProjects);
    }

    [Fact]
    public void Chronological_holdout_uses_newest_projects()
    {
        var service = new HistoryImportService();
        var settings = ValidationSettings();
        var candidates = Enumerable.Range(0, 8)
            .Select(i => Candidate(
                $"JOB-{i}",
                new DateTime(2026, 1, 1).AddDays(i),
                i >= 6 ? 2.0 : 0.7))
            .ToList();

        var report = service.BuildCalibrationValidation(candidates, settings);

        Assert.True(report.HasIndependentHoldout);
        Assert.True(report.BlocksProfileUpdate);
    }

    [Fact]
    public void Rolling_backtest_activates_for_twenty_projects()
    {
        var service = new HistoryImportService();
        var settings = ValidationSettings();
        var candidates = Enumerable.Range(0, 20)
            .Select(i => Candidate($"ROLL-{i}", new DateTime(2025, 1, 1).AddDays(i), 1.15))
            .ToList();

        var report = service.BuildCalibrationValidation(candidates, settings);

        Assert.Equal(3, report.RollingFoldCount);
        Assert.True(report.RollingProposedMapePercent < report.RollingBaselineMapePercent);
    }

    [Fact]
    public void Incomplete_offer_needs_state_bound_audited_exception()
    {
        var service = new QuoteReleaseService();
        var settings = new CostingSettings { RatesConfirmedByCompany = false };
        var project = new QuoteProject
        {
            Analysis = new AnalysisResult
            {
                RatesConfirmedByCompany = false,
                AutoQuote = new AutoQuoteSummary
                {
                    IsPriceComplete = false,
                    ReadinessItems = [new QuoteReadinessItem { Code = "RATES", Label = "Stawki", Status = "BRAK" }]
                }
            }
        };

        Assert.False(service.Evaluate(project, settings).CanExport);
        var approved = service.ApproveOverride(project, settings, "Klient potwierdził zakres bez stawki zewnętrznej.");
        Assert.True(approved.CanExport);
        Assert.True(approved.UsesOverride);

        settings.MarkupPercent += 1;
        Assert.False(service.Evaluate(project, settings).CanExport);
    }

    [Fact]
    public void Complete_offer_freezes_reproducible_snapshot()
    {
        var service = new QuoteReleaseService();
        var settings = new CostingSettings();
        var project = new QuoteProject
        {
            Analysis = new AnalysisResult
            {
                RatesConfirmedByCompany = true,
                AutoQuote = new AutoQuoteSummary
                {
                    RecommendedPricePln = 1250,
                    IsPriceComplete = true,
                    ReadinessItems = [new QuoteReadinessItem { Code = "MASS", Label = "Masa", Status = "GOTOWE" }]
                }
            }
        };
        project.Analysis!.ReleaseSettingsHash = service.ComputeSettingsHash(settings);

        var snapshot = service.FreezeForExport(project, settings);

        Assert.Equal("STANDARD", snapshot.ReleaseMode);
        Assert.Equal(64, snapshot.Fingerprint.Length);
        Assert.Equal(snapshot.Fingerprint, service.Evaluate(project, settings).Fingerprint);
    }

    [Fact]
    public void Firm_golden_set_waits_for_real_minimum_and_reports_tail_error()
    {
        var service = new FirmGoldenSetService();
        var waiting = service.Evaluate(new FirmGoldenSetDocument());
        Assert.Equal("OCZEKUJE", waiting.Status);
        Assert.False(waiting.Passed);

        var document = new FirmGoldenSetDocument
        {
            Id = "COMPANY-2026-Q3",
            Projects = Enumerable.Range(0, 20).Select(i => new FirmGoldenSetCase
            {
                ProjectId = $"P-{i}",
                ProjectClass = "WELDED",
                CompletedAt = new DateTime(2026, 1, 1).AddDays(i),
                ActualPricePln = 1000,
                PredictedPricePln = i >= 17 ? 1500 : 1000,
                ActualHours = 10,
                PredictedHours = 10,
                EvidenceHash = $"HASH-{i}"
            }).ToList()
        };
        var report = service.Evaluate(document);

        Assert.Equal(20, report.ProjectCount);
        Assert.Equal(50.0, report.PriceP90Percent, 6);
        Assert.Equal("BLOKADA", report.Status);
    }

    private static CostingSettings ValidationSettings() => new()
    {
        CalibrationValidationEnabled = true,
        CalibrationValidationMinimumProjects = 6,
        CalibrationValidationHoldoutPercent = 25,
        CalibrationValidationMaxRegressionPercentPoints = 2,
        AutoCalibrationEnabled = true,
        AutoCalibrationMinSamples = 2,
        AutoCalibrationMinFactor = 0.5,
        AutoCalibrationMaxFactor = 2.5
    };

    private static HistoryImportCandidate Candidate(
        string key,
        DateTime date,
        double actualFactor,
        string customer = "",
        string drawing = "") => new()
    {
        SourceKey = key,
        ProjectName = key,
        Customer = customer,
        DrawingNumber = drawing,
        CalibrationDate = date,
        Imported = true,
        Status = "Historia",
        ModelCutHours = 10,
        ActualCutHours = 10 * actualFactor
    };
}
