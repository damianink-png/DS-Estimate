using DSEstimate.Core;
using Xunit;

namespace DSEstimate.Core.Tests;

public class Fix13HistoricalIntelligenceTests
{
    [Fact]
    public void Hierarchical_material_breakdown_prefers_leaf_mass_and_does_not_double_count_parent()
    {
        var r = new AnalysisResult
        {
            WeightKg = 100,
            WeightSource = "BOM",
            Material = "S355",
            Drawing = new DrawingIntelligence
            {
                BomItems =
                [
                    new BomItemSignal { PartNumber="ASM", Description="Złożenie", Quantity=1, Level=1, Material="S355", TotalMassKg=100 },
                    new BomItemSignal { PartNumber="P1", Description="Blacha 10", Quantity=1, Level=2, Material="S355", TotalMassKg=40 },
                    new BomItemSignal { PartNumber="P2", Description="Blacha 12", Quantity=1, Level=2, Material="S690QL", TotalMassKg=60 }
                ]
            }
        };

        var built = MaterialBreakdownEngine.Build(r);

        Assert.Equal(100, built.Materials.Sum(x => x.MassKg), 3);
        Assert.Equal(40, built.Materials.Single(x => x.Material == "S355").MassKg, 3);
        Assert.Equal(60, built.Materials.Single(x => x.Material == "S690QL").MassKg, 3);
    }

    [Theory]
    [InlineData("RHS 100x100x5", "RHS/SHS")]
    [InlineData("HEB 300", "DWUTEOWNIK")]
    [InlineData("Blacha 20", "BLACHA")]
    [InlineData("Rura 88.9x5", "RURA")]
    [InlineData("Odkuwka", "ODKUWKA")]
    public void Semi_finished_classifier_understands_common_manufacturing_stock(string text, string expected)
    {
        Assert.Equal(expected, MaterialBreakdownEngine.ClassifySemiFinished(text));
    }

    [Fact]
    public void Similar_completed_projects_calibrate_combined_weld_and_assembly_without_learning_fake_split()
    {
        var current = new AnalysisResult
        {
            Processes =
            [
                new ProcessEstimate { Code="WELD", Name="Spawanie", Enabled=true, Hours=10, BaseHours=10, RatePlnPerHour=200 },
                new ProcessEstimate { Code="ASSY", Name="Montaż", Enabled=true, Hours=10, BaseHours=10, RatePlnPerHour=200 }
            ]
        };
        QuoteProject Old(double actual3401)
        {
            var p = new QuoteProject
            {
                Analysis = new AnalysisResult
                {
                    Processes =
                    [
                        new ProcessEstimate { Code="WELD", Enabled=true, Hours=10, BaseHours=10 },
                        new ProcessEstimate { Code="ASSY", Enabled=true, Hours=10, BaseHours=10 }
                    ]
                }
            };
            p.Actuals.SskHours["3401"] = actual3401;
            return p;
        }
        var h1 = Old(30);
        var h2 = Old(32);
        var similar = new List<SimilarProject>
        {
            new() { ProjectId=h1.Id, SimilarityPercent=92 },
            new() { ProjectId=h2.Id, SimilarityPercent=86 }
        };

        new CostEngine().ApplySimilarityAwareCalibration(current, [h1,h2], similar, new CostingSettings());

        var weld = current.Processes.Single(x => x.Code == "WELD");
        var assy = current.Processes.Single(x => x.Code == "ASSY");
        Assert.True(current.HistoricalCalibration.Applied);
        Assert.True(weld.CalibrationFactor > 1.0);
        Assert.Equal(weld.CalibrationFactor, assy.CalibrationFactor, 6);
        Assert.Equal(2, current.HistoricalCalibration.ProcessAdjustments.Count);
    }

    [Fact]
    public void Historical_calibration_never_overrides_manual_process_decision()
    {
        var current = new AnalysisResult
        {
            Processes =
            [
                new ProcessEstimate { Code="WELD", Name="Spawanie", Enabled=true, ManualOverride=true, Hours=7, BaseHours=7, RatePlnPerHour=200 },
                new ProcessEstimate { Code="ASSY", Name="Montaż", Enabled=true, Hours=10, BaseHours=10, RatePlnPerHour=200 }
            ]
        };
        var h1 = new QuoteProject { Analysis = new AnalysisResult { Processes=[new ProcessEstimate { Code="WELD", Enabled=true, Hours=10, BaseHours=10 }, new ProcessEstimate { Code="ASSY", Enabled=true, Hours=10, BaseHours=10 }] } };
        var h2 = new QuoteProject { Analysis = new AnalysisResult { Processes=[new ProcessEstimate { Code="WELD", Enabled=true, Hours=10, BaseHours=10 }, new ProcessEstimate { Code="ASSY", Enabled=true, Hours=10, BaseHours=10 }] } };
        h1.Actuals.SskHours["3401"] = 35;
        h2.Actuals.SskHours["3401"] = 36;
        var similar = new List<SimilarProject> { new() { ProjectId=h1.Id, SimilarityPercent=90 }, new() { ProjectId=h2.Id, SimilarityPercent=88 } };

        new CostEngine().ApplySimilarityAwareCalibration(current, [h1,h2], similar, new CostingSettings());

        Assert.Equal(7, current.Processes.Single(x => x.Code == "WELD").Hours, 6);
        Assert.Equal(1.0, current.Processes.Single(x => x.Code == "WELD").CalibrationFactor, 6);
    }

    [Fact]
    public void Cnc_feature_summary_keeps_operation_types_separate()
    {
        var r = new AnalysisResult
        {
            Geometry = new GeometrySummary
            {
                UniquePartGroups = 1,
                FullyAnalyzedUniqueSolids = 1,
                TotalBevelFaces = 6,
                Parts =
                [
                    new PartGroup
                    {
                        Quantity = 2,
                        Holes =
                        [
                            new HoleFeature { Count=1, RequiresDrill=true, RequiresCnc=true },
                            new HoleFeature { Count=2, RequiresDrill=true, RequiresReam=true, ReamedLikely=true },
                            new HoleFeature { Count=1, RequiresDrill=true, RequiresTap=true, ThreadCode="M12" },
                            new HoleFeature { Count=1, RequiresBore=true, CounterboreLikely=true }
                        ]
                    }
                ]
            }
        };

        var s = CncFeatureSummaryEngine.Build(r);

        Assert.True(s.DrilledHoleCount >= 8);
        Assert.True(s.ReamedHoleCount >= 4);
        Assert.True(s.ThreadedHoleCount >= 2);
        Assert.True(s.BoredHoleCount >= 2);
        Assert.True(s.SecondaryOperationCount >= 2);
        Assert.True(s.Confidence >= 70);
    }
}
