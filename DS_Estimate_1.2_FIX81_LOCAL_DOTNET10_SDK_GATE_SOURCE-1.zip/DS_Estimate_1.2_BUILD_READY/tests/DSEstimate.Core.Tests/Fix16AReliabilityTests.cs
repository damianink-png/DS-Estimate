using DSEstimate.Core;
using Xunit;

namespace DSEstimate.Core.Tests;

public sealed class Fix16AReliabilityTests
{
    [Fact]
    public void Calibration_keys_are_case_insensitive_and_material_factor_is_cost_weighted()
    {
        var result = new AnalysisResult
        {
            MaterialCostPln = 100,
            Processes =
            [
                new ProcessEstimate { Code = "WELD", Enabled = true, Hours = 10, Basis = "model" }
            ],
            MaterialBreakdown =
            [
                new MaterialBreakdownItem { Material = "S355J2", MassKg = 100 },
                new MaterialBreakdownItem { Material = "S690QL", MassKg = 100 }
            ]
        };
        var settings = new CostingSettings
        {
            MaterialPricePlnKg = 5,
            MaterialPriceOverridesPlnKg = new Dictionary<string, double>
            {
                ["S355"] = 5,
                ["S690"] = 15
            },
            RuntimeCalibration = new CalibrationProfile
            {
                Version = "case-test",
                EffectiveFrom = DateTime.Today,
                GoldenSetId = "golden-case",
                ChangeReason = "regression",
                ProcessMultipliers = new Dictionary<string, double> { ["weld"] = 1.2 },
                MaterialMultipliers = new Dictionary<string, double>
                {
                    ["s355"] = 1.0,
                    ["s690"] = 2.0
                }
            }
        };

        CalibrationLayer.Apply(result, settings);

        Assert.Equal(12, result.Processes[0].Hours, 6);
        Assert.Equal(175, result.MaterialCostPln, 6);
        Assert.Equal(1.75, result.ExternalCalibration.MaterialFactor, 6);
    }

    [Fact]
    public void Null_multiplier_maps_are_treated_as_neutral()
    {
        var result = new AnalysisResult
        {
            MaterialCostPln = 100,
            Processes = [new ProcessEstimate { Code = "CUT", Enabled = true, Hours = 2, Basis = "model" }]
        };
        var settings = new CostingSettings
        {
            RuntimeCalibration = new CalibrationProfile
            {
                Version = "null-map-test",
                EffectiveFrom = DateTime.Today,
                ProcessMultipliers = null!,
                MaterialMultipliers = null!
            }
        };

        CalibrationLayer.Apply(result, settings);

        Assert.False(result.ExternalCalibration.Rejected);
        Assert.Equal(2, result.Processes[0].Hours, 6);
        Assert.Equal(100, result.MaterialCostPln, 6);
    }

    [Fact]
    public void What_if_is_finite_and_uses_the_same_signed_markup_as_the_quote()
    {
        var result = new AnalysisResult
        {
            CostTotalPln = 1000,
            MaterialCostPln = 500,
            ProcessCostPln = 300,
            AppliedMarkupPercent = -10,
            AppliedWhatIfMaterialPriceChangePercent = 20,
            AppliedWhatIfProcessTimeChangePercent = double.NaN,
            AutoQuote = new AutoQuoteSummary
            {
                RecommendedPricePln = 900,
                P50PricePln = 900,
                IsPriceComplete = true
            }
        };

        QuoteScenarioEngine.Apply(result);

        var material = result.QuoteScenarios.Single(x => x.Code == "MATERIAL");
        var process = result.QuoteScenarios.Single(x => x.Code == "PROCESS");
        Assert.Equal(990, material.PricePln, 6);
        Assert.Equal(0, process.DeltaCostPln, 6);
        Assert.All(result.QuoteScenarios, x =>
        {
            Assert.True(double.IsFinite(x.CostPln));
            Assert.True(double.IsFinite(x.PricePln));
        });
    }

    [Fact]
    public void German_edge_note_does_not_enable_bending()
    {
        var result = new AnalysisResult
        {
            Drawing = new DrawingIntelligence { Findings = ["Kanten entgraten"] }
        };

        SheetMetalReadinessEngine.Apply(result);

        Assert.False(result.SheetMetal.RequiresBending);
        Assert.DoesNotContain(result.Risks, x => x.Code == "BENDING_UNPRICED");
    }
}
