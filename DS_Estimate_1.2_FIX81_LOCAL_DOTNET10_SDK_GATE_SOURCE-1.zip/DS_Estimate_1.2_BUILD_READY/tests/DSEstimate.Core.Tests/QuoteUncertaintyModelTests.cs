using DSEstimate.Core;
using Xunit;

namespace DSEstimate.Core.Tests;

/// <summary>
/// Testy zachowania (nie tekstu kodu) modelu niepewności 1.0.1.
/// </summary>
public class QuoteUncertaintyModelTests
{
    private static AnalysisResult CleanResult() => new()
    {
        ConfidencePercent = 95,
        RatesConfirmedByCompany = true,
        WeightKg = 120,
        CostTotalPln = 10_000,
        MaterialCostPln = 4_000,
        FinalPricePln = 13_000
    };

    [Fact]
    public void Clean_project_lands_on_the_minimum_band()
    {
        var result = QuoteUncertaintyModel.Evaluate(CleanResult());

        Assert.Equal(QuoteUncertaintyModel.MinUncertaintyPercent, result.UncertaintyPercent, 3);
        Assert.True(result.LowFactor < 1.0);
        Assert.True(result.HighFactor > 1.0);
    }

    [Fact]
    public void Uncertainty_is_always_inside_the_declared_band()
    {
        var r = CleanResult();
        r.ConfidencePercent = 0;
        r.RatesConfirmedByCompany = false;
        for (var i = 0; i < 40; i++)
            r.Risks.Add(new RiskItem { Code = $"R{i}", Level = RiskLevel.Critical, Blocking = true });

        var result = QuoteUncertaintyModel.Evaluate(r);

        Assert.InRange(
            result.UncertaintyPercent,
            QuoteUncertaintyModel.MinUncertaintyPercent,
            QuoteUncertaintyModel.MaxUncertaintyPercent);
    }

    [Fact]
    public void Blocking_risk_widens_the_band()
    {
        var clean = QuoteUncertaintyModel.Evaluate(CleanResult());

        var risky = CleanResult();
        risky.Risks.Add(new RiskItem { Code = "X", Level = RiskLevel.High, Blocking = true });
        var withRisk = QuoteUncertaintyModel.Evaluate(risky);

        Assert.True(withRisk.UncertaintyPercent > clean.UncertaintyPercent);
        Assert.True(withRisk.HighFactor > clean.HighFactor);
    }

    [Fact]
    public void Missing_weight_is_never_treated_as_certain()
    {
        var r = CleanResult();
        r.WeightKg = null;

        var result = QuoteUncertaintyModel.Evaluate(r);

        Assert.True(result.UncertaintyPercent > QuoteUncertaintyModel.MinUncertaintyPercent);
        Assert.Contains(result.Drivers, x => x.Name.Contains("masa"));
    }

    [Fact]
    public void Assumed_density_matters_more_when_material_dominates_the_cost()
    {
        var lowMaterial = CleanResult();
        lowMaterial.DensityAssumed = true;
        lowMaterial.MaterialCostPln = 500;

        var highMaterial = CleanResult();
        highMaterial.DensityAssumed = true;
        highMaterial.MaterialCostPln = 9_000;

        Assert.True(
            QuoteUncertaintyModel.Evaluate(highMaterial).UncertaintyPercent >
            QuoteUncertaintyModel.Evaluate(lowMaterial).UncertaintyPercent);
    }

    [Fact]
    public void Unpriced_external_operations_widen_the_band()
    {
        var r = CleanResult();
        r.AutoRoute.Add(new AutoRouteStep { Code = "GALV", Name = "Cynkowanie", RequiresExternalRate = true });

        Assert.True(
            QuoteUncertaintyModel.Evaluate(r).UncertaintyPercent >
            QuoteUncertaintyModel.Evaluate(CleanResult()).UncertaintyPercent);
    }

    [Fact]
    public void Ambiguous_revisions_weigh_more_than_clearly_selected_ones()
    {
        var clear = CleanResult();
        clear.Package.MultipleRevisionsDetected = true;
        clear.Package.RevisionSelectionConfident = true;

        var ambiguous = CleanResult();
        ambiguous.Package.MultipleRevisionsDetected = true;
        ambiguous.Package.RevisionSelectionConfident = false;

        Assert.True(
            QuoteUncertaintyModel.Evaluate(ambiguous).UncertaintyPercent >
            QuoteUncertaintyModel.Evaluate(clear).UncertaintyPercent);
    }

    [Fact]
    public void Drivers_sum_up_to_the_unclamped_uncertainty()
    {
        var r = CleanResult();
        r.ConfidencePercent = 70;
        r.RatesConfirmedByCompany = false;

        var result = QuoteUncertaintyModel.Evaluate(r);
        var expected = QuoteUncertaintyModel.MinUncertaintyPercent +
                       result.Drivers.Sum(x => x.ContributionPercentPoints);

        Assert.Equal(expected, result.UncertaintyPercent, 3);
        Assert.NotEqual("Brak istotnych czynników niepewności.", result.DriversText);
    }

    [Fact]
    public void Extreme_estimated_nesting_widens_material_uncertainty()
    {
        var clean = CleanResult();
        var risky = CleanResult();
        risky.Nesting = new NestingEstimate { Available = true, MaterialFactor = 2.4, Confidence = 52 };
        risky.Risks.Add(new RiskItem { Code = "NESTING_HIGH_FACTOR", Level = RiskLevel.Medium });

        Assert.True(
            QuoteUncertaintyModel.Evaluate(risky).UncertaintyPercent >
            QuoteUncertaintyModel.Evaluate(clean).UncertaintyPercent);
    }
}
