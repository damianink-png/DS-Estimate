using DSEstimate.Core;
using Xunit;

namespace DSEstimate.Core.Tests;

public class Fix12BCostRealityTests
{
    [Fact]
    public void Extreme_bbox_nesting_is_diagnostic_not_material_price_multiplier()
    {
        var geometry = new GeometrySummary
        {
            Available = true,
            SolidCount = 1,
            UniquePartGroups = 1,
            FullyAnalyzedUniqueSolids = 1,
            VolumeMm3 = 1_000_000,
            Parts =
            [
                new PartGroup
                {
                    Name = "Plate",
                    Classification = "Blacha / płyta",
                    Quantity = 1,
                    Xmm = 1000, Ymm = 1000, Zmm = 10,
                    VolumeMm3Each = 1_000_000,
                    SurfaceMm2Each = 2_000_000
                }
            ]
        };
        var settings = new CostingSettings { MaterialPricePlnKg = 7, MaterialWastePercent = 4 };
        var r = new CostEngine().Build(geometry, new DrawingIntelligence { MaterialHint = "S355" }, new DxfSignals(), null, settings);

        Assert.True(r.Nesting.Available);
        Assert.True(r.Nesting.MaterialFactor > settings.NestingPriceAuthorityMaxFactor);
        Assert.False(r.Nesting.UsedForMaterialCost);
        Assert.Equal(r.WeightKg!.Value * 7 * 1.04, r.MaterialCostPln, 2);
    }

    [Fact]
    public void Unknown_scope_document_mass_does_not_conflict_with_project_step_mass()
    {
        var geometry = new GeometrySummary
        {
            Available = true,
            SolidCount = 2,
            UniquePartGroups = 2,
            FullyAnalyzedUniqueSolids = 2,
            VolumeMm3 = 200_000_000
        };
        var drawing = new DrawingIntelligence
        {
            MaterialHint = "S355",
            DocumentMassKg = 1032.8,
            DocumentMassConfidence = 92,
            DocumentMassScope = "UNKNOWN"
        };

        var r = new CostEngine().Build(geometry, drawing, new DxfSignals(), null, new CostingSettings());

        Assert.DoesNotContain(r.Risks, x => x.Code == "WEIGHT_DRAWING_DIFF");
        Assert.Contains(r.Drawing.Findings, x => x.Contains("lokalnym kandydatem", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public void Large_welded_assembly_gets_real_fabrication_fitup_time()
    {
        var geometry = new GeometrySummary
        {
            Available = true,
            SolidCount = 95,
            UniquePartGroups = 53,
            FullyAnalyzedUniqueSolids = 53,
            ContactPairs = 88,
            WeldCandidatePairs = 25,
            WeldCandidateLengthMm = 9595,
            BoundingXmm = 3196,
            BoundingYmm = 860,
            BoundingZmm = 2406,
            VolumeMm3 = 200_000_000,
            Parts =
            [
                new PartGroup { Name="P", Classification="Blacha / płyta", Quantity=95, Xmm=500, Ymm=250, Zmm=16, VolumeMm3Each=2_105_263, FaceCount=8 }
            ]
        };
        var drawing = new DrawingIntelligence { MaterialHint="S355", Keywords=["WELD"], WeldSizeMm=5, WeldSideCount=1 };
        var r = new CostEngine().Build(geometry, drawing, new DxfSignals(), null, new CostingSettings());
        var assy = r.Processes.Single(x => x.Code == "ASSY");

        Assert.True(assy.Hours > 20);
        Assert.Contains("Fabrication Complexity", assy.Basis);
    }

    [Fact]
    public void Cnc_has_per_unique_group_programming_and_manual_operations()
    {
        var geometry = new GeometrySummary
        {
            Available = true,
            SolidCount = 12,
            UniquePartGroups = 6,
            FullyAnalyzedUniqueSolids = 6,
            VolumeMm3 = 50_000_000,
            Parts =
            [
                new PartGroup { Name="Machined A", Classification="Detal", Quantity=6, Xmm=500, Ymm=300, Zmm=80, VolumeMm3Each=4_000_000, FaceCount=40, CylindricalFaceCount=6 },
                new PartGroup { Name="Machined B", Classification="Detal", Quantity=6, Xmm=450, Ymm=250, Zmm=70, VolumeMm3Each=3_500_000, FaceCount=35, CylindricalFaceCount=5 }
            ]
        };
        var drawing = new DrawingIntelligence { MaterialHint="S355", Keywords=["MACHINED", "RA 3.2"] };
        var r = new CostEngine().Build(geometry, drawing, new DxfSignals(), null, new CostingSettings());
        var cnc = r.Processes.Single(x => x.Code == "CNC");
        var manual = r.Processes.Single(x => x.Code == "CNC_MANUAL");

        Assert.Contains("programowanie/oprzyrządowanie", cnc.Basis);
        Assert.True(manual.Enabled);
        Assert.True(manual.Hours > 0);
    }

    [Fact]
    public void Unpriced_external_operation_marks_quote_as_partial_not_recommended_complete_price()
    {
        var r = new AnalysisResult
        {
            ConfidencePercent = 90,
            RatesConfirmedByCompany = true,
            WeightKg = 1000,
            Material = "S355",
            MaterialCostPln = 10_000,
            ProcessCostPln = 10_000,
            CostTotalPln = 20_000,
            TechnicalPricePln = 22_400,
            FinalPricePln = 22_400,
            Drawing = new DrawingIntelligence { Keywords=["PT"] }
        };

        AutoQuoteEngine.Apply(r);

        Assert.Equal("NIEPEŁNA", r.AutoQuote.Status);
        Assert.False(r.AutoQuote.IsPriceComplete);
        Assert.Contains("CZĘŚCIOWA", r.AutoQuote.PriceLabel);
        Assert.Equal(1, r.AutoQuote.UnpricedExternalOperationCount);
    }
}
