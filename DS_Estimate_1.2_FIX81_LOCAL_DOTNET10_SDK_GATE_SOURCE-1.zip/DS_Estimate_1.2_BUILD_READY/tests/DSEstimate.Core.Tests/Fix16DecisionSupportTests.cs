using DSEstimate.Core;
using Xunit;

namespace DSEstimate.Core.Tests;

public sealed class Fix16DecisionSupportTests
{
    [Fact]
    public void External_calibration_is_idempotent_and_applies_material_and_process()
    {
        var result = new AnalysisResult
        {
            Material = "S355J2",
            MaterialCostPln = 100,
            Processes =
            [
                new ProcessEstimate { Code = "WELD", Enabled = true, Hours = 10, RatePlnPerHour = 200, Basis = "model" }
            ],
            MaterialBreakdown =
            [
                new MaterialBreakdownItem { Material = "S355J2", MassKg = 100 }
            ]
        };
        var settings = new CostingSettings
        {
            RuntimeCalibration = new CalibrationProfile
            {
                Version = "test-1",
                EffectiveFrom = DateTime.Today,
                GoldenSetId = "golden-test",
                ChangeReason = "test",
                ProcessMultipliers = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase) { ["WELD"] = 1.2 },
                MaterialMultipliers = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase) { ["S355"] = 1.1 }
            }
        };

        CalibrationLayer.Apply(result, settings);
        CalibrationLayer.Apply(result, settings);

        Assert.Equal(12, result.Processes[0].Hours, 6);
        Assert.Equal(110, result.MaterialCostPln, 6);
        Assert.Equal(1, result.ExternalCalibration.ProcessAdjustmentCount);
        Assert.Equal(1, result.ExternalCalibration.MaterialAdjustmentCount);
    }

    [Fact]
    public void Future_calibration_is_rejected_without_changing_values()
    {
        var result = new AnalysisResult
        {
            MaterialCostPln = 100,
            Processes = [new ProcessEstimate { Code = "CUT", Enabled = true, Hours = 2 }]
        };
        var settings = new CostingSettings
        {
            RuntimeCalibration = new CalibrationProfile
            {
                Version = "future",
                EffectiveFrom = DateTime.Today.AddDays(1),
                GoldenSetId = "golden-test",
                ChangeReason = "test",
                ProcessMultipliers = new Dictionary<string, double> { ["CUT"] = 1.2 }
            }
        };

        CalibrationLayer.Apply(result, settings);

        Assert.True(result.ExternalCalibration.Rejected);
        Assert.Equal(2, result.Processes[0].Hours, 6);
        Assert.Equal(100, result.MaterialCostPln, 6);
    }

    [Fact]
    public void What_if_changes_only_selected_cost_share()
    {
        var result = new AnalysisResult
        {
            CostTotalPln = 1000,
            MaterialCostPln = 400,
            ProcessCostPln = 400,
            AppliedMarkupPercent = 12,
            AppliedWhatIfMaterialPriceChangePercent = 10,
            AppliedWhatIfProcessTimeChangePercent = -10,
            AutoQuote = new AutoQuoteSummary { RecommendedPricePln = 1120, P50PricePln = 1120 }
        };

        QuoteScenarioEngine.Apply(result);

        Assert.Equal(3, result.QuoteScenarios.Count);
        Assert.Equal(1164.8, result.QuoteScenarios.Single(x => x.Code == "MATERIAL").PricePln, 6);
        Assert.Equal(1075.2, result.QuoteScenarios.Single(x => x.Code == "PROCESS").PricePln, 6);
    }

    [Fact]
    public void What_if_preserves_partial_price_label()
    {
        var result = new AnalysisResult
        {
            CostTotalPln = 1000,
            MaterialCostPln = 400,
            ProcessCostPln = 400,
            AppliedMarkupPercent = 12,
            AutoQuote = new AutoQuoteSummary
            {
                RecommendedPricePln = 1120,
                P50PricePln = 1120,
                IsPriceComplete = false
            }
        };

        QuoteScenarioEngine.Apply(result);

        Assert.All(result.QuoteScenarios, x => Assert.False(x.IsPriceComplete));
        Assert.Contains("CZĘŚCIOWA", result.QuoteScenarios[0].PriceDisplay);
    }

    [Fact]
    public void Explicit_bending_is_visible_and_unpriced()
    {
        var result = new AnalysisResult
        {
            Geometry = new GeometrySummary
            {
                Parts = [new PartGroup { Classification = "Blacha / płyta", Quantity = 2 }]
            },
            Drawing = new DrawingIntelligence { Keywords = ["BENDING"] }
        };

        SheetMetalReadinessEngine.Apply(result);

        Assert.True(result.SheetMetal.RequiresBending);
        Assert.True(result.SheetMetal.RequiresExternalRate);
        Assert.Contains(result.Risks, x => x.Code == "BENDING_UNPRICED");
    }
}
