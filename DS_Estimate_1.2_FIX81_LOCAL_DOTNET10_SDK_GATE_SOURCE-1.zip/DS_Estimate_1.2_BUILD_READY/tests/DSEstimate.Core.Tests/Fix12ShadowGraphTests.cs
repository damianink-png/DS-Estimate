using DSEstimate.Core;
using DSEstimate.Infrastructure;
using Xunit;

namespace DSEstimate.Core.Tests;

public class Fix12ShadowGraphTests
{
    [Fact]
    public void Confidence_vector_keeps_existence_separate_from_cost_confidence()
    {
        var c = new ConfidenceVector
        {
            Existence = 0.98,
            Binding = 0.82,
            Geometry = 0.55,
            Parameters = 0.48
        };

        Assert.Equal(98, c.ExistencePercent);
        Assert.InRange(c.CostPercent, 60, 80);
        Assert.True(c.Cost < c.Existence);
    }

    [Fact]
    public void Shadow_graph_does_not_have_price_authority_or_mutate_legacy_quote()
    {
        var result = BuildPostWeldCase();
        var priceBefore = result.FinalPricePln;
        var processBefore = result.Processes.Select(x => (x.Code, x.Hours, x.RatePlnPerHour, x.Confidence)).ToList();

        var graph = AssemblyStateGraphBuilder.Build(new QuoteProject { Name = "fixture" }, result);

        Assert.True(graph.ShadowOnly);
        Assert.False(graph.HasPriceAuthority);
        Assert.Equal(priceBefore, result.FinalPricePln);
        Assert.Equal(processBefore, result.Processes.Select(x => (x.Code, x.Hours, x.RatePlnPerHour, x.Confidence)).ToList());
    }

    [Fact]
    public void Post_weld_machining_uses_welded_assembly_state_and_whole_assembly_geometry()
    {
        var result = BuildPostWeldCase();
        var graph = AssemblyStateGraphBuilder.Build(new QuoteProject { Name = "fixture" }, result);

        Assert.True(graph.PostWeldMachiningDetected);
        var weld = graph.Processes.Single(x => x.Process == TechnologyProcessKind.Welding);
        var post = graph.Processes.Single(x => x.Process == TechnologyProcessKind.PostMachining);
        Assert.True(graph.Processes.IndexOf(weld) < graph.Processes.IndexOf(post));
        Assert.Contains(weld.Id, post.RequiredBefore);
        Assert.Contains("STATE-WELDED-ASSEMBLY", post.InputStateIds);

        var postState = graph.States.Single(x => x.Id == post.OutputStateId);
        Assert.Equal(2163, postState.Geometry.BoundingYmm);
        Assert.Equal(410, postState.Geometry.MassKg);
        Assert.True(post.Confidence.Existence > post.Confidence.Parameters);
    }

    [Fact]
    public void Unique_part_groups_are_contract_entities_not_physical_instances()
    {
        var result = BuildPostWeldCase();
        var graph = AssemblyStateGraphBuilder.Build(new QuoteProject { Name = "fixture" }, result);

        Assert.Equal(2, graph.UniquePartGroups.Count);
        Assert.Equal(6, graph.UniquePartGroups.Sum(x => x.InstanceIds.Count));
        Assert.All(graph.UniquePartGroups, x => Assert.StartsWith("UPG-", x.Id));
    }

    [Fact]
    public void Partial_dxf_scope_is_a_shadow_warning_not_global_binding()
    {
        var result = BuildPostWeldCase();
        result.Dxf = new DxfSignals
        {
            SourceFile = "BASE_PLATE_LASER.dxf",
            SourceFileCount = 1,
            GeometryMeasurementReliable = true,
            CutLengthMm = 946
        };
        result.Geometry.Parts.Add(new PartGroup
        {
            GroupKey = "PLATE_C",
            Name = "Plate C",
            Classification = "Blacha / płyta",
            Quantity = 1,
            Xmm = 300,
            Ymm = 200,
            Zmm = 8
        });

        var graph = AssemblyStateGraphBuilder.Build(new QuoteProject(), result);

        Assert.Contains(graph.Warnings, x => x.Contains("DXF scope", StringComparison.OrdinalIgnoreCase));
        Assert.False(graph.HasPriceAuthority);
    }

    private static AnalysisResult BuildPostWeldCase()
    {
        return new AnalysisResult
        {
            WeightKg = 410,
            FinalPricePln = 11_000,
            AutoQuote = new AutoQuoteSummary
            {
                RecommendedPricePln = 10_970,
                RouteSummary = "CUT → WELD → CNC"
            },
            Geometry = new GeometrySummary
            {
                Available = true,
                SolidCount = 6,
                UniquePartGroups = 2,
                FullyAnalyzedUniqueSolids = 2,
                BoundingXmm = 1583,
                BoundingYmm = 2163,
                BoundingZmm = 100,
                VolumeMm3 = 52_245_000,
                SurfaceMm2 = 21_436_000,
                PaintableSurfaceMm2 = 1_689_000,
                WeldCandidatePairs = 4,
                WeldCandidateLengthMm = 6320,
                Parts =
                [
                    new PartGroup
                    {
                        GroupKey = "PLATE_A", Name = "Plate A", Classification = "Blacha / płyta",
                        Quantity = 4, Xmm = 800, Ymm = 600, Zmm = 20, MassKgEach = 40,
                        FaceCount = 12, EdgeCount = 24
                    },
                    new PartGroup
                    {
                        GroupKey = "RHS_B", Name = "RHS B", Classification = "Profil zamknięty / RHS-SHS",
                        Quantity = 2, Xmm = 1000, Ymm = 100, Zmm = 100, MassKgEach = 25,
                        FaceCount = 10, EdgeCount = 20
                    }
                ]
            },
            Drawing = new DrawingIntelligence
            {
                SourceFile = "DRAWING_WELDED_MACHINE_FRAME.pdf",
                WeldSizeMm = 6,
                WeldTypeHint = "GROOVE",
                TotalDftMicron = 240,
                GeometricTolerances =
                [
                    new GeometricToleranceSignal
                    {
                        Type = "PARALLELISM",
                        ValueMm = 0.2,
                        Tight = true,
                        SourceText = "MACHINED PADS AFTER WELDING: Ra 3.2, parallelism 0.20 to A"
                    }
                ]
            },
            Processes =
            [
                new ProcessEstimate { Code = "CUT", Name = "Cięcie", Enabled = true, Hours = 2, RatePlnPerHour = 300, Confidence = 80 },
                new ProcessEstimate { Code = "WELD", Name = "Spawanie", Enabled = true, Hours = 5, RatePlnPerHour = 220, Confidence = 78 },
                new ProcessEstimate { Code = "CNC", Name = "Obróbka CNC", Enabled = true, Hours = 2.3, RatePlnPerHour = 166, Confidence = 68 }
            ],
            Evidence = new EvidenceOrchestrationSummary
            {
                Facts =
                [
                    new EvidenceFact
                    {
                        Field = "mass", NumericValue = 410, Unit = "kg", SourceFile = "WELDED_MACHINE_FRAME.step",
                        SourceKind = "STEP", Scope = "PROJECT_TOTAL", Confidence = 96
                    },
                    new EvidenceFact
                    {
                        Field = "weld_throat", NumericValue = 6, Unit = "mm", SourceFile = "DRAWING_WELDED_MACHINE_FRAME.pdf",
                        SourceKind = "PDF", Scope = "WELD", Confidence = 78
                    }
                ]
            }
        };
    }
}
