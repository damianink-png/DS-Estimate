using DSEstimate.Core;
using Xunit;

namespace DSEstimate.Core.Tests;

public class Fix11TechnologyScopeTests
{
    [Fact]
    public void Post_weld_machining_is_routed_after_welding()
    {
        var r = new AnalysisResult
        {
            ConfidencePercent = 90,
            RatesConfirmedByCompany = true,
            WeightKg = 410,
            CostTotalPln = 10_000,
            FinalPricePln = 11_200,
            Welding = new WeldEstimate { Enabled = true, Source = "PDF/OCR + STEP", ConsumableCostPln = 50 },
            Drawing = new DrawingIntelligence
            {
                GeometricTolerances =
                [
                    new GeometricToleranceSignal
                    {
                        Type = "PARALLELISM",
                        ValueMm = 0.2,
                        SourceText = "MACHINED PADS AFTER WELDING: Ra 3.2, parallelism 0.20 to A"
                    }
                ]
            },
            Processes =
            [
                new ProcessEstimate { Code = "CNC", Name = "Obróbka CNC", Enabled = true, Hours = 1.0, RatePlnPerHour = 200, Confidence = 68 },
                new ProcessEstimate { Code = "WELD", Name = "Spawanie", Enabled = true, Hours = 2.0, RatePlnPerHour = 200, Confidence = 80 }
            ]
        };

        AutoQuoteEngine.Apply(r);

        var weld = r.AutoRoute.Single(x => x.Code == "WELD");
        var cnc = r.AutoRoute.Single(x => x.Code == "CNC");
        Assert.True(weld.Sequence < cnc.Sequence);
        Assert.Contains("po spawaniu", cnc.Name, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void Post_weld_cnc_capacity_uses_whole_assembly_not_smallest_part()
    {
        var geometry = new GeometrySummary
        {
            Available = true,
            SolidCount = 2,
            UniquePartGroups = 2,
            FullyAnalyzedUniqueSolids = 2,
            VolumeMm3 = 52_245_000,
            BoundingXmm = 1583,
            BoundingYmm = 2163,
            BoundingZmm = 100,
            Parts =
            [
                new PartGroup { Name = "P1", Classification = "Blacha / płyta", Quantity = 1, Xmm = 800, Ymm = 600, Zmm = 20, VolumeMm3Each = 9_000_000 },
                new PartGroup { Name = "P2", Classification = "Blacha / płyta", Quantity = 1, Xmm = 700, Ymm = 500, Zmm = 20, VolumeMm3Each = 8_000_000 }
            ]
        };
        var drawing = new DrawingIntelligence
        {
            MaterialHint = "S355J2+N",
            Keywords = ["MACHINED", "RA 3.2"],
            GeometricTolerances =
            [
                new GeometricToleranceSignal
                {
                    Type = "PARALLELISM",
                    ValueMm = 0.2,
                    Tight = true,
                    SourceText = "MACHINED PADS AFTER WELDING: Ra 3.2, parallelism 0.20 to A"
                }
            ]
        };

        var r = new CostEngine().Build(geometry, drawing, new DxfSignals(), null, new CostingSettings());
        var cnc = r.Processes.Single(x => x.Code == "CNC");

        Assert.True(cnc.Enabled);
        Assert.Equal("CNC_LARGE", cnc.WorkstationCode);
        Assert.Contains("po spawaniu", cnc.Basis, StringComparison.OrdinalIgnoreCase);
        Assert.True(cnc.Confidence < 90);
        Assert.Contains(r.Risks, x => x.Code == "POST_WELD_CNC_SCOPE");
    }

    [Fact]
    public void One_measured_dxf_does_not_claim_full_cutting_coverage_for_many_plate_groups()
    {
        var geometry = new GeometrySummary
        {
            Available = true,
            SolidCount = 6,
            UniquePartGroups = 3,
            FullyAnalyzedUniqueSolids = 3,
            VolumeMm3 = 10_000_000,
            Parts =
            [
                new PartGroup { Name = "A", Classification = "Blacha / płyta", Quantity = 2, Xmm = 400, Ymm = 200, Zmm = 8, VolumeMm3Each = 600_000 },
                new PartGroup { Name = "B", Classification = "Blacha / płyta", Quantity = 2, Xmm = 500, Ymm = 250, Zmm = 8, VolumeMm3Each = 900_000 },
                new PartGroup { Name = "C", Classification = "Blacha / płyta", Quantity = 2, Xmm = 600, Ymm = 300, Zmm = 8, VolumeMm3Each = 1_200_000 }
            ]
        };
        var dxf = new DxfSignals
        {
            GeometryMeasurementReliable = true,
            CutLengthMm = 946,
            CutStartCount = 5,
            CutGeometryEntityCount = 6,
            SourceFileCount = 1,
            DrawingUnits = "mm"
        };
        var drawing = new DrawingIntelligence { MaterialHint = "S355J2+N" };

        var r = new CostEngine().Build(geometry, drawing, dxf, null, new CostingSettings());
        var cut = r.Processes.Single(x => x.Code == "CUT");

        Assert.Contains("Pokrycie DXF względem rodzin blach: 1/3", cut.Basis);
        Assert.True(cut.Confidence < 80);
        Assert.Contains(r.Risks, x => x.Code == "CUT_PARTIAL_COVERAGE");
    }

    [Fact]
    public void Very_low_auto_paint_area_ratio_reduces_confidence_and_creates_risk()
    {
        var geometry = new GeometrySummary
        {
            Available = true,
            SolidCount = 10,
            UniquePartGroups = 5,
            FullyAnalyzedUniqueSolids = 5,
            VolumeMm3 = 10_000_000,
            SurfaceMm2 = 21_436_000,
            ExposedSurfaceMm2 = 21_315_000,
            PaintableSurfaceMm2 = 1_689_000,
            InternalPaintExcludedMm2 = 5_713_000,
            SealedCavitySurfaceMm2 = 13_914_000
        };
        var drawing = new DrawingIntelligence
        {
            MaterialHint = "S355J2+N",
            Keywords = ["PAINT"],
            PaintColour = "RAL 7016",
            SurfacePreparation = "SA 2.5",
            TotalDftMicron = 240
        };

        var r = new CostEngine().Build(geometry, drawing, new DxfSignals(), null, new CostingSettings());

        Assert.True(r.Painting.Enabled);
        Assert.True(r.Painting.Confidence <= 68);
        Assert.Contains(r.Risks, x => x.Code == "PAINT_AREA_LOW_RATIO");
    }
}
