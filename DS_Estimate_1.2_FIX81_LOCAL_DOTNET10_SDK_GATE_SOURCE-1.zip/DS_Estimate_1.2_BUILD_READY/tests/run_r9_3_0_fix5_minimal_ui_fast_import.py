from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
PASS = FAIL = 0


def check(name, condition, detail=""):
    global PASS, FAIL
    if condition:
        PASS += 1
        print("PASS ", name)
    else:
        FAIL += 1
        print("FAIL ", name, detail)


def read(relative):
    return (ROOT / relative).read_text(encoding="utf-8-sig")


main = read("src/DSEstimate.App/Views/MainWindow.axaml")
app = read("src/DSEstimate.App/App.axaml")
vm = read("src/DSEstimate.App/ViewModels/MainViewModel.cs")
domain = read("src/DSEstimate.Core/Domain.cs")
package = read("src/DSEstimate.Infrastructure/ClientPackageImportService.cs")
analyzers = read("src/DSEstimate.Infrastructure/DocumentAnalyzers.cs")
service = read("src/DSEstimate.Infrastructure/ProjectAnalysisService.cs")
runner = read("src/DSEstimate.Infrastructure/PythonRunner.cs")
build = read("BUILD_FULL_PORTABLE_ZIP.ps1")
release = read("RUN_FULL_RELEASE_TESTS.cmd")

for relative in ["src/DSEstimate.App/App.axaml", "src/DSEstimate.App/Views/MainWindow.axaml"]:
    try:
        ET.parse(ROOT / relative)
        check("XML " + Path(relative).name, True)
    except Exception as exc:
        check("XML " + Path(relative).name, False, str(exc))

busy_start = main.find('<Border Classes="card" IsVisible="{Binding IsBusy}">')
busy_end = main.find("</Border>", busy_start)
busy = main[busy_start:busy_end]
check("busy UI has one progress bar", busy.count("<ProgressBar") == 1 and "IsIndeterminate" not in busy)
check("busy UI has no watchdog wall", "Watchdog STEP:" not in busy and "blokowane jest usuwanie" not in busy)
check("document toggle uses readable centered style", 'Classes="secondary documentToggle"' in main and all(x in app for x in ["Button.documentToggle", 'FontSize" Value="14', 'HorizontalContentAlignment" Value="Center']))

check("summary exposes total mass", main.count("Masa całkowita:") >= 1 and 'IsVisible="{Binding Analysis.HasWeight}"' in main and "public bool HasWeight" in domain)
check("empty historical values are hidden", main.count('IsVisible="{Binding Analysis.AutoQuote.HasHistoricalReference}"') == 2 and "HasHistoricalReference" in domain)
check("route uses per-operation expansion", 'Text="Automatyczny routing technologiczny"' in main and 'ItemsSource="{Binding Analysis.AutoRoute}"' in main and "Rozwiń wybraną operację" in main)
route_start = main.find('ItemsSource="{Binding Analysis.AutoRoute}"')
route_end = main.find("</ItemsControl>", route_start)
check("route basis is collapsed", "<Expander" in main[route_start:route_end] and "Podstawa: {0}" in main[route_start:route_end])
process_start = main.find('ItemsSource="{Binding Processes}"')
process_end = main.find("</ItemsControl>", process_start)
check("processes use per-row expansion", "<Expander" in main[process_start:process_end] and ("Podstawa: {0}" in main[process_start:process_end] or 'Text="{Binding Basis}"' in main[process_start:process_end]))
check("process essentials remain visible", all(x in main[process_start:process_end] for x in ["WorkstationName", "Hours", "CostPln", "Confidence"]))

check("details has explicit empty state", all(x in main + vm for x in ["HasNoParts", "PartsEmptyText", "Brak detali do wyświetlenia", "Brak geometrii STEP w tej paczce"]))
check("stale detail search is cleared", vm.count('PartSearch = "";') >= 3)

for status in ["Oczekuje", "W toku", "Przeanalizowany", "Uwaga", "Błąd", "Pominięto", "Anulowano"]:
    check("status " + status, status in domain + vm + service)
check("status pills distinguish pending and work", all(x in main + app + domain for x in ["IsStatusPending", "IsStatusInProgress", "statusPill.pending", "statusPill.inProgress"]))

for kind in ["step", "dxf", "dwg", "pdf", "image", "table", "text", "other"]:
    check("file kind colour " + kind, f"kindPill.{kind}" in app and f'Classes.{kind}="{{Binding Is' in main)

check("ZIP work leaves UI thread", "return Task.Run(" in package and "ExpandCore" in package)
check("ZIP reports real progress", "PackageImportProgress" in package and "ReportImportProgress" in package and "Rozpakowywanie ZIP" in package and "importProgress" in vm)
check("ZIP import is cancellable", "_analysisCancellation.Token" in vm and "Import anulowany" in vm and "ThrowIfCancellationRequested" in package)
check("ZIP cache is content addressed", all(x in package for x in ["PackageCacheVersion", "SafeHash(zipPath)", "PackageCacheDirectory", "manifest.json"]))
check("warm ZIP skips decompression", "TryReadCacheManifest" in package and "ReusedArchiveCount++" in package and "ReplayCachedArchive" in package)
check("cache materializes stable project files", "MaterializeForProject" in package and "CreateHardLinkWindows" in package and "File.Copy" in package)
check("Windows hardlink binds the real API entry point", 'EntryPoint = "CreateHardLinkW"' in package)
check("cached duplicate hashes avoid reread", "ContentHash" in package and "string.IsNullOrWhiteSpace(x.ContentHash)" in package)
check("ZIP safety remains", all(x in package for x in ["MaxNestedZipDepth", "MaxArchiveEntries", "budget.SeenBytes", 'x == ".."', "ValidateBudget"]))

check("Git LFS STEP is rejected without Python", "git-lfs.github.com/spec/v1" in analyzers and 'AnalysisMode = "invalid-input"' in analyzers)
# FIX10 broadened negative-result caching from deterministic no-solid inputs to timeouts/
# corrupt inputs as well. Preserve the original guarantee while accepting the stronger helper.
check("negative STEP results are cacheable",
      analyzers.count("IsDeterministicUnavailable") >= 2 and
      analyzers.count("IsCacheableUnavailable") >= 6 and
      "zapamiętanej diagnostyki STEP" in analyzers)
check("negative STEP skips fallback and full analysis",
      "GeometryAnalyzer.IsDeterministicUnavailable(unavailableScan)" in service and
      "STEP pominięty: brak zamkniętych brył" in service and
      "continue;" in service)
check("Python output is decoded as UTF-8", all(x in runner for x in ["StandardOutputEncoding = Encoding.UTF8", "StandardErrorEncoding = Encoding.UTF8", 'psi.Environment["PYTHONUTF8"] = "1"']))

check("new regression is wired into Windows build", "run_r9_3_0_fix5_minimal_ui_fast_import.py" in build)
check("new regression is wired into full gate", "run_r9_3_0_fix5_minimal_ui_fast_import.py" in release)

for relative in [
    "src/DSEstimate.Core/Domain.cs",
    "src/DSEstimate.App/ViewModels/MainViewModel.cs",
    "src/DSEstimate.Infrastructure/ClientPackageImportService.cs",
    "src/DSEstimate.Infrastructure/ProjectAnalysisService.cs",
    "src/DSEstimate.Infrastructure/PythonRunner.cs",
]:
    text = read(relative)
    check("brace balance " + Path(relative).name, text.count("{") == text.count("}"))

print(f"\nSUMMARY\nPASS={PASS} FAIL={FAIL}")
sys.exit(1 if FAIL else 0)
