#!/usr/bin/env python3
"""FIX23: detect tiled/inline scans without double-counting image overlays."""
from __future__ import annotations
import importlib.util
import io
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('dse_fix23_document', ROOT / 'engines/python/analyze_document.py')
document = importlib.util.module_from_spec(spec)
spec.loader.exec_module(document)
passed = failed = skipped = 0


def check(name, condition, detail=''):
    global passed, failed
    if condition:
        passed += 1
        print('PASS ', name)
    else:
        failed += 1
        print('FAIL ', name, detail)


class FakeRect:
    x0 = y0 = 0
    x1 = y1 = 100

    @property
    def width(self): return self.x1 - self.x0

    @property
    def height(self): return self.y1 - self.y0


class FakePage:
    rect = FakeRect()

    def __init__(self, boxes): self.boxes = boxes

    def get_image_info(self, xrefs=False):
        return [{'bbox': r, 'xref': 0} for r in self.boxes]


def tiled(n):
    side = 100 / n
    return [(x * side, y * side, (x + 1) * side, (y + 1) * side)
            for x in range(n) for y in range(n)]


check('tiled 4x4 scan detected', document._page_has_scanned_drawing(FakePage(tiled(4))))
check('tiled 8x8 scan detected', document._page_has_scanned_drawing(FakePage(tiled(8))))
check('overlapping duplicate images not overcounted',
      not document._page_has_scanned_drawing(FakePage([(0, 0, 20, 20)] * 80)))
check('small logo ignored', not document._page_has_scanned_drawing(FakePage([(0, 0, 10, 10)])))
check('outside-page image clipped', not document._page_has_scanned_drawing(FakePage([(-300, -300, 20, 20)])))
check('partly clipped scan still detected', document._page_has_scanned_drawing(FakePage([(-50, 0, 60, 100)])))
check('blank page ignored', not document._page_has_scanned_drawing(FakePage([])))
check('zero safety cap still enforced', document.select_ocr_page_indices(10, 0, [7]) == [])

try:
    import pymupdf as fitz
    from PIL import Image, ImageDraw
except ImportError:
    skipped += 1
    print('SKIP  real PDF integration (PyMuPDF/Pillow unavailable)')
else:
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / 'tiled-mixed.pdf'
        pdf = fitz.open()
        image = Image.new('RGB', (160, 160), 'white')
        ImageDraw.Draw(image).text((10, 50), 'S355', fill='black')
        stream = io.BytesIO()
        image.save(stream, format='PNG')
        for i in range(10):
            page = pdf.new_page(width=400, height=400)
            if i == 6:
                for x in range(4):
                    for y in range(4):
                        page.insert_image(fitz.Rect(x * 100, y * 100, (x + 1) * 100, (y + 1) * 100),
                                          stream=stream.getvalue())
            else:
                page.insert_text((20, 30), 'TECHNICAL SPECIFICATION ' * 12)
        pdf.save(path)
        pdf.close()
        with fitz.open(path) as pdf:
            page_texts = [page.get_text('text') for page in pdf]
            detected = document.find_sparse_raster_pdf_pages(page_texts, pdf)
            check('real tiled sheet detected among 10 searchable sheets', detected == [6], str(detected))
            check('real tile area is <30% individually', all(
                (info['bbox'][2] - info['bbox'][0]) * (info['bbox'][3] - info['bbox'][1]) < 0.3 * 400 * 400
                for info in pdf[6].get_image_info(xrefs=False)))
        # Real inline image: write a PDF BI/ID/EI operator into a page content stream.
        inline = fitz.open()
        page = inline.new_page(width=100, height=100)
        page.insert_text((2, 2), 'x', fontsize=1)  # ensure a content stream exists
        # 2x2 RGB image encoded in ASCII hex; placed over 80% of the page.
        pixels = ('FF0000' * 4).encode('ascii')
        operator = (b'\nq 90 0 0 90 5 5 cm BI /W 2 /H 2 /BPC 8 /CS /RGB '
                    b'/F /AHx ID ' + pixels + b'> EI Q\n')
        content_xref = page.get_contents()[0]
        inline.update_stream(content_xref, page.read_contents() + operator)
        info = page.get_image_info(xrefs=False)
        check('inline BI/ID/EI image is visible to PyMuPDF', bool(info) and not page.get_images(full=False), str(info))
        check('inline scan detected', document._page_has_scanned_drawing(page))
        inline.close()

        original_config = document.configure_tesseract
        original_languages = document.choose_ocr_languages
        original_run = document.run_technical_ocr
        keys = ['DSE_SKIP_PDF_OCR', 'DSE_HISTORY_FAST_PDF', 'DSE_HISTORY_SAFE', 'DSE_OCR_MAX_PAGES']
        saved = {k: os.environ.get(k) for k in keys}
        try:
            for k in keys: os.environ.pop(k, None)
            os.environ['DSE_OCR_MAX_PAGES'] = '1'
            document.configure_tesseract = lambda module: ('fake-tesseract', '--psm 6')
            document.choose_ocr_languages = lambda module, config: ('eng', ['eng'])
            document.run_technical_ocr = lambda *a, **kw: ('S355', 1, 90.0, 90.0, [], [])
            result = document.analyze_pdf(path)
            warnings = '\n'.join(result['warnings'])
            check('real OCR prioritizes tiled scan under page cap', '(nr 7)' in warnings, warnings)
            check('OCR output merged into material', result.get('materialHint') == 'S355', str(result.get('materialHint')))
        finally:
            document.configure_tesseract = original_config
            document.choose_ocr_languages = original_languages
            document.run_technical_ocr = original_run
            for k, value in saved.items():
                if value is None: os.environ.pop(k, None)
                else: os.environ[k] = value

print(f'\nSUMMARY PASS={passed} FAIL={failed} SKIP={skipped}')
sys.exit(1 if failed else 0)
