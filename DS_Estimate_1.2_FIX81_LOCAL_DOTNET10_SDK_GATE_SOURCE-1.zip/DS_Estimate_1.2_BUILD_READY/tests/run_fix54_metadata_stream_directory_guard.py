#!/usr/bin/env python3
"""FIX54: synthetic ECMA-335 metadata directory checks; NOT a .NET build."""
from __future__ import annotations

import importlib.util
import struct
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERIFY = ROOT / "tests/verify_dotnet_solution_outputs.py"
spec = importlib.util.spec_from_file_location("dse_fix54_verify", VERIFY)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
checks: list[bool] = []


def check(label: str, ok: bool) -> None:
    checks.append(bool(ok))
    print(("PASS " if ok else "FAIL ") + label, flush=True)


def managed_fixture() -> bytes:
    """A small structurally plausible metadata root, not executable IL."""
    data = bytearray(4096)
    data[:2] = b"MZ"
    struct.pack_into("<I", data, 0x3C, 0x80)
    data[0x80:0x84] = b"PE\0\0"
    struct.pack_into("<H", data, 0x86, 1)  # section count
    struct.pack_into("<H", data, 0x94, 0xE0)  # optional header size
    struct.pack_into("<H", data, 0x98, 0x10B)  # PE32
    struct.pack_into("<I", data, 0x98 + 92, 16)  # directory count
    struct.pack_into("<II", data, 0x98 + 96 + 14 * 8, 0x2000, 0x48)
    section = 0x98 + 0xE0
    struct.pack_into("<IIII", data, section + 8, 0x1000, 0x2000, 0x1000, 0x400)
    struct.pack_into("<I", data, 0x400, 0x48)
    struct.pack_into("<II", data, 0x408, 0x2100, 0xA0)
    root = 0x500
    data[root:root + 4] = b"BSJB"
    struct.pack_into("<HHII", data, root + 4, 1, 1, 0, 12)
    data[root + 16:root + 28] = b"v4.0.30319\0\0"
    struct.pack_into("<HH", data, root + 28, 0, 3)
    # Stream directory: #~, #Strings, #Blob.  All data stays inside 0xA0.
    struct.pack_into("<II", data, root + 32, 0x60, 0x20)
    data[root + 40:root + 44] = b"#~\0\0"
    struct.pack_into("<II", data, root + 44, 0x80, 0x10)
    data[root + 52:root + 64] = b"#Strings\0\0\0\0"
    struct.pack_into("<II", data, root + 64, 0x90, 0x10)
    data[root + 72:root + 80] = b"#Blob\0\0\0"
    data[root + 0x60:root + 0x80] = b"\x01" * 0x20
    data[root + 0x80:root + 0xA0] = b"\x01" * 0x20
    return bytes(data)


def changed(original: bytes, offset: int, payload: bytes) -> bytes:
    data = bytearray(original)
    data[offset:offset + len(payload)] = payload
    return bytes(data)


with tempfile.TemporaryDirectory(prefix="dse-fix54-") as folder:
    root = Path(folder) / "root"
    log = Path(folder) / "logs" / "solution-output-evidence.log"
    for _, relative in mod.OUTPUTS:
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(managed_fixture())
    first = root / mod.OUTPUTS[0][1]
    valid = managed_fixture()

    def accepted(data: bytes, strict: bool = True) -> bool:
        first.write_bytes(data)
        try:
            mod.inspect_output(first, require_metadata_streams=strict)
            return True
        except mod.SolutionOutputError:
            return False

    check("valid synthetic ECMA metadata streams accepted", accepted(valid))
    check("all four synthetic managed DLLs accepted in strict mode",
          len(mod.verify_outputs(root, require_metadata_streams=True)) == 5)
    check("legacy BSJB-only fixture remains accepted in legacy mode",
          accepted(changed(valid, 0x500 + 32, b"\0" * 48), strict=False))
    check("BSJB-only fake rejected in strict mode",
          not accepted(changed(valid, 0x500 + 32, b"\0" * 48)))
    cases = (
        ("invalid metadata root major", 0x504, struct.pack("<H", 9)),
        ("nonzero metadata root reserved", 0x508, struct.pack("<I", 1)),
        ("misaligned version length", 0x50C, struct.pack("<I", 11)),
        ("oversized version length", 0x50C, struct.pack("<I", 256)),
        ("nonversion metadata string", 0x510, b"x"),
        ("nonzero stream flags", 0x51C, struct.pack("<H", 1)),
        ("too few streams", 0x51E, struct.pack("<H", 2)),
        ("excessive stream count", 0x51E, struct.pack("<H", 33)),
        ("unterminated stream name", 0x548, b"X" * 32),
        ("missing #Strings", 0x534, b"#Other\0\0\0\0\0\0"),
        ("missing #Blob", 0x548, b"#Other\0\0"),
        ("duplicate stream name", 0x548, b"#~\0\0\0\0\0\0"),
        ("stream out of bounds", 0x540, struct.pack("<I", 0xF0)),
        ("stream overlaps metadata header", 0x520, struct.pack("<I", 0x20)),
        ("tables stream too short", 0x524, struct.pack("<I", 8)),
        ("metadata RVA truncated", 0x40C, struct.pack("<I", 0x20)),
    )
    for label, offset, payload in cases:
        check(label + " rejected", not accepted(changed(valid, offset, payload)))

    first.write_bytes(valid)
    proc = subprocess.run([sys.executable, str(VERIFY), "--root", str(root),
                           "--output", str(log), "--require-metadata-streams"],
                          capture_output=True, text=True, timeout=15)
    check("strict CLI passes synthetic metadata directory", proc.returncode == 0 and
          log.is_file() and log.read_text().count("sha256=") == 4)
    first.write_bytes(changed(valid, 0x51E, struct.pack("<H", 0)))
    proc = subprocess.run([sys.executable, str(VERIFY), "--root", str(root),
                           "--output", str(log), "--require-metadata-streams"],
                          capture_output=True, text=True, timeout=15)
    check("strict CLI fails closed and writes FAIL log", proc.returncode == 1 and
          "FAIL" in log.read_text(encoding="utf-8"))

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
check("Windows CI enables strict metadata stream gate",
      "python tests/verify_dotnet_solution_outputs.py --root . --output TestResults/solution-output-evidence.log --require-metadata-streams" in workflow)
check("strict metadata check follows real dotnet build command",
      workflow.index("dotnet build DS_Estimate.sln") < workflow.index("python tests/verify_dotnet_solution_outputs.py"))
check("xUnit TRX strict gate preserved", "--min-executed 60 --reject-skipped" in workflow)
check("real PDF gate preserved", "--require-real-pdf" in workflow)
check("artifact logs remain private and exclude DLLs", "**/*.dll" not in
      workflow.split("      - name: Save test results", 1)[-1])
for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{gate} invokes FIX54", "run_fix54_metadata_stream_directory_guard.py" in
          (ROOT / gate).read_text(encoding="utf-8-sig"))
print(f"SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0", flush=True)
raise SystemExit(0 if all(checks) else 1)
