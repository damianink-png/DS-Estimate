#!/usr/bin/env python3
"""FIX36 checks CI-only launcher fixture and workflow wiring (NOT .NET execution)."""
from __future__ import annotations

import hashlib
import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
FIXTURE_SCRIPT = ROOT / "tests/prepare_launcher_ci_payload.py"
spec = importlib.util.spec_from_file_location("launcher_fixture", FIXTURE_SCRIPT)
assert spec and spec.loader
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)

checks: list[tuple[str, bool]] = []


def check(label: str, condition: bool) -> None:
    checks.append((label, bool(condition)))
    print(("PASS " if condition else "FAIL ") + label, flush=True)


with tempfile.TemporaryDirectory(prefix="dse-fix36-") as tmp:
    directory = Path(tmp) / "isolated"
    proc = subprocess.run([sys.executable, str(FIXTURE_SCRIPT), str(directory)],
                          capture_output=True, text=True, check=False)
    check("fixture CLI succeeds", proc.returncode == 0)
    archive = directory / fixture.ZIP_NAME
    digest = directory / fixture.HASH_NAME
    check("fixture archive exists and nonempty", archive.is_file() and archive.stat().st_size > 0)
    check("fixture SHA256 exists", digest.is_file())
    if archive.is_file() and digest.is_file():
        check("fixture SHA256 matches bytes", digest.read_text(encoding="ascii").strip() ==
              hashlib.sha256(archive.read_bytes()).hexdigest())
        with ZipFile(archive) as zf:
            check("fixture ZIP integrity", zf.testzip() is None)
            check("fixture contains only explicit non-release marker",
                  zf.namelist() == ["NOT_A_RELEASE.txt"] and
                  zf.read("NOT_A_RELEASE.txt") == fixture.MARKER)
    else:
        check("fixture SHA256 matches bytes", False)
        check("fixture ZIP integrity", False)
        check("fixture contains only explicit non-release marker", False)

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
launcher = (ROOT / "src/DSEstimate.Launcher/DSEstimate.Launcher.csproj").read_text(encoding="utf-8-sig")
solution = (ROOT / "DS_Estimate.sln").read_text(encoding="utf-8-sig")
check("launcher intentionally separate from solution", "DSEstimate.Launcher.csproj" not in solution)
check("launcher build requires both payload inputs", "ValidatePayload" in launcher and
      "'$(PayloadZip)'" in launcher and "'$(PayloadHash)'" in launcher)
check("CI compiles application solution", "dotnet build DS_Estimate.sln" in workflow)
check("CI generates isolated fixture", "python tests/prepare_launcher_ci_payload.py TestResults/launcher-smoke" in workflow)
check("CI compiles actual launcher project", "dotnet build src/DSEstimate.Launcher/DSEstimate.Launcher.csproj" in workflow)
check("CI runs setup/fixture/launcher/xUnit in order", 0 <= workflow.find("actions/setup-python@v5")
      < workflow.find("python tests/prepare_launcher_ci_payload.py")
      < workflow.find("dotnet build src/DSEstimate.Launcher/DSEstimate.Launcher.csproj")
      < workflow.find("dotnet test tests/DSEstimate.Core.Tests/"))
check("CI uploads only TRX and discovery evidence, never dummy launcher",
      "TestResults/**/*.trx" in workflow and
      "TestResults/xunit-discovery.txt" in workflow and
      "TestResults/launcher-smoke" not in workflow.split("- name: Save test results", 1)[-1] and
      "if-no-files-found: warn" in workflow)
check("CI passes payload ZIP and hash", "-p:PayloadZip=$payload" in workflow and
      "-p:PayloadHash=$hash" in workflow)
check("CI does not publish fake launcher", "dotnet publish src/DSEstimate.Launcher" not in workflow)
check("CI still runs xUnit and verifies real TRX", "dotnet test tests/DSEstimate.Core.Tests/" in workflow and
      "verify_dotnet_trx.py TestResults/ds-estimate-xunit.trx --require-results" in workflow)
for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{gate} includes FIX36", "run_fix36_launcher_compile_coverage.py" in
          (ROOT / gate).read_text(encoding="utf-8-sig"))

ok = sum(1 for _, result in checks if result)
bad = len(checks) - ok
print(f"SUMMARY PASS={ok} FAIL={bad} SKIP=0", flush=True)
raise SystemExit(1 if bad else 0)
