#!/usr/bin/env python3
"""FIX43: prove PDF regression CI cannot pass with the real PDF tests skipped.

Uses a subprocess shim to simulate an unavailable PyMuPDF without uninstalling
or modifying the local Python environment. This is a Python-only test, not xUnit.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
passed = failed = 0


def check(name: str, condition: bool) -> None:
    global passed, failed
    passed += bool(condition)
    failed += not bool(condition)
    print(("PASS " if condition else "FAIL ") + name, flush=True)


def invoke(test_name: str, strict: bool, block_import: bool) -> subprocess.CompletedProcess[str]:
    test_path = ROOT / "tests" / test_name
    if block_import:
        # sys.modules[name] = None forces a genuine ImportError in the test's
        # own `import pymupdf`, without changing installed packages.
        script = "import runpy, sys; sys.modules['pymupdf'] = None; sys.argv = [sys.argv[1]] + sys.argv[2:]; runpy.run_path(sys.argv[0], run_name='__main__')"
        cmd = [sys.executable, "-c", script, str(test_path)]
    else:
        cmd = [sys.executable, str(test_path)]
    if strict:
        cmd.append("--require-real-pdf")
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return subprocess.run(cmd, cwd=ROOT, env=env, capture_output=True,
                          text=True, encoding="utf-8", errors="replace", timeout=60)


for name in ("run_fix29_pdf_exact_bom_links.py", "run_fix30_pdf_bom_step_links.py"):
    check(name + " strict flag wired in CI",
          f"python tests/{name} --require-real-pdf" in WORKFLOW)
    legacy = invoke(name, strict=False, block_import=True)
    check(name + " legacy missing-dependency remains SKIP",
          legacy.returncode == 0 and "SKIP" in legacy.stdout
          and "SKIP=1" in legacy.stdout)
    strict_missing = invoke(name, strict=True, block_import=True)
    check(name + " strict missing-dependency returns FAIL",
          strict_missing.returncode != 0 and "FAIL real PDF required" in strict_missing.stdout
          and "FAIL=1" in strict_missing.stdout and "SKIP=0" in strict_missing.stdout)
    real = invoke(name, strict=True, block_import=False)
    expected_evidence = (
        "real two-page PDF creates one link" if name.startswith("run_fix29")
        else "real PDF page numbers are correct"
    )
    check(name + " strict real PDF executed and PASS",
          real.returncode == 0 and "SKIP=0" in real.stdout
          and "FAIL=0" in real.stdout and expected_evidence in real.stdout)

# Each test command must still check the native exit code after Tee-Object.
regression = WORKFLOW.split("- name: Check Python engine syntax and PDF BOM contracts", 1)[1].split("- name: Check launcher", 1)[0]
check("CI preserves nonzero exit codes for compileall and both PDF tests",
      regression.count("if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }") == 3)

print(f"SUMMARY PASS={passed} FAIL={failed} SKIP=0", flush=True)
raise SystemExit(1 if failed else 0)
