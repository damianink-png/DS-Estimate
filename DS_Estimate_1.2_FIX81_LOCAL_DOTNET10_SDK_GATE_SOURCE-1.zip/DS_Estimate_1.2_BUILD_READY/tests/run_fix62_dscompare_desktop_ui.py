"""FIX62 structural integration tests. Does not claim runtime .NET/Avalonia coverage."""
from pathlib import Path
from xml.etree import ElementTree as etree
ROOT=Path(__file__).resolve().parents[1]
V=ROOT/'src/DSEstimate.App/Views/MainWindow.axaml'
ST=ROOT/'src/DSEstimate.App/App.axaml'
C=ROOT/'src/DSEstimate.App/Views/MainWindow.axaml.cs'
NS={'a':'https://github.com/avaloniaui'}
checks=[]
def check(name,ok):
    checks.append((name,bool(ok)))
    print(('PASS' if ok else 'FAIL')+' | '+name)

root=etree.parse(str(V)); style=etree.parse(str(ST)); source=C.read_text(encoding='utf-8-sig')
controls=root.findall('.//a:Button',NS)
check('well-formed Avalonia views and App resources',root.getroot() is not None and style.getroot() is not None)
check('correct main window class',root.getroot().get('{http://schemas.microsoft.com/winfx/2006/xaml}Class')=='DSEstimate.Views.MainWindow')
check('exactly two result tab buttons',len([b for b in controls if 'tab' in (b.get('Classes') or '').split()])==2)
check('persistent result tab navigation bound to analysis',len([c for p in root.findall('.//a:StackPanel',NS) if p.get('Grid.Row')=='1' and p.get('IsVisible')=='{Binding HasAnalysis}' for c in p.findall('a:Button',NS)])==2)
check('summary command kept',any(b.get('Command')=='{Binding ShowSummaryCommand}' for b in controls))
check('parts command kept',any(b.get('Command')=='{Binding ShowPartsCommand}' for b in controls))
check('project save command preserved',any(b.get('Command')=='{Binding SaveCommand}' for b in controls))
check('analyze command preserved',any(b.get('Command')=='{Binding AnalyzeCommand}' for b in controls))
check('export offer preserved',any(b.get('Click')=='OnExportExcelClick' for b in controls))
check('single draggable drop zone',len(root.findall('.//a:Border',NS))>0 and len([b for b in root.findall('.//a:Border',NS) if b.get('{http://schemas.microsoft.com/winfx/2006/xaml}Name')=='DropZone'])==1)
drop=next(b for b in root.findall('.//a:Border',NS) if b.get('{http://schemas.microsoft.com/winfx/2006/xaml}Name')=='DropZone')
check('DnD disabled through CanModifyDocuments',drop.get('IsEnabled')=='{Binding CanModifyDocuments}')
check('busy drag cursor rejects drop', '_vm.CanModifyDocuments && e.DataTransfer.Formats.Contains(DataFormat.File)' in source)
drop_source=source.split('private async void OnDrop',1)[1].split('private async void OnAddFilesClick',1)[0]
legacy_guard=('if (!_vm.CanModifyDocuments)' in drop_source and drop_source.index('if (!_vm.CanModifyDocuments)')<drop_source.index('TryGetFiles()'))
short_circuit_guard='if (!_vm.CanModifyDocuments || e.DataTransfer.TryGetFiles() is not { } files)' in drop_source
check('busy drop before enumeration',legacy_guard or short_circuit_guard)
check('two theme dictionaries preserved',len(style.findall('.//a:ResourceDictionary.ThemeDictionaries/a:ResourceDictionary',NS))==2)
check('DS Compare graphite palette', '#252A30' in ST.read_text(encoding='utf-8-sig') and '#5C9ED6' in ST.read_text(encoding='utf-8-sig'))
check('warning color distinct from navigation accent', '#D9A85F' in ST.read_text(encoding='utf-8-sig') and '#AB721E' in ST.read_text(encoding='utf-8-sig'))
check('persistent status footer',len([b for b in root.findall('.//a:Border',NS) if b.get('Grid.Row')=='2' and any(t.get('Text')=='{Binding StatusText}' for t in b.iter())])==1)
check('no pricing core modification in FIX62 description', 'not** a price estimation engine' in (ROOT/'FIX62_DS_COMPARE_DESKTOP_UI.md').read_text(encoding='utf-8'))
if not all(v for _,v in checks):raise SystemExit(1)
print(f'FIX62 desktop UI: {len(checks)}/{len(checks)} PASS (structural tests, not GUI runtime)')
