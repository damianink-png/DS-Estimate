#!/usr/bin/env python3
"""Verify a *built* win-x64 launcher apphost and record reproducible evidence.

This checks the CI-only launcher compilation output, not a portable release,
installer execution, embedded payload contents, or a successful .NET test run.
The launcher binary is deliberately NOT copied into CI artifacts.
"""
from __future__ import annotations

import argparse
import hashlib
import struct
import sys
from pathlib import Path

LAUNCHER_NAME = "DS_Estimate_1_2_URUCHOM.exe"
AMD64_MACHINE = 0x8664
PE32_PLUS = 0x20B


class LauncherEvidenceError(ValueError):
    pass


def inspect_launcher(path: Path) -> dict[str, str | int]:
    if not path.is_file() or path.is_symlink():
        raise LauncherEvidenceError("launcher is missing or not a regular file")
    data = path.read_bytes()
    if len(data) < 4096 or data[:2] != b"MZ":
        raise LauncherEvidenceError("missing MZ header or implausibly small executable")
    pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
    if pe_offset < 0x40 or pe_offset + 26 > len(data):
        raise LauncherEvidenceError("invalid PE header offset")
    if data[pe_offset:pe_offset + 4] != b"PE\0\0":
        raise LauncherEvidenceError("missing PE signature")
    machine = struct.unpack_from("<H", data, pe_offset + 4)[0]
    optional_magic = struct.unpack_from("<H", data, pe_offset + 24)[0]
    if machine != AMD64_MACHINE or optional_magic != PE32_PLUS:
        raise LauncherEvidenceError("launcher is not a win-x64 PE32+ executable")
    return {
        "name": path.name,
        "bytes": len(data),
        "machine": "AMD64",
        "format": "PE32+",
        "sha256": hashlib.sha256(data).hexdigest(),
    }


def verify_build(root: Path) -> dict[str, str | int]:
    if not root.is_dir() or root.is_symlink():
        raise LauncherEvidenceError("launcher Release build directory is missing")
    candidates = sorted(root.rglob(LAUNCHER_NAME))
    if len(candidates) != 1:
        raise LauncherEvidenceError(f"expected exactly one launcher EXE, found {len(candidates)}")
    result = inspect_launcher(candidates[0])
    result["relative_path"] = str(candidates[0].relative_to(root)).replace("\\", "/")
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        result = verify_build(args.root)
        lines = ["PASS CI-only Windows launcher PE evidence"]
        lines.extend(f"{key}={value}" for key, value in result.items())
        code = 0
    except (OSError, LauncherEvidenceError) as exc:
        lines = [f"FAIL CI-only Windows launcher PE evidence: {exc}"]
        code = 1
    report = "\n".join(lines) + "\n"
    print(report, end="", file=sys.stderr if code else sys.stdout)
    try:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(report, encoding="utf-8")
    except OSError as exc:
        print(f"FAIL writing launcher evidence: {exc}", file=sys.stderr)
        return 1
    return code


if __name__ == "__main__":
    raise SystemExit(main())
