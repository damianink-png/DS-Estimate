#!/usr/bin/env python3
from pathlib import Path
import json
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8-sig')

CORE = read('src/DSEstimate.Core/CostEngine.cs')
DOMAIN = read('src/DSEstimate.Core/Domain.cs')
AN = read('src/DSEstimate.Infrastructure/ProjectAnalysisService.cs')
DOC = read('src/DSEstimate.Infrastructure/DocumentAnalyzers.cs')
PYRUN = read('src/DSEstimate.Infrastructure/PythonRunner.cs')
REP = read('src/DSEstimate.Infrastructure/DiagnosticReportService.cs')
VM = read('src/DSEstimate.App/ViewModels/MainViewModel.cs')
UI = read('src/DSEstimate.App/Views/MainWindow.axaml')
STEP = read('engines/python/analyze_step.py')
WORKER = read('engines/python/step_worker.py')
DRAW = read('engines/python/analyze_document.py')
BUILD = read('BUILD_FULL_PORTABLE_ZIP.ps1')
VER = read('VERSION.txt').strip()
passed = failed = 0

def check(name, cond, detail=''):
    global passed, failed
    if cond:
        passed += 1
        print('PASS ', name)
    else:
        failed += 1
        print('FAIL ', name, '::', detail)

# Clean public baseline identity.
check('version exactly 1.2', VER == '1.2', VER)
check('UI minimal label', 'DS Estimate 1.2 · MINIMAL UI · OFFLINE' in UI)
check('report version 1.2', 'DS Estimate 1.2 MINIMAL UI' in REP)
check('app build output 1.2', 'DS_Estimate_1_2_FULL_PORTABLE_win-x64.zip' in BUILD)
check('launcher output 1.2', 'DS_Estimate_1_2_URUCHOM.exe' in BUILD)
LAUNCHER_CSPROJ = read('src/DSEstimate.Launcher/DSEstimate.Launcher.csproj')
LAUNCHER_CODE = read('src/DSEstimate.Launcher/Program.cs')
check('launcher assembly identity 1.2', 'DS_Estimate_1_2_URUCHOM' in LAUNCHER_CSPROJ)
check('launcher extraction folder 1.2', 'ReleaseFolder = "1_2"' in LAUNCHER_CODE)
check('developer report comparator removed from clean base', not (ROOT/'POROWNAJ_RAPORTY.cmd').exists() and 'POROWNAJ_RAPORTY.cmd' not in BUILD and 'compare_diagnostic_reports.py' not in BUILD)
check('obsolete public benchmark not shipped', 'POBIERZ_I_PRZETESTUJ_PUBLICZNE' not in BUILD and 'URUCHOM_PUBLICZNY_BENCHMARK' not in BUILD)
check('obsolete public benchmark root files absent', not any((ROOT/x).exists() for x in ['PUBLIC_BENCHMARK_MANIFEST.json','POBIERZ_I_PRZETESTUJ_PUBLICZNE.cmd','POBIERZ_TESTY_PUBLICZNE.cmd','URUCHOM_PUBLICZNY_BENCHMARK.cmd','POBIERZ_I_PRZETESTUJ_PUBLICZNE.ps1']))
check('release gate uses 1.2 identity test', 'run_ds_estimate_1_2_minimal_ui.py' in read('RUN_FULL_RELEASE_TESTS.cmd'))
check('release gate excludes stale version gates', 'run_r8_2_branding_offline.py' not in read('RUN_FULL_RELEASE_TESTS.cmd') and 'run_r9_3_0_fix10j_parallel_progressive_checkpoint.py' not in read('RUN_FULL_RELEASE_TESTS.cmd'))


# 1.2 minimal UI invariants.
check('only two main analysis tabs', UI.count('<Button Classes="tab"') == 2, str(UI.count('<Button Classes="tab"')))
check('main tabs are quote and details', 'Content="Wycena"' in UI and 'Content="Szczegóły"' in UI)
check('process editor lives on quote tab', UI.count('<StackPanel IsVisible="{Binding IsSummaryTab}" Spacing="12">') >= 2)
check('risks live with technical details', UI.count('<StackPanel IsVisible="{Binding IsPartsTab}" Spacing="12">') >= 2)
check('key feature KPI row', all(x in UI for x in ['Text="OTWORY"','Text="SPOINY"','Text="MALOWANIE"','Text="CZAS PROCESÓW"']))
check('daily settings compact card', 'Text="Najważniejsze ustawienia"' in UI and 'Settings.MarkupPercent' in UI)
check('expert settings collapsed', 'Text="Tryb ekspercki"' in UI and 'Rzadko używane parametry technologiczne' in UI)
check('verbose routing hidden from default flow', 'Text="Automatyczny routing technologiczny"' in UI and '<Border Classes="card" IsVisible="False">' in UI)

# Best design branch: conditional multi-root card + safe actions.
check('multi-root card conditional', 'IsVisible="{Binding HasMultiRootRisk}"' in UI)
check('multi-root variants button', 'MarkMultiRootVariantsCommand' in UI and 'To warianty' in UI)
check('multi-root subassemblies button', 'ConfirmMultiRootSubassembliesCommand' in UI and 'To podzespoły' in UI)
check('multi-root separate quotes real command', 'SplitMultiRootQuotesCommand' in UI and 'Osobne wyceny' in UI)
check('variants remain blocking aggregate', 'cena zbiorcza pozostaje zablokowana' in VM.lower())
check('separate quotes create projects', 'await _projects.SaveAsync(child)' in VM)

# Persistent OCP worker.
check('step worker exists', (ROOT/'engines/python/step_worker.py').is_file())
check('worker imports analyze_step once', 'import analyze_step' in WORKER)
check('worker gc between jobs', 'gc.collect()' in WORKER)
check('persistent step worker pool', 'StepWorkerPools' in PYRUN and 'StepWorkerPool' in PYRUN)
check('worker pool max two', 'new StepWorkerPool(python, workerScript, 2)' in PYRUN and 'Math.Clamp(size, 1, 2)' in PYRUN)
check('worker watchdog restart', 'Restart("watchdog czasu wykonania")' in PYRUN and 'Restart("idle watchdog")' in PYRUN)

# Progressive checkpoint + robust resume.
check('FIX20 STEP cache version', 'surface4-cnc5-pocket1-hole3-dse12-fix20' in DOC)
check('checkpoint keyed with version and content', 'checkpointIdentity' in DOC and 'contentHash' in DOC)
check('partial watchdog cache not terminal', 'cached.Available && cached.WatchdogTriggered' in DOC and 'return null' in DOC)
check('resume env from host', 'DSE_STEP_RESUME' in DOC)
check('resume key persisted', 'resumeKey' in STEP and 'featureAnalyzed' in STEP)
check('resume key is pre-feature fingerprint', 'hashlib.sha256(repr(quick_key)' in STEP)
check('resume handles out-of-order groups', 'saved_by_resume_key' in STEP and 'featureAnalyzed' in STEP)
check('progressive checkpoint atomic', 'os.replace(tmp, cp)' in STEP)
check('progressive checkpoint retains holes', 'totalHoleCount' in STEP and 'checkpoint-features' in STEP)

# CNC: >=80% for topology; below threshold only actual observed features + one setup.
check('CNC threshold 80%', 'stepFeatureCoverage >= 0.80' in CORE and 'stepFeatureCoverage < 0.80' in CORE)
check('partial observed CNC evidence', 'PARTIAL_STEP_FEATURES' in CORE and 'partialObservedMachining' in CORE)
check('partial hole operations retained', 'var routedHoleOps = holeOps;' in CORE)
check('topology complexity gated', 'var complexityMinutes = geometryFeaturesReliableForRouting' in CORE)
check('bbox removal gated', 'if (geometryFeaturesReliableForRouting)' in CORE and 'removedVolumeCm3' in CORE)
check('partial observed feature minutes', 'observedFeatureMinutes' in CORE and 'minimumSetupMinutes' in CORE)
check('no topology extrapolation message', 'Topologia, bbox-removal i złożoność nie są ekstrapolowane' in CORE)

# Material hierarchy and broader density map.
check('BOM material before density', 'ResolveProjectMaterial(drawing)' in CORE and 'ResolveDensity(result.Material' in CORE)
check('mixed material protected', 'MIXED:' in CORE and 'MIXED_MATERIAL_DENSITY' in CORE)
check('aluminium grades expanded', all(x in CORE for x in ['5083','6063','2017','2024']))
check('stainless grades expanded', all(x in CORE for x in ['1.4307','1.4401','1.4571']))
check('copper brass bronze densities', all(x in CORE for x in ['8960','8500','8800']))
check('cast iron magnesium densities', '7250' in CORE and '1740' in CORE)
check('PTFE PEEK densities', 'PTFE' in CORE and 'PEEK' in CORE and '2200' in CORE and '1300' in CORE)
check('titanium grade 5 separate', '4430' in CORE and '4510' in CORE and 'GRADE 5' in CORE)

# Drawing weld length remains stronger than geometry-only candidate.
check('explicit weld fields domain', 'WeldExplicitLengthMm' in DOMAIN and 'WeldExplicitLengthConfidence' in DOMAIN)
check('explicit weld parser', 'weldExplicitLengthMm' in DRAW and 'TOTAL\\s+(?:WELD|WELDING)\\s+LENGTH' in DRAW)
check('intermittent length excluded from total', 'INTERMITTENT|PRZERYWAN|STITCH|PITCH|SKOK' in DRAW)
check('drawing weld total wins', 'explicitDrawingLengthM' in CORE and '? explicitDrawingLengthM.Value' in CORE)
check('weld cross-check retained', 'Cross-check spoin DS 1.0' in CORE)

# Audit/reporting.
check('used for pricing report', 'UŻYTE DO WYCENY / ŹRÓDŁA DECYZJI' in REP)
check('report feature coverage', 'STEP features:' in REP and 'featureCoverage' in REP)
check('report blocking risks', 'Ryzyka blokujące:' in REP)
check('report used files', 'Pliki z dowodami użytymi w decyzjach' in REP)

# Source guard and real-world safeguards remain.
check('renderings source guard retained', 'Renderings' in AN or 'RENDERINGS' in AN or 'Renderings' in read('src/DSEstimate.Infrastructure/DocumentSelectionPolicy.cs'))
check('multi-root high risk retained', 'MULTI_ROOT_STEP' in CORE and 'RiskLevel.High' in CORE)
check('parallel roots max two retained', 'Math.Min(2, parallelRootCandidates.Count)' in AN or 'MaxDegreeOfParallelism = 2' in AN or 'SemaphoreSlim(2' in AN)


# 1.0.1 behavior/audit/security additions.
UNC = read('src/DSEstimate.Core/QuoteUncertaintyModel.cs')
PKG = read('src/DSEstimate.Infrastructure/ClientPackageImportService.cs')
SLN = read('DS_Estimate.sln')
check('uncertainty model extracted', 'QuoteUncertaintyModel' in UNC and 'MinUncertaintyPercent' in UNC and 'MaxUncertaintyPercent' in UNC)
check('uncertainty drivers exposed', 'UncertaintyDrivers' in DOMAIN and 'UncertaintyDrivers' in REP and 'UncertaintyDrivers' in UI)
check('uncertainty weighted by material share', 'MaterialCostPln / total' in UNC and 'DensityAssumed' in UNC)
check('zip compression ratio guard', 'MaxCompressionRatio = 200' in PKG and 'MinRatioCheckCompressedBytes' in PKG and 'SeenCompressedBytes' in PKG)
check('package cache bumped for zip guard', 'dse101-zipguard' in PKG)
check('xunit behavior tests included', 'DSEstimate.Core.Tests' in SLN and (ROOT/'tests/DSEstimate.Core.Tests/QuoteUncertaintyModelTests.cs').is_file())

try:
    ET.parse(ROOT/'src/DSEstimate.App/Views/MainWindow.axaml')
    check('MainWindow XAML parses', True)
except Exception as exc:
    check('MainWindow XAML parses', False, str(exc))

# Runtime-light structured weld parse.
try:
    sys.path.insert(0, str(ROOT/'engines/python'))
    from analyze_document import detect_structured_technical_signals
    a = detect_structured_technical_signals('TOTAL WELD LENGTH: 6320 mm\nWELD a6 BOTH SIDES')
    b = detect_structured_technical_signals('INTERMITTENT WELD LENGTH 50 mm PITCH 100 mm')
    check('runtime total weld parse', abs((a.get('weldExplicitLengthMm') or 0)-6320) < 0.01)
    check('runtime intermittent not total', b.get('weldExplicitLengthMm') is None)
except Exception as exc:
    check('runtime weld parse', False, str(exc))

# Worker protocol survives repeated requests without CAD input.
try:
    missing_step = str(ROOT/'tests/data/dse1_missing.step')
    worker_input = ''.join(
        json.dumps({'Path': missing_step, 'Env': {}}) + '\n'
        for _ in range(2)
    ) + '__quit__\n'
    proc = subprocess.run(
        [sys.executable, '-u', str(ROOT/'engines/python/step_worker.py')],
        input=worker_input,
        capture_output=True,
        text=True,
        cwd=str(ROOT/'engines/python'),
        timeout=60,
    )
    response_lines = [line for line in proc.stdout.splitlines() if line.strip()]
    responses = [json.loads(line) for line in response_lines]
    check(
        'persistent worker protocol two jobs',
        len(responses) == 2 and proc.returncode == 0,
        f'rc={proc.returncode}; responses={len(responses)}; stderr={proc.stderr[-500:]}',
    )
except Exception as exc:
    check('persistent worker protocol two jobs', False, str(exc))

check('worker bypasses unstable native finalizers', 'os._exit(rc)' in WORKER)


# 1.1 staged-analysis invariants.
check('hole engine 3.0', '"holeEngineVersion": "3.0"' in STEP)
check('hole state distinguishes incomplete zero', 'HoleAnalysisState' in DOMAIN and 'DetectedHoleCountDisplay' in DOMAIN and 'nieustalone · STEP' in DOMAIN)
check('hole fallback requires void and near-full circumference', 'boundary_fallback' in STEP and 'angular_coverage < 0.96' in STEP and 'center_void' in STEP)
check('topology alone cannot enable CNC', 'var hasMachining = machiningKeyword || drawingPrecisionEvidence || geometryMachinedHoles > 0 || partialObservedMachining;' in CORE)
check('manual paint uses cached geometry only', 'BuildPaintEstimate(result, settings, forceCoating: true)' in CORE and 'przeliczono tylko model malowania z cache geometrii' in CORE)
check('large STEP progress watchdog', 'DSE_PROGRESS_IDLE_WATCHDOG_SECONDS' in DOC and '? 1800 : 300' in DOC)
check('persistent worker tracks progress heartbeat', '_lastProgressUtcTicks' in PYRUN and 'TIMEOUT_IDLE' in PYRUN)
check('contacts emit heartbeat', 'styki {exact_checks}/{hard_pair_cap}' in STEP)
check('joints emit heartbeat', 'spoiny/styki powierzchni' in STEP)
check('stage checkpoint contacts', 'checkpoint-contacts' in STEP)
check('stage checkpoint joints', 'checkpoint-joints' in STEP)

print(f'\nSUMMARY PASS={passed} FAIL={failed}')
raise SystemExit(1 if failed else 0)
