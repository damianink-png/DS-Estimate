#!/usr/bin/env python3
"""FIX30: Python runtime and C# source-contract checks (NOT a .NET test)."""
from __future__ import annotations
import importlib.util
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
passed = failed = skipped = 0
require_real_pdf = "--require-real-pdf" in sys.argv


def check(name, condition):
    global passed, failed
    if condition:
        passed += 1
        print('PASS', name)
    else:
        failed += 1
        print('FAIL', name)


def source(rel):
    return (ROOT / rel).read_text(encoding='utf-8-sig')


core = source('src/DSEstimate.Core/Domain.cs')
resolver = source('src/DSEstimate.Infrastructure/DrawingStepEvidenceResolver.cs')
service = source('src/DSEstimate.Infrastructure/ProjectAnalysisService.cs')
report = source('src/DSEstimate.Infrastructure/DiagnosticReportService.cs')
cs_tests = source('tests/DSEstimate.Core.Tests/Fix30DrawingStepEvidenceTests.cs')
check('C# result DTO is separate from pricing and BOM', 'public sealed class DrawingStepLink' in core and 'public List<DrawingStepLink> DrawingStepLinks' in core)
check('C# ambiguity list exposed in diagnostics', 'DrawingStepAmbiguousNumbers' in core and 'AmbiguousIdentifiers' in resolver)
check('resolver requires already verified PDF-BOM link', 'x.MatchType == "exact-within-pdf"' in resolver and 'Key(x.DrawingNumber) == Key(x.BomPartNumber)' in resolver)
check('resolver does not use fuzzy identifier matching', 'static string Key(string? value)' in resolver and '.Trim().ToUpperInvariant()' in resolver and 'GetFileNameWithoutExtension' in resolver)
check('resolver restricts candidates to existing active STEP', 'x.Kind == DocumentKind.Step' in resolver and 'x.IsActiveRevision' in resolver and '!x.ExcludeFromAnalysis' in resolver and 'File.Exists(x.Path)' in resolver)
check('resolver excludes duplicate PDF/STEP matches', 'pdfMatches.Count != 1 || stepMatches.Count != 1' in resolver)
check('resolver handles .step and .stp', '".step"' in resolver and '".stp"' in resolver)
check('source matching uses scoped drawing and active project docs', 'DrawingStepEvidenceResolver.Resolve(drawing.DrawingBomLinks, activeDocuments)' in service and 'var drawing = MergeDrawings(drawingsForFusion)' in service)
check('STEP links attached before CostEngine', service.index('drawing.DrawingStepLinks = stepEvidence.Links;') < service.index('var result = _cost.Build('))
check('report explicitly states geometry is not verified', 'geometria niezweryfikowana' in report)
check('report explicitly denies material, quantity and cost propagation', 'bez automatycznego przypisania materiału, ilości, operacji i kosztów' in report)
check('C# tests cover exact, duplicate, excluded and unverified cases', all(x in cs_tests for x in ['Unique_exact_id', 'Repeated_pdf_ids', 'Near_matches', 'Unverified_pdf_bom']))
check('Windows release test gate includes FIX30', 'run_fix30_pdf_bom_step_links.py' in source('RUN_FULL_RELEASE_TESTS.cmd'))
check('portable release test gate includes FIX30', 'run_fix30_pdf_bom_step_links.py' in source('BUILD_FULL_PORTABLE_ZIP.ps1'))

spec = importlib.util.spec_from_file_location('dse_fix30_pdf', ROOT / 'engines/python/analyze_document.py')
document = importlib.util.module_from_spec(spec)
spec.loader.exec_module(document)

page_texts = ['DRAWING NO\nPART-001\nMATERIAL: S355J2', 'POS DOKNR MENGE GEWICHT\nPART-001\n2 ST\n20 KG']
evidence = document._pdf_page_evidence(page_texts, source_file='source.pdf')
links, ambiguous = document._pdf_exact_drawing_bom_links(evidence)
check('existing Python PDF page-to-BOM linking unchanged', len(links) == 1 and links[0]['drawingNumber'] == 'PART-001' and not ambiguous)
check('PDF page evidence remains scoped to original sheet', len(evidence) == 2 and evidence[0]['pageNumber'] == 1 and evidence[1]['pageNumber'] == 2)
check('near-miss drawing number still not treated as BOM match', document._pdf_exact_drawing_bom_links(document._pdf_page_evidence([page_texts[0].replace('PART-001', 'PART_001'), page_texts[1]]))[0] == [])

try:
    import pymupdf as fitz
except ImportError as exc:
    if require_real_pdf:
        failed += 1
        print('FAIL real PDF required but PyMuPDF unavailable:', exc)
    else:
        skipped += 1
        print('SKIP actual two-page PDF:', exc)
else:
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / 'drawing-bom.pdf'
        pdf = fitz.open()
        for page_text in page_texts:
            page = pdf.new_page(width=595, height=842)
            page.insert_text((45, 55), page_text, fontsize=12)
        pdf.save(path)
        pdf.close()
        old = os.environ.get('DSE_SKIP_PDF_OCR')
        os.environ['DSE_SKIP_PDF_OCR'] = '1'
        try:
            result = document.analyze_pdf(path)
        finally:
            if old is None:
                os.environ.pop('DSE_SKIP_PDF_OCR', None)
            else:
                os.environ['DSE_SKIP_PDF_OCR'] = old
        check('real PDF keeps one exact PDF-BOM link', len(result.get('drawingBomLinks', [])) == 1)
        check('real PDF page numbers are correct', result.get('drawingBomLinks', [{}])[0].get('bomPageNumber') == 2)

print(f'\nSUMMARY PASS={passed} FAIL={failed} SKIP={skipped}')
raise SystemExit(1 if failed else 0)
