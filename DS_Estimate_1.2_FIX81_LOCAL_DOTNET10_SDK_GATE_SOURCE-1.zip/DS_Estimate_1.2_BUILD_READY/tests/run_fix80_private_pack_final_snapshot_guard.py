#!/usr/bin/env python3
"""FIX80: detect earlier sources changed after per-file validation, before ZIP replace."""
from __future__ import annotations

import contextlib
import hashlib
import importlib.util
import io
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / 'engines/python/build_private_analysis_pack.py'
spec = importlib.util.spec_from_file_location('dse_private_pack_fix80', ENGINE)
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
checks = []


def check(label, condition):
    checks.append(bool(condition))
    print(('PASS' if condition else 'FAIL') + ' | ' + label, flush=True)


def invoke(source, output, mutation=None, reader=None):
    previous_argv = sys.argv
    sys.argv = [str(ENGINE), str(source), str(output)]
    write_original = engine.write_private_entry
    read_original = engine.read_text
    invoked = False

    def on_zip_entry(*args, **kwargs):
        nonlocal invoked
        if mutation is not None and not invoked:
            invoked = True
            mutation()
        return write_original(*args, **kwargs)

    def on_read(path):
        if reader is not None:
            reader(path)
        return read_original(path)

    output_text = io.StringIO()
    try:
        with patch.object(engine, 'write_private_entry', on_zip_entry), patch.object(engine, 'read_text', on_read):
            with contextlib.redirect_stdout(output_text):
                try:
                    engine.main()
                except SystemExit as exc:
                    return str(exc.code), output_text.getvalue()
        return '0', output_text.getvalue()
    finally:
        sys.argv = previous_argv


with tempfile.TemporaryDirectory(prefix='dse_fix80_') as tmp:
    root = Path(tmp) / 'source'
    root.mkdir()
    first = root / 'a.txt'
    second = root / 'b.txt'
    first.write_text('Material S355 CNC\n', encoding='utf-8')
    second.write_text('Material S690 CNC\n', encoding='utf-8')
    output = root / 'private.zip'
    result = subprocess.run([sys.executable, str(ENGINE), str(root), str(output)],
                            capture_output=True, text=True, timeout=30)
    check('stable real CLI exits 0', result.returncode == 0)
    check('stable real CLI returns ok=true', result.returncode == 0 and json.loads(result.stdout)['ok'] is True)
    with zipfile.ZipFile(output) as archive:
        check('stable ZIP CRC passes', archive.testzip() is None)
        check('stable ZIP includes both sources', json.loads(archive.read('MANIFEST.json'))['file_count'] == 2)
    original = output.read_bytes()
    original_hash = hashlib.sha256(original).hexdigest()

    def change_first():
        first.write_text('Material S960 CNC\n', encoding='utf-8')

    status, message = invoke(root, output, mutation=change_first)
    check('late source edit is rejected', status == 'SOURCE_CHANGED_DURING_PACK')
    check('late source edit actually happened', first.read_text(encoding='utf-8') == 'Material S960 CNC\n')
    check('late source edit does not replace previous ZIP', output.read_bytes() == original)
    check('late source edit preserves previous ZIP SHA256', hashlib.sha256(output.read_bytes()).hexdigest() == original_hash)
    check('late source edit leaves no temp ZIP', not list(root.glob('.private.zip.*.tmp')))
    check('late source edit does not leak private path', str(first) not in status + message)

    first.write_text('Material S355 CNC\n', encoding='utf-8')
    status, message = invoke(root, output, mutation=first.unlink)
    check('late deletion is rejected', status == 'SOURCE_CHANGED_DURING_PACK')
    check('late deletion happened', not first.exists())
    check('late deletion preserves previous ZIP', output.read_bytes() == original)
    check('late deletion leaves no temp ZIP', not list(root.glob('.private.zip.*.tmp')))
    check('late deletion does not leak private path', str(first) not in status + message)

    first.write_text('Material S355 CNC\n', encoding='utf-8')
    def mutate_early(path):
        if path == second:
            first.write_text('Material S960 CNC\n', encoding='utf-8')
    status, _ = invoke(root, output, reader=mutate_early)
    check('early file edited during later file extraction is rejected', status == 'SOURCE_CHANGED_DURING_PACK')
    check('early edit preserves previous ZIP', output.read_bytes() == original)

    first.write_text('Material S355 CNC\n', encoding='utf-8')
    status, success = invoke(root, output)
    check('stable retry succeeds', status == '0')
    check('stable retry reports ok=true', json.loads(success)['ok'] is True)
    with zipfile.ZipFile(output) as archive:
        check('retry ZIP CRC passes', archive.testzip() is None)
        files = json.loads(archive.read('MANIFEST.json'))['files']
        check('retry ZIP records both sources', len(files) == 2)
        hashes = {item['sha256'] for item in files}
        check('retry SHA256 corresponds to both current files', hashes == {
            hashlib.sha256(first.read_bytes()).hexdigest(),
            hashlib.sha256(second.read_bytes()).hexdigest()})

cmd = (ROOT / 'RUN_FULL_RELEASE_TESTS.cmd').read_text('utf-8-sig')
ps1 = (ROOT / 'BUILD_FULL_PORTABLE_ZIP.ps1').read_text('utf-8-sig')
workflow = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text('utf-8')
name = 'run_fix80_private_pack_final_snapshot_guard.py'
check('CMD includes FIX80 and propagates exit', ('%PY% tests\\' + name + ' || exit /b 1') in cmd)
check('PowerShell includes FIX80', ('"tests\\' + name + '",') in ps1)
check('private Windows CI includes FIX80', ('run: python tests/' + name) in workflow)

print(f'SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0', flush=True)
raise SystemExit(0 if all(checks) else 1)
