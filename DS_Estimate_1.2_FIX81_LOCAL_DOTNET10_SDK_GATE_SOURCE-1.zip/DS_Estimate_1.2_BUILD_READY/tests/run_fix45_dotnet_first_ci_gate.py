#!/usr/bin/env python3
"""FIX45: assert the .NET/launcher/xUnit gates precede optional PDF dependency.

This is a static workflow regression. It does not run .NET, Windows or xUnit.
"""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text(encoding='utf-8')
checks: list[tuple[str, bool]] = []


def check(label: str, ok: bool) -> None:
    checks.append((label, bool(ok)))
    print(('PASS ' if ok else 'FAIL ') + label, flush=True)


def position(name: str) -> int:
    marker = f'      - name: {name}\n'
    check(f'unique CI step: {name}', WORKFLOW.count(marker) == 1)
    return WORKFLOW.find(marker)


names = [
    'Restore .NET solution',
    'Compile solution C# projects (including Avalonia app)',
    'Prepare CI-only launcher compile fixture',
    'Compile Windows launcher C# (not a release)',
    'Capture C# xUnit discovery listing',
    'Run C# xUnit tests',
    'Verify xUnit TRX contains executed tests',
    'Install real PDF regression dependency',
    'Check Python engine syntax and PDF BOM contracts',
    'Save test results',
]
locations = [position(name) for name in names]
check('C# solution, launcher, discovery, xUnit, TRX verification precede PDF install',
      all(x >= 0 for x in locations) and locations == sorted(locations))
check('Python 3.12 available before launcher fixture',
      WORKFLOW.index('actions/setup-python@v5') < locations[2])
check('PyMuPDF dependency still pinned and checked',
      'PyMuPDF==1.26.7' in WORKFLOW and
      'python -c "import pymupdf;' in WORKFLOW)
check('real PDF regressions still fail on SKIP',
      'python tests/run_fix29_pdf_exact_bom_links.py --require-real-pdf' in WORKFLOW and
      'python tests/run_fix30_pdf_bom_step_links.py --require-real-pdf' in WORKFLOW)
check('strict real TRX gate preserved',
      'python tests/verify_dotnet_trx.py TestResults/ds-estimate-xunit.trx '
      '--require-results --min-executed 60' in WORKFLOW)
check('native exit code checks remain in PDF gate',
      WORKFLOW.count('if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }') >= 10)
check('evidence upload is unconditional and excludes source',
      'if: always()' in WORKFLOW and
      all(x in WORKFLOW for x in ('TestResults/xunit-discovery.txt',
          'TestResults/xunit-execution.log', 'TestResults/python-pdf-dependency.log',
          'TestResults/python-engine-regression.log')) and
      all(x not in WORKFLOW[locations[-1]:] for x in ('src/', 'engines/python/', 'launcher-smoke')))
for gate in ('RUN_FULL_RELEASE_TESTS.cmd', 'BUILD_FULL_PORTABLE_ZIP.ps1'):
    check(f'{gate} includes FIX45',
          'run_fix45_dotnet_first_ci_gate.py' in
          (ROOT / gate).read_text(encoding='utf-8-sig'))
passed = sum(ok for _, ok in checks)
print(f'SUMMARY PASS={passed} FAIL={len(checks)-passed} SKIP=0', flush=True)
raise SystemExit(0 if passed == len(checks) else 1)
