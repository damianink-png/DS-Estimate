#!/usr/bin/env python3
"""FIX59: synthetic VSTest discovery transcript grammar checks; NOT .NET tests."""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "tests/verify_xunit_discovery.py"
spec = importlib.util.spec_from_file_location("dse_fix59_discovery", TARGET)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
checks: list[bool] = []


def check(name: str, passed: bool) -> None:
    checks.append(bool(passed))
    print(("PASS " if passed else "FAIL ") + name, flush=True)


def listing(lines: list[str]) -> str:
    return ("Test run for DSEstimate.Core.Tests.dll (.NETCoreApp,Version=v10.0)\n"
            "The following Tests are available:\n" +
            "".join("    " + line + "\n" for line in lines))


names = [f"DSEstimate.Core.Tests.Fix59.Case{i:03d}" for i in range(60)]
with tempfile.TemporaryDirectory(prefix="dse-fix59-") as tmp:
    file = Path(tmp) / "xunit-discovery.txt"

    def verify(text: str, minimum: int = 1) -> tuple[bool, str]:
        file.write_text(text, encoding="utf-8")
        try:
            return True, str(mod.verify_discovery(file, min_discovered=minimum))
        except mod.DiscoveryError as exc:
            return False, str(exc)

    ok, msg = verify(listing(names), 60)
    check("60 qualified test identities accepted", ok and msg == "60")
    ok, msg = verify(listing(["Warning: Runtime.Some.Type"]))
    check("indented warning cannot masquerade as test", not ok and "Too few" in msg)
    ok, msg = verify(listing(["Error: Microsoft.TestPlatform.ObjectModel"]))
    check("indented error cannot masquerade as test", not ok and "Too few" in msg)
    ok, msg = verify(listing(["Prose message about Foo.Bar.Baz"]))
    check("indented prose cannot masquerade as test", not ok and "Too few" in msg)
    ok, msg = verify(listing(["Test.WithoutMethod"]))
    check("two-part non-qualified identity rejected", not ok)
    ok, msg = verify(listing(["Namespace.Class.Method"]))
    check("three-part qualified identity accepted", ok and msg == "1")
    ok, msg = verify(listing(["Namespace.Outer+Inner.Method"]))
    check("nested C# type identity accepted", ok and msg == "1")
    ok, msg = verify(listing(["Namespace.Generic`1.Method"]))
    check("generic C# type identity accepted", ok and msg == "1")
    ok, msg = verify(listing(["Namespace.Class.Theory(value: 1, name: \"a b\")"]))
    check("parameterized test identity accepted", ok and msg == "1")
    ok, msg = verify(listing(names[:59] + ["Warning: Runtime.Some.Type"]), 60)
    check("59 real tests plus warning do not reach 60", not ok and "59 < 60" in msg)
    ok, msg = verify(listing(names + [names[0]]), 60)
    check("FIX58 duplicate rejection preserved", not ok and "Duplicate" in msg)
    ok, msg = verify(listing(names[:59]), 60)
    check("FIX57 minimum 60 preserved", not ok and "59 < 60" in msg)
    file.write_text(listing(names[:59] + ["Warning: Runtime.Some.Type"]), encoding="utf-8")
    proc = subprocess.run([sys.executable, str(TARGET), str(file), "--min-discovered", "60"],
                          capture_output=True, text=True)
    check("CLI rejects warning-inflated list with exit 1", proc.returncode == 1)
    file.write_text(listing(names), encoding="utf-8")
    proc = subprocess.run([sys.executable, str(TARGET), str(file), "--min-discovered", "60"],
                          capture_output=True, text=True)
    check("CLI accepts 60 qualified tests with exit 0", proc.returncode == 0 and "listed=60" in proc.stdout)

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
check("workflow keeps actual discovery and strict minimum", "--list-tests" in workflow and
      "verify_xunit_discovery.py TestResults/xunit-discovery.txt --min-discovered 60" in workflow)
check("workflow includes FIX59 regression", "python tests/run_fix59_xunit_qualified_name_guard.py" in workflow)
for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{gate} includes FIX59", "run_fix59_xunit_qualified_name_guard.py" in
          (ROOT / gate).read_text(encoding="utf-8-sig"))
print(f"SUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)} SKIP=0", flush=True)
raise SystemExit(0 if all(checks) else 1)
