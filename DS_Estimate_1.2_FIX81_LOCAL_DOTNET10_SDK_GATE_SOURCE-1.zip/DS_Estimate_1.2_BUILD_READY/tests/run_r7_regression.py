﻿#!/usr/bin/env python3
from __future__ import annotations

import json
import math
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENGINES = ROOT / "engines" / "python"
sys.path.insert(0, str(ENGINES))

from analyze_document import result_from_text, _ocr_pass_conflicts, merge_ocr_texts

PASS = 0
FAIL = 0
SKIP = 0
DETAILS: list[str] = []


def check(name: str, condition: bool, detail: str = ""):
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"PASS  {name}")
    else:
        FAIL += 1
        DETAILS.append(f"{name}: {detail}")
        print(f"FAIL  {name} :: {detail}")


def skip(name: str, detail: str):
    global SKIP
    SKIP += 1
    print(f"SKIP  {name} :: {detail}")


def run_json(script: Path, file: Path):
    cp = subprocess.run(
        [sys.executable, str(script), str(file)],
        text=True,
        capture_output=True,
        cwd=str(ROOT),
        timeout=120,
    )
    if not cp.stdout.strip():
        raise RuntimeError(f"{script.name}: no stdout; stderr={cp.stderr}")
    return json.loads(cp.stdout.strip().splitlines()[-1])


def test_document_parser():
    false_cases = [
        "WELD 135 a6 both sides",
        "WELD 111 a8",
        "WELD 136 z6",
        "SHAFT Ø50 h7",
        "SHAFT FI 40 h6",
    ]
    for text in false_cases:
        r = result_from_text(text)
        check(f"document false-hole guard: {text}", len(r["holeRequirements"]) == 0, str(r["holeRequirements"]))

    true_cases = [
        ("HOLE Ø50 H7 REAMED", 50.0, "H7"),
        ("HOLE @50 H7 REAMED", 50.0, "H7"),  # common OCR replacement for Ø
        ("HOLE FI 25 H8", 25.0, "H8"),
        ("HOLE D=20 H7", 20.0, "H7"),
        ("DIA 12 H9", 12.0, "H9"),
    ]
    for text, dia, fit in true_cases:
        r = result_from_text(text)
        holes = r["holeRequirements"]
        ok = len(holes) >= 1 and abs(float(holes[0]["nominalDiameterMm"]) - dia) < 1e-6 and holes[0]["fitCode"] == fit
        check(f"document true hole: {text}", ok, str(holes))

    mixed = result_from_text(
        "S355J2+N\nWELD 135 a6 BOTH SIDES\nHOLE Ø50 H7 REAMED\nSHAFT Ø40 h6\nRAL 9005\nDFT 120 um\nMT 100%"
    )
    check("mixed material", mixed["materialHint"].startswith("S355J2"), str(mixed["materialHint"]))
    check("mixed weld process", mixed["weldProcessCode"] == "135", str(mixed["weldProcessCode"]))
    check("mixed weld size", mixed["weldSizeKind"] == "a" and abs(float(mixed["weldSizeMm"]) - 6) < 1e-6, str((mixed["weldSizeKind"], mixed["weldSizeMm"])))
    check("mixed weld sides", mixed["weldSideCount"] == 2, str(mixed["weldSideCount"]))
    check("mixed fit ignores shaft", len(mixed["holeRequirements"]) == 1 and mixed["holeRequirements"][0]["fitCode"] == "H7", str(mixed["holeRequirements"]))
    check("mixed RAL", mixed["paintColour"] == "RAL 9005", str(mixed["paintColour"]))
    check("mixed DFT", abs(float(mixed["totalDftMicron"]) - 120) < 1e-6, str(mixed["totalDftMicron"]))

    conflicts = _ocr_pass_conflicts("RAL 9005 DFT 120 um HOLE Ø50 H7", "RAL 8005 DFT 100 um HOLE Ø60 H7")
    joined = " | ".join(conflicts)
    check("OCR cross-check catches RAL", "RAL" in joined, joined)
    check("OCR cross-check catches DFT", "DFT" in joined, joined)
    check("OCR cross-check catches holes", "otwory/tolerancje" in joined, joined)
    no_conflict = _ocr_pass_conflicts("RAL 9005", "unreadable text")
    check("OCR cross-check does not flag one-pass miss", no_conflict == [], str(no_conflict))

    recovered_text = merge_ocr_texts("HOLE 050 H7 REAMED", "HOLE 950 H7 REAMED")
    recovered = result_from_text(recovered_text)
    check(
        "OCR two-pass lost-diameter recovery",
        len(recovered["holeRequirements"]) == 1
        and abs(float(recovered["holeRequirements"][0]["nominalDiameterMm"]) - 50) < 1e-6
        and recovered["holeRequirements"][0]["fitCode"] == "H7",
        recovered_text + " :: " + str(recovered["holeRequirements"]),
    )


def test_revision_regex_source():
    src = (ROOT / "src" / "DSEstimate.Infrastructure" / "ProjectAnalysisService.cs").read_text(encoding="utf-8")
    # Keep this test tied to the intended conservative grammar used by C#.
    explicit = re.compile(r"(?i)(?:^|[_\- .])REV(?:ISION)?[_\- .]*([A-Z0-9]{1,4})(?:$|[_\- .])")
    short = re.compile(r"(?i)(?:^|[_\- .])R(\d{1,4}(?![_\- .]\d)|[A-Z])(?:$|[_\- .])")

    def get_rev(stem: str):
        m = explicit.search(stem)
        if m:
            return m.group(1).upper()
        m = short.search(stem)
        return m.group(1).upper() if m else None

    expected = {
        "PART_REV_A": "A",
        "PART_REV02": "02",
        "PART_R1": "1",
        "PART_R12_MODEL": "12",
        "PART_RA": "A",
        "PART_RIB": None,
        "PART_RHS": None,
        "PART_RING": None,
        "DS_ESTIMATE_R8_3_PACKAGE": None,
        "PART_REV_B_DRAWING": "B",
    }
    for stem, rev in expected.items():
        check(f"revision: {stem}", get_rev(stem) == rev, f"got {get_rev(stem)!r}, expected {rev!r}")
    check("revision source rejects version token R8_3", "(?![ _\\-.][0-9])" in src, "C# source no longer protects against version-like R8_3 tokens")


def test_dxf(tmp: Path):
    try:
        import ezdxf
    except Exception as exc:
        skip("DXF geometry suite", f"ezdxf unavailable: {exc}")
        return

    def build(name: str, units_code: int, scale: float):
        p = tmp / name
        doc = ezdxf.new("R2013")
        doc.units = units_code
        msp = doc.modelspace()
        w, h, radius = 100.0 / scale, 50.0 / scale, 5.0 / scale
        msp.add_lwpolyline([(0, 0), (w, 0), (w, h), (0, h)], close=True)
        msp.add_circle((w * 0.5, h * 0.5), radius)
        doc.saveas(p)
        return p

    expected = 2 * (100 + 50) + 2 * math.pi * 5
    mm = run_json(ENGINES / "analyze_dxf.py", build("shape_mm.dxf", 4, 1.0))
    inch = run_json(ENGINES / "analyze_dxf.py", build("shape_inch.dxf", 1, 25.4))
    unitless = run_json(ENGINES / "analyze_dxf.py", build("shape_unitless.dxf", 0, 1.0))

    check("DXF mm cut length", abs(mm["cutLengthMm"] - expected) < 0.5, f"got {mm['cutLengthMm']}, expected {expected}")
    check("DXF mm closed profiles", mm["closedProfileCount"] == 2 and mm["minimumPierceCount"] == 2, str(mm))
    check("DXF mm reliable", mm["geometryMeasurementReliable"] is True, str(mm))
    check("DXF inch unit conversion", abs(inch["cutLengthMm"] - expected) < 0.7, f"got {inch['cutLengthMm']}, expected {expected}")
    check("DXF inch reliable", inch["geometryMeasurementReliable"] is True, str(inch))
    check("DXF unitless blocks automatic length costing", unitless["geometryMeasurementReliable"] is False, str(unitless))
    check("DXF unitless warning", any("DXF_UNITS_UNKNOWN" in w for w in unitless["warnings"]), str(unitless["warnings"]))

    # Production-style DXF: a contour exported as separate LINE entities plus
    # marking and dimension/helper layers. Only CUT geometry should drive cutting.
    layered_path = tmp / "layered_lines.dxf"
    doc = ezdxf.new("R2013"); doc.units = 4
    for layer in ("CUT", "ETCH", "DIM"):
        if layer not in doc.layers:
            doc.layers.add(layer)
    msp = doc.modelspace()
    rect = [((0, 0), (100, 0)), ((100, 0), (100, 50)), ((100, 50), (0, 50)), ((0, 50), (0, 0))]
    for a, b in rect:
        msp.add_line(a, b, dxfattribs={"layer": "CUT"})
    msp.add_circle((50, 25), 5, dxfattribs={"layer": "ETCH"})
    msp.add_line((0, -10), (100, -10), dxfattribs={"layer": "DIM"})
    doc.saveas(layered_path)
    layered = run_json(ENGINES / "analyze_dxf.py", layered_path)
    check("DXF chained LINE contour", layered["closedProfileCount"] == 1 and layered["minimumPierceCount"] == 1 and layered["openPathCount"] == 0, str(layered))
    check("DXF layer filter CUT length", abs(layered["cutLengthMm"] - 300.0) < 0.2, str(layered))
    check("DXF ETCH separated from cutting", abs(layered["markingLengthMm"] - (2 * math.pi * 5)) < 0.2, str(layered))
    check("DXF helper layer ignored", abs(layered["ignoredNonCutLengthMm"] - 100.0) < 0.2, str(layered))

    open_path = tmp / "open_lines.dxf"
    doc = ezdxf.new("R2013"); doc.units = 4; msp = doc.modelspace()
    for a, b in rect[:3]:
        msp.add_line(a, b)
    doc.saveas(open_path)
    opened = run_json(ENGINES / "analyze_dxf.py", open_path)
    check("DXF open chain reported once", opened["closedProfileCount"] == 0 and opened["openPathCount"] == 1 and opened["minimumPierceCount"] == 1 and opened["cutStartCount"] == 1, str(opened))


def test_step(tmp: Path):
    try:
        import cadquery as cq
    except Exception as exc:
        skip("STEP geometry suite", f"cadquery unavailable: {exc}")
        return

    def save(name: str, obj):
        p = tmp / name
        cq.exporters.export(obj, str(p))
        return p

    # Through hole plate.
    through = cq.Workplane("XY").box(100, 80, 20).faces(">Z").workplane().hole(20)
    r = run_json(ENGINES / "analyze_step.py", save("through.step", through))
    check("STEP through-hole count", r["totalHoleCount"] == 1, str(r.get("holes")))
    check("STEP through-hole flag", bool(r["parts"][0]["holes"][0]["throughLikely"]), str(r["parts"][0]["holes"]))
    expected_vol = 100 * 80 * 20 - math.pi * 10 * 10 * 20
    check("STEP through-hole volume", abs(r["volumeMm3"] - expected_vol) < 1.0, f"got {r['volumeMm3']}, expected {expected_vol}")

    # Blind hole.
    blind = cq.Workplane("XY").box(100, 80, 20).faces(">Z").workplane().hole(10, depth=8)
    rb = run_json(ENGINES / "analyze_step.py", save("blind.step", blind))
    check("STEP blind-hole count", rb["totalHoleCount"] == 1, str(rb.get("holes")))
    check("STEP blind-hole flag", not bool(rb["parts"][0]["holes"][0]["throughLikely"]), str(rb["parts"][0]["holes"]))
    check("STEP blind-hole depth", abs(float(rb["parts"][0]["holes"][0]["depthMm"]) - 8) < 0.2, str(rb["parts"][0]["holes"]))

    # Counterbore.
    cb = cq.Workplane("XY").box(100, 80, 20).faces(">Z").workplane().cboreHole(10, 20, 5)
    rcb = run_json(ENGINES / "analyze_step.py", save("counterbore.step", cb))
    check("STEP counterbore physical-hole merge", rcb["totalHoleCount"] == 1, str(rcb.get("holes")))
    check("STEP counterbore classification", bool(rcb["parts"][0]["holes"][0].get("counterboreLikely")), str(rcb["parts"][0]["holes"]))

    # Countersink 90 deg.
    cs = cq.Workplane("XY").box(100, 80, 20).faces(">Z").workplane().cskHole(10, 20, 90)
    rcs = run_json(ENGINES / "analyze_step.py", save("countersink.step", cs))
    check("STEP countersink classification", rcs["totalHoleCount"] == 1 and bool(rcs["parts"][0]["holes"][0].get("countersinkLikely")), str(rcs.get("holes")))
    angle = rcs["parts"][0]["holes"][0].get("countersinkAngleDeg")
    check("STEP countersink angle", angle is not None and abs(float(angle) - 90) < 0.6, str(rcs["parts"][0]["holes"]))

    # External cylinder is not a hole.
    rod = cq.Workplane("XY").circle(25).extrude(100)
    rr = run_json(ENGINES / "analyze_step.py", save("rod.step", rod))
    check("STEP external cylinder not hole", rr["totalHoleCount"] == 0, str(rr.get("holes")))

    # Tube internal bore is a true through hole / bore.
    tube = cq.Workplane("XY").circle(25).circle(20).extrude(100)
    rt = run_json(ENGINES / "analyze_step.py", save("tube.step", tube))
    check("STEP tube internal bore", rt["totalHoleCount"] >= 1 and any(abs(float(h.get("diameterMm", 0)) - 40) < 0.5 for h in rt["parts"][0]["holes"]), str(rt.get("holes")))

    # T-joint: two bodies touching on 80x8 contact patch.
    base = cq.Workplane("XY").box(120, 100, 10).translate((0, 0, 5))
    rib = cq.Workplane("XZ").box(80, 40, 8).translate((0, 0, 30))
    compound = cq.Compound.makeCompound([base.val(), rib.val()])
    rj = run_json(ENGINES / "analyze_step.py", save("t_joint.step", compound))
    check("STEP T-joint bodies", rj["solidCount"] == 2, str(rj))
    check("STEP T-joint weld candidate", rj["weldCandidatePairs"] >= 1 and rj["weldCandidateLengthMm"] > 70, str(rj.get("jointCandidates")))
    check("STEP T-joint mating hidden", rj["hiddenMatingSurfaceMm2"] > 1000, str(rj))

    # Two touching plates with matching coaxial holes: probable bolted joint, not weld.
    p1 = cq.Workplane("XY").box(80, 80, 10).faces(">Z").workplane().hole(14).translate((0, 0, 5))
    p2 = cq.Workplane("XY").box(80, 80, 10).faces(">Z").workplane().hole(14).translate((0, 0, 15))
    bolt_comp = cq.Compound.makeCompound([p1.val(), p2.val()])
    rbj = run_json(ENGINES / "analyze_step.py", save("bolted_joint.step", bolt_comp))
    check("STEP probable bolted pair", rbj["possibleBoltedJointPairs"] >= 1, str(rbj.get("jointCandidates")))
    check("STEP probable bolted pair not weld", rbj["weldCandidatePairs"] == 0, str(rbj.get("jointCandidates")))


def test_tabular_and_docs(tmp: Path):
    try:
        from openpyxl import Workbook
    except Exception as exc:
        skip("XLSX BOM", f"openpyxl unavailable: {exc}")
    else:
        p = tmp / "bom.xlsx"
        wb = Workbook(); ws = wb.active
        ws.append(["Part Number", "Qty", "Description", "Material"])
        ws.append(["P-001", 2, "Plate", "S355J2+N"])
        ws.append(["P-002", 4, "Rib", "S355J2+N"])
        wb.save(p)
        r = run_json(ENGINES / "analyze_tabular.py", p)
        check("XLSX BOM items", len(r["bomItems"]) == 2, str(r["bomItems"]))
        check("XLSX material", r["materialHint"].startswith("S355J2"), str(r["materialHint"]))

    p = tmp / "bom.csv"
    p.write_text("Part Number;Qty;Description;Material\nP-001;2;Plate;S355J2+N\nP-002;4;Rib;S355J2+N\n", encoding="utf-8")
    r = run_json(ENGINES / "analyze_tabular.py", p)
    check("CSV BOM items", len(r["bomItems"]) == 2, str(r["bomItems"]))

    p = tmp / "notes.txt"
    p.write_text("S355J2+N\nWELD 135 a6 BOTH SIDES\nHOLE Ø50 H7 REAMED\nRAL 9005\nDFT 120 um\n", encoding="utf-8")
    r = run_json(ENGINES / "analyze_tabular.py", p)
    check("TXT technical extraction", r["weldProcessCode"] == "135" and r["paintColour"] == "RAL 9005" and len(r["holeRequirements"]) == 1, str(r))

    try:
        from docx import Document
    except Exception as exc:
        skip("DOCX technical extraction", f"python-docx unavailable: {exc}")
    else:
        p = tmp / "notes.docx"
        doc = Document(); doc.add_paragraph("S355J2+N"); doc.add_paragraph("WELD 135 a6 BOTH SIDES"); doc.add_paragraph("HOLE Ø50 H7 REAMED"); doc.add_paragraph("RAL 9005 DFT 120 um"); doc.save(p)
        r = run_json(ENGINES / "analyze_tabular.py", p)
        check("DOCX technical extraction", r["weldProcessCode"] == "135" and r["paintColour"] == "RAL 9005" and len(r["holeRequirements"]) == 1, str(r))


def test_python_syntax():
    scripts = list(ENGINES.glob("*.py"))
    cp = subprocess.run([sys.executable, "-m", "py_compile", *map(str, scripts)], capture_output=True, text=True)
    check("Python engine syntax", cp.returncode == 0, cp.stderr)


def main():
    print("DS Estimate V5.6 R7 regression suite")
    test_python_syntax()
    test_document_parser()
    test_revision_regex_source()
    with tempfile.TemporaryDirectory(prefix="ds_estimate_r7_") as td:
        tmp = Path(td)
        test_dxf(tmp)
        test_step(tmp)
        test_tabular_and_docs(tmp)

    print("\nSUMMARY")
    print(f"PASS={PASS} FAIL={FAIL} SKIP={SKIP}")
    if DETAILS:
        print("FAILURES:")
        for d in DETAILS:
            print(" -", d)
    return 1 if FAIL else 0


if __name__ == "__main__":
    # CadQuery/OCP may spend a very long time in interpreter finalizers after
    # all assertions and temporary-file cleanup have already completed.  That
    # can falsely hang the portable release build.  Flush the test report and
    # terminate with the actual test code immediately.
    rc = main()
    try:
        sys.stdout.flush(); sys.stderr.flush()
    finally:
        os._exit(rc)
