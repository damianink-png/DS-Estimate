#!/usr/bin/env python3
from pathlib import Path
import importlib.util, json, subprocess, sys, tempfile, zipfile

ROOT = Path(__file__).resolve().parents[1]
checks=[]
def check(name, cond, detail=''):
    ok=bool(cond); checks.append(ok)
    print(('PASS  ' if ok else 'FAIL  ')+name+(f' :: {detail}' if detail else ''))

resolver=(ROOT/'src/DSEstimate.Infrastructure/DocumentFamilyResolver.cs').read_text(encoding='utf-8-sig')
merge=(ROOT/'src/DSEstimate.Infrastructure/ProjectAnalysisService.cs').read_text(encoding='utf-8-sig')
domain=(ROOT/'src/DSEstimate.Core/Domain.cs').read_text(encoding='utf-8-sig')
cost=(ROOT/'src/DSEstimate.Core/CostEngine.cs').read_text(encoding='utf-8-sig')
evidence=(ROOT/'src/DSEstimate.Infrastructure/EvidenceOrchestrator.cs').read_text(encoding='utf-8-sig')
report=(ROOT/'src/DSEstimate.Infrastructure/DiagnosticReportService.cs').read_text(encoding='utf-8-sig')
private_py=(ROOT/'engines/python/build_private_analysis_pack.py').read_text(encoding='utf-8')
xunit=(ROOT/'tests/DSEstimate.Core.Tests/Fix12DResolverTests.cs').read_text(encoding='utf-8-sig')

check('resolver source exists', 'class DocumentFamilyResolution' in resolver and 'class DocumentFamilyResolver' in resolver)
check('root BOM candidates require real BOM rows', 'IsAuthoritativeBomSource' in resolver and 'BomItems.Count >= 3' in resolver)
check('resolver extracts stable 8-14 digit entity key', r'\d{8,14}' in resolver)
check('weak BOM remains audit only', 'ScopeEnforced' in resolver and 'minCorroboration' in resolver and 'AUDIT_ONLY' in merge)
check('hierarchical BOM closure expands child lists', 'while (queue.Count > 0' in resolver and 'bomByEntity' in resolver)
check('ambiguous multiple roots are audit only', 'ambiguousRoots' in resolver and '!ambiguousRoots && corroboration' in resolver)
check('fusion filters numbered families before merge', 'drawingsForFusion' in merge and 'dxfsForFusion' in merge and 'familyResolution.Allows' in merge)
check('BOM quantity routing uses entity family key', 'DocumentFamilyResolver.RoutingKey(item.PartNumber)' in merge)
check('suspicious OCR fractional huge quantity guarded', 'Math.Abs(item.Quantity - Math.Round(item.Quantity))' in merge and 'item.Quantity > 100' in merge)
check('partial STEP cannot set project total mass', 'StepGeometryProjectCoveragePartial ? null' in cost and 'PARTIAL_PROJECT' in evidence)
check('partial STEP evidence excluded from total consensus', 'or "PARTIAL_PROJECT"' in evidence)
check('mixed local materials are evidence not global conflict', 'material_local' in evidence and 'PART:' in evidence)
check('resolver audit section in report', 'FIX12D / RESOLVER RODZIN DOKUMENTÓW' in report and 'egzekwowanie scope' in report)
check('resolver metadata stored in domain', 'ResolvedFamilyScopeEnforced' in domain and 'ResolvedProductionFamilies' in domain)
check('xunit behavior tests included', 'Root_bom_limits_foreign_numbered_families_when_correlated' in xunit and 'Weak_ocr_bom_is_audit_only_and_does_not_filter' in xunit and 'Nested_authoritative_bom_expands_leaf_families' in xunit)
release_cmd=(ROOT/'RUN_FULL_RELEASE_TESTS.cmd').read_text(encoding='ascii')
build_ps=(ROOT/'BUILD_FULL_PORTABLE_ZIP.ps1').read_text(encoding='utf-8-sig')
check('FIX12D wired into source release gate', 'run_fix12d_resolver_scope.py' in release_cmd)
check('FIX12D wired into portable build gate', 'run_fix12d_resolver_scope.py' in build_ps)

# Runtime parser behavior for dense supplier legends: A40/A41 requirement indexes.
spec=importlib.util.spec_from_file_location('ad', ROOT/'engines/python/analyze_document.py')
ad=importlib.util.module_from_spec(spec); spec.loader.exec_module(ad)
legend='''Welded construction ISO 5817 C\nA1: ISO 5817-B\nA2: ISO 5817-C\nA3: ISO 5817-D\nA10: ISO 4063-783\nA20: STA11 / S-Hett\nA40: ISO 17635-UT\nA41: ISO 17635-MT'''
r=ad.detect_structured_technical_signals(legend)
check('A40 A41 A20 legend not parsed as weld throat', r.get('weldSizeMm') is None, str(r.get('weldSizeMm')))
r2=ad.detect_structured_technical_signals('WELD DETAIL\nfillet weld a4\nISO 5817 C')
check('real a4 weld remains recognized', abs((r2.get('weldSizeMm') or 0)-4.0)<1e-9, str(r2.get('weldSizeMm')))
erp=ad.detect_structured_technical_signals('Pos DokNr Menge Gewicht\nL 90000000002\n1,000 ST\n6.661,626 KG\nL 90000000003\n1,000 ST\n62,800 KG')
check('largest hierarchical BOM row is not project total', erp.get('documentMassScope')=='SUBASSEMBLY', str(erp.get('documentMassScope')))

# Runtime private-pack privacy: cost values stay usable, actual contact data and IDs are redacted.
with tempfile.TemporaryDirectory() as td:
    td=Path(td); src=td/'src'; src.mkdir(); out=td/'pack.zip'
    (src/'90000000001_metrics.txt').write_text(
        'Koszt razem: 1234567.89 PLN\nCzas CNC: 80.2 h\nTel: +48 123 456 789\nDrawing no: 90000000003\nMaterial S690QL\n',
        encoding='utf-8')
    cp=subprocess.run([sys.executable, str(ROOT/'engines/python/build_private_analysis_pack.py'), str(src), str(out)], capture_output=True, text=True)
    check('private pack generator runs', cp.returncode==0, cp.stderr[-200:])
    if cp.returncode==0 and out.exists():
        with zipfile.ZipFile(out) as z:
            man=json.loads(z.read('MANIFEST.json'))
            sn=json.loads(z.read('TECHNICAL_SNIPPETS.json'))
        blob=json.dumps(sn,ensure_ascii=False)
        check('private pack format v2', man.get('format')=='DS_ESTIMATE_PRIVATE_ANALYSIS_PACK_V2')
        check('decimal cost is preserved', '1234567.89' in blob)
        spec2=importlib.util.spec_from_file_location('pp', ROOT/'engines/python/build_private_analysis_pack.py')
        pp=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(pp)
        red=pp.redact('Tel: +48 123 456 789')
        check('phone is redacted', '+48 123 456 789' not in red and '<PHONE_' in red, red)
        check('drawing number is redacted from snippets', '90000000003' not in blob)
        check('stable entity correlation emitted', any(x.get('entity_ids') for x in man.get('files',[])))

for name,text in [('resolver',resolver),('merge',merge),('domain',domain),('cost',cost),('evidence',evidence),('report',report),('xunit',xunit)]:
    check(name+' braces balanced', text.count('{')==text.count('}'))

print(f'\nSUMMARY PASS={sum(checks)} FAIL={len(checks)-sum(checks)}')
raise SystemExit(0 if all(checks) else 1)
