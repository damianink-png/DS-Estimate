#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
files = {
    'cost': ROOT/'src/DSEstimate.Core/CostEngine.cs',
    'auto': ROOT/'src/DSEstimate.Core/AutoQuoteEngine.cs',
    'rule': ROOT/'src/DSEstimate.Core/ShopRuleEngine.cs',
    'unc': ROOT/'src/DSEstimate.Core/QuoteUncertaintyModel.cs',
    'adv': ROOT/'src/DSEstimate.Core/AdvancedCostEngines.cs',
    'xunit': ROOT/'tests/DSEstimate.Core.Tests/Fix11TechnologyScopeTests.cs',
}
text = {k:p.read_text(encoding='utf-8-sig') for k,p in files.items()}
checks=[]

def check(name, cond):
    checks.append((name, bool(cond)))
    print(('PASS  ' if cond else 'FAIL  ') + name)

check('post-weld detector exists in cost', 'RequiresPostWeldMachining(AnalysisResult r)' in text['cost'])
check('post-weld detector exists in autoquote', 'RequiresPostWeldMachining(AnalysisResult r)' in text['auto'])
check('route explicitly orders weld before cnc', 'if (postWeldMachining)' in text['auto'] and 'AddWeld();\n            AddCnc();' in text['auto'])
check('post-weld cnc uses assembly envelope', 'var dims = postWeldMachining' in text['cost'] and 'result.Geometry.BoundingXmm' in text['cost'])
check('post-weld cnc uses assembly mass', 'var partMass = postWeldMachining' in text['cost'])
check('post-weld prevents topology-wide machining scope', '&& machiningKeyword && !postWeldMachining' in text['cost'])
check('post-weld disables whole-assembly face complexity extrapolation', 'geometryFeaturesReliableForRouting && !postWeldMachining' in text['cost'])
check('partial dxf coverage model', 'Pokrycie DXF względem rodzin blach' in text['cost'] and 'uncoveredPlateQty * 0.035' in text['cost'])
check('partial dxf coverage risk', 'CUT_PARTIAL_COVERAGE' in text['cost'])
check('cnc rule no longer forces time confidence to 94', 'cnc.Confidence = Math.Max(cnc.Confidence, 78);' in text['rule'] and 'cnc.Confidence = Math.Max(cnc.Confidence, 94);' not in text['rule'])
check('paint low-area sanity cap', 'autoPaintAreaRatio < 0.20' in text['cost'] and 'Math.Min(confidence, 68)' in text['cost'])
check('paint low-area risk', 'PAINT_AREA_LOW_RATIO' in text['cost'])
check('nesting high factor lowers confidence', 'factor >= 2.20' in text['adv'] and 'confidence = Math.Min(confidence, 52)' in text['adv'])
check('nesting high factor risk', 'NESTING_HIGH_FACTOR' in text['cost'])
check('nesting factor shown in material basis', 'współczynnik zakup/netto' in text['cost'])
check('domain-specific uncertainty drivers', 'zakres obróbki po spawaniu' in text['unc'] and 'częściowe pokrycie DXF dla cięcia' in text['unc'])
check('behavior xunit tests added', files['xunit'].exists() and 'Post_weld_machining_is_routed_after_welding' in text['xunit'])

# Lightweight structural guard available in Linux validation environment.
for key in ('cost','auto','rule','unc','adv','xunit'):
    src=text[key]
    check(f'{key} braces balanced', src.count('{') == src.count('}'))

passed=sum(v for _,v in checks)
failed=len(checks)-passed
print(f'\nSUMMARY PASS={passed} FAIL={failed}')
sys.exit(1 if failed else 0)
