#!/usr/bin/env python3
"""FIX47 synthetic PE and CI wiring regression. NOT a .NET build."""
from __future__ import annotations

import importlib.util
import struct
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERIFY = ROOT / 'tests/verify_launcher_ci_output.py'
spec = importlib.util.spec_from_file_location('verify_launcher_ci_output', VERIFY)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
checks: list[tuple[str, bool]] = []


def check(label: str, ok: bool) -> None:
    checks.append((label, bool(ok)))
    print(('PASS ' if ok else 'FAIL ') + label, flush=True)


def dummy_pe(machine=0x8664, magic=0x20B, signature=b'PE\0\0') -> bytes:
    """Only synthetic bytes to exercise the verifier; never shipped as an EXE."""
    data = bytearray(4096)
    data[:2] = b'MZ'
    struct.pack_into('<I', data, 0x3C, 0x80)
    data[0x80:0x84] = signature
    struct.pack_into('<H', data, 0x84, machine)
    struct.pack_into('<H', data, 0x98, magic)
    return bytes(data)


with tempfile.TemporaryDirectory(prefix='dse-fix47-') as temp:
    root = Path(temp) / 'bin' / 'Release'
    output = Path(temp) / 'TestResults' / 'launcher-build-evidence.log'
    exe = root / 'net10.0-windows' / 'win-x64' / mod.LAUNCHER_NAME
    exe.parent.mkdir(parents=True)
    try:
        mod.verify_build(root)
        missing_rejected = False
    except mod.LauncherEvidenceError:
        missing_rejected = True
    check('missing executable rejected', missing_rejected)
    exe.write_bytes(dummy_pe())
    result = mod.verify_build(root)
    check('synthetic win-x64 PE header accepted', result['machine'] == 'AMD64' and result['format'] == 'PE32+')
    check('SHA256 matches synthetic bytes', result['sha256'] == __import__('hashlib').sha256(exe.read_bytes()).hexdigest())
    check('relative output path recorded', result['relative_path'].endswith('win-x64/' + mod.LAUNCHER_NAME))
    for label, payload in (
        ('invalid MZ rejected', b'NO' + dummy_pe()[2:]),
        ('invalid PE signature rejected', dummy_pe(signature=b'BAD!')),
        ('32-bit machine rejected', dummy_pe(machine=0x14C)),
        ('PE32 optional header rejected', dummy_pe(magic=0x10B)),
        ('truncated executable rejected', dummy_pe()[:128]),
    ):
        exe.write_bytes(payload)
        try:
            mod.inspect_launcher(exe)
            rejected = False
        except mod.LauncherEvidenceError:
            rejected = True
        check(label, rejected)
    exe.write_bytes(dummy_pe())
    duplicate = root / 'duplicate' / mod.LAUNCHER_NAME
    duplicate.parent.mkdir(parents=True)
    duplicate.write_bytes(dummy_pe())
    try:
        mod.verify_build(root)
        rejected = False
    except mod.LauncherEvidenceError:
        rejected = True
    check('ambiguous multiple EXEs rejected', rejected)
    duplicate.unlink()
    cli = subprocess.run([sys.executable, str(VERIFY), '--root', str(root), '--output', str(output)],
                         capture_output=True, text=True, check=False)
    check('CLI succeeds with synthetic PE', cli.returncode == 0 and 'PASS' in cli.stdout)
    check('CLI records SHA256 evidence', output.is_file() and 'sha256=' in output.read_text(encoding='utf-8'))
    exe.unlink()
    cli = subprocess.run([sys.executable, str(VERIFY), '--root', str(root), '--output', str(output)],
                         capture_output=True, text=True, check=False)
    check('CLI fails closed with missing output', cli.returncode == 1 and 'FAIL' in output.read_text(encoding='utf-8'))

workflow = (ROOT / '.github/workflows/ds-estimate-dotnet10.yml').read_text(encoding='utf-8')
check('actual launcher build precedes PE check', workflow.index('dotnet build src/DSEstimate.Launcher/') < workflow.index('python tests/verify_launcher_ci_output.py'))
check('PE check precedes xUnit', workflow.index('python tests/verify_launcher_ci_output.py') < workflow.index('      - name: Run C# xUnit tests'))
check('CI evidence log uploaded', 'TestResults/launcher-build-evidence.log' in workflow.split('      - name: Save test results', 1)[-1])
check('CI fixture EXE not uploaded', 'TestResults/launcher-smoke' not in workflow.split('      - name: Save test results', 1)[-1])
for gate in ('RUN_FULL_RELEASE_TESTS.cmd', 'BUILD_FULL_PORTABLE_ZIP.ps1'):
    check(f'{gate} includes FIX47', 'run_fix47_launcher_pe_evidence.py' in (ROOT / gate).read_text(encoding='utf-8-sig'))

passed = sum(ok for _, ok in checks)
print(f'SUMMARY PASS={passed} FAIL={len(checks)-passed} SKIP=0', flush=True)
raise SystemExit(0 if passed == len(checks) else 1)
