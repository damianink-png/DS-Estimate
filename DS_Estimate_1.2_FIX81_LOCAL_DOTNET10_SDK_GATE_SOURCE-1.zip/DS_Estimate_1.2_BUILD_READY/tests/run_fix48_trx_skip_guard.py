#!/usr/bin/env python3
"""FIX48: synthetic strict TRX skip-guard tests; does NOT run xUnit/.NET."""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERIFY = ROOT / "tests/verify_dotnet_trx.py"
spec = importlib.util.spec_from_file_location("verify_dotnet_trx", VERIFY)
assert spec and spec.loader
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
checks: list[bool] = []


def check(label: str, condition: bool) -> None:
    checks.append(bool(condition))
    print(("PASS " if condition else "FAIL ") + label, flush=True)


def trx(passed: int, *, skipped: int = 0, skipped_outcome: str = "NotExecuted",
        extra_counters: str = "", omit_skipped_records: bool = False) -> str:
    records = "".join(f'<UnitTestResult testId="p{i}" outcome="Passed" />' for i in range(passed))
    if not omit_skipped_records:
        records += "".join(
            f'<UnitTestResult testId="s{i}" outcome="{skipped_outcome}" />'
            for i in range(skipped)
        )
    return ('<TestRun xmlns="http://microsoft.com/schemas/VisualStudio/TeamTest/2010">'
            f'<Results>{records}</Results><ResultSummary outcome="Completed">'
            f'<Counters total="{passed + skipped}" executed="{passed}" passed="{passed}" '
            f'failed="0" error="0" timeout="0" aborted="0" notRunnable="0" '
            f'{extra_counters}/></ResultSummary></TestRun>')


with tempfile.TemporaryDirectory(prefix="dse-fix48-") as directory:
    path = Path(directory) / "synthetic.trx"
    cases = [
        ("60 passing records accepted by strict mode", trx(60), True),
        ("61 passing records accepted", trx(61), True),
        ("59 passing records rejected by minimum", trx(59), False),
        ("59 pass plus one skipped rejected", trx(59, skipped=1), False),
        ("60 pass plus one skipped rejected", trx(60, skipped=1), False),
        ("60 pass plus one Skipped outcome rejected", trx(60, skipped=1, skipped_outcome="Skipped"), False),
        ("missing skipped record does not hide incomplete run", trx(60, skipped=1, omit_skipped_records=True), False),
        ("forged notExecuted counter rejected", trx(60, extra_counters='notExecuted="1" '), False),
        ("forged skipped counter rejected", trx(60, extra_counters='skipped="1" '), False),
        ("invalid notExecuted counter rejected", trx(60, extra_counters='notExecuted="x" '), False),
        ("negative skipped counter rejected", trx(60, extra_counters='skipped="-1" '), False),
        ("zero notExecuted counter accepted", trx(60, extra_counters='notExecuted="0" '), True),
    ]
    for label, content, expected in cases:
        path.write_text(content, encoding="utf-8")
        try:
            module.verify_trx(path, min_executed=60, reject_skipped=True)
            accepted = True
        except module.TrxValidationError:
            accepted = False
        check(label, accepted == expected)

    path.write_text(trx(60, skipped=1), encoding="utf-8")
    check("historical default still permits skips without claiming they passed",
          module.verify_trx(path, require_results=True, min_executed=60)["passed"] == 60)
    cli = subprocess.run([sys.executable, str(VERIFY), str(path), "--require-results",
                          "--min-executed", "60", "--reject-skipped"],
                         capture_output=True, text=True, timeout=15, check=False)
    check("strict CLI rejects skipped case", cli.returncode == 1 and "FAIL" in cli.stderr)
    path.write_text(trx(60), encoding="utf-8")
    cli = subprocess.run([sys.executable, str(VERIFY), str(path), "--require-results",
                          "--min-executed", "60", "--reject-skipped"],
                         capture_output=True, text=True, timeout=15, check=False)
    check("strict CLI accepts complete passing suite", cli.returncode == 0 and "PASS" in cli.stdout)

workflow = (ROOT / ".github/workflows/ds-estimate-dotnet10.yml").read_text(encoding="utf-8")
check("CI explicitly rejects skips after real xUnit TRX",
      "verify_dotnet_trx.py TestResults/ds-estimate-xunit.trx --require-results --min-executed 60 --reject-skipped" in workflow)
check("xUnit execution precedes strict TRX validation",
      workflow.index("      - name: Run C# xUnit tests") < workflow.index("      - name: Verify xUnit TRX"))
for gate in ("RUN_FULL_RELEASE_TESTS.cmd", "BUILD_FULL_PORTABLE_ZIP.ps1"):
    check(f"{gate} includes FIX48", "run_fix48_trx_skip_guard.py" in
          (ROOT / gate).read_text(encoding="utf-8-sig"))

passed = sum(checks)
print(f"SUMMARY PASS={passed} FAIL={len(checks) - passed} SKIP=0", flush=True)
raise SystemExit(0 if passed == len(checks) else 1)
