#!/usr/bin/env python3
"""FIX22 regression: searchable multi-sheet PDFs must not hide scanned sheets."""
from __future__ import annotations
import importlib.util
import io
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('dse_fix22_document', ROOT / 'engines/python/analyze_document.py')
document = importlib.util.module_from_spec(spec)
spec.loader.exec_module(document)
passed = failed = skipped = 0

def check(name, condition, detail=''):
    global passed, failed
    if condition:
        passed += 1
        print('PASS ', name)
    else:
        failed += 1
        print('FAIL ', name, detail)

check('old representative sample unchanged', document.select_ocr_page_indices(20, 3) == [0, 10, 19])
check('single raster page takes priority', document.select_ocr_page_indices(20, 1, [8]) == [8])
check('priority respects cap and sorts', document.select_ocr_page_indices(20, 2, [13, 8, 8]) == [8, 13])
check('invalid priority filtered', document.select_ocr_page_indices(10, 2, [-1, 100]) == [0, 9])
check('priority sample spread across many scanned pages', document.select_ocr_page_indices(20, 3, [1, 3, 5, 7, 9]) == [1, 5, 9])

try:
    import pymupdf as fitz
    from PIL import Image, ImageDraw
except ImportError:
    skipped += 1
    print('SKIP  real PDF integration (PyMuPDF/Pillow unavailable)')
else:
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / 'mixed.pdf'
        pdf = fitz.open()
        for i in range(10):
            page = pdf.new_page(width=595, height=842)
            if i == 6:
                im = Image.new('RGB', (600, 800), 'white')
                ImageDraw.Draw(im).text((100, 200), 'S355', fill='black')
                data = io.BytesIO()
                im.save(data, format='PNG')
                page.insert_image(fitz.Rect(10, 10, 585, 832), stream=data.getvalue())
            elif i == 2:
                # Small logo must not turn a rich searchable PDF into an OCR job.
                im = Image.new('RGB', (30, 30), 'black')
                data = io.BytesIO()
                im.save(data, format='PNG')
                page.insert_image(fitz.Rect(10, 10, 40, 40), stream=data.getvalue())
                page.insert_text((45, 80), 'MATERIAL SPECIFICATION ' * 15)
            else:
                page.insert_text((45, 80), 'TECHNICAL SPECIFICATION ' * 15)
        pdf.save(path)
        pdf.close()
        doc = fitz.open(path)
        page_texts = [p.get_text('text') for p in doc]
        check('large raster sheet detected among text sheets', document.find_sparse_raster_pdf_pages(page_texts, doc) == [6],
              str(document.find_sparse_raster_pdf_pages(page_texts, doc)))
        doc.close()

        original_config = document.configure_tesseract
        original_languages = document.choose_ocr_languages
        original_run = document.run_technical_ocr
        keys = ['DSE_SKIP_PDF_OCR', 'DSE_HISTORY_FAST_PDF', 'DSE_HISTORY_SAFE', 'DSE_OCR_MAX_PAGES']
        saved = {k: os.environ.get(k) for k in keys}
        try:
            os.environ.pop('DSE_SKIP_PDF_OCR', None)
            os.environ.pop('DSE_HISTORY_FAST_PDF', None)
            os.environ.pop('DSE_HISTORY_SAFE', None)
            os.environ['DSE_OCR_MAX_PAGES'] = '2'
            document.configure_tesseract = lambda module: ('fake-tesseract', '--psm 6')
            document.choose_ocr_languages = lambda module, config: ('eng', ['eng'])
            seen = []
            def fake_ocr(*args, **kwargs):
                seen.append(True)
                return ('S355', 1, 90.0, 90.0, [], [])
            document.run_technical_ocr = fake_ocr
            result = document.analyze_pdf(path)
            warning_text = '\n'.join(result['warnings'])
            check('OCR runs despite rich searchable document', len(seen) == 2, str(result['warnings']))
            check('scanned sheet prioritized in actual OCR', '(nr 1,7)' in warning_text, warning_text)
            check('material from OCR merged into result', result.get('materialHint') == 'S355', str(result.get('materialHint')))
            os.environ['DSE_SKIP_PDF_OCR'] = '1'
            seen.clear()
            skipped_result = document.analyze_pdf(path)
            check('explicit fast path still bypasses OCR', not seen and not skipped_result.get('ocrEnginePath'))
        finally:
            document.configure_tesseract = original_config
            document.choose_ocr_languages = original_languages
            document.run_technical_ocr = original_run
            for k, v in saved.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

print(f'\nSUMMARY PASS={passed} FAIL={failed} SKIP={skipped}')
sys.exit(1 if failed else 0)
