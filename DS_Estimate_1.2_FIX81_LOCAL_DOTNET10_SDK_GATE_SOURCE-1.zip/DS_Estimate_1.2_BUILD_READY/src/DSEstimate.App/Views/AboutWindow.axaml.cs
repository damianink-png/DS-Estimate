﻿using System.Diagnostics;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Threading;

namespace DSEstimate.Views;

public partial class AboutWindow : Window
{
    private readonly DispatcherTimer _logoTimer;
    private readonly Stopwatch _logoWatch = new();

    public AboutWindow()
    {
        InitializeComponent();

        _logoTimer = new DispatcherTimer
        {
            Interval = TimeSpan.FromMilliseconds(16)
        };
        _logoTimer.Tick += OnLogoTick;

        Opened += (_, _) => StartLogoAnimation();
        Closed += (_, _) => _logoTimer.Stop();
    }

    private void StartLogoAnimation()
    {
        LogoRing.StrokeDashOffset = 1600;
        LogoD.StrokeDashOffset = 1600;
        LogoS.StrokeDashOffset = 1600;
        _logoWatch.Restart();
        _logoTimer.Start();
    }

    private void OnLogoTick(object? sender, EventArgs e)
    {
        var ms = _logoWatch.Elapsed.TotalMilliseconds;
        LogoRing.StrokeDashOffset = Offset(ms, 0, 1500);
        LogoD.StrokeDashOffset = Offset(ms, 220, 1450);
        LogoS.StrokeDashOffset = Offset(ms, 520, 1450);

        if (ms >= 2350)
        {
            LogoRing.StrokeDashOffset = 0;
            LogoD.StrokeDashOffset = 0;
            LogoS.StrokeDashOffset = 0;
            _logoTimer.Stop();
        }
    }

    private static double Offset(double elapsedMs, double delayMs, double durationMs)
    {
        var t = Math.Clamp((elapsedMs - delayMs) / durationMs, 0.0, 1.0);
        // Cubic ease-out keeps the smooth drawing feel, but the total animation is intentionally slower and calmer.
        var eased = 1.0 - Math.Pow(1.0 - t, 3.0);
        return 1600.0 * (1.0 - eased);
    }

    private void OnCloseClick(object? sender, RoutedEventArgs e) => Close();

    private void OnOpenLicensesClick(object? sender, RoutedEventArgs e)
    {
        var path = FindLicensesDirectory();
        if (path is null)
            return;

        try
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = path,
                UseShellExecute = true
            });
        }
        catch
        {
            // The information remains visible in this window even if Explorer is blocked by policy.
        }
    }

    private static string? FindLicensesDirectory()
    {
        var candidates = new List<string>
        {
            Path.Combine(AppContext.BaseDirectory, "LICENCJE"),
            Path.Combine(Environment.CurrentDirectory, "LICENCJE")
        };

        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        for (var i = 0; i < 8 && dir is not null; i++, dir = dir.Parent)
            candidates.Add(Path.Combine(dir.FullName, "LICENCJE"));

        return candidates
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .FirstOrDefault(Directory.Exists);
    }
}
