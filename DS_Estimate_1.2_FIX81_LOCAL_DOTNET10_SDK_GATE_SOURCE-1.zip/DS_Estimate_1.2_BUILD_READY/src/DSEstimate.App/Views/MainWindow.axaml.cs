﻿using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Platform.Storage;
using Avalonia.Styling;
using DSEstimate.ViewModels;

namespace DSEstimate.Views;

public partial class MainWindow : Window
{
    private readonly MainViewModel _vm;

    public MainWindow()
    {
        InitializeComponent();

        ApplySavedTheme();

        _vm = new MainViewModel();
        DataContext = _vm;

        DragDrop.AddDragOverHandler(DropZone, OnDragOver);
        DragDrop.AddDropHandler(DropZone, OnDrop);
        Closing += (_, _) => _vm.SaveDraftOnExit();
    }

    private void OnDragOver(object? sender, DragEventArgs e)
    {
        // DS Compare UX: never advertise an active drop target while an import runs.
        e.DragEffects = _vm.CanModifyDocuments && e.DataTransfer.Formats.Contains(DataFormat.File)
            ? DragDropEffects.Copy
            : DragDropEffects.None;
    }

    private async void OnDrop(object? sender, DragEventArgs e)
    {
        // Do not let a rejected drop bubble to a parent handler.
        e.Handled = true;
        if (!_vm.CanModifyDocuments || e.DataTransfer.TryGetFiles() is not { } files)
            return;

        var paths = LocalExistingPaths(files);
        if (paths.Count > 0)
            await _vm.AddInputsAsync(paths);
    }

    // Avalonia can expose non-file URIs (e.g. virtual/cloud storage items).
    // Uri.LocalPath is only meaningful for local file:// entries. Avoid
    // importing bogus paths or crashing when such items are dragged/picked.
    private static IReadOnlyList<string> LocalExistingPaths(IEnumerable<IStorageItem> items) =>
        items.Select(item => item.Path)
             .Where(uri => uri.IsFile)
             .Select(uri => uri.LocalPath)
             .Where(path => File.Exists(path) || Directory.Exists(path))
             .Distinct(StringComparer.OrdinalIgnoreCase)
             .ToList();

    private async void OnAddFilesClick(object? sender, RoutedEventArgs e)
    {
        if (!_vm.CanModifyDocuments)
            return;
        var files = await StorageProvider.OpenFilePickerAsync(
            new FilePickerOpenOptions
            {
                Title = "Dodaj dokumentację",
                AllowMultiple = true,
                // Jeden selektor bez podziału na typ źródła. ZIP przechodzi przez ten sam
                // pipeline co STEP/PDF/DXF itd.; format rozpoznaje importer po rozszerzeniu.
                FileTypeFilter = [FilePickerFileTypes.All]
            });

        // Picker is asynchronous: a running import may have started while open.
        if (_vm.CanModifyDocuments)
            await _vm.AddInputsAsync(LocalExistingPaths(files));
    }

    private async void OnChooseHistoryFolderClick(object? sender, RoutedEventArgs e)
    {
        if (!_vm.CanModifyDocuments)
            return;
        var folders = await StorageProvider.OpenFolderPickerAsync(
            new FolderPickerOpenOptions
            {
                Title = "Wybierz folder nadrzędny z projektami historycznymi",
                AllowMultiple = false
            });

        var folder = folders.FirstOrDefault();
        if (_vm.CanModifyDocuments && folder is not null && folder.Path.IsFile)
            await _vm.AnalyzeHistoryFolderAsync(folder.Path.LocalPath);
    }



    private void OnProcessEnabledClick(object? sender, RoutedEventArgs e)
    {
        if (sender is CheckBox { DataContext: DSEstimate.Core.ProcessEstimate process })
            _vm.RegisterProcessToggle(process);
    }

    // Export services accept local filesystem paths, not virtual/cloud URIs.
    // The save picker can return a non-file storage provider; never call
    // Uri.LocalPath on such a result. A null selection means cancellation.
    private static string? LocalSavePath(IStorageFile? file) =>
        file is not null && file.Path.IsFile ? file.Path.LocalPath : null;

    private async void OnExportDiagnosticReportClick(object? sender, RoutedEventArgs e)
    {
        if (_vm.Analysis is null)
            return;

        var file = await StorageProvider.SaveFilePickerAsync(
            new FilePickerSaveOptions
            {
                Title = "Eksportuj raport diagnostyczny",
                SuggestedFileName = "DS_Estimate_RAPORT_" + Sanitize(_vm.ProjectName) + ".txt",
                DefaultExtension = "txt",
                FileTypeChoices =
                [
                    new FilePickerFileType("Raport TXT")
                    {
                        Patterns = ["*.txt"]
                    }
                ]
            });

        if (file is null)
            return;

        var localPath = LocalSavePath(file);
        if (localPath is null)
        {
            _vm.StatusText = "Raport można zapisać tylko w lokalnym folderze.";
            return;
        }

        try
        {
            await _vm.ExportDiagnosticReportAsync(localPath);
        }
        catch (Exception ex)
        {
            _vm.StatusText = "Nie wyeksportowano raportu: " + ex.Message;
        }
    }

    private async void OnExportExcelClick(object? sender, RoutedEventArgs e)
    {
        if (_vm.Analysis is null)
            return;
        if (!_vm.PrepareOfferExport())
            return;

        var file = await StorageProvider.SaveFilePickerAsync(
            new FilePickerSaveOptions
            {
                Title = "Eksportuj wycenę",
                SuggestedFileName = Sanitize(_vm.ProjectName) + "_wycena.xlsx",
                DefaultExtension = "xlsx",
                FileTypeChoices =
                [
                    new FilePickerFileType("Excel XLSX")
                    {
                        Patterns = ["*.xlsx"]
                    }
                ]
            });

        if (file is null)
            return;

        var localPath = LocalSavePath(file);
        if (localPath is null)
        {
            _vm.StatusText = "Ofertę można zapisać tylko w lokalnym folderze.";
            return;
        }

        try
        {
            await _vm.ExportExcelAsync(localPath);
        }
        catch (Exception ex)
        {
            _vm.StatusText = "Nie wyeksportowano oferty: " + ex.Message;
        }
    }

    private void OnSaveSettingsClick(object? sender, RoutedEventArgs e) =>
        _vm.SaveSettings();

    private void OnThemeClick(object? sender, RoutedEventArgs e)
    {
        if (Application.Current is null)
            return;

        var next =
            Application.Current.ActualThemeVariant == ThemeVariant.Dark
                ? ThemeVariant.Light
                : ThemeVariant.Dark;

        Application.Current.RequestedThemeVariant = next;
        SaveThemePreference(next == ThemeVariant.Dark);
    }

    private async void OnAboutClick(object? sender, RoutedEventArgs e)
    {
        var window = new AboutWindow();
        await window.ShowDialog(this);
    }

    private static string ThemePreferencePath()
    {
        var dir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "DSEstimateNext");

        Directory.CreateDirectory(dir);
        return Path.Combine(dir, "theme.txt");
    }

    private static void ApplySavedTheme()
    {
        if (Application.Current is null)
            return;

        try
        {
            var path = ThemePreferencePath();
            if (!File.Exists(path))
                return;

            var value = File.ReadAllText(path).Trim();
            Application.Current.RequestedThemeVariant =
                value.Equals("light", StringComparison.OrdinalIgnoreCase)
                    ? ThemeVariant.Light
                    : ThemeVariant.Dark;
        }
        catch
        {
            // Theme persistence must never block application startup.
        }
    }

    private static void SaveThemePreference(bool dark)
    {
        try
        {
            File.WriteAllText(ThemePreferencePath(), dark ? "dark" : "light");
        }
        catch
        {
            // Theme switching still works even if the local profile is read-only.
        }
    }

    private static string Sanitize(string value)
    {
        foreach (var c in Path.GetInvalidFileNameChars())
            value = value.Replace(c, '_');

        return string.IsNullOrWhiteSpace(value) ? "DS_Estimate" : value;
    }
}
