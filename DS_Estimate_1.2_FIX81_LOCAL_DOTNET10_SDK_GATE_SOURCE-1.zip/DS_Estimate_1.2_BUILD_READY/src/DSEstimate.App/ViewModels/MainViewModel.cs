﻿using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Globalization;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DSEstimate.Core;
using DSEstimate.Infrastructure;

namespace DSEstimate.ViewModels;

public partial class MainViewModel : ObservableObject
{
    private readonly ProjectRepository _projects = new();
    private readonly ProjectAnalysisService _analysisService = new();
    private readonly ExcelExportService _excel = new();
    private readonly DiagnosticReportService _report = new();
    private readonly SettingsRepository _settingsRepo = new();
    private readonly ClientPackageImportService _packageImport = new();
    private readonly HistoryImportService _historyImport = new();
    private readonly CostEngine _cost = new();
    private readonly QuoteReleaseService _quoteRelease = new();
    private readonly EngineHealthService _engineHealth = new();
    private readonly FirmGoldenSetService _goldenSet = new();

    private QuoteProject _project = NewProjectModel();
    private List<PartGroup> _allParts = [];
    private bool _suspendDirtyTracking;
    private CancellationTokenSource? _analysisCancellation;
    private CancellationTokenSource? _historyScanCancellation;
    private DateTime _lastCheckpointPersistUtc = DateTime.MinValue;

    public CostingSettings Settings { get; private set; }

    // Fixed standard stations exposed separately so the settings UI can show only
    // process-relevant capacity fields (e.g. no XYZ inputs for manual welding).
    public WorkstationDefinition CuttingStation => GetStation("CUT_GENERAL");
    public WorkstationDefinition Weld135Station => GetStation("WELD_135");
    public WorkstationDefinition Weld136Station => GetStation("WELD_136");
    public WorkstationDefinition Weld111Station => GetStation("WELD_111");
    public WorkstationDefinition CncSmallStation => GetStation("CNC_SMALL");
    public WorkstationDefinition CncMediumStation => GetStation("CNC_MEDIUM");
    public WorkstationDefinition CncLargeStation => GetStation("CNC_LARGE");
    public WorkstationDefinition SurfaceStation => GetStation("SURF_GENERAL");
    public WorkstationDefinition AssemblyStation => GetStation("ASSY_GENERAL");
    public IReadOnlyList<WorkstationDefinition> CompanyRateCardStations => Settings.Workstations
        .Where(x => x.DisplayInRateCard)
        .OrderBy(x => int.TryParse(x.CostCenterCode, out var code) ? code : int.MaxValue)
        .ThenBy(x => x.CostCenterCode, StringComparer.OrdinalIgnoreCase)
        .ToList();

    public ObservableCollection<ProjectListItem> RecentProjects { get; } = [];
    public ObservableCollection<ProjectListItem> ProjectSearchResults { get; } = [];
    public ObservableCollection<ProjectDocument> Documents { get; } = [];
    public ObservableCollection<PartGroup> Parts { get; } = [];
    public ObservableCollection<ProcessEstimate> Processes { get; } = [];
    public ObservableCollection<RiskItem> Risks { get; } = [];
    public ObservableCollection<CostLine> CostLines { get; } = [];
    public ObservableCollection<CostConfidenceItem> CostConfidence { get; } = [];
    public ObservableCollection<SimilarProject> SimilarProjects { get; } = [];
    public ObservableCollection<AssemblyTreeNode> AssemblyTree { get; } = [];
    public ObservableCollection<RuleHit> RuleHits { get; } = [];
    public ObservableCollection<CalibrationFactorInfo> CalibrationFactors { get; } = [];
    public ObservableCollection<HistoryImportCandidate> HistoryImportItems { get; } = [];
    public ObservableCollection<HistoryCalibrationSuggestion> HistoryCalibrationSuggestions { get; } = [];
    public ObservableCollection<CncCapacitySuggestion> CncCapacitySuggestions { get; } = [];
    public ObservableCollection<HistoryRateSuggestion> HistoryRateSuggestions { get; } = [];
    public ObservableCollection<EngineHealthItem> EngineHealthItems { get; } = [];

    [ObservableProperty] private string projectName = "";
    [ObservableProperty] private string customer = "";
    [ObservableProperty] private string manualWeightText = "";
    [ObservableProperty] private string statusText = "Dodaj dokumentację do nowej wyceny.";
    [ObservableProperty] private string projectSearch = "";
    [ObservableProperty] private string partSearch = "";
    [ObservableProperty] private bool isBusy;
    [ObservableProperty] private double analysisProgressPercent;
    [ObservableProperty] private string analysisProgressText = "Gotowe do analizy.";
    [ObservableProperty] private bool documentsExpanded = true;
    [ObservableProperty] private bool hasAnalysis;
    [ObservableProperty] private bool deleteArmed;
    [ObservableProperty] private bool newProjectArmed;
    [ObservableProperty] private bool isDirty;
    [ObservableProperty] private bool analysisNeedsRecalculation;
    [ObservableProperty] private bool hasStoredDraft;
    [ObservableProperty] private string recalculationComparisonText = "";
    [ObservableProperty] private ProductionActuals actuals = new();

    [ObservableProperty] private bool isWorkspace = true;
    [ObservableProperty] private bool isProjectsPage;
    [ObservableProperty] private bool isSettingsPage;
    [ObservableProperty] private bool isHistoryImportPage;
    [ObservableProperty] private bool isPurchasedPartsPage;

    [ObservableProperty] private bool isSummaryTab = true;
    [ObservableProperty] private bool isPartsTab;
    [ObservableProperty] private bool isProcessesTab;
    [ObservableProperty] private bool isCostTab;
    [ObservableProperty] private bool isRisksTab;

    [ObservableProperty] private AnalysisResult? analysis;
    [ObservableProperty] private string historyImportRoot = "";
    [ObservableProperty] private bool historyFastMode = true;
    [ObservableProperty] private string historyImportStatus = "Wybierz folder zawierający projekty historyczne.";
    [ObservableProperty] private string historyImportProgressText = "";
    [ObservableProperty] private double historyImportProgressPercent;
    [ObservableProperty] private bool historyImportHasResults;
    [ObservableProperty] private bool resetHistoryArmed;
    [ObservableProperty] private CalibrationValidationReport calibrationValidation = new();
    [ObservableProperty] private string offerOverrideReason = "";
    [ObservableProperty] private string engineHealthSummary = "Sprawdzanie silników…";
    [ObservableProperty] private string firmGoldenSetSummary = "Golden set: sprawdzanie…";
    private QuoteReleaseDecision _quoteReleaseDecision = new();

    public string RevisionText => $"r{_project.Revision}";
    public string SaveText => _project.Revision == 0 ? "Zapisz projekt" : "Zapisz nową rewizję";
    public string DisplayProjectName =>
        string.IsNullOrWhiteSpace(ProjectName) ? "Nowa wycena" : ProjectName.Trim();
    public bool CanDeleteProject => _project.Revision > 0;
    public string DeleteButtonText =>
        DeleteArmed ? "Kliknij ponownie: USUŃ" : "Usuń projekt";
    public string NewProjectButtonText =>
        NewProjectArmed ? "Kliknij ponownie: NOWA" : "+  Nowa wycena";
    public string DraftStateText =>
        IsDirty ? "wersja robocza • autozapis" : _project.Revision > 0 ? "zapisano" : "";
    public bool HasDraftState => !string.IsNullOrWhiteSpace(DraftStateText);
    public bool CanAnalyze => Documents.Count > 0 && !IsBusy;
    public bool CanCancelAnalysis => IsBusy && _analysisCancellation is not null;
    public bool CanModifyDocuments => !IsBusy;
    public bool CanRecalculate => HasAnalysis && Documents.Count > 0 && !IsBusy;
    public bool HasRecalculationComparison => !string.IsNullOrWhiteSpace(RecalculationComparisonText);
    public bool HasManualProcessOverrides => _project.ProcessOverrides?.Values.Any(x => x.HasAny) == true;
    public string ManualOverrideSummary => HasManualProcessOverrides
        ? $"Ręczne decyzje: {_project.ProcessOverrides.Values.Count(x => x.HasAny)} · zapisane w projekcie"
        : "Procesy: automatyka / dokumentacja / historia";
    public bool HasInterruptedAnalysis => _project.ResumeState?.WasInterrupted == true || _project.ResumeState?.InProgress == true;
    public string ResumeSummary => HasInterruptedAnalysis
        ? $"Poprzednia analiza przerwana · ukończone pliki: {_project.ResumeState.CompletedDocumentCount}. Ponowne LICZ użyje cache ukończonych analiz."
        : "";
    public bool HasMultiRootRisk => Analysis?.Risks.Any(x => string.Equals(x.Code, "MULTI_ROOT_STEP", StringComparison.OrdinalIgnoreCase)) == true;
    public string MultiRootDecisionText => (_project.MultiRootDecision ?? "").Trim().ToUpperInvariant() switch
    {
        "SUBASSEMBLIES" => "Potwierdzono: współistniejące podzespoły",
        "VARIANTS" => "Potwierdzono: alternatywne warianty",
        "SEPARATE_QUOTES" => "Utworzono osobne wyceny",
        _ => "Wymaga decyzji"
    };
    public bool CanImportHistory => HistoryImportItems.Any(x => x.ReadyToImport && !x.Imported) && !IsBusy;
    public bool CanApplyCncCapacitySuggestions => CncCapacitySuggestions.Any(x => x.Usable && !x.IsLargeBoundary) && !IsBusy;
    public bool CanApplyHistoryRates => HistoryRateSuggestions.Any(x => x.Usable) && !IsBusy;
    public string DocumentsToggleText => DocumentsExpanded ? "Zwiń" : "Rozwiń";
    public bool HasParts => Parts.Count > 0;
    public bool HasNoParts => !HasParts;
    public string PartsEmptyText => _allParts.Count == 0
        ? "Brak geometrii STEP w tej paczce. Detale pojawią się po analizie pliku STEP/STP zawierającego zamknięte bryły."
        : "Brak detali pasujących do wpisanego filtra.";
    public int HistoryReadyCount => HistoryImportItems.Count(x => x.ReadyToImport && !x.Imported);
    public int HistoryRefreshCount => HistoryImportItems.Count(x => x.ReadyToImport && x.AlreadyImported && !x.Imported);
    public int HistoryWarningCount => HistoryImportItems.Count(x => x.Status == "Uwaga");
    public int HistoryErrorCount => HistoryImportItems.Count(x => x.Status == "Błąd");
    public int HistoryImportedCount => HistoryImportItems.Count(x => x.Imported || x.AlreadyImported);
    public IReadOnlyList<PurchasedPartPrice> PurchasedPartPrices => Settings.PurchasedPartPrices;
    public string CompanyProfileStatus => Settings.CompanyProfileHistoryProjects <= 0
        ? "Profil bazowy · zaimportuj historię, aby program sam się skalibrował"
        : $"Profil firmy · {Settings.CompanyProfileHistoryProjects} projektów · pewność {Settings.CompanyProfileConfidence}% · v{Settings.CompanyProfileVersion} · walidacja {Settings.CompanyProfileValidationStatus}";
    public string ResetHistoryButtonText => ResetHistoryArmed
        ? "Kliknij ponownie: WYCZYŚĆ"
        : "Wyczyść historię i kalibrację";
    public bool CanExportOffer => HasAnalysis && _quoteReleaseDecision.CanExport && !IsBusy;
    public bool ShowOfferOverride => HasAnalysis && _quoteReleaseDecision.Blockers.Count > 0;
    public string OfferReleaseSummary => HasAnalysis
        ? _quoteReleaseDecision.Summary
        : "Najpierw wykonaj analizę.";
    public bool HasFrozenSnapshot => _project.FrozenSnapshot is not null;
    public string FrozenSnapshotSummary => _project.FrozenSnapshot?.Summary ?? "";

    private WorkstationDefinition GetStation(string code) =>
        Settings.Workstations.First(x => string.Equals(x.Code, code, StringComparison.OrdinalIgnoreCase));

    public MainViewModel()
    {
        Settings = _settingsRepo.Load();
        Actuals = _project.Actuals;
        Documents.CollectionChanged += OnDocumentsCollectionChanged;
        RestoreDraftIfAvailable();
        RefreshQuoteRelease();
        RefreshEngineHealth();
        _ = RefreshProjectListsAsync();
    }

    private void OnDocumentsCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        OnPropertyChanged(nameof(CanAnalyze));
        OnPropertyChanged(nameof(CanCancelAnalysis));
        OnPropertyChanged(nameof(CanModifyDocuments));
        OnPropertyChanged(nameof(CanRecalculate));
        if (!_suspendDirtyTracking)
            MarkDirty();
        RefreshQuoteRelease();
    }

    partial void OnProjectSearchChanged(string value) => _ = SearchProjectsAsync();
    partial void OnPartSearchChanged(string value) => ApplyPartFilter();
    partial void OnProjectNameChanged(string value)
    {
        OnPropertyChanged(nameof(DisplayProjectName));
        if (!_suspendDirtyTracking) MarkDirty();
    }
    partial void OnCustomerChanged(string value) { if (!_suspendDirtyTracking) MarkDirty(); }
    partial void OnManualWeightTextChanged(string value) { if (!_suspendDirtyTracking) MarkDirty(); }
    partial void OnDeleteArmedChanged(bool value) => OnPropertyChanged(nameof(DeleteButtonText));
    partial void OnNewProjectArmedChanged(bool value) => OnPropertyChanged(nameof(NewProjectButtonText));
    partial void OnResetHistoryArmedChanged(bool value) => OnPropertyChanged(nameof(ResetHistoryButtonText));
    partial void OnDocumentsExpandedChanged(bool value) => OnPropertyChanged(nameof(DocumentsToggleText));
    partial void OnIsDirtyChanged(bool value)
    {
        OnPropertyChanged(nameof(DraftStateText));
        OnPropertyChanged(nameof(HasDraftState));
    }
    partial void OnRecalculationComparisonTextChanged(string value) => OnPropertyChanged(nameof(HasRecalculationComparison));
    partial void OnHasAnalysisChanged(bool value)
    {
        OnPropertyChanged(nameof(CanRecalculate));
        RefreshQuoteRelease();
    }
    partial void OnIsBusyChanged(bool value)
    {
        OnPropertyChanged(nameof(CanAnalyze));
        OnPropertyChanged(nameof(CanCancelAnalysis));
        OnPropertyChanged(nameof(CanModifyDocuments));
        OnPropertyChanged(nameof(CanRecalculate));
        OnPropertyChanged(nameof(CanImportHistory));
        OnPropertyChanged(nameof(CanApplyHistoryRates));
        OnPropertyChanged(nameof(CanExportOffer));
    }

    [RelayCommand]
    private void ToggleDocuments() => DocumentsExpanded = !DocumentsExpanded;

    [RelayCommand]
    private void NewProject()
    {
        if (IsBusy)
        {
            StatusText = "Trwa analiza / import. Poczekaj na zakończenie, zanim utworzysz nową wycenę.";
            return;
        }

        if (HasCurrentWork() && !NewProjectArmed)
        {
            PersistDraft();
            NewProjectArmed = true;
            StatusText = "Bieżąca wycena jest zachowana jako wersja robocza. Kliknij ponownie „Nowa wycena”, aby ją porzucić i zacząć od zera.";
            return;
        }

        if (_project.Revision == 0)
            _packageImport.DeleteProjectImports(_project.Id);
        _projects.DeleteDraft();
        HasStoredDraft = false;

        _suspendDirtyTracking = true;
        try
        {
            _project = NewProjectModel();
            ProjectName = "";
            Customer = "";
            ManualWeightText = "";
            PartSearch = "";
            Actuals = _project.Actuals;
            Documents.Clear();
            ClearAnalysis();
            DeleteArmed = false;
            NewProjectArmed = false;
            AnalysisNeedsRecalculation = false;
            RecalculationComparisonText = "";
            IsDirty = false;
        }
        finally
        {
            _suspendDirtyTracking = false;
        }

        StatusText = "Dodaj dokumentację i kliknij LICZ WYCENĘ. Pozostałe pola są opcjonalne.";
        NotifyProjectState();
        ShowWorkspace();
        ShowSummary();
    }

    [RelayCommand]
    private void ShowWorkspace()
    {
        IsWorkspace = true;
        IsProjectsPage = false;
        IsSettingsPage = false;
        IsHistoryImportPage = false;
        IsPurchasedPartsPage = false;
    }

    [RelayCommand]
    private void ShowProjects()
    {
        PersistDraftIfNeeded();
        HasStoredDraft = _projects.LoadDraft() is not null;
        IsWorkspace = false;
        IsProjectsPage = true;
        IsSettingsPage = false;
        IsHistoryImportPage = false;
        IsPurchasedPartsPage = false;
        _ = SearchProjectsAsync();
    }

    [RelayCommand]
    private void ShowSettings()
    {
        PersistDraftIfNeeded();
        IsWorkspace = false;
        IsProjectsPage = false;
        IsSettingsPage = true;
        IsHistoryImportPage = false;
        IsPurchasedPartsPage = false;
        OnPropertyChanged(nameof(CompanyProfileStatus));
    }

    [RelayCommand]
    private void ShowHistoryImport()
    {
        PersistDraftIfNeeded();
        IsWorkspace = false;
        IsProjectsPage = false;
        IsSettingsPage = false;
        IsHistoryImportPage = true;
        IsPurchasedPartsPage = false;
        if (string.IsNullOrWhiteSpace(HistoryImportRoot))
            HistoryImportStatus = "Wybierz folder nadrzędny. Każdy podfolder powinien zawierać metrykę XLSX/XLSM i dokumentację klienta (najlepiej ZIP).";
    }

    [RelayCommand]
    private void BackToSettings() => ShowSettings();

    [RelayCommand]
    private void ShowPurchasedParts()
    {
        PersistDraftIfNeeded();
        IsWorkspace = false;
        IsProjectsPage = false;
        IsSettingsPage = false;
        IsHistoryImportPage = false;
        IsPurchasedPartsPage = true;
        OnPropertyChanged(nameof(PurchasedPartPrices));
    }

    [RelayCommand]
    private void SavePurchasedParts()
    {
        _settingsRepo.Save(Settings);
        StatusText = "Zapisano lokalny cennik części kupnych.";
        OnPropertyChanged(nameof(PurchasedPartPrices));
    }

    [RelayCommand]
    private void AddPurchasedPart()
    {
        var n = Settings.PurchasedPartPrices.Count + 1;
        Settings.PurchasedPartPrices.Add(new PurchasedPartPrice
        {
            Code = $"LOCAL_{n:000}",
            Category = "Inne",
            Name = "Nowa część kupna",
            MatchExpression = "NOWA CZĘŚĆ",
            Unit = "szt.",
            PricePln = 0,
            Enabled = true,
            MarketReference = false,
            Source = "Cennik firmowy — wpis ręczny",
            SourceDate = DateTime.Now.ToString("yyyy-MM")
        });
        OnPropertyChanged(nameof(PurchasedPartPrices));
    }

    [RelayCommand]
    private void RemovePurchasedPart(PurchasedPartPrice? item)
    {
        if (item is null) return;
        Settings.PurchasedPartPrices.Remove(item);
        OnPropertyChanged(nameof(PurchasedPartPrices));
    }

    [RelayCommand] private void ShowSummary() => SetTab("summary");
    [RelayCommand] private void ShowParts() => SetTab("parts");
    [RelayCommand] private void ShowProcesses() => SetTab("processes");
    [RelayCommand] private void ShowCost() => SetTab("cost");
    [RelayCommand] private void ShowRisks() => SetTab("risks");

    [RelayCommand]
    private void OpenReadinessItem(string? code)
    {
        if (Analysis is null || string.IsNullOrWhiteSpace(code))
            return;
        var item = Analysis.AutoQuote.ReadinessItems.FirstOrDefault(x =>
            string.Equals(x.Code, code, StringComparison.OrdinalIgnoreCase));
        if (item is null)
            return;

        if (string.Equals(item.Target, "settings", StringComparison.OrdinalIgnoreCase))
            ShowSettings();
        else
        {
            ShowWorkspace();
            SetTab(string.Equals(item.Target, "processes", StringComparison.OrdinalIgnoreCase) ? "processes" : "risks");
        }
        StatusText = item.NextAction;
    }

    [RelayCommand]
    private async Task ConfirmMultiRootSubassembliesAsync()
    {
        if (!HasMultiRootRisk || IsBusy) return;
        _project.MultiRootDecision = "SUBASSEMBLIES";
        MarkDirty();
        PersistDraft();
        OnPropertyChanged(nameof(MultiRootDecisionText));
        StatusText = "Potwierdzono, że główne STEP-y są współistniejącymi podzespołami. Aktualizuję wycenę…";
        await AnalyzeAsync();
    }

    [RelayCommand]
    private void MarkMultiRootVariants()
    {
        if (!HasMultiRootRisk || IsBusy) return;
        _project.MultiRootDecision = "VARIANTS";
        if (Analysis is not null)
        {
            Analysis.Package.MultiRootDecision = "VARIANTS";
            var risk = Analysis.Risks.FirstOrDefault(x => string.Equals(x.Code, "MULTI_ROOT_STEP", StringComparison.OrdinalIgnoreCase));
            if (risk is not null)
            {
                risk.Title = "Warianty STEP potwierdzone — cena zbiorcza nieważna";
                risk.Message = "Modele STEP są alternatywnymi wariantami. Nie zatwierdzaj ich sumy jako jednej ceny; użyj „Osobne wyceny”.";
                risk.Level = RiskLevel.High;
                risk.Blocking = true;
            }
        }
        MarkDirty();
        PersistDraft();
        LoadAnalysisCollections();
        OnPropertyChanged(nameof(MultiRootDecisionText));
        StatusText = "Oznaczono modele STEP jako warianty. Cena zbiorcza pozostaje zablokowana — możesz utworzyć osobne wyceny jednym kliknięciem.";
    }

    [RelayCommand]
    private async Task SplitMultiRootQuotesAsync()
    {
        if (!HasMultiRootRisk || IsBusy) return;
        SyncProjectFromUi();
        var roots = Documents
            .Where(x => !x.ExcludeFromAnalysis && x.IsActiveRevision && x.Kind == DocumentKind.Step && x.Role == DocumentRole.Production)
            .OrderBy(x => x.Name, StringComparer.OrdinalIgnoreCase)
            .ToList();
        if (roots.Count < 2)
        {
            StatusText = "Nie znaleziono co najmniej dwóch aktywnych produkcyjnych STEP-ów do rozdzielenia.";
            return;
        }

        var shared = Documents.Where(x => x.Kind != DocumentKind.Step).ToList();
        foreach (var root in roots)
        {
            var child = new QuoteProject
            {
                Id = Guid.NewGuid(),
                Name = $"{DisplayProjectName} — {Path.GetFileNameWithoutExtension(root.Name)}",
                Customer = Customer?.Trim() ?? "",
                CreatedAt = DateTime.Now,
                ModifiedAt = DateTime.Now,
                MultiRootDecision = ""
            };
            child.Documents.Add(CloneProjectDocument(root));
            foreach (var doc in shared)
                child.Documents.Add(CloneProjectDocument(doc));
            await _projects.SaveAsync(child);
        }

        _project.MultiRootDecision = "SEPARATE_QUOTES";
        if (Analysis is not null)
        {
            Analysis.Package.MultiRootDecision = "SEPARATE_QUOTES";
            var risk = Analysis.Risks.FirstOrDefault(x => string.Equals(x.Code, "MULTI_ROOT_STEP", StringComparison.OrdinalIgnoreCase));
            if (risk is not null)
            {
                risk.Title = "Utworzono osobne wyceny dla głównych STEP";
                risk.Message = $"Utworzono {roots.Count} osobne projekty. Ten projekt zbiorczy pozostaje tylko audytem paczki i nie powinien być zatwierdzany jako jedna oferta.";
                risk.Blocking = true;
            }
        }
        MarkDirty();
        PersistDraft();
        await RefreshProjectListsAsync();
        LoadAnalysisCollections();
        OnPropertyChanged(nameof(MultiRootDecisionText));
        StatusText = $"Utworzono {roots.Count} osobne wyceny — po jednej dla każdego głównego STEP. Znajdziesz je w Bazie projektów.";
    }

    private static ProjectDocument CloneProjectDocument(ProjectDocument source) => new()
    {
        Path = source.Path,
        Name = source.Name,
        Kind = source.Kind,
        SizeBytes = source.SizeBytes,
        RelativePath = source.RelativePath,
        PackageSource = source.PackageSource,
        ContentHash = source.ContentHash,
        ContentDuplicateOf = source.ContentDuplicateOf,
        Role = source.Role,
        RoleConfidence = source.RoleConfidence,
        RoleReason = source.RoleReason,
        ProjectGroupKey = source.ProjectGroupKey,
        IsActiveRevision = source.IsActiveRevision,
        ExcludeFromAnalysis = source.ExcludeFromAnalysis,
        Status = "Oczekuje",
        Summary = ""
    };

    [RelayCommand]
    private void RestoreStoredDraft()
    {
        var draft = _projects.LoadDraft();
        if (draft is null)
        {
            HasStoredDraft = false;
            StatusText = "Brak zapisanej wersji roboczej.";
            return;
        }

        ApplyDraftToWorkspace(draft, "Przywrócono wersję roboczą. Możesz kontynuować dokładnie od miejsca, w którym przerwano pracę.");
    }

    [RelayCommand]
    private async Task OpenProjectAsync(ProjectListItem? item)
    {
        if (item is null)
            return;

        var loaded = await _projects.LoadAsync(item.Id);
        if (loaded is null)
            return;

        _suspendDirtyTracking = true;
        try
        {
            _project = loaded;
            ProjectName = loaded.Name;
            Customer = loaded.Customer;
            ManualWeightText = loaded.ManualWeightKg?.ToString("0.###", CultureInfo.CurrentCulture) ?? "";
            Actuals = loaded.Actuals ?? new ProductionActuals();

            Documents.Clear();
            foreach (var d in loaded.Documents)
                Documents.Add(d);

            Analysis = loaded.Analysis;
            MigrateLegacyProcessOverrideState(Analysis);
            PartSearch = "";
            LoadAnalysisCollections();
            HasAnalysis = Analysis is not null;
            DeleteArmed = false;
            NewProjectArmed = false;
            AnalysisNeedsRecalculation = false;
            RecalculationComparisonText = "";
            IsDirty = false;
        }
        finally
        {
            _suspendDirtyTracking = false;
        }

        StatusText = $"Otworzono {ProjectName} · rewizja {_project.Revision}. Możesz użyć „Przelicz wg aktualnych ustawień”, aby sprawdzić wynik po zmianie stawek/modelu.";
        NotifyProjectState();
        ShowWorkspace();
        ShowSummary();
    }

    [RelayCommand]
    private async Task DuplicateProjectAsync()
    {
        SyncProjectFromUi();

        _project = new QuoteProject
        {
            Id = Guid.NewGuid(),
            Revision = 0,
            Name = $"{ProjectName} — kopia",
            Customer = Customer,
            CreatedAt = DateTime.Now,
            ModifiedAt = DateTime.Now,
            ManualWeightKg = ParseWeight(),
            Documents = Documents.Select(CloneDocument).ToList(),
            Actuals = new ProductionActuals(),
            Analysis = Analysis
        };

        ProjectName = _project.Name;
        Actuals = _project.Actuals;
        StatusText = "Utworzono niezależną kopię projektu.";
        await SaveAsync();
    }

    [RelayCommand]
    private async Task DeleteProjectAsync()
    {
        if (_project.Revision == 0)
            return;

        if (!DeleteArmed)
        {
            DeleteArmed = true;
            StatusText = "Usunięcie jest trwałe. Kliknij ponownie przycisk usuwania, aby potwierdzić.";
            return;
        }

        var deletedName = _project.Name;
        await _projects.DeleteAsync(_project.Id);
        _packageImport.DeleteProjectImports(_project.Id);

        DeleteArmed = false;
        NewProjectArmed = true;
        NewProject();
        await RefreshProjectListsAsync();
        StatusText = $"Projekt „{deletedName}” został usunięty.";
    }

    public Task AddFilesAsync(IEnumerable<string> paths) => AddInputsAsync(paths);

    public async Task AddInputsAsync(IEnumerable<string> paths)
    {
        if (IsBusy)
        {
            StatusText = "Trwa analiza / import. Dodawanie plików jest chwilowo zablokowane.";
            return;
        }

        var inputList = paths.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if (inputList.Count == 0)
            return;

        _analysisCancellation?.Dispose();
        _analysisCancellation = new CancellationTokenSource();
        IsBusy = true;
        OnPropertyChanged(nameof(CanCancelAnalysis));
        DocumentsExpanded = true;
        AnalysisProgressPercent = 5;
        AnalysisProgressText = "Wczytywanie paczki klienta / dokumentów…";
        StatusText = "Wczytywanie paczki klienta / dokumentów…";
        ClearAnalysis();
        await Task.Yield();
        try
        {
            var importProgress = new Progress<PackageImportProgress>(p =>
            {
                AnalysisProgressPercent = Math.Max(
                    AnalysisProgressPercent,
                    Math.Clamp(p.Percent, 0, 100));
                AnalysisProgressText = p.Message;
                StatusText = p.Message;
            });
            var imported = await _packageImport.ExpandAsync(
                inputList,
                _project.Id,
                Settings.MaxZipExtractGb,
                _analysisCancellation.Token,
                progress: importProgress);

            ProjectDocument BuildImportedDocument(
                ImportedPackageFile item,
                Guid targetProjectId,
                ICollection<ProjectDocument> existing)
            {
                var materializedPath = _packageImport.MaterializeImportedFileForProject(item, targetProjectId);
                var visibleName = Path.GetFileName(item.RelativePath);
                if (existing.Any(x => string.Equals(x.Name, visibleName, StringComparison.OrdinalIgnoreCase)))
                {
                    var stem = Path.GetFileNameWithoutExtension(visibleName);
                    var ext = Path.GetExtension(visibleName);
                    var n = 2;
                    string candidate;
                    do candidate = $"{stem} [KONFLIKT {n++}]{ext}";
                    while (existing.Any(x => string.Equals(x.Name, candidate, StringComparison.OrdinalIgnoreCase)));
                    visibleName = candidate;
                }

                var duplicateContentOf = item.DuplicateContentOf;
                if (string.IsNullOrWhiteSpace(duplicateContentOf) && !string.IsNullOrWhiteSpace(item.ContentHash))
                {
                    var previousContent = existing.FirstOrDefault(x =>
                        !string.IsNullOrWhiteSpace(x.ContentHash) &&
                        string.Equals(x.ContentHash, item.ContentHash, StringComparison.OrdinalIgnoreCase));
                    if (previousContent is not null)
                        duplicateContentOf = string.IsNullOrWhiteSpace(previousContent.RelativePath)
                            ? previousContent.Name
                            : previousContent.RelativePath;
                }

                var file = new FileInfo(materializedPath);
                return new ProjectDocument
                {
                    Path = materializedPath,
                    Name = visibleName,
                    RelativePath = item.RelativePath,
                    PackageSource = item.Source,
                    ContentHash = item.ContentHash,
                    ContentDuplicateOf = duplicateContentOf,
                    Role = item.Role,
                    RoleConfidence = item.RoleConfidence,
                    RoleReason = item.RoleReason,
                    ProjectGroupKey = item.ProjectGroupKey,
                    Kind = DetectKind(file.Extension),
                    SizeBytes = file.Exists ? file.Length : 0,
                    Status = "Oczekuje",
                    IsActiveRevision = true
                };
            }

            var autoSplitPerformed = Documents.Count == 0 && inputList.Count == 1 &&
                                     Directory.Exists(inputList[0]) && imported.ProjectGroups.Count > 1;
            if (autoSplitPerformed)
            {
                var groups = imported.ProjectGroups.OrderBy(x => x.Name, StringComparer.OrdinalIgnoreCase).ToList();
                var shared = imported.Files.Where(x => string.IsNullOrWhiteSpace(x.ProjectGroupKey)).ToList();

                // The first detected project remains the open workspace; root/shared files
                // are attached only here so common README/reference material is not multiplied.
                var firstItems = groups[0].Files.Concat(shared).DistinctBy(x => x.Path, StringComparer.OrdinalIgnoreCase).ToList();
                foreach (var item in firstItems)
                {
                    if (Documents.Any(x => string.Equals(x.Path, item.Path, StringComparison.OrdinalIgnoreCase)))
                        continue;
                    Documents.Add(BuildImportedDocument(item, _project.Id, Documents));
                }
                ProjectName = groups[0].Name;

                foreach (var group in groups.Skip(1))
                {
                    var child = new QuoteProject
                    {
                        Id = Guid.NewGuid(),
                        Name = group.Name,
                        Customer = _project.Customer,
                        CreatedAt = DateTime.Now,
                        ModifiedAt = DateTime.Now
                    };
                    foreach (var item in group.Files)
                        child.Documents.Add(BuildImportedDocument(item, child.Id, child.Documents));
                    await _projects.SaveAsync(child);
                }
                await RefreshProjectListsAsync();
            }
            else
            {
                foreach (var item in imported.Files)
                {
                    if (Documents.Any(x => string.Equals(x.Path, item.Path, StringComparison.OrdinalIgnoreCase)))
                    {
                        imported.DuplicateNameCount++;
                        continue;
                    }
                    var doc = BuildImportedDocument(item, _project.Id, Documents);
                    if (!string.IsNullOrWhiteSpace(doc.ContentDuplicateOf) && string.IsNullOrWhiteSpace(item.DuplicateContentOf))
                        imported.DuplicateContentAliasCount++;
                    Documents.Add(doc);
                }
            }

            if (Documents.Count > 0 &&
                (string.IsNullOrWhiteSpace(ProjectName) ||
                 string.Equals(ProjectName.Trim(), "Nowa wycena", StringComparison.OrdinalIgnoreCase)))
            {
                var packageName = inputList.Count == 1
                    ? Directory.Exists(inputList[0])
                        ? new DirectoryInfo(inputList[0]).Name
                        : Path.GetFileNameWithoutExtension(inputList[0])
                    : Path.GetFileNameWithoutExtension(Documents[0].Name);
                ProjectName = string.IsNullOrWhiteSpace(packageName)
                    ? Path.GetFileNameWithoutExtension(Documents[0].Name)
                    : packageName;
            }

            var sourceInfo = imported.ZipCount > 0 || imported.FolderCount > 0
                ? $" · ZIP {imported.ZipCount}" +
                  (imported.NestedZipCount > 0 ? $" (zagnieżdżone {imported.NestedZipCount})" : "") +
                  $" · foldery {imported.FolderCount}"
                : "";
            var duplicateInfo = imported.DuplicateNameCount > 0
                ? $" · identyczne duplikaty pominięte {imported.DuplicateNameCount}"
                : "";
            if (imported.ConflictingNameCount > 0)
                duplicateInfo += $" · konflikty tej samej nazwy zachowane {imported.ConflictingNameCount}";
            if (imported.DuplicateContentAliasCount > 0)
                duplicateInfo += $" · identyczna treść pod inną nazwą {imported.DuplicateContentAliasCount}";
            var warningCount = imported.Warnings.Count + imported.SkippedUnsupportedCount;
            var warningInfo = warningCount > 0
                ? $" · pominięto/uwagi {warningCount}"
                : "";
            var cacheInfo = imported.ReusedArchiveCount > 0
                ? $" · ZIP z cache {imported.ReusedArchiveCount}"
                : "";
            var splitInfo = autoSplitPerformed
                ? $" · podwyceny {imported.ProjectGroups.Count} (otwarta: {ProjectName})"
                : "";
            StatusText = Documents.Count > 0
                ? $"Dokumentacja gotowa: {Documents.Count} plików{sourceInfo}{cacheInfo}{duplicateInfo}{warningInfo}{splitInfo}. Kliknij LICZ WYCENĘ."
                : $"Nie znaleziono obsługiwanych dokumentów{warningInfo}. Dodaj STEP/STP, PDF, DXF/DWG, Excel, DOC/DOCX, obraz, tekst albo ZIP.";
            MarkDirty();
            PersistDraft();
            OnPropertyChanged(nameof(HasInterruptedAnalysis));
            OnPropertyChanged(nameof(ResumeSummary));
            OnPropertyChanged(nameof(HasManualProcessOverrides));
            OnPropertyChanged(nameof(ManualOverrideSummary));
        }
        catch (OperationCanceledException)
        {
            AnalysisProgressText = "Import anulowany.";
            StatusText = "Import dokumentacji został anulowany. Niekompletne pliki nie zostały dodane do projektu.";
        }
        catch (Exception ex)
        {
            StatusText = $"Nie udało się wczytać paczki: {ex.Message}";
        }
        finally
        {
            _analysisCancellation?.Dispose();
            _analysisCancellation = null;
            IsBusy = false;
            OnPropertyChanged(nameof(CanCancelAnalysis));
        }
    }

    [RelayCommand]
    private void RemoveDocument(ProjectDocument? document)
    {
        if (IsBusy)
        {
            StatusText = "Nie można usuwać plików podczas analizy. Poczekaj na zakończenie.";
            return;
        }

        if (document is not null)
        {
            Documents.Remove(document);
            if (Documents.Count == 0)
                ClearAnalysis();
            StatusText = Documents.Count == 0
                ? "Usunięto wszystkie pliki. Dodaj dokumentację, aby policzyć nową wycenę."
                : $"Usunięto plik: {document.Name}. Pozostało {Documents.Count} plik(ów).";
            MarkDirty();
            PersistDraft();
            RefreshQuoteRelease();
            RefreshEngineHealth();
        }
    }

    [RelayCommand]
    private async Task AnalyzeAsync()
    {
        if (IsBusy)
        {
            StatusText = "Analiza już trwa. Poczekaj na zakończenie bieżącego liczenia.";
            return;
        }

        if (Documents.Count == 0)
        {
            StatusText = "Najpierw dodaj dokumentację.";
            return;
        }

        SyncProjectFromUi();
        _analysisCancellation?.Dispose();
        _analysisCancellation = new CancellationTokenSource();
        _project.ResumeState = new AnalysisResumeState
        {
            InProgress = true,
            WasInterrupted = false,
            StartedAt = DateTime.Now,
            LastCheckpointAt = DateTime.Now,
            LastMessage = "Analiza rozpoczęta"
        };
        PersistAnalysisCheckpoint(force: true);
        IsBusy = true;
        OnPropertyChanged(nameof(CanCancelAnalysis));
        DocumentsExpanded = true;
        AnalysisProgressPercent = 1;
        AnalysisProgressText = "Analiza geometrii, rysunków i procesu…";
        StatusText = "Analiza geometrii, rysunków i procesu…";
        foreach (var document in Documents.Where(x => !x.ExcludeFromAnalysis))
        {
            document.Status = "W toku";
            document.Summary = "Analiza rozpoczęta";
        }
        await Task.Yield();

        try
        {
            var progress = new Progress<AnalysisProgress>(p =>
            {
                AnalysisProgressPercent = Math.Clamp(p.Percent, 0, 100);
                AnalysisProgressText = string.IsNullOrWhiteSpace(p.CurrentFile)
                    ? p.Message
                    : $"{p.Message} · {p.CurrentFile}";
                StatusText = p.Message;

                // R9.2.3D2: publish per-document results immediately instead of waiting
                // for the slowest STEP/PDF. Progress<T> marshals this update back to the
                // UI context, so DXF/PDF/BOM summaries appear live and safely.
                if (!string.IsNullOrWhiteSpace(p.DocumentPath))
                {
                    var doc = Documents.FirstOrDefault(x => string.Equals(x.Path, p.DocumentPath, StringComparison.OrdinalIgnoreCase));
                    if (doc is not null)
                    {
                        if (!string.IsNullOrWhiteSpace(p.DocumentStatus))
                            doc.Status = NormalizeDocumentStatus(p.DocumentStatus);
                        if (!string.IsNullOrWhiteSpace(p.DocumentSummary)) doc.Summary = p.DocumentSummary;

                        if (doc.IsStatusGood && !string.IsNullOrWhiteSpace(doc.ContentHash))
                        {
                            _project.ResumeState.CompletedDocumentHashes.Add(doc.ContentHash);
                            _project.ResumeState.LastCheckpointAt = DateTime.Now;
                            _project.ResumeState.LastMessage = p.Message;
                            PersistAnalysisCheckpoint();
                        }
                    }
                }
            });
            var result = await _analysisService.AnalyzeAsync(
                _project, Settings, _analysisCancellation.Token, progress: progress);
            AnalysisProgressPercent = 96;
            AnalysisProgressText = "Porównanie z historią projektów…";
            StatusText = "Porównanie z historią projektów…";
            var history = await _projects.LoadRecentProjectsAsync(500);
            _analysisService.ApplyHistory(result, _project, history, Settings);
            CaptureAutomaticProcessBaselines(result);
            ApplyPersistedProcessOverrides(result);

            _project.ResumeState.InProgress = false;
            _project.ResumeState.WasInterrupted = false;
            _project.ResumeState.LastCheckpointAt = DateTime.Now;
            _project.ResumeState.LastMessage = "Analiza zakończona";
            _project.Analysis = result;
            Analysis = result;
            HasAnalysis = true;
            PartSearch = "";
            NormalizeDocumentStatuses();
            LoadAnalysisCollections();
            ShowSummary();

            AnalysisProgressPercent = 100;
            AnalysisProgressText = "Gotowe.";
            DocumentsExpanded = false;
            StatusText = result.AutoQuote.RecommendedPricePln > 0
                ? $"GOTOWE · {result.AutoQuote.Status} · cena {result.AutoQuote.RecommendedPricePln:N0} PLN · pewność {result.ConfidencePercent}% · {result.AutoQuote.EnabledOperationCount} operacji."
                : $"GOTOWE · {result.AutoQuote.Status} · cena ofertowa nie wyznaczona · koszt rozpoznany {result.AutoQuote.RecognizedCostPln:N0} PLN · pewność {result.ConfidencePercent}% · {result.AutoQuote.EnabledOperationCount} operacji.";
            AnalysisNeedsRecalculation = false;
            RecalculationComparisonText = "";
            MarkDirty();
            PersistDraft();
            RefreshQuoteRelease();
            RefreshEngineHealth();
        }
        catch (OperationCanceledException)
        {
            foreach (var document in Documents.Where(x => x.IsStatusInProgress))
                document.Status = "Anulowano";
            AnalysisProgressText = "Analiza anulowana.";
            _project.ResumeState.InProgress = false;
            _project.ResumeState.WasInterrupted = true;
            _project.ResumeState.LastCheckpointAt = DateTime.Now;
            _project.ResumeState.LastMessage = "Anulowano przez użytkownika";
            PersistAnalysisCheckpoint(force: true);
            StatusText = $"Analiza została anulowana. Ukończone pliki: {_project.ResumeState.CompletedDocumentCount}; ponowne LICZ użyje ich cache.";
        }
        catch (Exception ex)
        {
            foreach (var document in Documents.Where(x => x.IsStatusInProgress))
                document.Status = "Błąd";
            AnalysisProgressText = "Analiza przerwana błędem.";
            _project.ResumeState.InProgress = false;
            _project.ResumeState.WasInterrupted = true;
            _project.ResumeState.LastCheckpointAt = DateTime.Now;
            _project.ResumeState.LastMessage = ex.Message;
            PersistAnalysisCheckpoint(force: true);
            var crash = CrashDiagnosticService.Write(ex, "project-analysis", Analysis);
            StatusText = $"Nie udało się policzyć wyceny: {ex.Message}. Ukończone pliki pozostają w cache do wznowienia. Diagnostyka: {crash}";
        }
        finally
        {
            _analysisCancellation?.Dispose();
            _analysisCancellation = null;
            IsBusy = false;
            OnPropertyChanged(nameof(CanCancelAnalysis));
        }
    }

    [RelayCommand]
    private void CancelAnalysis()
    {
        if (_analysisCancellation is null)
            return;
        StatusText = "Anulowanie pracy… zatrzymuję bieżący analizator lub import.";
        _analysisCancellation.Cancel();
    }

    [RelayCommand]
    private async Task RecalculateCurrentAsync()
    {
        if (!CanRecalculate || Analysis is null)
            return;

        var previous = Analysis.AutoQuote.RecommendedPricePln > 0
            ? Analysis.AutoQuote.RecommendedPricePln
            : Analysis.FinalPricePln;
        var previousRevision = _project.Revision;
        await AnalyzeAsync();
        if (Analysis is null)
            return;

        var current = Analysis.AutoQuote.RecommendedPricePln > 0
            ? Analysis.AutoQuote.RecommendedPricePln
            : Analysis.FinalPricePln;
        var delta = previous == 0 ? 0 : (current - previous) / previous * 100.0;
        RecalculationComparisonText =
            $"Poprzedni wynik: {previous:N0} PLN → aktualne ustawienia: {current:N0} PLN ({delta:+0.0;-0.0;0}%).";
        AnalysisNeedsRecalculation = false;
        MarkDirty();
        PersistDraft();
        StatusText = previousRevision > 0
            ? $"Przeliczono rewizję r{previousRevision}. Trwałe ręczne decyzje procesów zostały zachowane."
            : "Przeliczono wersję roboczą. Trwałe ręczne decyzje procesów zostały zachowane.";
    }

    [RelayCommand]
    private async Task ResetProcessOverridesAsync()
    {
        if (IsBusy || Documents.Count == 0)
            return;
        _project.ProcessOverrides ??= new Dictionary<string, ProcessManualOverride>(StringComparer.OrdinalIgnoreCase);
        _project.ProcessOverrides.Clear();
        foreach (var process in Processes)
            process.ManualOverride = false;
        OnPropertyChanged(nameof(HasManualProcessOverrides));
        OnPropertyChanged(nameof(ManualOverrideSummary));
        MarkDirty();
        PersistDraft();
        StatusText = "Usunięto ręczne decyzje procesów. Odtwarzam automatykę z dokumentacji i historii…";
        await AnalyzeAsync();
    }

    public async Task AnalyzeHistoryFolderAsync(string rootPath)
    {
        if (IsBusy)
        {
            HistoryImportStatus = "Inna analiza już trwa. Poczekaj na jej zakończenie.";
            return;
        }
        if (string.IsNullOrWhiteSpace(rootPath) || !Directory.Exists(rootPath))
        {
            HistoryImportStatus = "Wybrany folder nie istnieje.";
            return;
        }

        PersistDraftIfNeeded();
        _historyImport.CleanupUnimported(HistoryImportItems);
        HistoryImportItems.Clear();
        HistoryCalibrationSuggestions.Clear();
        CncCapacitySuggestions.Clear();
        HistoryRateSuggestions.Clear();
        CalibrationValidation = new CalibrationValidationReport();
        HistoryImportRoot = rootPath;
        HistoryImportHasResults = false;
        HistoryImportProgressPercent = 0;
        HistoryImportProgressText = "Przygotowanie analizy…";
        HistoryImportStatus = "Analizuję stare projekty bez zapisywania ich do historii.";
        _historyScanCancellation?.Dispose();
        _historyScanCancellation = new CancellationTokenSource();
        IsBusy = true;
        NotifyHistoryImportState();
        await Task.Yield();

        try
        {
            var progress = new Progress<HistoryImportProgress>(p =>
            {
                HistoryImportProgressText = p.Text;
                HistoryImportProgressPercent = p.Percent;
            });

            var result = await _historyImport.AnalyzeRootAsync(rootPath, Settings, progress, _historyScanCancellation.Token, HistoryFastMode);
            foreach (var candidate in result.Candidates)
            {
                if (!string.IsNullOrWhiteSpace(candidate.SourceKey) &&
                    await _projects.IsHistorySourceImportedAsync(candidate.SourceKey))
                {
                    candidate.AlreadyImported = true;
                    if (candidate.HasPreparedProject && candidate.ReadyToImport)
                    {
                        candidate.Status = "Do aktualizacji";
                        candidate.Message = "Ten projekt jest już w historii. Został ponownie przeanalizowany silnikiem DS Estimate 1.0; import zastąpi poprzedni wynik nową analizą dokumentacji, zachowując czasy rzeczywiste z wyceny.";
                    }
                    else
                    {
                        candidate.ReadyToImport = false;
                        candidate.Status = "Już w historii";
                    }
                }
                HistoryImportItems.Add(candidate);
            }

            foreach (var suggestion in _historyImport.BuildSuggestions(
                         HistoryImportItems.Where(x => x.ReadyToImport || x.Imported), Settings))
                HistoryCalibrationSuggestions.Add(suggestion);

            foreach (var suggestion in _historyImport.BuildCncCapacitySuggestions(
                         HistoryImportItems.Where(x => x.ReadyToImport || x.Imported), Settings))
                CncCapacitySuggestions.Add(suggestion);

            foreach (var suggestion in _historyImport.BuildRateSuggestions(
                         HistoryImportItems.Where(x => x.ReadyToImport || x.Imported), Settings))
                HistoryRateSuggestions.Add(suggestion);

            CalibrationValidation = _historyImport.BuildCalibrationValidation(
                HistoryImportItems.Where(x => x.ReadyToImport || x.Imported || x.Status == "Uwaga"), Settings);

            HistoryImportHasResults = true;
            HistoryImportProgressPercent = 100;
            HistoryImportProgressText = "Analiza zakończona";
            HistoryImportStatus =
                $"Znaleziono {result.FolderCount} folderów · gotowe {HistoryReadyCount} · do ponownej analizy {HistoryRefreshCount} · uwagi {HistoryWarningCount} · błędy {HistoryErrorCount}. " +
                "Nic nie zostało jeszcze zapisane do bazy.";
        }
        catch (OperationCanceledException)
        {
            HistoryImportStatus = "Skanowanie historii anulowano. Ukończone wyniki pozostają w cache; ponowne uruchomienie nie musi liczyć tych samych plików od zera.";
            HistoryImportProgressText = "Anulowano przez użytkownika";
        }
        catch (Exception ex)
        {
            var crash = CrashDiagnosticService.Write(ex, "history-scan");
            HistoryImportStatus = $"Nie udało się przeanalizować historii: {ex.Message}. Pakiet diagnostyczny: {crash}";
        }
        finally
        {
            _historyScanCancellation?.Dispose();
            _historyScanCancellation = null;
            IsBusy = false;
            NotifyHistoryImportState();
        }
    }

    [RelayCommand]
    private void CancelHistoryScan()
    {
        if (_historyScanCancellation is null) return;
        HistoryImportStatus = "Zatrzymuję skanowanie historii…";
        _historyScanCancellation.Cancel();
    }

    [RelayCommand]
    private async Task ImportAnalyzedHistoryAsync()
    {
        if (IsBusy)
            return;

        var ready = HistoryImportItems
            .Where(x => x.ReadyToImport && !x.Imported && x.HasPreparedProject)
            .ToList();
        if (ready.Count == 0)
        {
            HistoryImportStatus = "Brak nowych projektów gotowych do importu.";
            return;
        }

        IsBusy = true;
        NotifyHistoryImportState();
        var imported = 0;
        var failed = 0;
        try
        {
            for (var i = 0; i < ready.Count; i++)
            {
                var item = ready[i];
                HistoryImportProgressPercent = ready.Count == 0 ? 0 : i * 100.0 / ready.Count;
                HistoryImportProgressText = $"Import {i + 1}/{ready.Count} · {item.ProjectName}";
                try
                {
                    var previousProjectId = item.AlreadyImported
                        ? await _projects.GetHistoryProjectIdAsync(item.SourceKey)
                        : null;

                    var project = _historyImport.LoadPreparedProject(item)
                                  ?? throw new InvalidOperationException("Nie można odczytać przygotowanego snapshotu projektu historycznego.");
                    await _projects.SaveAsync(project);
                    await _projects.RegisterHistoryImportAsync(item.SourceKey, project.Id);

                    if (previousProjectId.HasValue && previousProjectId.Value != project.Id)
                    {
                        await _projects.DeleteProjectDataAsync(previousProjectId.Value);
                        _packageImport.DeleteProjectImports(previousProjectId.Value);
                    }

                    _historyImport.ReleasePreparedSnapshot(item);
                    item.PreparedProject = null;
                    item.Imported = true;
                    item.ReadyToImport = false;
                    item.Status = previousProjectId.HasValue ? "Zaktualizowano" : "Zaimportowano";
                    item.Message = previousProjectId.HasValue
                        ? "Poprzedni wpis historii zastąpiono analizą DS Estimate 1.0. Czasy/koszty z wyceny pozostały danymi rzeczywistymi, a dokumentacja została przeliczona aktualnym silnikiem."
                        : "Projekt zapisano w historii wraz z wynikiem modelu i rzeczywistymi godzinami z metryki.";
                    imported++;
                }
                catch (Exception ex)
                {
                    item.Status = "Błąd";
                    item.Message = $"Import nieudany: {ex.Message}";
                    failed++;
                }
            }

            HistoryImportProgressPercent = 100;
            HistoryImportProgressText = "Import zakończony";

            string profileText = "";
            if (imported > 0 && Settings.AutoCompanyProfileEnabled && Settings.AutoApplyHistoryProfile)
            {
                // Rebuild the automatic profile from ALL persisted historical imports, not
                // only from the latest batch. This lets the shop profile improve cumulatively
                // when old quotations are imported on several different days.
                var historicalProjects = await _projects.LoadRecentProjectsAsync(2000);
                var profileCandidates = _historyImport.BuildCandidatesFromImportedProjects(historicalProjects);
                if (profileCandidates.Count == 0)
                    profileCandidates = HistoryImportItems.Where(x => x.Imported || x.ReadyToImport).ToList();
                var calibration = _historyImport.BuildSuggestions(profileCandidates, Settings);
                var rates = _historyImport.BuildRateSuggestions(profileCandidates, Settings);
                // Capacity samples require the detailed sheet↔geometry matching available in the
                // current scan, therefore they remain conservative and come from this batch.
                var capacities = _historyImport.BuildCncCapacitySuggestions(HistoryImportItems, Settings);
                var profile = _historyImport.ApplyCompanyProfile(Settings, profileCandidates, calibration, rates, capacities);
                _settingsRepo.Save(Settings);
                CalibrationValidation = _historyImport.BuildCalibrationValidation(profileCandidates, Settings);
                profileText = profile.Applied
                    ? $" Profil firmy został zaktualizowany automatycznie: {profile.HistoryProjects} projektów, pewność {profile.Confidence}%, walidacja {profile.ValidationStatus}."
                    : $" Profil nie został zmieniony. {profile.ValidationSummary}";
                OnPropertyChanged(nameof(CompanyProfileStatus));
                OnPropertyChanged(nameof(CuttingStation));
                OnPropertyChanged(nameof(Weld135Station));
                OnPropertyChanged(nameof(Weld136Station));
                OnPropertyChanged(nameof(Weld111Station));
                OnPropertyChanged(nameof(CncSmallStation));
                OnPropertyChanged(nameof(CncMediumStation));
                OnPropertyChanged(nameof(CncLargeStation));
                OnPropertyChanged(nameof(SurfaceStation));
                OnPropertyChanged(nameof(AssemblyStation));
                if (profile.Applied && HasAnalysis) AnalysisNeedsRecalculation = true;
            }

            HistoryImportStatus =
                $"Zaimportowano {imported} projektów" + (failed > 0 ? $" · błędy {failed}" : "") + "." + profileText;
            await RefreshProjectListsAsync();
        }
        finally
        {
            IsBusy = false;
            RefreshHistoryImportCollection();
            NotifyHistoryImportState();
        }
    }

    [RelayCommand]
    private void ApplyProcessEdits()
    {
        if (IsBusy || Analysis is null)
            return;

        CaptureProcessOverridesFromEditor();
        _cost.ApplyManualProcessEdits(Analysis, Processes, Settings);
        LoadAnalysisCollections();
        AnalysisNeedsRecalculation = false;
        MarkDirty();
        PersistDraft();
        StatusText = HasManualProcessOverrides
            ? $"Zastosowano i zapisano {_project.ProcessOverrides.Values.Count(x => x.HasAny)} ręczne decyzje procesów. Przelicz ich nie usunie."
            : "Nie wykryto zmian względem automatyki.";
        OnPropertyChanged(nameof(Analysis));
        OnPropertyChanged(nameof(HasManualProcessOverrides));
        OnPropertyChanged(nameof(ManualOverrideSummary));
    }

    public void RegisterProcessToggle(ProcessEstimate process)
    {
        if (process is null) return;
        process.ManualOverride = process.Enabled != process.AutomaticEnabled;
        CaptureProcessOverride(process);
        MarkDirty();
        PersistDraft();
        OnPropertyChanged(nameof(HasManualProcessOverrides));
        OnPropertyChanged(nameof(ManualOverrideSummary));
    }

    [RelayCommand]
    private async Task ResetHistoryAndCalibrationAsync()
    {
        if (IsBusy)
            return;
        if (!ResetHistoryArmed)
        {
            ResetHistoryArmed = true;
            StatusText = "Reset historii usuwa tylko projekty zaimportowane przez moduł historii i zeruje profil kalibracji. Kliknij przycisk ponownie, aby potwierdzić.";
            return;
        }

        ResetHistoryArmed = false;
        IsBusy = true;
        try
        {
            // Remove physical import copies/cache belonging to historical projects as well
            // as database rows. This keeps "wyczyść historię" semantically complete.
            var persistedBeforeReset = await _projects.LoadRecentProjectsAsync(5000);
            foreach (var historical in persistedBeforeReset.Where(x => x.HistoryImport is not null))
                _packageImport.DeleteProjectImports(historical.Id);

            var removed = await _projects.ClearImportedHistoryAsync();

            if (Settings.CompanyProfileBaselineWorkstations.Count > 0)
            {
                Settings.Workstations = Settings.CompanyProfileBaselineWorkstations.Select(CloneWorkstation).ToList();
                if (!string.IsNullOrWhiteSpace(Settings.CompanyProfileBaselinePricingProfileName))
                    Settings.PricingProfileName = Settings.CompanyProfileBaselinePricingProfileName;
                if (Settings.CompanyProfileBaselineRatesConfirmedByCompany.HasValue)
                    Settings.RatesConfirmedByCompany = Settings.CompanyProfileBaselineRatesConfirmedByCompany.Value;
            }
            else if (Settings.PricingProfileName.StartsWith("Profil firmy — historia", StringComparison.OrdinalIgnoreCase))
            {
                // Profiles created in releases before R9.0.8 have no reversible snapshot.
                // Clear the calibration status without silently overwriting the user's current rates.
                Settings.PricingProfileName = new CostingSettings().PricingProfileName;
                Settings.RatesConfirmedByCompany = false;
            }

            Settings.CompanyProcessFactors.Clear();
            Settings.CompanyProfileVersion = 0;
            Settings.CompanyProfileHistoryProjects = 0;
            Settings.CompanyProfileConfidence = 0;
            Settings.CompanyProfileUpdatedAt = null;
            Settings.CompanyProfileBaselineWorkstations.Clear();
            Settings.CompanyProfileBaselinePricingProfileName = "";
            Settings.CompanyProfileBaselineRatesConfirmedByCompany = null;
            Settings.CompanyProfileValidationStatus = "OCZEKUJE";
            Settings.CompanyProfileValidationSummary = "";
            Settings.CompanyProfileValidationTrainingProjects = 0;
            Settings.CompanyProfileValidationProjects = 0;
            Settings.CompanyProfileValidationBaselineMapePercent = 0;
            Settings.CompanyProfileValidationProposedMapePercent = 0;
            Settings.CompanyProfileValidationBaselineBiasPercent = 0;
            Settings.CompanyProfileValidationProposedBiasPercent = 0;
            Settings.CompanyProfileValidationBaselineP90Percent = 0;
            Settings.CompanyProfileValidationProposedP90Percent = 0;
            Settings.CompanyProfileValidationRollingFolds = 0;
            Settings.CompanyProfileValidationRollingBaselineMapePercent = 0;
            Settings.CompanyProfileValidationRollingProposedMapePercent = 0;
            _settingsRepo.Save(Settings);

            HistoryImportItems.Clear();
            HistoryCalibrationSuggestions.Clear();
            CncCapacitySuggestions.Clear();
            HistoryRateSuggestions.Clear();
            CalibrationValidation = new CalibrationValidationReport();
            HistoryImportHasResults = false;
            HistoryImportProgressText = "";
            HistoryImportProgressPercent = 0;
            CalibrationFactors.Clear();
            if (Analysis is not null)
                Analysis.CalibrationFactors.Clear();

            OnPropertyChanged(nameof(CompanyProfileStatus));
            OnPropertyChanged(nameof(CompanyRateCardStations));
            OnPropertyChanged(nameof(CuttingStation));
            OnPropertyChanged(nameof(Weld135Station));
            OnPropertyChanged(nameof(Weld136Station));
            OnPropertyChanged(nameof(Weld111Station));
            OnPropertyChanged(nameof(CncSmallStation));
            OnPropertyChanged(nameof(CncMediumStation));
            OnPropertyChanged(nameof(CncLargeStation));
            OnPropertyChanged(nameof(SurfaceStation));
            OnPropertyChanged(nameof(AssemblyStation));
            if (HasAnalysis)
                AnalysisNeedsRecalculation = true;

            HistoryImportStatus = $"Wyczyszczono historię i kalibrację · usunięto {removed} projektów historycznych. Profil firmy wrócił do stanu bazowego.";
            StatusText = HistoryImportStatus;
            await RefreshProjectListsAsync();
        }
        finally
        {
            IsBusy = false;
            NotifyHistoryImportState();
        }
    }

    private static WorkstationDefinition CloneWorkstation(WorkstationDefinition x) => new()
    {
        Code = x.Code, Name = x.Name, ProcessCode = x.ProcessCode, MatchTag = x.MatchTag,
        Enabled = x.Enabled, Priority = x.Priority, RatePlnPerHour = x.RatePlnPerHour,
        CostCenterCode = x.CostCenterCode, CostCenterName = x.CostCenterName,
        DisplayInRateCard = x.DisplayInRateCard, AutomaticRoutingCandidate = x.AutomaticRoutingCandidate,
        DirectLaborRatePlnH = x.DirectLaborRatePlnH, DepartmentOverheadPercent = x.DepartmentOverheadPercent,
        DepartmentCostRatePlnH = x.DepartmentCostRatePlnH, ManufacturingCostRatePlnH = x.ManufacturingCostRatePlnH,
        GeneralOverheadPercent = x.GeneralOverheadPercent, GeneralCostRatePlnH = x.GeneralCostRatePlnH,
        VariableDepartmentPercent = x.VariableDepartmentPercent, VariableDepartmentRatePlnH = x.VariableDepartmentRatePlnH,
        MaxXmm = x.MaxXmm, MaxYmm = x.MaxYmm, MaxZmm = x.MaxZmm,
        MaxWeightKg = x.MaxWeightKg, MaxThicknessMm = x.MaxThicknessMm,
        TimeFactor = x.TimeFactor, LearnedSamples = x.LearnedSamples
    };

    [RelayCommand]
    private void ClearHistoryImportResults()
    {
        if (IsBusy)
            return;
        _historyImport.CleanupUnimported(HistoryImportItems);
        HistoryImportItems.Clear();
        HistoryCalibrationSuggestions.Clear();
        CncCapacitySuggestions.Clear();
        HistoryRateSuggestions.Clear();
        CalibrationValidation = new CalibrationValidationReport();
        HistoryImportHasResults = false;
        HistoryImportProgressText = "";
        HistoryImportProgressPercent = 0;
        HistoryImportStatus = "Wyniki wyczyszczono. Możesz wybrać inny folder historii.";
        NotifyHistoryImportState();
    }

    private void RefreshHistoryImportCollection()
    {
        var items = HistoryImportItems.ToList();
        HistoryImportItems.Clear();
        foreach (var item in items)
            HistoryImportItems.Add(item);
    }

    private void NotifyHistoryImportState()
    {
        OnPropertyChanged(nameof(CanImportHistory));
        OnPropertyChanged(nameof(HistoryReadyCount));
        OnPropertyChanged(nameof(HistoryRefreshCount));
        OnPropertyChanged(nameof(HistoryWarningCount));
        OnPropertyChanged(nameof(HistoryErrorCount));
        OnPropertyChanged(nameof(HistoryImportedCount));
        OnPropertyChanged(nameof(CanApplyCncCapacitySuggestions));
        OnPropertyChanged(nameof(CanApplyHistoryRates));
    }

    [RelayCommand]
    private void ApplyHistoryRates()
    {
        if (IsBusy)
            return;
        var changed = _historyImport.ApplyRateSuggestions(Settings, HistoryRateSuggestions);
        if (changed <= 0)
        {
            HistoryImportStatus = "Nie znaleziono stawek RBH do zastosowania.";
            return;
        }

        _settingsRepo.Save(Settings);
        OnPropertyChanged(nameof(CompanyRateCardStations));
        OnPropertyChanged(nameof(CuttingStation));
        OnPropertyChanged(nameof(Weld135Station));
        OnPropertyChanged(nameof(Weld136Station));
        OnPropertyChanged(nameof(Weld111Station));
        OnPropertyChanged(nameof(CncSmallStation));
        OnPropertyChanged(nameof(CncMediumStation));
        OnPropertyChanged(nameof(CncLargeStation));
        OnPropertyChanged(nameof(SurfaceStation));
        OnPropertyChanged(nameof(AssemblyStation));
        if (HasAnalysis)
            AnalysisNeedsRecalculation = true;
        HistoryImportStatus = $"Zastosowano {changed} stawek RBH z metryk do Ustawień. Profil oznaczono jako firmowy; bieżące wyceny wymagają ponownego przeliczenia.";
        NotifyHistoryImportState();
    }

    [RelayCommand]
    private void ApplyCncCapacitySuggestions()
    {
        if (IsBusy)
            return;
        var changed = _historyImport.ApplyCncCapacitySuggestions(Settings, CncCapacitySuggestions);
        if (changed <= 0)
        {
            HistoryImportStatus = "Brak wystarczająco pewnych propozycji zakresów CNC do zastosowania.";
            return;
        }

        _settingsRepo.Save(Settings);
        OnPropertyChanged(nameof(CncSmallStation));
        OnPropertyChanged(nameof(CncMediumStation));
        OnPropertyChanged(nameof(CncLargeStation));
        if (HasAnalysis)
            AnalysisNeedsRecalculation = true;

        // Do not automatically repeat a potentially long history scan. The learned
        // boundaries are intended for future estimates. The current preview stays
        // auditable as the result calculated with the settings that were active when
        // the scan started; the user may explicitly re-run the folder if desired.
        HistoryImportStatus = $"Zastosowano uczone granice routingu dla {changed} stanowisk CNC (małe/średnie). Nie uruchomiono ponownie całej analizy; nowe granice będą używane w kolejnych wycenach. Dużej maszyny nie ograniczono automatycznie od góry.";
        NotifyHistoryImportState();
    }

    [RelayCommand]
    private async Task SaveAsync()
    {
        SyncProjectFromUi();
        await _projects.SaveAsync(_project);

        if (!string.Equals(_project.Name, "Nowa wycena", StringComparison.OrdinalIgnoreCase))
            ProjectName = _project.Name;

        DeleteArmed = false;
        NewProjectArmed = false;
        IsDirty = false;
        AnalysisNeedsRecalculation = false;
        _projects.DeleteDraft();
        HasStoredDraft = false;
        StatusText = $"Zapisano rewizję {_project.Revision} · {DateTime.Now:HH:mm:ss}.";
        NotifyProjectState();

        await RefreshProjectListsAsync();
    }

    public async Task ExportExcelAsync(string path)
    {
        SyncProjectFromUi();
        var snapshot = _quoteRelease.FreezeForExport(_project, Settings);
        _excel.Export(_project, path);
        MarkDirty();
        PersistDraft();
        RefreshQuoteRelease();
        StatusText = $"Wyeksportowano XLSX z zamrożonym snapshotem {snapshot.FingerprintShort}.";
        await Task.CompletedTask;
    }

    public bool PrepareOfferExport()
    {
        SyncProjectFromUi();
        RefreshQuoteRelease();
        if (CanExportOffer)
            return true;
        StatusText = OfferReleaseSummary;
        return false;
    }

    [RelayCommand]
    private void ApproveOfferOverride()
    {
        if (IsBusy || Analysis is null)
            return;
        try
        {
            SyncProjectFromUi();
            _quoteRelease.ApproveOverride(_project, Settings, OfferOverrideReason);
            OfferOverrideReason = "";
            MarkDirty();
            PersistDraft();
            RefreshQuoteRelease();
            StatusText = "Zapisano audytowany wyjątek. Eksport jest dozwolony tylko dla obecnego odcisku danych i ustawień.";
        }
        catch (Exception ex)
        {
            StatusText = ex.Message;
        }
    }

    [RelayCommand]
    private void RefreshEngineHealth()
    {
        var report = _engineHealth.Capture();
        EngineHealthItems.Clear();
        foreach (var item in report.Items)
            EngineHealthItems.Add(item);
        EngineHealthSummary = report.Summary;

        var goldenPath = FirmGoldenSetService.FindDefaultPath();
        FirmGoldenSetSummary = _goldenSet.LoadAndEvaluate(goldenPath ?? "").Summary;
    }

    [RelayCommand]
    private void RestartStepWorkers()
    {
        if (IsBusy)
        {
            StatusText = "Nie można restartować STEP workera podczas analizy.";
            return;
        }
        var count = PythonRunner.RestartIdleStepWorkers();
        RefreshEngineHealth();
        StatusText = count > 0
            ? $"Zrestartowano {count} bezczynny(e) STEP worker(y)."
            : "Brak uruchomionego bezczynnego STEP workera — uruchomi się przy pierwszej analizie.";
    }

    public async Task ExportDiagnosticReportAsync(string path)
    {
        SyncProjectFromUi();
        _report.Export(_project, Settings, path);
        StatusText = "Wyeksportowano raport diagnostyczny.";
        await Task.CompletedTask;
    }

    private void SynchronizeCompanyRateCard()
    {
        var visibleBySsk = Settings.Workstations
            .Where(x => x.DisplayInRateCard && !string.IsNullOrWhiteSpace(x.CostCenterCode))
            .ToDictionary(x => x.CostCenterCode, x => x, StringComparer.OrdinalIgnoreCase);

        foreach (var station in Settings.Workstations.Where(x => !x.DisplayInRateCard && !string.IsNullOrWhiteSpace(x.CostCenterCode)))
        {
            if (visibleBySsk.TryGetValue(station.CostCenterCode, out var source))
                station.RatePlnPerHour = source.RatePlnPerHour;
        }

        HistoryImportService.SynchronizeBaseProcessRates(Settings);
        Settings.RatesConfirmedByCompany = true;
        if (!Settings.PricingProfileName.Contains("ZKS 2026", StringComparison.OrdinalIgnoreCase))
            Settings.PricingProfileName = "ZKS 2026 — RBH po koszcie całkowitym";
        OnPropertyChanged(nameof(CompanyRateCardStations));
    }

    public void SaveSettings()
    {
        SynchronizeCompanyRateCard();
        _settingsRepo.Save(Settings);
        if (HasAnalysis && Analysis is not null)
        {
            // FIX16: what-if is a presentation/decision layer over the current cost
            // result. Refresh it immediately; other model/rate changes still keep the
            // project marked for a safe full recalculation.
            Analysis.AppliedWhatIfMaterialPriceChangePercent = Settings.WhatIfMaterialPriceChangePercent;
            Analysis.AppliedWhatIfProcessTimeChangePercent = Settings.WhatIfProcessTimeChangePercent;
            QuoteScenarioEngine.Apply(Analysis);
            OnPropertyChanged(nameof(Analysis));
            AnalysisNeedsRecalculation = true;
            MarkDirty();
            PersistDraft();
            StatusText = "Ustawienia zapisane. Scenariusze what-if odświeżono bez STEP/OCR; zmiany modelu lub stawek pozostają oznaczone do pełnego przeliczenia.";
        }
        else
        {
            StatusText = "Ustawienia zapisane.";
        }
        RefreshQuoteRelease();
        RefreshEngineHealth();
    }

    public void SaveDraftOnExit()
    {
        if (IsDirty || (_project.Revision == 0 && HasCurrentWork()))
            PersistDraft();
        _historyImport.CleanupUnimported(HistoryImportItems);
    }

    private void RestoreDraftIfAvailable()
    {
        try
        {
            var draft = _projects.LoadDraft();
            if (draft is null)
                return;

            ApplyDraftToWorkspace(draft, "Przywrócono automatycznie zapisaną wersję roboczą z poprzedniej sesji.");
        }
        catch
        {
            // Uszkodzony draft nie może blokować uruchomienia aplikacji.
        }
    }

    private void ApplyDraftToWorkspace(QuoteProject draft, string status)
    {
        _suspendDirtyTracking = true;
        try
        {
            _project = draft;
            ProjectName = string.Equals(draft.Name, "Nowa wycena", StringComparison.OrdinalIgnoreCase) ? "" : draft.Name;
            Customer = draft.Customer ?? "";
            ManualWeightText = draft.ManualWeightKg?.ToString("0.###", CultureInfo.CurrentCulture) ?? "";
            Actuals = draft.Actuals ?? new ProductionActuals();
            Documents.Clear();
            foreach (var d in draft.Documents)
                Documents.Add(d);
            Analysis = draft.Analysis;
            MigrateLegacyProcessOverrideState(Analysis);
            HasAnalysis = Analysis is not null;
            PartSearch = "";
            LoadAnalysisCollections();
            IsDirty = true;
            HasStoredDraft = true;
            NewProjectArmed = false;
            AnalysisNeedsRecalculation = false;
            RecalculationComparisonText = "";
        }
        finally
        {
            _suspendDirtyTracking = false;
        }

        StatusText = HasInterruptedAnalysis
            ? status + $" Ukończone pliki poprzedniej analizy: {_project.ResumeState.CompletedDocumentCount}; kolejne LICZ użyje cache."
            : status;
        NotifyProjectState();
        ShowWorkspace();
        ShowSummary();
    }

    private void PersistDraftIfNeeded()
    {
        if (IsBusy)
            return;
        if (IsDirty || (_project.Revision == 0 && HasCurrentWork()))
            PersistDraft();
    }

    private void PersistDraft()
    {
        try
        {
            SyncProjectFromUi();
            _projects.SaveDraft(_project);
            HasStoredDraft = true;
            IsDirty = true;
        }
        catch
        {
            // Autozapis jest zabezpieczeniem i nie może przerywać normalnej pracy.
        }
    }

    private void MarkDirty()
    {
        if (_suspendDirtyTracking)
            return;
        IsDirty = true;
        NewProjectArmed = false;
    }

    private bool HasCurrentWork() =>
        Documents.Count > 0 ||
        HasAnalysis ||
        !string.IsNullOrWhiteSpace(ProjectName) ||
        !string.IsNullOrWhiteSpace(Customer) ||
        !string.IsNullOrWhiteSpace(ManualWeightText);

    private void NotifyProjectState()
    {
        OnPropertyChanged(nameof(RevisionText));
        OnPropertyChanged(nameof(SaveText));
        OnPropertyChanged(nameof(CanDeleteProject));
        OnPropertyChanged(nameof(NewProjectButtonText));
        OnPropertyChanged(nameof(DraftStateText));
        OnPropertyChanged(nameof(HasDraftState));
        OnPropertyChanged(nameof(CanRecalculate));
        OnPropertyChanged(nameof(HasMultiRootRisk));
        OnPropertyChanged(nameof(MultiRootDecisionText));
        OnPropertyChanged(nameof(HasManualProcessOverrides));
        OnPropertyChanged(nameof(ManualOverrideSummary));
        OnPropertyChanged(nameof(HasInterruptedAnalysis));
        OnPropertyChanged(nameof(ResumeSummary));
        RefreshQuoteRelease();
    }

    private void SyncProjectFromUi()
    {
        _project.Name = string.IsNullOrWhiteSpace(ProjectName)
            ? "Nowa wycena"
            : ProjectName.Trim();

        _project.Customer = Customer?.Trim() ?? "";
        _project.ManualWeightKg = ParseWeight();
        _project.Documents = Documents.ToList();
        _project.Actuals = Actuals ?? new ProductionActuals();
        if (_project.Actuals.HasAny && !_project.Actuals.CompletedAt.HasValue)
            _project.Actuals.CompletedAt = DateTime.Now;
        _project.Analysis = Analysis;
    }

    private void MigrateLegacyProcessOverrideState(AnalysisResult? result)
    {
        if (result is null)
            return;
        _project.ProcessOverrides ??= new Dictionary<string, ProcessManualOverride>(StringComparer.OrdinalIgnoreCase);
        foreach (var process in result.Processes)
        {
            // Projects saved before FIX13A do not have automatic baseline fields.
            // Preserve any legacy manual row as a full override; reset-to-automatic
            // still works because it triggers a fresh analysis after clearing this map.
            if (process.AutomaticRatePlnPerHour <= 0.0001)
            {
                if (process.ManualOverride && !_project.ProcessOverrides.ContainsKey(process.Code))
                {
                    _project.ProcessOverrides[process.Code] = new ProcessManualOverride
                    {
                        Code = process.Code,
                        OverrideEnabled = true,
                        Enabled = process.Enabled,
                        OverrideHours = true,
                        Hours = Math.Max(0, process.Hours),
                        OverrideRate = true,
                        RatePlnPerHour = Math.Max(0, process.RatePlnPerHour),
                        UpdatedAt = DateTime.Now
                    };
                }
                process.AutomaticEnabled = process.Enabled;
                process.AutomaticHours = process.Hours;
                process.AutomaticRatePlnPerHour = process.RatePlnPerHour;
            }
        }
    }

    private static void CaptureAutomaticProcessBaselines(AnalysisResult result)
    {
        foreach (var process in result.Processes)
        {
            process.AutomaticEnabled = process.Enabled;
            process.AutomaticHours = process.Hours;
            process.AutomaticRatePlnPerHour = process.RatePlnPerHour;
            process.ManualOverride = false;
        }
    }

    private void ApplyPersistedProcessOverrides(AnalysisResult result)
    {
        if (_project.ProcessOverrides is null || _project.ProcessOverrides.Count == 0)
            return;

        var applied = 0;
        foreach (var process in result.Processes)
        {
            if (!_project.ProcessOverrides.TryGetValue(process.Code, out var saved) || !saved.HasAny)
                continue;
            if (saved.OverrideEnabled) process.Enabled = saved.Enabled;
            if (saved.OverrideHours) process.Hours = Math.Max(0, saved.Hours);
            if (saved.OverrideRate) process.RatePlnPerHour = Math.Max(0, saved.RatePlnPerHour);
            process.ManualOverride = true;
            applied++;
        }
        if (applied > 0)
            _cost.ApplyManualProcessEdits(result, result.Processes, Settings);
    }

    private void CaptureProcessOverridesFromEditor()
    {
        foreach (var process in Processes)
            CaptureProcessOverride(process);
        foreach (var key in _project.ProcessOverrides.Where(x => !x.Value.HasAny).Select(x => x.Key).ToList())
            _project.ProcessOverrides.Remove(key);
    }

    private void CaptureProcessOverride(ProcessEstimate process)
    {
        _project.ProcessOverrides ??= new Dictionary<string, ProcessManualOverride>(StringComparer.OrdinalIgnoreCase);
        var enabledChanged = process.Enabled != process.AutomaticEnabled;
        var hoursChanged = Math.Abs(process.Hours - process.AutomaticHours) > 0.001;
        var rateChanged = Math.Abs(process.RatePlnPerHour - process.AutomaticRatePlnPerHour) > 0.01;
        if (!enabledChanged && !hoursChanged && !rateChanged)
        {
            _project.ProcessOverrides.Remove(process.Code);
            process.ManualOverride = false;
            return;
        }

        _project.ProcessOverrides[process.Code] = new ProcessManualOverride
        {
            Code = process.Code,
            OverrideEnabled = enabledChanged,
            Enabled = process.Enabled,
            OverrideHours = hoursChanged,
            Hours = Math.Max(0, process.Hours),
            OverrideRate = rateChanged,
            RatePlnPerHour = Math.Max(0, process.RatePlnPerHour),
            UpdatedAt = DateTime.Now
        };
        process.ManualOverride = true;
    }

    private void PersistAnalysisCheckpoint(bool force = false)
    {
        try
        {
            var now = DateTime.UtcNow;
            if (!force && now - _lastCheckpointPersistUtc < TimeSpan.FromSeconds(2))
                return;
            _lastCheckpointPersistUtc = now;
            SyncProjectFromUi();
            _projects.SaveDraft(_project);
            HasStoredDraft = true;
            OnPropertyChanged(nameof(HasInterruptedAnalysis));
            OnPropertyChanged(nameof(ResumeSummary));
        }
        catch
        {
            // Checkpoint is best-effort; analyzer cache still remains available.
        }
    }

    private void LoadAnalysisCollections()
    {
        _allParts = Analysis?.Geometry.Parts.ToList() ?? [];
        ApplyPartFilter();

        Processes.Clear();
        foreach (var item in Analysis?.Processes ?? [])
            Processes.Add(item);

        Risks.Clear();
        var risks = Analysis?.Risks.OrderByDescending(x => x.Level)
                    ?? Enumerable.Empty<RiskItem>();
        foreach (var item in risks)
            Risks.Add(item);

        CostLines.Clear();
        foreach (var item in Analysis?.CostLines ?? [])
            CostLines.Add(item);

        CostConfidence.Clear();
        foreach (var item in Analysis?.CostConfidence ?? [])
            CostConfidence.Add(item);

        SimilarProjects.Clear();
        foreach (var item in Analysis?.SimilarProjects ?? [])
            SimilarProjects.Add(item);

        AssemblyTree.Clear();
        foreach (var item in Analysis?.AssemblyTree ?? [])
            AssemblyTree.Add(item);

        RuleHits.Clear();
        foreach (var item in Analysis?.RuleHits ?? [])
            RuleHits.Add(item);

        CalibrationFactors.Clear();
        foreach (var item in Analysis?.CalibrationFactors ?? [])
            CalibrationFactors.Add(item);

        OnPropertyChanged(nameof(HasMultiRootRisk));
        OnPropertyChanged(nameof(MultiRootDecisionText));
        NotifyPartsState();
        RefreshQuoteRelease();
    }

    private void ApplyPartFilter()
    {
        Parts.Clear();
        var q = PartSearch?.Trim() ?? "";

        foreach (var part in _allParts.Where(x =>
                     string.IsNullOrWhiteSpace(q) ||
                     x.Name.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                     x.Classification.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                     x.SourceFile.Contains(q, StringComparison.OrdinalIgnoreCase)))
        {
            Parts.Add(part);
        }

        NotifyPartsState();
    }

    private void ClearAnalysis()
    {
        Analysis = null;
        HasAnalysis = false;
        _allParts = [];
        Parts.Clear();
        Processes.Clear();
        Risks.Clear();
        CostLines.Clear();
        CostConfidence.Clear();
        SimilarProjects.Clear();
        AssemblyTree.Clear();
        RuleHits.Clear();
        CalibrationFactors.Clear();
        NotifyPartsState();
        RefreshQuoteRelease();
    }

    private void RefreshQuoteRelease()
    {
        _project.Analysis = Analysis;
        _quoteReleaseDecision = _quoteRelease.Evaluate(_project, Settings);
        OnPropertyChanged(nameof(CanExportOffer));
        OnPropertyChanged(nameof(ShowOfferOverride));
        OnPropertyChanged(nameof(OfferReleaseSummary));
        OnPropertyChanged(nameof(HasFrozenSnapshot));
        OnPropertyChanged(nameof(FrozenSnapshotSummary));
    }

    private void NotifyPartsState()
    {
        OnPropertyChanged(nameof(HasParts));
        OnPropertyChanged(nameof(HasNoParts));
        OnPropertyChanged(nameof(PartsEmptyText));
    }

    private static string NormalizeDocumentStatus(string status) => status switch
    {
        "OK" => "Przeanalizowany",
        "Gotowy" => "Oczekuje",
        _ => status
    };

    private void NormalizeDocumentStatuses()
    {
        foreach (var document in Documents)
            document.Status = NormalizeDocumentStatus(document.Status);
    }

    private async Task RefreshProjectListsAsync()
    {
        RecentProjects.Clear();
        foreach (var item in await _projects.RecentAsync(6))
            RecentProjects.Add(item);

        await SearchProjectsAsync();
    }

    private async Task SearchProjectsAsync()
    {
        var items = await _projects.SearchAsync(ProjectSearch, 200);

        ProjectSearchResults.Clear();
        foreach (var item in items)
            ProjectSearchResults.Add(item);
    }

    private double? ParseWeight()
    {
        if (double.TryParse(
                ManualWeightText.Replace(',', '.'),
                NumberStyles.Float,
                CultureInfo.InvariantCulture,
                out var value) && value > 0)
            return value;

        return null;
    }

    private void SetTab(string tab)
    {
        IsSummaryTab = tab == "summary";
        IsPartsTab = tab == "parts";
        IsProcessesTab = tab == "processes";
        IsCostTab = tab == "cost";
        IsRisksTab = tab == "risks";
    }

    private static QuoteProject NewProjectModel() =>
        new()
        {
            Id = Guid.NewGuid(),
            Revision = 0,
            Name = "Nowa wycena",
            CreatedAt = DateTime.Now,
            ModifiedAt = DateTime.Now
        };

    private static ProjectDocument CloneDocument(ProjectDocument d) =>
        new()
        {
            Path = d.Path,
            Name = d.Name,
            Kind = d.Kind,
            SizeBytes = d.SizeBytes,
            RelativePath = d.RelativePath,
            PackageSource = d.PackageSource,
            ContentHash = d.ContentHash,
            ContentDuplicateOf = d.ContentDuplicateOf,
            IsActiveRevision = d.IsActiveRevision,
            ExcludeFromAnalysis = d.ExcludeFromAnalysis,
            Status = d.Status,
            Summary = d.Summary
        };

    private static DocumentKind DetectKind(string extension) =>
        extension.ToLowerInvariant() switch
        {
            ".step" or ".stp" => DocumentKind.Step,
            ".dxf" => DocumentKind.Dxf,
            ".dwg" => DocumentKind.Dwg,
            ".pdf" => DocumentKind.Pdf,
            ".png" or ".jpg" or ".jpeg" or ".tif" or ".tiff" or ".bmp" => DocumentKind.Image,
            ".xlsx" or ".xlsm" or ".xls" or ".csv" => DocumentKind.Excel,
            ".txt" or ".bom" or ".log" or ".md" or ".docx" or ".doc" or ".rtf" => DocumentKind.Text,
            _ => DocumentKind.Other
        };
}
