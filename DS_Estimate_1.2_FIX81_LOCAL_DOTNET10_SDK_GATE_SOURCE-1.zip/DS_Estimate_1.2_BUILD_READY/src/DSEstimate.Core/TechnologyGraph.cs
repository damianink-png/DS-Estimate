namespace DSEstimate.Core;

/// <summary>
/// FIX12A contract-first manufacturing model. These types are deliberately cost-neutral:
/// the shadow graph may explain and validate the current quote, but it cannot overwrite it.
/// </summary>
public enum ManufacturingStateKind
{
    RawMaterial,
    Cut,
    PreMachined,
    SubAssembly,
    WeldedAssembly,
    PostMachined,
    SurfacePrepared,
    Finished
}

public enum TechnologyProcessKind
{
    Material,
    Cutting,
    PreMachining,
    FitUp,
    Welding,
    PostMachining,
    Quality,
    SurfacePreparation,
    Painting,
    FinalAssembly,
    Other
}

public sealed class TechnologyGeometryDescriptor
{
    public double BoundingXmm { get; set; }
    public double BoundingYmm { get; set; }
    public double BoundingZmm { get; set; }
    public double VolumeMm3 { get; set; }
    public double SurfaceMm2 { get; set; }
    public double MassKg { get; set; }
    public int SolidCount { get; set; }
    public int HoleCount { get; set; }
    public int FaceCount { get; set; }
    public int EdgeCount { get; set; }

    public string BoundingBoxText => $"{BoundingXmm:0.###}×{BoundingYmm:0.###}×{BoundingZmm:0.###} mm";
}

public sealed class UniquePartGroup
{
    public string Id { get; set; } = "";
    public string GeometryKey { get; set; } = "";
    public string Name { get; set; } = "";
    public string SourceFile { get; set; } = "";
    public string Classification { get; set; } = "";
    public int Quantity { get; set; } = 1;
    public TechnologyGeometryDescriptor Geometry { get; set; } = new();
    public List<string> InstanceIds { get; set; } = [];
    public List<string> EvidenceIds { get; set; } = [];
}

public sealed class AssemblyState
{
    public string Id { get; set; } = "";
    public ManufacturingStateKind State { get; set; }
    public string Name { get; set; } = "";
    public List<string> EntityIds { get; set; } = [];
    public TechnologyGeometryDescriptor Geometry { get; set; } = new();
    public List<string> ProducedByProcessIds { get; set; } = [];
    public List<string> ConsumedByProcessIds { get; set; } = [];
}

/// <summary>
/// Confidence is intentionally multi-dimensional. Existence says that an operation is
/// required; Binding says that the target entity is known; Geometry says that the current
/// geometry state is understood; Parameters says that enough technological parameters are
/// known to estimate time/cost. Values are normalized to 0..1.
/// </summary>
public sealed class ConfidenceVector
{
    public double Existence { get; set; }
    public double Binding { get; set; }
    public double Geometry { get; set; }
    public double Parameters { get; set; }

    public double Cost => Clamp(Existence) *
        (0.35 * Clamp(Binding) + 0.35 * Clamp(Geometry) + 0.30 * Clamp(Parameters));

    public int ExistencePercent => Percent(Existence);
    public int BindingPercent => Percent(Binding);
    public int GeometryPercent => Percent(Geometry);
    public int ParametersPercent => Percent(Parameters);
    public int CostPercent => Percent(Cost);

    private static double Clamp(double value) => Math.Clamp(value, 0.0, 1.0);
    private static int Percent(double value) => (int)Math.Round(Clamp(value) * 100.0, MidpointRounding.AwayFromZero);
}

public sealed class EvidenceTargetCandidate
{
    public string EntityId { get; set; } = "";
    public string EntityKind { get; set; } = "";
    public double Score { get; set; }
    public string Basis { get; set; } = "";
}

/// <summary>
/// Canonical FIX12 evidence contract:
/// Source -> Observation -> Candidate targets -> Geometry filter -> Process constraint.
/// No binding is allowed to change quote cost directly.
/// </summary>
public sealed class EvidenceBinding
{
    public string Id { get; set; } = "";
    public string SourceFile { get; set; } = "";
    public string SourceKind { get; set; } = "";
    public string Observation { get; set; } = "";
    public string Field { get; set; } = "";
    public string Scope { get; set; } = "UNKNOWN";
    public List<EvidenceTargetCandidate> TargetCandidates { get; set; } = [];
    public string ResolvedTargetId { get; set; } = "";
    public string GeometryFilter { get; set; } = "";
    public string ProcessConstraint { get; set; } = "";
    public ConfidenceVector Confidence { get; set; } = new();
    public bool NeedsReview { get; set; }
    public string Note { get; set; } = "";
}

public sealed class ProcessNode
{
    public string Id { get; set; } = "";
    public TechnologyProcessKind Process { get; set; }
    public string LegacyProcessCode { get; set; } = "";
    public string Name { get; set; } = "";
    public List<string> InputStateIds { get; set; } = [];
    public string OutputStateId { get; set; } = "";
    public List<string> RequiredBefore { get; set; } = [];
    public List<string> RequiredAfter { get; set; } = [];
    public List<string> EvidenceIds { get; set; } = [];
    public ConfidenceVector Confidence { get; set; } = new();
    public double LegacyHours { get; set; }
    public double LegacyCostPln { get; set; }
    public string Basis { get; set; } = "";
    public bool ShadowOnly { get; set; } = true;
}

public sealed class ShadowTechnologyGraph
{
    public string Version { get; set; } = "FIX12A-SHADOW-1";
    public bool ShadowOnly { get; set; } = true;
    public bool HasPriceAuthority { get; set; }
    public List<UniquePartGroup> UniquePartGroups { get; set; } = [];
    public List<AssemblyState> States { get; set; } = [];
    public List<ProcessNode> Processes { get; set; } = [];
    public List<EvidenceBinding> EvidenceBindings { get; set; } = [];
    public List<string> Warnings { get; set; } = [];
    public double LegacyRecommendedPricePln { get; set; }
    public string LegacyRoute { get; set; } = "";
    public string ShadowRoute { get; set; } = "";
    public bool PostWeldMachiningDetected { get; set; }

    public string Summary =>
        $"{UniquePartGroups.Count} grup · {States.Count} stanów · {Processes.Count} procesów · " +
        $"{EvidenceBindings.Count} powiązań dowodów · price authority: {(HasPriceAuthority ? "TAK" : "NIE")}";
}
