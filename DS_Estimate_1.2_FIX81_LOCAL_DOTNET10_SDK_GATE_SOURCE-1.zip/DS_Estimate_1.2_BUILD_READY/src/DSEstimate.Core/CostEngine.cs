namespace DSEstimate.Core;

public sealed class CostEngine
{
    public AnalysisResult Build(
        GeometrySummary geometry,
        DrawingIntelligence drawing,
        DxfSignals dxf,
        double? manualWeightKg,
        CostingSettings settings,
        PackageIntelligence? package = null)
    {
        var result = new AnalysisResult
        {
            Geometry = geometry,
            Drawing = drawing,
            Dxf = dxf,
            Package = package ?? new PackageIntelligence(),
            PricingProfileName = string.IsNullOrWhiteSpace(settings.PricingProfileName)
                ? "Robocze - do kalibracji"
                : settings.PricingProfileName.Trim(),
            RatesConfirmedByCompany = settings.RatesConfirmedByCompany,
            AppliedMarkupPercent = settings.MarkupPercent,
            AppliedHistoricalBlendPercent = settings.HistoricalBlendPercent,
            AppliedWhatIfMaterialPriceChangePercent = settings.WhatIfMaterialPriceChangePercent,
            AppliedWhatIfProcessTimeChangePercent = settings.WhatIfProcessTimeChangePercent
        };

        result.Material = ResolveProjectMaterial(drawing);
        var resolvedDensity = ResolveDensity(result.Material, settings.DefaultSteelDensityKgM3);
        result.DensityKgM3 = resolvedDensity.DensityKgM3;
        result.DensityAssumed = resolvedDensity.Assumed;
        if (result.Material.StartsWith("MIXED:", StringComparison.OrdinalIgnoreCase))
            result.Drawing.Findings.Add($"Materiał projektu: mieszany ({result.Material[6..].Trim()}); zachowano gatunki na pozycjach BOM zamiast wymuszać jeden gatunek globalny.");

        var rawGeometryWeight = geometry.Available && geometry.VolumeMm3 > 0
            ? geometry.VolumeMm3 * 1e-9 * result.DensityKgM3
            : (double?)null;
        // FIX12D: a geometrically valid STEP may represent only a few children of a
        // much larger root BOM. In that case keep STEP for feature/process analysis,
        // but do not promote its mass to PROJECT_TOTAL.
        var geometryWeight = drawing.StepGeometryProjectCoveragePartial ? null : rawGeometryWeight;
        if (drawing.StepGeometryProjectCoveragePartial && rawGeometryWeight is > 0)
            result.Drawing.Findings.Add(
                $"FIX12D: masa {rawGeometryWeight.Value:0.###} kg z dostępnych STEP pozostaje lokalnym cross-checkiem; " +
                $"pokrycie root BOM = {drawing.ResolvedStepFamilyMatchCount}/{drawing.ResolvedRootBomFamilyCount}, więc nie użyto jej jako masy projektu.");
        var bomWeight = drawing.BomTotalMassKg is > 0 ? drawing.BomTotalMassKg : null;
        var positiveBomMassItems = drawing.BomItems
            .Select(x => x.EffectiveTotalMassKg)
            .Where(x => x > 0)
            .ToList();
        var largestBomItemWeight = positiveBomMassItems.Count > 0 ? positiveBomMassItems.Max() : 0.0;
        var suspiciousUrlMass = drawing.BomItems.Any(x =>
            x.EffectiveTotalMassKg >= 100_000 &&
            (x.PartNumber.Contains("://", StringComparison.OrdinalIgnoreCase) ||
             x.Description.Contains("://", StringComparison.OrdinalIgnoreCase)));
        var catastrophicStepRatio = bomWeight is > 100_000 && geometryWeight is > 0 &&
            bomWeight.Value / Math.Max(geometryWeight.Value, 0.001) >= 1_000;
        var dominantCatastrophicRow = bomWeight is > 100_000 && largestBomItemWeight > 0 &&
            largestBomItemWeight / bomWeight.Value >= 0.995;
        // Defence in depth: a table parser must never let a price, URL variant or
        // product specification produce a many-orders-of-magnitude project mass.
        // Preserve the raw BOM value for diagnostics, but keep it out of costing.
        var bomWeightRejected = bomWeight is > 0 &&
            (suspiciousUrlMass || (catastrophicStepRatio && dominantCatastrophicRow));
        double? trustedBomWeight = bomWeightRejected ? null : bomWeight;
        if (bomWeightRejected)
            result.Drawing.Warnings.Add(
                $"Odrzucono niewiarygodną masę BOM {bomWeight!.Value:0.###} kg: wartość wygląda jak liczba z adresu, ceny lub specyfikacji produktu. Nie użyto jej do wyceny.");
        // A multi-row hierarchical BOM does NOT provide a safe total merely because
        // one row is the heaviest. Use item mass as project mass only for a single-row
        // BOM; otherwise wait for an explicit BOM/document total or STEP.
        var singleItemBomWeight = !bomWeightRejected && positiveBomMassItems.Count == 1
            ? positiveBomMassItems[0]
            : 0.0;
        var documentWeight = drawing.DocumentMassKg is > 0 && drawing.DocumentMassConfidence >= 45
            ? drawing.DocumentMassKg
            : singleItemBomWeight > 0 ? singleItemBomWeight : null;
        var reconstructedWeight = drawing.HybridMassProjectAuthoritative && drawing.HybridMassKg is > 0
            ? drawing.HybridMassKg
            : null;

        // Explicit user mass remains authoritative. When STEP material is unknown,
        // an explicit BOM mass is safer than applying the default steel density to
        // a potentially mixed-material assembly. Otherwise STEP remains the normal
        // source and BOM acts as an independent cross-check/fallback.
        if (manualWeightKg is > 0)
        {
            result.WeightKg = manualWeightKg;
            result.WeightSource = "ręczna";
        }
        else if (trustedBomWeight is > 0 && (geometryWeight is null || result.DensityAssumed))
        {
            result.WeightKg = trustedBomWeight;
            result.WeightSource = "BOM";
            result.Drawing.Findings.Add($"Masa wynikowa przyjęta z tabeli BOM: {trustedBomWeight.Value:0.###} kg.");
        }
        else if (documentWeight is > 0 && (geometryWeight is null || result.DensityAssumed))
        {
            result.WeightKg = documentWeight;
            result.WeightSource = drawing.DocumentMassKg is > 0 ? "PDF/DXF" : "BOM/PDF";
            result.Drawing.Findings.Add(drawing.DocumentMassKg is > 0
                ? $"Masa wynikowa przyjęta z dokumentacji PDF/DXF: {documentWeight.Value:0.###} kg (pewność odczytu {drawing.DocumentMassConfidence}%)."
                : $"Masa wynikowa przyjęta z jedynej pozycji BOM/PDF: {documentWeight.Value:0.###} kg.");
        }
        else if (geometryWeight is > 0 && trustedBomWeight is > 0 &&
                 drawing.BomMassSourceCount == 1 && drawing.BomMassRowCount >= 2 &&
                 Math.Abs(geometryWeight.Value - trustedBomWeight.Value) / Math.Max(trustedBomWeight.Value, 0.001) > 0.25)
        {
            // R9.2.3D2: in large RFQ packages several standalone STEP files can be
            // independent exports of parts/subassemblies. MergeGeometry intentionally
            // preserves all geometry for process analysis, but summing their volumes is
            // not a safe project weight. A single explicit hierarchical BOM total wins
            // when STEP and BOM differ materially; STEP remains a cross-check.
            result.WeightKg = trustedBomWeight;
            result.WeightSource = "BOM";
            result.Drawing.Findings.Add(
                $"Masa wynikowa: użyto jawnej masy całego BOM {trustedBomWeight.Value:0.###} kg zamiast sumy wolumenów wielu STEP ({geometryWeight.Value:0.###} kg). Geometria STEP pozostaje źródłem technologii/cech.");
        }
        else if (reconstructedWeight is > 0 && (geometryWeight is null || result.DensityAssumed))
        {
            result.WeightKg = reconstructedWeight;
            result.WeightSource = "FIX14 rekonstrukcja BOM/DXF/STEP";
            result.Drawing.Findings.Add(
                $"FIX14: masa projektu {reconstructedWeight.Value:0.###} kg została zrekonstruowana z {drawing.HybridMassContributions.Count} rodzin " +
                $"(pokrycie {drawing.HybridMassCoveragePercent:0.#}%, pewność {drawing.HybridMassConfidence}%).");
        }
        else if (geometryWeight is > 0)
        {
            result.WeightKg = geometryWeight;
            result.WeightSource = "STEP";
        }
        else if (trustedBomWeight is > 0)
        {
            result.WeightKg = trustedBomWeight;
            result.WeightSource = "BOM";
        }
        else if (documentWeight is > 0)
        {
            result.WeightKg = documentWeight;
            result.WeightSource = drawing.DocumentMassKg is > 0 ? "PDF/DXF" : "BOM/PDF";
        }

        ApplyPartMasses(result);
        var projectBreakdown = MaterialBreakdownEngine.Build(result);
        result.MaterialBreakdown = projectBreakdown.Materials;
        result.SemiFinishedProducts = projectBreakdown.SemiFinished;
        result.CncFeatures = CncFeatureSummaryEngine.Build(result);

        result.Welding = BuildWeldEstimate(result, settings);
        result.Painting = BuildPaintEstimate(result, settings);
        result.Processes = BuildProcesses(result, settings);
        result.Risks = BuildRisks(result, manualWeightKg, geometryWeight);
        if (drawing.StepGeometryProjectCoveragePartial)
        {
            result.Risks.Add(new RiskItem
            {
                Code = "FIX12D_PARTIAL_STEP_SCOPE",
                Level = result.WeightKg is > 0 ? RiskLevel.Medium : RiskLevel.High,
                Title = "STEP nie obejmuje całego głównego BOM",
                Message = $"Resolver powiązał {drawing.ResolvedStepFamilyMatchCount} rodzin STEP z {drawing.ResolvedRootBomFamilyCount} rodzinami głównej listy części. " +
                          (result.WeightKg is > 0
                              ? $"Masa projektu pochodzi z {result.WeightSource}; STEP służy tylko do cech lokalnych."
                              : "Nie ma bezpiecznej masy całego projektu — cena materiału pozostaje częściowa do czasu BOM/jawnej masy zespołu."),
                Blocking = result.WeightKg is null
            });
        }
        if (bomWeightRejected)
        {
            result.Risks.Add(new RiskItem
            {
                Code = "BOM_MASS_IMPLAUSIBLE",
                Level = RiskLevel.Critical,
                Title = "Niewiarygodna masa w BOM została odrzucona",
                Message = $"Tabela zwróciła {bomWeight!.Value:0.###} kg, ale wartość ma cechy ceny, identyfikatora lub liczby ze specyfikacji. " +
                          (geometryWeight is > 0
                              ? $"Do wyceny użyto geometrii STEP ({geometryWeight.Value:0.###} kg przy bieżącej gęstości)."
                              : "Brak bezpiecznej masy zastępczej — uzupełnij masę ręcznie lub popraw nagłówki BOM."),
                Blocking = geometryWeight is null
            });
        }
        if (trustedBomWeight is > 0 && geometryWeight is > 0)
        {
            var diff = Math.Abs(trustedBomWeight.Value - geometryWeight.Value) / Math.Max(trustedBomWeight.Value, 0.001) * 100.0;
            if (diff > 8)
            {
                result.Risks.Add(new RiskItem
                {
                    Code = "WEIGHT_BOM_DIFF",
                    Level = diff > 25 ? RiskLevel.High : RiskLevel.Medium,
                    Title = "Masa BOM różni się od STEP",
                    Message = $"BOM: {trustedBomWeight.Value:0.###} kg; STEP przy bieżącej gęstości: {geometryWeight.Value:0.###} kg; różnica {diff:0.#}%. Sprawdź zakres BOM i materiały mieszane.",
                    Blocking = false
                });
            }
            else
            {
                result.Drawing.Findings.Add($"Kontrola masy: BOM {trustedBomWeight.Value:0.###} kg i STEP {geometryWeight.Value:0.###} kg są zgodne (różnica {diff:0.#}%).");
            }
        }
        if (documentWeight is > 0 && geometryWeight is > 0)
        {
            var massScope = (drawing.DocumentMassScope ?? "UNKNOWN").Trim().ToUpperInvariant();
            var comparableProjectScope = massScope is "PROJECT_TOTAL" or "BOM_TOTAL" or "ASSEMBLY_TOTAL";
            if (comparableProjectScope)
            {
                var diff = Math.Abs(documentWeight.Value - geometryWeight.Value) / Math.Max(documentWeight.Value, 0.001) * 100.0;
                if (diff > 8)
                {
                    result.Risks.Add(new RiskItem
                    {
                        Code = "WEIGHT_DRAWING_DIFF",
                        Level = diff > 25 ? RiskLevel.High : RiskLevel.Medium,
                        Title = "Masa z dokumentacji całego zakresu różni się od STEP",
                        Message = $"Dokumentacja ({massScope}): {documentWeight.Value:0.###} kg; STEP: {geometryWeight.Value:0.###} kg; różnica {diff:0.#}%. Sprawdź zakres złożenia i materiał.",
                        Blocking = false
                    });
                }
                else
                    result.Drawing.Findings.Add($"Kontrola masy: dokumentacja ({massScope}) {documentWeight.Value:0.###} kg i STEP {geometryWeight.Value:0.###} kg są zgodne (różnica {diff:0.#}%).");
            }
            else
            {
                result.Drawing.Findings.Add($"Masa {documentWeight.Value:0.###} kg z PDF/DXF ma zakres {massScope}; pozostaje lokalnym kandydatem i nie jest porównywana z masą całego STEP {geometryWeight.Value:0.###} kg.");
            }
        }
        if (result.Painting.Enabled && result.Painting.PaintableAreaM2 <= 0.0001)
        {
            result.Risks.Add(new RiskItem
            {
                Code = "PAINT_AREA_MISSING",
                Level = RiskLevel.High,
                Title = "Malowanie wymagane, ale brak powierzchni",
                Message = "Dokumentacja wskazuje malowanie/przygotowanie powierzchni, lecz nie udało się uzyskać powierzchni z STEP ani dokumentacji. Koszt malowania wymaga weryfikacji.",
                Blocking = false
            });
        }
        else if (result.Painting.Enabled && result.Painting.Confidence <= 42 && geometry.SurfaceMm2 <= 0 && drawing.DocumentSurfaceAreaM2 is null && drawing.HybridSurfaceAreaM2 is null)
        {
            result.Risks.Add(new RiskItem
            {
                Code = "PAINT_AREA_MASS_ESTIMATE",
                Level = RiskLevel.High,
                Title = "Powierzchnia malowania oszacowana z masy",
                Message = $"Brak wiarygodnej powierzchni geometrycznej. Użyto awaryjnego szacunku {result.Painting.PaintableAreaM2:0.###} m² z masy {result.WeightKg:0.###} kg. Zweryfikuj pole przed zatwierdzeniem wyceny.",
                Blocking = false
            });
        }
        if (result.Painting.Enabled && drawing.HybridSurfaceAreaM2 is > 0 && drawing.HybridSurfaceAreaCoveragePercent < 99.5)
        {
            result.Risks.Add(new RiskItem
            {
                Code = "FIX12E_SURFACE_PARTIAL_COVERAGE",
                Level = drawing.HybridSurfaceAreaCoveragePercent < 70 ? RiskLevel.Medium : RiskLevel.Low,
                Title = "Powierzchnia malowania zrekonstruowana z niepełnej paczki",
                Message = $"FIX12E policzył {drawing.HybridSurfaceAreaM2.Value:0.###} m² z pokryciem {drawing.HybridSurfaceAreaCoveragePercent:0.#}% rodzin BOM. " +
                          $"Źródła: {drawing.HybridSurfaceAreaSource}. Brakujące rodziny nie zostały arbitralnie ani podwójnie doliczone.",
                Blocking = false
            });
        }

        ShopRuleEngine.Apply(result, settings);
        ApplyWorkstations(result, settings);
        result.ProjectClass = ProjectClassEngine.Classify(result);
        result.Nesting = NestingCostEngine.Estimate(result, settings);
        if (result.Nesting.Available && result.Nesting.MaterialFactor >= 1.70)
        {
            result.Risks.Add(new RiskItem
            {
                Code = "NESTING_HIGH_FACTOR",
                Level = result.Nesting.MaterialFactor >= 2.20 ? RiskLevel.Medium : RiskLevel.Low,
                Title = "Wysoki współczynnik materiału z nestingu szacunkowego",
                Message = $"Nesting prostokątnych obwiedni STEP daje zakup/netto ×{result.Nesting.MaterialFactor:0.##} ({result.Nesting.UtilizationPercent:0.#}% wykorzystania). To nie jest nesting CAM; przy tak skrajnym wyniku nie ma prawa podbijać ceny materiału — do kosztu użyto bezpiecznego naddatku zakładowego, a nesting pozostaje tylko diagnostyką.",
                Blocking = false
            });
        }
        result.PurchasedParts = PurchasedPartPricingEngine.Estimate(result.Drawing, settings);
        result.PurchasedPartsCostPln = result.PurchasedParts.Sum(x => x.TotalPricePln);
        result.QualityCosts = QualityCostEngine.Estimate(result, settings);
        result.QualityCostPln = result.QualityCosts.Sum(x => x.CostPln);
        result.ExternalCostPln += result.QualityCostPln;
        result.ConfidencePercent = CalculateConfidence(result);
        result.ReadinessPercent = CalculateReadiness(result);

        result.MaterialCostPln = BuildMaterialCost(result, settings);
        result.RecognizedPartialMaterialCostPln = BuildRecognizedPartialMaterialCost(result, settings);

        result.TechnologyMaterialCostPln =
            result.Welding.ConsumableCostPln +
            result.Painting.PaintMaterialCostPln;

        // FIX16: detect explicit sheet-forming requirements conservatively. Until
        // bend count/radii and a workstation rate are known, the operation stays
        // visible and unpriced instead of being silently omitted from the offer.
        SheetMetalReadinessEngine.Apply(result);

        // FIX15: physical process model is frozen first; calibration is a separate,
        // versioned data layer loaded from calibration.json. Neutral factors do nothing.
        CalibrationLayer.Apply(result, settings);
        PriceFreshnessEngine.Apply(result, settings);

        result.ProcessCostPln = result.Processes.Where(x => x.Enabled).Sum(x => x.CostPln);
        result.CostTotalPln =
            result.MaterialCostPln +
            result.PurchasedPartsCostPln +
            result.TechnologyMaterialCostPln +
            result.ProcessCostPln +
            result.ExternalCostPln;

        result.TechnicalPricePln =
            result.CostTotalPln * (1.0 + settings.MarkupPercent / 100.0);

        result.FinalPricePln = result.TechnicalPricePln;

        result.CostLines =
        [
            new()
            {
                Name = "Materiał",
                AmountPln = result.MaterialCostPln,
                Confidence = result.Nesting.Available && result.Nesting.UsedForMaterialCost ? result.Nesting.Confidence : (result.Material == "Nie rozpoznano" ? 58 : 92),
                Basis = BuildMaterialBasis(result, settings)
            },
            .. (result.PurchasedPartsCostPln > 0 ? new[]
            {
                new CostLine
                {
                    Name = "Części kupne",
                    AmountPln = result.PurchasedPartsCostPln,
                    Confidence = result.PurchasedParts.Count > 0 ? (int)Math.Round(result.PurchasedParts.Average(x => x.Confidence)) : 40,
                    Basis = $"{result.PurchasedParts.Count} pozycji BOM dopasowanych do lokalnego cennika."
                }
            } : Array.Empty<CostLine>()),
            new()
            {
                Name = "Materiały technologiczne",
                AmountPln = result.TechnologyMaterialCostPln,
                Confidence = Math.Min(result.Welding.Enabled ? result.Welding.Confidence : 100, result.Painting.Enabled ? result.Painting.Confidence : 100),
                Basis = $"Spoiwa: {result.Welding.ConsumableCostPln:0.##} PLN; farby: {result.Painting.PaintMaterialCostPln:0.##} PLN."
            },
            .. result.Processes
                .Where(x => x.Enabled)
                .Select(x => new CostLine
                {
                    Name = string.IsNullOrWhiteSpace(x.WorkstationName) ? x.Name : $"{x.Name} — {x.WorkstationName}",
                    AmountPln = x.CostPln,
                    Confidence = x.Confidence,
                    Basis = x.Basis
                }),
            .. (result.QualityCostPln > 0 ? new[]
            {
                new CostLine
                {
                    Name = "Jakość / badania",
                    AmountPln = result.QualityCostPln,
                    Confidence = result.QualityCosts.Count > 0 ? (int)Math.Round(result.QualityCosts.Average(x => x.Confidence)) : 40,
                    Basis = string.Join("; ", result.QualityCosts.Select(x => $"{x.Name}: {x.CostPln:0} PLN"))
                }
            } : Array.Empty<CostLine>()),
            new()
            {
                Name = "Usługi zewnętrzne pozostałe",
                AmountPln = Math.Max(0, result.ExternalCostPln - result.QualityCostPln),
                Confidence = result.ExternalCostPln > result.QualityCostPln ? 45 : 90,
                Basis = "Pozycje zewnętrzne inne niż automatycznie wycenione wymagania jakościowe."
            }
        ];

        result.CostConfidence = CostConfidenceEngine.Build(result);
        SanityCheckEngine.Apply(result);

        AutoQuoteEngine.Apply(result);
        return result;
    }

    public void ApplyManualProcessEdits(
        AnalysisResult result,
        IEnumerable<ProcessEstimate> editedProcesses,
        CostingSettings settings)
    {
        var edited = editedProcesses.Select(x => new ProcessEstimate
        {
            Code = x.Code,
            Name = x.Name,
            Enabled = x.Enabled,
            ManualOverride = x.ManualOverride,
            AutomaticEnabled = x.AutomaticEnabled,
            AutomaticHours = x.AutomaticHours,
            AutomaticRatePlnPerHour = x.AutomaticRatePlnPerHour,
            Hours = Math.Clamp(HoursWithoutExternalCalibration(x), 0, 100000),
            RatePlnPerHour = Math.Clamp(double.IsFinite(x.RatePlnPerHour) ? x.RatePlnPerHour : 0, 0, 100000),
            BaseHours = x.BaseHours,
            CalibrationFactor = x.CalibrationFactor,
            WorkstationCode = x.WorkstationCode,
            WorkstationName = x.WorkstationName,
            Confidence = Math.Clamp(x.Confidence, 1, 99),
            Basis = x.ManualOverride && !x.Basis.Contains("Korekta ręczna procesu przez użytkownika", StringComparison.OrdinalIgnoreCase)
                ? x.Basis + " Korekta ręczna procesu przez użytkownika."
                : x.Basis
        }).ToList();

        result.Processes = edited;
        var requestedSurface = edited.Any(x => x.Enabled && string.Equals(x.Code, "SURF", StringComparison.OrdinalIgnoreCase));
        // 1.1 incremental recalculation: enabling painting never re-runs STEP/PDF/DXF.
        // Rebuild only the paint model from already cached geometry; when documentation
        // did not require paint, use the editable default coating assumptions explicitly.
        if (requestedSurface && !result.Painting.CoatingRequired)
        {
            result.Painting = BuildPaintEstimate(result, settings, forceCoating: true);
            var surf = edited.FirstOrDefault(x => string.Equals(x.Code, "SURF", StringComparison.OrdinalIgnoreCase));
            if (surf is not null)
            {
                surf.Hours = Math.Max(0.35, result.Painting.TotalHours);
                surf.BaseHours = surf.Hours;
                surf.Confidence = Math.Max(surf.Confidence, result.Painting.Confidence);
                surf.Basis = result.Painting.Basis + " Wymuszone ręcznie; przeliczono tylko model malowania z cache geometrii.";
            }
        }
        var weldEnabled = edited.Any(x => x.Enabled && string.Equals(x.Code, "WELD", StringComparison.OrdinalIgnoreCase));
        var surfaceEnabled = edited.Any(x => x.Enabled && string.Equals(x.Code, "SURF", StringComparison.OrdinalIgnoreCase));
        result.Welding.Enabled = weldEnabled;
        result.Painting.Enabled = surfaceEnabled;
        result.TechnologyMaterialCostPln =
            (weldEnabled ? result.Welding.ConsumableCostPln : 0) +
            (surfaceEnabled ? result.Painting.PaintMaterialCostPln : 0);

        CalibrationLayer.Apply(result, settings);
        PriceFreshnessEngine.Apply(result, settings);

        result.Drawing.Findings.RemoveAll(x => x.StartsWith("Ręczna korekta procesów:", StringComparison.OrdinalIgnoreCase));
        var manualCount = edited.Count(x => x.ManualOverride);
        if (manualCount > 0)
            result.Drawing.Findings.Add($"Ręczna korekta procesów: {manualCount} oper. ma trwały override ON/OFF/czas/stawka; geometria i dokumentacja pozostały bez zmian.");
        RecalculateFinancials(result, settings);
    }

    private static double HoursWithoutExternalCalibration(ProcessEstimate process)
    {
        var hours = !process.ManualOverride &&
                    Math.Abs(process.ExternalCalibrationFactor - 1.0) > 0.000001 &&
                    process.ModelHoursBeforeExternalCalibration >= 0
            ? process.ModelHoursBeforeExternalCalibration
            : process.Hours;
        return double.IsFinite(hours) ? hours : 0;
    }

    public void PrepareForHistoricalCalibration(AnalysisResult result, CostingSettings settings)
    {
        CalibrationLayer.Reset(result);
        RecalculateFinancials(result, settings);
    }

    public void FinalizeExternalCalibration(AnalysisResult result, CostingSettings settings)
    {
        CalibrationLayer.Apply(result, settings);
        PriceFreshnessEngine.Apply(result, settings);
        RecalculateFinancials(result, settings);
    }

    public void ApplyProductionCalibration(
        AnalysisResult result,
        IReadOnlyList<QuoteProject> history,
        CostingSettings settings)
    {
        result.CalibrationFactors = [];
        if (!settings.AutoCalibrationEnabled)
            return;

        var minSamples = Math.Max(1, settings.AutoCalibrationMinSamples);
        var minFactor = Math.Clamp(settings.AutoCalibrationMinFactor, 0.25, 2.0);
        var maxFactor = Math.Clamp(settings.AutoCalibrationMaxFactor, minFactor, 3.0);
        var projectClass = result.ProjectClass?.Code ?? "";

        foreach (var current in result.Processes.Where(x => x.Enabled))
        {
            // Prefer the persisted company profile produced by historical import. This keeps
            // normal quoting fast and avoids recomputing hundreds of historical ratios each time.
            if (settings.AutoCompanyProfileEnabled && settings.CompanyProcessFactors is { Count: > 0 })
            {
                var profiles = settings.CompanyProcessFactors
                    .Where(x => x.Samples >= minSamples)
                    .Where(x => string.Equals(x.ProcessCode, current.Code, StringComparison.OrdinalIgnoreCase) ||
                                (string.Equals(current.Code, "CNC", StringComparison.OrdinalIgnoreCase) &&
                                 string.Equals(x.ProcessCode, current.WorkstationCode, StringComparison.OrdinalIgnoreCase)))
                    .Where(x => string.IsNullOrWhiteSpace(x.WorkstationCode) ||
                                string.Equals(x.WorkstationCode, current.WorkstationCode, StringComparison.OrdinalIgnoreCase))
                    .Where(x => string.IsNullOrWhiteSpace(x.ProjectClass) ||
                                string.Equals(x.ProjectClass, projectClass, StringComparison.OrdinalIgnoreCase))
                    .OrderByDescending(x => string.Equals(x.ProjectClass, projectClass, StringComparison.OrdinalIgnoreCase))
                    .ThenByDescending(x => !string.IsNullOrWhiteSpace(x.WorkstationCode))
                    .ThenByDescending(x => x.Samples)
                    .ToList();
                var learned = profiles.FirstOrDefault();
                if (learned is not null)
                {
                    var learnedFactor = Math.Clamp(learned.Factor, minFactor, maxFactor);
                    current.BaseHours = current.BaseHours > 0 ? current.BaseHours : current.Hours;
                    current.CalibrationFactor = learnedFactor;
                    current.Hours = Round(current.BaseHours * learnedFactor);
                    current.Basis += $" Profil firmy: ×{learnedFactor:0.###} ({learned.Samples} próbek" +
                                     (string.IsNullOrWhiteSpace(learned.ProjectClass) ? "" : $", klasa {learned.ProjectClass}") + ").";
                    result.CalibrationFactors.Add(new CalibrationFactorInfo
                    {
                        ProcessCode = current.Code,
                        ProcessName = current.Name,
                        Samples = learned.Samples,
                        Factor = learnedFactor,
                        Basis = learned.Basis
                    });
                    continue;
                }
            }
            var ratios = new List<double>();
            var genericCncRatios = new List<double>();
            foreach (var old in history)
            {
                if (old.Actuals is null || !old.Actuals.HasAny || old.Analysis is null)
                    continue;

                var plannedProcess = old.Analysis.Processes.FirstOrDefault(x => x.Code == current.Code && x.Enabled);
                if (plannedProcess is null)
                    continue;

                var planned = plannedProcess.BaseHours > 0
                    ? plannedProcess.BaseHours
                    : plannedProcess.Hours;
                if (planned <= 0.05)
                    continue;

                var actual = old.Actuals.GetHours(current.Code);
                if (actual > 0)
                {
                    var genericRatio = actual / planned;
                    if (genericRatio is >= 0.25 and <= 4.0)
                        genericCncRatios.Add(genericRatio);
                }

                if (string.Equals(current.Code, "CNC", StringComparison.OrdinalIgnoreCase) &&
                    old.HistoryImport is not null &&
                    TryGetCncClassHours(old.HistoryImport, current.WorkstationCode, out var classActual, out var classPlanned))
                {
                    var classRatio = classActual / classPlanned;
                    if (classRatio is >= 0.25 and <= 4.0)
                        ratios.Add(classRatio);
                    continue;
                }

                if (!string.Equals(current.Code, "CNC", StringComparison.OrdinalIgnoreCase) && actual > 0)
                {
                    var ratio = actual / planned;
                    if (ratio is >= 0.25 and <= 4.0)
                        ratios.Add(ratio);
                }
            }

            if (string.Equals(current.Code, "CNC", StringComparison.OrdinalIgnoreCase) && ratios.Count < minSamples)
                ratios = genericCncRatios;

            if (ratios.Count < minSamples)
                continue;

            ratios.Sort();
            var factor = Math.Clamp(Median(ratios), minFactor, maxFactor);
            current.BaseHours = current.BaseHours > 0 ? current.BaseHours : current.Hours;
            current.CalibrationFactor = factor;
            current.Hours = Round(current.BaseHours * factor);
            current.Basis += $" Kalibracja plan/wykonanie: ×{factor:0.###} na podstawie {ratios.Count} zakończonych projektów.";

            result.CalibrationFactors.Add(new CalibrationFactorInfo
            {
                ProcessCode = current.Code,
                ProcessName = current.Name,
                Samples = ratios.Count,
                Factor = factor,
                Basis = $"Mediana rzeczywiste/planowane, ograniczona do {minFactor:0.##}–{maxFactor:0.##}."
            });
        }

        if (result.CalibrationFactors.Count > 0)
            RecalculateFinancials(result, settings);
    }


    /// <summary>
    /// FIX13 Historical Calibration Engine.  The persisted company profile remains
    /// the broad prior; this pass adds a local correction from the most similar
    /// completed projects. Ratios are similarity-weighted, robustly medianed and
    /// shrunk toward 1.0 so a small neighbourhood cannot overfit a quote.
    /// </summary>
    public void ApplySimilarityAwareCalibration(
        AnalysisResult result,
        IReadOnlyList<QuoteProject> history,
        IReadOnlyList<SimilarProject> similar,
        CostingSettings settings)
    {
        var summary = new HistoricalCalibrationSummary();
        result.HistoricalCalibration = summary;
        if (!settings.AutoCalibrationEnabled)
        {
            summary.Basis = "Automatyczna kalibracja plan/wykonanie jest wyłączona.";
            return;
        }

        var simById = similar
            .Where(x => x.SimilarityPercent >= 60)
            .GroupBy(x => x.ProjectId)
            .ToDictionary(g => g.Key, g => g.OrderByDescending(x => x.SimilarityPercent).First());

        var neighbors = history
            .Where(x => x.Analysis is not null && x.Actuals is not null && x.Actuals.HasAny && simById.ContainsKey(x.Id))
            .OrderByDescending(x => simById[x.Id].SimilarityPercent)
            .Take(12)
            .ToList();

        summary.NeighborCount = neighbors.Count;
        if (neighbors.Count < 2)
        {
            summary.Basis = neighbors.Count == 0
                ? "Brak zakończonych podobnych projektów z wykonaniem."
                : "Tylko jeden podobny projekt z wykonaniem — za mało do lokalnej korekty.";
            return;
        }

        static double SimilarityWeight(double similarity)
        {
            var normalized = Math.Clamp((similarity - 55.0) / 45.0, 0.08, 1.0);
            return normalized * normalized;
        }

        double? HistoricalActual(QuoteProject old, string code)
        {
            if (old.Actuals is null) return null;
            if (string.Equals(code, "CNC_MANUAL", StringComparison.OrdinalIgnoreCase) &&
                old.Actuals.SskHours.TryGetValue("3205", out var cncManual) && cncManual > 0)
                return cncManual;
            if (string.Equals(code, "PREP_MANUAL", StringComparison.OrdinalIgnoreCase) &&
                old.Actuals.SskHours.TryGetValue("3302", out var prepManual) && prepManual > 0)
                return prepManual;
            if (string.Equals(code, "PREP_MACHINE", StringComparison.OrdinalIgnoreCase) &&
                old.Actuals.SskHours.TryGetValue("3303", out var prepMachine) && prepMachine > 0)
                return prepMachine;
            if (string.Equals(code, "SURF", StringComparison.OrdinalIgnoreCase) &&
                old.Actuals.SskHours.TryGetValue("3402", out var surf) && surf > 0)
                return surf;
            var generic = old.Actuals.GetHours(code);
            return generic > 0 ? generic : null;
        }

        var adjustedCodes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        // 3401 is historically one combined bucket.  Learn it as one signal and
        // apply the same factor to WELD + ASSY instead of learning a self-created split.
        var currentWeld = result.Processes.FirstOrDefault(x => x.Enabled && !x.ManualOverride && x.Code == "WELD");
        var currentAssy = result.Processes.FirstOrDefault(x => x.Enabled && !x.ManualOverride && x.Code == "ASSY");
        if (currentWeld is not null && currentAssy is not null)
        {
            var samples = new List<(double Ratio, double Weight, double Similarity)>();
            foreach (var old in neighbors)
            {
                var oldWeld = old.Analysis!.Processes.FirstOrDefault(x => x.Enabled && x.Code == "WELD");
                var oldAssy = old.Analysis.Processes.FirstOrDefault(x => x.Enabled && x.Code == "ASSY");
                if (oldWeld is null || oldAssy is null) continue;
                var planned = (oldWeld.BaseHours > 0 ? oldWeld.BaseHours : oldWeld.Hours) +
                              (oldAssy.BaseHours > 0 ? oldAssy.BaseHours : oldAssy.Hours);
                if (planned <= 0.1) continue;
                var actual = old.Actuals.SskHours.TryGetValue("3401", out var ssk3401) && ssk3401 > 0
                    ? ssk3401
                    : old.Actuals.WeldingHours + old.Actuals.AssemblyHours;
                if (actual <= 0) continue;
                var ratio = actual / planned;
                if (ratio is < 0.25 or > 4.0) continue;
                var sim = simById[old.Id].SimilarityPercent;
                samples.Add((ratio, SimilarityWeight(sim), sim));
            }
            if (samples.Count >= 2)
            {
                var raw = WeightedMedian(samples.Select(x => (x.Ratio, x.Weight)).ToList());
                var avgSim = samples.Average(x => x.Similarity);
                var trust = Math.Clamp(0.20 + avgSim / 100.0 * 0.48 + Math.Min(0.18, samples.Count * 0.035), 0.35, 0.86);
                var factor = Math.Clamp(1.0 + (raw - 1.0) * trust, settings.AutoCalibrationMinFactor, settings.AutoCalibrationMaxFactor);
                foreach (var process in new[] { currentWeld, currentAssy })
                {
                    var before = process.Hours;
                    process.BaseHours = process.BaseHours > 0 ? process.BaseHours : process.Hours;
                    process.CalibrationFactor = factor;
                    process.Hours = Round(process.BaseHours * factor);
                    process.Basis += $" FIX13 podobne realizacje: 3401 ×{factor:0.###} ({samples.Count} projektów, podobieństwo śr. {avgSim:0}%).";
                    summary.ProcessAdjustments.Add(new HistoricalProcessAdjustment
                    {
                        ProcessCode = process.Code,
                        ProcessName = process.Name,
                        Samples = samples.Count,
                        RawFactor = raw,
                        AppliedFactor = factor,
                        BeforeHours = before,
                        AfterHours = process.Hours,
                        AverageSimilarityPercent = avgSim,
                        Confidence = (int)Math.Round(Math.Clamp(45 + avgSim * 0.35 + samples.Count * 3, 50, 94)),
                        Basis = "SSK 3401 uczone łącznie; ten sam współczynnik dla WELD/ASSY, bez uczenia podziału stworzonego przez model."
                    });
                    adjustedCodes.Add(process.Code);
                }
            }
        }

        foreach (var current in result.Processes.Where(x => x.Enabled && !x.ManualOverride && !adjustedCodes.Contains(x.Code)))
        {
            var samples = new List<(double Ratio, double Weight, double Similarity)>();
            foreach (var old in neighbors)
            {
                var oldProcess = old.Analysis!.Processes.FirstOrDefault(x =>
                    x.Enabled && string.Equals(x.Code, current.Code, StringComparison.OrdinalIgnoreCase));
                if (oldProcess is null) continue;
                var planned = oldProcess.BaseHours > 0 ? oldProcess.BaseHours : oldProcess.Hours;
                if (planned <= 0.05) continue;
                var actual = HistoricalActual(old, current.Code);
                if (actual is not > 0) continue;
                var ratio = actual.Value / planned;
                if (ratio is < 0.25 or > 4.0) continue;
                var sim = simById[old.Id].SimilarityPercent;
                samples.Add((ratio, SimilarityWeight(sim), sim));
            }

            if (samples.Count < 2)
                continue;

            var raw = WeightedMedian(samples.Select(x => (x.Ratio, x.Weight)).ToList());
            var avgSimilarity = samples.Average(x => x.Similarity);
            var trust = Math.Clamp(0.18 + avgSimilarity / 100.0 * 0.48 + Math.Min(0.20, samples.Count * 0.04), 0.32, 0.86);
            var factor = Math.Clamp(
                1.0 + (raw - 1.0) * trust,
                Math.Max(0.25, settings.AutoCalibrationMinFactor),
                Math.Max(settings.AutoCalibrationMinFactor, settings.AutoCalibrationMaxFactor));

            var beforeHours = current.Hours;
            current.BaseHours = current.BaseHours > 0 ? current.BaseHours : current.Hours;
            current.CalibrationFactor = factor;
            current.Hours = Round(current.BaseHours * factor);
            current.Basis += $" FIX13 podobne realizacje: ×{factor:0.###} ({samples.Count} projektów, podobieństwo śr. {avgSimilarity:0}%).";
            summary.ProcessAdjustments.Add(new HistoricalProcessAdjustment
            {
                ProcessCode = current.Code,
                ProcessName = current.Name,
                Samples = samples.Count,
                RawFactor = raw,
                AppliedFactor = factor,
                BeforeHours = beforeHours,
                AfterHours = current.Hours,
                AverageSimilarityPercent = avgSimilarity,
                Confidence = (int)Math.Round(Math.Clamp(42 + avgSimilarity * 0.38 + samples.Count * 3, 48, 94)),
                Basis = "Ważona mediana wykonanie/model dla najbliższych projektów; współczynnik skurczony w stronę 1,0."
            });
        }

        summary.Applied = summary.ProcessAdjustments.Count > 0;
        summary.Confidence = summary.ProcessAdjustments.Count == 0
            ? 0
            : (int)Math.Round(summary.ProcessAdjustments.Average(x => x.Confidence));
        summary.Basis = summary.Applied
            ? $"FIX13 Historical Calibration: {neighbors.Count} sąsiadów, {summary.ProcessAdjustments.Select(x => x.ProcessCode).Distinct(StringComparer.OrdinalIgnoreCase).Count()} procesów skorygowanych; kalibracja lokalna ma pierwszeństwo przed szerokim profilem firmy, ale nie nad ręcznym override."
            : $"Znaleziono {neighbors.Count} podobnych realizacji, lecz brak co najmniej 2 wiarygodnych próbek dla aktywnych procesów.";

        var externalHints = neighbors
            .Where(x => x.Analysis!.ExternalCostPln > 0)
            .Select(x => (Value: x.Analysis!.ExternalCostPln, Weight: SimilarityWeight(simById[x.Id].SimilarityPercent)))
            .ToList();
        if (externalHints.Count >= 2)
            summary.ExternalCostHintPln = WeightedMedian(externalHints);

        if (summary.Applied)
            RecalculateFinancials(result, settings);
    }

    private static bool TryGetCncClassHours(HistoryImportMetadata history, string stationCode, out double actual, out double planned)
    {
        actual = 0;
        planned = 0;
        switch ((stationCode ?? "").ToUpperInvariant())
        {
            case "CNC_SMALL":
                actual = history.CncLightHours;
                planned = history.ModelCncSmallHours;
                break;
            case "CNC_MEDIUM":
                actual = history.CncMediumHours;
                planned = history.ModelCncMediumHours;
                break;
            case "CNC_LARGE":
                actual = history.CncHeavyHours;
                planned = history.ModelCncLargeHours;
                break;
            default:
                return false;
        }
        return actual > 0 && planned > 0.05;
    }

    public void ApplyHistory(
        AnalysisResult result,
        IReadOnlyList<SimilarProject> similar,
        CostingSettings settings)
    {
        result.SimilarProjects = similar.ToList();

        var useful = similar
            .Where(x => x.SimilarityPercent >= 62 && x.FinalPricePln > 0)
            .OrderByDescending(x => x.SimilarityPercent)
            .Take(7)
            .ToList();

        if (useful.Count < 2)
        {
            result.HistoricalPricePln = null;
            result.HistoricalCalibration.PriceNeighborCount = useful.Count;
            result.FinalPricePln = result.TechnicalPricePln;
            AutoQuoteEngine.Apply(result);
            return;
        }

        static double PriceWeight(double similarity)
        {
            var x = Math.Clamp((similarity - 55.0) / 45.0, 0.08, 1.0);
            return x * x;
        }

        double historical;
        List<(double Value, double Weight)> perKg = result.WeightKg.HasValue
            ? useful
                .Where(x => x.WeightKg is > 0)
                .Select(x => (
                    Value: x.FinalPricePln / x.WeightKg!.Value,
                    Weight: PriceWeight(x.SimilarityPercent)))
                .ToList()
            : [];

        if (result.WeightKg.HasValue && perKg.Count >= 2)
            historical = WeightedMedian(perKg) * result.WeightKg.Value;
        else
            historical = WeightedMedian(useful
                .Select(x => (Value: x.FinalPricePln, Weight: PriceWeight(x.SimilarityPercent)))
                .ToList());

        result.HistoricalPricePln = historical;
        result.HistoricalCalibration.PriceNeighborCount = useful.Count;
        result.HistoricalCalibration.WeightedHistoricalPricePln = historical;
        if (result.HistoricalCalibration.Confidence <= 0)
            result.HistoricalCalibration.Confidence = (int)Math.Round(useful.Average(x => x.SimilarityPercent));
        result.HistoricalCalibration.Basis = string.IsNullOrWhiteSpace(result.HistoricalCalibration.Basis)
            ? $"FIX13: historyczna referencja ceny z {useful.Count} podobnych projektów, ważona podobieństwem."
            : result.HistoricalCalibration.Basis + $" Referencja ceny: {useful.Count} projektów, ważona podobieństwem.";

        var histShare = Math.Clamp(settings.HistoricalBlendPercent / 100.0, 0, 0.50);
        result.FinalPricePln =
            result.TechnicalPricePln * (1 - histShare) +
            historical * histShare;

        AutoQuoteEngine.Apply(result);
    }

    private static void ApplyPartMasses(AnalysisResult result)
    {
        foreach (var part in result.Geometry.Parts)
            part.MassKgEach = part.VolumeMm3Each * 1e-9 * result.DensityKgM3;
    }


    private static WeldEstimate BuildWeldEstimate(
        AnalysisResult result,
        CostingSettings s)
    {
        var drawing = result.Drawing;
        var geometry = result.Geometry;

        var weldKeyword = HasKeyword(drawing, "WELD", "SPAW", "ISO 5817");
        var structuredWeldSignal =
            !string.IsNullOrWhiteSpace(drawing.WeldTypeHint) ||
            !string.IsNullOrWhiteSpace(drawing.WeldProcessCode) ||
            drawing.WeldSizeMm.HasValue;
        var rawGeometricLengthM = geometry.WeldCandidateLengthMm / 1000.0;
        var geometryCandidate =
            geometry.WeldCandidatePairs > 0 &&
            rawGeometricLengthM >= 0.04;
        var explicitDrawingLengthM = drawing.WeldExplicitLengthMm is > 0
            ? drawing.WeldExplicitLengthMm.Value / 1000.0
            : (double?)null;

        var geometricLengthM = rawGeometricLengthM;
        var allAroundLengthEstimated = false;
        if (drawing.WeldAllAround && geometryCandidate)
        {
            // Joint Engine reports a conservative base weld length. For an explicit
            // all-around symbol, infer an approximate contact perimeter from the
            // measured contact patch A and its base length L: P ~= 2*(L + A/L).
            // This is exact for a rectangular patch and remains conservative for
            // many rib/plate contacts; the estimate is always marked as such.
            var allAroundMm = geometry.JointCandidates
                .Where(x => x.StructuralCandidate && !x.PossibleBoltedJoint && x.CandidateWeldLengthMm > 1)
                .Sum(x =>
                {
                    var length = x.CandidateWeldLengthMm;
                    var width = x.ContactAreaMm2 > 0
                        ? Math.Clamp(x.ContactAreaMm2 / length, 0.0, length * 2.0)
                        : 0.0;
                    return 2.0 * (length + width);
                });

            if (allAroundMm > geometry.WeldCandidateLengthMm * 1.05)
            {
                geometricLengthM = allAroundMm / 1000.0;
                allAroundLengthEstimated = true;
            }
        }

        var enabled = weldKeyword || structuredWeldSignal || geometryCandidate || explicitDrawingLengthM is > 0;

        if (explicitDrawingLengthM is > 0 && geometryCandidate)
        {
            var delta = Math.Abs(explicitDrawingLengthM.Value - geometricLengthM) /
                        Math.Max(explicitDrawingLengthM.Value, 0.001);
            if (delta > 0.15)
            {
                result.Drawing.Findings.Add(
                    $"Cross-check spoin DS 1.0: rysunek podaje łącznie {explicitDrawingLengthM.Value:0.###} m, " +
                    $"a STEP wskazuje ok. {geometricLengthM:0.###} m kandydackich krawędzi. Do kosztu przyjęto jawną długość z rysunku.");
            }
        }

        var sizeKind = string.IsNullOrWhiteSpace(drawing.WeldSizeKind)
            ? "a"
            : drawing.WeldSizeKind.ToLowerInvariant();

        var sizeInput = drawing.WeldSizeMm ?? s.DefaultWeldSizeAmm;
        var sizeAssumed = !drawing.WeldSizeMm.HasValue;

        // Convert leg-size z to throat-size a for fillet weld metal area.
        var throatA = sizeKind == "z"
            ? sizeInput / Math.Sqrt(2.0)
            : sizeInput;

        throatA = Math.Clamp(throatA, 1.0, 30.0);

        var process = string.IsNullOrWhiteSpace(drawing.WeldProcessCode)
            ? s.DefaultWeldProcessCode
            : drawing.WeldProcessCode;

        if (process != "111" && process != "135" && process != "136")
            process = s.DefaultWeldProcessCode;

        if (process != "111" && process != "135" && process != "136")
            process = "135";

        var processAssumed = string.IsNullOrWhiteSpace(drawing.WeldProcessCode);

        var sideCount = drawing.WeldSideCount > 0
            ? Math.Clamp(drawing.WeldSideCount, 1, 2)
            : 1;

        // A drawing field explicitly labelled TOTAL weld length already expresses
        // the manufactured total, therefore it must not be multiplied by the side
        // count again.  Side count remains a useful audit signal and is applied only
        // to geometry-derived base length.
        var effectiveLengthM = explicitDrawingLengthM is > 0
            ? explicitDrawingLengthM.Value
            : geometricLengthM * sideCount;

        // Intermittent welds are reduced only when both weld-segment length and
        // pitch are explicitly confirmed in the documentation. Otherwise keep 1.0.
        var intermittencyFactor = drawing.WeldIntermittencyConfirmed &&
                                  drawing.WeldIntermittentLengthMm.HasValue &&
                                  drawing.WeldPitchMm.HasValue &&
                                  drawing.WeldPitchMm.Value >= drawing.WeldIntermittentLengthMm.Value &&
                                  drawing.WeldPitchMm.Value > 0
            ? Math.Clamp(drawing.WeldIntermittentLengthMm.Value / drawing.WeldPitchMm.Value, 0.05, 1.0)
            : 1.0;

        // Equal-leg 45° fillet: cross-section = a². For an explicitly documented
        // groove weld use a geometric V-groove approximation instead of silently
        // treating it as a fillet. Plate thickness is inferred from STEP bbox only
        // when it is available and plausible.
        var crossSectionMm2 = throatA * throatA;
        var grooveGeometryUsed = false;
        var grooveThicknessMm = 0.0;
        if (drawing.WeldTypeHint == "GROOVE" && drawing.WeldGrooveAngleDeg.HasValue)
        {
            var thicknesses = geometry.Parts
                .Where(x => x.Classification.Contains("Blacha", StringComparison.OrdinalIgnoreCase) ||
                            x.Classification.Contains("Płyta", StringComparison.OrdinalIgnoreCase))
                .Select(x => new[] { x.Xmm, x.Ymm, x.Zmm }.Where(v => v > 0.5).DefaultIfEmpty(0).Min())
                .Where(x => x >= 2 && x <= 200)
                .OrderBy(x => x)
                .ToList();
            grooveThicknessMm = thicknesses.Count > 0 ? thicknesses[thicknesses.Count / 2] : 0;
            if (grooveThicknessMm > 0)
            {
                var angleRad = Math.Clamp(drawing.WeldGrooveAngleDeg.Value, 20, 160) * Math.PI / 180.0;
                var rootGap = Math.Clamp(drawing.WeldRootGapMm ?? 0, 0, 20);
                // Symmetric V groove without a documented root face: triangular groove + root opening.
                var grooveArea = grooveThicknessMm * grooveThicknessMm * Math.Tan(angleRad / 2.0) +
                                 rootGap * grooveThicknessMm;
                if (grooveArea > 0 && double.IsFinite(grooveArea))
                {
                    crossSectionMm2 = Math.Clamp(grooveArea, 1, 10000);
                    grooveGeometryUsed = true;
                }
            }
        }

        // kg/m = area[mm²] * 1000 mm * density[kg/mm³]
        var densityKgMm3 = s.WeldSteelDensityKgM3 * 1e-9;
        var massPerMeterKg = crossSectionMm2 * 1000.0 * densityKgMm3;
        var weldMetalMassKg = massPerMeterKg * effectiveLengthM * intermittencyFactor;

        var efficiency = Math.Clamp(s.WeldConsumableEfficiencyPercent / 100.0, 0.25, 1.0);
        var fillerKg = weldMetalMassKg / efficiency;

        var depositionRate = process switch
        {
            "111" => s.WeldDepositionRate111KgH,
            "136" => s.WeldDepositionRate136KgH,
            _ => s.WeldDepositionRate135KgH,
        };
        depositionRate = Math.Max(0.1, depositionRate);

        var arcHours = weldMetalMassKg / depositionRate;

        // FIX13: when multiple drawing families provide their own explicit weld
        // length and a/z size, calculate weld metal and arc time per family.  This
        // prevents a single a13 callout from inflating all a3/a4 welds in the project.
        var familyBreakdown = new List<WeldFamilyEstimate>();
        foreach (var family in drawing.WeldFamilySignals
                     .Where(x => x.ExplicitLengthMm is > 0 && x.SizeMm is > 0 && x.Quantity > 0))
        {
            var familyLengthM = family.ExplicitLengthMm!.Value / 1000.0 * Math.Max(1, family.Quantity);
            if (familyLengthM <= 0) continue;
            var familyKind = string.IsNullOrWhiteSpace(family.SizeKind) ? "a" : family.SizeKind.Trim().ToLowerInvariant();
            var familyA = familyKind == "z" ? family.SizeMm!.Value / Math.Sqrt(2.0) : family.SizeMm!.Value;
            familyA = Math.Clamp(familyA, 1.0, 30.0);
            var familyArea = familyA * familyA;
            var familyMass = familyArea * 1000.0 * densityKgMm3 * familyLengthM;
            var familyProcess = family.ProcessCode is "111" or "135" or "136" ? family.ProcessCode : process;
            var familyDeposition = familyProcess switch
            {
                "111" => Math.Max(0.1, s.WeldDepositionRate111KgH),
                "136" => Math.Max(0.1, s.WeldDepositionRate136KgH),
                _ => Math.Max(0.1, s.WeldDepositionRate135KgH)
            };
            familyBreakdown.Add(new WeldFamilyEstimate
            {
                FamilyKey = family.FamilyKey,
                ProcessCode = familyProcess,
                SizeKind = familyKind,
                SizeMm = family.SizeMm.Value,
                LengthM = familyLengthM,
                Quantity = family.Quantity,
                WeldMetalMassKg = familyMass,
                ArcHours = familyMass / familyDeposition,
                Confidence = family.Confidence,
                Basis = family.Basis
            });
        }

        var familyScoped = familyBreakdown.Count >= 2;
        if (familyScoped)
        {
            effectiveLengthM = familyBreakdown.Sum(x => x.LengthM);
            weldMetalMassKg = familyBreakdown.Sum(x => x.WeldMetalMassKg);
            fillerKg = weldMetalMassKg / efficiency;
            arcHours = familyBreakdown.Sum(x => x.ArcHours);
            crossSectionMm2 = effectiveLengthM > 0
                ? familyBreakdown.Sum(x => x.WeldMetalMassKg / Math.Max(densityKgMm3 * 1000.0, 1e-12)) / effectiveLengthM
                : crossSectionMm2;
            throatA = Math.Sqrt(Math.Max(1.0, crossSectionMm2));
            sizeAssumed = false;
            result.Drawing.Findings.Add(
                $"FIX13 Weld Cost: koszt łuku policzono per rodzina dla {familyBreakdown.Count} profili spoin; L={effectiveLengthM:0.###} m, metal={weldMetalMassKg:0.###} kg.");
        }

        // Welding 2.0: separate arc time from fit-up and manipulation. For large welded
        // assemblies, positioning/turning is often a stronger driver than pure deposition.
        var rawFitUpHours = geometry.WeldCandidatePairs * Math.Max(0, s.WeldFitUpMinutesPerJoint) / 60.0;
        // R9.2.3C: dense contact grids can contain hundreds of tiny geometric
        // candidates along one physical weld route. Per-candidate fit-up must not
        // grow without bound. Cap joint overhead by actual weld length and the
        // number of unique component families; assembly carries the remaining
        // positioning burden.
        var jointOverheadCapHours = Math.Max(0.75, effectiveLengthM * 0.25 + geometry.UniquePartGroups * 0.02);
        var fitUpHours = Math.Min(rawFitUpHours, jointOverheadCapHours);
        var rawJointHandlingHours = geometry.WeldCandidatePairs * Math.Max(0, s.WeldHandlingMinutesPerJoint) / 60.0;
        var baseHandlingHours =
            Math.Min(rawJointHandlingHours, jointOverheadCapHours) +
            effectiveLengthM * Math.Max(0, s.WeldHandlingHoursPerMeter);
        var massKg = result.WeightKg ?? geometry.Parts.Sum(x => Math.Max(0, x.MassKgEach) * Math.Max(1, x.Quantity));
        var bboxMax = Math.Max(geometry.BoundingXmm, Math.Max(geometry.BoundingYmm, geometry.BoundingZmm));
        var repositionDrivers = Math.Max(0, geometry.WeldCandidatePairs - 1) / 6.0 +
                                (massKg >= 250 ? 1 : 0) +
                                (massKg >= 1500 ? 1 : 0) +
                                (bboxMax >= 2500 ? 1 : 0);
        var estimatedRepositions = enabled ? Math.Clamp((int)Math.Ceiling(repositionDrivers), 0, 12) : 0;
        var heavyMultiplier = massKg >= 1500 ? Math.Max(1.0, s.WeldRepositionHeavyMultiplier)
            : massKg >= 500 ? 1.45 : 1.0;
        var manipulationHours = estimatedRepositions * Math.Max(0, s.WeldRepositionMinutesBase) * heavyMultiplier / 60.0;
        var handlingHours = fitUpHours + baseHandlingHours + manipulationHours;

        var totalHours = enabled
            ? Math.Max(0.35, arcHours + handlingHours)
            : 0;

        var passes = throatA <= 4.0 ? 1 : throatA <= 7.0 ? 2 : 3;

        var geomConfidence = geometry.JointCandidates
            .Where(x => x.StructuralCandidate && !x.PossibleBoltedJoint)
            .Select(x => x.Confidence)
            .DefaultIfEmpty(0)
            .Max();

        var confidence = explicitDrawingLengthM is > 0
            ? Math.Clamp(drawing.WeldExplicitLengthConfidence > 0 ? drawing.WeldExplicitLengthConfidence : 84, 70, 98)
            : (weldKeyword || structuredWeldSignal)
                ? drawing.WeldSizeMm.HasValue && !processAssumed ? 96 : 90
                : geometryCandidate ? Math.Max(62, geomConfidence) : 35;

        if (drawing.WeldTypeHint == "GROOVE")
            confidence = grooveGeometryUsed ? Math.Min(confidence, 92) : Math.Min(confidence, 78);
        if (enabled && !drawing.WeldSideCountConfirmed)
            confidence = Math.Min(confidence, 84);

        var type = drawing.WeldTypeHint switch
        {
            "FILLET" => "pachwinowa",
            "GROOVE" => "doczołowa / rowkowa",
            _ => geometry.JointCandidates.Any(x =>
                    x.StructuralCandidate &&
                    x.Type.Contains("blacha-blacha", StringComparison.OrdinalIgnoreCase))
                ? "pachwinowa / doczołowa - wymaga symbolu"
                : "pachwinowa / wnioskowana"
        };

        var source = explicitDrawingLengthM is > 0
            ? geometryCandidate ? "rysunek — jawna długość + STEP cross-check" : "rysunek — jawna długość"
            : (weldKeyword || structuredWeldSignal) && geometryCandidate
                ? "PDF/OCR + STEP"
                : (weldKeyword || structuredWeldSignal)
                    ? "PDF/OCR"
                    : geometryCandidate
                        ? "STEP"
                        : "brak potwierdzenia";

        return new WeldEstimate
        {
            Enabled = enabled,
            Type = type,
            Source = source,
            ProcessCode = process,
            SizeKind = sizeKind,
            SizeMm = sizeInput,
            SideCount = sideCount,
            SideCountConfirmed = drawing.WeldSideCountConfirmed,
            AllAround = drawing.WeldAllAround,
            AllAroundLengthEstimated = allAroundLengthEstimated,
            Intermittent = drawing.WeldIntermittent,
            IntermittencyConfirmed = drawing.WeldIntermittencyConfirmed,
            IntermittencyFactor = intermittencyFactor,
            GeometricLengthM = geometricLengthM,
            EffectiveLengthM = effectiveLengthM,
            CrossSectionMm2 = crossSectionMm2,
            WeldMetalMassKg = weldMetalMassKg,
            FillerMetalKg = fillerKg,
            NumberOfPasses = passes,
            DepositionRateKgH = depositionRate,
            ArcHours = arcHours,
            FitUpHours = fitUpHours,
            ManipulationHours = manipulationHours,
            EstimatedRepositions = estimatedRepositions,
            HandlingHours = handlingHours,
            TotalHours = totalHours,
            ConsumableCostPln = enabled ? fillerKg * s.WeldConsumablePricePlnKg : 0,
            Confidence = confidence,
            SizeAssumed = sizeAssumed,
            ProcessAssumed = processAssumed,
            FamilyScoped = familyScoped,
            FamilyBreakdown = familyBreakdown,
            Basis =
                (familyScoped
                    ? $"FIX13 family-scoped: {familyBreakdown.Count} rodzin, L={effectiveLengthM:0.###} m; "
                    : "") +
                (explicitDrawingLengthM is > 0
                    ? $"L jawna z rysunku={effectiveLengthM:0.###} m (STEP cross-check≈{geometricLengthM:0.###} m); "
                    : $"L={geometricLengthM:0.###} m × {sideCount} str." +
                      (allAroundLengthEstimated ? " (all-around: obwód styku oszacowany z A/L); " : "; ")) +
                (grooveGeometryUsed
                    ? $"rowek V: kąt {drawing.WeldGrooveAngleDeg:0.#}°, szczelina {(drawing.WeldRootGapMm ?? 0):0.##} mm, t≈{grooveThicknessMm:0.##} mm, A≈{crossSectionMm2:0.##} mm²; "
                    : $"{sizeKind}{sizeInput:0.##} (a={throatA:0.##} mm); ") +
                $"proces {process}; metal spoiny {weldMetalMassKg:0.###} kg; spoiwo {fillerKg:0.###} kg; " +
                $"depozycja {depositionRate:0.##} kg/h; dopasowanie {fitUpHours:0.###} h; " +
                $"manipulacja {manipulationHours:0.###} h / ~{estimatedRepositions} obrotów; " +
                (drawing.WeldIntermittencyConfirmed ? $"przerywana {drawing.WeldIntermittentLengthMm:0.#}/{drawing.WeldPitchMm:0.#} mm (×{intermittencyFactor:0.###})." : "")
        };
    }

    private static PaintEstimate BuildPaintEstimate(
        AnalysisResult result,
        CostingSettings s,
        bool forceCoating = false)
    {
        var drawing = result.Drawing;
        var geometry = result.Geometry;

        var prepKeyword = HasKeyword(
            drawing,
            "SHOT BLAST", "ŚRUT");

        var coatingKeyword = HasKeyword(
            drawing,
            "PAINT", "MALOW", "LACK", "BESCHICHT", "C2", "C3", "C4", "C5") ||
            drawing.Norms.Any(x => x.Contains("12944", StringComparison.OrdinalIgnoreCase));

        var prepRequired =
            prepKeyword ||
            !string.IsNullOrWhiteSpace(drawing.SurfacePreparation) ||
            drawing.Norms.Any(x => x.Contains("8501", StringComparison.OrdinalIgnoreCase));

        var explicitPaintScope = string.IsNullOrWhiteSpace(drawing.PaintScope)
            ? "AUTO"
            : drawing.PaintScope.Trim().ToUpperInvariant();
        if (explicitPaintScope is not "AUTO" and not "ALL" and not "EXTERNAL_ONLY" and not "INTERNAL_ONLY")
            explicitPaintScope = "AUTO";

        var coatingRequired =
            forceCoating ||
            coatingKeyword ||
            !string.IsNullOrWhiteSpace(drawing.CorrosionClass) ||
            !string.IsNullOrWhiteSpace(drawing.PaintColour) ||
            drawing.TotalDftMicron.HasValue ||
            explicitPaintScope != "AUTO";

        var enabled = prepRequired || coatingRequired;

        // FIX12E: a valid local STEP is not automatically a valid project-wide
        // surface.  If the root BOM contains families not represented by STEP,
        // project coating uses the per-family hybrid reconstruction instead.
        var stepCoversWholeRoot = !drawing.ResolvedFamilyScopeEnforced ||
            drawing.ResolvedRootBomFamilyCount <= 0 ||
            drawing.ResolvedStepFamilyMatchCount >= drawing.ResolvedRootBomFamilyCount;
        var projectGeometrySurfaceUsable = geometry.Available && stepCoversWholeRoot;

        var grossAreaM2 = projectGeometrySurfaceUsable ? geometry.SurfaceMm2 / 1_000_000.0 : 0;
        var hiddenM2 = projectGeometrySurfaceUsable ? geometry.HiddenMatingSurfaceMm2 / 1_000_000.0 : 0;
        var internalGeometryM2 = projectGeometrySurfaceUsable ? geometry.InternalPaintExcludedMm2 / 1_000_000.0 : 0;
        var sealedAssemblyM2 = projectGeometrySurfaceUsable ? geometry.SealedCavitySurfaceMm2 / 1_000_000.0 : 0;
        var closedM2 = internalGeometryM2 + sealedAssemblyM2;

        var defaultPaintableM2 = projectGeometrySurfaceUsable && geometry.PaintableSurfaceMm2 > 0
            ? geometry.PaintableSurfaceMm2 / 1_000_000.0
            : projectGeometrySurfaceUsable && geometry.ExposedSurfaceMm2 > 0
                ? geometry.ExposedSurfaceMm2 / 1_000_000.0
                : grossAreaM2;
        var exposedNonMatingM2 = projectGeometrySurfaceUsable && geometry.ExposedSurfaceMm2 > 0
            ? geometry.ExposedSurfaceMm2 / 1_000_000.0
            : Math.Max(0, grossAreaM2 - hiddenM2);

        var paintAreaSource = projectGeometrySurfaceUsable && geometry.SurfaceMm2 > 0 ? "STEP — pełny zakres projektu" : "brak";
        var paintAreaEstimatedFromMass = false;
        var hybridAreaUsed = false;
        if (drawing.HybridSurfaceAreaM2 is > 0 && (!projectGeometrySurfaceUsable || defaultPaintableM2 <= 0.0001))
        {
            defaultPaintableM2 = drawing.HybridSurfaceAreaM2.Value;
            exposedNonMatingM2 = drawing.HybridSurfaceAreaM2.Value;
            grossAreaM2 = drawing.HybridSurfaceAreaM2.Value;
            paintAreaSource = $"FIX12E hybrydowo — {drawing.HybridSurfaceAreaSource}; pokrycie {drawing.HybridSurfaceAreaCoveragePercent:0.#}% rodzin";
            hybridAreaUsed = true;
            paintAreaEstimatedFromMass = drawing.HybridSurfaceAreaContributions.Any(x =>
                x.SourceKind.Contains("MASS", StringComparison.OrdinalIgnoreCase));
        }
        else if (defaultPaintableM2 <= 0.0001 && drawing.DocumentSurfaceAreaM2 is > 0)
        {
            defaultPaintableM2 = drawing.DocumentSurfaceAreaM2.Value;
            exposedNonMatingM2 = drawing.DocumentSurfaceAreaM2.Value;
            grossAreaM2 = drawing.DocumentSurfaceAreaM2.Value;
            paintAreaSource = "PDF/DXF — jawnie podana powierzchnia";
        }
        else if (enabled && defaultPaintableM2 <= 0.0001 && result.Dxf.GeometryMeasurementReliable &&
                 result.Dxf.ClosedProfileAreaMm2 > 0 &&
                 result.Dxf.ClosedProfileCount > 0 && result.Dxf.OpenPathCount <= Math.Max(2, result.Dxf.ClosedProfileCount / 2))
        {
            // Flat-part fallback: two broad faces of closed DXF profiles. Edge area is
            // intentionally omitted because thickness is unknown. This is marked low
            // confidence and is not used for exploded multi-view drawings with many open paths.
            var twoSidedFlatArea = 2.0 * result.Dxf.ClosedProfileAreaMm2 / 1_000_000.0;
            defaultPaintableM2 = Math.Max(0.05, twoSidedFlatArea);
            exposedNonMatingM2 = defaultPaintableM2;
            grossAreaM2 = defaultPaintableM2;
            paintAreaSource = "DXF — 2× suma pól zamkniętych profili (bez krawędzi, niska pewność)";
        }
        else if (enabled && defaultPaintableM2 <= 0.0001 && result.WeightKg is > 0)
        {
            // Last-resort should-cost fallback. It is deliberately low-confidence:
            // a fabricated steel structure commonly spans a wide m2/kg range, but
            // returning silent 0 m2 is more damaging than a clearly flagged estimate.
            defaultPaintableM2 = Math.Max(0.5, result.WeightKg.Value * 0.025);
            exposedNonMatingM2 = defaultPaintableM2;
            grossAreaM2 = defaultPaintableM2;
            paintAreaEstimatedFromMass = true;
            paintAreaSource = "awaryjny szacunek z masy (0,025 m²/kg)";
        }

        // Geometry supplies a conservative default (external/accessible surfaces).
        // An explicit drawing note can widen/narrow the scope. Mating/faying faces
        // stay excluded unless a future dedicated requirement says otherwise.
        var paintableM2 = explicitPaintScope switch
        {
            "ALL" => exposedNonMatingM2,
            "INTERNAL_ONLY" => Math.Max(0, internalGeometryM2 + sealedAssemblyM2),
            _ => defaultPaintableM2
        };
        var internalAreaIncludedM2 = explicitPaintScope is "ALL" or "INTERNAL_ONLY"
            ? Math.Max(0, Math.Min(paintableM2, internalGeometryM2 + sealedAssemblyM2))
            : 0;
        var preAssemblyInternalAreaM2 = explicitPaintScope is "ALL" or "INTERNAL_ONLY"
            ? Math.Max(0, sealedAssemblyM2)
            : 0;
        var preAssemblyInternalPaintingRequired = preAssemblyInternalAreaM2 > 0.0001;

        // Exact paint exclusion is only applied when the documentation explicitly says
        // to mask/not paint machined surfaces. Fit/thread semantics alone are not enough
        // to silently change coating area. Cylindrical wall area is a conservative estimate.
        var maskedMachinedM2 = 0.0;
        if (drawing.PaintMaskMachinedSurfaces)
        {
            maskedMachinedM2 = geometry.Parts.Sum(part => part.Holes
                .Where(h => h.FitConfirmed || h.ReamedLikely || !string.IsNullOrWhiteSpace(h.ThreadCode))
                .Sum(h => Math.PI * Math.Max(0, h.DiameterMm) * Math.Max(0, h.DepthMm) * h.Count * Math.Max(1, part.Quantity)))
                / 1_000_000.0;
            maskedMachinedM2 = Math.Min(maskedMachinedM2, paintableM2);
            paintableM2 = Math.Max(0, paintableM2 - maskedMachinedM2);
            internalAreaIncludedM2 = Math.Min(internalAreaIncludedM2, paintableM2);
        }

        var solids = Math.Clamp(s.DefaultPaintVolumeSolidsPercent, 5, 100);
        var loss = Math.Clamp(s.PaintLossPercent, 0, 100);

        var detailedLayers = drawing.PaintLayers
            .Where(x => x.DftMicron > 0)
            .GroupBy(x => $"{NormalizePaintLayerName(x.Name)}|{x.DftMicron:0.###}|{Math.Max(1, x.CoatCount)}", StringComparer.OrdinalIgnoreCase)
            .Select(g => g.First())
            .ToList();

        // R9.2.2: repeated PDF/DXF representations of the same coating system must
        // not be stacked as additional coats.  An explicit TOTAL DFT is authoritative.
        // If detailed layers do not reconcile to that total, cost the explicit total
        // rather than silently inflating (e.g. 220 µm -> 660 µm).
        if (drawing.TotalDftMicron is > 0 && detailedLayers.Count > 0)
        {
            var total = drawing.TotalDftMicron.Value;
            var sum = detailedLayers.Sum(x => x.DftMicron * Math.Max(1, x.CoatCount));
            if (Math.Abs(sum - total) / Math.Max(total, 1) > 0.05)
            {
                var withoutTotalRows = detailedLayers
                    .Where(x => Math.Abs(x.DftMicron * Math.Max(1, x.CoatCount) - total) / Math.Max(total, 1) > 0.03)
                    .ToList();
                var reduced = withoutTotalRows.Sum(x => x.DftMicron * Math.Max(1, x.CoatCount));
                detailedLayers = withoutTotalRows.Count > 0 && Math.Abs(reduced - total) / Math.Max(total, 1) <= 0.05
                    ? withoutTotalRows
                    : [];
            }
        }

        var dft = coatingRequired
            ? drawing.TotalDftMicron ??
              (detailedLayers.Count > 0
                  ? detailedLayers.Sum(x => x.DftMicron * Math.Max(1, x.CoatCount))
                  : s.DefaultPaintDftMicron)
            : 0;

        if (coatingRequired)
            dft = Math.Clamp(dft, 10, 3000);

        var dftAssumed =
            coatingRequired &&
            !drawing.TotalDftMicron.HasValue &&
            detailedLayers.Count == 0;

        var layerEstimates = new List<PaintLayerEstimate>();

        if (coatingRequired)
        {
            var sourceLayers = detailedLayers.Count > 0
                ? detailedLayers
                : [new PaintLayerSignal
                {
                    Name = "System powłok / łącznie",
                    DftMicron = dft
                }];

            foreach (var layer in sourceLayers)
            {
                var layerDft = Math.Clamp(layer.DftMicron, 5, 1500);
                var coatCount = Math.Clamp(layer.CoatCount, 1, 12);
                var layerCoverage = 10.0 * solids / layerDft;
                var layerLitersTheoryPerCoat = layerCoverage > 0
                    ? paintableM2 / layerCoverage
                    : 0;
                var layerLitersTheory = layerLitersTheoryPerCoat * coatCount;
                var layerLitersLoss = layerLitersTheory * (1.0 + loss / 100.0);

                layerEstimates.Add(new PaintLayerEstimate
                {
                    Name = string.IsNullOrWhiteSpace(layer.Name)
                        ? "Warstwa"
                        : layer.Name,
                    DftMicron = layerDft,
                    CoatCount = coatCount,
                    TheoreticalCoverageM2PerL = layerCoverage,
                    LitersTheoretical = layerLitersTheory,
                    LitersWithLoss = layerLitersLoss,
                    MaterialCostPln = layerLitersLoss * s.PaintPricePlnL
                });
            }
        }

        var litersTheory = layerEstimates.Sum(x => x.LitersTheoretical);
        var litersLoss = layerEstimates.Sum(x => x.LitersWithLoss);
        var coverage = litersTheory > 0
            ? paintableM2 / litersTheory
            : 0;

        var prepRate = Math.Max(0.1, s.SurfacePrepM2PerHour);
        var appRate = Math.Max(0.1, s.PaintApplicationM2PerHour);

        var prepHours = prepRequired ? paintableM2 / prepRate : 0;
        var coatPasses = coatingRequired
            ? Math.Max(1, layerEstimates.Sum(x => Math.Max(1, x.CoatCount)))
            : 0;
        var applicationHours = coatingRequired
            ? paintableM2 / appRate * coatPasses
            : 0;

        // Stripe coat is typically applied on welds/edges before full coats. STEP gives us
        // a measured weld-candidate length, which is a much stronger driver than a fixed add-on.
        var stripeLengthM = drawing.PaintStripeCoatRequired
            ? Math.Max(0, geometry.WeldCandidateLengthMm / 1000.0)
            : 0;
        var stripeCoatHours = stripeLengthM > 0
            ? stripeLengthM / Math.Max(0.1, s.PaintStripeCoatMetersPerHour)
            : 0;

        // Handling/manipulation is kept automatic and hidden from normal UI. It scales
        // gently with mass and assembly complexity and can later be calibrated from 3402 history.
        var paintMassKg = result.WeightKg ?? 0;
        var paintHandlingHours = enabled
            ? (Math.Max(0, s.PaintHandlingMinutesBase) +
               Math.Max(0, paintMassKg) / 1000.0 * Math.Max(0, s.PaintHandlingMinutesPer1000Kg) +
               Math.Min(30.0, Math.Max(0, geometry.SolidCount - 1) * 0.35)) / 60.0
            : 0;

        // If the documentation requires coating a chamber that becomes sealed in the
        // final assembly, schedule that coating before closure. The extra handling uses
        // the existing (and history-calibratable) paint setup value instead of adding
        // a new manual parameter. Area-driven prep/application time is already counted.
        var preAssemblyHandlingHours = preAssemblyInternalPaintingRequired && enabled
            ? Math.Max(0, s.PaintHandlingMinutesBase) / 120.0
            : 0;
        paintHandlingHours += preAssemblyHandlingHours;

        var manualPaintPreviewHours = !enabled && paintableM2 > 0.0001
            ? Math.Max(0.35, paintableM2 / appRate + (Math.Max(0, s.PaintHandlingMinutesBase) / 60.0))
            : 0;
        var totalHours = enabled
            ? Math.Max(0.35, prepHours + applicationHours + stripeCoatHours + paintHandlingHours)
            : manualPaintPreviewHours;

        var confidence =
            coatingRequired &&
            drawing.TotalDftMicron.HasValue &&
            (!prepRequired || !string.IsNullOrWhiteSpace(drawing.SurfacePreparation))
                ? 96
                : coatingRequired ? 88 : prepRequired ? 82 : 35;
        if (projectGeometrySurfaceUsable && geometry.SurfaceAccessibilityLimitReached && explicitPaintScope != "ALL")
            confidence = Math.Min(confidence, 70);
        if (drawing.PaintScopeConflict)
            confidence = Math.Min(confidence, 60);
        if (explicitPaintScope is "ALL" or "INTERNAL_ONLY" && !projectGeometrySurfaceUsable)
            confidence = Math.Min(confidence, 55);
        if (drawing.DocumentSurfaceAreaM2 is > 0 && !projectGeometrySurfaceUsable && !hybridAreaUsed)
            confidence = Math.Min(confidence, Math.Clamp(drawing.DocumentSurfaceAreaConfidence, 45, 82));
        if (hybridAreaUsed)
            confidence = Math.Min(confidence, Math.Clamp(drawing.HybridSurfaceAreaConfidence, 30, 92));
        if (paintAreaEstimatedFromMass)
            confidence = Math.Min(confidence, hybridAreaUsed ? 58 : 38);
        var autoPaintAreaRatio = grossAreaM2 > 0.0001 ? paintableM2 / grossAreaM2 : 1.0;
        if (explicitPaintScope == "AUTO" && projectGeometrySurfaceUsable && autoPaintAreaRatio < 0.20)
            confidence = Math.Min(confidence, 68);

        var paintCompleteness = 0;
        var paintCompletenessParts = new List<string>();
        if (!string.IsNullOrWhiteSpace(drawing.SurfacePreparation)) { paintCompleteness += 20; paintCompletenessParts.Add("przygotowanie"); }
        if (!string.IsNullOrWhiteSpace(drawing.CorrosionClass)) { paintCompleteness += 15; paintCompletenessParts.Add("klasa korozyjności"); }
        if (drawing.PaintLayers.Count > 0) { paintCompleteness += 25; paintCompletenessParts.Add("warstwy"); }
        else if (drawing.TotalDftMicron is > 0) { paintCompleteness += 18; paintCompletenessParts.Add("DFT"); }
        if (!string.IsNullOrWhiteSpace(drawing.PaintColour)) { paintCompleteness += 10; paintCompletenessParts.Add("kolor"); }
        if (paintableM2 > 0) { paintCompleteness += 20; paintCompletenessParts.Add("powierzchnia"); }
        if (!string.IsNullOrWhiteSpace(drawing.PaintScope) && drawing.PaintScope != "AUTO") { paintCompleteness += 10; paintCompletenessParts.Add("zakres"); }
        paintCompleteness = Math.Clamp(paintCompleteness, 0, 100);
        var paintCompletenessBasis = paintCompletenessParts.Count == 0
            ? "Brak kompletnej specyfikacji systemu powłok."
            : $"Potwierdzone: {string.Join(", ", paintCompletenessParts)}.";
        if (coatingRequired && drawing.PaintLayers.Count == 0 && drawing.TotalDftMicron is null)
            result.Drawing.Findings.Add("FIX13 Paint System: wykryto wymaganie powłoki, ale brak jawnego układu warstw/DFT; koszt korzysta z ustawień bazowych i pozostaje oznaczony jako założenie.");

        var paintZoneClasses = drawing.PaintZoneSignals
            .Select(x => x.CorrosionClass)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x)
            .ToList();
        var paintZoneDfts = drawing.PaintZoneSignals
            .Where(x => x.DftMicron is > 0)
            .Select(x => x.DftMicron!.Value)
            .Distinct()
            .OrderBy(x => x)
            .ToList();
        if ((paintZoneClasses.Count > 1 || paintZoneDfts.Count > 1) && coatingRequired)
        {
            confidence = Math.Min(confidence, drawing.HybridSurfaceAreaCoveragePercent >= 90 ? 82 : 72);
            result.Drawing.Findings.Add(
                $"FIX14 Painting Zones: {drawing.PaintZoneSignals.Count} rodzin ze strefami powłok; klasy {string.Join("/", paintZoneClasses.DefaultIfEmpty("—"))}; " +
                $"DFT {string.Join("/", paintZoneDfts.Select(x => x.ToString("0.#")))}. Różne strefy nie są scalane jako konflikt globalny.");
        }

        var zoneBasis = drawing.PaintZoneSignals.Count > 0
            ? $" FIX14 strefy: {drawing.PaintZoneSignals.Count} rodzin" +
              (paintZoneClasses.Count > 0 ? $", klasy {string.Join("/", paintZoneClasses)}" : "") +
              (paintZoneDfts.Count > 0 ? $", DFT {string.Join("/", paintZoneDfts.Select(x => x.ToString("0.#")))} µm" : "") + "."
            : "";

        return new PaintEstimate
        {
            Enabled = enabled,
            SurfacePreparationRequired = prepRequired,
            CoatingRequired = coatingRequired,
            SurfacePreparation = drawing.SurfacePreparation,
            CorrosionClass = drawing.CorrosionClass,
            Colour = drawing.PaintColour,
            GrossAreaM2 = grossAreaM2,
            HiddenContactAreaM2 = hiddenM2,
            ClosedInternalAreaM2 = closedM2,
            OpenInternalAreaM2 = internalGeometryM2,
            MaskedMachinedAreaM2 = maskedMachinedM2,
            PaintableAreaM2 = paintableM2,
            AreaSource = paintAreaSource,
            AreaConfidence = hybridAreaUsed ? drawing.HybridSurfaceAreaConfidence : confidence,
            AreaCoveragePercent = hybridAreaUsed ? drawing.HybridSurfaceAreaCoveragePercent : (projectGeometrySurfaceUsable ? 100 : 0),
            Scope = explicitPaintScope,
            InternalAreaIncludedM2 = internalAreaIncludedM2,
            PreAssemblyInternalAreaM2 = preAssemblyInternalAreaM2,
            PreAssemblyInternalPaintingRequired = preAssemblyInternalPaintingRequired,
            PreAssemblyHandlingHours = preAssemblyHandlingHours,
            TotalDftMicron = dft,
            DftAssumed = dftAssumed,
            LayerCount = coatPasses,
            Layers = layerEstimates,
            VolumeSolidsPercent = solids,
            LossPercent = loss,
            TheoreticalCoverageM2PerL = coverage,
            PaintLitersTheoretical = litersTheory,
            PaintLitersWithLoss = litersLoss,
            SurfacePrepHours = prepHours,
            ApplicationHours = applicationHours,
            StripeCoatHours = stripeCoatHours,
            HandlingHours = paintHandlingHours,
            TotalHours = totalHours,
            PaintMaterialCostPln = layerEstimates.Sum(x => x.MaterialCostPln),
            Confidence = confidence,
            SystemCompletenessPercent = paintCompleteness,
            SystemCompletenessBasis = paintCompletenessBasis,
            Basis = coatingRequired
                ? $"Zakres: {(explicitPaintScope switch { "ALL" => "zewnętrzne + wewnętrzne", "EXTERNAL_ONLY" => "tylko zewnętrzne", "INTERNAL_ONLY" => "tylko wewnętrzne", _ => "zewnętrzne/dostępne — automatycznie" })}; " +
                  $"pow. do malowania {paintableM2:0.###} m² ({paintAreaSource}); {coatPasses} przejść powłoki, DFT {dft:0.#} µm; " +
                  $"części stałe {solids:0.#}%; wydajność teor. systemu {coverage:0.##} m²/l; " +
                  $"straty {loss:0.#}%; zużycie {litersLoss:0.##} l." +
                  (internalAreaIncludedM2 > 0 ? $" Wnętrza wliczone: {internalAreaIncludedM2:0.###} m²." : "") +
                  (preAssemblyInternalPaintingRequired
                      ? $" Zamknięte wnętrza {preAssemblyInternalAreaM2:0.###} m²: malowanie zaplanowane przed zamknięciem/spawaniem zespołu (+{preAssemblyHandlingHours:0.###} h obsługi)."
                      : "") +
                  (drawing.PaintStripeCoatRequired
                      ? stripeLengthM > 0
                          ? $" Stripe coat: {stripeLengthM:0.##} m spoin/krawędzi, {stripeCoatHours:0.###} h."
                          : " Stripe coat wymagany, ale brak wiarygodnej długości krawędzi/spoin — nie doliczono arbitralnego czasu."
                      : "") +
                  (paintHandlingHours > 0 ? $" Manipulacja/obsługa: {paintHandlingHours:0.###} h." : "") +
                  (projectGeometrySurfaceUsable && geometry.SurfaceAccessibilityLimitReached ? " Część dostępności powierzchni pozostała niejednoznaczna — obniżono pewność, bez agresywnego odejmowania pola." : "") +
                  (explicitPaintScope == "AUTO" && projectGeometrySurfaceUsable && autoPaintAreaRatio < 0.20
                      ? $" Sanity-check: automat pozostawił do malowania tylko {autoPaintAreaRatio:P0} powierzchni brutto; obniżono pewność pola."
                      : "") + zoneBasis
                : $"Tylko przygotowanie powierzchni; dostępna powierzchnia {paintableM2:0.###} m² ({paintAreaSource}); manipulacja/obsługa {paintHandlingHours:0.###} h." + zoneBasis
        };
    }

    private static void ApplyWorkstations(AnalysisResult result, CostingSettings settings)
    {
        foreach (var process in result.Processes)
        {
            process.BaseHours = process.Hours;
            process.CalibrationFactor = 1.0;
            if (!process.Enabled)
                continue;

            var candidates = settings.Workstations
                .Where(x => x.Enabled && x.AutomaticRoutingCandidate && string.Equals(x.ProcessCode, process.Code, StringComparison.OrdinalIgnoreCase))
                .Where(x => string.IsNullOrWhiteSpace(x.MatchTag) ||
                            (process.Code == "WELD" && string.Equals(x.MatchTag, result.Welding.ProcessCode, StringComparison.OrdinalIgnoreCase)))
                .Where(x => FitsCapacity(x, result, process.Code))
                .OrderBy(x => settings.AutomaticWorkstationSelection
                    ? process.Hours * Math.Max(0.25, x.TimeFactor) * (x.RatePlnPerHour > 0 ? x.RatePlnPerHour : process.RatePlnPerHour)
                    : x.Priority)
                .ThenBy(x => x.Priority)
                .ThenBy(x => x.RatePlnPerHour > 0 ? x.RatePlnPerHour : double.MaxValue)
                .ToList();

            var selected = candidates.FirstOrDefault();
            if (selected is null)
                continue;

            process.WorkstationCode = selected.Code;
            process.WorkstationName = selected.Name;
            var stationFactor = Math.Clamp(selected.TimeFactor, 0.25, 4.0);
            if (settings.AutomaticWorkstationSelection && Math.Abs(stationFactor - 1.0) > 0.0001)
                process.Hours = Round(process.Hours * stationFactor);
            process.BaseHours = process.Hours;
            if (selected.RatePlnPerHour > 0)
                process.RatePlnPerHour = selected.RatePlnPerHour;

            process.Basis += (settings.AutomaticWorkstationSelection
                                 ? $" Automatyczny wybór najtańszego pasującego wariantu: {selected.Name}"
                                 : $" Stanowisko: {selected.Name}") +
                             (selected.RatePlnPerHour > 0
                                 ? $" ({selected.RatePlnPerHour:0.##} PLN/h)."
                                 : " (stawka bazowa procesu)." );
        }
    }

    private static bool FitsCapacity(WorkstationDefinition station, AnalysisResult result, string processCode)
    {
        // Welding is selected by ISO 4063 process tag and rate. Manual welding has no
        // meaningful universal XYZ envelope, so dimensions are intentionally ignored.
        if (string.Equals(processCode, "WELD", StringComparison.OrdinalIgnoreCase))
            return true;

        if (string.Equals(processCode, "CUT", StringComparison.OrdinalIgnoreCase))
        {
            var cutX = result.Dxf.CutBoundingXmm;
            var cutY = result.Dxf.CutBoundingYmm;

            if (cutX <= 0 || cutY <= 0)
            {
                var plate = result.Geometry.Parts
                    .Where(x => x.Classification.Contains("Blacha", StringComparison.OrdinalIgnoreCase) ||
                                x.Classification.Contains("Płyta", StringComparison.OrdinalIgnoreCase))
                    .OrderByDescending(x => x.Xmm * x.Ymm * x.Zmm)
                    .FirstOrDefault();
                if (plate is not null)
                {
                    var d = new[] { plate.Xmm, plate.Ymm, plate.Zmm }.OrderByDescending(x => x).ToArray();
                    cutX = d.ElementAtOrDefault(0);
                    cutY = d.ElementAtOrDefault(1);
                }
            }

            if (!Fits2D(cutX, cutY, station.MaxXmm, station.MaxYmm))
                return false;

            if (station.MaxThicknessMm > 0)
            {
                var thicknesses = result.Geometry.Parts
                    .Where(x => x.Classification.Contains("Blacha", StringComparison.OrdinalIgnoreCase) ||
                                x.Classification.Contains("Płyta", StringComparison.OrdinalIgnoreCase))
                    .Select(x => new[] { x.Xmm, x.Ymm, x.Zmm }.Where(v => v > 0.05).DefaultIfEmpty(0).Min())
                    .Where(x => x > 0)
                    .OrderBy(x => x)
                    .ToList();
                var thickness = thicknesses.Count > 0 ? thicknesses[thicknesses.Count / 2] : 0;
                if (thickness > station.MaxThicknessMm)
                    return false;
            }
            return true;
        }

        if (string.Equals(processCode, "CNC", StringComparison.OrdinalIgnoreCase))
        {
            var postWeldMachining = RequiresPostWeldMachining(result);
            var largestPart = result.Geometry.Parts
                .OrderByDescending(x => x.Xmm * x.Ymm * x.Zmm)
                .FirstOrDefault();

            var dims = postWeldMachining
                ? new[] { result.Geometry.BoundingXmm, result.Geometry.BoundingYmm, result.Geometry.BoundingZmm }
                : largestPart is null
                    ? new[] { result.Geometry.BoundingXmm, result.Geometry.BoundingYmm, result.Geometry.BoundingZmm }
                    : new[] { largestPart.Xmm, largestPart.Ymm, largestPart.Zmm };

            if (!Fits3D(dims, station.MaxXmm, station.MaxYmm, station.MaxZmm))
                return false;

            var partMass = postWeldMachining
                ? result.WeightKg ?? result.Geometry.Parts.Sum(x => Math.Max(0, x.MassKgEach) * Math.Max(1, x.Quantity))
                : largestPart?.MassKgEach ?? result.WeightKg ?? 0;
            return station.MaxWeightKg <= 0 || partMass <= station.MaxWeightKg;
        }

        if (string.Equals(processCode, "SURF", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(processCode, "ASSY", StringComparison.OrdinalIgnoreCase))
        {
            var dims = new[] { result.Geometry.BoundingXmm, result.Geometry.BoundingYmm, result.Geometry.BoundingZmm };
            if (!Fits3D(dims, station.MaxXmm, station.MaxYmm, station.MaxZmm))
                return false;
            var totalMass = result.WeightKg ?? result.Geometry.Parts.Sum(x => x.MassKgEach * Math.Max(1, x.Quantity));
            return station.MaxWeightKg <= 0 || totalMass <= station.MaxWeightKg;
        }

        return true;
    }

    private static bool Fits2D(double x, double y, double maxX, double maxY)
    {
        if (x <= 0 || y <= 0 || (maxX <= 0 && maxY <= 0))
            return true;
        var dims = new[] { x, y };
        var limits = new[] { maxX <= 0 ? double.MaxValue : maxX, maxY <= 0 ? double.MaxValue : maxY };
        Array.Sort(dims);
        Array.Sort(limits);
        return dims[0] <= limits[0] && dims[1] <= limits[1];
    }

    private static bool Fits3D(double[] dimensions, double maxX, double maxY, double maxZ)
    {
        if (dimensions.All(x => x <= 0) || (maxX <= 0 && maxY <= 0 && maxZ <= 0))
            return true;
        var dims = dimensions.Select(x => Math.Max(0, x)).ToArray();
        var limits = new[]
        {
            maxX <= 0 ? double.MaxValue : maxX,
            maxY <= 0 ? double.MaxValue : maxY,
            maxZ <= 0 ? double.MaxValue : maxZ
        };
        Array.Sort(dims);
        Array.Sort(limits);
        return dims[0] <= limits[0] && dims[1] <= limits[1] && dims[2] <= limits[2];
    }

    private static void RecalculateFinancials(AnalysisResult result, CostingSettings settings)
    {
        result.AppliedMarkupPercent = settings.MarkupPercent;
        result.AppliedHistoricalBlendPercent = settings.HistoricalBlendPercent;
        result.AppliedWhatIfMaterialPriceChangePercent = settings.WhatIfMaterialPriceChangePercent;
        result.AppliedWhatIfProcessTimeChangePercent = settings.WhatIfProcessTimeChangePercent;
        result.ProcessCostPln = result.Processes.Where(x => x.Enabled).Sum(x => x.CostPln);
        var weldMaterialsInPrice = result.Processes.Any(x => x.Enabled && string.Equals(x.Code, "WELD", StringComparison.OrdinalIgnoreCase))
            ? result.Welding.ConsumableCostPln : 0;
        var paintMaterialsInPrice = result.Processes.Any(x => x.Enabled && string.Equals(x.Code, "SURF", StringComparison.OrdinalIgnoreCase))
            ? result.Painting.PaintMaterialCostPln : 0;
        result.TechnologyMaterialCostPln = weldMaterialsInPrice + paintMaterialsInPrice;
        result.CostTotalPln =
            result.MaterialCostPln +
            result.PurchasedPartsCostPln +
            result.TechnologyMaterialCostPln +
            result.ProcessCostPln +
            result.ExternalCostPln;
        result.TechnicalPricePln = result.CostTotalPln * (1.0 + settings.MarkupPercent / 100.0);
        var historyShare = result.HistoricalPricePln is > 0
            ? Math.Clamp(settings.HistoricalBlendPercent / 100.0, 0, 0.50)
            : 0.0;
        result.FinalPricePln = historyShare > 0
            ? result.TechnicalPricePln * (1.0 - historyShare) + result.HistoricalPricePln!.Value * historyShare
            : result.TechnicalPricePln;

        result.CostLines =
        [
            new()
            {
                Name = "Materiał", AmountPln = result.MaterialCostPln,
                Confidence = result.Nesting.Available && result.Nesting.UsedForMaterialCost ? result.Nesting.Confidence : (result.Material == "Nie rozpoznano" ? 58 : 92),
                Basis = BuildMaterialBasis(result, settings)
            },
            .. (result.PurchasedPartsCostPln > 0 ? new[]
            {
                new CostLine { Name = "Części kupne", AmountPln = result.PurchasedPartsCostPln,
                    Confidence = result.PurchasedParts.Count > 0 ? (int)Math.Round(result.PurchasedParts.Average(x => x.Confidence)) : 40,
                    Basis = $"{result.PurchasedParts.Count} pozycji BOM dopasowanych do cennika." }
            } : Array.Empty<CostLine>()),
            new()
            {
                Name = "Materiały technologiczne", AmountPln = result.TechnologyMaterialCostPln,
                Confidence = Math.Min(result.Welding.Enabled ? result.Welding.Confidence : 100, result.Painting.Enabled ? result.Painting.Confidence : 100),
                Basis = $"Spoiwa: {weldMaterialsInPrice:0.##} PLN; farby: {paintMaterialsInPrice:0.##} PLN."
            },
            .. result.Processes.Where(x => x.Enabled).Select(x => new CostLine
            {
                Name = string.IsNullOrWhiteSpace(x.WorkstationName) ? x.Name : $"{x.Name} — {x.WorkstationName}",
                AmountPln = x.CostPln, Confidence = x.Confidence, Basis = x.Basis
            }),
            .. (result.QualityCostPln > 0 ? new[]
            {
                new CostLine { Name = "Jakość / badania", AmountPln = result.QualityCostPln,
                    Confidence = result.QualityCosts.Count > 0 ? (int)Math.Round(result.QualityCosts.Average(x => x.Confidence)) : 40,
                    Basis = string.Join("; ", result.QualityCosts.Select(x => $"{x.Name}: {x.CostPln:0} PLN")) }
            } : Array.Empty<CostLine>()),
            new()
            {
                Name = "Usługi zewnętrzne pozostałe", AmountPln = Math.Max(0, result.ExternalCostPln - result.QualityCostPln),
                Confidence = result.ExternalCostPln > result.QualityCostPln ? 45 : 90,
                Basis = "Pozycje zewnętrzne inne niż automatycznie wycenione wymagania jakościowe."
            }
        ];
        result.CostConfidence = CostConfidenceEngine.Build(result);
        AutoQuoteEngine.Apply(result);
    }

    private static List<ProcessEstimate> BuildProcesses(
        AnalysisResult result,
        CostingSettings s)
    {
        var p = new List<ProcessEstimate>();

        var partQty = result.Geometry.Parts.Sum(x => x.Quantity);
        var plateGroups = result.Geometry.Parts
            .Where(x => x.Classification.Contains("Blacha", StringComparison.OrdinalIgnoreCase) ||
                        x.Classification.Contains("Płyta", StringComparison.OrdinalIgnoreCase))
            .ToList();
        var plateQty = plateGroups.Sum(x => x.Quantity);

        var longQty = result.Geometry.Parts
            .Where(x =>
                x.Classification.Contains("Profil", StringComparison.OrdinalIgnoreCase) ||
                x.Classification.Contains("Płaskownik", StringComparison.OrdinalIgnoreCase) ||
                x.Classification.Contains("Rura", StringComparison.OrdinalIgnoreCase) ||
                x.Classification.Contains("Pręt", StringComparison.OrdinalIgnoreCase) ||
                x.Classification.Contains("Wałek", StringComparison.OrdinalIgnoreCase))
            .Sum(x => x.Quantity);

        var hasCutting = result.Dxf.EntityCount > 0 || plateQty > 0 || longQty > 0;
        var measuredCut = result.Dxf.GeometryMeasurementReliable && result.Dxf.CutLengthMm > 0;
        double cutHours;
        int cutConfidence;
        string cutBasis;

        if (measuredCut)
        {
            // Use the thinnest bbox dimension as a robust plate-thickness proxy for STEP plate groups.
            // Median avoids a single badly classified solid dominating the technology choice.
            var plateThicknesses = result.Geometry.Parts
                .Where(x => x.Classification.Contains("Blacha", StringComparison.OrdinalIgnoreCase) ||
                            x.Classification.Contains("Płyta", StringComparison.OrdinalIgnoreCase))
                .Select(x => new[] { x.Xmm, x.Ymm, x.Zmm }.Where(v => v > 0.05).DefaultIfEmpty(0).Min())
                .Where(x => x > 0)
                .OrderBy(x => x)
                .ToList();
            var thicknessMm = plateThicknesses.Count > 0
                ? plateThicknesses[plateThicknesses.Count / 2]
                : 0;

            var profile = s.CuttingProfiles
                .Where(x => x.Matches(result.Material ?? "", thicknessMm))
                .OrderBy(x => Math.Max(0, x.MaxThicknessMm - x.MinThicknessMm))
                .FirstOrDefault();

            var speedMmMin = Math.Max(50, profile?.SpeedMmMin ?? s.CuttingReferenceSpeedMmMin);
            var pierceSeconds = Math.Max(0, profile?.PierceSeconds ?? s.CuttingPierceSeconds);
            var rapidSpeedMmMin = Math.Max(100, profile?.RapidSpeedMmMin ?? s.CuttingRapidSpeedMmMin);
            var markingSpeedMmMin = Math.Max(50, profile?.MarkingSpeedMmMin ?? s.CuttingMarkingSpeedMmMin);
            var curveFactor = Math.Clamp(profile?.CurveSpeedFactor ?? s.CuttingCurveSpeedFactor, 0.25, 1.0);
            var projectRunQty = Math.Clamp(result.Drawing.ProjectQuantityHint ?? 1.0, 1.0, 10000.0);
            var projectSeriesFactor = projectRunQty > 1
                ? Math.Max(Math.Clamp(s.SeriesMinimumRunFactor, 0.2, 1.0), Math.Pow(projectRunQty, Math.Clamp(s.SeriesSetupExponent, 0.5, 1.0) - 1.0))
                : 1.0;
            var setupMinutes = Math.Max(0, s.CuttingSetupMinutes) * projectSeriesFactor;

            var curvedEntities = result.Dxf.Arcs + result.Dxf.Splines + result.Dxf.Ellipses;
            var curvedShare = Math.Clamp(curvedEntities / (double)Math.Max(1, result.Dxf.CutGeometryEntityCount), 0, 1);
            var effectiveCutLengthMm = result.Dxf.CutLengthMm * (1.0 + curvedShare * (1.0 / curveFactor - 1.0));
            var cuttingMinutes = effectiveCutLengthMm / speedMmMin;
            var pierceMinutes = result.Dxf.CutStartCount * pierceSeconds / 60.0;
            var rapidMinutes = result.Dxf.EstimatedRapidTravelMm / rapidSpeedMmMin;
            var markingMinutes = result.Dxf.MarkingLengthMm / markingSpeedMmMin;
            var fileHandlingMinutes = Math.Max(0, result.Dxf.SourceFileCount - 1) * Math.Max(0, s.CuttingExtraFileHandlingMinutes);

            // A measured DXF is strong evidence only for the part family/families it
            // actually represents. It must not silently replace cutting estimates for an
            // entire multi-part STEP assembly. In the absence of explicit file-to-part
            // mapping, use DXF source count as conservative coverage and cost the uncovered
            // plate quantities with the STEP fallback.
            var coveredGroupCount = plateGroups.Count == 0
                ? 0
                : Math.Min(plateGroups.Count, Math.Max(1, result.Dxf.SourceFileCount));
            var coveredPlateQty = plateGroups
                .OrderByDescending(x => Math.Max(1, x.Quantity))
                .Take(coveredGroupCount)
                .Sum(x => Math.Max(1, x.Quantity));
            var uncoveredPlateQty = Math.Max(0, plateQty - coveredPlateQty);
            var dxfCoverage = plateGroups.Count == 0 ? 1.0 : coveredGroupCount / (double)plateGroups.Count;

            cutHours =
                (setupMinutes + cuttingMinutes + pierceMinutes + rapidMinutes + markingMinutes + fileHandlingMinutes) / 60.0 +
                coveredPlateQty * 0.01 +
                uncoveredPlateQty * 0.035 +
                longQty * 0.025;

            cutConfidence = profile is not null && thicknessMm > 0 ? 95 : 89;
            if (result.Dxf.OpenPathCount > 0)
                cutConfidence = Math.Min(cutConfidence, 84);
            if (uncoveredPlateQty > 0)
                cutConfidence = Math.Min(cutConfidence, (int)Math.Round(58 + 34 * dxfCoverage));

            var technologyText = profile is not null
                ? $"profil {profile.Code}/{profile.Name}, t≈{thicknessMm:0.##} mm"
                : thicknessMm > 0
                    ? $"profil bazowy, t≈{thicknessMm:0.##} mm"
                    : "profil bazowy (brak pewnej grubości)";

            cutBasis =
                $"DXF: cięcie {result.Dxf.CutLengthMm / 1000.0:0.###} m; starty/przebicia {result.Dxf.CutStartCount}; " +
                $"przejazdy szybkie ≈{result.Dxf.EstimatedRapidTravelMm / 1000.0:0.###} m; znakowanie {result.Dxf.MarkingLengthMm / 1000.0:0.###} m; " +
                $"krzywe {curvedShare:P0}; {technologyText}." +
                (plateGroups.Count > 0
                    ? $" Pokrycie DXF względem rodzin blach: {coveredGroupCount}/{plateGroups.Count}; pozostałe {uncoveredPlateQty} szt. policzono fallbackiem STEP."
                    : "") +
                (projectRunQty > 1 ? $" Seria {projectRunQty:0.#} szt.: setup ×{projectSeriesFactor:0.###}." : "");
        }
        else
        {
            // Conservative fallback retained for DXF without reliable units and
            // for STEP-only packages. Entity count is a weak driver, so confidence
            // stays lower than for measured geometry.
            cutHours =
                result.Dxf.EntityCount / 500.0 +
                plateQty * 0.035 +
                longQty * 0.025;
            cutConfidence = result.Dxf.EntityCount > 0 ? 68 : hasCutting ? 62 : 35;
            cutBasis = result.Dxf.EntityCount > 0
                ? $"DXF bez wiarygodnej długości/skali: {result.Dxf.EntityCount} elementów; blachy: {plateQty}; elementy długie: {longQty}."
                : $"Klasyfikacja STEP: blachy {plateQty}, elementy długie {longQty}.";
        }

        p.Add(new ProcessEstimate
        {
            Code = "CUT",
            Name = "Cięcie / przygotowanie półfabrykatów",
            Enabled = hasCutting,
            Hours = Round(Math.Max(hasCutting ? 0.35 : 0, cutHours)),
            RatePlnPerHour = s.CuttingRatePlnH,
            Confidence = cutConfidence,
            Basis = cutBasis
        });

        // FIX12B: preparation is a real shop burden and must not disappear inside a
        // single CUT/CNC number. Keep manual and machine preparation separate so the
        // company 3302/3303 history can calibrate them independently.
        var uniqueGroupCount = Math.Max(0, result.Geometry.UniquePartGroups > 0 ? result.Geometry.UniquePartGroups : result.Geometry.Parts.Count);
        var prepManualHours = hasCutting
            ? uniqueGroupCount * Math.Max(0, s.PrepManualHoursPerUniqueGroup) +
              Math.Max(0, partQty) * Math.Max(0, s.PrepManualHoursPerPhysicalPart)
            : 0.0;
        var prepMachineHours = hasCutting
            ? plateGroups.Count * Math.Max(0, s.PrepMachineHoursPerPlateGroup) +
              Math.Max(0, result.Geometry.TotalBevelFaces) * Math.Max(0, s.PrepMachineHoursPerBevelFace)
            : 0.0;

        p.Add(new ProcessEstimate
        {
            Code = "PREP_MANUAL",
            Name = "Przygotowanie produkcji - obróbka ręczna",
            Enabled = prepManualHours >= 0.20,
            Hours = Round(prepManualHours),
            RatePlnPerHour = s.CuttingRatePlnH,
            Confidence = result.Geometry.Available ? 68 : 48,
            Basis = $"FIX12B: {uniqueGroupCount} rodzin unikalnych + {partQty} instancji; czas trasowania, gratowania, oczyszczenia i przygotowania przed operacjami głównymi."
        });
        p.Add(new ProcessEstimate
        {
            Code = "PREP_MACHINE",
            Name = "Przygotowanie produkcji - obróbka maszynowa",
            Enabled = prepMachineHours >= 0.20,
            Hours = Round(prepMachineHours),
            RatePlnPerHour = s.CuttingRatePlnH,
            Confidence = result.Geometry.Available ? 66 : 45,
            Basis = $"FIX12B: {plateGroups.Count} rodzin blach + {result.Geometry.TotalBevelFaces} powierzchni ukosowanych; przygotowanie krawędzi/elementów przed montażem i spawaniem."
        });

        var weld = result.Welding;

        p.Add(new ProcessEstimate
        {
            Code = "WELD",
            Name = "Spawanie",
            Enabled = weld.Enabled,
            Hours = Round(weld.TotalHours),
            RatePlnPerHour = s.WeldingRatePlnH,
            Confidence = weld.Confidence,
            Basis = weld.Enabled
                ? $"{weld.Basis} Łuk {weld.ArcHours:0.###} h; dopasowanie {weld.FitUpHours:0.###} h; manipulacja {weld.ManipulationHours:0.###} h; spoiwo {weld.FillerMetalKg:0.###} kg; ściegi {weld.NumberOfPasses}."
                : "Brak wystarczającego potwierdzenia spawania."
        });

        static bool IsPlateLike(PartGroup part) =>
            part.Classification.Contains("Blacha", StringComparison.OrdinalIgnoreCase) ||
            part.Classification.Contains("Płyta", StringComparison.OrdinalIgnoreCase);

        static double PartThickness(PartGroup part) =>
            new[] { part.Xmm, part.Ymm, part.Zmm }
                .Where(v => v > 0.05)
                .DefaultIfEmpty(0)
                .Min();

        bool ThermalCutCapability(PartGroup part, HoleFeature hole)
        {
            var thickness = PartThickness(part);
            if (!IsPlateLike(part) || thickness <= 0 || hole.DiameterMm <= 0)
                return false;

            var profile = s.CuttingProfiles
                .Where(x => x.Matches(result.Material ?? "", thickness))
                .OrderBy(x => Math.Max(0, x.MaxThicknessMm - x.MinThicknessMm))
                .FirstOrDefault();
            var supportsInternalContours = profile?.SupportsInternalContours ?? true;
            var minimumDiameter = Math.Max(0, profile?.MinimumHoleDiameterMm ?? s.CuttingMinimumHoleDiameterMm);
            var minimumRatio = Math.Max(0, profile?.MinimumHoleToThicknessRatio ?? s.CuttingMinimumHoleToThicknessRatio);
            return supportsInternalContours &&
                   hole.DiameterMm >= minimumDiameter &&
                   hole.DiameterMm >= thickness * minimumRatio;
        }

        (bool Drill, bool Ream, bool Tap, bool Bore, bool Secondary, bool Thermal, bool Cnc)
            GeometryHolePlan(PartGroup part, HoleFeature hole)
        {
            var hasExplicitRoute = hole.RequiresDrill || hole.RequiresReam || hole.RequiresTap ||
                                   hole.RequiresBore || hole.RequiresCnc || hole.CanThermalCut;
            var tap = hole.RequiresTap || !string.IsNullOrWhiteSpace(hole.ThreadCode);
            // Thread takes precedence over a coincidental fit token.  A tap route is
            // drill + tap, never an automatic drill + ream + tap stack.
            var ream = !tap && (hole.RequiresReam || hole.FitConfirmed || hole.ReamedLikely);
            var bore = !tap && !ream &&
                       (hole.RequiresBore || (!hasExplicitRoute && hole.PrecisionMachined));
            var secondary = hole.CounterboreLikely || hole.SpotfaceLikely || hole.CountersinkLikely;
            var explicitCnc = hole.RequiresCnc || tap || ream || bore || secondary;
            var thermal = !explicitCnc && ThermalCutCapability(part, hole);
            var cnc = explicitCnc || !thermal;
            var drill = cnc && (hole.RequiresDrill || tap || ream || bore || secondary || !thermal);
            return (drill, ream, tap, bore, secondary, thermal, cnc);
        }

        (bool Drill, bool Ream, bool Tap, bool Bore, bool Secondary, bool Cnc)
            DrawingHolePlan(HoleRequirementSignal hole)
        {
            var hasExplicitRoute = hole.RequiresDrill || hole.RequiresReam || hole.RequiresTap ||
                                   hole.RequiresBore || hole.RequiresCnc || hole.CanThermalCut;
            var tap = hole.RequiresTap || !string.IsNullOrWhiteSpace(hole.ThreadCode);
            var ream = !tap && (hole.RequiresReam || hole.FitConfirmed || hole.ReamedLikely ||
                string.Equals(hole.OperationHint, "FIT", StringComparison.OrdinalIgnoreCase));
            var bore = !tap && !ream && (hole.RequiresBore || (!hasExplicitRoute &&
                (hole.PrecisionMachined || string.Equals(hole.OperationHint, "TOLERANCED", StringComparison.OrdinalIgnoreCase))));
            var secondary = string.Equals(hole.OperationHint, "COUNTERBORE", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(hole.OperationHint, "COUNTERSINK", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(hole.OperationHint, "SPOTFACE", StringComparison.OrdinalIgnoreCase);
            var drill = hole.RequiresDrill || tap || ream || bore || secondary;
            var cnc = hole.RequiresCnc || drill || ream || tap || bore || secondary;
            return (drill, ream, tap, bore, secondary, cnc);
        }

        var postWeldMachining = RequiresPostWeldMachining(result);
        var machiningKeyword = HasKeyword(result.Drawing, "MACHIN", "OBRÓB", "FREZ", "RA ");
        // FIX10I: a watchdog checkpoint deliberately preserves topology/bbox/volume but
        // may contain zero fully analysed feature groups. Face/cylinder counts from such
        // checkpoints are not enough evidence to invent hours of CNC machining. Keep
        // independent PDF/BOM machining signals and any actually extracted hole features,
        // but disable complexity-only inference until feature coverage is meaningful.
        var stepFeatureCoverage = result.Geometry.UniquePartGroups > 0
            ? Math.Clamp(result.Geometry.FullyAnalyzedUniqueSolids / (double)result.Geometry.UniquePartGroups, 0, 1)
            : result.Geometry.WatchdogTriggered ? 0 : 1;
        // FIX10K / A2: below 80% unique-part feature coverage a watchdog result is
        // evidence of partial observations, not a complete machining model.  Full CNC
        // routing from topology/face complexity is therefore allowed only at >=80%.
        var geometryFeaturesReliableForRouting = !result.Geometry.WatchdogTriggered || stepFeatureCoverage >= 0.80;
        var watchdogFeaturesPartial = result.Geometry.WatchdogTriggered && stepFeatureCoverage < 0.80;
        var holeOps = result.Geometry.Parts
            .SelectMany(part => part.Holes.Select(h => new
            {
                Part = part,
                Hole = h,
                Qty = Math.Max(1, part.Quantity),
                Plan = GeometryHolePlan(part, h)
            }))
            .ToList();
        var geometryHoleCount = holeOps.Sum(x => Math.Max(1, x.Hole.Count) * x.Qty);
        var partialObservedMachining = watchdogFeaturesPartial && holeOps.Any(x => x.Plan.Cnc);
        // DS Estimate 1.1: completed feature groups remain valid observations
        // even if the whole STEP has <80% feature coverage. Use those explicit holes /
        // threads / fits, but never extrapolate topology, removed volume or complexity
        // to the unanalysed remainder.
        var routedHoleOps = holeOps;
        var holeCount = Math.Max(result.Geometry.TotalHoleCount, geometryHoleCount);
        var fitHoles = routedHoleOps.Sum(x => x.Plan.Ream ? Math.Max(1, x.Hole.Count) * x.Qty : 0);
        var threadedHoles = routedHoleOps.Sum(x => x.Plan.Tap ? Math.Max(1, x.Hole.Count) * x.Qty : 0);
        var boredHoles = routedHoleOps.Sum(x => x.Plan.Bore ? Math.Max(1, x.Hole.Count) * x.Qty : 0);
        var secondaryHoles = routedHoleOps.Sum(x => x.Plan.Secondary ? Math.Max(1, x.Hole.Count) * x.Qty : 0);
        var drilledHoles = routedHoleOps.Sum(x => x.Plan.Drill ? Math.Max(1, x.Hole.Count) * x.Qty : 0);
        var thermalGeometryHoles = routedHoleOps.Sum(x => x.Plan.Thermal ? Math.Max(1, x.Hole.Count) * x.Qty : 0);
        var geometryMachinedHoles = routedHoleOps.Sum(x => x.Plan.Cnc ? Math.Max(1, x.Hole.Count) * x.Qty : 0);
        var geometryDrillOnlyHoles = routedHoleOps.Sum(x =>
            x.Plan.Drill && !x.Plan.Ream && !x.Plan.Tap && !x.Plan.Bore && !x.Plan.Secondary
                ? Math.Max(1, x.Hole.Count) * x.Qty
                : 0);

        // 2D drawing evidence must remain useful when there is no STEP. Precision
        // holes/tolerances trigger CNC; plain DXF circles are displayed as candidates
        // but deliberately do not force machining by themselves.
        var drawingHoleCount = result.Drawing.EstimatedHoleCount2D;
        var drawingPlans = result.Drawing.HoleRequirements
            .Select(x => new { Hole = x, Plan = DrawingHolePlan(x), Qty = Math.Max(1, x.Count) })
            .ToList();
        var drawingFitHoles = drawingPlans.Sum(x => x.Plan.Ream ? x.Qty : 0);
        var drawingThreadedHoles = drawingPlans.Sum(x => x.Plan.Tap ? x.Qty : 0);
        var drawingBoredHoles = drawingPlans.Sum(x => x.Plan.Bore ? x.Qty : 0);
        var drawingSecondaryHoles = drawingPlans.Sum(x => x.Plan.Secondary ? x.Qty : 0);
        var drawingRequiredDrillHoles = drawingPlans.Sum(x => x.Plan.Drill ? x.Qty : 0);
        var drawingCncHoles = drawingPlans.Sum(x => x.Plan.Cnc ? x.Qty : 0);
        var drawingDrillOnlyHoles = drawingPlans.Sum(x =>
            x.Plan.Drill && !x.Plan.Ream && !x.Plan.Tap && !x.Plan.Bore && !x.Plan.Secondary
                ? x.Qty
                : 0);
        var tightDimensionalTolerances = result.Drawing.TightDimensionalToleranceCount;
        var tightGeometricTolerances = result.Drawing.TightGeometricToleranceCount;
        var drawingOnlyFitHoles = Math.Max(0, drawingFitHoles - fitHoles);
        var drawingOnlyThreadedHoles = Math.Max(0, drawingThreadedHoles - threadedHoles);
        var drawingOnlyBoredHoles = Math.Max(0, drawingBoredHoles - boredHoles);
        var drawingOnlySecondaryHoles = Math.Max(0, drawingSecondaryHoles - secondaryHoles);
        var drawingOnlyDrillHoles = Math.Max(0, drawingDrillOnlyHoles - geometryDrillOnlyHoles);
        var drawingOnlyRequiredDrillOps = Math.Max(0, drawingRequiredDrillHoles - drilledHoles);
        var effectiveFitHoles = fitHoles + drawingOnlyFitHoles;
        var effectiveThreadedHoles = threadedHoles + drawingOnlyThreadedHoles;
        var effectiveBoredHoles = boredHoles + drawingOnlyBoredHoles;
        var effectiveSecondaryHoles = secondaryHoles + drawingOnlySecondaryHoles;
        var effectivePlainHoles = geometryDrillOnlyHoles + drawingOnlyDrillHoles;
        // Hole count is physical and must stay one-per-callout even when that hole has
        // several operations. Operation counts below remain separate for time costing.
        var drawingOnlyCncHoles = Math.Max(0, drawingCncHoles - geometryMachinedHoles);
        var effectiveHoleCount = geometryMachinedHoles + drawingOnlyCncHoles;

        // A scoped post-weld machining note (e.g. "MACHINED PADS AFTER WELDING")
        // proves an operation on the welded assembly, but does not mean every complex STEP
        // part must be loaded and machined individually.
        var allowTopologyMachiningEstimate = geometryFeaturesReliableForRouting && machiningKeyword && !postWeldMachining;
        var machiningGroups = result.Geometry.Parts
            .Where(x => x.Holes.Any(h => GeometryHolePlan(x, h).Cnc) ||
                        (allowTopologyMachiningEstimate && (x.FaceCount >= 18 || x.CylindricalFaceCount >= 4)))
            .ToList();
        var machiningPartQty = postWeldMachining
            ? (result.Geometry.SolidCount >= 2 ? 1 : machiningGroups.Sum(x => Math.Max(1, x.Quantity)))
            : machiningGroups.Sum(x => Math.Max(1, x.Quantity));
        var drawingPrecisionEvidence = drawingCncHoles > 0 ||
                                       tightDimensionalTolerances > 0 || tightGeometricTolerances > 0;
        var hasMachining = machiningKeyword || drawingPrecisionEvidence || geometryMachinedHoles > 0 || partialObservedMachining;
        var cncEvidenceLevel = postWeldMachining
            ? "POST_WELD_DRAWING"
            : drawingPrecisionEvidence || machiningKeyword
                ? "DRAWING_FEATURES"
                : geometryFeaturesReliableForRouting && geometryMachinedHoles > 0
                ? "STEP_FEATURES"
                : partialObservedMachining
                    ? "PARTIAL_STEP_FEATURES"
                    : "NONE";

        // Feature-driven CNC time: travel/approach + drilling depth + optional secondary
        // operations (ream/tap/counterbore/countersink), plus setup/loading and a bounded
        // geometry-complexity allowance. This is intentionally calibratable per shop.
        var drillMinutes = 0.0;
        var reamMinutes = 0.0;
        var tapMinutes = 0.0;
        var boreMinutes = 0.0;
        var secondaryMinutes = 0.0;
        var operationToolGroups = 0;

        foreach (var x in routedHoleOps)
        {
            var h = x.Hole;
            var qty = Math.Max(1, h.Count) * x.Qty;
            var partThickness = PartThickness(x.Part);
            if (!x.Plan.Cnc)
                continue; // ordinary hole remains in thermal-cutting path

            var depth = h.DepthMm > 0 ? h.DepthMm : Math.Max(1, partThickness);
            var approachMin = Math.Max(0, s.CncRapidSecondsPerHole) / 60.0;

            if (x.Plan.Drill)
                drillMinutes += qty * (approachMin + depth / Math.Max(1, s.CncDrillFeedMmMin));

            if (x.Plan.Ream)
                reamMinutes += qty * (approachMin * 0.5 + depth / Math.Max(1, s.CncReamFeedMmMin));
            if (x.Plan.Tap)
                tapMinutes += qty * (approachMin * 0.5 + depth / Math.Max(1, s.CncTapFeedMmMin));
            if (x.Plan.Bore)
                boreMinutes += qty * (approachMin * 0.5 + depth / Math.Max(1, s.CncSecondaryFeedMmMin));
            if (x.Plan.Secondary)
            {
                var secondaryDepth = h.CounterboreDepthMm > 0
                    ? h.CounterboreDepthMm
                    : Math.Max(1.0, Math.Abs(h.MaxDiameterMm - h.DiameterMm) / 2.0);
                secondaryMinutes += qty * (approachMin * 0.5 + secondaryDepth / Math.Max(1, s.CncSecondaryFeedMmMin));
            }
        }

        // Add unresolved 2D/PDF precision operations with a conservative assumed
        // depth. They are never counted twice when STEP already provides the same class.
        var assumedDrawingDepthMm = 15.0;
        var drawingApproachMin = Math.Max(0, s.CncRapidSecondsPerHole) / 60.0;
        var drawingDrillOps = drawingOnlyRequiredDrillOps;
        drillMinutes += drawingDrillOps * (drawingApproachMin + assumedDrawingDepthMm / Math.Max(1, s.CncDrillFeedMmMin));
        reamMinutes += drawingOnlyFitHoles * (drawingApproachMin * 0.5 + assumedDrawingDepthMm / Math.Max(1, s.CncReamFeedMmMin));
        tapMinutes += drawingOnlyThreadedHoles * (drawingApproachMin * 0.5 + assumedDrawingDepthMm / Math.Max(1, s.CncTapFeedMmMin));
        boreMinutes += drawingOnlyBoredHoles * (drawingApproachMin * 0.5 + assumedDrawingDepthMm / Math.Max(1, s.CncSecondaryFeedMmMin));
        secondaryMinutes += drawingOnlySecondaryHoles * (drawingApproachMin * 0.5 + 3.0 / Math.Max(1, s.CncSecondaryFeedMmMin));

        if (drilledHoles + drawingDrillOps > 0) operationToolGroups++;
        if (effectiveFitHoles > 0) operationToolGroups++;
        if (effectiveThreadedHoles > 0) operationToolGroups++;
        if (effectiveBoredHoles > 0) operationToolGroups++;
        if (effectiveSecondaryHoles > 0) operationToolGroups++;
        if (tightGeometricTolerances > 0) operationToolGroups++;

        // CNC 2.1 (R9.0.8): "zamocowania" describe the number of orientations/setups
        // of the machining route, not the number of part groups. Summing 1-3 setups for
        // every STEP group produced absurd values such as 336. Shop rule: usually 2,
        // hard maximum 4; 3-4 require strong multi-side/complexity evidence.
        var setupCount = 0.0;
        var strongestSetupCount = 0;
        var removedVolumeCm3 = 0.0;
        var repeatedSetupMinutes = 0.0;
        foreach (var part in machiningGroups)
        {
            var qty = Math.Max(1, part.Quantity);
            var sideDrivers = 1;
            if (geometryFeaturesReliableForRouting)
            {
                if (part.CylindricalFaceCount >= 4 || part.Holes.Count >= 4) sideDrivers = 2;
                if (part.FaceCount >= 60 || part.Holes.Any(h => h.DepthMm > Math.Max(12, h.DiameterMm * 5))) sideDrivers = 3;
                if (part.FaceCount >= 120 && part.CylindricalFaceCount >= 12 && part.Holes.Sum(h => h.Count) >= 8) sideDrivers = 4;
            }
            // Below 80% coverage use one setup for observed features; do not infer
            // additional orientations from topology of an incomplete assembly.
            strongestSetupCount = Math.Max(strongestSetupCount, sideDrivers);

            if (geometryFeaturesReliableForRouting)
            {
                var dims = new[] { part.Xmm, part.Ymm, part.Zmm }.Select(x => Math.Max(0, x)).ToArray();
                var bboxVolume = dims[0] * dims[1] * dims[2];
                var fill = bboxVolume > 1 ? Math.Clamp(part.VolumeMm3Each / bboxVolume, 0, 1) : 1;
                // Avoid pretending that plate/profile blank voids are milled away. Apply volume
                // removal only to plausible machined blocks/shafts with sufficiently filled bbox.
                var cls = part.Classification ?? "";
                var plausibleBlock = !cls.Contains("Blacha", StringComparison.OrdinalIgnoreCase) &&
                                     !cls.Contains("Profil", StringComparison.OrdinalIgnoreCase) &&
                                     !cls.Contains("Rura", StringComparison.OrdinalIgnoreCase) &&
                                     fill >= 0.35 && fill <= 0.995;
                if (plausibleBlock)
                    removedVolumeCm3 += Math.Max(0, bboxVolume - part.VolumeMm3Each) / 1000.0 * qty;
            }

            if (qty > 1)
            {
                // Repeated identical parts do not create a new orientation each time.
                // Keep only a small bounded allowance for first-piece/series handling;
                // loading time below already scales with every physical part.
                var repeatDiscount = Math.Clamp(s.CncSetupRepeatDiscountPercent / 100.0, 0, 0.95);
                var exponent = Math.Clamp(s.SeriesSetupExponent, 0.5, 1.0);
                var runFactor = Math.Max(Math.Clamp(s.SeriesMinimumRunFactor, 0.2, 1.0), Math.Pow(qty, exponent - 1.0));
                var allowance = Math.Max(0, s.CncAdditionalSetupMinutes) * (1.0 - repeatDiscount) * runFactor;
                repeatedSetupMinutes = Math.Max(repeatedSetupMinutes, allowance);
            }
        }
        if (hasMachining)
        {
            setupCount = machiningGroups.Count == 0 ? 1 : Math.Clamp(strongestSetupCount, 1, 4);
            // Tight GD&T normally requires at least a second orientation/alignment, but
            // never lets the heuristic exceed the shop hard limit of four setups.
            if ((tightGeometricTolerances > 0 || effectiveFitHoles >= 4) && setupCount < 2)
                setupCount = 2;
            // Post-weld machining is an assembly operation: include a dedicated alignment
            // setup, but do not multiply loading by every pre-weld STEP body.
            if (postWeldMachining && result.Geometry.SolidCount >= 2)
                setupCount = Math.Max(setupCount, 2);
        }
        repeatedSetupMinutes = Math.Min(repeatedSetupMinutes, Math.Max(0, s.CncAdditionalSetupMinutes));
        var projectRunQtyCnc = Math.Clamp(result.Drawing.ProjectQuantityHint ?? 1.0, 1.0, 10000.0);
        var projectSeriesFactorCnc = projectRunQtyCnc > 1
            ? Math.Max(Math.Clamp(s.SeriesMinimumRunFactor, 0.2, 1.0), Math.Pow(projectRunQtyCnc, Math.Clamp(s.SeriesSetupExponent, 0.5, 1.0) - 1.0))
            : 1.0;
        var setupMinutesCnc = setupCount * Math.Max(0, s.CncSetupMinutesPerPartGroup) * projectSeriesFactorCnc + repeatedSetupMinutes;
        if (hasMachining && machiningGroups.Count == 0)
            setupMinutesCnc = Math.Max(setupMinutesCnc, s.CncSetupMinutesPerPartGroup);
        var loadMinutesCnc = machiningPartQty * Math.Max(0, s.CncLoadMinutesPerPart);
        // FIX14 setup/program clustering: families with the same coarse envelope,
        // classification and machining feature mix can reuse one program/fixture plan.
        // Quantity never multiplies programming; clearly different families remain separate.
        var programmingClusterCount = machiningGroups
            .Select(part => new
            {
                Class = (part.Classification ?? "").Trim().ToUpperInvariant(),
                X = (int)Math.Round(part.Xmm / 5.0),
                Y = (int)Math.Round(part.Ymm / 5.0),
                Z = (int)Math.Round(part.Zmm / 5.0),
                Holes = part.Holes.Sum(h => Math.Max(1, h.Count)),
                Precision = part.Holes.Count(h => h.RequiresCnc || h.FitConfirmed || h.ReamedLikely || !string.IsNullOrWhiteSpace(h.ThreadCode))
            })
            .Distinct()
            .Count();
        var programmingGroupCount = postWeldMachining
            ? (hasMachining ? 1 : 0)
            : Math.Max(0, programmingClusterCount);
        var programmingMinutes = Math.Min(900.0, programmingGroupCount * Math.Max(0, s.CncProgrammingMinutesPerUniqueGroup) * projectSeriesFactorCnc);
        var toolChangeMinutes = operationToolGroups * Math.Max(0, s.CncToolChangeSeconds) / 60.0;
        var complexityMinutes = geometryFeaturesReliableForRouting && !postWeldMachining
            ? result.Geometry.Parts.Sum(x =>
                Math.Max(0, x.FaceCount - 12) * Math.Max(1, x.Quantity) / 100.0 * Math.Max(0, s.CncComplexityMinutesPer100Faces))
            : 0.0;
        var removalMinutes = removedVolumeCm3 / Math.Max(1, s.CncRemovalRateCm3Min);
        // Tight GD&T/dimensional requirements require probing/alignment/measurement even
        // when the drawing is the only geometry source. Keep this bounded and explicit.
        var toleranceMinutes = Math.Min(120.0, tightDimensionalTolerances * 4.0 + tightGeometricTolerances * 8.0);

        var cncMinutes = setupMinutesCnc + loadMinutesCnc + programmingMinutes + toolChangeMinutes +
                         drillMinutes + reamMinutes + tapMinutes + boreMinutes + secondaryMinutes +
                         complexityMinutes + removalMinutes + toleranceMinutes;
        if (watchdogFeaturesPartial && !drawingPrecisionEvidence && !machiningKeyword)
        {
            // Partial STEP: price only what was actually observed in completed feature
            // groups. Keep one setup + loading/tool/feature time; explicitly discard
            // bbox stock-removal and face-complexity extrapolation for unknown groups.
            var observedFeatureMinutes = loadMinutesCnc + toolChangeMinutes +
                                         drillMinutes + reamMinutes + tapMinutes + boreMinutes + secondaryMinutes;
            var minimumSetupMinutes = hasMachining
                ? Math.Max(21.0, Math.Max(0, s.CncSetupMinutesPerPartGroup))
                : 0.0;
            cncMinutes = hasMachining ? minimumSetupMinutes + observedFeatureMinutes : 0.0;
        }
        var cncHours = cncMinutes / 60.0;
        var cncGeometryFeatures = routedHoleOps.Where(x => x.Plan.Cnc).ToList();
        var featureDepthCoverage = cncGeometryFeatures.Count == 0 ? 0 :
            cncGeometryFeatures.Count(x => x.Hole.DepthMm > 0) / (double)cncGeometryFeatures.Count;
        var drawingOnlyMachining = !result.Geometry.Available && drawingPrecisionEvidence;
        var genericDrawingCutCandidates = Math.Max(0, drawingHoleCount - drawingPlans.Sum(x => x.Plan.Cnc ? x.Qty : 0));
        var thermalOrCutCandidateHoles = Math.Max(thermalGeometryHoles, genericDrawingCutCandidates);

        p.Add(new ProcessEstimate
        {
            Code = "CNC",
            Name = "Obróbka CNC",
            Enabled = hasMachining,
            Hours = Round(Math.Max(hasMachining ? 0.35 : 0, cncHours)),
            RatePlnPerHour = s.MachiningRatePlnH,
            Confidence = postWeldMachining && featureDepthCoverage >= 0.7 ? 82
                : postWeldMachining ? 68
                : machiningKeyword && featureDepthCoverage >= 0.7 ? 90
                : featureDepthCoverage >= 0.7 && holeCount > 0 ? 89
                : drawingOnlyMachining && (tightGeometricTolerances > 0 || effectiveFitHoles > 0) ? 78
                : drawingOnlyMachining ? 70
                : machiningKeyword ? 74
                : effectiveHoleCount >= 4 ? 80
                : partialObservedMachining ? 48
                : hasMachining ? 68 : 35,
            Basis =
                $"Poziom dowodów CNC: {cncEvidenceLevel}; cechy CNC: otwory {effectiveHoleCount} (wiercone {effectivePlainHoles}, rozwiercane {effectiveFitHoles}, gwintowane {effectiveThreadedHoles}, wytaczane {effectiveBoredHoles}, wtórne {effectiveSecondaryHoles}); " +
                $"otwory termiczne / kandydaci z 2D: {thermalOrCutCandidateHoles}; " +
                $"tolerancje ciasne: wymiarowe {tightDimensionalTolerances}, kształtu/położenia {tightGeometricTolerances}; " +
                $"zamocowania≈{setupCount:0.#}; setup {setupMinutesCnc:0.#} min; programowanie/oprzyrządowanie {programmingMinutes:0.#} min dla {programmingGroupCount} klastrów ({machiningGroups.Count} rodzin); załadunek {loadMinutesCnc:0.#} min; " +
                $"usuwanie materiału≈{removedVolumeCm3:0} cm³ / {removalMinutes:0.#} min; wiercenie {drillMinutes:0.#} min; " +
                $"rozwiercanie {reamMinutes:0.#} min; gwintowanie {tapMinutes:0.#} min; wytaczanie {boreMinutes:0.#} min; operacje wtórne {secondaryMinutes:0.#} min; " +
                $"tolerancje/pomiar {toleranceMinutes:0.#} min; złożoność geometrii {complexityMinutes:0.#} min. " +
                $"Pokrycie rzeczywistą głębokością cech: {featureDepthCoverage:P0}." +
                (postWeldMachining
                    ? $" Dokumentacja wymaga obróbki po spawaniu; dobór stanowiska liczony dla złożenia {result.Geometry.BoundingXmm:0.#}×{result.Geometry.BoundingYmm:0.#}×{result.Geometry.BoundingZmm:0.#} mm / {(result.WeightKg ?? 0):0.#} kg."
                    : "") +
                (!geometryFeaturesReliableForRouting
                    ? $" DS Estimate 1.0: analiza STEP zakończyła się checkpointem/watchdogiem (pokrycie unikalnych grup {stepFeatureCoverage:P0} < 80%); liczone są wyłącznie rzeczywiście rozpoznane cechy + pojedynczy setup. Topologia, bbox-removal i złożoność nie są ekstrapolowane na nieprzeanalizowaną część modelu."
                    : "") +
                (drawingOnlyMachining ? " Routing CNC wynika z PDF/DXF bez STEP — czas ma obniżoną pewność." : "") +
                (projectRunQtyCnc > 1 ? $" Seria {projectRunQtyCnc:0.#} szt.: setup/programowanie ×{projectSeriesFactorCnc:0.###} (bez cichego mnożenia geometrii)." : "")
        });

        // FIX12B: manual machining/deburring/measurement around CNC is kept as a
        // separate cost centre (3205). It is driven by the actual number of machined
        // parts and precision/secondary features, not by a fixed project multiplier.
        var manualMachiningMinutes = hasMachining
            ? machiningPartQty * Math.Max(0, s.CncManualMinutesPerMachinedPart) +
              effectiveHoleCount * Math.Max(0, s.CncManualMinutesPerPrecisionHole) +
              effectiveSecondaryHoles * Math.Max(0, s.CncManualMinutesPerSecondaryHole) +
              Math.Min(90.0, Math.Max(0, result.WeightKg ?? 0) / 1000.0 * 35.0)
            : 0.0;
        p.Add(new ProcessEstimate
        {
            Code = "CNC_MANUAL",
            Name = "Obróbka mechaniczna - operacje ręczne",
            Enabled = manualMachiningMinutes >= 15.0,
            Hours = Round(manualMachiningMinutes / 60.0),
            RatePlnPerHour = s.MachiningRatePlnH,
            Confidence = hasMachining ? Math.Min(82, Math.Max(58, 55 + effectiveHoleCount / 4)) : 35,
            Basis = $"FIX12B: {machiningPartQty} obrabianych instancji; {effectiveHoleCount} cech precyzyjnych; {effectiveSecondaryHoles} operacji wtórnych; gratowanie, pomiar, znakowanie i obsługa międzyoperacyjna."
        });

        var paint = result.Painting;

        p.Add(new ProcessEstimate
        {
            Code = "SURF",
            Name = "Malowanie / przygotowanie powierzchni",
            Enabled = paint.Enabled,
            Hours = Round(paint.TotalHours),
            RatePlnPerHour = s.PaintingRatePlnH,
            Confidence = paint.Confidence,
            Basis = paint.Enabled
                ? $"{paint.Basis} Przygotowanie {paint.SurfacePrepHours:0.###} h + aplikacja {paint.ApplicationHours:0.###} h + manipulacja {paint.HandlingHours:0.###} h. " +
                  $"Przygotowanie: {(string.IsNullOrWhiteSpace(paint.SurfacePreparation) ? "nie rozpoznano" : paint.SurfacePreparation)}; " +
                  $"klasa: {(string.IsNullOrWhiteSpace(paint.CorrosionClass) ? "—" : paint.CorrosionClass)}; kolor: {(string.IsNullOrWhiteSpace(paint.Colour) ? "—" : paint.Colour)}."
                : paint.PaintableAreaM2 > 0
                    ? $"Brak jednoznacznego wymagania malowania w dokumentacji. Powierzchnia {paint.PaintableAreaM2:0.###} m² jest jednak dostępna; w zakładce Proces można ręcznie włączyć operację i skorygować czas/stawkę."
                    : "Brak jednoznacznego wymagania malowania w dokumentacji."
        });

        var hasAssembly = result.Geometry.SolidCount >= 2;
        // Use structural joint classes, not every tolerance-threshold contact.
        // Weld fit-up is already represented in the weld model, so assembly joint
        // time is driven mainly by non-weld/bolted candidates plus bounded part
        // handling. This prevents the same fit-up burden being costed twice.
        var nonWeldJointPairs = Math.Max(0, result.Geometry.PossibleBoltedJointPairs);
        var totalContactPairs = Math.Max(nonWeldJointPairs, result.Geometry.ContactPairs);
        var assemblyPartMinutes = Math.Max(0, partQty - 1) * Math.Max(0, s.AssemblyMinutesPerPart);
        var assemblyContactMinutes = totalContactPairs * Math.Max(0, s.AssemblyMinutesPerContact);
        var assemblyHandlingMinutes = Math.Max(0, result.WeightKg ?? 0) / 1000.0 * Math.Max(0, s.AssemblyHeavyHandlingMinutesPer1000Kg);
        var maxEnvelopeM = Math.Max(result.Geometry.BoundingXmm, Math.Max(result.Geometry.BoundingYmm, result.Geometry.BoundingZmm)) / 1000.0;
        var assemblyEnvelopeMinutes = Math.Max(0, maxEnvelopeM) * Math.Max(0, s.AssemblyLargeEnvelopeMinutesPerMeter);
        var assemblyHours = (assemblyPartMinutes + assemblyContactMinutes + assemblyHandlingMinutes + assemblyEnvelopeMinutes) / 60.0;

        p.Add(new ProcessEstimate
        {
            Code = "ASSY",
            Name = "Montaż / dopasowanie",
            Enabled = hasAssembly,
            Hours = Round(Math.Max(hasAssembly ? 0.4 : 0, assemblyHours)),
            RatePlnPerHour = s.AssemblyRatePlnH,
            Confidence = result.Geometry.ContactPairs > 0 ? 72 : hasAssembly ? 58 : 35,
            Basis = $"FIX12B Fabrication Complexity: bryły {result.Geometry.SolidCount}; styki {result.Geometry.ContactPairs}; pary nieweldowane/śrubowe {nonWeldJointPairs}; obsługa części {assemblyPartMinutes:0.#} min + ustalanie/styki {assemblyContactMinutes:0.#} min + ciężar {assemblyHandlingMinutes:0.#} min + gabaryt {assemblyEnvelopeMinutes:0.#} min."
        });

        foreach (var process in p)
        {
            process.BaseHours = process.Hours;
            process.CalibrationFactor = 1.0;
        }

        return p;
    }

    private static List<RiskItem> BuildRisks(
        AnalysisResult r,
        double? manualWeight,
        double? geometryWeight)
    {
        var risks = new List<RiskItem>();

        if (r.Material == "Nie rozpoznano")
        {
            risks.Add(new RiskItem
            {
                Code = "MATERIAL",
                Level = RiskLevel.High,
                Title = "Nieznany gatunek materiału",
                Message = $"Masa może być liczona przy gęstości zastępczej {r.DensityKgM3:0} kg/m³, ale cena materiału i technologia wymagają właściwego gatunku.",
                Blocking = true
            });
        }

        if (r.Material.StartsWith("MIXED:", StringComparison.OrdinalIgnoreCase) && r.DensityAssumed)
        {
            risks.Add(new RiskItem
            {
                Code = "MIXED_MATERIAL_DENSITY",
                Level = RiskLevel.High,
                Title = "Złożenie z wielu materiałów — masa wymaga potwierdzenia",
                Message = "BOM wskazuje kilka rodzin materiałowych. Bez jawnej masy BOM albo mapowania materiału do objętości każdej części program nie tworzy sztucznej średniej gęstości; masa z objętości STEP pozostaje szacunkiem.",
                Blocking = r.WeightSource.Equals("STEP", StringComparison.OrdinalIgnoreCase)
            });
        }

        if (!r.Geometry.Available)
        {
            var stepWasProvided = r.Package.DocumentGroups.Any(group => group.StepFiles.Count > 0);
            risks.Add(new RiskItem
            {
                Code = "GEOMETRY",
                Level = RiskLevel.High,
                Title = stepWasProvided
                    ? "Brak pełnej analizy geometrii STEP"
                    : "Nie dostarczono modelu STEP",
                Message = stepWasProvided
                    ? "Silnik CAD nie zwrócił poprawnej geometrii dostarczonego modelu. Wycena nie powinna opierać się wyłącznie na analizie tekstowej."
                    : "Paczka nie zawiera aktywnego modelu STEP/STP. Wycena korzysta z PDF, DXF i BOM, dlatego geometrię oraz zakres prac trzeba potwierdzić przed zatwierdzeniem.",
                Blocking = true
            });
        }

        var stepFeatureCoverage = r.Geometry.UniquePartGroups > 0
            ? Math.Clamp(r.Geometry.FullyAnalyzedUniqueSolids / (double)r.Geometry.UniquePartGroups, 0, 1)
            : r.Geometry.WatchdogTriggered ? 0 : 1;
        if (r.Geometry.Available && r.Geometry.WatchdogTriggered && stepFeatureCoverage < 0.80)
        {
            risks.Add(new RiskItem
            {
                Code = "STEP_FEATURES_PARTIAL",
                Level = stepFeatureCoverage < 0.05 ? RiskLevel.High : RiskLevel.Medium,
                Title = "Niepełna analiza STEP po watchdogu",
                Message = stepFeatureCoverage >= 0.999
                    ? "Cechy detali STEP zostały zachowane w progresywnym checkpointcie, ale watchdog przerwał późniejszą analizę styków/spoin/dostępności powierzchni. Otwory i fazy mogą być użyte do routingu, natomiast brak styków/spoin nie jest traktowany jako potwierdzone zero."
                    : $"Podstawowa geometria (bryły, masa, gabaryt i objętość) została zachowana, a pełne cechy wykonania objęły {stepFeatureCoverage:P0} unikalnych grup. Poniżej 80% program nie wylicza pełnych godzin CNC z samej topologii ani z częściowego zestawu cech; bez niezależnego PDF/BOM pozostaje tylko minimalny setup i ostrzeżenie.",
                Blocking = stepFeatureCoverage < 0.05
            });
        }

        var activeStepFiles = r.Package.DocumentGroups
            .SelectMany(x => x.StepFiles)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        var assemblyRelationEstablished = r.Geometry.Warnings.Any(x =>
            x.Contains("Assembly Root", StringComparison.OrdinalIgnoreCase) ||
            x.Contains("bez dublowania masy", StringComparison.OrdinalIgnoreCase));
        if (activeStepFiles.Count is >= 2 and <= 4 && !assemblyRelationEstablished)
        {
            var multiRootDecision = r.Package.MultiRootDecision?.Trim().ToUpperInvariant() ?? "";
            if (multiRootDecision == "SUBASSEMBLIES")
            {
                risks.Add(new RiskItem
                {
                    Code = "MULTI_ROOT_CONFIRMED",
                    Level = RiskLevel.Info,
                    Title = "Relacja wielu STEP potwierdzona",
                    Message = $"Użytkownik potwierdził, że {activeStepFiles.Count} główne modele STEP są współistniejącymi podzespołami. Geometria i masa mogą być agregowane razem: {string.Join(", ", activeStepFiles.Take(4))}.",
                    Blocking = false
                });
            }
            else
            {
                var variants = multiRootDecision == "VARIANTS";
                var separate = multiRootDecision == "SEPARATE_QUOTES";
                risks.Add(new RiskItem
                {
                    Code = "MULTI_ROOT_STEP",
                    Level = RiskLevel.High,
                    Title = variants ? "Warianty STEP potwierdzone — cena zbiorcza nieważna"
                        : separate ? "Utworzono osobne wyceny dla głównych STEP"
                        : "Kilka niezależnych głównych modeli STEP",
                    Message = variants
                        ? $"Użytkownik oznaczył {activeStepFiles.Count} modele STEP jako alternatywne warianty. Bieżąca agregacja nie może być zatwierdzona jako jedna cena; wybierz „Osobne wyceny”."
                        : separate
                            ? $"Główne STEP-y zostały oznaczone do osobnych wycen. Bieżący projekt zbiorczy pozostaje tylko audytem paczki i nie powinien być zatwierdzany jako jedna oferta."
                            : $"Paczka zawiera {activeStepFiles.Count} aktywne modele STEP bez potwierdzonej relacji główne złożenie–składnik: {string.Join(", ", activeStepFiles.Take(4))}. Ich geometria jest obecnie agregowana, dlatego przed zatwierdzeniem ceny trzeba potwierdzić, czy są to współistniejące podzespoły, czy alternatywne warianty/eksporty.",
                    Blocking = true
                });
            }
        }

        if (!r.WeightKg.HasValue)
        {
            risks.Add(new RiskItem
            {
                Code = "WEIGHT",
                Level = RiskLevel.High,
                Title = "Brak masy",
                Message = "Nie ma masy ręcznej ani możliwej do obliczenia z objętości STEP.",
                Blocking = true
            });
        }

        if (manualWeight.HasValue && geometryWeight.HasValue)
        {
            var diff = Math.Abs(manualWeight.Value - geometryWeight.Value) /
                       Math.Max(manualWeight.Value, 1) * 100.0;

            if (diff > 8)
            {
                risks.Add(new RiskItem
                {
                    Code = "WEIGHT_DIFF",
                    Level = RiskLevel.Medium,
                    Title = "Rozbieżność masy",
                    Message = $"Masa ręczna różni się od masy geometrycznej o {diff:0.#}%.",
                    Blocking = false
                });
            }
        }

        if (r.Drawing.ExtractedTextLength < 30)
        {
            risks.Add(new RiskItem
            {
                Code = "DRAWING",
                Level = RiskLevel.Medium,
                Title = "Mało danych z rysunków",
                Message = "Nie znaleziono wystarczającej warstwy tekstowej/OCR. Normy, badania i wymagania powierzchniowe mogą być pominięte.",
                Blocking = false
            });
        }

        if (r.Drawing.OcrCriticalConflicts.Count > 0)
        {
            risks.Add(new RiskItem
            {
                Code = "OCR_CROSSCHECK",
                Level = RiskLevel.Medium,
                Title = "Sprzeczne odczyty OCR",
                Message = "Dwa niezależne przebiegi OCR zwróciły różne wartości krytyczne: " + string.Join("; ", r.Drawing.OcrCriticalConflicts.Take(4)) + ". Wartość należy potwierdzić z warstwy tekstowej/STEP lub rysunku.",
                Blocking = false
            });
        }

        if (r.Drawing.OcrCriticalConfidence is < 70)
        {
            var tokens = r.Drawing.OcrLowConfidenceSignals.Count > 0
                ? $" Niskopewne tokeny: {string.Join(", ", r.Drawing.OcrLowConfidenceSignals.Take(8))}."
                : "";
            risks.Add(new RiskItem
            {
                Code = "OCR_CONFIDENCE",
                Level = RiskLevel.Medium,
                Title = "Niska pewność krytycznych danych OCR",
                Message = $"Średnia pewność OCR dla oznaczeń liczbowych/technicznych wynosi {r.Drawing.OcrCriticalConfidence:0}%. Średnice, tolerancje, RAL i DFT wymagają weryfikacji.{tokens}",
                Blocking = false
            });
        }

        if (r.Dxf.Warnings.Any(x => x.Contains("DXF_UNITS_UNKNOWN", StringComparison.OrdinalIgnoreCase)))
        {
            risks.Add(new RiskItem
            {
                Code = "DXF_UNITS",
                Level = RiskLevel.Medium,
                Title = "Nieznane jednostki DXF",
                Message = "DXF zawiera geometrię, ale nie ma wiarygodnej informacji o jednostkach ($INSUNITS). Długość cięcia nie została użyta automatycznie do czasu procesu.",
                Blocking = false
            });
        }

        if (r.Dxf.GeometryMeasurementReliable && r.Dxf.OpenPathCount > 0)
        {
            risks.Add(new RiskItem
            {
                Code = "DXF_OPEN_PATHS",
                Level = RiskLevel.Low,
                Title = "Otwarte komponenty geometrii DXF",
                Message = $"DXF zawiera {r.Dxf.OpenPathCount} otwartych komponentów po połączeniu stykających się LINE/ARC. Mogą to być szczeliny w konturze albo geometria technologiczna; zweryfikuj przed ofertą.",
                Blocking = false
            });
        }

        if (r.Dxf.GeometryMeasurementReliable && r.Dxf.MarkingLengthMm > 0)
        {
            risks.Add(new RiskItem
            {
                Code = "DXF_MARKING",
                Level = RiskLevel.Low,
                Title = "Wykryto znakowanie / etching w DXF",
                Message = $"Warstwy MARK/ETCH/SCRIBE zawierają ok. {r.Dxf.MarkingLengthMm / 1000.0:0.###} m geometrii. Została odseparowana od długości cięcia, ale nie jest jeszcze automatycznie wyceniana bez profilu konkretnej technologii znakowania.",
                Blocking = false
            });
        }

        if (r.Geometry.TotalHoleCount > 0 && !HasKeyword(r.Drawing, "H7", "H8", "TOL", "RA "))
        {
            risks.Add(new RiskItem
            {
                Code = "HOLE_TOL",
                Level = RiskLevel.Low,
                Title = "Otwory bez rozpoznanych tolerancji",
                Message = $"Geometria sugeruje {r.Geometry.TotalHoleCount} fizycznych otworów, ale nie znaleziono danych o tolerancji/chropowatości.",
                Blocking = false
            });
        }

        var uncertainCylinders = r.Geometry.Parts
            .Sum(x => x.UncertainCylindricalFaceCount * x.Quantity);

        if (uncertainCylinders > 0)
        {
            risks.Add(new RiskItem
            {
                Code = "HOLE_UNCERTAIN",
                Level = RiskLevel.Low,
                Title = "Niejednoznaczne powierzchnie cylindryczne",
                Message = $"Hole Engine 2.0 odrzucił {uncertainCylinders} niejednoznacznych powierzchni zamiast automatycznie uznać je za otwory.",
                Blocking = false
            });
        }

        if (r.Geometry.PossibleBoltedJointPairs > 0)
        {
            risks.Add(new RiskItem
            {
                Code = "BOLTED_PATTERN",
                Level = RiskLevel.Low,
                Title = "Możliwe połączenie śrubowe",
                Message = $"Geometria wykryła {r.Geometry.PossibleBoltedJointPairs} par dolegających części ze współosiowymi otworami przelotowymi. Automatyczne wnioskowanie spawania dla tych par zostało wyłączone; dokumentacja może je ponownie potwierdzić.",
            });
        }

        if (r.Geometry.SurfaceAccessibilityLimitReached &&
            !(r.Drawing.ResolvedFamilyScopeEnforced &&
              r.Drawing.ResolvedStepFamilyMatchCount < r.Drawing.ResolvedRootBomFamilyCount &&
              r.Drawing.HybridSurfaceAreaM2 is > 0))
        {
            risks.Add(new RiskItem
            {
                Code = "SURFACE_ACCESS_LIMIT",
                Level = RiskLevel.Low,
                Title = "Konserwatywna powierzchnia malowania",
                Message = "Złożenie ma zbyt wiele ścian dla pełnej analizy dostępności powierzchni. Zamknięte komory mogły nie zostać odjęte od powierzchni malowania.",
            });
        }

        var weldProcess = r.Processes.FirstOrDefault(x => x.Code == "WELD");
        var weldConfirmedByDocs =
            HasKeyword(r.Drawing, "WELD", "SPAW", "ISO 5817") ||
            !string.IsNullOrWhiteSpace(r.Drawing.WeldTypeHint) ||
            !string.IsNullOrWhiteSpace(r.Drawing.WeldProcessCode) ||
            r.Drawing.WeldSizeMm.HasValue;
        if (weldProcess?.Enabled == true &&
            !weldConfirmedByDocs &&
            r.Geometry.WeldCandidatePairs > 0)
        {
            risks.Add(new RiskItem
            {
                Code = "WELD_INFERRED",
                Level = RiskLevel.Medium,
                Title = "Spawanie wnioskowane z geometrii",
                Message = $"STEP wskazuje {r.Geometry.WeldCandidatePairs} konstrukcyjnych styków i ok. {r.Geometry.WeldCandidateLengthMm / 1000.0:0.###} m krawędzi możliwej spoiny, ale dokumentacja nie potwierdziła symbolu/uwagi spawalniczej. Zweryfikuj przed ofertą.",
            });
        }

        if (r.Welding.Enabled &&
            r.Drawing.WeldTypeHint == "GROOVE")
        {
            risks.Add(new RiskItem
            {
                Code = "WELD_GROOVE_MODEL",
                Level = RiskLevel.Medium,
                Title = "Spoina doczołowa/rowkowa wymaga geometrii przygotowania",
                Message = "Rozpoznano spoinę doczołową/rowkową. Masa spoiny jest obecnie liczona modelem równoważnym na podstawie wymiaru a/z; dla dokładnej wyceny potrzebne są kąt rowka, szczelina i próg.",
            });
        }

        if (r.Welding.Enabled && r.Welding.SizeAssumed)
        {
            risks.Add(new RiskItem
            {
                Code = "WELD_SIZE_ASSUMED",
                Level = RiskLevel.Medium,
                Title = "Założony wymiar spoiny",
                Message = $"Nie rozpoznano a/z na dokumentacji. Model kosztowy użył domyślnego a={r.Welding.SizeMm:0.##} mm. Zweryfikuj przed ofertą.",
            });
        }

        if (r.Welding.Enabled && !r.Welding.SideCountConfirmed)
        {
            risks.Add(new RiskItem
            {
                Code = "WELD_SIDES_ASSUMED",
                Level = RiskLevel.Medium,
                Title = "Niepotwierdzona liczba stron spoiny",
                Message = "Dokumentacja nie potwierdziła spawania jedno- lub obustronnego. Do czasu przyjęto 1 stronę, więc wynik może być zaniżony przy spoinie obustronnej.",
                Blocking = false
            });
        }

        if (r.Welding.Enabled && r.Welding.AllAround && r.Welding.AllAroundLengthEstimated)
        {
            risks.Add(new RiskItem
            {
                Code = "WELD_ALL_AROUND_EST",
                Level = RiskLevel.Low,
                Title = "Obwód spoiny dookoła oszacowany z geometrii",
                Message = "Dokumentacja potwierdza spoinę all-around. Długość została rozszerzona z bazowej krawędzi Joint Engine do przybliżonego obwodu styku na podstawie pola kontaktu i długości bazowej.",
                Blocking = false
            });
        }

        if (r.Welding.Enabled && r.Welding.Intermittent && !r.Welding.IntermittencyConfirmed)
        {
            risks.Add(new RiskItem
            {
                Code = "WELD_INTERMITTENT",
                Level = RiskLevel.Medium,
                Title = "Spoina przerywana bez rozpoznanego skoku",
                Message = "Dokumentacja sugeruje spoinę przerywaną, ale nie rozpoznano wiarygodnie długości odcinka/skoku. Długość nie została automatycznie zmniejszona.",
            });
        }

        if (r.Painting.CoatingRequired && r.Painting.DftAssumed)
        {
            risks.Add(new RiskItem
            {
                Code = "PAINT_DFT_ASSUMED",
                Level = RiskLevel.Medium,
                Title = "Założona grubość powłoki",
                Message = $"Nie rozpoznano całkowitej DFT. Do zużycia farby użyto ustawienia domyślnego {r.Painting.TotalDftMicron:0.#} µm.",
            });
        }

        if (r.Geometry.JointAnalysisLimitReached)
        {
            risks.Add(new RiskItem
            {
                Code = "JOINT_LIMIT",
                Level = RiskLevel.Medium,
                Title = "Częściowa analiza połączeń",
                Message = "Joint/Surface Engine osiągnął limit analizy ścian. Powierzchnia dolegania, malowania i długość kandydatów spoin wymagają weryfikacji.",
            });
        }

        if (r.Geometry.ContactLimitReached)
        {
            risks.Add(new RiskItem
            {
                Code = "CONTACT_LIMIT",
                Level = RiskLevel.Medium,
                Title = "Niepełna analiza styków",
                Message = "Duże złożenie osiągnęło limit dokładnych sprawdzeń styków. Czas spawania/montażu wymaga weryfikacji.",
                Blocking = false
            });
        }

        foreach (var conflict in r.Drawing.Conflicts.Where(x => !x.IsLocalVariation))
        {
            risks.Add(new RiskItem
            {
                Code = "DATA_CONFLICT",
                Level = conflict.Level,
                Title = $"Sprzeczne dane: {conflict.Field}",
                Message = $"Wartości: {conflict.Values}. Źródła: {conflict.Sources}. {conflict.Resolution}",
                Blocking = false
            });
        }

        if (r.Package.MultipleRevisionsDetected)
        {
            risks.Add(new RiskItem
            {
                Code = "REVISION_CONFLICT",
                Level = r.Package.RevisionSelectionConfident ? RiskLevel.Info : RiskLevel.High,
                Title = r.Package.RevisionSelectionConfident
                    ? "Starsze rewizje pominięte automatycznie"
                    : "Niejednoznaczne rewizje dokumentów",
                Message = r.Package.RevisionSelectionConfident
                    ? $"Wykryto kilka rewizji i automatycznie wybrano najnowsze. Pominięto: {string.Join(", ", r.Package.IgnoredOlderRevisionFiles)}."
                    : $"W paczce wykryto niejednoznaczne rodziny rewizji: {string.Join("; ", r.Package.RevisionFamilies)}. Wynik policzono, ale oznaczenie rewizji wymaga uwagi.",
                Blocking = false
            });
        }

        if (r.Package.SkippedDocumentCount > 0)
        {
            risks.Add(new RiskItem
            {
                Code = "DOCUMENT_SKIPPED",
                Level = RiskLevel.Low,
                Title = "Część plików pominięta",
                Message = $"Pominięto {r.Package.SkippedDocumentCount} z {r.Package.DocumentCount} plików. Analiza pozostałych plików została dokończona.",
                Blocking = false
            });
        }

        if (RequiresPostWeldMachining(r) && r.Processes.Any(x => x.Code == "CNC" && x.Enabled))
        {
            risks.Add(new RiskItem
            {
                Code = "POST_WELD_CNC_SCOPE",
                Level = RiskLevel.Medium,
                Title = "Obróbka CNC po spawaniu — zakres cech wymaga potwierdzenia",
                Message = $"Dokumentacja wskazuje obróbkę po spawaniu. Routing i dobór stanowiska używają gabarytu/masy całego złożenia ({r.Geometry.BoundingXmm:0.#}×{r.Geometry.BoundingYmm:0.#}×{r.Geometry.BoundingZmm:0.#} mm; {(r.WeightKg ?? 0):0.#} kg), ale czas skrawania pozostaje ostrożnym szacunkiem, jeśli nie rozpoznano geometrii obrabianych powierzchni.",
                Blocking = false
            });
        }

        var plateGroupCountForCoverage = r.Geometry.Parts.Count(x =>
            (x.Classification ?? "").Contains("Blacha", StringComparison.OrdinalIgnoreCase) ||
            (x.Classification ?? "").Contains("Płyta", StringComparison.OrdinalIgnoreCase));
        var dxfCoverageGroups = r.Dxf.GeometryMeasurementReliable && r.Dxf.CutLengthMm > 0
            ? Math.Min(plateGroupCountForCoverage, Math.Max(1, r.Dxf.SourceFileCount))
            : 0;
        if (plateGroupCountForCoverage > 1 && dxfCoverageGroups > 0 && dxfCoverageGroups < plateGroupCountForCoverage)
        {
            risks.Add(new RiskItem
            {
                Code = "CUT_PARTIAL_COVERAGE",
                Level = RiskLevel.Medium,
                Title = "DXF pokrywa tylko część rodzin detali",
                Message = $"Zmierzona geometria DXF reprezentuje konserwatywnie {dxfCoverageGroups}/{plateGroupCountForCoverage} rodzin blach STEP. Dla niepokrytych detali koszt cięcia policzono fallbackiem z geometrii STEP zamiast traktować jeden DXF jako cały projekt.",
                Blocking = false
            });
        }

        if (r.Painting.CoatingRequired &&
            string.Equals(r.Painting.Scope, "AUTO", StringComparison.OrdinalIgnoreCase) &&
            r.Painting.GrossAreaM2 > 0.0001 &&
            r.Painting.PaintableAreaM2 / r.Painting.GrossAreaM2 < 0.20)
        {
            var ratio = r.Painting.PaintableAreaM2 / r.Painting.GrossAreaM2;
            risks.Add(new RiskItem
            {
                Code = "PAINT_AREA_LOW_RATIO",
                Level = RiskLevel.Medium,
                Title = "Nietypowo mała powierzchnia malowania",
                Message = $"Automatyczny Surface Engine pozostawił do malowania {r.Painting.PaintableAreaM2:0.###} m² z {r.Painting.GrossAreaM2:0.###} m² brutto ({ratio:P0}). Pewność pola została obniżona; zweryfikuj zamknięte komory i wymagania malowania wnętrz.",
                Blocking = false
            });
        }

        if (!r.RatesConfirmedByCompany)
        {
            risks.Add(new RiskItem
            {
                Code = "RATES_UNVERIFIED",
                Level = RiskLevel.Medium,
                Title = "Stawki kosztowe są robocze",
                Message = $"Profil „{r.PricingProfileName}” nie jest oznaczony jako potwierdzony firmowo. Wynik technologiczny jest liczony normalnie, ale cena pozostaje wstępna do czasu kalibracji stawek.",
                Blocking = false
            });
        }

        return risks;
    }

    private static int CalculateConfidence(AnalysisResult r)
    {
        var score = 22;
        if (r.Geometry.Available) score += 28;
        if (r.WeightKg.HasValue) score += 18;
        if (r.Material != "Nie rozpoznano") score += 12;
        if (r.Drawing.ExtractedTextLength > 100) score += 8;
        if (r.Drawing.Norms.Count > 0) score += 5;
        if (r.Geometry.ContactPairs > 0) score += 4;
        score -= Math.Min(15, r.Drawing.Conflicts.Count(x => !x.IsLocalVariation) * 3);
        if (r.Package.MultipleRevisionsDetected)
            score -= r.Package.RevisionSelectionConfident ? 1 : 8;

        // Analysis completeness is not the same as price certainty. Penalize domains where
        // the documents prove an operation exists but its cost-driving scope/geometry is weak.
        if (RequiresPostWeldMachining(r) && r.Processes.Any(x => x.Code == "CNC" && x.Enabled && x.Confidence < 80))
            score -= 8;
        if (r.Nesting.Available && r.Nesting.MaterialFactor >= 1.70)
            score -= r.Nesting.MaterialFactor >= 2.20 ? 8 : 4;
        if (r.Painting.CoatingRequired && r.Painting.GrossAreaM2 > 0.0001 &&
            r.Painting.PaintableAreaM2 / r.Painting.GrossAreaM2 < 0.20 &&
            string.Equals(r.Painting.Scope, "AUTO", StringComparison.OrdinalIgnoreCase))
            score -= 7;
        if (r.Risks.Any(x => x.Code == "CUT_PARTIAL_COVERAGE"))
            score -= 6;

        return Math.Clamp(score, 15, 97);
    }

    private static int CalculateReadiness(AnalysisResult r)
    {
        var penalty = 0;

        foreach (var risk in r.Risks)
        {
            penalty += risk.Level switch
            {
                RiskLevel.Critical => 30,
                RiskLevel.High => 18,
                RiskLevel.Medium => 9,
                RiskLevel.Low => 3,
                _ => 0
            };
        }

        return Math.Clamp(r.ConfidencePercent - penalty / 2, 10, 99);
    }

    private static string ResolveMaterial(string raw) =>
        string.IsNullOrWhiteSpace(raw) ? "Nie rozpoznano" : raw.Trim().ToUpperInvariant();

    // FIX10K / A4: let a production BOM refine material before applying the default
    // steel density.  Mixed-material assemblies are never collapsed into one fake
    // grade.  If their BOM does not carry a safe explicit mass, the normal mass
    // hierarchy keeps the density assumption visible instead of inventing a weighted
    // density without a reliable part-to-volume mapping.
    private static string ResolveProjectMaterial(DrawingIntelligence drawing)
    {
        var global = ResolveMaterial(drawing.MaterialHint);
        var bomMaterials = drawing.BomItems
            .Where(x => x.Quantity > 0 && !string.IsNullOrWhiteSpace(x.Material))
            .Select(x => ResolveMaterial(x.Material))
            .Where(x => !x.Equals("Nie rozpoznano", StringComparison.OrdinalIgnoreCase))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (bomMaterials.Count == 0)
            return global;

        if (bomMaterials.Count == 1)
        {
            if (global.Equals("Nie rozpoznano", StringComparison.OrdinalIgnoreCase))
                return bomMaterials[0];
            // A generic family marker may be refined by a more specific BOM grade.
            if (IsCompatibleMaterialFamily(global, bomMaterials[0]))
                return bomMaterials[0].Length >= global.Length ? bomMaterials[0] : global;
            return $"MIXED: {global}, {bomMaterials[0]}";
        }

        var families = bomMaterials.Select(MaterialFamilyKey)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        if (families.Count == 1)
        {
            var specific = bomMaterials.OrderByDescending(x => x.Length).First();
            return global.Equals("Nie rozpoznano", StringComparison.OrdinalIgnoreCase) || IsCompatibleMaterialFamily(global, specific)
                ? specific
                : $"MIXED: {global}, {specific}";
        }

        return $"MIXED: {string.Join(", ", bomMaterials.Take(6))}";
    }

    private static bool IsCompatibleMaterialFamily(string left, string right) =>
        MaterialFamilyKey(left).Equals(MaterialFamilyKey(right), StringComparison.OrdinalIgnoreCase);

    private static string MaterialFamilyKey(string material)
    {
        var value = (material ?? "").Trim().ToUpperInvariant();
        if (value.Contains("1.4301") || value.Contains("1.4307") || value.Contains("AISI 304") ||
            value.Contains("1.4401") || value.Contains("1.4404") || value.Contains("1.4571") || value.Contains("AISI 316") ||
            value.Contains("STAINLESS") || value.Contains("NIERDZEW")) return "STAINLESS";
        if (value.Contains("ALUMIN") || value.Contains("EN AW") || value.Contains("AW-") || value.Contains("ALMG") || value.Contains("ALSI") || value.Contains("ALZN") || value.StartsWith("AL ")) return "ALUMINIUM";
        if (value.Contains("COPPER") || value.Contains("MIEDŹ") || value.Contains("MIEDZ") || value.Contains("CU-")) return "COPPER";
        if (value.Contains("BRASS") || value.Contains("MOSIĄDZ") || value.Contains("MOSIADZ") || value.Contains("CUZN")) return "BRASS";
        if (value.Contains("BRONZE") || value.Contains("BRĄZ") || value.Contains("BRAZ") || value.Contains("CUSN")) return "BRONZE";
        if (value.Contains("CAST IRON") || value.Contains("ŻELIWO") || value.Contains("ZELIWO") || value.Contains("GG25") || value.Contains("GJL") || value.Contains("GJS")) return "CAST_IRON";
        if (value.Contains("MAGNESIUM") || value.Contains("MAGNEZ") || value.Contains("AZ31") || value.Contains("AZ91")) return "MAGNESIUM";
        if (value.Contains("TITAN") || value.Contains("TYTAN") || value.StartsWith("TI-")) return "TITANIUM";
        if (value.Contains("PLA") || value.Contains("ABS") || value.Contains("PA12") || value.Contains("PA6") || value.Contains("POM") ||
            value.Contains("POLYCARBONATE") || value.Contains("POLIWĘGLAN") || value.Contains("PTFE") || value.Contains("TEFLON") || value.Contains("PEEK")) return "PLASTIC";
        if (value.Contains("S235")) return "S235";
        if (value.Contains("S275")) return "S275";
        if (value.Contains("S355")) return "S355";
        if (value.Contains("S420")) return "S420";
        if (value.Contains("S460")) return "S460";
        if (value.Contains("S690")) return "S690";
        if (value.Contains("S960")) return "S960";
        if (value.Contains("STEEL") || value.Contains("STAL") || value.Contains("A36") || value.Contains("ST52") || value.Contains("HARDOX") ||
            value.Contains("DOMEX") || value.Contains("WELDOX") || value.Contains("C45") || value.Contains("C35") || value.Contains("42CRMO")) return "STEEL";
        return value;
    }

    private static (double DensityKgM3, bool Assumed) ResolveDensity(string material, double steelDefault)
    {
        // DS Estimate 1.0 baseline: prefer a known material family over the steel
        // fallback. Mixed assemblies keep the density assumption visible unless BOM
        // provides an explicit trusted total mass.
        var normalized = (material ?? "").Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(normalized) ||
            normalized.Equals("NIE ROZPOZNANO", StringComparison.OrdinalIgnoreCase) ||
            normalized.StartsWith("MIXED:", StringComparison.OrdinalIgnoreCase))
            return (steelDefault, true);

        if (normalized.Contains("1.4301") || normalized.Contains("1.4307") || normalized.Contains("AISI 304") || normalized == "304" || normalized.Contains("X5CRNI18"))
            return (7900, false);
        if (normalized.Contains("1.4401") || normalized.Contains("1.4404") || normalized.Contains("1.4571") || normalized.Contains("AISI 316") || normalized == "316")
            return (8000, false);
        if (normalized.Contains("AISI 410") || normalized.Contains("AISI 420") || normalized.Contains("1.400"))
            return (7700, false);

        if (normalized.Contains("PLA")) return (1240, false);
        if (normalized.Contains("ABS")) return (1050, false);
        if (normalized.Contains("PA12")) return (1010, false);
        if (normalized.Contains("PA6")) return (1130, false);
        if (normalized.Contains("POM")) return (1410, false);
        if (normalized.Contains("POLYCARBONATE") || normalized.Contains("POLIWĘGLAN") || normalized.Contains("PC ")) return (1200, false);
        if (normalized.Contains("PTFE") || normalized.Contains("TEFLON")) return (2200, false);
        if (normalized.Contains("PEEK")) return (1300, false);

        var aluminiumTokens = new[]
        {
            "ALUMIN", "ALUMINIUM", "ALUMINUM", "EN AW", "AW-", "ALMG", "ALSI", "ALZN",
            "5052", "5083", "5754", "6060", "6061", "6063", "6082", "7075", "2017", "2024"
        };
        if (aluminiumTokens.Any(token => normalized.Contains(token, StringComparison.OrdinalIgnoreCase)) ||
            normalized.StartsWith("AL ", StringComparison.OrdinalIgnoreCase))
            return (2700, false);

        // Grade 5 / Ti-6Al-4V is lighter than commercially pure titanium.
        if (normalized.Contains("TI-6AL") || normalized.Contains("TI6AL") || normalized.Contains("GRADE 5") || normalized.Contains("3.7165"))
            return (4430, false);
        if (normalized.Contains("TYTAN") || normalized.Contains("TITAN") || normalized.StartsWith("TI-", StringComparison.OrdinalIgnoreCase))
            return (4510, false);
        if (normalized.Contains("MIEDŹ") || normalized.Contains("MIEDZ") || normalized.Contains("COPPER") || normalized.Contains("CU-ETP") || normalized.Contains("CU-DHP") || normalized.Contains("CU-"))
            return (8960, false);
        if (normalized.Contains("MOSIĄDZ") || normalized.Contains("MOSIADZ") || normalized.Contains("BRASS") || normalized.Contains("CUZN"))
            return (8500, false);
        if (normalized.Contains("BRĄZ") || normalized.Contains("BRAZ") || normalized.Contains("BRONZE") || normalized.Contains("CUSN"))
            return (8800, false);
        if (normalized.Contains("ŻELIWO") || normalized.Contains("ZELIWO") || normalized.Contains("CAST IRON") || normalized.Contains("GG25") || normalized.Contains("GJL") || normalized.Contains("GJS"))
            return (7250, false);
        if (normalized.Contains("MAGNEZ") || normalized.Contains("MAGNESIUM") || normalized.Contains("AZ31") || normalized.Contains("AZ91"))
            return (1740, false);

        var knownSteelTokens = new[]
        {
            "S235", "S275", "S355", "S420", "S460", "S500", "S550", "S690", "S960",
            "ASTM A36", "A36", "A572", "A514", "A516", "ST52", "42CRMO", "C45", "C35",
            "HARDOX", "DOMEX", "WELDOX", "STEEL", "STAL", "1.0038", "1.0570", "1.0503"
        };
        if (knownSteelTokens.Any(token => normalized.Contains(token, StringComparison.OrdinalIgnoreCase)))
            return (steelDefault, false);

        return (steelDefault, true);
    }

    private static bool RequiresPostWeldMachining(AnalysisResult r)
    {
        static bool Match(string? value)
        {
            if (string.IsNullOrWhiteSpace(value)) return false;
            return value.Contains("AFTER WELD", StringComparison.OrdinalIgnoreCase) ||
                   value.Contains("POST WELD", StringComparison.OrdinalIgnoreCase) ||
                   value.Contains("POST-WELD", StringComparison.OrdinalIgnoreCase) ||
                   value.Contains("PO SPAW", StringComparison.OrdinalIgnoreCase) ||
                   value.Contains("NACH DEM SCHWEISS", StringComparison.OrdinalIgnoreCase);
        }

        return r.Drawing.Findings.Any(Match) ||
               r.Drawing.Warnings.Any(Match) ||
               r.Drawing.DimensionalTolerances.Any(x => Match(x.SourceText)) ||
               r.Drawing.GeometricTolerances.Any(x => Match(x.SourceText));
    }

    private static bool HasKeyword(DrawingIntelligence d, params string[] tokens) =>
        d.Keywords.Any(k => tokens.Any(t => k.Contains(t, StringComparison.OrdinalIgnoreCase)));

    private static double BuildRecognizedPartialMaterialCost(AnalysisResult result, CostingSettings settings)
    {
        // A complete material cost already exists when project mass is authoritative.
        // Partial reconstruction is only an additional diagnostic when the full offer
        // remains blocked by missing root-project mass/coverage.
        if (result.MaterialCostPln > 0 && result.HasWeight)
            return result.MaterialCostPln;

        var rows = result.Drawing.HybridMassContributions
            .Where(x => x.MassKg > 0.001 && !string.Equals(x.FamilyKey, result.Drawing.ResolvedRootEntityKey, StringComparison.OrdinalIgnoreCase))
            .ToList();
        if (rows.Count == 0)
            return 0;

        double RateFor(string? material)
        {
            var fallback = Math.Max(0, settings.MaterialPricePlnKg);
            var value = (material ?? "").Trim();
            if (string.IsNullOrWhiteSpace(value) || settings.MaterialPriceOverridesPlnKg is not { Count: > 0 })
                return fallback;
            var exact = settings.MaterialPriceOverridesPlnKg.FirstOrDefault(x =>
                string.Equals(x.Key.Trim(), value, StringComparison.OrdinalIgnoreCase));
            if (!string.IsNullOrWhiteSpace(exact.Key) && exact.Value > 0)
                return exact.Value;
            var fuzzy = settings.MaterialPriceOverridesPlnKg
                .Where(x => x.Value > 0)
                .OrderByDescending(x => x.Key.Length)
                .FirstOrDefault(x => value.Contains(x.Key, StringComparison.OrdinalIgnoreCase) ||
                                     x.Key.Contains(value, StringComparison.OrdinalIgnoreCase));
            return !string.IsNullOrWhiteSpace(fuzzy.Key) ? fuzzy.Value : fallback;
        }

        var waste = 1.0 + Math.Max(0, settings.MaterialWastePercent) / 100.0;
        return rows.Sum(x => x.MassKg * RateFor(x.Material)) * waste;
    }

    private static double BuildMaterialCost(AnalysisResult result, CostingSettings settings)
    {
        if (!result.WeightKg.HasValue || result.WeightKg.Value <= 0)
            return 0;

        var defaultPrice = Math.Max(0, settings.MaterialPricePlnKg);
        var price = defaultPrice;
        if (settings.MaterialPriceOverridesPlnKg is { Count: > 0 } && result.MaterialBreakdown.Count > 0)
        {
            double RateFor(string material)
            {
                if (string.IsNullOrWhiteSpace(material) || material == "NIEPRZYPISANE")
                    return defaultPrice;
                var exact = settings.MaterialPriceOverridesPlnKg
                    .FirstOrDefault(x => string.Equals(x.Key.Trim(), material.Trim(), StringComparison.OrdinalIgnoreCase));
                if (!string.IsNullOrWhiteSpace(exact.Key) && exact.Value > 0)
                    return exact.Value;
                var fuzzy = settings.MaterialPriceOverridesPlnKg
                    .Where(x => x.Value > 0)
                    .OrderByDescending(x => x.Key.Length)
                    .FirstOrDefault(x => material.Contains(x.Key, StringComparison.OrdinalIgnoreCase) ||
                                         x.Key.Contains(material, StringComparison.OrdinalIgnoreCase));
                return !string.IsNullOrWhiteSpace(fuzzy.Key) ? fuzzy.Value : defaultPrice;
            }

            var weightedCost = result.MaterialBreakdown.Sum(x => Math.Max(0, x.MassKg) * RateFor(x.Material));
            var breakdownMass = result.MaterialBreakdown.Sum(x => Math.Max(0, x.MassKg));
            if (weightedCost > 0 && breakdownMass > 0)
                price = weightedCost / breakdownMass;
        }
        var fallbackFactor = 1.0 + Math.Max(0, settings.MaterialWastePercent) / 100.0;
        result.Nesting.UsedForMaterialCost = false;
        if (!result.Nesting.Available || result.Nesting.MaterialFactor <= 0)
            return result.WeightKg.Value * price * fallbackFactor;

        // FIX12B: bounding-box shelf packing is not CAM nesting. It receives price
        // authority only in a normal, well-supported range; extreme factors stay
        // diagnostic and cannot multiply the customer's material cost by 2-3x.
        var nestingTrustedForPrice =
            result.Nesting.Confidence >= Math.Clamp(settings.NestingPriceAuthorityMinConfidence, 1, 99) &&
            result.Nesting.MaterialFactor <= Math.Max(1.0, settings.NestingPriceAuthorityMaxFactor);
        if (!nestingTrustedForPrice)
            return result.WeightKg.Value * price * fallbackFactor;

        result.Nesting.UsedForMaterialCost = true;
        var plateMass = result.Geometry.Parts
            .Where(x => (x.Classification ?? "").Contains("Blacha", StringComparison.OrdinalIgnoreCase) ||
                        (x.Classification ?? "").Contains("Płyta", StringComparison.OrdinalIgnoreCase))
            .Sum(x => Math.Max(0, x.MassKgEach) * Math.Max(1, x.Quantity));
        plateMass = Math.Clamp(plateMass, 0, result.WeightKg.Value);
        var nonPlateMass = Math.Max(0, result.WeightKg.Value - plateMass);
        return plateMass * price * Math.Max(1.0, result.Nesting.MaterialFactor) +
               nonPlateMass * price * fallbackFactor;
    }

    private static string BuildMaterialBasis(AnalysisResult r, CostingSettings s)
    {
        if (!r.WeightKg.HasValue)
            return "Brak wiarygodnej masy.";
        var gradeRates = s.MaterialPriceOverridesPlnKg is { Count: > 0 } && r.MaterialBreakdown.Any(x =>
            s.MaterialPriceOverridesPlnKg.Keys.Any(k => !string.IsNullOrWhiteSpace(k) &&
                (string.Equals(k.Trim(), x.Material.Trim(), StringComparison.OrdinalIgnoreCase) ||
                 x.Material.Contains(k, StringComparison.OrdinalIgnoreCase))));
        var gradeNote = gradeRates
            ? $" FIX13: koszt jednostkowy ważony po rozpoznanych gatunkach ({r.MaterialBreakdown.Count} pozycji breakdown)."
            : "";
        if (r.Nesting.Available && r.Nesting.UsedForMaterialCost)
            return $"{r.WeightKg.Value:N1} kg × stawka materiału; blachy: zweryfikowany zakres szacunkowego nestingu {r.Nesting.UtilizationPercent:0.#}% wykorzystania, współczynnik zakup/netto ×{r.Nesting.MaterialFactor:0.##}.{gradeNote}";
        if (r.Nesting.Available)
            return $"{r.WeightKg.Value:N1} kg × stawka materiału + {s.MaterialWastePercent:0.#}% naddatku. Nesting prostokątnych obwiedni (×{r.Nesting.MaterialFactor:0.##}, {r.Nesting.UtilizationPercent:0.#}%) pozostawiono wyłącznie diagnostycznie i NIE użyto go do ceny.{gradeNote}";
        return $"{r.WeightKg.Value:N1} kg × stawka materiału + {s.MaterialWastePercent:0.#}% naddatku (fallback bez rozkroju).{gradeNote}";
    }


    private static double WeightedMedian(IReadOnlyList<(double Value, double Weight)> values)
    {
        var clean = values
            .Where(x => double.IsFinite(x.Value) && double.IsFinite(x.Weight) && x.Weight > 0)
            .OrderBy(x => x.Value)
            .ToList();
        if (clean.Count == 0) return 1.0;
        var total = clean.Sum(x => x.Weight);
        var half = total / 2.0;
        var cumulative = 0.0;
        foreach (var item in clean)
        {
            cumulative += item.Weight;
            if (cumulative >= half)
                return item.Value;
        }
        return clean[^1].Value;
    }

    private static double Median(IReadOnlyList<double> values)
    {
        if (values.Count == 0) return 0;
        var mid = values.Count / 2;
        return values.Count % 2 == 0
            ? (values[mid - 1] + values[mid]) / 2.0
            : values[mid];
    }

    private static double Round(double value) => Math.Round(value, 2);

    private static string NormalizePaintLayerName(string? name)
    {
        if (string.IsNullOrWhiteSpace(name)) return "WARSTWA";
        var value = name.Trim().ToUpperInvariant();
        if (value.Contains("PODKŁAD") || value.Contains("PODKLAD") || value.Contains("PRIMER") || value.Contains("GRUND")) return "PODKLAD";
        if (value.Contains("POŚRED") || value.Contains("POSRED") || value.Contains("INTERMEDIATE") || value.Contains("ZWISCHEN")) return "POSREDNIA";
        if (value.Contains("NAWIERZ") || value.Contains("TOPCOAT") || value.Contains("TOP COAT") || value.Contains("FINISH") || value.Contains("DECKLACK")) return "NAWIERZCHNIA";
        return value;
    }

}
