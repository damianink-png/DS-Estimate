using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace DSEstimate.Core;

public enum DocumentKind { Step, Dxf, Dwg, Pdf, Image, Excel, Other, Text }
public enum DocumentRole { Unknown = 0, Production = 1, Reference = 2, PurchasedItem = 3, SoftwareGraphic = 4, PreviousReport = 5 }
public enum RiskLevel { Info = 0, Low = 1, Medium = 2, High = 3, Critical = 4 }

public sealed class ProjectDocument : INotifyPropertyChanged
{
    private string _status = "Oczekuje";
    private string _summary = "";

    public string Path { get; set; } = "";
    public string Name { get; set; } = "";
    public DocumentKind Kind { get; set; }
    public long SizeBytes { get; set; }
    public string RelativePath { get; set; } = "";
    public string PackageSource { get; set; } = "";
    // SHA-256 calculated by the package importer. It is persisted so renamed,
    // byte-identical files cannot masquerade as independent evidence.
    public string ContentHash { get; set; } = "";
    // Informational only in FIX9.5a. The document remains visible and follows
    // the normal analyzer route; only its vote in Evidence Orchestrator is merged.
    public string ContentDuplicateOf { get; set; } = "";
    public bool IsContentDuplicate => !string.IsNullOrWhiteSpace(ContentDuplicateOf);
    // FIX10: cheap source classification is persisted with the project so report/cost
    // fusion can distinguish manufacturing evidence from references and software assets.
    public DocumentRole Role { get; set; } = DocumentRole.Unknown;
    public int RoleConfidence { get; set; }
    public string RoleReason { get; set; } = "";
    public string ProjectGroupKey { get; set; } = "";
    public string RoleDisplay => Role switch
    {
        DocumentRole.Production => "Dokument produkcyjny",
        DocumentRole.Reference => "Referencja",
        DocumentRole.PurchasedItem => "Element kupowany",
        DocumentRole.SoftwareGraphic => "Oprogramowanie / grafika",
        DocumentRole.PreviousReport => "Poprzedni raport",
        _ => "Niesklasyfikowany"
    };
    public bool IsActiveRevision { get; set; } = true;
    public bool ExcludeFromAnalysis { get; set; }

    public string Status
    {
        get => _status;
        set
        {
            if (_status == value) return;
            _status = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(IsStatusGood));
            OnPropertyChanged(nameof(IsStatusInProgress));
            OnPropertyChanged(nameof(IsStatusPending));
            OnPropertyChanged(nameof(IsStatusWarning));
            OnPropertyChanged(nameof(IsStatusError));
            OnPropertyChanged(nameof(IsStatusNeutral));
            OnPropertyChanged(nameof(StatusDisplay));
        }
    }

    public bool IsStatusGood =>
        string.Equals(Status, "OK", StringComparison.OrdinalIgnoreCase) ||
        string.Equals(Status, "Przeanalizowany", StringComparison.OrdinalIgnoreCase);
    public bool IsStatusInProgress =>
        Status.StartsWith("W toku", StringComparison.OrdinalIgnoreCase) ||
        Status.StartsWith("Analiza", StringComparison.OrdinalIgnoreCase);
    public bool IsStatusPending =>
        string.Equals(Status, "Oczekuje", StringComparison.OrdinalIgnoreCase) ||
        string.Equals(Status, "Gotowy", StringComparison.OrdinalIgnoreCase);
    public bool IsStatusSkippedNoTechnical =>
        Status.StartsWith("Pominięto — brak danych technicznych", StringComparison.OrdinalIgnoreCase);
    public bool IsStatusWarning =>
        Status.StartsWith("Uwaga", StringComparison.OrdinalIgnoreCase) ||
        (!IsStatusSkippedNoTechnical && Status.StartsWith("Pominię", StringComparison.OrdinalIgnoreCase)) ||
        Status.StartsWith("Starsza", StringComparison.OrdinalIgnoreCase) ||
        Status.StartsWith("Części", StringComparison.OrdinalIgnoreCase) ||
        Status.StartsWith("Anul", StringComparison.OrdinalIgnoreCase);
    public bool IsStatusError =>
        Status.StartsWith("Błąd", StringComparison.OrdinalIgnoreCase) ||
        Status.StartsWith("Niedostęp", StringComparison.OrdinalIgnoreCase) ||
        Status.StartsWith("Timeout", StringComparison.OrdinalIgnoreCase);
    public bool IsStatusNeutral =>
        IsStatusSkippedNoTechnical ||
        (!IsStatusGood && !IsStatusInProgress && !IsStatusPending && !IsStatusWarning && !IsStatusError);
    public string StatusDisplay => Status switch
    {
        "OK" => "Przeanalizowany",
        "Gotowy" => "Oczekuje",
        _ => Status
    };

    public bool IsStepKind => Kind == DocumentKind.Step;
    public bool IsDxfKind => Kind == DocumentKind.Dxf;
    public bool IsDwgKind => Kind == DocumentKind.Dwg;
    public bool IsPdfKind => Kind == DocumentKind.Pdf;
    public bool IsImageKind => Kind == DocumentKind.Image;
    public bool IsTableKind => Kind == DocumentKind.Excel;
    public bool IsTextKind => Kind == DocumentKind.Text;
    public bool IsOtherKind => Kind == DocumentKind.Other;

    public string Summary
    {
        get => _summary;
        set
        {
            if (_summary == value) return;
            _summary = value;
            OnPropertyChanged();
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}

public sealed class HoleFeature
{
    public double DiameterMm { get; set; }
    public double MaxDiameterMm { get; set; }
    public double DepthMm { get; set; }
    public int Count { get; set; }
    public bool ThroughLikely { get; set; }
    public bool CounterboreLikely { get; set; }
    public bool SpotfaceLikely { get; set; }
    public double CounterboreDepthMm { get; set; }
    public bool CountersinkLikely { get; set; }
    public double CountersinkAngleDeg { get; set; }
    public int StageCount { get; set; } = 1;
    public string Type { get; set; } = "wewnętrzny";
    public int Confidence { get; set; }
    public string FitCode { get; set; } = "";
    public string ThreadCode { get; set; } = "";
    public bool FitConfirmed { get; set; }
    public bool PrecisionMachined { get; set; }
    public bool ReamedLikely { get; set; }
    public string SemanticType { get; set; } = "";
    // Explicit manufacturing route.  These flags keep drill/ream/tap/bore mutually
    // understandable and prevent a precision/thread callout from silently becoming
    // an unrelated operation in the costing engine.
    public bool RequiresDrill { get; set; }
    public bool RequiresReam { get; set; }
    public bool RequiresTap { get; set; }
    public bool RequiresBore { get; set; }
    public bool RequiresCnc { get; set; }
    public bool CanThermalCut { get; set; }

    public string Display
    {
        get
        {
            var stage = SpotfaceLikely && MaxDiameterMm > DiameterMm
                ? $" / planowanie Ø{MaxDiameterMm:0.##} × {CounterboreDepthMm:0.##}"
                : CounterboreLikely && MaxDiameterMm > DiameterMm
                    ? $" / pogł. walc. Ø{MaxDiameterMm:0.##} × {CounterboreDepthMm:0.##}"
                : CountersinkLikely && MaxDiameterMm > DiameterMm
                    ? $" / pogł. stoż. Ø{MaxDiameterMm:0.##} {CountersinkAngleDeg:0.#}°"
                    : "";
            var kind = ThroughLikely ? "przel." : Type == "nieprzelotowy" ? "ślepy" : Type;
            var semantic = !string.IsNullOrWhiteSpace(ThreadCode) ? $" · gwint {ThreadCode}"
                : FitConfirmed ? $" · pasowany {FitCode}"
                : ReamedLikely ? " · rozwiercany"
                : PrecisionMachined ? " · precyzyjny"
                : "";
            return DepthMm > 0
                ? $"Ø{DiameterMm:0.##}{stage} × {DepthMm:0.#} mm · {Count} szt. · {kind}{semantic}"
                : $"Ø{DiameterMm:0.##}{stage} · {Count} szt. · {kind}{semantic}";
        }
    }
}

public sealed class BevelFeature
{
    public int Count { get; set; }
    public double MinAngleDeg { get; set; }
    public double MaxAngleDeg { get; set; }
    public string Display => Count == 0 ? "—" : $"{Count} · {MinAngleDeg:0.#}–{MaxAngleDeg:0.#}°";
}

public sealed class PartGroup
{
    public string GroupKey { get; set; } = "";
    public string Name { get; set; } = "";
    public string SourceFile { get; set; } = "";
    public string Classification { get; set; } = "Detal";
    public int ClassificationConfidence { get; set; }
    public string ClassificationBasis { get; set; } = "";
    public int Quantity { get; set; } = 1;
    public double Xmm { get; set; }
    public double Ymm { get; set; }
    public double Zmm { get; set; }
    public double VolumeMm3Each { get; set; }
    public double SurfaceMm2Each { get; set; }
    public int FaceCount { get; set; }
    public int EdgeCount { get; set; }
    public int CylindricalFaceCount { get; set; }
    public int InternalCylindricalFaceCount { get; set; }
    public int ExternalCylindricalFaceCount { get; set; }
    public int UncertainCylindricalFaceCount { get; set; }
    public int ConicalFaceCount { get; set; }
    public int PlanarFaceCount { get; set; }
    public int InternalPlanarFaceCount { get; set; }
    public double InternalPaintExcludedMm2Each { get; set; }
    public BevelFeature Bevel { get; set; } = new();
    public int PocketCandidateCount { get; set; }
    public double PocketCandidateAreaMm2 { get; set; }
    public double PocketMaxDepthMm { get; set; }
    public List<HoleFeature> Holes { get; set; } = [];
    public double MassKgEach { get; set; }
    public string DimensionsText => $"{Xmm:0.#} × {Ymm:0.#} × {Zmm:0.#} mm";
    public string ClassificationDisplay => ClassificationConfidence > 0
        ? $"{Classification} · {ClassificationConfidence}%"
        : Classification;
    public string QuantityText => $"× {Quantity}";
    public string MassText => $"{MassKgEach * Quantity:N1} kg";
    public string HoleText => Holes.Count == 0 ? "—" : $"{Holes.Sum(h => h.Count)} otw.";
}

public sealed class JointCandidate
{
    public string SourceFile { get; set; } = "";
    public int BodyA { get; set; }
    public int BodyB { get; set; }
    public string Type { get; set; } = "";
    public double DistanceMm { get; set; }
    public double ContactAreaMm2 { get; set; }
    public double ProjectedJointAreaMm2 { get; set; }
    public double CandidateWeldLengthMm { get; set; }
    public int Confidence { get; set; }
    public bool StructuralCandidate { get; set; }
    public bool PossibleBoltedJoint { get; set; }
    public int MatchingThroughHoles { get; set; }
    public string WeldLengthBasis { get; set; } = "";
    public int PatchCount { get; set; }
    public string Basis { get; set; } = "";
}

public sealed class GeometrySummary
{
    public bool Available { get; set; }
    public int SolidCount { get; set; }
    public int UniquePartGroups { get; set; }
    public int ContactPairs { get; set; }
    public int ContactPairsTight { get; set; }
    public int ContactPairsNominal { get; set; }
    public int ContactCandidatePairs { get; set; }
    public int ContactExactChecks { get; set; }
    public bool ContactLimitReached { get; set; }
    public string HoleEngineVersion { get; set; } = "";
    public string JointEngineVersion { get; set; } = "";
    public string SurfaceEngineVersion { get; set; } = "";
    public string Importer { get; set; } = "";
    public double VolumeMm3 { get; set; }
    public double SurfaceMm2 { get; set; }
    public double ExposedSurfaceMm2 { get; set; }
    public double PaintableSurfaceMm2 { get; set; }
    public double PlanarMatingAreaMm2 { get; set; }
    public double HiddenMatingSurfaceMm2 { get; set; }
    public double InternalPaintExcludedMm2 { get; set; }
    public double SealedCavitySurfaceMm2 { get; set; }
    public int SurfaceAccessibilityCheckedFaces { get; set; }
    public bool SurfaceAccessibilityLimitReached { get; set; }
    public int WeldCandidatePairs { get; set; }
    public int PossibleBoltedJointPairs { get; set; }
    public double WeldCandidateLengthMm { get; set; }
    public bool JointAnalysisLimitReached { get; set; }
    public int JointFaceChecks { get; set; }
    public int FullyAnalyzedUniqueSolids { get; set; }
    public int ReusedSolidAnalyses { get; set; }
    public string AnalysisMode { get; set; } = "full";
    // FIX10: report the same watchdog limit that PythonRunner actually received.
    public bool WatchdogTriggered { get; set; }
    public double? WatchdogLimitSeconds { get; set; }
    public List<JointCandidate> JointCandidates { get; set; } = [];
    public double BoundingXmm { get; set; }
    public double BoundingYmm { get; set; }
    public double BoundingZmm { get; set; }
    public int TotalHoleCount { get; set; }
    public int TotalPocketCandidateCount { get; set; }
    public string PocketEngineVersion { get; set; } = "";
    // 1.1: zero is only authoritative when feature analysis completed.
    public string HoleAnalysisState { get; set; } = "unknown"; // unknown / partial / complete
    public int HoleFallbackCount { get; set; }
    public int TotalBevelFaces { get; set; }
    public List<PartGroup> Parts { get; set; } = [];
    public List<string> Warnings { get; set; } = [];
}


public sealed class HoleRequirementSignal
{
    public double? NominalDiameterMm { get; set; }
    public int Count { get; set; } = 1;
    public string FitCode { get; set; } = "";
    public string ThreadCode { get; set; } = "";
    public string OperationHint { get; set; } = "";
    public bool ReamedLikely { get; set; }
    public bool FitConfirmed { get; set; }
    public bool PrecisionMachined { get; set; }
    public bool RequiresDrill { get; set; }
    public bool RequiresReam { get; set; }
    public bool RequiresTap { get; set; }
    public bool RequiresBore { get; set; }
    public bool RequiresCnc { get; set; }
    public bool CanThermalCut { get; set; }
    public string SourceText { get; set; } = "";
}

public sealed class PaintLayerSignal
{
    public string Name { get; set; } = "";
    public double DftMicron { get; set; }
    public int CoatCount { get; set; } = 1;
}

public sealed class DimensionalToleranceSignal
{
    public string Kind { get; set; } = "";
    public double? PlusMm { get; set; }
    public double? MinusMm { get; set; }
    public double? SymmetricMm { get; set; }
    public bool Tight { get; set; }
    public string SourceText { get; set; } = "";
}

public sealed class GeometricToleranceSignal
{
    public string Type { get; set; } = "";
    public double? ValueMm { get; set; }
    public string Datum { get; set; } = "";
    public bool Tight { get; set; }
    public string SourceText { get; set; } = "";
}

public sealed class InformationConflict
{
    public string Field { get; set; } = "";
    public string Values { get; set; } = "";
    public string Sources { get; set; } = "";
    public string Resolution { get; set; } = "";
    public RiskLevel Level { get; set; } = RiskLevel.Medium;
    // True when different values belong to different drawing/part families and therefore are not a project-wide contradiction.
    public bool IsLocalVariation { get; set; }
}

public sealed class PackageIntelligence
{
    public int DocumentCount { get; set; }
    public int RelevantDocumentCount { get; set; }
    public int NeutralSkippedDocumentCount { get; set; }
    public int SkippedDocumentCount { get; set; }
    public int WarningDocumentCount { get; set; }
    public bool MultipleRevisionsDetected { get; set; }
    public List<string> RevisionSignals { get; set; } = [];
    public List<string> RevisionFamilies { get; set; } = [];
    public List<string> SelectedRevisionFiles { get; set; } = [];
    public List<string> IgnoredOlderRevisionFiles { get; set; } = [];
    public bool RevisionSelectionConfident { get; set; } = true;
    public List<DocumentGroupInfo> DocumentGroups { get; set; } = [];
    // FIX10K / A3: explicit user decision for ambiguous 2-4 root STEP packages.
    // Values: "" (unresolved), SUBASSEMBLIES, VARIANTS, SEPARATE_QUOTES.
    public string MultiRootDecision { get; set; } = "";
    public string RevisionSummary => MultipleRevisionsDetected
        ? RevisionSelectionConfident
            ? $"Wykryto kilka rewizji; automatycznie wybrano najnowsze ({IgnoredOlderRevisionFiles.Count} starszych pominięto)"
            : $"Wykryto kilka niejednoznacznych rewizji: {string.Join(", ", RevisionSignals)}"
        : RevisionSignals.Count > 0
            ? $"Rewizja: {string.Join(", ", RevisionSignals)}"
            : IgnoredOlderRevisionFiles.Count > 0
                ? $"Automatycznie pominięto {IgnoredOlderRevisionFiles.Count} plik(ów) OLD/ARCHIVE"
                : "Brak jawnego oznaczenia rewizji w nazwach plików";
}

public sealed class BomItemSignal
{
    public string PartNumber { get; set; } = "";
    public string Description { get; set; } = "";
    public double Quantity { get; set; } = 1;
    // Optional hierarchy metadata supplied by CAD/ERP BOM exports. Level=0 means
    // flat/unknown; Position preserves the supplier's Pos./Item identifier.
    public int Level { get; set; }
    public string Position { get; set; } = "";
    public double GeometryQuantity { get; set; }
    public bool QuantityMismatch => GeometryQuantity > 0 && Math.Abs(Quantity - GeometryQuantity) > 0.001;
    public string Material { get; set; } = "";
    // Optional mass supplied directly by a BOM/ERP export. This is kept
    // independently from STEP mass so both sources can be cross-checked.
    public double? MassKgEach { get; set; }
    public double? TotalMassKg { get; set; }
    public string SourceFile { get; set; } = "";
    public double EffectiveTotalMassKg => TotalMassKg ?? ((MassKgEach ?? 0) * Math.Max(0, Quantity));
    public string MassText => EffectiveTotalMassKg > 0 ? $"{EffectiveTotalMassKg:0.###} kg" : "—";
    public string Display => string.IsNullOrWhiteSpace(Description)
        ? $"{PartNumber} × {Quantity:0.###}"
        : $"{PartNumber} · {Description} × {Quantity:0.###}";
}


public sealed class SurfaceAreaContribution
{
    public string FamilyKey { get; set; } = "";
    public string SourceKind { get; set; } = "";
    public double AreaM2 { get; set; }
    public double Quantity { get; set; } = 1;
    public double? ThicknessMm { get; set; }
    public int Confidence { get; set; }
    public string Basis { get; set; } = "";
}



public sealed class MassReconstructionContribution
{
    public string FamilyKey { get; set; } = "";
    public string SourceKind { get; set; } = "";
    public string Material { get; set; } = "";
    public double MassKg { get; set; }
    public double Quantity { get; set; } = 1;
    public double? ThicknessMm { get; set; }
    public int Confidence { get; set; }
    public string Basis { get; set; } = "";
}

public sealed class NdtFamilySignal
{
    public string FamilyKey { get; set; } = "";
    public string SourceFile { get; set; } = "";
    public List<string> Methods { get; set; } = [];
    public int Confidence { get; set; }
    public string Basis { get; set; } = "";
}

public sealed class PaintZoneSignal
{
    public string FamilyKey { get; set; } = "";
    public string SourceFile { get; set; } = "";
    public string CorrosionClass { get; set; } = "";
    public string Preparation { get; set; } = "";
    public string Colour { get; set; } = "";
    public double? DftMicron { get; set; }
    public int Confidence { get; set; }
    public string Basis { get; set; } = "";
}

public sealed class SanityCheckItem
{
    public string Code { get; set; } = "";
    public RiskLevel Level { get; set; }
    public string Message { get; set; } = "";
    public string Basis { get; set; } = "";
}

public sealed class MaterialBreakdownItem
{
    public string Material { get; set; } = "";
    public string SemiFinishedKind { get; set; } = "";
    public double MassKg { get; set; }
    public int FamilyCount { get; set; }
    public int Confidence { get; set; }
    public string Source { get; set; } = "";
    public string Basis { get; set; } = "";
    public double SharePercent { get; set; }
    public string MassText => MassKg > 0 ? $"{MassKg:N1} kg" : "—";
}

public sealed class SemiFinishedProductItem
{
    public string Kind { get; set; } = "";
    public string Material { get; set; } = "";
    public double Quantity { get; set; }
    public double MassKg { get; set; }
    public int Confidence { get; set; }
    public string Source { get; set; } = "";
    public string Basis { get; set; } = "";
}

public sealed class WeldFamilySignal
{
    public string FamilyKey { get; set; } = "";
    public string SourceFile { get; set; } = "";
    public string ProcessCode { get; set; } = "";
    public string SizeKind { get; set; } = "";
    public double? SizeMm { get; set; }
    public double? ExplicitLengthMm { get; set; }
    public int SideCount { get; set; }
    public double Quantity { get; set; } = 1;
    public int Confidence { get; set; }
    public string Basis { get; set; } = "";
}

public sealed class WeldFamilyEstimate
{
    public string FamilyKey { get; set; } = "";
    public string ProcessCode { get; set; } = "";
    public string SizeKind { get; set; } = "";
    public double SizeMm { get; set; }
    public double LengthM { get; set; }
    public double Quantity { get; set; } = 1;
    public double WeldMetalMassKg { get; set; }
    public double ArcHours { get; set; }
    public int Confidence { get; set; }
    public string Basis { get; set; } = "";
}

public sealed class CncFeatureSummary
{
    public int MachinedFamilyCount { get; set; }
    public int PrecisionHoleCount { get; set; }
    public int DrilledHoleCount { get; set; }
    public int ReamedHoleCount { get; set; }
    public int ThreadedHoleCount { get; set; }
    public int BoredHoleCount { get; set; }
    public int SecondaryOperationCount { get; set; }
    public int TightDimensionalToleranceCount { get; set; }
    public int TightGeometricToleranceCount { get; set; }
    public int BevelFaceCount { get; set; }
    public int PocketCandidateCount { get; set; }
    public int SetupCount { get; set; }
    public int ComplexityScore { get; set; }
    public int Confidence { get; set; }
    public string NextAction { get; set; } = "";
    public string Basis { get; set; } = "";
}

public sealed class HistoricalProcessAdjustment
{
    public string ProcessCode { get; set; } = "";
    public string ProcessName { get; set; } = "";
    public int Samples { get; set; }
    public double RawFactor { get; set; } = 1.0;
    public double AppliedFactor { get; set; } = 1.0;
    public double BeforeHours { get; set; }
    public double AfterHours { get; set; }
    public double AverageSimilarityPercent { get; set; }
    public int Confidence { get; set; }
    public string Basis { get; set; } = "";
}

public sealed class HistoricalCalibrationSummary
{
    public bool Applied { get; set; }
    public int NeighborCount { get; set; }
    public int PriceNeighborCount { get; set; }
    public int Confidence { get; set; }
    public double? WeightedHistoricalPricePln { get; set; }
    public double? ExternalCostHintPln { get; set; }
    public string Basis { get; set; } = "";
    public List<HistoricalProcessAdjustment> ProcessAdjustments { get; set; } = [];
}

public sealed class DocumentGroupInfo
{
    public string Key { get; set; } = "";
    public int FileCount { get; set; }
    public int ActiveFileCount { get; set; }
    public List<string> Files { get; set; } = [];
    public List<string> StepFiles { get; set; } = [];
    public List<string> DrawingFiles { get; set; } = [];
    public List<string> BomFiles { get; set; } = [];
    public string Summary => $"{Key}: {ActiveFileCount}/{FileCount} aktywnych";
}

public sealed class AssemblyTreeNode
{
    public string Id { get; set; } = "";
    public string ParentId { get; set; } = "";
    public int Level { get; set; }
    public string Kind { get; set; } = "Detal";
    public string Name { get; set; } = "";
    public string PartNumber { get; set; } = "";
    public double Quantity { get; set; } = 1;
    public double GeometryQuantity { get; set; }
    public bool QuantityMismatch => GeometryQuantity > 0 && Math.Abs(Quantity - GeometryQuantity) > 0.001;
    public string Material { get; set; } = "";
    public double MassKg { get; set; }
    public string Source { get; set; } = "";
    public int Confidence { get; set; }
    public string MatchBasis { get; set; } = "";
    public string Indent => new string(' ', Math.Max(0, Level) * 4);
    public string DisplayName => $"{new string('·', Math.Max(0, Level))} {Name}".TrimStart();
    public string QuantityText => $"× {Quantity:0.###}";
    public string MassText => MassKg > 0 ? $"{MassKg:N1} kg" : "—";
}

public sealed class RuleHit
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Effect { get; set; } = "";
    public string Basis { get; set; } = "";
    public int Confidence { get; set; }
}

public sealed class WorkstationDefinition
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string ProcessCode { get; set; } = "";
    public string MatchTag { get; set; } = "";
    public bool Enabled { get; set; } = true;
    public int Priority { get; set; } = 10;
    public double RatePlnPerHour { get; set; }

    // Company cost-center card. RatePlnPerHour is the effective RBH after total cost.
    // The breakdown below is audit/UI information imported from the company assumptions sheet.
    public string CostCenterCode { get; set; } = "";
    public string CostCenterName { get; set; } = "";
    public bool DisplayInRateCard { get; set; }
    public bool AutomaticRoutingCandidate { get; set; } = true;
    public double DirectLaborRatePlnH { get; set; }
    public double DepartmentOverheadPercent { get; set; }
    public double DepartmentCostRatePlnH { get; set; }
    public double ManufacturingCostRatePlnH { get; set; }
    public double GeneralOverheadPercent { get; set; }
    public double GeneralCostRatePlnH { get; set; }
    public double VariableDepartmentPercent { get; set; }
    public double VariableDepartmentRatePlnH { get; set; }

    public double MaxXmm { get; set; }
    public double MaxYmm { get; set; }
    public double MaxZmm { get; set; }
    public double MaxWeightKg { get; set; }
    public double MaxThicknessMm { get; set; }
    // Relative cycle-time multiplier used by the automatic workstation selector.
    // 1.0 = baseline; values learned from history can make a machine faster/slower
    // without requiring the operator to tune routing manually.
    public double TimeFactor { get; set; } = 1.0;
    public int LearnedSamples { get; set; }

    // UI helpers: each process exposes only the limits that are technologically meaningful.
    public bool IsCutting => string.Equals(ProcessCode, "CUT", StringComparison.OrdinalIgnoreCase);
    public bool IsWelding => string.Equals(ProcessCode, "WELD", StringComparison.OrdinalIgnoreCase);
    public bool IsCnc => string.Equals(ProcessCode, "CNC", StringComparison.OrdinalIgnoreCase);
    public bool IsSurface => string.Equals(ProcessCode, "SURF", StringComparison.OrdinalIgnoreCase);
    public bool IsAssembly => string.Equals(ProcessCode, "ASSY", StringComparison.OrdinalIgnoreCase);
    public string RateDisplay => RatePlnPerHour > 0 ? $"{RatePlnPerHour:N0} PLN/h" : "stawka bazowa";
}

public sealed class ProductionActuals
{
    public DateTime? CompletedAt { get; set; }
    // Exact historical cost-centre truth is retained alongside the simplified
    // CUT/CNC/WELD/SURF/ASSY view. This prevents information such as 3302/3303
    // or 3205 from disappearing during reanalysis/calibration.
    public Dictionary<string, double> SskHours { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public double CuttingHours { get; set; }
    public double WeldingHours { get; set; }
    public double MachiningHours { get; set; }
    public double SurfaceHours { get; set; }
    public double AssemblyHours { get; set; }
    public double ActualTotalCostPln { get; set; }
    public string Note { get; set; } = "";

    public bool HasAny =>
        SskHours.Values.Any(x => x > 0) ||
        CuttingHours > 0 || WeldingHours > 0 || MachiningHours > 0 ||
        SurfaceHours > 0 || AssemblyHours > 0 || ActualTotalCostPln > 0;

    public double GetHours(string processCode)
    {
        if (SskHours.TryGetValue(processCode, out var exact))
            return Math.Max(0, exact);
        return processCode.ToUpperInvariant() switch
        {
        "CUT" => CuttingHours,
        "WELD" => WeldingHours,
        "CNC" => MachiningHours,
        "SURF" => SurfaceHours,
        "ASSY" => AssemblyHours,
        _ => 0
        };
    }
}


/// <summary>
/// Provenance and original values for a project imported from a historical costing workbook.
/// These values are intentionally kept separate from AnalysisResult so the model prediction
/// and the historical truth can be compared without overwriting each other.
/// </summary>
public sealed class HistoryImportMetadata
{
    public string AnalysisEngineVersion { get; set; } = "";
    public string SourceKey { get; set; } = "";
    public string SourceFolder { get; set; } = "";
    public string MetricWorkbook { get; set; } = "";
    public DateTime ImportedAt { get; set; } = DateTime.Now;
    public string DrawingNumber { get; set; } = "";
    public double CombinedWeldAssemblyHours { get; set; }
    public double RobotWeldingHours { get; set; }
    public int MetricSheetCount { get; set; }
    public string MetricAggregationBasis { get; set; } = "";
    public double CncHeavyHours { get; set; }
    public double CncMediumHours { get; set; }
    public double CncLightHours { get; set; }
    public double CncManualHours { get; set; }
    public double ModelCncLargeHours { get; set; }
    public double ModelCncMediumHours { get; set; }
    public double ModelCncSmallHours { get; set; }
    public double? HistoricalMaterialCostPln { get; set; }
    public double? HistoricalTotalCostPln { get; set; }
    public double? HistoricalPricePln { get; set; }
    public double ProductionQuantity { get; set; } = 1.0;
    public string ProjectClass { get; set; } = "";
    public string SplitBasis { get; set; } = "";
    public Dictionary<string, double> SskHours { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, double> HistoricalRateHintsPlnH { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class CalibrationFactorInfo
{
    public string ProcessCode { get; set; } = "";
    public string ProcessName { get; set; } = "";
    public int Samples { get; set; }
    public double Factor { get; set; } = 1.0;
    public string Basis { get; set; } = "";
    public string Display => $"{ProcessName}: ×{Factor:0.###} ({Samples} próbek)";
}

// FIX26: page-scoped PDF evidence is informational, not an automatic
// material/quantity assignment to a STEP part or BOM position.
public sealed class DrawingPageEvidence
{
    public string SourceFile { get; set; } = "";
    public int PageNumber { get; set; }
    public List<string> DrawingNumbers { get; set; } = [];
    public string MaterialHint { get; set; } = "";
    public string MaterialReference { get; set; } = "";
    public List<string> BomPartNumbers { get; set; } = [];
    public int BomRowCount { get; set; }
    public List<string> Norms { get; set; } = [];
    public bool TextLayerPresent { get; set; }
    public bool OcrApplied { get; set; }
    public bool OcrTextPresent { get; set; }
    public bool SuspectedRaster { get; set; }
}

// FIX29: diagnostic only; no automatic material, quantity or price propagation.
public sealed class DrawingBomLink
{
    public string SourceFile { get; set; } = "";
    public string DrawingNumber { get; set; } = "";
    public int DrawingPageNumber { get; set; }
    public string BomPartNumber { get; set; } = "";
    public int BomPageNumber { get; set; }
    public string MatchType { get; set; } = "";
}

// FIX30: exact PDF drawing/BOM identifier ↔ existing STEP *filename*.
// This is an audit hint only, not proof that the STEP geometry is the part.
public sealed class DrawingStepLink
{
    public string SourcePdf { get; set; } = "";
    public string DrawingNumber { get; set; } = "";
    public int DrawingPageNumber { get; set; }
    public int BomPageNumber { get; set; }
    public string StepFile { get; set; } = "";
    public string MatchType { get; set; } = "";
}

public sealed class DrawingIntelligence
{
    public List<DrawingBomLink> DrawingBomLinks { get; set; } = [];
    public List<DrawingStepLink> DrawingStepLinks { get; set; } = [];
    public List<string> DrawingStepAmbiguousNumbers { get; set; } = [];
    public int PdfPageCount { get; set; }
    public List<DrawingPageEvidence> PageEvidence { get; set; } = [];
    public string SourceFile { get; set; } = "";
    public string MaterialHint { get; set; } = "";
    // Supplier/customer specification or internal material reference read from a
    // title block. It is diagnostic only and must never substitute a physical grade.
    public string MaterialReference { get; set; } = "";
    public int MaterialReferenceConfidence { get; set; }
    public string MaterialReferenceEvidence { get; set; } = "";
    public List<string> Keywords { get; set; } = [];
    public List<string> Norms { get; set; } = [];
    public List<string> Findings { get; set; } = [];
    public List<string> Warnings { get; set; } = [];
    public List<string> DetectedLanguages { get; set; } = [];
    public string OcrLanguagesUsed { get; set; } = "";
    public string OcrEnginePath { get; set; } = "";
    public double? OcrMeanConfidence { get; set; }
    public double? OcrCriticalConfidence { get; set; }
    public List<string> OcrLowConfidenceSignals { get; set; } = [];
    public List<string> OcrCriticalConflicts { get; set; } = [];
    public int ExtractedTextLength { get; set; }

    // Structured technical signals extracted from PDF/OCR.
    public string WeldProcessCode { get; set; } = "";
    public string WeldTypeHint { get; set; } = "";
    public string WeldSizeKind { get; set; } = "";
    public double? WeldSizeMm { get; set; }
    public int WeldSideCount { get; set; }
    public bool WeldSideCountConfirmed { get; set; }
    public bool WeldIntermittent { get; set; }
    public double? WeldIntermittentLengthMm { get; set; }
    public double? WeldPitchMm { get; set; }
    // FIX10K / A5: explicit total weld length stated on a production drawing.
    // This is stronger than a geometry-only joint candidate length and is still
    // cross-checked against STEP before costing.
    public double? WeldExplicitLengthMm { get; set; }
    public int WeldExplicitLengthConfidence { get; set; }
    public string WeldExplicitLengthEvidence { get; set; } = "";
    public bool WeldIntermittencyConfirmed { get; set; }
    public bool WeldAllAround { get; set; }
    public double? WeldGrooveAngleDeg { get; set; }
    public double? WeldRootGapMm { get; set; }
    public string SurfacePreparation { get; set; } = "";
    public string CorrosionClass { get; set; } = "";
    public string PaintColour { get; set; } = "";
    public double? TotalDftMicron { get; set; }
    public List<PaintLayerSignal> PaintLayers { get; set; } = [];
    public bool PaintStripeCoatRequired { get; set; }
    public List<HoleRequirementSignal> HoleRequirements { get; set; } = [];
    public List<DimensionalToleranceSignal> DimensionalTolerances { get; set; } = [];
    public List<GeometricToleranceSignal> GeometricTolerances { get; set; } = [];
    // Mass read directly from drawing/PDF/DXF title blocks or ERP-style drawing tables.
    // This is separate from BOM total mass so hierarchy-heavy BOMs are not silently summed.
    public double? DocumentMassKg { get; set; }
    public int DocumentMassConfidence { get; set; }
    public string DocumentMassEvidence { get; set; } = "";
    // PART / SUBASSEMBLY / ASSEMBLY_TOTAL / BOM_TOTAL / UNKNOWN.
    // Scope prevents a valid part weight from silently becoming the whole-project weight.
    public string DocumentMassScope { get; set; } = "UNKNOWN";
    // Optional explicit surface area supplied by a drawing note. It may be used for
    // coating only when 3D geometry does not provide a usable surface.
    public double? DocumentSurfaceAreaM2 { get; set; }
    public int DocumentSurfaceAreaConfidence { get; set; }
    public string DocumentSurfaceAreaEvidence { get; set; } = "";
    public bool PaintMaskMachinedSurfaces { get; set; }
    // AUTO keeps the safe geometry default: external/accessible non-mating surfaces.
    // Explicit drawing notes may set ALL / EXTERNAL_ONLY / INTERNAL_ONLY.
    public string PaintScope { get; set; } = "AUTO";
    public string PaintScopeEvidence { get; set; } = "";
    public bool PaintScopeConflict { get; set; }
    public double? ProjectQuantityHint { get; set; }
    // Mass summary emitted by a single tabular/BOM document. During merge the
    // application only promotes it when the source is unambiguous; multiple full
    // and sub-BOM files are never silently summed.
    public double? BomTotalMassKg { get; set; }
    public int BomMassRowCount { get; set; }
    public int BomPositiveMassRowCount { get; set; }
    public int BomMassSourceCount { get; set; }

    // FIX12D document-family resolver. These values describe whether the CAD set
    // actually covers the authoritative root parts list. They are deliberately
    // separate from OCR confidence: a perfect STEP of one detail is still only a
    // partial project model when the root BOM contains dozens of other families.
    public string ResolvedRootEntityKey { get; set; } = "";
    public int ResolvedRootBomFamilyCount { get; set; }
    public bool ResolvedFamilyScopeEnforced { get; set; }
    public int ResolvedStepFamilyCount { get; set; }
    public int ResolvedStepFamilyMatchCount { get; set; }
    public int ResolvedDxfFamilyCount { get; set; }
    public int ResolvedDxfFamilyMatchCount { get; set; }
    public bool StepGeometryProjectCoveragePartial { get; set; }
    public bool DxfScopeLimited { get; set; }
    public List<string> ResolvedProductionFamilies { get; set; } = [];

    // FIX12E hybrid surface reconstruction.  When the root assembly does not
    // have a complete STEP, coating area is assembled per production family from
    // the best available source (explicit drawing, local STEP, DXF+thickness,
    // profile/BOM or low-confidence mass fallback).
    public double? HybridSurfaceAreaM2 { get; set; }
    public int HybridSurfaceAreaConfidence { get; set; }
    public double HybridSurfaceAreaCoveragePercent { get; set; }
    public string HybridSurfaceAreaSource { get; set; } = "";
    public List<SurfaceAreaContribution> HybridSurfaceAreaContributions { get; set; } = [];

    // FIX14: reconstruct project mass per root-BOM family when the complete STEP is unavailable.
    // The reconstructed value becomes project-authoritative only at high coverage/confidence;
    // partial mass remains useful for a partial material cost without unlocking an offer price.
    public double? HybridMassKg { get; set; }
    public int HybridMassConfidence { get; set; }
    public double HybridMassCoveragePercent { get; set; }
    public bool HybridMassProjectAuthoritative { get; set; }
    public string HybridMassSource { get; set; } = "";
    public List<MassReconstructionContribution> HybridMassContributions { get; set; } = [];

    // FIX14: quality and coating requirements stay scoped to the drawing/part family.
    public List<NdtFamilySignal> NdtFamilySignals { get; set; } = [];
    public List<PaintZoneSignal> PaintZoneSignals { get; set; } = [];

    // FIX13: preserve weld evidence per drawing/part family instead of collapsing
    // every a/z value into one project-wide parameter.
    public List<WeldFamilySignal> WeldFamilySignals { get; set; } = [];

    public List<BomItemSignal> BomItems { get; set; } = [];
    public List<InformationConflict> Conflicts { get; set; } = [];

    // 2D/PDF drawing counts remain visible and usable even when there is no STEP.
    // Generic DXF/PDF diameter candidates and more-specific fit/thread/tolerance
    // descriptions can refer to the same physical holes, therefore totals use the
    // largest supported count per nominal diameter instead of blindly summing every
    // representation.
    public int EstimatedHoleCount2D => HoleRequirements
        .Where(x => x.NominalDiameterMm is > 0 || !string.IsNullOrWhiteSpace(x.ThreadCode))
        .GroupBy(x => x.NominalDiameterMm is > 0
            ? $"D:{Math.Round(x.NominalDiameterMm.Value, 2):0.00}"
            : $"T:{x.ThreadCode.ToUpperInvariant()}", StringComparer.OrdinalIgnoreCase)
        .Sum(g =>
        {
            var generic = g.Where(x => string.Equals(x.OperationHint, "DRAWING_DIAMETER", StringComparison.OrdinalIgnoreCase) ||
                                       string.Equals(x.OperationHint, "DXF_CIRCLE", StringComparison.OrdinalIgnoreCase))
                .Select(x => Math.Max(1, x.Count)).DefaultIfEmpty(0).Max();
            var specific = g.Where(x => !string.Equals(x.OperationHint, "DRAWING_DIAMETER", StringComparison.OrdinalIgnoreCase) &&
                                        !string.Equals(x.OperationHint, "DXF_CIRCLE", StringComparison.OrdinalIgnoreCase))
                .GroupBy(x => $"{x.FitCode}|{x.ThreadCode}|{x.OperationHint}", StringComparer.OrdinalIgnoreCase)
                .Sum(x => x.Select(v => Math.Max(1, v.Count)).DefaultIfEmpty(0).Max());
            return Math.Max(generic, specific);
        });

    public int PrecisionHoleCount2D => HoleRequirements
        .Where(x => x.FitConfirmed || x.ReamedLikely || x.PrecisionMachined || !string.IsNullOrWhiteSpace(x.ThreadCode))
        .GroupBy(x => $"{Math.Round(x.NominalDiameterMm ?? 0, 2):0.00}|{x.FitCode}|{x.ThreadCode}", StringComparer.OrdinalIgnoreCase)
        .Sum(g => g.Select(x => Math.Max(1, x.Count)).DefaultIfEmpty(0).Max());

    public int TightDimensionalToleranceCount => DimensionalTolerances.Count(x => x.Tight);
    public int TightGeometricToleranceCount => GeometricTolerances.Count(x => x.Tight);
}

public sealed class DxfSignals
{
    public string SourceFile { get; set; } = "";
    public int Lines { get; set; }
    public int Arcs { get; set; }
    public int Circles { get; set; }
    public int Polylines { get; set; }
    public int Splines { get; set; }
    public int Ellipses { get; set; }
    public int Hatches { get; set; }
    public int Inserts { get; set; }
    public int Dimensions { get; set; }
    public int TextEntities { get; set; }
    public int OtherEntities { get; set; }
    public int TotalEntities { get; set; }
    public string Reader { get; set; } = "";
    public int LayerCount { get; set; }
    public string EntityTypeSummary { get; set; } = "";
    public string ExtentsSummary { get; set; } = "";
    public string FileEncoding { get; set; } = "";
    public bool BinaryFormat { get; set; }
    public bool ReferenceOnlyLikely { get; set; }
    public string DiagnosticSummary { get; set; } = "";
    public double CutLengthMm { get; set; }
    public double MarkingLengthMm { get; set; }
    public double IgnoredNonCutLengthMm { get; set; }
    public int CutGeometryEntityCount { get; set; }
    public int ClosedProfileCount { get; set; }
    public int OpenPathCount { get; set; }
    public int MinimumPierceCount { get; set; }
    public int CutStartCount { get; set; }
    public double CutBoundingXmm { get; set; }
    public double CutBoundingYmm { get; set; }
    public double CutBoundingAreaMm2 { get; set; }
    // Sum of individually closed 2D profile areas. This is a low-confidence fallback
    // for flat-part coating when STEP and explicit drawing area are unavailable.
    public double ClosedProfileAreaMm2 { get; set; }
    public int GeometryHoleCandidateCount { get; set; }
    public double EstimatedRapidTravelMm { get; set; }
    public int SourceFileCount { get; set; }
    public List<string> CutLayers { get; set; } = [];
    public List<string> MarkingLayers { get; set; } = [];
    public string DrawingUnits { get; set; } = "";
    public bool GeometryMeasurementReliable { get; set; }
    public int ExtractedTextLength { get; set; }
    public string MaterialHint { get; set; } = "";
    public string MaterialReference { get; set; } = "";
    public int MaterialReferenceConfidence { get; set; }
    public string MaterialReferenceEvidence { get; set; } = "";
    public List<string> Keywords { get; set; } = [];
    public List<string> Norms { get; set; } = [];
    public List<string> Findings { get; set; } = [];
    public List<string> Warnings { get; set; } = [];
    // Structured signals from DXF text/blocks/dimensions. Keeping these on DxfSignals
    // lets DXF carry the same manufacturing semantics as a PDF drawing.
    public string WeldProcessCode { get; set; } = "";
    public string WeldTypeHint { get; set; } = "";
    public string WeldSizeKind { get; set; } = "";
    public double? WeldSizeMm { get; set; }
    public int WeldSideCount { get; set; }
    public bool WeldSideCountConfirmed { get; set; }
    public bool WeldIntermittent { get; set; }
    public double? WeldIntermittentLengthMm { get; set; }
    public double? WeldPitchMm { get; set; }
    // FIX10K / A5: explicit total weld length stated on a production drawing.
    // This is stronger than a geometry-only joint candidate length and is still
    // cross-checked against STEP before costing.
    public double? WeldExplicitLengthMm { get; set; }
    public int WeldExplicitLengthConfidence { get; set; }
    public string WeldExplicitLengthEvidence { get; set; } = "";
    public bool WeldIntermittencyConfirmed { get; set; }
    public bool WeldAllAround { get; set; }
    public double? WeldGrooveAngleDeg { get; set; }
    public double? WeldRootGapMm { get; set; }
    public string SurfacePreparation { get; set; } = "";
    public string CorrosionClass { get; set; } = "";
    public string PaintColour { get; set; } = "";
    public double? TotalDftMicron { get; set; }
    public List<PaintLayerSignal> PaintLayers { get; set; } = [];
    public bool PaintStripeCoatRequired { get; set; }
    public List<HoleRequirementSignal> HoleRequirements { get; set; } = [];
    public List<DimensionalToleranceSignal> DimensionalTolerances { get; set; } = [];
    public List<GeometricToleranceSignal> GeometricTolerances { get; set; } = [];
    public double? DocumentMassKg { get; set; }
    public int DocumentMassConfidence { get; set; }
    public string DocumentMassEvidence { get; set; } = "";
    public string DocumentMassScope { get; set; } = "UNKNOWN";
    public double? DocumentSurfaceAreaM2 { get; set; }
    public int DocumentSurfaceAreaConfidence { get; set; }
    public string DocumentSurfaceAreaEvidence { get; set; } = "";
    public bool PaintMaskMachinedSurfaces { get; set; }
    public string PaintScope { get; set; } = "AUTO";
    public string PaintScopeEvidence { get; set; } = "";
    public bool PaintScopeConflict { get; set; }
    public double? ProjectQuantityHint { get; set; }

    public int EntityCount => TotalEntities > 0
        ? TotalEntities
        : Lines + Arcs + Circles + Polylines + Splines + Ellipses +
          Hatches + Inserts + Dimensions + TextEntities + OtherEntities;
}

public sealed class ProcessEstimate : INotifyPropertyChanged
{
    private bool _manualOverride;
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public bool Enabled { get; set; }
    // R9.0.8 / FIX13A: operator correction is explicit and survives draft/save/re-analysis.
    public bool ManualOverride
    {
        get => _manualOverride;
        set
        {
            if (_manualOverride == value) return;
            _manualOverride = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ManualOverride)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DecisionOrigin)));
        }
    }
    // Automatic baseline captured after document + history engines. It lets the UI
    // distinguish a real edit from simply opening the process editor.
    public bool AutomaticEnabled { get; set; }
    public double AutomaticHours { get; set; }
    public double AutomaticRatePlnPerHour { get; set; }
    public double Hours { get; set; }
    public double RatePlnPerHour { get; set; }
    public double BaseHours { get; set; }
    public double CalibrationFactor { get; set; } = 1.0;
    // FIX15: physical model and versioned external calibration are separate layers.
    public double ModelHoursBeforeExternalCalibration { get; set; }
    public double ExternalCalibrationFactor { get; set; } = 1.0;
    public string ExternalCalibrationVersion { get; set; } = "";
    public string WorkstationCode { get; set; } = "";
    public string WorkstationName { get; set; } = "";
    public int Confidence { get; set; }
    public string Basis { get; set; } = "";
    public double CostPln => Enabled ? Hours * RatePlnPerHour : 0;
    public string DecisionOrigin => ManualOverride
        ? "RĘCZNIE"
        : Basis.Contains("podobne realizacje", StringComparison.OrdinalIgnoreCase) ||
          Basis.Contains("Kalibracja plan/wykonanie", StringComparison.OrdinalIgnoreCase) ||
          Basis.Contains("Profil firmy", StringComparison.OrdinalIgnoreCase)
            ? "HISTORIA"
            : Basis.Contains("PDF", StringComparison.OrdinalIgnoreCase) ||
              Basis.Contains("DXF", StringComparison.OrdinalIgnoreCase) ||
              Basis.Contains("STEP", StringComparison.OrdinalIgnoreCase) ||
              Basis.Contains("BOM", StringComparison.OrdinalIgnoreCase)
                ? "DOKUMENT"
                : "AUTO";

    public event PropertyChangedEventHandler? PropertyChanged;
}

public sealed class ProcessManualOverride
{
    public string Code { get; set; } = "";
    public bool OverrideEnabled { get; set; }
    public bool Enabled { get; set; }
    public bool OverrideHours { get; set; }
    public double Hours { get; set; }
    public bool OverrideRate { get; set; }
    public double RatePlnPerHour { get; set; }
    public DateTime UpdatedAt { get; set; } = DateTime.Now;
    public bool HasAny => OverrideEnabled || OverrideHours || OverrideRate;
}

public sealed class AnalysisResumeState
{
    public bool InProgress { get; set; }
    public bool WasInterrupted { get; set; }
    public DateTime? StartedAt { get; set; }
    public DateTime? LastCheckpointAt { get; set; }
    public string LastMessage { get; set; } = "";
    public HashSet<string> CompletedDocumentHashes { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public int CompletedDocumentCount => CompletedDocumentHashes.Count;
}


public sealed class WeldEstimate
{
    public bool Enabled { get; set; }
    public string Type { get; set; } = "pachwinowa / wnioskowana";
    public string Source { get; set; } = "";
    public string ProcessCode { get; set; } = "135";
    public string SizeKind { get; set; } = "a";
    public double SizeMm { get; set; }
    public int SideCount { get; set; } = 1;
    public bool SideCountConfirmed { get; set; }
    public bool AllAround { get; set; }
    public bool AllAroundLengthEstimated { get; set; }
    public bool Intermittent { get; set; }
    public bool IntermittencyConfirmed { get; set; }
    public double IntermittencyFactor { get; set; } = 1.0;
    public double GeometricLengthM { get; set; }
    public double EffectiveLengthM { get; set; }
    public double CrossSectionMm2 { get; set; }
    public double WeldMetalMassKg { get; set; }
    public double FillerMetalKg { get; set; }
    public int NumberOfPasses { get; set; }
    public double DepositionRateKgH { get; set; }
    public double ArcHours { get; set; }
    public double FitUpHours { get; set; }
    public double ManipulationHours { get; set; }
    public int EstimatedRepositions { get; set; }
    public double HandlingHours { get; set; }
    public double TotalHours { get; set; }
    public double ConsumableCostPln { get; set; }
    public int Confidence { get; set; }
    public bool SizeAssumed { get; set; }
    public bool ProcessAssumed { get; set; }
    public bool FamilyScoped { get; set; }
    public List<WeldFamilyEstimate> FamilyBreakdown { get; set; } = [];
    public string Basis { get; set; } = "";
}

public sealed class PaintLayerEstimate
{
    public string Name { get; set; } = "";
    public double DftMicron { get; set; }
    public int CoatCount { get; set; } = 1;
    public double TheoreticalCoverageM2PerL { get; set; }
    public double LitersTheoretical { get; set; }
    public double LitersWithLoss { get; set; }
    public double MaterialCostPln { get; set; }
}

public sealed class PaintEstimate
{
    public bool Enabled { get; set; }
    public bool SurfacePreparationRequired { get; set; }
    public bool CoatingRequired { get; set; }
    public string SurfacePreparation { get; set; } = "";
    public string CorrosionClass { get; set; } = "";
    public string Colour { get; set; } = "";
    public double GrossAreaM2 { get; set; }
    public double HiddenContactAreaM2 { get; set; }
    public double ClosedInternalAreaM2 { get; set; }
    public double OpenInternalAreaM2 { get; set; }
    public double AmbiguousAreaM2 { get; set; }
    public double MaskedMachinedAreaM2 { get; set; }
    public double PaintableAreaM2 { get; set; }
    public string AreaSource { get; set; } = "";
    public int AreaConfidence { get; set; }
    public double AreaCoveragePercent { get; set; }
    public string Scope { get; set; } = "AUTO";
    public string ScopeDisplay => Scope switch
    {
        "ALL" => "zewnętrzne + wewnętrzne",
        "EXTERNAL_ONLY" => "tylko zewnętrzne",
        "INTERNAL_ONLY" => "tylko wewnętrzne",
        _ => "zewnętrzne / dostępne (automatycznie)"
    };
    public double InternalAreaIncludedM2 { get; set; }
    public double PreAssemblyInternalAreaM2 { get; set; }
    public bool PreAssemblyInternalPaintingRequired { get; set; }
    public double PreAssemblyHandlingHours { get; set; }
    public double TotalDftMicron { get; set; }
    public bool DftAssumed { get; set; }
    public int LayerCount { get; set; }
    public List<PaintLayerEstimate> Layers { get; set; } = [];
    public double VolumeSolidsPercent { get; set; }
    public double LossPercent { get; set; }
    public double TheoreticalCoverageM2PerL { get; set; }
    public double PaintLitersTheoretical { get; set; }
    public double PaintLitersWithLoss { get; set; }
    public double SurfacePrepHours { get; set; }
    public double ApplicationHours { get; set; }
    public double StripeCoatHours { get; set; }
    public double HandlingHours { get; set; }
    public double TotalHours { get; set; }
    public double PaintMaterialCostPln { get; set; }
    public int Confidence { get; set; }
    public int SystemCompletenessPercent { get; set; }
    public string SystemCompletenessBasis { get; set; } = "";
    public string Basis { get; set; } = "";
}

public sealed class CostLine
{
    public string Name { get; set; } = "";
    public double AmountPln { get; set; }
    public int Confidence { get; set; }
    public string Basis { get; set; } = "";
    public string ConfidenceText => Confidence > 0 ? $"{Confidence}%" : "—";
}

public sealed class RiskItem
{
    public string Code { get; set; } = "";
    public RiskLevel Level { get; set; }
    public string Title { get; set; } = "";
    public string Message { get; set; } = "";
    public bool Blocking { get; set; }
}

public sealed class SimilarProject
{
    public Guid ProjectId { get; set; }
    public string Name { get; set; } = "";
    public string Customer { get; set; } = "";
    public double SimilarityPercent { get; set; }
    public double? WeightKg { get; set; }
    public double FinalPricePln { get; set; }
    public string ProjectClass { get; set; } = "";
    public string SimilarityBasis { get; set; } = "";
}

public sealed class AutoRouteStep
{
    public int Sequence { get; set; }
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Source { get; set; } = "";
    public int Confidence { get; set; }
    public double Hours { get; set; }
    public double CostPln { get; set; }
    public bool IncludedInPrice { get; set; }
    public bool RequiresExternalRate { get; set; }
    public string Basis { get; set; } = "";

    public string SequenceText => Sequence.ToString("00");
    public string ConfidenceText => $"{Confidence}%";
    public string HoursText => Hours > 0 ? $"{Hours:0.##} h" : "—";
    public string CostText =>
        RequiresExternalRate
            ? "BRAK STAWKI"
            : IncludedInPrice && CostPln > 0
                ? $"{CostPln:N0} PLN"
                : "ujęte w innym kroku";
}

public sealed class QuoteReadinessItem
{
    public string Code { get; set; } = "";
    public string Label { get; set; } = "";
    public string Status { get; set; } = "NIE DOTYCZY";
    public string Detail { get; set; } = "";
    public string NextAction { get; set; } = "";
    public string Target { get; set; } = "risks";
    public bool IsReady => Status == "GOTOWE" || Status == "NIE DOTYCZY";
    public bool NeedsReview => Status == "SPRAWDŹ" || Status == "CZĘŚCIOWO";
    public bool IsBlocking => Status == "BRAK";
    public string Display => $"{Label}: {Status}";
}

public sealed class QuoteReleaseOverride
{
    public bool Granted { get; set; }
    public string Reason { get; set; } = "";
    public string ApprovedBy { get; set; } = "Użytkownik lokalny";
    public DateTime? ApprovedAt { get; set; }
    // The exception is valid only for the exact project/settings state reviewed by
    // the user. Any later input or pricing change invalidates it automatically.
    public string ApprovedFingerprint { get; set; } = "";
}

public sealed class FrozenQuoteSnapshot
{
    public DateTime CreatedAt { get; set; }
    public string ReleaseMode { get; set; } = "STANDARD";
    public string Fingerprint { get; set; } = "";
    public string AnalysisHash { get; set; } = "";
    public string SettingsHash { get; set; } = "";
    public string CalibrationHash { get; set; } = "";
    public string EngineHash { get; set; } = "";
    public string ReleaseAuditHash { get; set; } = "";
    public Dictionary<string, string> DocumentHashes { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public string FingerprintShort => string.IsNullOrWhiteSpace(Fingerprint)
        ? "BRAK"
        : Fingerprint.Length > 16 ? Fingerprint[..16] : Fingerprint;
    public string Summary => $"{ReleaseMode} · {CreatedAt:yyyy-MM-dd HH:mm:ss} · SHA-256 {FingerprintShort}";
}

public sealed class AutoQuoteSummary
{
    public string Status { get; set; } = "WSTĘPNA";
    public string StatusDetail { get; set; } = "";
    public bool IsPriceComplete { get; set; } = true;
    public string PriceLabel { get; set; } = "CENA REKOMENDOWANA";
    public string PriceCompletenessNote { get; set; } = "";
    public int AutomaticAssumptionCount { get; set; }
    public int BlockingIssueCount { get; set; }
    public int UnpricedExternalOperationCount { get; set; }
    public int EnabledOperationCount { get; set; }
    public double RecommendedPricePln { get; set; }
    // Recognised should-cost can remain useful even when a complete offer price is blocked.
    public double RecognizedCostPln { get; set; }
    public double RecognizedMaterialCostPln { get; set; }
    public double RecognizedMaterialCoveragePercent { get; set; }
    public int UnresolvedFamilyCount { get; set; }
    public string RecommendedPriceDisplay => RecommendedPricePln > 0 ? $"{RecommendedPricePln:N0} PLN" : "NIE WYZNACZONO";
    public string RecognizedCostDisplay => RecognizedCostPln > 0 ? $"{RecognizedCostPln:N0} PLN" : "—";
    public bool HasRecommendedPrice => RecommendedPricePln > 0;
    public bool HasRecognizedPartialCost => RecommendedPricePln <= 0 && RecognizedCostPln > 0;
    public double PriceLowPln { get; set; }
    public double PriceHighPln { get; set; }
    // FIX15: P50 is explicit; low/high remain risk range, not false precision.
    public double P50PricePln { get; set; }
    public string PriceRangeDisplay => HasRecommendedPrice
        ? $"P50 {P50PricePln:N0} PLN · zakres {PriceLowPln:N0}–{PriceHighPln:N0} PLN"
        : "Zakres ceny: nie wyznaczono";
    public double UncertaintyPercent { get; set; }
    // 1.0.1: jawne czynniki niepewności z QuoteUncertaintyModel (audyt widełek).
    public string UncertaintyDrivers { get; set; } = "";
    public string MainAssumptions { get; set; } = "";
    public string RouteSummary { get; set; } = "";
    public string PricingProfileName { get; set; } = "";
    public string RatesStatus { get; set; } = "";
    public double ModeledCostPln { get; set; }
    public double SellingUpliftPln { get; set; }
    public double CostPerKg { get; set; }
    public double PricePerKg { get; set; }
    public int ConflictCount { get; set; }
    public bool RevisionWarning { get; set; }
    public double? HistoricalReferencePln { get; set; }
    public double? HistoricalDifferencePercent { get; set; }
    public bool HasHistoricalReference => HistoricalReferencePln is > 0;
    public List<QuoteReadinessItem> ReadinessItems { get; set; } = [];
    public int ReadinessIssueCount => ReadinessItems.Count(x => x.NeedsReview || x.IsBlocking);
    public string ReadinessSummary => ReadinessIssueCount == 0
        ? "Zakres wyceny kompletny — wszystkie wymagane obszary mają podstawę."
        : $"Do sprawdzenia: {ReadinessIssueCount} obszar(y). Kliknij pozycję, aby przejść do szczegółów.";
}

public sealed class EngineTimingItem
{
    public string Engine { get; set; } = "";
    public string Detail { get; set; } = "";
    public double ElapsedSeconds { get; set; }
    public bool FromCache { get; set; }
    public bool RanInParallel { get; set; }
}

/// <summary>
/// One auditable observation produced by a deterministic analyzer.  FIX9.5 keeps
/// the raw value independently from the final quote so a later orchestration pass
/// can explain which source supported, contradicted or was ignored by a decision.
/// </summary>
public sealed class EvidenceFact
{
    public string Field { get; set; } = "";
    public string Label { get; set; } = "";
    public string Value { get; set; } = "";
    public double? NumericValue { get; set; }
    public string Unit { get; set; } = "";
    public string SourceFile { get; set; } = "";
    public string SourceIdentity { get; set; } = "";
    public List<string> SourceAliases { get; set; } = [];
    public string SourceKind { get; set; } = "";
    public string Method { get; set; } = "";
    public string Scope { get; set; } = "UNKNOWN";
    public int Confidence { get; set; }
    public bool SupportsDecision { get; set; }
    public bool ConflictsWithDecision { get; set; }
    public bool Outlier { get; set; }
    public string Note { get; set; } = "";

    public string DisplayValue => NumericValue.HasValue
        ? $"{NumericValue.Value:0.###}{(string.IsNullOrWhiteSpace(Unit) ? "" : $" {Unit}")}"
        : Value;
}

/// <summary>
/// Explainable result of comparing facts for one technical field.  It is an
/// audit/review output in FIX9.5 and intentionally does not silently overwrite
/// the established Cost Engine result.
/// </summary>
public sealed class EvidenceDecision
{
    public string Field { get; set; } = "";
    public string Label { get; set; } = "";
    public string State { get; set; } = "BRAK_DANYCH";
    public string SelectedValue { get; set; } = "";
    public double? SelectedNumericValue { get; set; }
    public string Unit { get; set; } = "";
    public int Confidence { get; set; }
    public int SupportingSources { get; set; }
    public int ConflictingSources { get; set; }
    public int OutlierSources { get; set; }
    public bool NeedsReview { get; set; }
    public string Rule { get; set; } = "";
    public string Explanation { get; set; } = "";
    public string NextAction { get; set; } = "";
    public List<string> SourceFiles { get; set; } = [];

    public string DisplayValue => SelectedNumericValue.HasValue
        ? $"{SelectedNumericValue.Value:0.###}{(string.IsNullOrWhiteSpace(Unit) ? "" : $" {Unit}")}"
        : string.IsNullOrWhiteSpace(SelectedValue) ? "—" : SelectedValue;
}

/// <summary>
/// Post-run trace of why a file was routed to a particular specialist and what
/// happened.  This makes the adaptive scheduler observable without filling the
/// normal minimalist UI with implementation details.
/// </summary>
public sealed class EvidenceRouteDecision
{
    public string SourceFile { get; set; } = "";
    public string DocumentKind { get; set; } = "";
    public string Strategy { get; set; } = "";
    public string Engine { get; set; } = "";
    public int Priority { get; set; }
    public bool Expensive { get; set; }
    public bool FromCache { get; set; }
    public bool IndependentEvidence { get; set; } = true;
    public string Outcome { get; set; } = "";
    public string Reason { get; set; } = "";
    public string NextAction { get; set; } = "";
}

public sealed class EvidenceContentDuplicate
{
    public string ContentHashPrefix { get; set; } = "";
    public string CanonicalSource { get; set; } = "";
    public List<string> Files { get; set; } = [];
    public int AliasCount => Math.Max(0, Files.Count - 1);
}

public sealed class EvidenceOrchestrationSummary
{
    public string Version { get; set; } = "FIX10-EVIDENCE-3";
    public string Mode { get; set; } = "OFFLINE_DETERMINISTIC_PROTECTED_FUSION";
    public List<EvidenceFact> Facts { get; set; } = [];
    public List<EvidenceDecision> Decisions { get; set; } = [];
    public List<EvidenceRouteDecision> Routes { get; set; } = [];
    public List<EvidenceContentDuplicate> ContentDuplicates { get; set; } = [];
    public List<string> RecommendedActions { get; set; } = [];

    public int ConfirmedDecisionCount => Decisions.Count(x => x.State == "POTWIERDZONE");
    public int ReviewDecisionCount => Decisions.Count(x => x.NeedsReview);
    public int OutlierFactCount => Facts.Count(x => x.Outlier);
    public int CacheRouteCount => Routes.Count(x => x.FromCache);
    public int DuplicateAliasCount => ContentDuplicates.Sum(x => x.AliasCount);
    public string Summary =>
        $"{Decisions.Count} decyzji · {ConfirmedDecisionCount} potwierdzonych · " +
        $"{ReviewDecisionCount} do sprawdzenia · {OutlierFactCount} odstających wskazań · " +
        $"{DuplicateAliasCount} aliasów tej samej treści";
}

public sealed class AnalysisResult
{
    public DateTime AnalyzedAt { get; set; } = DateTime.Now;
    public string Material { get; set; } = "Nie rozpoznano";
    public double DensityKgM3 { get; set; } = 7850;
    public bool DensityAssumed { get; set; }
    public double? WeightKg { get; set; }
    public string WeightSource { get; set; } = "";
    public bool HasWeight => WeightKg is > 0;
    public GeometrySummary Geometry { get; set; } = new();
    public DrawingIntelligence Drawing { get; set; } = new();
    public DxfSignals Dxf { get; set; } = new();
    public PackageIntelligence Package { get; set; } = new();
    public string PricingProfileName { get; set; } = "Robocze - do kalibracji";
    public bool RatesConfirmedByCompany { get; set; }
    public List<ProcessEstimate> Processes { get; set; } = [];
    public WeldEstimate Welding { get; set; } = new();
    public PaintEstimate Painting { get; set; } = new();
    public NestingEstimate Nesting { get; set; } = new();
    public List<PurchasedPartEstimate> PurchasedParts { get; set; } = [];
    public List<QualityCostEstimate> QualityCosts { get; set; } = [];
    public List<CostConfidenceItem> CostConfidence { get; set; } = [];
    public List<SanityCheckItem> SanityChecks { get; set; } = [];
    public List<MaterialBreakdownItem> MaterialBreakdown { get; set; } = [];
    public double RecognizedPartialMaterialCostPln { get; set; }
    public List<SemiFinishedProductItem> SemiFinishedProducts { get; set; } = [];
    public CncFeatureSummary CncFeatures { get; set; } = new();
    public HistoricalCalibrationSummary HistoricalCalibration { get; set; } = new();
    public ProjectClassResult ProjectClass { get; set; } = new();
    public List<CostLine> CostLines { get; set; } = [];
    public List<RiskItem> Risks { get; set; } = [];
    public List<SimilarProject> SimilarProjects { get; set; } = [];
    public List<AutoRouteStep> AutoRoute { get; set; } = [];
    public List<AssemblyTreeNode> AssemblyTree { get; set; } = [];
    public List<RuleHit> RuleHits { get; set; } = [];
    public List<CalibrationFactorInfo> CalibrationFactors { get; set; } = [];
    public TrustFoundationSnapshot Trust { get; set; } = new();
    public List<PriceAgeWarning> PriceAgeWarnings { get; set; } = [];
    public ExternalCalibrationAudit ExternalCalibration { get; set; } = new();
    public List<QuoteScenario> QuoteScenarios { get; set; } = [];
    public SheetMetalReadinessSummary SheetMetal { get; set; } = new();
    public AutoQuoteSummary AutoQuote { get; set; } = new();
    public int ConfidencePercent { get; set; }
    public int ReadinessPercent { get; set; }
    public double MaterialCostPln { get; set; }
    public double PurchasedPartsCostPln { get; set; }
    public double QualityCostPln { get; set; }
    public double TechnologyMaterialCostPln { get; set; }
    public double ProcessCostPln { get; set; }
    public double ExternalCostPln { get; set; }
    public double OtherExternalCostPln => Math.Max(0, ExternalCostPln - QualityCostPln);
    public double CostTotalPln { get; set; }
    public double TechnicalPricePln { get; set; }
    public double? HistoricalPricePln { get; set; }
    public string HistoricalPriceDisplay => HistoricalPricePln is > 0 ? $"{HistoricalPricePln.Value:N0} PLN" : "brak";
    public double FinalPricePln { get; set; }
    public double AppliedMarkupPercent { get; set; }
    public double AppliedHistoricalBlendPercent { get; set; }
    public double AppliedWhatIfMaterialPriceChangePercent { get; set; } = 10.0;
    public double AppliedWhatIfProcessTimeChangePercent { get; set; } = -10.0;
    public double TotalHours => Processes.Where(x => x.Enabled).Sum(x => x.Hours);
    public int DetectedHoleCount => Math.Max(Geometry.TotalHoleCount, Drawing.EstimatedHoleCount2D);
    public string DetectedHoleCountDisplay
    {
        get
        {
            var count = DetectedHoleCount;
            if (count > 0) return count.ToString();
            if (Drawing.EstimatedHoleCount2D > 0) return Drawing.EstimatedHoleCount2D.ToString();
            var coverage = Geometry.UniquePartGroups > 0
                ? 100.0 * Geometry.FullyAnalyzedUniqueSolids / Geometry.UniquePartGroups
                : 0.0;
            if (!string.Equals(Geometry.HoleAnalysisState, "complete", StringComparison.OrdinalIgnoreCase))
                return $"nieustalone · STEP {coverage:0}%";
            return "0 · potwierdzony brak";
        }
    }
    public int PrecisionHoleCount => Math.Max(
        Geometry.Parts.Sum(p => p.Holes.Where(h => h.FitConfirmed || h.ReamedLikely || !string.IsNullOrWhiteSpace(h.ThreadCode))
            .Sum(h => Math.Max(1, h.Count) * Math.Max(1, p.Quantity))),
        Drawing.PrecisionHoleCount2D);
    public int DimensionalToleranceCount => Drawing.DimensionalTolerances.Count;
    public int GeometricToleranceCount => Drawing.GeometricTolerances.Count;
    public List<EngineTimingItem> EngineTimings { get; set; } = [];
    public EvidenceOrchestrationSummary Evidence { get; set; } = new();
    // FIX12A: contract-first shadow CAPP graph. Audit-only: it cannot alter CostEngine output.
    public ShadowTechnologyGraph ShadowTechnologyGraph { get; set; } = new();
    public double AnalysisWallSeconds { get; set; }
    // FIX18: binds a calculated result to the pricing/model settings active at
    // analysis time. A later settings change makes offer export require recalculation.
    public string ReleaseSettingsHash { get; set; } = "";
    public double AnalysisWorkSeconds => EngineTimings.Sum(x => Math.Max(0, x.ElapsedSeconds));
    public double ParallelEfficiencyGainPercent => AnalysisWorkSeconds > 0 && AnalysisWallSeconds > 0
        ? Math.Max(0, (AnalysisWorkSeconds - AnalysisWallSeconds) / AnalysisWorkSeconds * 100.0)
        : 0;
}

public sealed class QuoteProject
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public int Revision { get; set; }
    public string Name { get; set; } = "Nowa wycena";
    public string Customer { get; set; } = "";
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime ModifiedAt { get; set; } = DateTime.Now;
    public double? ManualWeightKg { get; set; }
    // Persisted acknowledgement so re-analysis does not ask the same multi-root
    // question again. The decision never guesses automatically.
    public string MultiRootDecision { get; set; } = "";
    // FIX13A: manual process decisions are project data, not transient UI state.
    public Dictionary<string, ProcessManualOverride> ProcessOverrides { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    // Persistent lightweight checkpoint. Heavy analyzer outputs remain in EngineResultCache
    // by content hash; this state only records which source files finished before interruption.
    public AnalysisResumeState ResumeState { get; set; } = new();
    public List<ProjectDocument> Documents { get; set; } = [];
    public ProductionActuals Actuals { get; set; } = new();
    public HistoryImportMetadata? HistoryImport { get; set; }
    public AnalysisResult? Analysis { get; set; }
    public QuoteReleaseOverride ReleaseOverride { get; set; } = new();
    public FrozenQuoteSnapshot? FrozenSnapshot { get; set; }
}

public sealed class ProjectListItem
{
    public Guid Id { get; set; }
    public string Name { get; set; } = "";
    public string Customer { get; set; } = "";
    public DateTime ModifiedAt { get; set; }
    public double? PricePln { get; set; }
    public int Revision { get; set; }
    public string Subtitle => string.IsNullOrWhiteSpace(Customer)
        ? $"{ModifiedAt:dd.MM.yyyy HH:mm}"
        : $"{Customer} · {ModifiedAt:dd.MM.yyyy}";
}


public sealed class CuttingTechnologyProfile
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string MaterialContains { get; set; } = "";
    public double MinThicknessMm { get; set; }
    public double MaxThicknessMm { get; set; }
    public double SpeedMmMin { get; set; }
    public double PierceSeconds { get; set; }
    public double RapidSpeedMmMin { get; set; } = 12000;
    public double MarkingSpeedMmMin { get; set; } = 3000;
    public double CurveSpeedFactor { get; set; } = 0.80;
    public double MinimumHoleDiameterMm { get; set; } = 8.0;
    public double MinimumHoleToThicknessRatio { get; set; } = 0.80;
    public bool SupportsInternalContours { get; set; } = true;

    public bool Matches(string material, double thicknessMm)
    {
        if (thicknessMm <= 0)
            return false;
        if (MinThicknessMm > 0 && thicknessMm < MinThicknessMm)
            return false;
        if (MaxThicknessMm > 0 && thicknessMm > MaxThicknessMm)
            return false;
        if (!string.IsNullOrWhiteSpace(MaterialContains) &&
            !material.Contains(MaterialContains, StringComparison.OrdinalIgnoreCase))
            return false;
        return SpeedMmMin > 0;
    }
}


public sealed class SheetStockDefinition
{
    public string Name { get; set; } = "3000×1500";
    public double Xmm { get; set; } = 3000;
    public double Ymm { get; set; } = 1500;
    public bool Enabled { get; set; } = true;
}

public sealed class NestingEstimate
{
    public bool Available { get; set; }
    // FIX12B: rectangular STEP nesting is advisory unless its confidence/factor are sane.
    // This flag states whether it was actually allowed to influence the material price.
    public bool UsedForMaterialCost { get; set; }
    public int SheetCount { get; set; }
    public string SheetFormat { get; set; } = "";
    public double NetPlateAreaM2 { get; set; }
    public double PurchasedSheetAreaM2 { get; set; }
    public double UtilizationPercent { get; set; }
    public double WastePercent { get; set; }
    public double MaterialFactor { get; set; } = 1.0;
    public int Confidence { get; set; }
    public string Basis { get; set; } = "";
}

public sealed class PurchasedPartPrice
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Category { get; set; } = "";
    // Groups separated with '&' are all required; alternatives inside a group use '|'.
    // Example: "ŚRUBA|SRUBA&M8X30|M8 X 30".
    public string MatchExpression { get; set; } = "";
    public string Unit { get; set; } = "szt.";
    public double PricePln { get; set; }
    public bool Enabled { get; set; } = true;
    public bool MarketReference { get; set; } = true;
    public string Source { get; set; } = "";
    public string SourceDate { get; set; } = "2026-08";
    public string PriceText => $"{PricePln:0.##} PLN/{Unit}";
}

public sealed class PurchasedPartEstimate
{
    public string PartNumber { get; set; } = "";
    public string Description { get; set; } = "";
    public string PriceCode { get; set; } = "";
    public string PriceName { get; set; } = "";
    public double Quantity { get; set; }
    public double UnitPricePln { get; set; }
    public double TotalPricePln { get; set; }
    public int Confidence { get; set; }
    public string Basis { get; set; } = "";
}

public sealed class QualityCostEstimate
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public double CostPln { get; set; }
    public int Confidence { get; set; }
    public string Basis { get; set; } = "";
}

public sealed class CostConfidenceItem
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public double AmountPln { get; set; }
    public int Confidence { get; set; }
    public double SharePercent { get; set; }
    public string NextAction { get; set; } = "";
    public string Basis { get; set; } = "";
    public string ConfidenceText => $"{Confidence}%";
}

public sealed class ProjectClassResult
{
    public string Code { get; set; } = "MIXED";
    public string Name { get; set; } = "Konstrukcja mieszana";
    public int Confidence { get; set; } = 50;
    public string Basis { get; set; } = "";
}

public sealed class ProcessCalibrationProfile
{
    public string ProcessCode { get; set; } = "";
    public string WorkstationCode { get; set; } = "";
    public string ProjectClass { get; set; } = "";
    public int Samples { get; set; }
    public double Factor { get; set; } = 1.0;
    public int Confidence { get; set; }
    public string Basis { get; set; } = "";
}

public sealed class CompanyProfileInfo
{
    public int Version { get; set; }
    public int HistoryProjects { get; set; }
    public int Confidence { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public bool Applied { get; set; } = true;
    public string ValidationStatus { get; set; } = "OCZEKUJE";
    public string ValidationSummary { get; set; } = "";
    public double ValidationBaselineMapePercent { get; set; }
    public double ValidationProposedMapePercent { get; set; }
    public int ValidationProjects { get; set; }
    public string Status => HistoryProjects <= 0
        ? "Profil bazowy — brak zaimportowanej historii"
        : $"Profil firmy · {HistoryProjects} projektów · pewność {Confidence}%";
}

public sealed class CostingSettings
{
    // Normal mode is intentionally automatic. Advanced settings remain available as a fallback,
    // but imported history is allowed to configure the company profile without user tuning.
    public bool AutoCompanyProfileEnabled { get; set; } = true;
    public bool AutoApplyHistoryProfile { get; set; } = true;
    public int CompanyProfileVersion { get; set; }
    public int CompanyProfileHistoryProjects { get; set; }
    public int CompanyProfileConfidence { get; set; }
    public DateTime? CompanyProfileUpdatedAt { get; set; }
    public List<ProcessCalibrationProfile> CompanyProcessFactors { get; set; } = [];
    // Snapshot of manual/base workstation settings before the first automatic history profile.
    // It makes a future "clear history and calibration" reversible instead of destructive.
    public List<WorkstationDefinition> CompanyProfileBaselineWorkstations { get; set; } = [];
    public string CompanyProfileBaselinePricingProfileName { get; set; } = "";
    public bool? CompanyProfileBaselineRatesConfirmedByCompany { get; set; }
    // FIX17: deterministic train/holdout validation. Holdout projects never enter
    // learned factors and can block an automatic profile update when MAPE regresses.
    public bool CalibrationValidationEnabled { get; set; } = true;
    public int CalibrationValidationMinimumProjects { get; set; } = 6;
    public double CalibrationValidationHoldoutPercent { get; set; } = 25.0;
    public double CalibrationValidationMaxRegressionPercentPoints { get; set; } = 2.0;
    public string CompanyProfileValidationStatus { get; set; } = "OCZEKUJE";
    public string CompanyProfileValidationSummary { get; set; } = "";
    public int CompanyProfileValidationTrainingProjects { get; set; }
    public int CompanyProfileValidationProjects { get; set; }
    public double CompanyProfileValidationBaselineMapePercent { get; set; }
    public double CompanyProfileValidationProposedMapePercent { get; set; }
    public double CompanyProfileValidationBaselineBiasPercent { get; set; }
    public double CompanyProfileValidationProposedBiasPercent { get; set; }
    public double CompanyProfileValidationBaselineP90Percent { get; set; }
    public double CompanyProfileValidationProposedP90Percent { get; set; }
    public int CompanyProfileValidationRollingFolds { get; set; }
    public double CompanyProfileValidationRollingBaselineMapePercent { get; set; }
    public double CompanyProfileValidationRollingProposedMapePercent { get; set; }

    public string PricingProfileName { get; set; } = "ZKS 2026 — RBH po koszcie całkowitym";
    public bool RatesConfirmedByCompany { get; set; } = true;
    public int WorkstationDefaultsVersion { get; set; } = 4;
    public double DefaultSteelDensityKgM3 { get; set; } = 7850;
    public double MaterialPricePlnKg { get; set; } = 7.00;
    public string MaterialPriceSource { get; set; } = "cennik zakładowy / wartość robocza";
    public string MaterialPriceSourceDate { get; set; } = "2026-08-01";
    public int PriceWarningDays { get; set; } = 60;
    public int PriceCriticalDays { get; set; } = 90;
    // FIX16: sensitivity scenarios are decision support only. They never alter the
    // saved P50 quote and use already calculated cost lines (no STEP/OCR rerun).
    public double WhatIfMaterialPriceChangePercent { get; set; } = 10.0;
    public double WhatIfProcessTimeChangePercent { get; set; } = -10.0;
    [JsonIgnore]
    public CalibrationProfile RuntimeCalibration { get; set; } = new();
    // Optional per-grade rates. Empty by default so existing company pricing is unchanged.
    // When populated, FIX13 prices only masses that are safely assigned to that grade.
    public Dictionary<string, double> MaterialPriceOverridesPlnKg { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public double MaterialWastePercent { get; set; } = 4.0;
    public double CuttingRatePlnH { get; set; } = 326;
    // Geometry-driven cutting model. These are shop assumptions and should be
    // calibrated per machine/material/thickness.
    public double CuttingReferenceSpeedMmMin { get; set; } = 1500;
    public double CuttingPierceSeconds { get; set; } = 2.0;
    public double CuttingSetupMinutes { get; set; } = 15.0;
    public double CuttingRapidSpeedMmMin { get; set; } = 12000;
    public double CuttingMarkingSpeedMmMin { get; set; } = 3000;
    public double CuttingCurveSpeedFactor { get; set; } = 0.80;
    public double CuttingExtraFileHandlingMinutes { get; set; } = 1.5;
    public double CuttingMinimumHoleDiameterMm { get; set; } = 8.0;
    public double CuttingMinimumHoleToThicknessRatio { get; set; } = 0.80;
    public List<CuttingTechnologyProfile> CuttingProfiles { get; set; } = [];
    public double WeldingRatePlnH { get; set; } = 224;
    public double MachiningRatePlnH { get; set; } = 166;
    // Feature-driven CNC timing. Values are shop defaults and should be calibrated.
    public double CncSetupMinutesPerPartGroup { get; set; } = 20.0;
    public double CncLoadMinutesPerPart { get; set; } = 2.0;
    public double CncToolChangeSeconds { get; set; } = 8.0;
    public double CncRapidSecondsPerHole { get; set; } = 3.5;
    public double CncDrillFeedMmMin { get; set; } = 180.0;
    public double CncReamFeedMmMin { get; set; } = 100.0;
    public double CncTapFeedMmMin { get; set; } = 220.0;
    public double CncSecondaryFeedMmMin { get; set; } = 120.0;
    public double CncComplexityMinutesPer100Faces { get; set; } = 12.0;
    // FIX12B: each unique machined family needs programming/fixture planning even when
    // the number of physical orientations is only 1-4. This is separate from setupCount.
    public double CncProgrammingMinutesPerUniqueGroup { get; set; } = 25.0;
    public double CncManualMinutesPerMachinedPart { get; set; } = 8.0;
    public double CncManualMinutesPerPrecisionHole { get; set; } = 2.0;
    public double CncManualMinutesPerSecondaryHole { get; set; } = 3.0;
    public double PaintingRatePlnH { get; set; } = 275;
    public double AssemblyRatePlnH { get; set; } = 224;
    // FIX12B fabrication-complexity defaults. These model real fit-up, alignment and
    // manipulation burden that is not represented by arc time alone.
    public double AssemblyMinutesPerPart { get; set; } = 7.0;
    public double AssemblyMinutesPerContact { get; set; } = 10.0;
    public double AssemblyHeavyHandlingMinutesPer1000Kg { get; set; } = 45.0;
    public double AssemblyLargeEnvelopeMinutesPerMeter { get; set; } = 20.0;
    public double PrepManualHoursPerUniqueGroup { get; set; } = 0.04;
    public double PrepManualHoursPerPhysicalPart { get; set; } = 0.012;
    public double PrepMachineHoursPerPlateGroup { get; set; } = 0.04;
    public double PrepMachineHoursPerBevelFace { get; set; } = 0.006;
    public double NestingPriceAuthorityMaxFactor { get; set; } = 1.35;
    public int NestingPriceAuthorityMinConfidence { get; set; } = 74;
    public double MarkupPercent { get; set; } = 12.0;
    public double HistoricalBlendPercent { get; set; } = 0.0;
    public double ContactToleranceMm { get; set; } = 0.25;
    public double BevelMinAngleDeg { get; set; } = 20;
    public double BevelMaxAngleDeg { get; set; } = 70;

    // Welding model - deliberately editable shop assumptions.
    public double DefaultWeldSizeAmm { get; set; } = 6.0;
    public string DefaultWeldProcessCode { get; set; } = "135";
    public double WeldSteelDensityKgM3 { get; set; } = 7850;
    public double WeldConsumableEfficiencyPercent { get; set; } = 90;
    public double WeldConsumablePricePlnKg { get; set; } = 22;
    public double WeldDepositionRate111KgH { get; set; } = 1.6;
    public double WeldDepositionRate135KgH { get; set; } = 3.5;
    public double WeldDepositionRate136KgH { get; set; } = 4.5;
    public double WeldHandlingMinutesPerJoint { get; set; } = 6.0;
    public double WeldHandlingHoursPerMeter { get; set; } = 0.04;

    // Painting / surface-preparation model - editable shop assumptions.
    public double DefaultPaintDftMicron { get; set; } = 120;
    public double DefaultPaintVolumeSolidsPercent { get; set; } = 60;
    public double PaintLossPercent { get; set; } = 15;
    public double PaintPricePlnL { get; set; } = 45;
    public double SurfacePrepM2PerHour { get; set; } = 18;
    public double PaintApplicationM2PerHour { get; set; } = 20;
    public double PaintStripeCoatMetersPerHour { get; set; } = 30;

    // Automatic process modelling. These values stay hidden from the normal workflow and
    // are progressively corrected by the company profile imported from historical jobs.
    public bool AutomaticWorkstationSelection { get; set; } = true;
    public bool NestingCostEnabled { get; set; } = true;
    public double NestingKerfMm { get; set; } = 3.0;
    public double NestingEdgeMarginMm { get; set; } = 10.0;
    public double NestingFallbackUtilizationPercent { get; set; } = 82.0;
    public List<SheetStockDefinition> SheetStocks { get; set; } =
    [
        new() { Name = "2000×1000", Xmm = 2000, Ymm = 1000 },
        new() { Name = "2500×1250", Xmm = 2500, Ymm = 1250 },
        new() { Name = "3000×1500", Xmm = 3000, Ymm = 1500 },
        new() { Name = "4000×2000", Xmm = 4000, Ymm = 2000 },
        new() { Name = "6000×2000", Xmm = 6000, Ymm = 2000 }
    ];

    public double CncRemovalRateCm3Min { get; set; } = 110.0;
    public double CncAdditionalSetupMinutes { get; set; } = 18.0;
    public double CncSetupRepeatDiscountPercent { get; set; } = 65.0;
    // Automatic series effect: setup/programming is amortized for repeated identical parts.
    public double SeriesSetupExponent { get; set; } = 0.82;
    public double SeriesMinimumRunFactor { get; set; } = 0.62;
    public double WeldFitUpMinutesPerJoint { get; set; } = 4.5;
    public double WeldRepositionMinutesBase { get; set; } = 5.0;
    public double WeldRepositionHeavyMultiplier { get; set; } = 2.2;
    public double PaintHandlingMinutesBase { get; set; } = 12.0;
    public double PaintHandlingMinutesPer1000Kg { get; set; } = 7.0;

    // Quality/documentation assumptions. A detected requirement is never silently ignored.
    public double QualityMtSetupPln { get; set; } = 180.0;
    public double QualityMtPerMeterPln { get; set; } = 22.0;
    public double QualityUtSetupPln { get; set; } = 300.0;
    public double QualityUtPerMeterPln { get; set; } = 45.0;
    public double QualityCmmBasePln { get; set; } = 280.0;
    public double QualityDftReportPln { get; set; } = 120.0;
    public double QualityMaterialCertificatePln { get; set; } = 55.0;
    public double QualityDocumentationPln { get; set; } = 90.0;

    public List<PurchasedPartPrice> PurchasedPartPrices { get; set; } =
    [
        new() { Code="BOLT_M8X30_88", Category="Elementy złączne", Name="Śruba M8×30 kl. 8.8 ocynk", MatchExpression="ŚRUBA|SRUBA&M8X30|M8 X 30|M8×30", PricePln=0.23, Source="Polska — referencja rynku detalicznego/bulk", SourceDate="2026-08" },
        new() { Code="NUT_M8", Category="Elementy złączne", Name="Nakrętka M8 DIN 934 ocynk", MatchExpression="NAKRĘTKA|NAKRETKA&M8", PricePln=0.11, Source="Polska — referencja ofert krajowych, cena startowa", SourceDate="2026-08" },
        new() { Code="WASHER_M8", Category="Elementy złączne", Name="Podkładka M8 DIN 125 ocynk", MatchExpression="PODKŁADKA|PODKLADKA&M8", PricePln=0.04, Source="Polska — referencja ofert krajowych, cena startowa", SourceDate="2026-08" },
        new() { Code="BOLT_M12X40_88", Category="Elementy złączne", Name="Śruba M12×40 kl. 8.8 ocynk", MatchExpression="ŚRUBA|SRUBA&M12X40|M12 X 40|M12×40", PricePln=0.90, Source="Polska — referencja rynku detalicznego/bulk", SourceDate="2026-08" },
        new() { Code="NUT_M12", Category="Elementy złączne", Name="Nakrętka M12 DIN 934 ocynk", MatchExpression="NAKRĘTKA|NAKRETKA&M12", PricePln=0.20, Source="Polska — referencja rynku detalicznego/bulk", SourceDate="2026-08" },
        new() { Code="WASHER_M12", Category="Elementy złączne", Name="Podkładka M12 DIN 125 ocynk", MatchExpression="PODKŁADKA|PODKLADKA&M12", PricePln=0.10, Source="Polska — referencja rynku detalicznego/bulk", SourceDate="2026-08" },
        new() { Code="BRG_6204_2RS", Category="Łożyska", Name="Łożysko 6204 2RS", MatchExpression="6204&2RS|2RSH|2RSR", PricePln=13.00, Source="Polska — przekrój aktualnych ofert detalicznych", SourceDate="2026-08" },
        new() { Code="BRG_6205_2RS", Category="Łożyska", Name="Łożysko 6205 2RS", MatchExpression="6205&2RS|2RSH|2RSR", PricePln=13.00, Source="Polska — przekrój ofert detalicznych", SourceDate="2026-08" },
        new() { Code="BUSH_20_25_20", Category="Tuleje", Name="Tuleja ślizgowa brąz 20×25×20", MatchExpression="TULEJA&20X25X20|20 X 25 X 20|20×25×20", PricePln=24.00, Source="Polska — referencja detaliczna netto", SourceDate="2026-08" },
        new() { Code="CYL_32_100", Category="Pneumatyka", Name="Siłownik pneumatyczny Ø32 skok 100", MatchExpression="SIŁOWNIK|SILOWNIK&32&100", PricePln=550.00, Source="Polska — referencja standardowych wykonań; duży rozrzut cen", SourceDate="2026-08" }
    ];

    // Automatic shop Rule Engine. Values are editable shop assumptions, not market truth.
    public bool RuleEngineEnabled { get; set; } = true;
    public bool RuleTightToleranceForcesCnc { get; set; } = true;
    public double RuleDeepBlindHoleRatio { get; set; } = 6.0;
    public double RuleHeavyHandlingKg { get; set; } = 1000.0;
    public double RuleLargeWeldAmm { get; set; } = 8.0;
    public bool RuleHighStrengthSteelWarning { get; set; } = true;

    // Plan vs actual self-calibration.
    public bool AutoCalibrationEnabled { get; set; } = true;
    public int AutoCalibrationMinSamples { get; set; } = 2;
    public double AutoCalibrationMinFactor { get; set; } = 0.70;
    public double AutoCalibrationMaxFactor { get; set; } = 1.35;

    // Client package import safety.
    public double MaxZipExtractGb { get; set; } = 10.0;

    // Company 2026 cost-center rates supplied by the user. RatePlnPerHour is the
    // effective RBH after total cost. Internal routing stations may share one SSK
    // (for example WELD 111/135/136 and ASSY all use 3401).
    public List<WorkstationDefinition> Workstations { get; set; } =
    [
        new() { Code = "CNC_LARGE", Name = "CNC ciężkie / duże", ProcessCode = "CNC", Priority = 30, RatePlnPerHour = 388, MaxXmm = 6000, MaxYmm = 2500, MaxZmm = 1500, MaxWeightKg = 10000, CostCenterCode="3201", CostCenterName="OBRÓBKA MECHANICZNA CIĘŻKA", DisplayInRateCard=true, DirectLaborRatePlnH=88.71, DepartmentOverheadPercent=305.34, DepartmentCostRatePlnH=270.87, ManufacturingCostRatePlnH=360, GeneralOverheadPercent=7.83, GeneralCostRatePlnH=28.16, VariableDepartmentPercent=14.40, VariableDepartmentRatePlnH=39.01 },
        new() { Code = "CNC_MEDIUM", Name = "CNC średnie", ProcessCode = "CNC", Priority = 20, RatePlnPerHour = 166, TimeFactor = 1.00, MaxXmm = 3000, MaxYmm = 1500, MaxZmm = 1200, MaxWeightKg = 5000, CostCenterCode="3202", CostCenterName="OBRÓBKA MECHANICZNA ŚREDNIA", DisplayInRateCard=true, DirectLaborRatePlnH=46.09, DepartmentOverheadPercent=234.51, DepartmentCostRatePlnH=108.09, ManufacturingCostRatePlnH=154, GeneralOverheadPercent=7.83, GeneralCostRatePlnH=12.07, VariableDepartmentPercent=14.69, VariableDepartmentRatePlnH=15.88 },
        new() { Code = "CNC_SMALL", Name = "CNC lekkie / małe", ProcessCode = "CNC", Priority = 10, RatePlnPerHour = 166, TimeFactor = 0.95, MaxXmm = 1000, MaxYmm = 700, MaxZmm = 700, MaxWeightKg = 500, CostCenterCode="3203", CostCenterName="OBRÓBKA MECHANICZNA LEKKA", DisplayInRateCard=true, DirectLaborRatePlnH=46.09, DepartmentOverheadPercent=234.51, DepartmentCostRatePlnH=108.09, ManufacturingCostRatePlnH=154, GeneralOverheadPercent=7.83, GeneralCostRatePlnH=12.07, VariableDepartmentPercent=14.69, VariableDepartmentRatePlnH=15.88 },
        new() { Code = "CNC_MANUAL_3205", Name = "Operacje ręczne obróbki", ProcessCode = "CNC_MANUAL", Priority = 10, RatePlnPerHour = 166, AutomaticRoutingCandidate=true, CostCenterCode="3205", CostCenterName="OBRÓBKA MECHANICZNA - OPERACJE RĘCZNE", DisplayInRateCard=true, DirectLaborRatePlnH=46.09, DepartmentOverheadPercent=234.51, DepartmentCostRatePlnH=108.09, ManufacturingCostRatePlnH=154, GeneralOverheadPercent=7.83, GeneralCostRatePlnH=12.07, VariableDepartmentPercent=14.69, VariableDepartmentRatePlnH=15.88 },

        new() { Code = "CUT_GENERAL", Name = "Cięcie termiczne", ProcessCode = "CUT", Priority = 10, RatePlnPerHour = 326, MaxXmm = 3000, MaxYmm = 1500, MaxThicknessMm = 25, CostCenterCode="3301", CostCenterName="CIĘCIE TERMICZNE", DisplayInRateCard=true, DirectLaborRatePlnH=64.72, DepartmentOverheadPercent=367.77, DepartmentCostRatePlnH=238.02, ManufacturingCostRatePlnH=303, GeneralOverheadPercent=7.83, GeneralCostRatePlnH=23.70, VariableDepartmentPercent=15.65, VariableDepartmentRatePlnH=37.26 },
        new() { Code = "PREP_MANUAL_3302", Name = "Przygotowanie produkcji - ręczne", ProcessCode = "PREP_MANUAL", Priority = 10, RatePlnPerHour = 326, AutomaticRoutingCandidate=true, CostCenterCode="3302", CostCenterName="PRZYGOT. PRODUKCJI - OBRÓBKA RĘCZNA", DisplayInRateCard=true, DirectLaborRatePlnH=64.72, DepartmentOverheadPercent=367.77, DepartmentCostRatePlnH=238.02, ManufacturingCostRatePlnH=303, GeneralOverheadPercent=7.83, GeneralCostRatePlnH=23.70, VariableDepartmentPercent=15.65, VariableDepartmentRatePlnH=37.26 },
        new() { Code = "PREP_MACHINE_3303", Name = "Przygotowanie produkcji - maszynowe", ProcessCode = "PREP_MACHINE", Priority = 10, RatePlnPerHour = 326, AutomaticRoutingCandidate=true, CostCenterCode="3303", CostCenterName="PRZYGOT. PRODUKCJI - OBRÓBKA MASZYNOWA", DisplayInRateCard=true, DirectLaborRatePlnH=64.72, DepartmentOverheadPercent=367.77, DepartmentCostRatePlnH=238.02, ManufacturingCostRatePlnH=303, GeneralOverheadPercent=7.83, GeneralCostRatePlnH=23.70, VariableDepartmentPercent=15.65, VariableDepartmentRatePlnH=37.26 },

        new() { Code = "WELD_135", Name = "Spawanie MAG 135", ProcessCode = "WELD", MatchTag = "135", Priority = 10, RatePlnPerHour = 224, CostCenterCode="3401", CostCenterName="MONTAŻ I SPAWANIE", DisplayInRateCard=true, DirectLaborRatePlnH=99.07, DepartmentOverheadPercent=109.72, DepartmentCostRatePlnH=108.70, ManufacturingCostRatePlnH=208, GeneralOverheadPercent=7.83, GeneralCostRatePlnH=16.27, VariableDepartmentPercent=21.34, VariableDepartmentRatePlnH=23.20 },
        new() { Code = "WELD_136", Name = "Spawanie MAG 136", ProcessCode = "WELD", MatchTag = "136", Priority = 10, RatePlnPerHour = 224, CostCenterCode="3401", CostCenterName="MONTAŻ I SPAWANIE" },
        new() { Code = "WELD_111", Name = "Spawanie MMA 111", ProcessCode = "WELD", MatchTag = "111", Priority = 10, RatePlnPerHour = 224, CostCenterCode="3401", CostCenterName="MONTAŻ I SPAWANIE" },
        new() { Code = "ASSY_GENERAL", Name = "Montaż / dopasowanie", ProcessCode = "ASSY", Priority = 10, RatePlnPerHour = 224, MaxXmm = 10000, MaxYmm = 5000, MaxZmm = 4000, MaxWeightKg = 20000, CostCenterCode="3401", CostCenterName="MONTAŻ I SPAWANIE" },
        new() { Code = "SURF_GENERAL", Name = "Czyszczenie i malowanie", ProcessCode = "SURF", Priority = 10, RatePlnPerHour = 275, MaxXmm = 6000, MaxYmm = 2500, MaxZmm = 2500, MaxWeightKg = 5000, CostCenterCode="3402", CostCenterName="CZYSZCZENIE I MALOWANIE", DisplayInRateCard=true, DirectLaborRatePlnH=21.50, DepartmentOverheadPercent=1086.03, DepartmentCostRatePlnH=233.50, ManufacturingCostRatePlnH=255, GeneralOverheadPercent=7.83, GeneralCostRatePlnH=19.97, VariableDepartmentPercent=13.38, VariableDepartmentRatePlnH=31.25 },
        new() { Code = "WELD_ROBOT_3403", Name = "Spawanie robotyzowane", ProcessCode = "REFERENCE", Priority = 90, RatePlnPerHour = 247, AutomaticRoutingCandidate=false, CostCenterCode="3403", CostCenterName="SPAWANIE ROBOTYZOWANE", DisplayInRateCard=true, DirectLaborRatePlnH=84.12, DepartmentOverheadPercent=172.05, DepartmentCostRatePlnH=144.73, ManufacturingCostRatePlnH=229, GeneralOverheadPercent=7.83, GeneralCostRatePlnH=17.92, VariableDepartmentPercent=16.65, VariableDepartmentRatePlnH=24.09 },
        new() { Code = "ZKS_GENERAL", Name = "ZKS", ProcessCode = "REFERENCE", Priority = 99, RatePlnPerHour = 236, AutomaticRoutingCandidate=false, CostCenterCode="ZKS", CostCenterName="ZKS", DisplayInRateCard=true, DirectLaborRatePlnH=82.84, DepartmentOverheadPercent=164.51, DepartmentCostRatePlnH=136.28, ManufacturingCostRatePlnH=219, GeneralOverheadPercent=7.83, GeneralCostRatePlnH=17.16, VariableDepartmentPercent=18.20, VariableDepartmentRatePlnH=24.80 }
    ];
}
