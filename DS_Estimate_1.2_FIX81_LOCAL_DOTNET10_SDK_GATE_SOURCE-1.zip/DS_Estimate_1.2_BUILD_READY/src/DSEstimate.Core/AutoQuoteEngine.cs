namespace DSEstimate.Core;

public static class AutoQuoteEngine
{
    public static void Apply(AnalysisResult r)
    {
        r.AutoRoute = BuildRoute(r);

        var blocking = r.Risks.Count(x => x.Blocking);
        var assumptions = CountAssumptions(r);
        var externalUnpriced = r.AutoRoute.Count(x => x.RequiresExternalRate);
        var seriousDataIssue =
            (r.Package.MultipleRevisionsDetected && !r.Package.RevisionSelectionConfident) ||
            r.Drawing.Conflicts.Any(x => !x.IsLocalVariation && x.Level >= RiskLevel.High) ||
            r.Risks.Any(x => x.Code == "BOM_QUANTITY_MISMATCH");

        var status = blocking > 0 || seriousDataIssue
            ? "WYMAGA UWAGI"
            : externalUnpriced > 0
                ? "NIEPEŁNA"
                : !r.RatesConfirmedByCompany || assumptions > 0 || r.ConfidencePercent < 82
                    ? "WSTĘPNA"
                    : "GOTOWA";

        // 1.0.1: model niepewności jest wydzielony do QuoteUncertaintyModel, dzięki
        // czemu jest testowalny jednostkowo i uwzględnia udział kosztu opartego na
        // założeniach (masa/gęstość, kooperacja, części zakupowe).
        var uncertaintyModel = QuoteUncertaintyModel.Evaluate(r);
        var uncertainty = uncertaintyModel.UncertaintyPercent;
        var lowFactor = uncertaintyModel.LowFactor;
        var highFactor = uncertaintyModel.HighFactor;

        var assumptionNames = r.Risks
            .Where(IsAssumptionRisk)
            .Select(x => x.Title)
            .Distinct()
            .Take(4)
            .ToList();

        if (externalUnpriced > 0)
            assumptionNames.Add($"{externalUnpriced} oper. zewnętrznych bez stawki");
        if (!r.RatesConfirmedByCompany)
            assumptionNames.Add("stawki robocze - niepotwierdzone firmowo");
        var projectConflictCount = r.Drawing.Conflicts.Count(x => !x.IsLocalVariation);
        if (projectConflictCount > 0)
            assumptionNames.Add($"{projectConflictCount} konflikt(y) danych między dokumentami");
        if (r.Package.MultipleRevisionsDetected && !r.Package.RevisionSelectionConfident)
            assumptionNames.Add("niejednoznaczne rewizje w jednej paczce");

        var historyDiff = r.HistoricalPricePln.HasValue && r.HistoricalPricePln.Value > 0
            ? (r.FinalPricePln - r.HistoricalPricePln.Value) / r.HistoricalPricePln.Value * 100.0
            : (double?)null;

        // FIX12E: process costs may still be useful when the root-project mass is
        // unknown, but they must never be presented as a recommended selling price.
        var materialBasisMissing = !r.HasWeight && r.MaterialCostPln <= 0.0001;
        var offerPriceAvailable = !materialBasisMissing && blocking == 0;
        var displayedRecommendedPrice = offerPriceAvailable ? r.FinalPricePln : 0;
        var recognizedMaterial = Math.Max(r.MaterialCostPln, r.RecognizedPartialMaterialCostPln);
        var recognizedCost = r.CostTotalPln + Math.Max(0, recognizedMaterial - r.MaterialCostPln);
        var coveredFamilies = r.Drawing.HybridMassContributions
            .Where(x => x.MassKg > 0.001 && !string.Equals(x.FamilyKey, r.Drawing.ResolvedRootEntityKey, StringComparison.OrdinalIgnoreCase))
            .Select(x => x.FamilyKey)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Count();
        var unresolvedFamilies = r.Drawing.ResolvedRootBomFamilyCount > 0
            ? Math.Max(0, r.Drawing.ResolvedRootBomFamilyCount - coveredFamilies)
            : 0;
        var priceLabel = !offerPriceAvailable
            ? "CENA OFERTOWA NIE WYZNACZONA"
            : externalUnpriced > 0 ? "CENA CZĘŚCIOWA (BEZ KOOPERACJI)" : "CENA REKOMENDOWANA";
        var completenessNote = !offerPriceAvailable
            ? $"Brak bezpiecznej podstawy materiałowej lub istnieje {blocking} ryzyk blokujących. " +
              $"Koszt rozpoznanych operacji i materiału / rozpoznanego zakresu: {recognizedCost:0.##} PLN" +
              (recognizedMaterial > 0 ? $" (w tym rozpoznany materiał {recognizedMaterial:0.##} PLN; pokrycie masy rodzin {r.Drawing.HybridMassCoveragePercent:0.#}%; nierozwiązane rodziny {unresolvedFamilies})" : "") +
              ". To nie jest cena ofertowa."
            : externalUnpriced > 0
                ? $"Kwota nie zawiera {externalUnpriced} operacji zewnętrznych bez stawki. Nie traktuj jej jako kompletnej oferty."
                : "Cena zawiera wszystkie automatycznie rozpoznane pozycje kosztowe.";

        r.AutoQuote = new AutoQuoteSummary
        {
            Status = status,
            StatusDetail = BuildStatusDetail(r, blocking, assumptions, externalUnpriced),
            IsPriceComplete = offerPriceAvailable && externalUnpriced == 0,
            PriceLabel = priceLabel,
            PriceCompletenessNote = completenessNote,
            AutomaticAssumptionCount = assumptions,
            BlockingIssueCount = blocking,
            UnpricedExternalOperationCount = externalUnpriced,
            EnabledOperationCount = r.AutoRoute.Count,
            RecommendedPricePln = displayedRecommendedPrice,
            RecognizedCostPln = recognizedCost,
            RecognizedMaterialCostPln = recognizedMaterial,
            RecognizedMaterialCoveragePercent = r.HasWeight ? 100 : r.Drawing.HybridMassCoveragePercent,
            UnresolvedFamilyCount = unresolvedFamilies,
            PriceLowPln = offerPriceAvailable ? Math.Max(0, r.FinalPricePln * lowFactor) : 0,
            PriceHighPln = offerPriceAvailable ? Math.Max(0, r.FinalPricePln * highFactor) : 0,
            P50PricePln = displayedRecommendedPrice,
            UncertaintyPercent = uncertainty,
            UncertaintyDrivers = uncertaintyModel.DriversText,
            MainAssumptions = assumptionNames.Count == 0
                ? "Brak istotnych automatycznych założeń."
                : string.Join(" · ", assumptionNames.Distinct()),
            RouteSummary = string.Join(
                " → ",
                r.AutoRoute
                    .OrderBy(x => x.Sequence)
                    .Select(x => x.Name)),
            PricingProfileName = r.PricingProfileName,
            RatesStatus = r.RatesConfirmedByCompany ? "STAWKI FIRMOWE POTWIERDZONE" : "STAWKI ROBOCZE",
            ModeledCostPln = r.CostTotalPln,
            SellingUpliftPln = offerPriceAvailable ? r.FinalPricePln - r.CostTotalPln : 0,
            CostPerKg = r.WeightKg is > 0 ? r.CostTotalPln / r.WeightKg.Value : 0,
            PricePerKg = offerPriceAvailable && r.WeightKg is > 0 ? r.FinalPricePln / r.WeightKg.Value : 0,
            ConflictCount = projectConflictCount,
            RevisionWarning = r.Package.MultipleRevisionsDetected && !r.Package.RevisionSelectionConfident,
            HistoricalReferencePln = r.HistoricalPricePln,
            HistoricalDifferencePercent = historyDiff
        };
        TrustFoundationEngine.Apply(r);
        r.AutoQuote.ReadinessItems = BuildReadiness(r);
        QuoteScenarioEngine.Apply(r);
    }

    private static List<QuoteReadinessItem> BuildReadiness(AnalysisResult r)
    {
        var items = new List<QuoteReadinessItem>();

        void Add(string code, string label, string status, string detail, string nextAction, string target) =>
            items.Add(new QuoteReadinessItem
            {
                Code = code,
                Label = label,
                Status = status,
                Detail = detail,
                NextAction = nextAction,
                Target = target
            });

        Add(
            "MASS",
            "Masa",
            r.HasWeight ? "GOTOWE" : "BRAK",
            r.HasWeight ? $"{r.WeightKg:0.##} kg · źródło: {r.WeightSource}" : "Brak bezpiecznej masy całego projektu.",
            r.HasWeight ? "Sprawdź źródło masy w wyniku." : "Dodaj BOM/STEP z masą albo wpisz ręczną masę projektu.",
            "risks");

        var recognizedMaterial = Math.Max(r.MaterialCostPln, r.RecognizedPartialMaterialCostPln);
        var materialNamed = !string.IsNullOrWhiteSpace(r.Material) &&
                            !string.Equals(r.Material, "Nie rozpoznano", StringComparison.OrdinalIgnoreCase);
        var materialStatus = r.MaterialCostPln > 0 && materialNamed
            ? "GOTOWE"
            : r.MaterialCostPln > 0
                ? "SPRAWDŹ"
                : recognizedMaterial > 0 ? "CZĘŚCIOWO" : "BRAK";
        Add(
            "MATERIAL",
            "Materiał",
            materialStatus,
            r.MaterialCostPln > 0 && materialNamed
                ? $"{r.Material} · {r.MaterialCostPln:0.##} PLN"
                : r.MaterialCostPln > 0
                    ? $"Koszt {r.MaterialCostPln:0.##} PLN oparto na materiale nierozpoznanym lub założonym."
                : recognizedMaterial > 0
                    ? $"Rozpoznano tylko część zakresu: {recognizedMaterial:0.##} PLN."
                    : "Nie wyznaczono bezpiecznego kosztu materiału.",
            materialStatus == "GOTOWE" ? "Pokaż podstawę materiałową." : "Sprawdź materiał, ilości i pokrycie rodzin BOM/STEP.",
            "risks");

        Add(
            "RATES",
            "Stawki",
            r.RatesConfirmedByCompany ? "GOTOWE" : "SPRAWDŹ",
            r.RatesConfirmedByCompany ? r.PricingProfileName : $"Profil roboczy: {r.PricingProfileName}",
            r.RatesConfirmedByCompany ? "Pokaż profil firmowy." : "Potwierdź stawki firmowe w Ustawieniach.",
            "settings");

        void AddRoute(string code, string label, Func<bool>? additionalReady = null)
        {
            var route = r.AutoRoute.FirstOrDefault(x => string.Equals(x.Code, code, StringComparison.OrdinalIgnoreCase));
            if (route is null)
            {
                Add(code, label, "NIE DOTYCZY", "Dokumentacja nie wymaga tego procesu.", "Brak działania.", "processes");
                return;
            }

            var ready = !route.RequiresExternalRate && (additionalReady?.Invoke() ?? true);
            Add(
                code,
                label,
                ready ? "GOTOWE" : "SPRAWDŹ",
                route.RequiresExternalRate ? $"{route.Name}: brak stawki." : route.Basis,
                ready ? "Pokaż proces i źródło." : "Uzupełnij stawkę lub potwierdź zakres procesu.",
                "processes");
        }

        AddRoute("CUT", "Cięcie");
        AddRoute("CNC", "CNC");
        AddRoute("WELD", "Spawanie");
        AddRoute("PAINT", "Malowanie", () => r.AutoRoute.Any(x => x.Code == "SURF" && x.IncludedInPrice));
        AddRoute("NDT", "Badania NDT");
        AddRoute("BEND", "Gięcie");

        var otherExternal = r.AutoRoute
            .Where(x => x.RequiresExternalRate && x.Code is not "NDT" and not "BEND")
            .ToList();
        if (otherExternal.Count > 0)
        {
            Add(
                "EXTERNAL",
                "Kooperacja",
                "SPRAWDŹ",
                $"Bez stawki: {string.Join(", ", otherExternal.Select(x => x.Name))}.",
                "Uzupełnij stawki kooperacji albo potwierdź wyłączenie z oferty.",
                "processes");
        }

        var blockingRisks = r.Risks.Count(x => x.Blocking);
        Add(
            "RISKS",
            "Ryzyka",
            blockingRisks > 0 ? "BRAK" : r.Risks.Count > 0 ? "SPRAWDŹ" : "GOTOWE",
            blockingRisks > 0
                ? $"{blockingRisks} ryzyk blokuje bezpieczną cenę ofertową."
                : r.Risks.Count > 0 ? $"{r.Risks.Count} ostrzeżeń bez blokady." : "Brak wykrytych ryzyk.",
            r.Risks.Count > 0 ? "Otwórz listę ryzyk i wymaganych działań." : "Brak działania.",
            "risks");

        if (r.Package.MultipleRevisionsDetected)
        {
            Add(
                "REVISION",
                "Rewizje",
                r.Package.RevisionSelectionConfident ? "GOTOWE" : "BRAK",
                r.Package.RevisionSelectionConfident
                    ? "Wybrano najnowsze rewizje z wystarczającą pewnością."
                    : "Nie można bezpiecznie wskazać obowiązującej rewizji.",
                "Sprawdź aktywne i pominięte rewizje dokumentów.",
                "risks");
        }

        return items;
    }

    private static string ShortBasis(string? basis, int maxLen = 150)
    {
        if (string.IsNullOrWhiteSpace(basis))
            return string.Empty;

        var clean = basis.Replace("\r", " ").Replace("\n", " ").Trim();
        var stopTokens = new[]
        {
            " Parametry technologii są ustawieniami zakładowymi",
            " Stanowisko:",
            " Czas łuku ",
            " Przygotowanie ",
            " Czas bazowy ",
            " Kalibracja plan/wykonanie:"
        };

        foreach (var token in stopTokens)
        {
            var idx = clean.IndexOf(token, StringComparison.OrdinalIgnoreCase);
            if (idx > 0)
            {
                clean = clean[..idx].Trim();
                break;
            }
        }

        if (clean.Length <= maxLen)
            return clean;

        var cut = clean.LastIndexOf(';', maxLen);
        if (cut < 40)
            cut = maxLen;
        return clean[..cut].TrimEnd(' ', ';', '.', ',') + "…";
    }

    private static List<AutoRouteStep> BuildRoute(AnalysisResult r)
    {
        var route = new List<AutoRouteStep>();
        var seq = 10;

        void Add(
            string code,
            string name,
            string source,
            int confidence,
            double hours,
            double cost,
            bool included,
            string basis,
            bool requiresExternalRate = false)
        {
            route.Add(new AutoRouteStep
            {
                Sequence = seq,
                Code = code,
                Name = name,
                Source = source,
                Confidence = Math.Clamp(confidence, 1, 99),
                Hours = Math.Max(0, hours),
                CostPln = Math.Max(0, cost),
                IncludedInPrice = included,
                RequiresExternalRate = requiresExternalRate,
                Basis = ShortBasis(basis)
            });
            seq += 10;
        }

        var weightText = r.WeightKg.HasValue
            ? $"{r.WeightKg.Value:0.##} kg"
            : "brak";

        var routeMaterialCost = Math.Max(r.MaterialCostPln, r.RecognizedPartialMaterialCostPln);
        Add(
            "MAT",
            r.MaterialCostPln > 0 ? "Materiał / półfabrykat" : "Materiał / półfabrykat — rozpoznany zakres",
            r.Material == "Nie rozpoznano" ? "założenie" : "BOM/PDF/DXF/STEP",
            r.Material == "Nie rozpoznano" ? 50 : (r.MaterialCostPln > 0 ? 95 : Math.Max(45, r.Drawing.HybridMassConfidence)),
            0,
            routeMaterialCost,
            r.MaterialCostPln > 0,
            r.MaterialCostPln > 0
                ? $"Materiał: {r.Material}; masa: {weightText}."
                : $"FIX14 partial quote: rozpoznano materiał dla {r.Drawing.HybridMassCoveragePercent:0.#}% rodzin; koszt {routeMaterialCost:0.##} PLN jest diagnostyczny i nie odblokowuje ceny ofertowej.");

        var processByCode = r.Processes
            .Where(x => x.Enabled)
            .ToDictionary(x => x.Code, StringComparer.OrdinalIgnoreCase);

        if (processByCode.TryGetValue("CUT", out var cut))
            Add("CUT", string.IsNullOrWhiteSpace(cut.WorkstationName) ? "Cięcie / przygotowanie" : $"Cięcie — {cut.WorkstationName}", "STEP/DXF", cut.Confidence, cut.Hours, cut.CostPln, true, cut.Basis);

        if (processByCode.TryGetValue("PREP_MANUAL", out var prepManual))
            Add("PREP_MANUAL", string.IsNullOrWhiteSpace(prepManual.WorkstationName) ? "Przygotowanie produkcji — ręczne" : prepManual.WorkstationName, "STEP + struktura detali", prepManual.Confidence, prepManual.Hours, prepManual.CostPln, true, prepManual.Basis);
        if (processByCode.TryGetValue("PREP_MACHINE", out var prepMachine))
            Add("PREP_MACHINE", string.IsNullOrWhiteSpace(prepMachine.WorkstationName) ? "Przygotowanie produkcji — maszynowe" : prepMachine.WorkstationName, "STEP + ukosy", prepMachine.Confidence, prepMachine.Hours, prepMachine.CostPln, true, prepMachine.Basis);

        if (r.Geometry.TotalBevelFaces > 0)
            Add(
                "BEVEL",
                "Fazowanie / ukosowanie",
                "STEP",
                72,
                0,
                0,
                false,
                $"Rozpoznano {r.Geometry.TotalBevelFaces} powierzchni ukosowanych. Koszt jest obecnie ujęty pośrednio w przygotowaniu/CNC.");

        if (r.Geometry.TotalHoleCount > 0)
        {
            var specialHoles = r.Geometry.Parts
                .SelectMany(x => x.Holes.Select(h => new { Hole = h, Qty = x.Quantity }))
                .Sum(x => (x.Hole.CounterboreLikely || x.Hole.SpotfaceLikely || x.Hole.CountersinkLikely ? x.Hole.Count : 0) * x.Qty);

            Add(
                "HOLE",
                specialHoles > 0 ? "Wiercenie / pogłębianie" : "Wiercenie otworów",
                "STEP",
                88,
                0,
                0,
                false,
                $"{r.Geometry.TotalHoleCount} otworów fizycznych; {specialHoles} z rozpoznanym pogłębieniem. Koszt jest zawarty w CNC.");
        }

        var postWeldMachining = RequiresPostWeldMachining(r);

        void AddWeld()
        {
            if (!processByCode.TryGetValue("WELD", out var weld))
                return;
            Add(
                "WELD",
                string.IsNullOrWhiteSpace(weld.WorkstationName) ? "Spawanie" : $"Spawanie — {weld.WorkstationName}",
                r.Welding.Source,
                weld.Confidence,
                weld.Hours,
                weld.CostPln + r.Welding.ConsumableCostPln,
                true,
                $"{weld.Basis} Materiał spawalniczy: {r.Welding.ConsumableCostPln:0.##} PLN.");
        }

        void AddCnc()
        {
            if (!processByCode.TryGetValue("CNC", out var cnc))
                return;
            Add(
                "CNC",
                string.IsNullOrWhiteSpace(cnc.WorkstationName)
                    ? (postWeldMachining ? "Obróbka CNC po spawaniu" : "Obróbka CNC")
                    : $"CNC — {cnc.WorkstationName}" + (postWeldMachining ? " (po spawaniu)" : ""),
                "STEP + PDF/OCR",
                cnc.Confidence,
                cnc.Hours,
                cnc.CostPln,
                true,
                cnc.Basis + (postWeldMachining ? " Kolejność wymuszona dokumentacją: spawanie → CNC." : ""));

            if (processByCode.TryGetValue("CNC_MANUAL", out var manual))
                Add("CNC_MANUAL", string.IsNullOrWhiteSpace(manual.WorkstationName) ? "Operacje ręczne obróbki" : manual.WorkstationName,
                    "STEP + cechy CNC", manual.Confidence, manual.Hours, manual.CostPln, true, manual.Basis);
        }

        if (postWeldMachining)
        {
            AddWeld();
            AddCnc();
        }
        else
        {
            AddCnc();
            AddWeld();
        }

        if (r.Welding.Enabled)
            Add(
                "FIT",
                "Dopasowanie / przygotowanie złączy",
                "STEP",
                Math.Max(55, r.Welding.Confidence - 12),
                0,
                0,
                false,
                "Krok technologiczny wynikający ze spawania; czas obsługi jest zawarty w modelu spawania/montażu.");

        var ndt = DetectNdt(r.Drawing);
        if (ndt.Count > 0)
        {
            var pricedNdt = r.QualityCosts.Where(x => x.Code.StartsWith("NDT_", StringComparison.OrdinalIgnoreCase)).ToList();
            var ndtCost = pricedNdt.Sum(x => x.CostPln);
            var pricedMethods = pricedNdt
                .Select(x => x.Code.StartsWith("NDT_", StringComparison.OrdinalIgnoreCase) ? x.Code[4..].ToUpperInvariant() : "")
                .Where(x => x.Length > 0)
                .ToHashSet(StringComparer.OrdinalIgnoreCase);
            var unpricedMethods = ndt.Where(x => !pricedMethods.Contains(x)).ToList();
            Add(
                "NDT",
                $"Badania NDT: {string.Join("/", ndt)}",
                "PDF/OCR + profil jakości",
                pricedNdt.Count > 0 ? (int)Math.Round(pricedNdt.Average(x => x.Confidence)) : 80,
                0,
                ndtCost,
                pricedNdt.Count > 0,
                pricedNdt.Count > 0
                    ? string.Join("; ", pricedNdt.Select(x => x.Basis)) +
                      (unpricedMethods.Count > 0 ? $"; bez stawki: {string.Join("/", unpricedMethods)}" : "")
                    : "Wymaganie wykryte w dokumentacji, ale brak skonfigurowanej reguły kosztowej.",
                requiresExternalRate: unpricedMethods.Count > 0);
        }

        var otherQuality = r.QualityCosts.Where(x => !x.Code.StartsWith("NDT_", StringComparison.OrdinalIgnoreCase)).ToList();
        if (otherQuality.Count > 0)
            Add(
                "QA",
                "Kontrola / dokumentacja jakościowa",
                "PDF/OCR + profil jakości",
                (int)Math.Round(otherQuality.Average(x => x.Confidence)),
                0,
                otherQuality.Sum(x => x.CostPln),
                true,
                string.Join("; ", otherQuality.Select(x => $"{x.Name}: {x.Basis}")));

        if (r.Painting.SurfacePreparationRequired)
            Add(
                "PREP",
                string.IsNullOrWhiteSpace(r.Painting.SurfacePreparation)
                    ? "Przygotowanie powierzchni"
                    : $"Przygotowanie {r.Painting.SurfacePreparation}",
                "PDF/OCR + STEP",
                r.Painting.Confidence,
                r.Painting.SurfacePrepHours,
                0,
                false,
                "Czas przygotowania jest zawarty w pozycji powierzchniowej.");

        if (r.Painting.CoatingRequired)
            Add(
                "PAINT",
                r.Painting.PreAssemblyInternalPaintingRequired
                    ? "Malowanie / system powłok — wnętrza przed zamknięciem"
                    : "Malowanie / system powłok",
                "PDF/OCR + STEP",
                r.Painting.Confidence,
                r.Painting.ApplicationHours,
                r.Painting.PaintMaterialCostPln,
                false,
                $"Zakres: {r.Painting.ScopeDisplay}; {r.Painting.LayerCount} warstw(a), {r.Painting.TotalDftMicron:0.#} µm DFT, {r.Painting.PaintableAreaM2:0.###} m²." +
                (r.Painting.PreAssemblyInternalPaintingRequired
                    ? $" Zamknięte wnętrza {r.Painting.PreAssemblyInternalAreaM2:0.###} m² malować przed zamknięciem/spawaniem zespołu."
                    : "") +
                " Koszt materiału i pracy jest już w wycenie.");

        if (HasKeyword(r.Drawing, "GALV", "OCYNK"))
            Add(
                "GALV",
                "Cynkowanie",
                "PDF/OCR",
                92,
                0,
                0,
                false,
                "Wykryto wymaganie cynkowania; brak stawki zakładowej.",
                requiresExternalRate: true);

        if (HasKeyword(r.Drawing, "HEAT TREAT", "PWHT", "ANNEAL", "NORMALIZ"))
            Add(
                "HT",
                "Obróbka cieplna",
                "PDF/OCR",
                90,
                0,
                0,
                false,
                "Wykryto wymaganie obróbki cieplnej; brak stawki zakładowej.",
                requiresExternalRate: true);

        if (r.SheetMetal.RequiresBending)
            Add(
                "BEND",
                "Gięcie / walcowanie",
                r.SheetMetal.Source,
                Math.Max(45, r.SheetMetal.Confidence),
                0,
                0,
                false,
                r.SheetMetal.NextAction,
                requiresExternalRate: r.SheetMetal.RequiresExternalRate);

        if (processByCode.TryGetValue("SURF", out var surf))
            Add("SURF", string.IsNullOrWhiteSpace(surf.WorkstationName) ? "Operacje powierzchniowe – koszt" : $"Powierzchnia — {surf.WorkstationName}", "model kosztowy", surf.Confidence, surf.Hours, surf.CostPln, true, surf.Basis);

        if (processByCode.TryGetValue("ASSY", out var assy))
            Add("ASSY", string.IsNullOrWhiteSpace(assy.WorkstationName) ? "Montaż / dopasowanie" : $"Montaż — {assy.WorkstationName}", "STEP", assy.Confidence, assy.Hours, assy.CostPln, true, assy.Basis);

        return route;
    }

    private static int CountAssumptions(AnalysisResult r)
    {
        var count = r.Risks.Count(IsAssumptionRisk);

        if (r.DensityAssumed)
            count++;

        if (r.Welding.Enabled && r.Welding.ProcessAssumed)
            count++;

        return count;
    }

    private static bool IsAssumptionRisk(RiskItem risk) =>
        risk.Code is
            "WELD_SIZE_ASSUMED" or
            "PAINT_DFT_ASSUMED" or
            "WELD_INFERRED" or
            "WELD_GROOVE_MODEL" or
            "HOLE_UNCERTAIN" or
            "SURFACE_ACCESS_LIMIT" or
            "JOINT_LIMIT" or
            "CONTACT_LIMIT" or
            "POST_WELD_CNC_SCOPE" or
            "CUT_PARTIAL_COVERAGE" or
            "PAINT_AREA_LOW_RATIO" or
            "NESTING_HIGH_FACTOR" or
            "DRAWING" or
            "MATERIAL";

    private static string BuildStatusDetail(
        AnalysisResult r,
        int blocking,
        int assumptions,
        int externalUnpriced)
    {
        if (blocking > 0)
        {
            if (!r.HasWeight && r.MaterialCostPln <= 0.0001)
                return $"Program policzył rozpoznane operacje, ale nie ma bezpiecznej masy/podstawy materiałowej projektu. Wykryto {blocking} brak(i) blokujące; cena ofertowa nie została wyznaczona.";
            return $"Program policzył wynik automatycznie, ale wykrył {blocking} istotne braki danych. Cena ofertowa wymaga zatwierdzenia po usunięciu blokad.";
        }

        if (r.Package.MultipleRevisionsDetected && !r.Package.RevisionSelectionConfident)
            return "Wycena została policzona, ale oznaczenia rewizji są niejednoznaczne. Sprawdź obowiązującą rewizję.";

        if (r.Package.MultipleRevisionsDetected && r.Package.RevisionSelectionConfident)
            return $"Wycena policzona na automatycznie wybranych najnowszych rewizjach; pominięto {r.Package.IgnoredOlderRevisionFiles.Count} starszych plików.";

        if (externalUnpriced > 0)
            return $"Wycena CZĘŚCIOWA: wykryto {externalUnpriced} oper. zewnętrzne bez stawki. Pokazana kwota nie zawiera kooperacji i nie może być traktowana jako kompletna cena ofertowa.";

        if (r.Drawing.Conflicts.Any(x => !x.IsLocalVariation && x.Level >= RiskLevel.High))
        {
            var projectConflicts = r.Drawing.Conflicts.Count(x => !x.IsLocalVariation);
            return $"Wycena została policzona, ale wykryto {projectConflicts} konflikt(y) danych między dokumentami. Zastosowano regułę konserwatywną / większościową.";
        }

        if (!r.RatesConfirmedByCompany)
            return $"Technologia i koszt zostały policzone automatycznie, ale profil stawek „{r.PricingProfileName}” jest roboczy. Cena pozostaje wstępna do czasu potwierdzenia stawek firmowych.";

        if (assumptions > 0)
            return $"Wycena policzona automatycznie. Zastosowano {assumptions} bezpieczne założenia; szczegóły są opcjonalne.";

        return $"Wycena policzona automatycznie na podstawie dokumentacji. Pewność {r.ConfidencePercent}%.";
    }

    private static List<string> DetectNdt(DrawingIntelligence d)
    {
        var result = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var code in new[] { "UT", "MT", "PT", "RT" })
        {
            if (d.Keywords.Any(k => string.Equals(k, code, StringComparison.OrdinalIgnoreCase)) ||
                d.NdtFamilySignals.Any(x => x.Methods.Contains(code, StringComparer.OrdinalIgnoreCase)))
                result.Add(code);
        }

        return result.OrderBy(x => x).ToList();
    }

    private static bool RequiresPostWeldMachining(AnalysisResult r)
    {
        static bool Match(string? value)
        {
            if (string.IsNullOrWhiteSpace(value)) return false;
            return value.Contains("AFTER WELD", StringComparison.OrdinalIgnoreCase) ||
                   value.Contains("POST WELD", StringComparison.OrdinalIgnoreCase) ||
                   value.Contains("POST-WELD", StringComparison.OrdinalIgnoreCase) ||
                   value.Contains("PO SPAW", StringComparison.OrdinalIgnoreCase) ||
                   value.Contains("NACH DEM SCHWEISS", StringComparison.OrdinalIgnoreCase);
        }

        return r.Drawing.Findings.Any(Match) ||
               r.Drawing.Warnings.Any(Match) ||
               r.Drawing.DimensionalTolerances.Any(x => Match(x.SourceText)) ||
               r.Drawing.GeometricTolerances.Any(x => Match(x.SourceText));
    }

    private static bool HasKeyword(DrawingIntelligence d, params string[] values)
    {
        foreach (var keyword in d.Keywords)
        foreach (var value in values)
        {
            if (string.Equals(keyword, value, StringComparison.OrdinalIgnoreCase) ||
                keyword.Contains(value, StringComparison.OrdinalIgnoreCase))
                return true;
        }

        foreach (var finding in d.Findings)
        foreach (var value in values)
        {
            if (finding.Contains(value, StringComparison.OrdinalIgnoreCase))
                return true;
        }

        return false;
    }
}
