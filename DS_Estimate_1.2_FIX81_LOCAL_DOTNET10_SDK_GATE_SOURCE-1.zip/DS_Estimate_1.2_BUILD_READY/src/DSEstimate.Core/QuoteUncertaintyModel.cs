namespace DSEstimate.Core;

/// <summary>
/// 1.0.1 — niepewność wyceny wydzielona z <see cref="AutoQuoteEngine"/>.
///
/// Poprzednio widełki liczyła jedna heurystyka zaszyta w środku AutoQuoteEngine.Apply,
/// przez co: (a) nie dało się jej przetestować jednostkowo, (b) dwa zupełnie różne
/// projekty o tej samej liczbie ryzyk dostawały identyczne widełki niezależnie od tego,
/// jaka część kosztu faktycznie opiera się na założeniach.
///
/// Model 1.0.1 zachowuje dotychczasową bazę (kompatybilność wyników) i dokłada
/// składniki ważone udziałem kosztu, którego dotyczy niepewność, plus jawną listę
/// czynników (Drivers) do pokazania w UI i raporcie.
/// </summary>
public sealed class QuoteUncertaintyResult
{
    public double UncertaintyPercent { get; init; }
    public double LowFactor { get; init; }
    public double HighFactor { get; init; }
    /// <summary>Czynniki niepewności: nazwa + wkład w punktach procentowych.</summary>
    public List<QuoteUncertaintyDriver> Drivers { get; init; } = [];

    public string DriversText => Drivers.Count == 0
        ? "Brak istotnych czynników niepewności."
        : string.Join(" · ", Drivers
            .OrderByDescending(x => x.ContributionPercentPoints)
            .Select(x => $"{x.Name} (+{x.ContributionPercentPoints:0.#} pp)"));
}

public sealed class QuoteUncertaintyDriver
{
    public string Name { get; init; } = "";
    public double ContributionPercentPoints { get; init; }
}

public static class QuoteUncertaintyModel
{
    public const double MinUncertaintyPercent = 5.0;
    public const double MaxUncertaintyPercent = 35.0;

    public static QuoteUncertaintyResult Evaluate(AnalysisResult r)
    {
        var drivers = new List<QuoteUncertaintyDriver>();
        var uncertainty = MinUncertaintyPercent;

        void Add(string name, double points)
        {
            if (points <= 0.0001)
                return;
            uncertainty += points;
            drivers.Add(new QuoteUncertaintyDriver { Name = name, ContributionPercentPoints = points });
        }

        var blocking = r.Risks.Count(x => x.Blocking);
        var mediumOrHigher = r.Risks.Count(x => x.Level >= RiskLevel.Medium);
        var externalUnpriced = r.AutoRoute.Count(x => x.RequiresExternalRate);

        Add("niska pewność danych wejściowych", Math.Max(0, 90 - r.ConfidencePercent) * 0.30);
        Add("ryzyka istotne", mediumOrHigher * 1.5);
        Add("ryzyka blokujące", blocking * 4.0);
        Add("operacje zewnętrzne bez stawki", externalUnpriced * 2.5);
        Add("konflikty między dokumentami", r.Drawing.Conflicts.Count(x => !x.IsLocalVariation) * 2.0);
        Add(
            "rewizje w paczce",
            r.Package.MultipleRevisionsDetected && !r.Package.RevisionSelectionConfident ? 6.0
                : r.Package.MultipleRevisionsDetected ? 1.0
                : 0.0);
        Add("stawki niepotwierdzone firmowo", !r.RatesConfirmedByCompany ? 4.0 : 0.0);
        Add("wiek cennika", r.PriceAgeWarnings.Sum(x => x.Level >= RiskLevel.High ? 3.0 : 1.5));

        // 1.0.1 — składniki ważone udziałem kosztu. Niepewność masy/materiału boli
        // proporcjonalnie do tego, ile kosztu z niej wynika, a nie ryczałtowo.
        var total = Math.Max(1.0, r.CostTotalPln);

        if (!r.HasWeight)
        {
            Add("masa nieustalona", 6.0);
        }
        else if (r.DensityAssumed)
        {
            var materialShare = Math.Clamp(r.MaterialCostPln / total, 0, 1);
            Add("gęstość/materiał założone", 6.0 * materialShare);
        }

        var externalShare = Math.Clamp(r.ExternalCostPln / total, 0, 1);
        Add("udział kooperacji w koszcie", 4.0 * externalShare);

        var purchasedShare = Math.Clamp(r.PurchasedPartsCostPln / total, 0, 1);
        Add("udział części zakupowych", 2.0 * purchasedShare);

        // FIX11: domain-specific uncertainty. These signals describe cases where the
        // operation is real, but the cost-driving geometry/scope is only partially known.
        var materialShare2 = Math.Clamp(r.MaterialCostPln / total, 0, 1);
        if (r.Nesting.Available && r.Nesting.MaterialFactor >= 1.70)
            Add("wysoki współczynnik nestingu szacunkowego", (r.Nesting.MaterialFactor >= 2.20 ? 8.0 : 5.0) * materialShare2);

        if (r.Risks.Any(x => x.Code == "CUT_PARTIAL_COVERAGE"))
        {
            var cutShare = Math.Clamp(r.Processes.Where(x => x.Code == "CUT" && x.Enabled).Sum(x => x.CostPln) / total, 0, 1);
            Add("częściowe pokrycie DXF dla cięcia", 4.0 + 4.0 * cutShare);
        }

        if (r.Risks.Any(x => x.Code == "POST_WELD_CNC_SCOPE"))
        {
            var cncShare = Math.Clamp(r.Processes.Where(x => x.Code == "CNC" && x.Enabled).Sum(x => x.CostPln) / total, 0, 1);
            Add("zakres obróbki po spawaniu", 4.0 + 5.0 * cncShare);
        }

        if (r.Risks.Any(x => x.Code == "PAINT_AREA_LOW_RATIO"))
        {
            var paintShare = Math.Clamp(
                (r.Processes.Where(x => x.Code == "SURF" && x.Enabled).Sum(x => x.CostPln) + r.Painting.PaintMaterialCostPln) / total,
                0, 1);
            Add("nietypowo mała automatyczna powierzchnia malowania", 3.0 + 5.0 * paintShare);
        }

        uncertainty = Math.Clamp(uncertainty, MinUncertaintyPercent, MaxUncertaintyPercent);

        return new QuoteUncertaintyResult
        {
            UncertaintyPercent = uncertainty,
            // Widełki są asymetryczne: w dół rynek i tak nie pozwala zejść tak mocno,
            // jak w górę potrafi urosnąć zakres przy nieznanych danych.
            LowFactor = 1.0 - uncertainty / 100.0 * 0.45,
            HighFactor = 1.0 + uncertainty / 100.0,
            Drivers = drivers
        };
    }
}
