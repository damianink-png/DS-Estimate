namespace DSEstimate.Core;

public sealed class QuoteScenario
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Assumption { get; set; } = "";
    public double CostPln { get; set; }
    public double PricePln { get; set; }
    public double DeltaCostPln { get; set; }
    public double DeltaPricePln { get; set; }
    public double DeltaPercent { get; set; }
    public bool HasOfferPrice { get; set; }
    public bool IsPriceComplete { get; set; }
    public string CostDisplay => $"koszt {CostPln:N0} PLN";
    public string PriceDisplay => !HasOfferPrice
        ? "NIE WYZNACZONO"
        : IsPriceComplete ? $"{PricePln:N0} PLN" : $"{PricePln:N0} PLN · CZĘŚCIOWA";
    public string DeltaDisplay => !HasOfferPrice
        ? Math.Abs(DeltaCostPln) < 0.005
            ? "punkt odniesienia"
            : $"Δ kosztu {DeltaCostPln:+#,##0;-#,##0;0} PLN · cena nadal niedostępna"
            : Math.Abs(DeltaPricePln) < 0.005
            ? "punkt odniesienia"
            : $"Δ ceny{(IsPriceComplete ? "" : " częściowej")} {DeltaPricePln:+#,##0;-#,##0;0} PLN ({DeltaPercent:+0.0;-0.0;0}%)";
}

public static class QuoteScenarioEngine
{
    public static void Apply(AnalysisResult r)
    {
        static double NonNegative(double value) => double.IsFinite(value) ? Math.Max(0, value) : 0;
        static double FiniteClamp(double value, double min, double max, double fallback = 0) =>
            double.IsFinite(value) ? Math.Clamp(value, min, max) : fallback;

        var baselinePrice = NonNegative(r.AutoQuote.P50PricePln);
        var baselineCost = NonNegative(r.CostTotalPln);
        var hasOffer = r.AutoQuote.HasRecommendedPrice;
        var markupPercent = FiniteClamp(r.AppliedMarkupPercent, -100, 1000);
        var markupFactor = Math.Max(0, 1.0 + markupPercent / 100.0);
        var historyShare = r.HistoricalPricePln is > 0
            ? FiniteClamp(r.AppliedHistoricalBlendPercent / 100.0, 0, 0.50)
            : 0.0;
        var costToOfferFactor = markupFactor * (1.0 - historyShare);

        QuoteScenario New(string code, string name, string assumption, double deltaCost)
        {
            var safeDeltaCost = double.IsFinite(deltaCost) ? deltaCost : 0;
            var cost = NonNegative(baselineCost + safeDeltaCost);
            var price = hasOffer ? NonNegative(baselinePrice + safeDeltaCost * costToOfferFactor) : 0;
            var deltaPrice = hasOffer ? price - baselinePrice : 0;
            return new QuoteScenario
            {
                Code = code,
                Name = name,
                Assumption = assumption,
                CostPln = cost,
                PricePln = price,
                DeltaCostPln = safeDeltaCost,
                DeltaPricePln = deltaPrice,
                DeltaPercent = hasOffer && baselinePrice > 0 ? deltaPrice / baselinePrice * 100.0 : 0,
                HasOfferPrice = hasOffer,
                IsPriceComplete = r.AutoQuote.IsPriceComplete
            };
        }

        var materialPercent = FiniteClamp(r.AppliedWhatIfMaterialPriceChangePercent, -50, 200);
        var processPercent = FiniteClamp(r.AppliedWhatIfProcessTimeChangePercent, -50, 200);
        r.QuoteScenarios =
        [
            New("BASE", "P50 — wynik bazowy", "Aktualne stawki, czasy i narzut.", 0),
            New(
                "MATERIAL",
                $"Materiał {materialPercent:+0.#;-0.#;0}%",
                "Zmiana dotyczy kosztu materiału; geometria, procesy i referencja historyczna pozostają bez zmian.",
                NonNegative(r.MaterialCostPln) * materialPercent / 100.0),
            New(
                "PROCESS",
                $"Czasy procesów {processPercent:+0.#;-0.#;0}%",
                "Zmiana produktywności dotyczy tylko roboczogodzin aktywnych procesów; materiał i kooperacja pozostają bez zmian.",
                NonNegative(r.ProcessCostPln) * processPercent / 100.0)
        ];
    }
}

public sealed class SheetMetalReadinessSummary
{
    public bool IsRelevant { get; set; }
    public bool RequiresBending { get; set; }
    public bool FlatPatternEvidence { get; set; }
    public bool RequiresExternalRate { get; set; }
    public int CandidateFamilyCount { get; set; }
    public int CandidatePartQuantity { get; set; }
    public int Confidence { get; set; }
    public string Source { get; set; } = "";
    public string Status { get; set; } = "Nie wykryto jawnego gięcia";
    public string NextAction { get; set; } = "Brak dodatkowej czynności.";
    public string Summary => IsRelevant
        ? $"{Status} · rodziny blach {CandidateFamilyCount} · pewność {Confidence}%"
        : "Brak sygnałów procesu gięcia/walcowania.";
}

public static class SheetMetalReadinessEngine
{
    private static readonly string[] BendSignals =
        ["BENDING", "BEND", "GIĘC", "ABKANT", "BIEG", "PLIAGE", "ROLL FORM", "WALC"];
    private static readonly string[] FlatSignals =
        ["FLAT_PATTERN", "FLAT PATTERN", "UNFOLD", "ROZWIN", "ABWICKLUNG", "DÉPLIÉ", "DEPLIE"];

    public static void Apply(AnalysisResult r)
    {
        r.Risks.RemoveAll(x => string.Equals(x.Code, "BENDING_UNPRICED", StringComparison.OrdinalIgnoreCase));
        var plates = r.Geometry.Parts
            .Where(x => x.Classification.Contains("Blacha", StringComparison.OrdinalIgnoreCase) ||
                        x.Classification.Contains("Płyta", StringComparison.OrdinalIgnoreCase))
            .ToList();
        var evidence = r.Drawing.Keywords
            .Concat(r.Drawing.Findings)
            .Concat(r.Dxf.Keywords)
            .Concat(r.Dxf.Findings)
            .ToList();
        var bending = evidence.Any(x => BendSignals.Any(s => x.Contains(s, StringComparison.OrdinalIgnoreCase)));
        var flat = evidence.Any(x => FlatSignals.Any(s => x.Contains(s, StringComparison.OrdinalIgnoreCase)));

        var summary = new SheetMetalReadinessSummary
        {
            IsRelevant = bending || flat,
            RequiresBending = bending,
            FlatPatternEvidence = flat,
            RequiresExternalRate = bending,
            CandidateFamilyCount = plates.Count,
            CandidatePartQuantity = plates.Sum(x => Math.Max(1, x.Quantity)),
            Confidence = bending ? (plates.Count > 0 ? 86 : 72) : flat ? 70 : 0,
            Source = bending ? "PDF/DXF/OCR — jawne wymaganie gięcia lub walcowania" : flat ? "PDF/DXF/OCR — sygnał rozwinięcia" : ""
        };

        if (bending)
        {
            summary.Status = flat
                ? "Gięcie wykryte; rozwinięcie wymaga potwierdzenia"
                : "Gięcie wykryte; brak potwierdzonego rozwinięcia";
            summary.NextAction = flat
                ? "Zweryfikuj promienie, kierunek włókna, liczbę gięć i stawkę prasy/kalandra."
                : "Dostarcz flat pattern/DXF po rozwinięciu oraz liczbę, kąty i promienie gięć; uzupełnij stawkę operacji.";
            r.Risks.Add(new RiskItem
            {
                Code = "BENDING_UNPRICED",
                Level = RiskLevel.Medium,
                Title = "Gięcie/walcowanie bez kompletnej podstawy kosztowej",
                Message = summary.NextAction,
                Blocking = false
            });
        }
        else if (flat)
        {
            summary.Status = "Wykryto sygnał rozwinięcia bez jawnego wymagania gięcia";
            summary.NextAction = "Sprawdź, czy rozwinięcie należy do aktywnej rewizji i czy detal jest wykonywany na prasie/kalandrze.";
        }

        r.SheetMetal = summary;
    }
}
