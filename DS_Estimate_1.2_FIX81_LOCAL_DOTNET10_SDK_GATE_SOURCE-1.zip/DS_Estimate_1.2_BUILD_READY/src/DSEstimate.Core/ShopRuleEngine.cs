namespace DSEstimate.Core;

public static class ShopRuleEngine
{
    public static void Apply(AnalysisResult r, CostingSettings s)
    {
        r.RuleHits = [];
        if (!s.RuleEngineEnabled)
            return;

        var cnc = r.Processes.FirstOrDefault(x => x.Code == "CNC");
        var assy = r.Processes.FirstOrDefault(x => x.Code == "ASSY");

        var tightTolerance =
            s.RuleTightToleranceForcesCnc &&
            (HasKeyword(r.Drawing, "H7", "H8", "TOL", "RA ") ||
             r.Drawing.DimensionalTolerances.Any(x => x.Tight) ||
             r.Drawing.GeometricTolerances.Any(x => x.Tight) ||
             r.Drawing.Findings.Any(x =>
                 x.Contains("±0.02", StringComparison.OrdinalIgnoreCase) ||
                 x.Contains("+/-0.02", StringComparison.OrdinalIgnoreCase)));

        if (tightTolerance)
        {
            if (cnc is not null)
            {
                cnc.Enabled = true;
                cnc.Hours = Math.Max(cnc.Hours, 0.5);
                cnc.BaseHours = Math.Max(cnc.BaseHours, cnc.Hours);
                // Confidence of the *requirement* is not the same as confidence of the
                // calculated machining time. A drawing note can prove CNC is needed while
                // geometry/depth/scope of that machining remains only partially known.
                cnc.Confidence = Math.Max(cnc.Confidence, 78);
                cnc.Basis += " Rule Engine: tolerancja/H7/chropowatość potwierdza potrzebę CNC; pewność czasu pozostaje zależna od pokrycia cech.";
            }

            AddHit(r, "RULE_TIGHT_CNC", "Tolerancja → CNC",
                "Potwierdzono wymaganie obróbki CNC; nie podniesiono automatycznie pewności czasu do poziomu pewności samego wymagania.",
                $"W dokumentacji wykryto precyzyjne pasowanie/tolerancję/chropowatość; wymiarowe: {r.Drawing.DimensionalTolerances.Count}, geometryczne: {r.Drawing.GeometricTolerances.Count}.", 94);
            AddRisk(r, "DFM_TIGHT_TOLERANCE", RiskLevel.Medium,
                "Precyzyjna tolerancja / pasowanie",
                "Dokumentacja zawiera sygnał precyzyjnej obróbki (np. H7/H8/tolerancja/chropowatość). Routing kieruje detal do CNC.");
        }

        var deepRatio = Math.Max(1.0, s.RuleDeepBlindHoleRatio);
        var deepBlind = r.Geometry.Parts
            .SelectMany(p => p.Holes.Select(h => new { Hole = h, p.Quantity }))
            .Where(x => !x.Hole.ThroughLikely && x.Hole.DiameterMm > 0 && x.Hole.DepthMm / x.Hole.DiameterMm >= deepRatio)
            .Sum(x => x.Hole.Count * x.Quantity);

        if (deepBlind > 0)
        {
            if (cnc is not null)
            {
                cnc.Enabled = true;
                cnc.Confidence = Math.Max(cnc.Confidence, 86);
            }
            AddHit(r, "RULE_DEEP_HOLE", "Głęboki otwór → CNC/DFM",
                "Potwierdzono CNC i dodano uwagę wykonalności.",
                $"{deepBlind} otworów nieprzelotowych ma L/D ≥ {deepRatio:0.##}.", 88);
            AddRisk(r, "DFM_DEEP_HOLE", RiskLevel.Medium,
                "Głębokie otwory nieprzelotowe",
                $"Wykryto {deepBlind} otworów o L/D ≥ {deepRatio:0.##}. Mogą wymagać specjalnego narzędzia, chłodzenia lub dodatkowej operacji.");
        }

        if (r.WeightKg is > 0 && r.WeightKg.Value >= Math.Max(1, s.RuleHeavyHandlingKg))
        {
            if (assy is not null)
            {
                assy.Enabled = true;
                assy.Hours = Math.Max(assy.Hours, 0.5);
                assy.BaseHours = Math.Max(assy.BaseHours, assy.Hours);
                assy.Confidence = Math.Max(assy.Confidence, 76);
                assy.Basis += $" Rule Engine: masa {r.WeightKg.Value:0.#} kg wymaga uwzględnienia manipulacji.";
            }
            AddHit(r, "RULE_HEAVY_HANDLING", "Masa → manipulacja",
                "Potwierdzono krok montaż/manipulacja.",
                $"Masa {r.WeightKg.Value:0.#} kg ≥ próg {s.RuleHeavyHandlingKg:0.#} kg.", 90);
            AddRisk(r, "DFM_HEAVY_HANDLING", RiskLevel.Low,
                "Ciężki detal / złożenie",
                "Masa przekracza próg manipulacji. Należy uwzględnić dostępność suwnicy, uchwytów i liczbę obrotów podczas produkcji.");
        }

        if (r.Welding.Enabled && r.Welding.SizeMm >= Math.Max(1, s.RuleLargeWeldAmm))
        {
            AddHit(r, "RULE_LARGE_WELD", "Duża spoina → wielościeg",
                $"Model spawania używa {r.Welding.NumberOfPasses} ściegów.",
                $"Rozpoznano {r.Welding.SizeKind}{r.Welding.SizeMm:0.##}; próg reguły {s.RuleLargeWeldAmm:0.##} mm.", 90);
        }

        if (s.RuleHighStrengthSteelWarning &&
            (r.Material.Contains("S690", StringComparison.OrdinalIgnoreCase) ||
             r.Material.Contains("S960", StringComparison.OrdinalIgnoreCase)))
        {
            AddHit(r, "RULE_HIGH_STRENGTH", "Stal wysokowytrzymała → kontrola technologii",
                "Dodano uwagę WPS/parametrów cieplnych.",
                $"Materiał: {r.Material}.", 96);
            AddRisk(r, "DFM_HIGH_STRENGTH", RiskLevel.Medium,
                "Stal wysokowytrzymała",
                "Wymagania dotyczące WPS, ciepła wprowadzonego, podgrzewania i materiałów dodatkowych powinny wynikać z dokumentacji/procedury zakładowej; program nie dopisuje ich sam.");
        }

        if (r.Geometry.TotalHoleCount >= 100)
        {
            AddRisk(r, "DFM_MANY_HOLES", RiskLevel.Low,
                "Duża liczba otworów",
                $"Wykryto {r.Geometry.TotalHoleCount} otworów. Wartość może istotnie wpływać na czas wiercenia, wymianę narzędzi i strategię mocowania.");
        }

        if (r.Geometry.SolidCount >= 80)
        {
            AddRisk(r, "DFM_LARGE_ASSEMBLY", RiskLevel.Medium,
                "Duże złożenie",
                $"Model zawiera {r.Geometry.SolidCount} brył. Montaż, manipulacja oraz kolejność spawania mogą mieć istotny wpływ na czas wykonania.");
        }

        if (r.Painting.CoatingRequired && r.Geometry.SealedCavitySurfaceMm2 > 0)
        {
            AddRisk(r, "DFM_PAINT_ACCESS", RiskLevel.Low,
                "Zamknięte powierzchnie a system malarski",
                "Surface Engine wykrył zamknięte/niedostępne powierzchnie i nie liczy ich domyślnie do malowania. Jeśli dokumentacja wymaga malowania wnętrza, potrzebna jest jawna adnotacja.");
        }

        if (r.Welding.Enabled && r.Geometry.SealedCavitySurfaceMm2 > 0 && r.Geometry.WeldCandidatePairs > 0)
        {
            AddRisk(r, "DFM_WELD_ACCESS", RiskLevel.Low,
                "Dostęp do części złączy po zamknięciu konstrukcji",
                "Model zawiera zamknięte komory i złącza spawane. Kolejność spawania może wymagać wykonania części spoin przed zamknięciem konstrukcji.");
        }
    }

    private static void AddHit(AnalysisResult r, string code, string name, string effect, string basis, int confidence)
    {
        if (r.RuleHits.Any(x => x.Code == code))
            return;
        r.RuleHits.Add(new RuleHit
        {
            Code = code,
            Name = name,
            Effect = effect,
            Basis = basis,
            Confidence = confidence
        });
    }

    private static void AddRisk(AnalysisResult r, string code, RiskLevel level, string title, string message)
    {
        if (r.Risks.Any(x => x.Code == code))
            return;
        r.Risks.Add(new RiskItem
        {
            Code = code,
            Level = level,
            Title = title,
            Message = message,
            Blocking = false
        });
    }

    private static bool HasKeyword(DrawingIntelligence d, params string[] tokens) =>
        d.Keywords.Any(k => tokens.Any(t => k.Contains(t, StringComparison.OrdinalIgnoreCase)));
}
