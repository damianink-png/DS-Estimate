﻿using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace DSEstimate.Core;

/// <summary>
/// Small, deterministic classifiers used to select the right slice of company history.
/// This is intentionally not a black-box ML model: the basis remains visible in the quote.
/// </summary>
public static class ProjectClassEngine
{
    public static ProjectClassResult Classify(AnalysisResult r)
    {
        var solids = Math.Max(0, r.Geometry.SolidCount);
        var mass = r.WeightKg ?? 0;
        var weld = r.Welding.Enabled || r.Geometry.WeldCandidatePairs > 0;
        var cnc = r.Processes.Any(x => x.Enabled && x.Code == "CNC");
        var plates = r.Geometry.Parts.Where(x => ContainsAny(x.Classification, "Blacha", "Płyta")).Sum(x => Math.Max(1, x.Quantity));
        var profiles = r.Geometry.Parts.Where(x => ContainsAny(x.Classification, "Profil", "Rura", "Pręt", "Wałek", "Płaskownik")).Sum(x => Math.Max(1, x.Quantity));
        var totalParts = Math.Max(1, r.Geometry.Parts.Sum(x => Math.Max(1, x.Quantity)));
        var plateShare = plates / (double)totalParts;
        var profileShare = profiles / (double)totalParts;

        if (weld && mass >= 1500 && solids >= 8)
            return New("HEAVY_WELD", "Ciężka konstrukcja spawana", 92,
                $"spawanie + masa {mass:0} kg + {solids} brył");
        if (cnc && !weld && solids <= 4 && mass <= 800)
            return New("MACHINED_PART", "Detal / mały zespół obrabiany", 90,
                $"CNC bez dominującego spawania; {solids} brył, {mass:0} kg");
        if (weld && profileShare >= 0.45)
            return New("PROFILE_WELD", "Konstrukcja profilowa spawana", 86,
                $"udział profili {profileShare:P0}; spawanie wykryte");
        if (plateShare >= 0.55 && (r.Dxf.EntityCount > 0 || r.Processes.Any(x => x.Code == "CUT" && x.Enabled)))
            return New("SHEET_ASSEMBLY", "Zespół blachowy", 84,
                $"udział blach {plateShare:P0}; cięcie/rozkroje obecne");
        if (weld && cnc)
            return New("WELD_MACHINED", "Konstrukcja spawana z obróbką", 88,
                "spawanie i obróbka CNC są istotnymi etapami");
        if (weld)
            return New("WELDED", "Konstrukcja spawana", 76, "spawanie wykryte");
        if (cnc)
            return New("MACHINED", "Konstrukcja obrabiana", 74, "obróbka CNC wykryta");
        return New("MIXED", "Konstrukcja mieszana", 58,
            $"brak jednej dominującej klasy; blachy {plateShare:P0}, profile {profileShare:P0}");
    }

    private static ProjectClassResult New(string code, string name, int confidence, string basis) => new()
    {
        Code = code,
        Name = name,
        Confidence = confidence,
        Basis = basis
    };

    private static bool ContainsAny(string? value, params string[] words) =>
        words.Any(x => (value ?? "").Contains(x, StringComparison.OrdinalIgnoreCase));
}

/// <summary>
/// Sheet-cost estimator. It uses STEP plate groups and a deterministic shelf packing pass.
/// It is not a replacement for CAM nesting, but it removes the fixed global waste assumption
/// whenever plate dimensions and thickness are known.
/// </summary>
public static class NestingCostEngine
{
    private sealed record Rect(double W, double H, double NetArea, double Thickness, string Name);
    private sealed class Row { public double UsedW; public double H; }

    public static NestingEstimate Estimate(AnalysisResult r, CostingSettings s)
    {
        if (!s.NestingCostEnabled || !r.Geometry.Available)
            return new NestingEstimate { Available = false, Basis = "Nesting kosztowy wyłączony lub brak geometrii." };

        var rects = new List<Rect>();
        foreach (var part in r.Geometry.Parts.Where(IsPlate))
        {
            var dims = new[] { part.Xmm, part.Ymm, part.Zmm }.Where(x => x > 0.05).OrderByDescending(x => x).ToArray();
            if (dims.Length < 3) continue;
            var thickness = dims[2];
            if (thickness <= 0 || dims[0] <= 0 || dims[1] <= 0) continue;
            var qty = Math.Clamp(Math.Max(1, part.Quantity), 1, 10000);
            var netAreaEach = part.VolumeMm3Each > 0
                ? part.VolumeMm3Each / thickness
                : dims[0] * dims[1] * 0.90;
            for (var i = 0; i < qty; i++)
                rects.Add(new Rect(dims[0], dims[1], Math.Max(1, netAreaEach), thickness, part.Name));
        }

        if (rects.Count == 0)
            return new NestingEstimate { Available = false, Basis = "Brak pewnych grup blach/płyt do rozkroju." };

        var stocks = s.SheetStocks.Where(x => x.Enabled && x.Xmm > 0 && x.Ymm > 0).ToList();
        if (stocks.Count == 0)
            return new NestingEstimate { Available = false, Basis = "Brak włączonych formatów arkuszy." };

        var netArea = rects.Sum(x => x.NetArea);
        var totalPurchased = 0.0;
        var totalSheets = 0;
        var selections = new List<string>();
        var impossible = 0;

        // Different thicknesses cannot share a stock sheet.
        foreach (var group in rects.GroupBy(x => Math.Round(x.Thickness, 1)))
        {
            var items = group.ToList();
            (SheetStockDefinition? stock, int sheets, double purchasedArea) best = (null, int.MaxValue, double.MaxValue);
            foreach (var stock in stocks)
            {
                var packed = Pack(items, stock, Math.Max(0, s.NestingKerfMm), Math.Max(0, s.NestingEdgeMarginMm));
                if (packed <= 0) continue;
                var area = packed * stock.Xmm * stock.Ymm;
                if (area < best.purchasedArea - 1e-6)
                    best = (stock, packed, area);
            }

            if (best.stock is null)
            {
                impossible += items.Count;
                // Fall back to net area / learned generic utilization instead of returning nonsense.
                var fallbackUtil = Math.Clamp(s.NestingFallbackUtilizationPercent / 100.0, 0.35, 0.98);
                var area = items.Sum(x => x.NetArea) / fallbackUtil;
                totalPurchased += area;
                selections.Add($"t≈{group.Key:0.#}: poza standardowym arkuszem → fallback {fallbackUtil:P0}");
            }
            else
            {
                totalSheets += best.sheets;
                totalPurchased += best.purchasedArea;
                selections.Add($"t≈{group.Key:0.#}: {best.stock.Name} × {best.sheets}");
            }
        }

        var util = totalPurchased > 0 ? Math.Clamp(netArea / totalPurchased, 0.01, 1.0) : 0;
        var factor = totalPurchased > 0 ? Math.Clamp(totalPurchased / Math.Max(1, netArea), 1.0, 3.0) : 1.0;
        var confidence = impossible == 0 ? (rects.Count >= 3 ? 82 : 74) : 58;
        // Rectangular STEP envelopes are a should-cost fallback, not CAM nesting. When
        // the implied purchase/net factor becomes extreme, lower confidence instead of
        // presenting the material figure as equally certain as a normal utilization case.
        if (factor >= 2.20)
            confidence = Math.Min(confidence, 52);
        else if (factor >= 1.70)
            confidence = Math.Min(confidence, 62);

        return new NestingEstimate
        {
            Available = totalPurchased > 0,
            SheetCount = totalSheets,
            SheetFormat = string.Join("; ", selections),
            NetPlateAreaM2 = netArea / 1_000_000.0,
            PurchasedSheetAreaM2 = totalPurchased / 1_000_000.0,
            UtilizationPercent = util * 100.0,
            WastePercent = (1.0 - util) * 100.0,
            MaterialFactor = factor,
            Confidence = confidence,
            Basis = $"Szacunkowy rozkrój prostokątnych obwiedni STEP; {rects.Count} szt.; " +
                    $"wykorzystanie {util:P0}; zakup/netto ×{factor:0.##}. " +
                    (factor >= 1.70 ? "Wysoki współczynnik — wymaga weryfikacji realnym nestingiem CAM. " : "") +
                    string.Join(" · ", selections)
        };
    }

    private static int Pack(List<Rect> input, SheetStockDefinition stock, double kerf, double margin)
    {
        var usableW = stock.Xmm - 2 * margin;
        var usableH = stock.Ymm - 2 * margin;
        if (usableW <= 0 || usableH <= 0) return 0;

        var items = input
            .Select(x => (W: x.W + kerf, H: x.H + kerf))
            .OrderByDescending(x => Math.Max(x.W, x.H))
            .ThenByDescending(x => x.W * x.H)
            .ToList();

        var sheets = new List<List<Row>>();
        foreach (var original in items)
        {
            var placed = false;
            foreach (var rows in sheets)
            {
                if (TryPlace(rows, original.W, original.H, usableW, usableH) ||
                    TryPlace(rows, original.H, original.W, usableW, usableH))
                {
                    placed = true;
                    break;
                }
            }
            if (placed) continue;

            var rowsNew = new List<Row>();
            if (!TryPlace(rowsNew, original.W, original.H, usableW, usableH) &&
                !TryPlace(rowsNew, original.H, original.W, usableW, usableH))
                return 0;
            sheets.Add(rowsNew);
        }
        return sheets.Count;
    }

    private static bool TryPlace(List<Row> rows, double w, double h, double sheetW, double sheetH)
    {
        if (w > sheetW + 1e-6 || h > sheetH + 1e-6) return false;
        foreach (var row in rows)
        {
            if (h <= row.H + 1e-6 && row.UsedW + w <= sheetW + 1e-6)
            {
                row.UsedW += w;
                return true;
            }
        }
        var usedH = rows.Sum(x => x.H);
        if (usedH + h <= sheetH + 1e-6)
        {
            rows.Add(new Row { H = h, UsedW = w });
            return true;
        }
        return false;
    }

    private static bool IsPlate(PartGroup x) =>
        (x.Classification ?? "").Contains("Blacha", StringComparison.OrdinalIgnoreCase) ||
        (x.Classification ?? "").Contains("Płyta", StringComparison.OrdinalIgnoreCase);
}

public static class PurchasedPartPricingEngine
{
    public static List<PurchasedPartEstimate> Estimate(DrawingIntelligence drawing, CostingSettings settings)
    {
        var output = new List<PurchasedPartEstimate>();
        foreach (var item in drawing.BomItems)
        {
            var text = Normalize($"{item.PartNumber} {item.Description}");
            var matches = settings.PurchasedPartPrices
                .Where(x => x.Enabled && x.PricePln >= 0 && Matches(text, x.MatchExpression))
                .OrderByDescending(x => Specificity(x.MatchExpression))
                .ToList();
            var match = matches.FirstOrDefault();
            if (match is null) continue;
            var qty = Math.Max(0, item.Quantity);
            output.Add(new PurchasedPartEstimate
            {
                PartNumber = item.PartNumber,
                Description = item.Description,
                PriceCode = match.Code,
                PriceName = match.Name,
                Quantity = qty,
                UnitPricePln = match.PricePln,
                TotalPricePln = qty * match.PricePln,
                Confidence = match.MarketReference ? 72 : 92,
                Basis = $"BOM → cennik części: {match.Name}; {match.PricePln:0.##} PLN/{match.Unit}; źródło {match.Source} ({match.SourceDate})."
            });
        }
        return output;
    }

    public static bool Matches(string normalizedText, string expression)
    {
        if (string.IsNullOrWhiteSpace(expression)) return false;
        foreach (var requiredGroup in expression.Split('&', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            var groupMatched = requiredGroup
                .Split('|', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(Normalize)
                .Any(alt => ContainsToken(normalizedText, alt));
            if (!groupMatched) return false;
        }
        return true;
    }

    private static bool ContainsToken(string text, string alt)
    {
        if (string.IsNullOrWhiteSpace(alt)) return false;
        if (Regex.IsMatch(alt, @"^M\d+$", RegexOptions.IgnoreCase))
            return Regex.IsMatch(text, $@"(?<!\d){Regex.Escape(alt)}(?!\d)", RegexOptions.IgnoreCase);
        return text.Contains(alt, StringComparison.OrdinalIgnoreCase);
    }

    private static int Specificity(string expression) =>
        expression.Split('&', StringSplitOptions.RemoveEmptyEntries).Length * 100 + expression.Length;

    private static string Normalize(string value)
    {
        var d = (value ?? "").Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder(d.Length);
        foreach (var ch in d)
        {
            var cat = CharUnicodeInfo.GetUnicodeCategory(ch);
            if (cat != UnicodeCategory.NonSpacingMark)
                sb.Append(char.ToUpperInvariant(ch));
        }
        return Regex.Replace(sb.ToString().Normalize(NormalizationForm.FormC), @"\s+", " ").Trim();
    }
}

public static class QualityCostEngine
{
    public static List<QualityCostEstimate> Estimate(AnalysisResult r, CostingSettings s)
    {
        var output = new List<QualityCostEstimate>();
        var keywords = r.Drawing.Keywords.Select(x => x.ToUpperInvariant()).ToHashSet();
        var findings = string.Join(" ", r.Drawing.Findings).ToUpperInvariant();
        var norms = string.Join(" ", r.Drawing.Norms).ToUpperInvariant();
        var weldM = Math.Max(0, r.Welding.EffectiveLengthM);

        double ScopedWeldLength(string method)
        {
            var families = r.Drawing.NdtFamilySignals
                .Where(x => x.Methods.Contains(method, StringComparer.OrdinalIgnoreCase))
                .Select(x => x.FamilyKey)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToHashSet(StringComparer.OrdinalIgnoreCase);
            if (families.Count == 0)
                return weldM;
            var scoped = r.Welding.FamilyBreakdown
                .Where(x => families.Contains(x.FamilyKey))
                .Sum(x => Math.Max(0, x.LengthM));
            return Math.Max(0, scoped);
        }

        var mtDetected = keywords.Contains("MT") || findings.Contains("BADANIA MT") || findings.Contains("MAGNETYC") ||
                         r.Drawing.NdtFamilySignals.Any(x => x.Methods.Contains("MT", StringComparer.OrdinalIgnoreCase));
        var utDetected = keywords.Contains("UT") || findings.Contains("BADANIA UT") || findings.Contains("ULTRASON") ||
                         r.Drawing.NdtFamilySignals.Any(x => x.Methods.Contains("UT", StringComparer.OrdinalIgnoreCase));
        if (mtDetected)
        {
            var mtM = ScopedWeldLength("MT");
            output.Add(New("NDT_MT", "Badania MT", s.QualityMtSetupPln + mtM * s.QualityMtPerMeterPln, 78,
                $"FIX14 scope MT: baza {s.QualityMtSetupPln:0} PLN + {mtM:0.##} m przypisanych rodzin × {s.QualityMtPerMeterPln:0.##} PLN/m"));
        }
        if (utDetected)
        {
            var utM = ScopedWeldLength("UT");
            output.Add(New("NDT_UT", "Badania UT", s.QualityUtSetupPln + utM * s.QualityUtPerMeterPln, 76,
                $"FIX14 scope UT: baza {s.QualityUtSetupPln:0} PLN + {utM:0.##} m przypisanych rodzin × {s.QualityUtPerMeterPln:0.##} PLN/m"));
        }
        if (keywords.Contains("CMM") || findings.Contains("CMM") || findings.Contains("WSPÓŁRZĘDNOŚC"))
            output.Add(New("CMM", "Kontrola CMM", s.QualityCmmBasePln, 66, "wymaganie pomiaru współrzędnościowego wykryte w dokumentacji"));
        if (r.Painting.Enabled && (r.Drawing.TotalDftMicron.HasValue || findings.Contains("DFT")))
            output.Add(New("DFT_REPORT", "Kontrola DFT / raport malarski", s.QualityDftReportPln, 74, "DFT/system malarski jest jawnie określony"));
        if (norms.Contains("10204") || findings.Contains("3.1") || findings.Contains("CERTYFIKAT") || findings.Contains("ŚWIADECTW"))
            output.Add(New("MAT_CERT", "Świadectwa materiałowe", s.QualityMaterialCertificatePln, 68, "EN 10204 / 3.1 / świadectwo materiałowe"));
        if (findings.Contains("TRACEABILITY") || findings.Contains("IDENTYFIKOWAL") || findings.Contains("DOKUMENTACJA JAKOŚC"))
            output.Add(New("QA_DOC", "Dokumentacja jakościowa / traceability", s.QualityDocumentationPln, 64, "wymaganie dokumentacji jakościowej/identyfikowalności"));

        return output;
    }

    private static QualityCostEstimate New(string code, string name, double cost, int confidence, string basis) => new()
    {
        Code = code,
        Name = name,
        CostPln = Math.Max(0, cost),
        Confidence = confidence,
        Basis = basis
    };
}

public static class CostConfidenceEngine
{
    public static List<CostConfidenceItem> Build(AnalysisResult r)
    {
        var result = new List<CostConfidenceItem>();
        var denominator = Math.Max(0.01, r.CostTotalPln);

        string NextAction(string code, int confidence)
        {
            if (confidence >= 85) return "Brak krytycznego braku danych; zachowaj źródła jako audyt.";
            return code.ToUpperInvariant() switch
            {
                "MAT" => r.WeightKg is null
                    ? "Dodaj jawną masę całego zespołu albo wiarygodny root BOM."
                    : r.MaterialBreakdown.Any(x => x.Material == "NIEPRZYPISANE")
                        ? "Uzupełnij materiał/masę brakujących pozycji BOM, aby rozbić koszt per gatunek."
                        : "Potwierdź ceny zakupowe właściwych gatunków i formatów półfabrykatu.",
                "CUT" => r.Drawing.ResolvedDxfFamilyMatchCount < r.Drawing.ResolvedRootBomFamilyCount && r.Drawing.ResolvedRootBomFamilyCount > 0
                    ? "Dodaj brakujące DXF lub kontury 2D rodzin BOM."
                    : "Potwierdź technologię cięcia, grubość i liczbę przebić.",
                "CNC" or "CNC_MANUAL" => r.CncFeatures.NextAction,
                "WELD" => r.Welding.FamilyScoped
                    ? "Potwierdź lokalne długości/strony spoin o najniższej pewności."
                    : "Dodaj symbole spoin i długości per złącze/rodzina.",
                "SURF" => r.Painting.AreaCoveragePercent < 95
                    ? "Uzupełnij brakujące rodziny DXF/BOM/STEP dla powierzchni."
                    : r.Painting.SystemCompletenessPercent < 70
                        ? "Potwierdź system powłok: przygotowanie, warstwy, DFT i zakres."
                        : "Potwierdź maskowanie powierzchni obrabianych i styków.",
                "ASSY" => "Potwierdź pełny BOM, liczbę podzespołów, wymagane ustawianie i manipulację.",
                "QA" => "Potwierdź zakres procentowy NDT i stawki kooperacji.",
                "BUY" => "Potwierdź ceny dostawców dla największych pozycji kupnych.",
                _ => "Zweryfikuj źródła o najniższej pewności dla tej operacji."
            };
        }

        void Add(string code, string name, double amount, int confidence, string basis)
        {
            result.Add(new CostConfidenceItem
            {
                Code = code,
                Name = name,
                AmountPln = amount,
                Confidence = Math.Clamp(confidence, 1, 99),
                SharePercent = Math.Max(0, amount) / denominator * 100.0,
                NextAction = NextAction(code, confidence),
                Basis = basis
            });
        }

        var materialConfidence = r.WeightKg.HasValue ? (r.Material == "Nie rozpoznano" ? 58 : 92) : 25;
        if (r.Nesting.Available && r.Nesting.UsedForMaterialCost)
            materialConfidence = Math.Min(materialConfidence, r.Nesting.Confidence);
        if (r.MaterialBreakdown.Any(x => x.Material == "NIEPRZYPISANE"))
            materialConfidence = Math.Min(materialConfidence, 72);
        Add(
            "MAT",
            "Materiał",
            r.MaterialCostPln,
            materialConfidence,
            r.Nesting.Available && r.Nesting.UsedForMaterialCost
                ? "masa + szacunkowy rozkrój arkuszy"
                : r.Nesting.Available
                    ? "masa × cena/kg + naddatek; nesting tylko diagnostyczny"
                    : "masa × cena/kg");

        foreach (var process in r.Processes.Where(x => x.Enabled))
            Add(process.Code, process.Name, process.CostPln, process.Confidence, process.Basis);

        if (r.PurchasedPartsCostPln > 0)
            Add(
                "BUY",
                "Części kupne",
                r.PurchasedPartsCostPln,
                r.PurchasedParts.Count == 0 ? 40 : (int)Math.Round(r.PurchasedParts.Average(x => x.Confidence)),
                $"{r.PurchasedParts.Count} pozycji BOM dopasowanych do cennika");

        if (r.QualityCostPln > 0)
            Add(
                "QA",
                "Jakość / badania",
                r.QualityCostPln,
                r.QualityCosts.Count == 0 ? 35 : (int)Math.Round(r.QualityCosts.Average(x => x.Confidence)),
                "wymagania wykryte w dokumentacji");

        return result.OrderByDescending(x => x.AmountPln).ToList();
    }
}
