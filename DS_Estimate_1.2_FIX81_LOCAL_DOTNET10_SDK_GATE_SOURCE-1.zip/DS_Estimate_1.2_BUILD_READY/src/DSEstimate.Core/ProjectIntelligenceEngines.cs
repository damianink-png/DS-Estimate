﻿using System.Text.RegularExpressions;

namespace DSEstimate.Core;

/// <summary>
/// FIX13: builds a non-destructive material and semi-finished-product breakdown.
/// It never invents a grade price. Cost authority remains with the normal material
/// model unless an explicit per-grade rate exists in settings.
/// </summary>
public static class MaterialBreakdownEngine
{
    public static (List<MaterialBreakdownItem> Materials, List<SemiFinishedProductItem> SemiFinished) Build(AnalysisResult result)
    {
        var materials = new List<MaterialBreakdownItem>();
        var semi = new List<SemiFinishedProductItem>();
        var bom = result.Drawing.BomItems ?? [];

        var massRows = bom
            .Where(x => !string.IsNullOrWhiteSpace(x.Material) && x.EffectiveTotalMassKg is > 0.001 and < 25_000)
            .ToList();

        // Hierarchical BOMs often contain parent totals and child masses. To avoid
        // double counting, use mass-bearing leaves branch-by-branch rather than a
        // single global deepest level (different branches may legitimately end at
        // different depths). Flat BOM rows (Level=0) remain independent.
        if (massRows.Any(x => x.Level > 0))
        {
            bool HasMassBearingDescendant(BomItemSignal parent)
            {
                if (parent.Level <= 0) return false;
                var index = bom.IndexOf(parent);
                if (index < 0) return false;
                for (var i = index + 1; i < bom.Count; i++)
                {
                    var candidate = bom[i];
                    if (candidate.Level <= parent.Level) break;
                    if (candidate.EffectiveTotalMassKg is > 0.001 and < 25_000)
                        return true;
                }
                return false;
            }
            massRows = massRows.Where(x => x.Level <= 0 || !HasMassBearingDescendant(x)).ToList();
        }

        foreach (var group in massRows.GroupBy(x => NormalizeMaterial(x.Material), StringComparer.OrdinalIgnoreCase))
        {
            var mass = group.Sum(x => x.EffectiveTotalMassKg);
            if (mass <= 0) continue;
            materials.Add(new MaterialBreakdownItem
            {
                Material = group.Key,
                SemiFinishedKind = MostCommon(group.Select(x => ClassifySemiFinished(x.Description))),
                MassKg = mass,
                FamilyCount = group.Select(x => NormalizeFamily(x.PartNumber)).Where(x => x.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).Count(),
                Confidence = 88,
                Source = "BOM",
                Basis = $"Masa z {group.Count()} pozycji BOM przypisanych do gatunku {group.Key}."
            });
        }

        var assignedMass = materials.Sum(x => x.MassKg);
        var knownWeight = result.WeightKg ?? 0;
        if (knownWeight > 0 && assignedMass > knownWeight * 1.35)
        {
            // Still looks hierarchical/duplicated. Keep breakdown diagnostic but
            // do not let impossible shares look authoritative.
            var scale = knownWeight / Math.Max(assignedMass, 0.001);
            foreach (var item in materials)
            {
                item.MassKg *= scale;
                item.Confidence = Math.Min(item.Confidence, 58);
                item.Basis += " Suma pozycji przekraczała masę projektu; udziały znormalizowano wyłącznie diagnostycznie.";
            }
            assignedMass = materials.Sum(x => x.MassKg);
        }

        if (materials.Count == 0 && knownWeight > 0 && !string.IsNullOrWhiteSpace(result.Material) && result.Material != "Nie rozpoznano")
        {
            materials.Add(new MaterialBreakdownItem
            {
                Material = result.Material,
                SemiFinishedKind = "MIXED/UNKNOWN",
                MassKg = knownWeight,
                FamilyCount = Math.Max(1, result.Geometry.UniquePartGroups),
                Confidence = result.WeightSource == "STEP" ? 82 : 68,
                Source = result.WeightSource,
                Basis = "Brak bezpiecznego rozbicia masy per pozycja; zachowano materiał projektu jako jedną pozycję."
            });
            assignedMass = knownWeight;
        }
        else if (knownWeight > 0 && assignedMass < knownWeight * 0.98)
        {
            var remainder = knownWeight - assignedMass;
            materials.Add(new MaterialBreakdownItem
            {
                Material = "NIEPRZYPISANE",
                SemiFinishedKind = "UNKNOWN",
                MassKg = remainder,
                FamilyCount = 0,
                Confidence = 35,
                Source = result.WeightSource,
                Basis = "Różnica między masą projektu a masami bezpiecznie przypisanymi do gatunków."
            });
        }

        var total = materials.Sum(x => Math.Max(0, x.MassKg));
        foreach (var item in materials)
            item.SharePercent = total > 0 ? item.MassKg / total * 100.0 : 0;

        foreach (var group in bom
                     .Where(x => x.Quantity > 0)
                     .Select(x => new { Item = x, Kind = ClassifySemiFinished(x.Description) })
                     .Where(x => x.Kind != "UNKNOWN")
                     .GroupBy(x => new { x.Kind, Material = NormalizeMaterial(x.Item.Material) }))
        {
            semi.Add(new SemiFinishedProductItem
            {
                Kind = group.Key.Kind,
                Material = group.Key.Material,
                Quantity = group.Sum(x => Math.Max(1, x.Item.Quantity)),
                MassKg = group.Sum(x => Math.Max(0, x.Item.EffectiveTotalMassKg)),
                Confidence = 78,
                Source = "BOM",
                Basis = $"Rozpoznano {group.Count()} pozycji po opisie półfabrykatu."
            });
        }

        // Geometry contributes classification even when BOM descriptions are weak.
        foreach (var group in result.Geometry.Parts
                     .Where(x => x.Quantity > 0)
                     .GroupBy(x => NormalizeGeometryKind(x.Classification), StringComparer.OrdinalIgnoreCase)
                     .Where(x => x.Key != "UNKNOWN"))
        {
            if (semi.Any(x => string.Equals(x.Kind, group.Key, StringComparison.OrdinalIgnoreCase)))
                continue;
            semi.Add(new SemiFinishedProductItem
            {
                Kind = group.Key,
                Material = result.Material,
                Quantity = group.Sum(x => x.Quantity),
                MassKg = group.Sum(x => Math.Max(0, x.MassKgEach) * Math.Max(1, x.Quantity)),
                Confidence = 74,
                Source = "STEP",
                Basis = "Klasyfikacja półfabrykatu na podstawie geometrii STEP."
            });
        }

        return (materials, semi.OrderByDescending(x => x.MassKg).ThenByDescending(x => x.Quantity).ToList());
    }

    private static string NormalizeMaterial(string? value)
    {
        var v = (value ?? "").Trim().ToUpperInvariant();
        return string.IsNullOrWhiteSpace(v) ? "NIEPRZYPISANE" : v;
    }

    private static string NormalizeFamily(string? value) =>
        Regex.Replace((value ?? "").ToUpperInvariant(), "[^A-Z0-9]+", "");

    private static string MostCommon(IEnumerable<string> values) => values
        .Where(x => !string.IsNullOrWhiteSpace(x) && x != "UNKNOWN")
        .GroupBy(x => x, StringComparer.OrdinalIgnoreCase)
        .OrderByDescending(x => x.Count())
        .Select(x => x.Key)
        .FirstOrDefault() ?? "UNKNOWN";

    public static string ClassifySemiFinished(string? description)
    {
        var t = (description ?? "").ToUpperInvariant();
        if (Regex.IsMatch(t, @"\b(RHS|SHS|PROFIL\s+ZAMK|QUADRATROHR|RECHTECKROHR)\b")) return "RHS/SHS";
        if (Regex.IsMatch(t, @"\b(RURA|ROHR|PIPE|TUBE)\b")) return "RURA";
        if (Regex.IsMatch(t, @"\b(HEA|HEB|HEM|IPE|IPN|DWUTEOWNIK|TRAEGER|TRÄGER)\b")) return "DWUTEOWNIK";
        if (Regex.IsMatch(t, @"\b(UNP|UPN|UPE|CEOWNIK)\b")) return "CEOWNIK";
        if (Regex.IsMatch(t, @"\b(L\s?[- ]?PROFIL|KĄTOWNIK|KATOWNIK|WINKEL)\b")) return "KĄTOWNIK";
        if (Regex.IsMatch(t, @"\b(FLACH|PŁASKOWNIK|PLASKOWNIK|FLAT\s*BAR)\b")) return "PŁASKOWNIK";
        if (Regex.IsMatch(t, @"\b(BLACHA|PLATE|BLECH|SHEET)\b")) return "BLACHA";
        if (Regex.IsMatch(t, @"\b(PRĘT|PRET|BAR|STAB|ROUND\s*BAR)\b")) return "PRĘT";
        if (Regex.IsMatch(t, @"\b(ODKUW|FORGING|GESCHMIEDET)\b")) return "ODKUWKA";
        if (Regex.IsMatch(t, @"\b(ODLEW|CASTING|GUSS)\b")) return "ODLEW";
        return "UNKNOWN";
    }

    private static string NormalizeGeometryKind(string? classification)
    {
        var t = (classification ?? "").ToUpperInvariant();
        if (t.Contains("BLACHA") || t.Contains("PŁYTA") || t.Contains("PLYTA")) return "BLACHA";
        if (t.Contains("RURA")) return "RURA";
        if (t.Contains("PROFIL")) return "PROFIL";
        if (t.Contains("PŁASKOWNIK") || t.Contains("PLASKOWNIK")) return "PŁASKOWNIK";
        if (t.Contains("PRĘT") || t.Contains("PRET") || t.Contains("WAŁEK") || t.Contains("WALEK")) return "PRĘT";
        return "UNKNOWN";
    }
}

public static class CncFeatureSummaryEngine
{
    public static CncFeatureSummary Build(AnalysisResult r)
    {
        var holes = r.Geometry.Parts.SelectMany(p => p.Holes.Select(h => new { H = h, Qty = Math.Max(1, p.Quantity) })).ToList();
        int Sum(Func<HoleFeature, bool> pred) => holes.Where(x => pred(x.H)).Sum(x => Math.Max(1, x.H.Count) * x.Qty);
        var precision = Math.Max(r.PrecisionHoleCount, r.Drawing.PrecisionHoleCount2D);
        var drilled = Sum(h => h.RequiresDrill || h.RequiresCnc);
        var reamed = Sum(h => h.ReamedLikely || h.RequiresReam);
        var threaded = Sum(h => !string.IsNullOrWhiteSpace(h.ThreadCode) || h.RequiresTap);
        var bored = Sum(h => h.RequiresBore);
        var secondary = Sum(h => h.CounterboreLikely || h.SpotfaceLikely || h.CountersinkLikely);
        var pockets = r.Geometry.Parts.Sum(p => p.PocketCandidateCount * Math.Max(1, p.Quantity));
        var tightDim = r.Drawing.DimensionalTolerances.Count(x => x.Tight);
        var tightGeom = r.Drawing.GeometricTolerances.Count(x => x.Tight);
        var machinedParts = r.Geometry.Parts
            .Where(p => p.Holes.Any(h => h.RequiresCnc || h.FitConfirmed || h.ReamedLikely || !string.IsNullOrWhiteSpace(h.ThreadCode)))
            .ToList();
        var machinedFamilies = machinedParts.Count + (tightDim + tightGeom > 0 ? 1 : 0);
        var setupClusters = machinedParts
            .Select(p => new
            {
                Class = (p.Classification ?? "").Trim().ToUpperInvariant(),
                X = (int)Math.Round(p.Xmm / 5.0),
                Y = (int)Math.Round(p.Ymm / 5.0),
                Z = (int)Math.Round(p.Zmm / 5.0),
                HoleMix = p.Holes.Count(h => h.RequiresCnc || h.FitConfirmed || h.ReamedLikely || !string.IsNullOrWhiteSpace(h.ThreadCode))
            })
            .Distinct()
            .Count();
        var setup = Math.Clamp(Math.Max(1, Math.Min(4, setupClusters + (tightGeom > 0 ? 1 : 0))), 1, 4);
        var complexity = Math.Clamp(
            precision * 2 + reamed * 3 + threaded * 2 + bored * 5 + secondary * 2 +
            tightDim * 3 + tightGeom * 5 + Math.Min(30, pockets * 4) + Math.Min(30, r.Geometry.TotalBevelFaces / 3), 0, 100);
        var coverage = r.Geometry.UniquePartGroups > 0
            ? 100.0 * r.Geometry.FullyAnalyzedUniqueSolids / r.Geometry.UniquePartGroups
            : 0;
        var confidence = (int)Math.Round(Math.Clamp(45 + coverage * 0.4 + (r.Drawing.HoleRequirements.Count > 0 ? 8 : 0), 40, 95));
        var next = confidence < 70
            ? "Dodaj pełniejszy STEP albo rysunki z tolerancjami/otworami, aby podnieść pewność CNC."
            : tightGeom > 0
                ? "Potwierdź bazy i wymagania GD&T przed zamrożeniem liczby zamocowań."
                : "Dane CNC mają dobre pokrycie; największa niepewność pozostaje w strategii mocowania/programowania.";
        return new CncFeatureSummary
        {
            MachinedFamilyCount = machinedFamilies,
            PrecisionHoleCount = precision,
            DrilledHoleCount = drilled,
            ReamedHoleCount = reamed,
            ThreadedHoleCount = threaded,
            BoredHoleCount = bored,
            SecondaryOperationCount = secondary,
            TightDimensionalToleranceCount = tightDim,
            TightGeometricToleranceCount = tightGeom,
            BevelFaceCount = r.Geometry.TotalBevelFaces,
            PocketCandidateCount = pockets,
            SetupCount = setup,
            ComplexityScore = complexity,
            Confidence = confidence,
            NextAction = next,
            Basis = $"cechy: precyzyjne {precision}, wiercone {drilled}, rozwiercane {reamed}, gwinty {threaded}, wytaczane {bored}, wtórne {secondary}, kieszenie-kandydaci {pockets}; tolerancje {tightDim}/{tightGeom}; klastry setup/program {Math.Max(1, setupClusters)}; pokrycie STEP {coverage:0}%"
        };
    }
}
