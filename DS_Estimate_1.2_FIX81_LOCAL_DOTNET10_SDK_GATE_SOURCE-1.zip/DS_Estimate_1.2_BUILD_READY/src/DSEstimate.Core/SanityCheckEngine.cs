﻿namespace DSEstimate.Core;

/// <summary>
/// FIX14: deterministic plausibility guard. It does not tune the quote; it only
/// surfaces internally inconsistent results before they can look authoritative.
/// </summary>
public static class SanityCheckEngine
{
    public static void Apply(AnalysisResult r)
    {
        r.SanityChecks.Clear();

        void Add(string code, RiskLevel level, string message, string basis, bool addRisk = true)
        {
            r.SanityChecks.Add(new SanityCheckItem
            {
                Code = code,
                Level = level,
                Message = message,
                Basis = basis
            });
            if (addRisk && !r.Risks.Any(x => string.Equals(x.Code, code, StringComparison.OrdinalIgnoreCase)))
            {
                r.Risks.Add(new RiskItem
                {
                    Code = code,
                    Level = level,
                    Title = "Kontrola spójności wyniku",
                    Message = message,
                    Blocking = false
                });
            }
        }

        if (!r.HasWeight && r.Drawing.ResolvedRootBomFamilyCount >= 3)
            Add("SANITY_MASS_SCOPE", RiskLevel.High,
                $"Nie ustalono masy całego projektu mimo root BOM obejmującego {r.Drawing.ResolvedRootBomFamilyCount} rodzin. Pełna cena materiału nie może być uznana za kompletną.",
                "Brak autorytatywnej masy PROJECT_TOTAL/BOM_TOTAL; częściowa rekonstrukcja pozostaje diagnostyczna.");

        if (r.WeightKg is > 1000 && r.Painting.CoatingRequired && r.Painting.PaintableAreaM2 > 0 &&
            r.Painting.PaintableAreaM2 / r.WeightKg.Value < 0.002)
            Add("SANITY_SURFACE_TOO_LOW", RiskLevel.Medium,
                $"Powierzchnia malowania {r.Painting.PaintableAreaM2:0.##} m² jest bardzo mała względem masy {r.WeightKg.Value:0} kg. Sprawdź pokrycie rodzin i zakres malowania.",
                $"Wskaźnik {r.Painting.PaintableAreaM2 / r.WeightKg.Value:0.####} m²/kg; pokrycie powierzchni {r.Painting.AreaCoveragePercent:0.#}%.");

        var physicalParts = r.Geometry.Parts.Sum(x => Math.Max(1, x.Quantity));
        if (physicalParts >= 50 && r.Welding.Enabled && r.Welding.TotalHours <= 0.5 && r.Drawing.WeldFamilySignals.Count > 0)
            Add("SANITY_WELD_TOO_LOW", RiskLevel.Medium,
                $"Model rozpoznał {physicalParts} części i lokalne sygnały spoin, ale czas spawania wynosi tylko {r.Welding.TotalHours:0.##} h.",
                "Długości spoin mogą być niepełne; wymagany przegląd mapy rodzin/złączy.");

        if (r.FinalPricePln > 0 && r.WeightKg is > 0 && !r.Risks.Any(x => x.Blocking))
        {
            var pricePerKg = r.FinalPricePln / r.WeightKg.Value;
            if (pricePerKg < 2 || pricePerKg > 1000)
                Add("SANITY_PRICE_PER_KG", RiskLevel.High,
                    $"Cena {pricePerKg:0.##} PLN/kg jest skrajna względem masy projektu. Zweryfikuj zakres dokumentacji, materiał i procesy.",
                    "Sanity-check nie zmienia ceny; wymusza jedynie widoczne ostrzeżenie.");
        }

        if (r.Drawing.HybridMassKg is > 0 && !r.Drawing.HybridMassProjectAuthoritative)
            Add("SANITY_PARTIAL_MASS", RiskLevel.Info,
                $"Rozpoznano częściowo {r.Drawing.HybridMassKg.Value:0.##} kg dla {r.Drawing.HybridMassCoveragePercent:0.#}% rodzin; ta masa służy tylko do kosztu rozpoznanego zakresu.",
                r.Drawing.HybridMassSource, addRisk: false);
    }
}
