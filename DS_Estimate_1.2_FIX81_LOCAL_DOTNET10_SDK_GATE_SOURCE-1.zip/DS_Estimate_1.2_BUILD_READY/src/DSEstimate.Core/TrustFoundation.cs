using System.Globalization;

namespace DSEstimate.Core;

public enum EvidenceAuthority { None = 0, Estimate = 1, Document = 2, Geometry = 3, User = 4, Calibrated = 5 }
public enum EvidenceValidationState { Unknown = 0, Review = 1, Validated = 2, Rejected = 3 }

public sealed class MeasuredValue<T>
{
    public T? Value { get; set; }
    public string Unit { get; set; } = "";
    public string Source { get; set; } = "";
    public List<string> Evidence { get; set; } = [];
    public int Confidence { get; set; }
    public string Scope { get; set; } = "UNKNOWN";
    public EvidenceAuthority Authority { get; set; }
    public EvidenceValidationState ValidationState { get; set; }
    public string CalibrationApplied { get; set; } = "none";
    public bool HasPriceAuthority => Value is not null && Authority != EvidenceAuthority.None && ValidationState != EvidenceValidationState.Rejected;
}

public sealed class TrustFoundationSnapshot
{
    public string Principle { get; set; } = "wartość + źródło + niepewność";
    public List<MeasuredValue<double?>> Values { get; set; } = [];
    public int ReviewRequiredCount => Values.Count(x => x.ValidationState == EvidenceValidationState.Review);
    public string Summary => $"{Values.Count} wartości audytowalnych · do weryfikacji {ReviewRequiredCount}";
}

public sealed class CalibrationProfile
{
    public string Schema { get; set; } = "ds-estimate-calibration-v1";
    public string Version { get; set; } = "1.0.0";
    public DateTime EffectiveFrom { get; set; } = new(2026, 8, 26);
    public string Note { get; set; } = "Neutralny profil 1.0.0. Zmieniać wyłącznie na podstawie golden set i wpisu w CALIBRATION_LOG.md.";
    public string GoldenSetId { get; set; } = "";
    public string ChangeReason { get; set; } = "";
    public Dictionary<string,double> ProcessMultipliers { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string,double> MaterialMultipliers { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class ExternalCalibrationAudit
{
    public string Version { get; set; } = "none";
    public string Source { get; set; } = "";
    public bool Applied { get; set; }
    public bool Rejected { get; set; }
    public string RejectionReason { get; set; } = "";
    public int ProcessAdjustmentCount { get; set; }
    public int MaterialAdjustmentCount { get; set; }
    public double MaterialCostBeforeCalibration { get; set; }
    public double RecognizedMaterialCostBeforeCalibration { get; set; }
    public double MaterialFactor { get; set; } = 1.0;
    public List<string> Adjustments { get; set; } = [];
    public string Summary => Rejected
        ? $"calibration.json {Version}: ODRZUCONA — {RejectionReason}"
        : Applied
            ? $"calibration.json {Version}: procesy {ProcessAdjustmentCount}, materiał {MaterialAdjustmentCount}"
            : $"calibration.json {Version}: brak aktywnych korekt";
}

public sealed class PriceAgeWarning
{
    public string Item { get; set; } = "";
    public string Source { get; set; } = "";
    public DateTime? EffectiveDate { get; set; }
    public int AgeDays { get; set; }
    public RiskLevel Level { get; set; }
    public string Message { get; set; } = "";
}

public static class CalibrationLayer
{
    public static void Reset(AnalysisResult r)
    {
        var previous = r.ExternalCalibration ?? new ExternalCalibrationAudit();
        foreach (var process in r.Processes)
        {
            if (process.ExternalCalibrationFactor > 0 &&
                Math.Abs(process.ExternalCalibrationFactor - 1.0) > 0.000001 &&
                process.ModelHoursBeforeExternalCalibration >= 0)
            {
                process.Hours = process.ModelHoursBeforeExternalCalibration;
            }
            process.ModelHoursBeforeExternalCalibration = 0;
            process.ExternalCalibrationFactor = 1.0;
            process.ExternalCalibrationVersion = "";
            var marker = process.Basis.IndexOf(" Kalibracja z calibration.json", StringComparison.OrdinalIgnoreCase);
            if (marker >= 0)
                process.Basis = process.Basis[..marker].TrimEnd();
        }

        if (previous.MaterialFactor > 0 && Math.Abs(previous.MaterialFactor - 1.0) > 0.000001)
        {
            r.MaterialCostPln = Math.Max(0, previous.MaterialCostBeforeCalibration);
            r.RecognizedPartialMaterialCostPln = Math.Max(0, previous.RecognizedMaterialCostBeforeCalibration);
        }
        r.ExternalCalibration = new ExternalCalibrationAudit();
    }

    public static void Apply(AnalysisResult r, CostingSettings settings)
    {
        Reset(r);
        var c = settings.RuntimeCalibration ?? new CalibrationProfile();
        var processFactors = NormalizeFactors(c.ProcessMultipliers);
        var materialFactors = NormalizeFactors(c.MaterialMultipliers);
        var version = string.IsNullOrWhiteSpace(c.Version) ? "unknown" : c.Version.Trim();
        r.ExternalCalibration = new ExternalCalibrationAudit { Version = version, Source = "calibration.json" };
        if (!string.Equals(c.Schema, "ds-estimate-calibration-v1", StringComparison.OrdinalIgnoreCase))
        {
            Reject(r, $"nieobsługiwany schemat {c.Schema}");
            return;
        }
        if (string.IsNullOrWhiteSpace(c.Version))
        {
            Reject(r, "brak wersji profilu");
            return;
        }
        if (c.EffectiveFrom == default)
        {
            Reject(r, "brak daty EffectiveFrom");
            return;
        }
        if (c.EffectiveFrom.Date > DateTime.Today)
        {
            Reject(r, $"profil zaczyna obowiązywać {c.EffectiveFrom:yyyy-MM-dd}");
            return;
        }
        if (processFactors.Values.Concat(materialFactors.Values)
            .Any(x => !double.IsFinite(x) || x <= 0))
        {
            Reject(r, "mnożniki muszą być dodatnimi liczbami skończonymi");
            return;
        }
        var hasNonNeutral = processFactors.Values.Any(x => Math.Abs(x - 1.0) > 0.000001) ||
                            materialFactors.Values.Any(x => Math.Abs(x - 1.0) > 0.000001);
        if (hasNonNeutral && (string.IsNullOrWhiteSpace(c.GoldenSetId) || string.IsNullOrWhiteSpace(c.ChangeReason)))
        {
            Reject(r, "nie-neutralna kalibracja bez GoldenSetId/ChangeReason");
            return;
        }

        var materialFactor = ResolveMaterialFactor(r, materialFactors, settings);
        if (Math.Abs(materialFactor - 1.0) > 0.000001 &&
            (r.MaterialCostPln > 0 || r.RecognizedPartialMaterialCostPln > 0))
        {
            materialFactor = Math.Clamp(materialFactor, 0.50, 2.00);
            r.ExternalCalibration.MaterialCostBeforeCalibration = r.MaterialCostPln;
            r.ExternalCalibration.RecognizedMaterialCostBeforeCalibration = r.RecognizedPartialMaterialCostPln;
            r.ExternalCalibration.MaterialFactor = materialFactor;
            r.MaterialCostPln *= materialFactor;
            r.RecognizedPartialMaterialCostPln *= materialFactor;
            r.ExternalCalibration.MaterialAdjustmentCount = 1;
            r.ExternalCalibration.Adjustments.Add(
                $"materiał: {r.ExternalCalibration.MaterialCostBeforeCalibration:0.##} PLN × {materialFactor:0.###} = {r.MaterialCostPln:0.##} PLN");
        }

        foreach (var process in r.Processes.Where(x => x.Enabled && !x.ManualOverride))
        {
            process.ModelHoursBeforeExternalCalibration = process.Hours;
            var factor = ResolveProcessFactor(process, processFactors);
            if (Math.Abs(factor - 1.0) < 0.000001)
                continue;
            factor = Math.Clamp(factor, 0.50, 2.00);
            process.ExternalCalibrationFactor = factor;
            process.ExternalCalibrationVersion = version;
            process.Hours *= factor;
            process.Basis += $" Kalibracja z calibration.json {version}: ×{factor:0.###}.";
            r.ExternalCalibration.Adjustments.Add($"{process.Code}: {process.ModelHoursBeforeExternalCalibration:0.###}h × {factor:0.###} = {process.Hours:0.###}h");
            r.ExternalCalibration.ProcessAdjustmentCount++;
        }
        r.ExternalCalibration.Applied = r.ExternalCalibration.ProcessAdjustmentCount > 0 ||
                                        r.ExternalCalibration.MaterialAdjustmentCount > 0;
    }

    private static void Reject(AnalysisResult r, string reason)
    {
        r.ExternalCalibration.Rejected = true;
        r.ExternalCalibration.RejectionReason = reason;
        r.ExternalCalibration.Applied = false;
        r.ExternalCalibration.Adjustments.Add($"ODRZUCONO: {reason}.");
    }

    private static Dictionary<string, double> NormalizeFactors(IReadOnlyDictionary<string, double>? factors)
    {
        var normalized = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        if (factors is null)
            return normalized;
        foreach (var pair in factors)
        {
            var key = pair.Key?.Trim();
            if (!string.IsNullOrWhiteSpace(key))
                normalized[key] = pair.Value;
        }
        return normalized;
    }

    private static double ResolveProcessFactor(ProcessEstimate process, IReadOnlyDictionary<string, double> factors)
    {
        if (!string.IsNullOrWhiteSpace(process.WorkstationCode) && factors.TryGetValue(process.WorkstationCode, out var station))
            return station;
        if (factors.TryGetValue(process.Code, out var processFactor))
            return processFactor;
        if (factors.TryGetValue("*", out var fallback))
            return fallback;
        return 1.0;
    }

    private static double ResolveMaterialFactor(
        AnalysisResult r,
        IReadOnlyDictionary<string, double> factors,
        CostingSettings settings)
    {
        if (factors.Count == 0)
            return 1.0;

        double FactorFor(string material)
        {
            if (!string.IsNullOrWhiteSpace(material) && factors.TryGetValue(material.Trim(), out var exact))
                return exact;
            if (!string.IsNullOrWhiteSpace(material))
            {
                var fuzzy = factors
                    .Where(x => !string.Equals(x.Key, "*", StringComparison.OrdinalIgnoreCase) &&
                                !string.Equals(x.Key, "DEFAULT", StringComparison.OrdinalIgnoreCase) &&
                                (material.Contains(x.Key, StringComparison.OrdinalIgnoreCase) ||
                                 x.Key.Contains(material, StringComparison.OrdinalIgnoreCase)))
                    .OrderByDescending(x => x.Key.Length)
                    .FirstOrDefault();
                if (!string.IsNullOrWhiteSpace(fuzzy.Key))
                    return fuzzy.Value;
            }
            if (factors.TryGetValue("DEFAULT", out var defaultFactor))
                return defaultFactor;
            return factors.TryGetValue("*", out var wildcard) ? wildcard : 1.0;
        }

        double RateFor(string material)
        {
            var fallback = Math.Max(0, settings.MaterialPricePlnKg);
            var overrides = settings.MaterialPriceOverridesPlnKg;
            if (string.IsNullOrWhiteSpace(material) || overrides is not { Count: > 0 })
                return fallback;
            var exact = overrides.FirstOrDefault(x =>
                string.Equals(x.Key.Trim(), material.Trim(), StringComparison.OrdinalIgnoreCase));
            if (!string.IsNullOrWhiteSpace(exact.Key) && exact.Value > 0)
                return exact.Value;
            var fuzzy = overrides
                .Where(x => x.Value > 0 && !string.IsNullOrWhiteSpace(x.Key))
                .OrderByDescending(x => x.Key.Length)
                .FirstOrDefault(x => material.Contains(x.Key, StringComparison.OrdinalIgnoreCase) ||
                                     x.Key.Contains(material, StringComparison.OrdinalIgnoreCase));
            return !string.IsNullOrWhiteSpace(fuzzy.Key) ? fuzzy.Value : fallback;
        }

        var weighted = r.MaterialBreakdown.Where(x => x.MassKg > 0).ToList();
        if (weighted.Count == 0)
            return FactorFor(r.Material);
        var costWeight = weighted.Sum(x => x.MassKg * RateFor(x.Material));
        if (costWeight > 0)
            return weighted.Sum(x => x.MassKg * RateFor(x.Material) * FactorFor(x.Material)) / costWeight;
        var mass = weighted.Sum(x => x.MassKg);
        return mass > 0 ? weighted.Sum(x => x.MassKg * FactorFor(x.Material)) / mass : 1.0;
    }
}

public static class PriceFreshnessEngine
{
    public static void Apply(AnalysisResult r, CostingSettings s, DateTime? now = null)
    {
        r.PriceAgeWarnings.Clear();
        var today = (now ?? DateTime.Now).Date;
        Add(r, "Materiał", s.MaterialPriceSource, s.MaterialPriceSourceDate, s.PriceWarningDays, s.PriceCriticalDays, today);
        foreach (var item in r.PurchasedParts.Where(x => x.TotalPricePln > 0))
        {
            var def = s.PurchasedPartPrices.FirstOrDefault(d => string.Equals(d.Code, item.PriceCode, StringComparison.OrdinalIgnoreCase));
            if (def is not null) Add(r, $"Część kupna: {def.Name}", def.Source, def.SourceDate, s.PriceWarningDays, s.PriceCriticalDays, today);
        }
    }

    private static void Add(AnalysisResult r, string item, string source, string rawDate, int warnDays, int criticalDays, DateTime today)
    {
        if (!TryParseDate(rawDate, out var date))
        {
            r.PriceAgeWarnings.Add(new PriceAgeWarning { Item=item, Source=source, Level=RiskLevel.Medium, Message=$"{item}: brak poprawnej daty cennika ({rawDate})." });
            return;
        }
        var age = Math.Max(0, (today-date.Date).Days);
        if (age < Math.Max(1, warnDays)) return;
        var level = age >= Math.Max(warnDays, criticalDays) ? RiskLevel.High : RiskLevel.Medium;
        r.PriceAgeWarnings.Add(new PriceAgeWarning { Item=item, Source=source, EffectiveDate=date, AgeDays=age, Level=level, Message=$"{item}: cena ma {age} dni (źródło: {source}, data {date:yyyy-MM-dd}) — do potwierdzenia." });
    }

    private static bool TryParseDate(string value, out DateTime date)
    {
        foreach (var fmt in new[] { "yyyy-MM-dd", "yyyy-MM", "dd.MM.yyyy", "MM/yyyy" })
            if (DateTime.TryParseExact(value?.Trim(), fmt, CultureInfo.InvariantCulture, DateTimeStyles.None, out date)) return true;
        return DateTime.TryParse(value, CultureInfo.GetCultureInfo("pl-PL"), DateTimeStyles.None, out date);
    }
}

public static class TrustFoundationEngine
{
    public static void Apply(AnalysisResult r)
    {
        var values = new List<MeasuredValue<double?>>();
        if (r.WeightKg is > 0)
        {
            var manual = r.WeightSource.Contains("ręcz", StringComparison.OrdinalIgnoreCase);
            var geometry = r.WeightSource.Contains("STEP", StringComparison.OrdinalIgnoreCase);
            var confidence = manual ? 99
                : r.Drawing.HybridMassProjectAuthoritative ? Math.Clamp(r.Drawing.HybridMassConfidence, 55, 95)
                : geometry && !r.Drawing.StepGeometryProjectCoveragePartial ? 92
                : r.Drawing.DocumentMassConfidence > 0 ? Math.Clamp(r.Drawing.DocumentMassConfidence, 40, 95)
                : 72;
            values.Add(new MeasuredValue<double?>
            {
                Value=r.WeightKg.Value, Unit="kg", Source=r.WeightSource, Evidence=[r.WeightSource], Confidence=confidence,
                Scope="PROJECT_TOTAL", Authority=manual?EvidenceAuthority.User:geometry?EvidenceAuthority.Geometry:EvidenceAuthority.Document,
                ValidationState=confidence>=75?EvidenceValidationState.Validated:EvidenceValidationState.Review
            });
        }
        else
            values.Add(new MeasuredValue<double?> { Value=null, Unit="kg", Source="brak bezpiecznego źródła", Confidence=0, Scope="PROJECT_TOTAL", Authority=EvidenceAuthority.None, ValidationState=EvidenceValidationState.Review });

        var materialComplete = r.MaterialCostPln > 0 && (r.HasWeight || r.Drawing.HybridMassProjectAuthoritative);
        var materialCalibrated = r.ExternalCalibration.Applied && r.ExternalCalibration.MaterialAdjustmentCount > 0;
        values.Add(new MeasuredValue<double?>
        {
            Value = r.MaterialCostPln > 0 ? r.MaterialCostPln : null,
            Unit = "PLN",
            Source = "CostEngine / materiał",
            Evidence = [r.Material, r.ExternalCalibration.Summary],
            Confidence = materialComplete ? 85 : r.MaterialCostPln > 0 ? 55 : 0,
            Scope = materialComplete ? "PROJECT_TOTAL" : "PARTIAL",
            Authority = r.MaterialCostPln <= 0
                ? EvidenceAuthority.None
                : materialCalibrated ? EvidenceAuthority.Calibrated : EvidenceAuthority.Estimate,
            ValidationState = materialComplete ? EvidenceValidationState.Validated : EvidenceValidationState.Review,
            CalibrationApplied = materialCalibrated
                ? $"{r.ExternalCalibration.Version} ×{r.ExternalCalibration.MaterialFactor:0.###}"
                : "none"
        });
        foreach (var pr in r.Processes.Where(x=>x.Enabled))
            values.Add(new MeasuredValue<double?> { Value=pr.Hours, Unit="h", Source=pr.DecisionOrigin, Evidence=[pr.Basis], Confidence=pr.Confidence, Scope=string.IsNullOrWhiteSpace(pr.WorkstationCode)?pr.Code:pr.WorkstationCode, Authority=pr.ManualOverride?EvidenceAuthority.User:Math.Abs(pr.ExternalCalibrationFactor-1.0)>0.000001?EvidenceAuthority.Calibrated:EvidenceAuthority.Estimate, ValidationState=pr.Confidence>=70?EvidenceValidationState.Validated:EvidenceValidationState.Review, CalibrationApplied=Math.Abs(pr.ExternalCalibrationFactor-1.0)>0.000001?$"{pr.ExternalCalibrationVersion} ×{pr.ExternalCalibrationFactor:0.###}":"none" });
        var priceValidated = r.AutoQuote.HasRecommendedPrice && r.AutoQuote.IsPriceComplete && r.AutoQuote.Status == "GOTOWA";
        values.Add(new MeasuredValue<double?> { Value=r.AutoQuote.HasRecommendedPrice?r.AutoQuote.P50PricePln:null, Unit="PLN", Source="AutoQuote + QuoteUncertaintyModel", Evidence=[r.AutoQuote.UncertaintyDrivers], Confidence=Math.Clamp(100-(int)Math.Round(r.AutoQuote.UncertaintyPercent),0,100), Scope="PROJECT_TOTAL", Authority=r.AutoQuote.HasRecommendedPrice?EvidenceAuthority.Estimate:EvidenceAuthority.None, ValidationState=priceValidated?EvidenceValidationState.Validated:EvidenceValidationState.Review, CalibrationApplied=r.ExternalCalibration.Applied?r.ExternalCalibration.Version:"none" });
        r.Trust = new TrustFoundationSnapshot { Values=values };
    }
}
