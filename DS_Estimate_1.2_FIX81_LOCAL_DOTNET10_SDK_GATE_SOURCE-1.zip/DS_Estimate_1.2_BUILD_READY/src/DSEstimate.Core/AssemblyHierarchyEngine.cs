﻿using System.Text.RegularExpressions;

namespace DSEstimate.Core;

/// <summary>
/// FIX13: hierarchy-first assembly tree.  BOM levels are preserved and STEP groups
/// are attached to the matching BOM node instead of flattening every unmatched row
/// under the project root.  The tree is audit-only; it does not sum parent and child
/// masses into the project weight.
/// </summary>
public static class AssemblyHierarchyEngine
{
    public static List<AssemblyTreeNode> Build(QuoteProject project, AnalysisResult analysis)
    {
        var result = new List<AssemblyTreeNode>();
        const string rootId = "ROOT";
        result.Add(new AssemblyTreeNode
        {
            Id = rootId,
            ParentId = "",
            Level = 0,
            Kind = analysis.Geometry.SolidCount > 1 || analysis.Drawing.BomItems.Count > 1 ? "Złożenie" : "Projekt",
            Name = string.IsNullOrWhiteSpace(project.Name) ? "Projekt" : project.Name,
            Quantity = 1,
            Material = analysis.Material,
            MassKg = analysis.WeightKg ?? 0,
            Source = "Paczka klienta",
            Confidence = 95,
            MatchBasis = "Korzeń automatycznej hierarchii."
        });

        var bom = analysis.Drawing.BomItems.ToList();
        var parts = analysis.Geometry.Parts.ToList();
        var usedBom = new HashSet<BomItemSignal>();
        var nodeByBom = new Dictionary<BomItemSignal, AssemblyTreeNode>();
        var nodeIndex = 0;

        if (bom.Count > 0)
        {
            var lastNodeAtLevel = new Dictionary<int, string> { [0] = rootId };
            foreach (var item in bom)
            {
                var rawLevel = Math.Max(0, item.Level);
                var level = rawLevel > 0 ? rawLevel : 1;
                var parentLevel = Math.Max(0, level - 1);
                while (parentLevel > 0 && !lastNodeAtLevel.ContainsKey(parentLevel))
                    parentLevel--;
                var parentId = lastNodeAtLevel.TryGetValue(parentLevel, out var knownParent) ? knownParent : rootId;
                if (level == 1) parentId = rootId;

                var id = $"BOM_{nodeIndex++}";
                var kind = IsAssemblyDescription(item.Description) || HasNestedChildren(bom, item)
                    ? "Podzespół BOM"
                    : "Pozycja BOM";
                var node = new AssemblyTreeNode
                {
                    Id = id,
                    ParentId = parentId,
                    Level = level,
                    Kind = kind,
                    Name = string.IsNullOrWhiteSpace(item.Description) ? item.PartNumber : item.Description,
                    PartNumber = item.PartNumber,
                    Quantity = item.Quantity <= 0 ? 1 : item.Quantity,
                    Material = item.Material,
                    MassKg = item.EffectiveTotalMassKg,
                    Source = item.SourceFile,
                    Confidence = item.EffectiveTotalMassKg > 0 ? 82 : 72,
                    MatchBasis = item.Level > 0
                        ? $"Hierarchia BOM: poziom {item.Level}, pozycja {item.Position}."
                        : "Pozycja płaskiego BOM; rodzic nie był jawnie podany."
                };
                result.Add(node);
                nodeByBom[item] = node;
                lastNodeAtLevel[level] = id;
                foreach (var stale in lastNodeAtLevel.Keys.Where(x => x > level).ToList())
                    lastNodeAtLevel.Remove(stale);
            }
        }

        foreach (var part in parts)
        {
            var match = FindBomMatch(part, bom.Where(x => !usedBom.Contains(x)));
            if (match is not null && nodeByBom.TryGetValue(match, out var node))
            {
                usedBom.Add(match);
                node.GeometryQuantity = part.Quantity;
                if (node.MassKg <= 0)
                    node.MassKg = part.MassKgEach * Math.Max(1, part.Quantity);
                if (string.IsNullOrWhiteSpace(node.Material))
                    node.Material = analysis.Material;
                node.Confidence = Math.Max(node.Confidence, 92);
                node.MatchBasis = Math.Abs(node.Quantity - part.Quantity) > 0.001
                    ? $"Połączono STEP z BOM ({match.SourceFile}); UWAGA: STEP ×{part.Quantity}, BOM ×{node.Quantity:0.###}."
                    : $"Połączono geometrię STEP z pozycją BOM ({match.SourceFile}).";
                continue;
            }

            result.Add(new AssemblyTreeNode
            {
                Id = $"STEP_{nodeIndex++}",
                ParentId = rootId,
                Level = 1,
                Kind = part.Classification,
                Name = !string.IsNullOrWhiteSpace(part.Name) ? part.Name : part.Classification,
                PartNumber = "",
                Quantity = part.Quantity,
                GeometryQuantity = part.Quantity,
                Material = analysis.Material,
                MassKg = part.MassKgEach * Math.Max(1, part.Quantity),
                Source = part.SourceFile,
                Confidence = 76,
                MatchBasis = "Geometria STEP bez jednoznacznego dopasowania do pozycji BOM."
            });
        }

        return result;
    }

    private static bool HasNestedChildren(IReadOnlyList<BomItemSignal> bom, BomItemSignal parent)
    {
        if (parent.Level <= 0) return false;
        var index = -1;
        for (var i = 0; i < bom.Count; i++)
        {
            if (ReferenceEquals(bom[i], parent)) { index = i; break; }
        }
        if (index < 0) return false;
        for (var i = index + 1; i < bom.Count; i++)
        {
            if (bom[i].Level <= parent.Level) break;
            if (bom[i].Level > parent.Level) return true;
        }
        return false;
    }

    private static bool IsAssemblyDescription(string? text)
    {
        var t = (text ?? "").ToUpperInvariant();
        return t.Contains("ASSEMB") || t.Contains("ZESP") || t.Contains("BAUGRUPPE") || t.Contains("WELDMENT");
    }

    private static BomItemSignal? FindBomMatch(PartGroup part, IEnumerable<BomItemSignal> candidates)
    {
        var tokens = new[]
        {
            Normalize(part.Name),
            Normalize(part.GroupKey),
            Normalize(Path.GetFileNameWithoutExtension(part.SourceFile))
        }.Where(x => x.Length >= 3).ToList();

        BomItemSignal? best = null;
        var bestScore = 0;
        foreach (var item in candidates)
        {
            var pn = Normalize(item.PartNumber);
            var desc = Normalize(item.Description);
            var score = 0;
            foreach (var token in tokens)
            {
                if (pn.Length >= 3 && (token.Contains(pn) || pn.Contains(token))) score += 7;
                if (desc.Length >= 4 && (token.Contains(desc) || desc.Contains(token))) score += 3;
            }
            if (score > bestScore)
            {
                bestScore = score;
                best = item;
            }
        }
        return bestScore >= 3 ? best : null;
    }

    private static string Normalize(string? value) =>
        Regex.Replace((value ?? "").ToUpperInvariant(), "[^A-Z0-9]+", "");
}
