﻿using System.Text.RegularExpressions;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

/// <summary>
/// FIX12A dual-run builder. It projects the proven FIX11 analysis into the new
/// manufacturing-state contract without changing processes, hours, rates or price.
/// FIX12B/C may later enrich bindings and validation before any price authority is enabled.
/// </summary>
public static class AssemblyStateGraphBuilder
{
    public static ShadowTechnologyGraph Build(QuoteProject project, AnalysisResult analysis)
    {
        var graph = new ShadowTechnologyGraph
        {
            ShadowOnly = true,
            HasPriceAuthority = false,
            LegacyRecommendedPricePln = analysis.AutoQuote.RecommendedPricePln > 0
                ? analysis.AutoQuote.RecommendedPricePln
                : analysis.FinalPricePln,
            LegacyRoute = analysis.AutoQuote.RouteSummary,
            PostWeldMachiningDetected = RequiresPostWeldMachining(analysis)
        };

        BuildUniqueGroups(graph, analysis);
        BuildEvidenceBindings(graph, analysis);
        BuildStatesAndProcesses(graph, project, analysis);
        ValidateGraph(graph, analysis);
        graph.ShadowRoute = string.Join(" → ", graph.Processes.Select(x => x.Name));
        return graph;
    }

    private static void BuildUniqueGroups(ShadowTechnologyGraph graph, AnalysisResult analysis)
    {
        var index = 0;
        foreach (var part in analysis.Geometry.Parts
                     .OrderBy(x => x.SourceFile, StringComparer.OrdinalIgnoreCase)
                     .ThenBy(x => x.GroupKey, StringComparer.OrdinalIgnoreCase)
                     .ThenBy(x => x.Name, StringComparer.OrdinalIgnoreCase))
        {
            index++;
            var id = $"UPG-{index:000}-{Slug(!string.IsNullOrWhiteSpace(part.GroupKey) ? part.GroupKey : part.Name)}";
            var group = new UniquePartGroup
            {
                Id = id,
                GeometryKey = part.GroupKey,
                Name = string.IsNullOrWhiteSpace(part.Name) ? id : part.Name,
                SourceFile = part.SourceFile,
                Classification = part.Classification,
                Quantity = Math.Max(1, part.Quantity),
                Geometry = new TechnologyGeometryDescriptor
                {
                    BoundingXmm = part.Xmm,
                    BoundingYmm = part.Ymm,
                    BoundingZmm = part.Zmm,
                    VolumeMm3 = part.VolumeMm3Each,
                    SurfaceMm2 = part.SurfaceMm2Each,
                    MassKg = part.MassKgEach,
                    HoleCount = part.Holes.Sum(h => Math.Max(1, h.Count)),
                    FaceCount = part.FaceCount,
                    EdgeCount = part.EdgeCount,
                    SolidCount = 1
                }
            };
            for (var q = 1; q <= group.Quantity; q++)
                group.InstanceIds.Add($"{id}-I{q:000}");
            graph.UniquePartGroups.Add(group);
        }
    }

    private static void BuildEvidenceBindings(ShadowTechnologyGraph graph, AnalysisResult analysis)
    {
        var id = 0;
        foreach (var fact in analysis.Evidence.Facts)
        {
            id++;
            var binding = new EvidenceBinding
            {
                Id = $"EVB-{id:0000}",
                SourceFile = fact.SourceFile,
                SourceKind = fact.SourceKind,
                Field = fact.Field,
                Observation = !string.IsNullOrWhiteSpace(fact.DisplayValue) ? fact.DisplayValue : fact.Label,
                Scope = fact.Scope,
                GeometryFilter = GeometryFilterFor(fact.Field),
                ProcessConstraint = ProcessConstraintFor(fact.Field),
                Confidence = new ConfidenceVector
                {
                    Existence = Clamp01(fact.Confidence / 100.0),
                    Binding = ScopeBindingConfidence(fact.Scope),
                    Geometry = GeometryConfidenceFor(fact.Field, analysis),
                    Parameters = ParameterConfidenceFor(fact.Field, fact.NumericValue.HasValue, analysis)
                },
                NeedsReview = fact.Outlier || fact.ConflictsWithDecision,
                Note = fact.Note
            };
            AddCandidates(binding, fact.SourceFile, fact.Field, graph, analysis);
            graph.EvidenceBindings.Add(binding);
        }

        // Structured tolerances often carry the process-order observation even when the
        // Evidence Orchestrator field is generic. Keep it as an auditable binding, never
        // as a direct CostEngine mutation.
        foreach (var tolerance in analysis.Drawing.GeometricTolerances.Where(x => ContainsAfterWeld(x.SourceText)))
        {
            id++;
            var binding = new EvidenceBinding
            {
                Id = $"EVB-{id:0000}",
                SourceFile = analysis.Drawing.SourceFile,
                SourceKind = "PDF/OCR",
                Field = "process_order",
                Observation = tolerance.SourceText,
                Scope = "ASSEMBLY_STATE",
                GeometryFilter = "planar faces / datum-related machined surfaces",
                ProcessConstraint = "AFTER:WELD",
                Confidence = new ConfidenceVector
                {
                    Existence = 0.98,
                    Binding = 0.82,
                    Geometry = analysis.Geometry.Available ? 0.70 : 0.35,
                    Parameters = tolerance.ValueMm.HasValue ? 0.70 : 0.50
                },
                ResolvedTargetId = "STATE-WELDED-ASSEMBLY",
                NeedsReview = false,
                Note = "FIX12A: kolejność procesu jest związana ze stanem złożenia; resolver powierzchni powstaje w FIX12B."
            };
            binding.TargetCandidates.Add(new EvidenceTargetCandidate
            {
                EntityId = "STATE-WELDED-ASSEMBLY",
                EntityKind = "AssemblyState",
                Score = 0.92,
                Basis = "jawne ograniczenie kolejności AFTER WELD + geometria złożenia"
            });
            graph.EvidenceBindings.Add(binding);
        }
    }

    private static void AddCandidates(
        EvidenceBinding binding,
        string sourceFile,
        string field,
        ShadowTechnologyGraph graph,
        AnalysisResult analysis)
    {
        var sourceStem = Normalize(Path.GetFileNameWithoutExtension(sourceFile));
        var matches = graph.UniquePartGroups
            .Select(group => new
            {
                Group = group,
                Score = CandidateScore(sourceStem, group)
            })
            .Where(x => x.Score >= 0.55)
            .OrderByDescending(x => x.Score)
            .ThenBy(x => x.Group.Id, StringComparer.OrdinalIgnoreCase)
            .Take(5)
            .ToList();

        foreach (var match in matches)
        {
            binding.TargetCandidates.Add(new EvidenceTargetCandidate
            {
                EntityId = match.Group.Id,
                EntityKind = "UniquePartGroup",
                Score = match.Score,
                Basis = "nazwa/rodzina źródła ↔ nazwa lub GroupKey STEP (FIX12A coarse resolver)"
            });
        }

        if (matches.Count == 1 && matches[0].Score >= 0.90)
        {
            binding.ResolvedTargetId = matches[0].Group.Id;
            binding.Confidence.Binding = Math.Max(binding.Confidence.Binding, matches[0].Score);
            return;
        }

        var unknownMassScope = field.Contains("mass", StringComparison.OrdinalIgnoreCase) &&
                               string.Equals(binding.Scope, "UNKNOWN", StringComparison.OrdinalIgnoreCase);
        if (IsAssemblyWideField(field) && !unknownMassScope)
        {
            binding.TargetCandidates.Add(new EvidenceTargetCandidate
            {
                EntityId = "STATE-PROJECT-CURRENT",
                EntityKind = "AssemblyState",
                Score = 0.80,
                Basis = "pole ma naturalny zasięg całego projektu/złożenia"
            });
            if (string.Equals(binding.Scope, "PROJECT_TOTAL", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(binding.Scope, "ASSEMBLY_TOTAL", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(binding.Scope, "BOM_TOTAL", StringComparison.OrdinalIgnoreCase))
            {
                binding.ResolvedTargetId = "STATE-PROJECT-CURRENT";
                binding.Confidence.Binding = Math.Max(binding.Confidence.Binding, 0.80);
            }
        }
        else if (unknownMassScope)
        {
            binding.NeedsReview = true;
            binding.Note = Append(binding.Note, "FIX12B: masa o zakresie UNKNOWN nie może zostać automatycznie przypięta do całego projektu.");
        }
        else if (matches.Count == 0)
        {
            binding.NeedsReview = true;
            binding.Note = Append(binding.Note,
                "FIX12A: brak jednoznacznego celu geometrycznego; dowód pozostaje kandydatem do resolvera FIX12B.");
        }
    }

    private static void BuildStatesAndProcesses(
        ShadowTechnologyGraph graph,
        QuoteProject project,
        AnalysisResult analysis)
    {
        var allEntities = graph.UniquePartGroups.Select(x => x.Id).ToList();
        var assemblyGeometry = AssemblyGeometry(analysis);
        var raw = AddState(graph, "STATE-RAW", ManufacturingStateKind.RawMaterial, "RAW_MATERIAL", allEntities, assemblyGeometry);
        var current = raw;

        var cut = FindProcess(analysis, "CUT");
        if (cut is not null)
            current = AddProcessWithState(graph, current, "PROC-CUT", TechnologyProcessKind.Cutting, cut,
                ManufacturingStateKind.Cut, "CUT", CutConfidence(analysis, cut));

        var cnc = FindProcess(analysis, "CNC");
        if (cnc is not null && !graph.PostWeldMachiningDetected)
            current = AddProcessWithState(graph, current, "PROC-CNC-PRE", TechnologyProcessKind.PreMachining, cnc,
                ManufacturingStateKind.PreMachined, "PRE_MACHINED", CncConfidence(analysis, cnc, false));

        var weld = FindProcess(analysis, "WELD");
        if (weld is not null)
        {
            var sub = AddState(graph, "STATE-SUBASSEMBLY", ManufacturingStateKind.SubAssembly,
                "SUBASSEMBLY", allEntities, assemblyGeometry);
            AddTransitionOnly(graph, current, sub, "PROC-FITUP", TechnologyProcessKind.FitUp,
                "Dopasowanie / przygotowanie złączy", 0, 0,
                new ConfidenceVector { Existence = 0.85, Binding = 0.90, Geometry = 0.85, Parameters = 0.55 },
                "Stan konstrukcyjny przed spawaniem; koszt fit-up pozostaje w legacy WELD/ASSY.");
            current = AddProcessWithState(graph, sub, "PROC-WELD", TechnologyProcessKind.Welding, weld,
                ManufacturingStateKind.WeldedAssembly, "WELDED_ASSEMBLY", WeldConfidence(analysis, weld),
                outputId: "STATE-WELDED-ASSEMBLY");
        }
        else if (graph.PostWeldMachiningDetected)
        {
            // Preserve an explicit state even when the legacy welding process was disabled;
            // this is a shadow warning, not permission to invent cost.
            current = AddState(graph, "STATE-WELDED-ASSEMBLY", ManufacturingStateKind.WeldedAssembly,
                "WELDED_ASSEMBLY (unpriced/needs review)", allEntities, assemblyGeometry);
            graph.Warnings.Add("POST_WELD wymaga stanu WELDED_ASSEMBLY, ale legacy WELD nie jest aktywny.");
        }

        if (cnc is not null && graph.PostWeldMachiningDetected)
        {
            current = AddProcessWithState(graph, current, "PROC-CNC-POST", TechnologyProcessKind.PostMachining, cnc,
                ManufacturingStateKind.PostMachined, "POST_MACHINED", CncConfidence(analysis, cnc, true));
            current.Geometry.MassKg = assemblyGeometry.MassKg;
        }

        var surface = FindProcess(analysis, "SURF");
        if (surface is not null)
        {
            var prepared = AddProcessWithState(graph, current, "PROC-SURFACE", TechnologyProcessKind.Painting, surface,
                ManufacturingStateKind.Finished, "FINISHED", PaintConfidence(analysis, surface));
            current = prepared;
        }

        var assy = FindProcess(analysis, "ASSY");
        if (assy is not null)
            current = AddProcessWithState(graph, current, "PROC-FINAL-ASSY", TechnologyProcessKind.FinalAssembly, assy,
                ManufacturingStateKind.Finished, "FINISHED_ASSEMBLY", LegacyConfidence(assy));

        // Alias used by evidence with project-wide scope; points to the latest known state.
        if (graph.States.All(x => x.Id != "STATE-PROJECT-CURRENT"))
        {
            graph.States.Add(new AssemblyState
            {
                Id = "STATE-PROJECT-CURRENT",
                State = current.State,
                Name = $"PROJECT_CURRENT → {current.Name}",
                EntityIds = [..current.EntityIds],
                Geometry = Clone(current.Geometry)
            });
        }

        BindProcessEvidence(graph);
        ApplyDependencies(graph);
    }

    private static AssemblyState AddProcessWithState(
        ShadowTechnologyGraph graph,
        AssemblyState input,
        string processId,
        TechnologyProcessKind kind,
        ProcessEstimate legacy,
        ManufacturingStateKind outputKind,
        string outputName,
        ConfidenceVector confidence,
        string? outputId = null)
    {
        var output = AddState(graph, outputId ?? $"STATE-{processId}", outputKind, outputName,
            input.EntityIds, Clone(input.Geometry));
        AddTransitionOnly(graph, input, output, processId, kind, legacy.Name,
            legacy.Hours, legacy.CostPln, confidence, legacy.Basis, legacy.Code);
        return output;
    }

    private static void AddTransitionOnly(
        ShadowTechnologyGraph graph,
        AssemblyState input,
        AssemblyState output,
        string processId,
        TechnologyProcessKind kind,
        string name,
        double legacyHours,
        double legacyCost,
        ConfidenceVector confidence,
        string basis,
        string legacyCode = "")
    {
        var node = new ProcessNode
        {
            Id = processId,
            Process = kind,
            LegacyProcessCode = legacyCode,
            Name = name,
            InputStateIds = [input.Id],
            OutputStateId = output.Id,
            Confidence = confidence,
            LegacyHours = legacyHours,
            LegacyCostPln = legacyCost,
            Basis = basis,
            ShadowOnly = true
        };
        graph.Processes.Add(node);
        input.ConsumedByProcessIds.Add(node.Id);
        output.ProducedByProcessIds.Add(node.Id);
    }

    private static AssemblyState AddState(
        ShadowTechnologyGraph graph,
        string id,
        ManufacturingStateKind kind,
        string name,
        IEnumerable<string> entityIds,
        TechnologyGeometryDescriptor geometry)
    {
        var existing = graph.States.FirstOrDefault(x => string.Equals(x.Id, id, StringComparison.OrdinalIgnoreCase));
        if (existing is not null) return existing;
        var state = new AssemblyState
        {
            Id = id,
            State = kind,
            Name = name,
            EntityIds = entityIds.Distinct(StringComparer.OrdinalIgnoreCase).ToList(),
            Geometry = Clone(geometry)
        };
        graph.States.Add(state);
        return state;
    }

    private static void BindProcessEvidence(ShadowTechnologyGraph graph)
    {
        foreach (var process in graph.Processes)
        {
            var ids = graph.EvidenceBindings
                .Where(binding => EvidenceSupportsProcess(binding, process.Process))
                .Select(binding => binding.Id)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
            process.EvidenceIds.AddRange(ids);
        }

        foreach (var group in graph.UniquePartGroups)
        {
            var ids = graph.EvidenceBindings
                .Where(x => string.Equals(x.ResolvedTargetId, group.Id, StringComparison.OrdinalIgnoreCase) ||
                            x.TargetCandidates.Any(c => string.Equals(c.EntityId, group.Id, StringComparison.OrdinalIgnoreCase) && c.Score >= 0.80))
                .Select(x => x.Id)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
            group.EvidenceIds.AddRange(ids);
        }
    }

    private static void ApplyDependencies(ShadowTechnologyGraph graph)
    {
        for (var i = 1; i < graph.Processes.Count; i++)
        {
            var previous = graph.Processes[i - 1];
            var current = graph.Processes[i];
            current.RequiredBefore.Add(previous.Id);
            previous.RequiredAfter.Add(current.Id);
        }

        if (graph.PostWeldMachiningDetected)
        {
            var weld = graph.Processes.FirstOrDefault(x => x.Process == TechnologyProcessKind.Welding);
            var post = graph.Processes.FirstOrDefault(x => x.Process == TechnologyProcessKind.PostMachining);
            if (weld is not null && post is not null)
            {
                if (!post.RequiredBefore.Contains(weld.Id, StringComparer.OrdinalIgnoreCase))
                    post.RequiredBefore.Add(weld.Id);
                if (!weld.RequiredAfter.Contains(post.Id, StringComparer.OrdinalIgnoreCase))
                    weld.RequiredAfter.Add(post.Id);
            }
        }
    }

    private static void ValidateGraph(ShadowTechnologyGraph graph, AnalysisResult analysis)
    {
        if (graph.HasPriceAuthority)
            graph.Warnings.Add("BŁĄD ARCHITEKTURY: FIX12A shadow nie może mieć price authority.");

        if (graph.PostWeldMachiningDetected)
        {
            var weldIndex = graph.Processes.FindIndex(x => x.Process == TechnologyProcessKind.Welding);
            var cncIndex = graph.Processes.FindIndex(x => x.Process == TechnologyProcessKind.PostMachining);
            if (weldIndex < 0 || cncIndex < 0 || weldIndex >= cncIndex)
                graph.Warnings.Add("Kolejność POST_WELD nie została jednoznacznie odwzorowana: wymagane WELD → POST_MACHINING.");

            var postState = graph.States.FirstOrDefault(x => x.State == ManufacturingStateKind.PostMachined);
            if (postState is not null && analysis.Geometry.Available)
            {
                var bboxMatches = Nearly(postState.Geometry.BoundingXmm, analysis.Geometry.BoundingXmm) &&
                                  Nearly(postState.Geometry.BoundingYmm, analysis.Geometry.BoundingYmm) &&
                                  Nearly(postState.Geometry.BoundingZmm, analysis.Geometry.BoundingZmm);
                if (!bboxMatches)
                    graph.Warnings.Add("POST_MACHINED nie odziedziczył gabarytu całego złożenia STEP.");
            }
        }

        var dxfSources = Math.Max(0, analysis.Dxf.SourceFileCount);
        var plateGroups = graph.UniquePartGroups.Count(x =>
            x.Classification.Contains("Blacha", StringComparison.OrdinalIgnoreCase) ||
            x.Classification.Contains("płyta", StringComparison.OrdinalIgnoreCase));
        if (analysis.Dxf.GeometryMeasurementReliable && dxfSources > 0 && plateGroups > dxfSources)
            graph.Warnings.Add($"DXF scope: {dxfSources} źródło(a) geometrii 2D dla {plateGroups} grup blach — dowód nie może być globalny bez resolvera FIX12B.");

        var paintRatio = analysis.Geometry.SurfaceMm2 > 0
            ? analysis.Geometry.PaintableSurfaceMm2 / analysis.Geometry.SurfaceMm2
            : 1.0;
        if (analysis.Painting.Enabled && paintRatio < 0.20)
            graph.Warnings.Add($"Reality-check shadow: powierzchnia malowania to {paintRatio:P1} powierzchni brutto; wymaga walidacji geometrycznej FIX12C.");
    }

    private static ConfidenceVector LegacyConfidence(ProcessEstimate process) => new()
    {
        Existence = Clamp01(process.Confidence / 100.0),
        Binding = 0.65,
        Geometry = 0.65,
        Parameters = Clamp01(process.Confidence / 100.0)
    };

    private static ConfidenceVector CncConfidence(AnalysisResult analysis, ProcessEstimate process, bool postWeld)
    {
        var depthFeatures = analysis.Geometry.Parts.SelectMany(p => p.Holes)
            .Where(h => h.RequiresCnc || h.RequiresReam || h.RequiresBore || h.PrecisionMachined)
            .ToList();
        var depthCoverage = depthFeatures.Count == 0 ? 0.0 :
            depthFeatures.Count(h => h.DepthMm > 0) / (double)depthFeatures.Count;
        var orderEvidence = postWeld ? 0.98 : Clamp01(process.Confidence / 100.0);
        return new ConfidenceVector
        {
            Existence = orderEvidence,
            Binding = postWeld ? 0.82 : (depthFeatures.Count > 0 ? 0.80 : 0.55),
            Geometry = postWeld
                ? (analysis.Geometry.Available ? 0.70 : 0.35)
                : Math.Clamp(0.50 + depthCoverage * 0.45, 0, 0.95),
            Parameters = depthFeatures.Count == 0 ? 0.45 : Math.Clamp(0.45 + depthCoverage * 0.45, 0, 0.90)
        };
    }

    private static ConfidenceVector CutConfidence(AnalysisResult analysis, ProcessEstimate process)
    {
        var plateGroups = Math.Max(1, analysis.Geometry.Parts.Count(x =>
            x.Classification.Contains("Blacha", StringComparison.OrdinalIgnoreCase) ||
            x.Classification.Contains("płyta", StringComparison.OrdinalIgnoreCase)));
        var measuredSources = Math.Max(0, analysis.Dxf.SourceFileCount);
        var scopeCoverage = Math.Clamp(measuredSources / (double)plateGroups, 0, 1);
        return new ConfidenceVector
        {
            Existence = Clamp01(process.Confidence / 100.0),
            Binding = analysis.Dxf.GeometryMeasurementReliable ? Math.Max(0.35, scopeCoverage) : 0.45,
            Geometry = analysis.Dxf.GeometryMeasurementReliable ? 0.92 : (analysis.Geometry.Available ? 0.65 : 0.40),
            Parameters = analysis.Dxf.CutLengthMm > 0 ? 0.82 : 0.55
        };
    }

    private static ConfidenceVector WeldConfidence(AnalysisResult analysis, ProcessEstimate process) => new()
    {
        Existence = Math.Max(0.50, Clamp01(process.Confidence / 100.0)),
        Binding = analysis.Geometry.WeldCandidatePairs > 0 ? 0.82 : 0.60,
        Geometry = analysis.Geometry.WeldCandidateLengthMm > 0 ? 0.82 : 0.55,
        Parameters = analysis.Drawing.WeldSizeMm.HasValue ? 0.78 : 0.50
    };

    private static ConfidenceVector PaintConfidence(AnalysisResult analysis, ProcessEstimate process)
    {
        var ratio = analysis.Geometry.SurfaceMm2 > 0
            ? analysis.Geometry.PaintableSurfaceMm2 / analysis.Geometry.SurfaceMm2
            : 1.0;
        return new ConfidenceVector
        {
            Existence = Clamp01(process.Confidence / 100.0),
            Binding = analysis.Geometry.Available ? 0.82 : 0.55,
            Geometry = ratio < 0.20 ? 0.35 : 0.80,
            Parameters = analysis.Drawing.TotalDftMicron.HasValue ? 0.85 : 0.55
        };
    }

    private static TechnologyGeometryDescriptor AssemblyGeometry(AnalysisResult analysis) => new()
    {
        BoundingXmm = analysis.Geometry.BoundingXmm,
        BoundingYmm = analysis.Geometry.BoundingYmm,
        BoundingZmm = analysis.Geometry.BoundingZmm,
        VolumeMm3 = analysis.Geometry.VolumeMm3,
        SurfaceMm2 = analysis.Geometry.SurfaceMm2,
        MassKg = analysis.WeightKg ?? 0,
        SolidCount = analysis.Geometry.SolidCount,
        HoleCount = analysis.Geometry.TotalHoleCount,
        FaceCount = analysis.Geometry.Parts.Sum(x => x.FaceCount * Math.Max(1, x.Quantity)),
        EdgeCount = analysis.Geometry.Parts.Sum(x => x.EdgeCount * Math.Max(1, x.Quantity))
    };

    private static TechnologyGeometryDescriptor Clone(TechnologyGeometryDescriptor value) => new()
    {
        BoundingXmm = value.BoundingXmm,
        BoundingYmm = value.BoundingYmm,
        BoundingZmm = value.BoundingZmm,
        VolumeMm3 = value.VolumeMm3,
        SurfaceMm2 = value.SurfaceMm2,
        MassKg = value.MassKg,
        SolidCount = value.SolidCount,
        HoleCount = value.HoleCount,
        FaceCount = value.FaceCount,
        EdgeCount = value.EdgeCount
    };

    private static ProcessEstimate? FindProcess(AnalysisResult analysis, string code) =>
        analysis.Processes.FirstOrDefault(x => x.Enabled && string.Equals(x.Code, code, StringComparison.OrdinalIgnoreCase));

    private static bool EvidenceSupportsProcess(EvidenceBinding binding, TechnologyProcessKind process)
    {
        var field = binding.Field.ToUpperInvariant();
        var constraint = binding.ProcessConstraint.ToUpperInvariant();
        return process switch
        {
            TechnologyProcessKind.Cutting => field.Contains("CUT") || field.Contains("HOLE_COUNT"),
            TechnologyProcessKind.Welding or TechnologyProcessKind.FitUp => field.Contains("WELD"),
            TechnologyProcessKind.PreMachining or TechnologyProcessKind.PostMachining =>
                field.Contains("HOLE") || field.Contains("TOLERANCE") || field.Contains("MACHIN") || constraint.Contains("WELD"),
            TechnologyProcessKind.Painting or TechnologyProcessKind.SurfacePreparation => field.Contains("PAINT") || field.Contains("COATING"),
            _ => false
        };
    }

    private static string GeometryFilterFor(string field)
    {
        var f = field.ToUpperInvariant();
        if (f.Contains("HOLE")) return "hole/cylindrical feature fingerprint";
        if (f.Contains("WELD")) return "joint/contact graph";
        if (f.Contains("PAINT")) return "accessible surface set";
        if (f.Contains("CUT")) return "2D contour ↔ UniquePartGroup";
        if (f.Contains("MASS")) return "entity mass / scope";
        return "unresolved geometry filter";
    }

    private static string ProcessConstraintFor(string field)
    {
        var f = field.ToUpperInvariant();
        if (f.Contains("WELD")) return "PROCESS:WELD";
        if (f.Contains("PAINT")) return "PROCESS:PAINT";
        if (f.Contains("CUT")) return "PROCESS:CUT";
        if (f.Contains("HOLE")) return "PROCESS:CUT_OR_CNC";
        return "";
    }

    private static double GeometryConfidenceFor(string field, AnalysisResult analysis)
    {
        var f = field.ToUpperInvariant();
        if (!analysis.Geometry.Available)
            return f.Contains("MATERIAL") || f.Contains("PAINT_DFT") ? 0.55 : 0.30;
        if (f.Contains("MASS")) return analysis.Geometry.VolumeMm3 > 0 ? 0.95 : 0.65;
        if (f.Contains("HOLE")) return string.Equals(analysis.Geometry.HoleAnalysisState, "complete", StringComparison.OrdinalIgnoreCase) ? 0.92 : 0.60;
        if (f.Contains("WELD")) return analysis.Geometry.WeldCandidatePairs > 0 ? 0.82 : 0.55;
        if (f.Contains("PAINT"))
        {
            var ratio = analysis.Geometry.SurfaceMm2 > 0 ? analysis.Geometry.PaintableSurfaceMm2 / analysis.Geometry.SurfaceMm2 : 1.0;
            return ratio < 0.20 ? 0.35 : 0.82;
        }
        return 0.70;
    }

    private static double ParameterConfidenceFor(string field, bool numeric, AnalysisResult analysis)
    {
        var f = field.ToUpperInvariant();
        if (f.Contains("WELD") && analysis.Drawing.WeldTypeHint == "GROOVE" && !analysis.Drawing.WeldGrooveAngleDeg.HasValue)
            return 0.50;
        if (f.Contains("PAINT") && analysis.Drawing.TotalDftMicron.HasValue) return 0.85;
        return numeric ? 0.80 : 0.65;
    }

    private static double ScopeBindingConfidence(string scope) => scope.ToUpperInvariant() switch
    {
        "PROJECT_TOTAL" or "ASSEMBLY_TOTAL" => 0.85,
        "TECHNICAL" or "COATING" or "WELD" => 0.68,
        "PART" or "SUBASSEMBLY" => 0.62,
        _ => 0.45
    };

    private static bool IsAssemblyWideField(string field)
    {
        var f = field.ToUpperInvariant();
        return f.Contains("MASS") || f.Contains("MATERIAL") || f.Contains("PAINT") || f.Contains("WELD_PROCESS");
    }

    private static double CandidateScore(string sourceStem, UniquePartGroup group)
    {
        if (string.IsNullOrWhiteSpace(sourceStem)) return 0;
        var name = Normalize(group.Name);
        var key = Normalize(group.GeometryKey);
        var groupSource = Normalize(Path.GetFileNameWithoutExtension(group.SourceFile));
        if (sourceStem == name || sourceStem == key || sourceStem == groupSource) return 0.98;
        if ((!string.IsNullOrWhiteSpace(name) && (sourceStem.Contains(name) || name.Contains(sourceStem))) ||
            (!string.IsNullOrWhiteSpace(key) && (sourceStem.Contains(key) || key.Contains(sourceStem)))) return 0.85;
        var sourceTokens = Tokens(sourceStem);
        var groupTokens = Tokens($"{name} {key} {groupSource}");
        if (sourceTokens.Count == 0 || groupTokens.Count == 0) return 0;
        var common = sourceTokens.Intersect(groupTokens, StringComparer.OrdinalIgnoreCase).Count();
        return common / (double)Math.Max(sourceTokens.Count, groupTokens.Count);
    }

    private static HashSet<string> Tokens(string value) => Regex.Split(value, @"[^A-Z0-9]+")
        .Where(x => x.Length >= 2 && x is not "DRAWING" and not "MODEL" and not "STEP" and not "DXF")
        .ToHashSet(StringComparer.OrdinalIgnoreCase);

    private static string Normalize(string value) => Regex.Replace((value ?? "").ToUpperInvariant(), @"[^A-Z0-9]+", " ").Trim();
    private static string Slug(string value)
    {
        var slug = Regex.Replace((value ?? "GROUP").ToUpperInvariant(), @"[^A-Z0-9]+", "-").Trim('-');
        if (string.IsNullOrWhiteSpace(slug)) slug = "GROUP";
        return slug.Length <= 36 ? slug : slug[..36];
    }

    private static bool RequiresPostWeldMachining(AnalysisResult analysis) =>
        analysis.Drawing.Findings.Any(ContainsAfterWeld) ||
        analysis.Drawing.Warnings.Any(ContainsAfterWeld) ||
        analysis.Drawing.DimensionalTolerances.Any(x => ContainsAfterWeld(x.SourceText)) ||
        analysis.Drawing.GeometricTolerances.Any(x => ContainsAfterWeld(x.SourceText));

    private static bool ContainsAfterWeld(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return false;
        return value.Contains("AFTER WELD", StringComparison.OrdinalIgnoreCase) ||
               value.Contains("POST WELD", StringComparison.OrdinalIgnoreCase) ||
               value.Contains("POST-WELD", StringComparison.OrdinalIgnoreCase) ||
               value.Contains("PO SPAW", StringComparison.OrdinalIgnoreCase) ||
               value.Contains("NACH DEM SCHWEISS", StringComparison.OrdinalIgnoreCase);
    }

    private static bool Nearly(double a, double b) => Math.Abs(a - b) <= Math.Max(0.01, Math.Abs(b) * 0.001);
    private static double Clamp01(double value) => Math.Clamp(value, 0.0, 1.0);
    private static string Append(string current, string addition) => string.IsNullOrWhiteSpace(current) ? addition : $"{current} {addition}";
}
