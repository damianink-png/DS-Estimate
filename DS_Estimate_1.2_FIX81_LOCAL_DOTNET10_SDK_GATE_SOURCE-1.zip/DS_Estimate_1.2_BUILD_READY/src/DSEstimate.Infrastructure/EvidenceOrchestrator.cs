﻿using System.Globalization;
using System.Text.RegularExpressions;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

/// <summary>
/// FIX10: deterministic, offline evidence orchestration layer with protected source voting.
///
/// Specialist analyzers remain authoritative for extraction.  This layer keeps
/// their observations with provenance, compares independent sources, detects
/// likely OCR scale errors and explains the route taken for every document.
/// In FIX9.5a decisions are audit-only: they never silently overwrite Cost Engine
/// inputs.  That safety boundary lets real FIX9/FIX9.5a reports be compared before
/// any decision is allowed to affect FIX10 pricing.
/// </summary>
public static class EvidenceOrchestrator
{
    public const string Version = "FIX10-EVIDENCE-3";

    public static EvidenceOrchestrationSummary Build(
        QuoteProject project,
        IReadOnlyList<GeometrySummary> geometrySources,
        IReadOnlyList<DrawingIntelligence> drawingSources,
        IReadOnlyList<DxfSignals> dxfSources,
        AnalysisResult result)
    {
        var summary = new EvidenceOrchestrationSummary { Version = Version };
        summary.ContentDuplicates = BuildContentDuplicates(project.Documents);
        var sourceIdentityMap = BuildSourceIdentityMap(project.Documents);

        AddMassEvidence(summary, project, drawingSources, dxfSources, result);
        AddMaterialEvidence(summary, drawingSources, result.Drawing);
        AddCoatingEvidence(summary, drawingSources, dxfSources);
        AddWeldEvidence(summary, drawingSources, dxfSources);
        AddGeometryEvidence(summary, result);
        AddOcrEvidence(summary, drawingSources);

        // PDF and DXF representations of the same document can reach this layer
        // through two adapters. Keep one strongest copy of an identical fact so
        // representation duplication never masquerades as independent consensus.
        foreach (var fact in summary.Facts)
            fact.SourceIdentity = ResolveSourceIdentity(fact.SourceFile, sourceIdentityMap);

        summary.Facts = summary.Facts
            .GroupBy(FactIdentity, StringComparer.OrdinalIgnoreCase)
            .Select(group =>
            {
                var best = group.OrderByDescending(x => x.Confidence).First();
                best.SourceAliases = group.Select(x => x.SourceFile)
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .OrderBy(x => x, StringComparer.OrdinalIgnoreCase)
                    .ToList();
                if (best.SourceAliases.Count > 1)
                    best.Note = JoinNote(best.Note,
                        $"Ta sama zawartość występuje pod nazwami: {string.Join(", ", best.SourceAliases)}; policzono jeden niezależny głos.");
                return best;
            })
            .OrderBy(x => x.Field, StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.SourceFile, StringComparer.OrdinalIgnoreCase)
            .ToList();

        summary.Decisions.Add(BuildMassDecision(summary.Facts, result));
        summary.Decisions.Add(BuildTextDecision(
            summary.Facts, "material", "Materiał", Known(result.Material), "Sprawdź oznaczenie materiału w BOM i dokumentacji.", materialCompatibility: true));
        AddOptionalDecision(summary, BuildTextDecision(
            summary.Facts, "paint_ral", "Kolor / RAL", result.Drawing.PaintColour,
            "Sprawdź właściwy system powłok dla każdej strefy lub podzespołu."));
        AddOptionalDecision(summary, BuildNumericDecision(
            summary.Facts, "paint_dft", "Łączna grubość DFT", result.Drawing.TotalDftMicron,
            "µm", 0.05, 0.10,
            "Porównaj zapis systemu malarskiego na rysunku i w specyfikacji."));
        AddOptionalDecision(summary, BuildTextDecision(
            summary.Facts, "weld_process", "Proces spawania", result.Drawing.WeldProcessCode,
            "Sprawdź proces ISO 4063 przypisany do poszczególnych złączy."));

        double? selectedThroat = result.Drawing.WeldSizeMm is > 0
            ? EquivalentWeldThroat(result.Drawing.WeldSizeMm.Value, result.Drawing.WeldSizeKind)
            : null;
        var weldDecision = BuildNumericDecision(
            summary.Facts, "weld_throat", "Równoważna gardziel spoiny", selectedThroat,
            "mm", 0.04, 0.12,
            "Sprawdź symbole a/z oraz przypisanie wymiaru do konkretnych złączy.");
        if (weldDecision is not null && result.Drawing.WeldSizeMm is > 0)
            weldDecision.SelectedValue = $"{result.Drawing.WeldSizeKind}{result.Drawing.WeldSizeMm.Value:0.###}";
        AddOptionalDecision(summary, weldDecision);

        AddOptionalDecision(summary, BuildCountDecision(
            summary.Facts, "hole_count", "Liczba otworów", result.DetectedHoleCount,
            "Porównaj ilości otworów z geometrii STEP i oznaczeń 2D; różnica może wynikać z krotności BOM."));
        AddOptionalDecision(summary, BuildOcrDecision(summary.Facts));

        summary.Routes = BuildRoutes(project.Documents, geometrySources, drawingSources, dxfSources)
            .OrderBy(x => x.Priority)
            .ThenBy(x => x.SourceFile, StringComparer.OrdinalIgnoreCase)
            .ToList();

        summary.RecommendedActions = summary.Decisions
            .Where(x => x.NeedsReview && !string.IsNullOrWhiteSpace(x.NextAction))
            .Select(x => x.NextAction.Trim())
            .Concat(summary.Routes
                .Where(x => !string.IsNullOrWhiteSpace(x.NextAction))
                .Select(x => x.NextAction.Trim()))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(20)
            .ToList();

        if (summary.RecommendedActions.Count == 0)
            summary.RecommendedActions.Add("Brak obowiązkowej ponownej analizy; zachowaj raport jako punkt odniesienia dla FIX10.");

        return summary;
    }

    private static void AddMassEvidence(
        EvidenceOrchestrationSummary summary,
        QuoteProject project,
        IReadOnlyList<DrawingIntelligence> drawings,
        IReadOnlyList<DxfSignals> dxfs,
        AnalysisResult result)
    {
        if (project.ManualWeightKg is > 0)
        {
            AddNumber(summary, "mass", "Masa", project.ManualWeightKg.Value, "kg",
                "Dane projektu", "Ręczne", "Wartość operatora", "PROJECT_TOTAL", 100,
                "Jawne pole masy ma pierwszeństwo, ale nadal jest porównywane z dokumentami.");
        }

        foreach (var drawing in drawings)
        {
            if (drawing.DocumentMassKg is > 0)
            {
                AddNumber(summary, "mass", "Masa", drawing.DocumentMassKg.Value, "kg",
                    SourceName(drawing.SourceFile), SourceKind(drawing.SourceFile),
                    SemanticMethod(drawing), Scope(drawing.DocumentMassScope),
                    Math.Clamp(drawing.DocumentMassConfidence, 35, 99), drawing.DocumentMassEvidence);
            }
            if (drawing.BomTotalMassKg is > 0 && drawing.BomMassRowCount > 0)
            {
                var confidence = drawing.BomMassSourceCount >= 2 ? 95 : 88;
                AddNumber(summary, "mass", "Masa BOM", drawing.BomTotalMassKg.Value, "kg",
                    SourceName(drawing.SourceFile), "BOM", "Suma kontrolowanych pozycji BOM",
                    "BOM_TOTAL", confidence,
                    $"{drawing.BomPositiveMassRowCount}/{drawing.BomMassRowCount} dodatnich pozycji masowych");
            }
        }

        foreach (var dxf in dxfs.Where(x => x.DocumentMassKg is > 0))
        {
            AddNumber(summary, "mass", "Masa z DXF/DWG", dxf.DocumentMassKg!.Value, "kg",
                SourceName(dxf.SourceFile), SourceKind(dxf.SourceFile), "Parser tekstu/bloków CAD",
                Scope(dxf.DocumentMassScope), Math.Clamp(dxf.DocumentMassConfidence, 35, 98),
                dxf.DocumentMassEvidence);
        }

        if (result.Geometry.Available && result.Geometry.VolumeMm3 > 0 && result.DensityKgM3 > 0)
        {
            var geometryMass = result.Geometry.VolumeMm3 / 1_000_000_000.0 * result.DensityKgM3;
            var confidence = result.Geometry.AnalysisMode.Contains("full", StringComparison.OrdinalIgnoreCase)
                ? 96
                : result.Geometry.AnalysisMode.Contains("checkpoint", StringComparison.OrdinalIgnoreCase)
                    ? 68
                    : 82;
            var stepScope = result.Drawing.StepGeometryProjectCoveragePartial ? "PARTIAL_PROJECT" : "PROJECT_TOTAL";
            var stepNote = result.Drawing.StepGeometryProjectCoveragePartial
                ? $"FIX12D: dostępny STEP pokrywa {result.Drawing.ResolvedStepFamilyMatchCount}/{result.Drawing.ResolvedRootBomFamilyCount} rodzin głównego BOM; masa STEP jest lokalnym cross-checkiem, nie masą całego projektu."
                : result.DensityAssumed ? "Gęstość przyjęta zastępczo." : "Gęstość wynika z rozpoznanego materiału/ustawień.";
            if (result.Drawing.StepGeometryProjectCoveragePartial)
                confidence = Math.Min(confidence, 62);
            AddNumber(summary, "mass", "Masa z objętości STEP", geometryMass, "kg",
                "STEP po Data Fusion", "STEP", $"Objętość × gęstość {result.DensityKgM3:0.###} kg/m³",
                stepScope, confidence, stepNote);
        }
    }

    private static void AddMaterialEvidence(
        EvidenceOrchestrationSummary summary,
        IReadOnlyList<DrawingIntelligence> drawings,
        DrawingIntelligence fusedDrawing)
    {
        // FIX12D: in a real assembly, S355/S690/S960/stainless etc. can all be valid
        // simultaneously for different positions.  Once a root BOM has been resolved,
        // numbered drawing families are therefore local evidence and must not vote
        // against one project-wide material.  Root/general specifications may still
        // support the project-level selection.
        var scoped = fusedDrawing.ResolvedRootBomFamilyCount > 0;
        foreach (var drawing in drawings.Where(x => !string.IsNullOrWhiteSpace(x.MaterialHint)))
        {
            var entity = DocumentFamilyResolver.ExtractEntityKey(drawing.SourceFile);
            var isRootOrGeneral = string.IsNullOrWhiteSpace(entity) ||
                                  entity.Equals(fusedDrawing.ResolvedRootEntityKey, StringComparison.OrdinalIgnoreCase);
            if (scoped && !isRootOrGeneral)
            {
                AddText(summary, "material_local", "Materiał detalu", drawing.MaterialHint,
                    SourceName(drawing.SourceFile), SourceKind(drawing.SourceFile), SemanticMethod(drawing),
                    $"PART:{entity}", SemanticConfidence(drawing, 82));
            }
            else
            {
                AddText(summary, "material", "Materiał", drawing.MaterialHint,
                    SourceName(drawing.SourceFile), SourceKind(drawing.SourceFile), SemanticMethod(drawing),
                    "TECHNICAL", SemanticConfidence(drawing, 82));
            }
        }

        // A mixed BOM legitimately contains several materials. Promote a BOM
        // material to project-level evidence only when one source is unambiguous;
        // otherwise retain it as local audit evidence.
        foreach (var source in drawings.SelectMany(x => x.BomItems)
                     .Where(x => !string.IsNullOrWhiteSpace(x.Material))
                     .GroupBy(x => SourceName(x.SourceFile), StringComparer.OrdinalIgnoreCase))
        {
            var values = source.Select(x => x.Material.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            var entity = DocumentFamilyResolver.ExtractEntityKey(source.Key);
            var local = scoped && !string.IsNullOrWhiteSpace(entity) &&
                        !entity.Equals(fusedDrawing.ResolvedRootEntityKey, StringComparison.OrdinalIgnoreCase);
            if (values.Count == 1)
                AddText(summary, local ? "material_local" : "material", local ? "Materiał detalu BOM" : "Materiał BOM", values[0], source.Key,
                    "BOM", "Kolumna materiału BOM", local ? $"PART:{entity}" : "TECHNICAL", 88);
        }
    }

    private static void AddCoatingEvidence(
        EvidenceOrchestrationSummary summary,
        IReadOnlyList<DrawingIntelligence> drawings,
        IReadOnlyList<DxfSignals> dxfs)
    {
        foreach (var drawing in drawings)
        {
            var confidence = SemanticConfidence(drawing, 78);
            if (!string.IsNullOrWhiteSpace(drawing.PaintColour))
                AddText(summary, "paint_ral", "Kolor / RAL", drawing.PaintColour,
                    SourceName(drawing.SourceFile), SourceKind(drawing.SourceFile), SemanticMethod(drawing),
                    "COATING", confidence);
            if (drawing.TotalDftMicron is > 0)
                AddNumber(summary, "paint_dft", "Łączna DFT", drawing.TotalDftMicron.Value, "µm",
                    SourceName(drawing.SourceFile), SourceKind(drawing.SourceFile), SemanticMethod(drawing),
                    "COATING", confidence, PaintLayerNote(drawing.PaintLayers));
        }

        foreach (var dxf in dxfs)
        {
            if (!string.IsNullOrWhiteSpace(dxf.PaintColour))
                AddText(summary, "paint_ral", "Kolor / RAL", dxf.PaintColour,
                    SourceName(dxf.SourceFile), SourceKind(dxf.SourceFile), "Parser tekstu/bloków CAD",
                    "COATING", 84);
            if (dxf.TotalDftMicron is > 0)
                AddNumber(summary, "paint_dft", "Łączna DFT", dxf.TotalDftMicron.Value, "µm",
                    SourceName(dxf.SourceFile), SourceKind(dxf.SourceFile), "Parser tekstu/bloków CAD",
                    "COATING", 84, PaintLayerNote(dxf.PaintLayers));
        }
    }

    private static void AddWeldEvidence(
        EvidenceOrchestrationSummary summary,
        IReadOnlyList<DrawingIntelligence> drawings,
        IReadOnlyList<DxfSignals> dxfs)
    {
        foreach (var drawing in drawings)
        {
            var confidence = SemanticConfidence(drawing, 78);
            if (!string.IsNullOrWhiteSpace(drawing.WeldProcessCode))
                AddText(summary, "weld_process", "Proces spawania", drawing.WeldProcessCode,
                    SourceName(drawing.SourceFile), SourceKind(drawing.SourceFile), SemanticMethod(drawing),
                    "WELD", confidence);
            if (drawing.WeldSizeMm is > 0)
            {
                var throat = EquivalentWeldThroat(drawing.WeldSizeMm.Value, drawing.WeldSizeKind);
                AddNumber(summary, "weld_throat", "Równoważna gardziel spoiny", throat, "mm",
                    SourceName(drawing.SourceFile), SourceKind(drawing.SourceFile), SemanticMethod(drawing),
                    "WELD", confidence,
                    $"Odczyt {drawing.WeldSizeKind}{drawing.WeldSizeMm.Value:0.###}; po normalizacji a≈{throat:0.###} mm.",
                    $"{drawing.WeldSizeKind}{drawing.WeldSizeMm.Value:0.###}");
            }
        }

        foreach (var dxf in dxfs)
        {
            if (!string.IsNullOrWhiteSpace(dxf.WeldProcessCode))
                AddText(summary, "weld_process", "Proces spawania", dxf.WeldProcessCode,
                    SourceName(dxf.SourceFile), SourceKind(dxf.SourceFile), "Parser tekstu/bloków CAD",
                    "WELD", 84);
            if (dxf.WeldSizeMm is > 0)
            {
                var throat = EquivalentWeldThroat(dxf.WeldSizeMm.Value, dxf.WeldSizeKind);
                AddNumber(summary, "weld_throat", "Równoważna gardziel spoiny", throat, "mm",
                    SourceName(dxf.SourceFile), SourceKind(dxf.SourceFile), "Parser tekstu/bloków CAD",
                    "WELD", 84,
                    $"Odczyt {dxf.WeldSizeKind}{dxf.WeldSizeMm.Value:0.###}; po normalizacji a≈{throat:0.###} mm.",
                    $"{dxf.WeldSizeKind}{dxf.WeldSizeMm.Value:0.###}");
            }
        }
    }

    private static void AddGeometryEvidence(EvidenceOrchestrationSummary summary, AnalysisResult result)
    {
        if (result.Geometry.Available)
        {
            if (result.Geometry.PaintableSurfaceMm2 > 0)
                AddNumber(summary, "paint_area", "Powierzchnia do malowania",
                    result.Geometry.PaintableSurfaceMm2 / 1_000_000.0, "m²",
                    "STEP po Data Fusion", "STEP", "Analiza dostępności i powierzchni dolegania",
                    "PROJECT_TOTAL", result.Geometry.SurfaceAccessibilityLimitReached ? 68 : 90);
            if (result.Geometry.TotalHoleCount > 0)
                AddNumber(summary, "hole_count", "Otwory STEP", result.Geometry.TotalHoleCount, "szt.",
                    "STEP po Data Fusion", "STEP", "Hole Engine", "PROJECT_TOTAL",
                    result.Geometry.AnalysisMode.Contains("checkpoint", StringComparison.OrdinalIgnoreCase) ? 55 : 92);
        }

        if (result.Drawing.EstimatedHoleCount2D > 0)
            AddNumber(summary, "hole_count", "Otwory 2D", result.Drawing.EstimatedHoleCount2D, "szt.",
                "PDF/DXF po Data Fusion", "2D", "Semantyka wymiarów i opisów", "PROJECT_TOTAL", 76);
        if (result.Drawing.DocumentSurfaceAreaM2 is > 0)
            AddNumber(summary, "paint_area", "Powierzchnia z dokumentacji",
                result.Drawing.DocumentSurfaceAreaM2.Value, "m²", "Dokumentacja po Data Fusion", "2D",
                "Jawna wartość powierzchni", "PROJECT_TOTAL", result.Drawing.DocumentSurfaceAreaConfidence);
        if (result.Dxf.GeometryMeasurementReliable && result.Dxf.CutLengthMm > 0)
            AddNumber(summary, "cut_length", "Długość cięcia", result.Dxf.CutLengthMm / 1000.0, "m",
                "DXF/DWG po Data Fusion", "DXF/DWG", "Geometria warstw cięcia", "PROJECT_TOTAL", 94);
    }

    private static void AddOcrEvidence(
        EvidenceOrchestrationSummary summary,
        IReadOnlyList<DrawingIntelligence> drawings)
    {
        foreach (var drawing in drawings.Where(x => x.OcrCriticalConfidence.HasValue))
        {
            AddNumber(summary, "ocr_quality", "Pewność OCR danych krytycznych",
                drawing.OcrCriticalConfidence!.Value, "%", SourceName(drawing.SourceFile),
                SourceKind(drawing.SourceFile), "Tesseract + cross-check", "QUALITY",
                Math.Clamp((int)Math.Round(drawing.OcrCriticalConfidence.Value), 1, 99),
                drawing.OcrCriticalConflicts.Count > 0
                    ? string.Join(" | ", drawing.OcrCriticalConflicts.Take(4))
                    : "Brak twardego konfliktu cross-check.");
        }
    }

    private static EvidenceDecision BuildMassDecision(IReadOnlyList<EvidenceFact> allFacts, AnalysisResult result)
    {
        var facts = allFacts.Where(x => x.Field == "mass" && x.NumericValue is > 0).ToList();
        var selected = result.WeightKg;
        var decision = new EvidenceDecision
        {
            Field = "mass",
            Label = "Masa całkowita",
            SelectedNumericValue = selected,
            Unit = "kg",
            SelectedValue = result.WeightSource,
            Rule = "MASS_SCOPE_CONSENSUS_9_5",
            SourceFiles = facts.Select(x => x.SourceFile).Distinct(StringComparer.OrdinalIgnoreCase).ToList()
        };

        if (selected is not > 0)
        {
            decision.State = "BRAK_DANYCH";
            decision.Confidence = 0;
            decision.NeedsReview = true;
            decision.Explanation = "Żadne bezpieczne źródło nie dostarczyło masy całkowitej.";
            decision.NextAction = "Dodaj masę ręcznie, pełny BOM albo poprawny model STEP z materiałem/gęstością.";
            return decision;
        }

        foreach (var fact in facts)
        {
            if (fact.Scope is "PART" or "SUBASSEMBLY" or "UNKNOWN" or "PARTIAL_PROJECT")
            {
                fact.Note = JoinNote(fact.Note, fact.Scope == "UNKNOWN"
                    ? "Zakres masy nie jest potwierdzony; wskazanie pozostaje diagnostyczne i nie konkuruje z masą całego projektu."
                    : fact.Scope == "PARTIAL_PROJECT"
                        ? "Masa z częściowego pokrycia CAD/STEP; nie konkuruje z masą całego projektu."
                        : "Masa lokalna; nie konkuruje z masą całego projektu.");
                continue;
            }

            var relative = RelativeDifference(fact.NumericValue!.Value, selected.Value);
            if (relative <= 0.03)
            {
                fact.SupportsDecision = true;
                continue;
            }
            if (IsDecimalScaleOutlier(fact.NumericValue.Value, selected.Value))
            {
                fact.Outlier = true;
                fact.Note = JoinNote(fact.Note, "Podejrzenie utraty/przesunięcia separatora dziesiętnego w OCR lub tabeli.");
                continue;
            }
            if (relative > 0.08)
                fact.ConflictsWithDecision = true;
        }

        decision.SupportingSources = IndependentSourceCount(facts.Where(x => x.SupportsDecision));
        decision.ConflictingSources = IndependentSourceCount(facts.Where(x => x.ConflictsWithDecision));
        decision.OutlierSources = IndependentSourceCount(facts.Where(x => x.Outlier));
        var independentSupport = facts.Where(x => x.SupportsDecision)
            .Select(VoteIdentity)
            .Distinct(StringComparer.OrdinalIgnoreCase).Count();

        var manual = facts.Any(x => x.SupportsDecision && x.SourceKind == "Ręczne");
        if (decision.ConflictingSources > 0)
        {
            decision.State = "KONFLIKT";
            decision.Confidence = manual ? 92 : Math.Max(45, independentSupport >= 2 ? 78 : 58);
            decision.NeedsReview = true;
            decision.Explanation = $"Wybrano {selected:0.###} kg ({result.WeightSource}), ale " +
                                   $"{decision.ConflictingSources} źródło/źródła różnią się o ponad 8%.";
            decision.NextAction = "Sprawdź zakres masy (detal/podzespół/całość) w wskazanych źródłach; nie sumuj ich ręcznie bez potwierdzenia.";
        }
        else if (independentSupport >= 2)
        {
            decision.State = "POTWIERDZONE";
            decision.Confidence = manual ? 100 : 94;
            decision.Explanation = $"Masa {selected:0.###} kg jest zgodna w {independentSupport} niezależnych źródłach.";
        }
        else if (independentSupport == 1)
        {
            decision.State = decision.OutlierSources > 0 ? "POTWIERDZONE_Z_ODSTAJACYM" : "JEDNO_ZRODLO";
            decision.Confidence = manual ? 100 : decision.OutlierSources > 0 ? 84 : 76;
            decision.NeedsReview = !manual && decision.OutlierSources == 0;
            decision.Explanation = decision.OutlierSources > 0
                ? $"Masa {selected:0.###} kg ma jedno zgodne źródło; {decision.OutlierSources} odczyt oznaczono jako prawdopodobny błąd skali/przecinka."
                : $"Masa {selected:0.###} kg pochodzi z jednego bezpiecznego źródła ({result.WeightSource}).";
            if (decision.NeedsReview)
                decision.NextAction = "Potwierdź masę drugim niezależnym źródłem: BOM, STEP albo jawna masa całkowita na rysunku.";
        }
        else
        {
            decision.State = "WYBRANO_Z_REGULY";
            decision.Confidence = 62;
            decision.NeedsReview = true;
            decision.Explanation = $"Cost Engine wybrał {selected:0.###} kg ({result.WeightSource}), ale warstwa dowodów nie znalazła zgodnego wskazania projektowego.";
            decision.NextAction = "Zweryfikuj źródło masy oraz zakres dokumentów przed zatwierdzeniem ceny.";
        }

        return decision;
    }

    private static EvidenceDecision BuildTextDecision(
        IReadOnlyList<EvidenceFact> allFacts,
        string field,
        string label,
        string? selected,
        string reviewAction,
        bool materialCompatibility = false)
    {
        var facts = allFacts.Where(x => x.Field == field && !string.IsNullOrWhiteSpace(x.Value)).ToList();
        var chosen = Known(selected);
        var decision = new EvidenceDecision
        {
            Field = field,
            Label = label,
            SelectedValue = chosen,
            Rule = materialCompatibility ? "TEXT_MATERIAL_FAMILY_9_5" : "TEXT_CONSENSUS_9_5",
            SourceFiles = facts.Select(x => x.SourceFile).Distinct(StringComparer.OrdinalIgnoreCase).ToList()
        };

        if (string.IsNullOrWhiteSpace(chosen))
        {
            decision.State = "BRAK_DANYCH";
            decision.Confidence = 0;
            decision.NeedsReview = facts.Count > 0;
            decision.Explanation = facts.Count == 0
                ? "Brak wskazań w dokumentacji."
                : "Źródła zawierają wskazania, ale Data Fusion nie wybrał bezpiecznej wartości.";
            decision.NextAction = decision.NeedsReview ? reviewAction : "";
            return decision;
        }

        foreach (var fact in facts)
        {
            var compatible = materialCompatibility
                ? MaterialsCompatible(fact.Value, chosen)
                : NormalizeText(fact.Value) == NormalizeText(chosen);
            if (compatible)
                fact.SupportsDecision = true;
            else
                fact.ConflictsWithDecision = true;
        }

        decision.SupportingSources = IndependentSourceCount(facts.Where(x => x.SupportsDecision));
        decision.ConflictingSources = IndependentSourceCount(facts.Where(x => x.ConflictsWithDecision));
        var independentSupport = facts.Where(x => x.SupportsDecision)
            .Select(VoteIdentity)
            .Distinct(StringComparer.OrdinalIgnoreCase).Count();

        if (decision.ConflictingSources > 0)
        {
            decision.State = "KONFLIKT";
            decision.Confidence = independentSupport >= 2 ? 78 : 55;
            decision.NeedsReview = true;
            decision.Explanation = $"Wybrano „{chosen}”, lecz wykryto {decision.ConflictingSources} sprzeczne wskazanie/wskazania.";
            decision.NextAction = reviewAction;
        }
        else if (independentSupport >= 2)
        {
            decision.State = "POTWIERDZONE";
            decision.Confidence = 93;
            decision.Explanation = $"Wartość „{chosen}” potwierdzają {independentSupport} niezależne źródła.";
        }
        else
        {
            decision.State = "JEDNO_ZRODLO";
            decision.Confidence = facts.Count > 0 ? Math.Clamp(facts.Max(x => x.Confidence), 55, 88) : 50;
            decision.NeedsReview = facts.Count == 0;
            decision.Explanation = facts.Count > 0
                ? $"Wartość „{chosen}” pochodzi z jednego logicznego źródła."
                : $"Wartość „{chosen}” istnieje w wyniku, ale brak zachowanego surowego wskazania.";
            if (decision.NeedsReview)
                decision.NextAction = reviewAction;
        }

        return decision;
    }

    private static EvidenceDecision? BuildNumericDecision(
        IReadOnlyList<EvidenceFact> allFacts,
        string field,
        string label,
        double? selected,
        string unit,
        double supportTolerance,
        double conflictTolerance,
        string reviewAction)
    {
        var facts = allFacts.Where(x => x.Field == field && x.NumericValue.HasValue).ToList();
        if (selected is not > 0 && facts.Count == 0)
            return null;

        var decision = new EvidenceDecision
        {
            Field = field,
            Label = label,
            SelectedNumericValue = selected,
            Unit = unit,
            Rule = "NUMERIC_CONSENSUS_9_5",
            SourceFiles = facts.Select(x => x.SourceFile).Distinct(StringComparer.OrdinalIgnoreCase).ToList()
        };
        if (selected is not > 0)
        {
            decision.State = "BRAK_WYBORU";
            decision.NeedsReview = true;
            decision.Explanation = "Wykryto wartości źródłowe, ale Data Fusion nie wybrał bezpiecznego wyniku.";
            decision.NextAction = reviewAction;
            return decision;
        }

        foreach (var fact in facts)
        {
            var relative = RelativeDifference(fact.NumericValue!.Value, selected.Value);
            if (relative <= supportTolerance)
                fact.SupportsDecision = true;
            else if (IsDecimalScaleOutlier(fact.NumericValue.Value, selected.Value))
                fact.Outlier = true;
            else if (relative > conflictTolerance)
                fact.ConflictsWithDecision = true;
        }

        decision.SupportingSources = IndependentSourceCount(facts.Where(x => x.SupportsDecision));
        decision.ConflictingSources = IndependentSourceCount(facts.Where(x => x.ConflictsWithDecision));
        decision.OutlierSources = IndependentSourceCount(facts.Where(x => x.Outlier));
        var independentSupport = facts.Where(x => x.SupportsDecision)
            .Select(VoteIdentity)
            .Distinct(StringComparer.OrdinalIgnoreCase).Count();

        if (decision.ConflictingSources > 0)
        {
            decision.State = "KONFLIKT";
            decision.Confidence = independentSupport >= 2 ? 78 : 55;
            decision.NeedsReview = true;
            decision.Explanation = $"Wybrana wartość {selected:0.###} {unit} ma {decision.ConflictingSources} sprzeczne wskazanie/wskazania.";
            decision.NextAction = reviewAction;
        }
        else if (independentSupport >= 2)
        {
            decision.State = "POTWIERDZONE";
            decision.Confidence = 93;
            decision.Explanation = $"Wartość {selected:0.###} {unit} potwierdzają {independentSupport} niezależne źródła.";
        }
        else
        {
            decision.State = decision.OutlierSources > 0 ? "POTWIERDZONE_Z_ODSTAJACYM" : "JEDNO_ZRODLO";
            decision.Confidence = decision.OutlierSources > 0 ? 82 : 72;
            decision.NeedsReview = independentSupport == 0;
            decision.Explanation = decision.OutlierSources > 0
                ? $"Wartość {selected:0.###} {unit} zachowano; {decision.OutlierSources} wskazanie oznaczono jako możliwy błąd skali/przecinka."
                : $"Wartość {selected:0.###} {unit} nie ma drugiego niezależnego potwierdzenia.";
            if (decision.NeedsReview)
                decision.NextAction = reviewAction;
        }
        return decision;
    }

    private static EvidenceDecision? BuildCountDecision(
        IReadOnlyList<EvidenceFact> allFacts,
        string field,
        string label,
        int selected,
        string reviewAction)
    {
        var facts = allFacts.Where(x => x.Field == field && x.NumericValue is > 0).ToList();
        if (selected <= 0 && facts.Count == 0)
            return null;

        var decision = new EvidenceDecision
        {
            Field = field,
            Label = label,
            SelectedNumericValue = selected > 0 ? selected : null,
            Unit = "szt.",
            Rule = "COUNT_MAX_WITH_REPRESENTATION_GUARD_9_5",
            SourceFiles = facts.Select(x => x.SourceFile).Distinct(StringComparer.OrdinalIgnoreCase).ToList()
        };
        foreach (var fact in facts)
        {
            if (Math.Abs(fact.NumericValue!.Value - selected) < 0.001)
                fact.SupportsDecision = true;
        }
        decision.SupportingSources = IndependentSourceCount(facts.Where(x => x.SupportsDecision));
        var independentSources = IndependentSourceCount(facts);
        var distinct = facts.Select(x => x.NumericValue!.Value).Distinct().Count();
        if (distinct > 1)
        {
            decision.State = "ROZNICE_REPREZENTACJI";
            decision.Confidence = 72;
            decision.NeedsReview = false;
            decision.Explanation = "STEP i dokumentacja 2D mogą opisywać tę samą cechę z inną krotnością; Cost Engine zachowuje większą bezpieczną liczbę zamiast je sumować.";
            decision.NextAction = "";
        }
        else if (independentSources >= 2)
        {
            decision.State = "POTWIERDZONE";
            decision.Confidence = 92;
            decision.Explanation = "Liczba cech jest zgodna w geometrii i dokumentacji.";
        }
        else
        {
            decision.State = "JEDNO_ZRODLO";
            decision.Confidence = 76;
            decision.Explanation = "Liczba cech pochodzi z jednego typu reprezentacji.";
        }
        return decision;
    }

    private static EvidenceDecision? BuildOcrDecision(IReadOnlyList<EvidenceFact> allFacts)
    {
        var facts = allFacts.Where(x => x.Field == "ocr_quality" && x.NumericValue.HasValue)
            .GroupBy(VoteIdentity, StringComparer.OrdinalIgnoreCase)
            .Select(x => x.OrderByDescending(f => f.Confidence).First())
            .ToList();
        if (facts.Count == 0)
            return null;
        var min = facts.Min(x => x.NumericValue!.Value);
        var avg = facts.Average(x => x.NumericValue!.Value);
        var low = facts.Where(x => x.NumericValue < 60).ToList();
        foreach (var fact in low)
            fact.ConflictsWithDecision = true;

        return new EvidenceDecision
        {
            Field = "ocr_quality",
            Label = "Jakość OCR danych krytycznych",
            SelectedNumericValue = avg,
            Unit = "%",
            State = low.Count == 0 ? "POTWIERDZONE" : "NISKA_PEWNOSC",
            Confidence = Math.Clamp((int)Math.Round(min), 1, 99),
            SupportingSources = facts.Count - low.Count,
            ConflictingSources = low.Count,
            NeedsReview = low.Count > 0,
            Rule = "OCR_CRITICAL_THRESHOLD_9_5",
            Explanation = low.Count == 0
                ? $"Wszystkie krytyczne odczyty OCR mają co najmniej 60% pewności (minimum {min:0.#}%)."
                : $"{low.Count} dokument/dokumenty mają mniej niż 60% pewności danych krytycznych (minimum {min:0.#}%).",
            NextAction = low.Count > 0
                ? "Powtórz tylko wskazane strony OCR z innym przygotowaniem obrazu albo potwierdź dane w pliku wektorowym."
                : "",
            SourceFiles = facts.Select(x => x.SourceFile).Distinct(StringComparer.OrdinalIgnoreCase).ToList()
        };
    }

    private static List<EvidenceRouteDecision> BuildRoutes(
        IReadOnlyList<ProjectDocument> documents,
        IReadOnlyList<GeometrySummary> geometries,
        IReadOnlyList<DrawingIntelligence> drawings,
        IReadOnlyList<DxfSignals> dxfs)
    {
        var routes = new List<EvidenceRouteDecision>();
        var canonicalByHash = documents
            .Where(x => !string.IsNullOrWhiteSpace(x.ContentHash))
            .GroupBy(x => x.ContentHash, StringComparer.OrdinalIgnoreCase)
            .Where(x => x.Count() > 1)
            .ToDictionary(
                x => x.Key,
                x => x.OrderBy(d => d.IsContentDuplicate)
                    .ThenBy(d => d.RelativePath.Count(c => c is '/' or '\\'))
                    .ThenBy(d => d.RelativePath, StringComparer.OrdinalIgnoreCase)
                    .First().Name,
                StringComparer.OrdinalIgnoreCase);
        foreach (var document in documents)
        {
            var status = document.Status ?? "";
            var summaryText = document.Summary ?? "";
            var drawing = drawings.FirstOrDefault(x => SameSource(x.SourceFile, document.Name));
            var dxf = dxfs.FirstOrDefault(x => SameSource(x.SourceFile, document.Name));
            var geometry = geometries.FirstOrDefault(x => x.Parts.Any(p => SameSource(p.SourceFile, document.Name)));
            var warnings = string.Join(" | ",
                drawing?.Warnings ?? new List<string>()) + " | " +
                string.Join(" | ", dxf?.Warnings ?? new List<string>()) + " | " +
                string.Join(" | ", geometry?.Warnings ?? new List<string>());
            var fromCache = warnings.Contains("cache:", StringComparison.OrdinalIgnoreCase) ||
                            summaryText.Contains("cache", StringComparison.OrdinalIgnoreCase);
            var duplicateOf = document.ContentDuplicateOf;
            if (string.IsNullOrWhiteSpace(duplicateOf) &&
                !string.IsNullOrWhiteSpace(document.ContentHash) &&
                canonicalByHash.TryGetValue(document.ContentHash, out var canonicalName) &&
                !string.Equals(canonicalName, document.Name, StringComparison.OrdinalIgnoreCase))
                duplicateOf = canonicalName;
            var route = new EvidenceRouteDecision
            {
                SourceFile = document.Name,
                DocumentKind = document.Kind.ToString(),
                FromCache = fromCache,
                IndependentEvidence = string.IsNullOrWhiteSpace(duplicateOf),
                Outcome = string.IsNullOrWhiteSpace(summaryText)
                    ? status
                    : $"{status}: {summaryText}"
            };

            var sourceGuardSkipped = status.StartsWith("Pominięto — brak danych technicznych", StringComparison.OrdinalIgnoreCase) &&
                                     DocumentSelectionPolicy.ShouldSkipTechnicalAnalysis(document);
            if (sourceGuardSkipped)
            {
                route.Strategy = "SOURCE GUARD → POMIŃ";
                route.Engine = "Source Selection Policy";
                route.Priority = 5;
                route.Expensive = false;
                route.Reason = $"{document.RoleDisplay}: {document.RoleReason}. Zatrzymano przed analizatorem specjalistycznym.";
            }
            else switch (document.Kind)
            {
                case DocumentKind.Excel:
                case DocumentKind.Text:
                    route.Strategy = "STRUKTURA → TEKST → BOM";
                    route.Engine = "Tabular/Office Analyzer";
                    route.Priority = 10;
                    route.Reason = "Tanie źródło ilości, materiału i masy uruchamiane przed ciężką geometrią.";
                    break;
                case DocumentKind.Dxf:
                    route.Strategy = "GEOMETRIA 2D → WARSTWY → TEKST";
                    route.Engine = "DXF Analyzer";
                    route.Priority = 12;
                    route.Reason = "Wektorowa geometria ma pierwszeństwo przed OCR rastra tej samej rodziny.";
                    break;
                case DocumentKind.Dwg:
                    route.Strategy = "DWG → DXF → GEOMETRIA/TEKST";
                    route.Engine = "ACadSharp + DXF Analyzer";
                    route.Priority = 13;
                    route.Expensive = true;
                    route.Reason = "Konwersja zachowuje lokalny/offline przebieg i umożliwia wspólną analizę 2D.";
                    break;
                case DocumentKind.Pdf:
                    route.Strategy = drawing is not null &&
                                     drawing.Findings.Any(x => x.Contains("pominięto kosztowny OCR", StringComparison.OrdinalIgnoreCase))
                        ? "TEKST PDF + BOGATSZY DXF; OCR POMINIĘTY"
                        : "TEKST WEKTOROWY → OCR CELOWY → CROSS-CHECK";
                    route.Engine = "PDF Analyzer + Tesseract";
                    route.Priority = 20;
                    route.Expensive = drawing is not null &&
                                      !string.IsNullOrWhiteSpace(drawing.OcrLanguagesUsed);
                    route.Reason = "OCR jest fallbackiem, a nie obowiązkowym przetwarzaniem każdej strony.";
                    break;
                case DocumentKind.Image:
                    route.Strategy = status.StartsWith("Pominię", StringComparison.OrdinalIgnoreCase)
                        ? "BOGATSZE ŹRÓDŁO → RASTER POMINIĘTY"
                        : "NORMALIZACJA → OCR → CROSS-CHECK";
                    route.Engine = "Image Analyzer + Tesseract";
                    route.Priority = 22;
                    route.Expensive = !status.StartsWith("Pominię", StringComparison.OrdinalIgnoreCase);
                    route.Reason = "Raster jest analizowany tylko wtedy, gdy PDF/DXF nie dostarcza wystarczających danych.";
                    break;
                case DocumentKind.Step:
                    route.Strategy = document.SizeBytes >= 8L * 1024 * 1024
                        ? "PRESCAN → FULL → CHECKPOINT/WATCHDOG FALLBACK"
                        : "FULL → CORE FALLBACK";
                    route.Engine = "OpenCascade/OCP STEP Analyzer";
                    route.Priority = 30;
                    route.Expensive = true;
                    route.Reason = document.SizeBytes >= 8L * 1024 * 1024
                        ? "Duży model otrzymuje checkpoint, aby timeout nie utracił podstawowej geometrii."
                        : "Mały model przechodzi pełną analizę cech; CORE pozostaje bezpiecznym fallbackiem.";
                    break;
                default:
                    route.Strategy = "ZACHOWAJ → POMIŃ ANALIZĘ";
                    route.Engine = "Brak analizatora";
                    route.Priority = 90;
                    route.Reason = "Format pozostaje w paczce i raporcie, ale nie wpływa po cichu na wycenę.";
                    break;
            }

            if (document.ExcludeFromAnalysis || !document.IsActiveRevision)
            {
                route.Strategy = "POMIŃ ZGODNIE Z REWIZJĄ/USTAWIENIEM";
                route.Priority = 95;
                route.Expensive = false;
                route.Reason = document.ExcludeFromAnalysis
                    ? "Operator wyłączył dokument z analizy."
                    : "Nowsza rewizja tej rodziny została wybrana automatycznie.";
            }

            if (!route.IndependentEvidence)
                route.Reason = JoinNote(route.Reason,
                    $"Treść jest identyczna z {duplicateOf}; plik pozostaje widoczny, ale nie stanowi drugiego niezależnego dowodu.");

            if (document.IsStatusError || status.Contains("Timeout", StringComparison.OrdinalIgnoreCase))
                route.NextAction = $"Sprawdź {document.Name}; uruchomienie zakończyło się błędem/timeoutem, ale pozostałe pliki mogą zachować wynik.";
            else if (document.IsStatusWarning && !status.StartsWith("Pominię", StringComparison.OrdinalIgnoreCase) &&
                     !status.StartsWith("Starsza", StringComparison.OrdinalIgnoreCase))
                route.NextAction = $"Przejrzyj ostrzeżenie analizatora dla {document.Name}.";

            routes.Add(route);
        }
        return routes;
    }

    private static void AddOptionalDecision(EvidenceOrchestrationSummary summary, EvidenceDecision? decision)
    {
        if (decision is null)
            return;
        if (decision.State == "BRAK_DANYCH" && decision.SourceFiles.Count == 0 && string.IsNullOrWhiteSpace(decision.SelectedValue))
            return;
        summary.Decisions.Add(decision);
    }

    private static void AddText(
        EvidenceOrchestrationSummary summary,
        string field,
        string label,
        string? value,
        string sourceFile,
        string sourceKind,
        string method,
        string scope,
        int confidence,
        string note = "")
    {
        if (string.IsNullOrWhiteSpace(value))
            return;
        summary.Facts.Add(new EvidenceFact
        {
            Field = field,
            Label = label,
            Value = value.Trim(),
            SourceFile = SourceName(sourceFile),
            SourceKind = sourceKind,
            Method = method,
            Scope = Scope(scope),
            Confidence = Math.Clamp(confidence, 0, 100),
            Note = note
        });
    }

    private static void AddNumber(
        EvidenceOrchestrationSummary summary,
        string field,
        string label,
        double value,
        string unit,
        string sourceFile,
        string sourceKind,
        string method,
        string scope,
        int confidence,
        string note = "",
        string displayValue = "")
    {
        if (!double.IsFinite(value) || value <= 0)
            return;
        summary.Facts.Add(new EvidenceFact
        {
            Field = field,
            Label = label,
            Value = displayValue,
            NumericValue = value,
            Unit = unit,
            SourceFile = SourceName(sourceFile),
            SourceKind = sourceKind,
            Method = method,
            Scope = Scope(scope),
            Confidence = Math.Clamp(confidence, 0, 100),
            Note = note
        });
    }

    private static string FactIdentity(EvidenceFact fact)
    {
        var numeric = fact.NumericValue?.ToString("0.######", CultureInfo.InvariantCulture) ?? "";
        return $"{fact.Field}|{VoteIdentity(fact)}|{fact.Scope}|{NormalizeText(fact.Value)}|{numeric}|{fact.Unit}";
    }

    private static int IndependentSourceCount(IEnumerable<EvidenceFact> facts) => facts
        .Select(VoteIdentity)
        .Distinct(StringComparer.OrdinalIgnoreCase)
        .Count();

    private static string VoteIdentity(EvidenceFact fact) =>
        string.IsNullOrWhiteSpace(fact.SourceIdentity)
            ? $"{fact.SourceKind}|{fact.SourceFile}"
            : fact.SourceIdentity;

    private static Dictionary<string, string> BuildSourceIdentityMap(IReadOnlyList<ProjectDocument> documents)
    {
        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var document in documents)
        {
            var identity = string.IsNullOrWhiteSpace(document.ContentHash)
                ? $"FILE:{document.Name.ToUpperInvariant()}"
                : $"SHA256:{document.ContentHash.ToUpperInvariant()}";
            foreach (var key in new[]
                     {
                         document.Name,
                         Path.GetFileName(document.Name),
                         Path.GetFileName(document.RelativePath)
                     }.Where(x => !string.IsNullOrWhiteSpace(x)))
                map.TryAdd(key, identity);
        }
        return map;
    }

    private static string ResolveSourceIdentity(
        string sourceFile,
        IReadOnlyDictionary<string, string> sourceIdentityMap)
    {
        if (sourceIdentityMap.TryGetValue(sourceFile, out var identity) ||
            sourceIdentityMap.TryGetValue(Path.GetFileName(sourceFile), out identity))
            return identity;
        return $"SOURCE:{sourceFile.ToUpperInvariant()}";
    }

    private static List<EvidenceContentDuplicate> BuildContentDuplicates(IReadOnlyList<ProjectDocument> documents)
    {
        return documents
            .Where(x => !string.IsNullOrWhiteSpace(x.ContentHash))
            .GroupBy(x => x.ContentHash, StringComparer.OrdinalIgnoreCase)
            .Where(x => x.Select(d => d.Name).Distinct(StringComparer.OrdinalIgnoreCase).Count() > 1)
            .Select(group =>
            {
                var ordered = group
                    .OrderBy(x => x.IsContentDuplicate)
                    .ThenBy(x => x.RelativePath.Count(c => c is '/' or '\\'))
                    .ThenBy(x => x.RelativePath, StringComparer.OrdinalIgnoreCase)
                    .ToList();
                return new EvidenceContentDuplicate
                {
                    ContentHashPrefix = group.Key.Length > 16 ? group.Key[..16] : group.Key,
                    CanonicalSource = ordered[0].Name,
                    Files = ordered.Select(x => x.Name).Distinct(StringComparer.OrdinalIgnoreCase).ToList()
                };
            })
            .OrderBy(x => x.CanonicalSource, StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    private static string SourceName(string? value) =>
        string.IsNullOrWhiteSpace(value) ? "(źródło zbiorcze)" : Path.GetFileName(value.Trim());

    private static string SourceKind(string? file)
    {
        var ext = Path.GetExtension(file ?? "").ToLowerInvariant();
        return ext switch
        {
            ".step" or ".stp" => "STEP",
            ".dxf" => "DXF",
            ".dwg" => "DWG",
            ".pdf" => "PDF",
            ".png" or ".jpg" or ".jpeg" or ".bmp" or ".tif" or ".tiff" => "Raster",
            ".xlsx" or ".xls" or ".xlsm" or ".csv" or ".bom" => "BOM",
            ".doc" or ".docx" or ".rtf" or ".txt" => "Dokument",
            _ => "Dokument"
        };
    }

    private static string SemanticMethod(DrawingIntelligence drawing)
    {
        if (!string.IsNullOrWhiteSpace(drawing.OcrLanguagesUsed) || drawing.OcrCriticalConfidence.HasValue)
            return "Parser dokumentu + OCR/cross-check";
        if (SourceKind(drawing.SourceFile) == "BOM")
            return "Parser tabelaryczny";
        return "Parser tekstu/wektora";
    }

    private static int SemanticConfidence(DrawingIntelligence drawing, int fallback)
    {
        if (drawing.OcrCriticalConfidence.HasValue)
            return Math.Clamp((int)Math.Round(drawing.OcrCriticalConfidence.Value), 35, 96);
        if (SourceKind(drawing.SourceFile) == "BOM")
            return 90;
        return Math.Clamp(fallback, 35, 95);
    }

    private static string PaintLayerNote(IEnumerable<PaintLayerSignal> layers)
    {
        var values = layers.Where(x => x.DftMicron > 0)
            .Select(x => $"{Math.Max(1, x.CoatCount)}×{x.DftMicron:0.#} µm{(string.IsNullOrWhiteSpace(x.Name) ? "" : $" {x.Name}")}")
            .Take(8).ToList();
        return values.Count == 0 ? "" : string.Join(" + ", values);
    }

    private static string Scope(string? value) => string.IsNullOrWhiteSpace(value)
        ? "UNKNOWN"
        : value.Trim().ToUpperInvariant();

    private static string Known(string? value)
    {
        if (string.IsNullOrWhiteSpace(value) ||
            value.Contains("nie rozpoznano", StringComparison.OrdinalIgnoreCase) ||
            value == "—")
            return "";
        return value.Trim();
    }

    private static string NormalizeText(string? value) => Regex.Replace(
        (value ?? "").ToUpperInvariant(), @"[^A-Z0-9+]", "");

    private static bool MaterialsCompatible(string left, string right)
    {
        var a = NormalizeText(left);
        var b = NormalizeText(right);
        if (a == b || a.Contains(b, StringComparison.Ordinal) || b.Contains(a, StringComparison.Ordinal))
            return true;
        var familyA = Regex.Match(a, @"S\d{3}").Value;
        var familyB = Regex.Match(b, @"S\d{3}").Value;
        return familyA.Length > 0 && familyA == familyB;
    }

    private static double EquivalentWeldThroat(double value, string? kind) =>
        string.Equals((kind ?? "").Trim(), "z", StringComparison.OrdinalIgnoreCase)
            ? value / Math.Sqrt(2.0)
            : value;

    private static double RelativeDifference(double left, double right) =>
        Math.Abs(left - right) / Math.Max(Math.Abs(right), 0.000001);

    private static bool IsDecimalScaleOutlier(double candidate, double reference)
    {
        if (candidate <= 0 || reference <= 0)
            return false;
        var ratio = candidate / reference;
        foreach (var scale in new[] { 0.01, 0.1, 10.0, 100.0 })
            if (Math.Abs(ratio - scale) / scale <= 0.035)
                return true;
        return false;
    }

    private static string JoinNote(string first, string second) =>
        string.IsNullOrWhiteSpace(first) ? second : $"{first} {second}";

    private static bool SameSource(string? left, string? right)
    {
        if (string.IsNullOrWhiteSpace(left) || string.IsNullOrWhiteSpace(right))
            return false;
        return string.Equals(Path.GetFileName(left), Path.GetFileName(right), StringComparison.OrdinalIgnoreCase) ||
               string.Equals(Path.GetFileNameWithoutExtension(left), Path.GetFileNameWithoutExtension(right), StringComparison.OrdinalIgnoreCase);
    }
}
