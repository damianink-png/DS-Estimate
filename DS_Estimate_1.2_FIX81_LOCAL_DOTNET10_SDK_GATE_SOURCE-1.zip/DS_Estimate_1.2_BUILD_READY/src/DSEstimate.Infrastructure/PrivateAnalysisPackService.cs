using System.Text.Json;

namespace DSEstimate.Infrastructure;

public sealed class PrivateAnalysisPackService
{
    private readonly PythonRunner _python = new();

    public async Task<(bool Ok, string Message)> BuildAsync(string sourceFolder, string outputZip, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(sourceFolder) || !Directory.Exists(sourceFolder))
            return (false, "Wybrany folder nie istnieje.");
        if (string.IsNullOrWhiteSpace(outputZip))
            return (false, "Nie wybrano pliku wyjściowego.");

        var payload = JsonSerializer.Serialize(new { source = sourceFolder, output = outputZip });
        var run = await _python.RunAsync(
            "build_private_analysis_pack.py",
            payload,
            cancellationToken,
            executionTimeout: TimeSpan.FromHours(2));

        if (!run.Ok)
            return (false, string.IsNullOrWhiteSpace(run.Stderr) ? "Nie udało się utworzyć pakietu." : run.Stderr.Trim());

        return (true, "Utworzono prywatny pakiet diagnostyczny bez oryginalnych plików źródłowych. Przed udostępnieniem przejrzyj ZIP — zredagowane dane techniczne nadal mogą być poufne.");
    }
}
