using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

/// <summary>
/// FIX30: conservative diagnostic cross-document association. A STEP filename
/// matching a verified, unique PDF drawing↔BOM identifier is NOT geometric
/// verification. This resolver never changes material, quantities or costs.
/// </summary>
public static class DrawingStepEvidenceResolver
{
    public sealed class Resolution
    {
        public List<DrawingStepLink> Links { get; } = [];
        public List<string> AmbiguousIdentifiers { get; } = [];
    }

    // FIX32: a zero-byte placeholder cannot be a usable STEP source. File size
    // is only a cheap validity guard, never evidence of geometric identity.
    // A file may disappear between import and resolution: fail closed.
    private static bool HasNonEmptyFile(string path)
    {
        try
        {
            var file = new FileInfo(path);
            return file.Exists && file.Length > 0;
        }
        catch (IOException) { return false; }
        catch (UnauthorizedAccessException) { return false; }
        catch (ArgumentException) { return false; }
        catch (NotSupportedException) { return false; }
    }

    public static Resolution Resolve(
        IEnumerable<DrawingBomLink> pdfBomLinks,
        IEnumerable<ProjectDocument> activeDocuments)
    {
        var result = new Resolution();
        // Do not normalize separators or strip revision suffixes: e.g.
        // PART-001 and PART_001 or PART-001-A may be different parts.
        static string Key(string? value) => (value ?? "").Trim().ToUpperInvariant();

        var pdfById = pdfBomLinks
            .Where(x => x.MatchType == "exact-within-pdf" &&
                        !string.IsNullOrWhiteSpace(x.SourceFile) &&
                        !string.IsNullOrWhiteSpace(x.DrawingNumber) &&
                        Key(x.DrawingNumber) == Key(x.BomPartNumber) &&
                        x.DrawingPageNumber > 0 && x.BomPageNumber > 0)
            .GroupBy(x => Key(x.DrawingNumber), StringComparer.Ordinal)
            .ToDictionary(x => x.Key, x => x.ToList(), StringComparer.Ordinal);

        // FIX31: the display Name is not the on-disk identity. Import may append
        // "[KONFLIKT N]" to Name, and a stale/custom Name can describe a different
        // file altogether. Use the actual existing path for both the extension
        // check and the exact filename match. Never merge duplicate physical names.
        var stepById = activeDocuments
            .Where(x => x.Kind == DocumentKind.Step && x.IsActiveRevision &&
                        !x.ExcludeFromAnalysis && !string.IsNullOrWhiteSpace(x.Path) &&
                        File.Exists(x.Path) && HasNonEmptyFile(x.Path))
            .Select(x => Path.GetFileName(x.Path))
            .Where(name => string.Equals(Path.GetExtension(name), ".step", StringComparison.OrdinalIgnoreCase) ||
                           string.Equals(Path.GetExtension(name), ".stp", StringComparison.OrdinalIgnoreCase))
            .GroupBy(name => Key(Path.GetFileNameWithoutExtension(name)), StringComparer.Ordinal)
            .ToDictionary(group => group.Key, group => group.ToList(), StringComparer.Ordinal);

        foreach (var id in pdfById.Keys.Intersect(stepById.Keys).OrderBy(x => x, StringComparer.Ordinal))
        {
            var pdfMatches = pdfById[id];
            var stepMatches = stepById[id];
            // Reused IDs across PDF files/pages, or duplicate STEP candidates,
            // must never be silently assigned to one geometry.
            if (pdfMatches.Count != 1 || stepMatches.Count != 1)
            {
                result.AmbiguousIdentifiers.Add(id);
                continue;
            }
            var pdf = pdfMatches[0];
            result.Links.Add(new DrawingStepLink
            {
                SourcePdf = pdf.SourceFile,
                DrawingNumber = pdf.DrawingNumber,
                DrawingPageNumber = pdf.DrawingPageNumber,
                BomPageNumber = pdf.BomPageNumber,
                StepFile = stepMatches[0],
                MatchType = "exact-pdf-bom-step-filename-only"
            });
        }
        return result;
    }
}
