﻿using System.Globalization;
using System.Text.RegularExpressions;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

/// <summary>
/// FIX14 Mass Reconstruction 2.0. Rebuilds mass per root-BOM family without requiring
/// one complete STEP. The resolver is deliberately conservative: a partial sum is kept
/// for a recognised material should-cost, while project mass authority is granted only
/// when root-family coverage and confidence are high.
/// </summary>
public static class HybridMassResolver
{
    private static readonly Regex ThicknessRx = new(
        @"(?ix)(?:\b(?:T|THK|THICKNESS|GR|GRUBO[ŚS]Ć|DICKE)\s*[:=]?\s*|\b(?:BL|PL|PLATE|BLECH)\s+)(?<t>\d{1,3}(?:[\.,]\d{1,2})?)\s*(?:MM)?\b",
        RegexOptions.Compiled);

    public static void Apply(
        DrawingIntelligence merged,
        GeometrySummary geometry,
        IReadOnlyList<DrawingIntelligence> drawings,
        IReadOnlyList<DxfSignals> dxfs,
        DocumentFamilyResolution resolution)
    {
        merged.HybridMassKg = null;
        merged.HybridMassConfidence = 0;
        merged.HybridMassCoveragePercent = 0;
        merged.HybridMassProjectAuthoritative = false;
        merged.HybridMassSource = "";
        merged.HybridMassContributions.Clear();

        if (!resolution.HasAuthoritativeRootBom || !resolution.ScopeEnforced)
            return;

        var targetFamilies = resolution.ProductionFamilies
            .Where(x => !string.IsNullOrWhiteSpace(x) &&
                        !x.Equals(resolution.RootEntityKey, StringComparison.OrdinalIgnoreCase))
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (targetFamilies.Count == 0)
            return;

        // An explicit root mass is stronger than reconstruction. Preserve it here so
        // the audit explains why family reconstruction was not used.
        var rootMass = drawings
            .Where(x => x.DocumentMassKg is > 0 && x.DocumentMassConfidence >= 88)
            .Where(x => DocumentFamilyResolver.ExtractEntityKey(x.SourceFile)
                .Equals(resolution.RootEntityKey, StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(x => x.DocumentMassConfidence)
            .FirstOrDefault();
        if (rootMass?.DocumentMassKg is > 0 &&
            (string.Equals(rootMass.DocumentMassScope, "ASSEMBLY_TOTAL", StringComparison.OrdinalIgnoreCase) ||
             string.Equals(rootMass.DocumentMassScope, "PROJECT_TOTAL", StringComparison.OrdinalIgnoreCase) ||
             string.Equals(rootMass.DocumentMassScope, "BOM_TOTAL", StringComparison.OrdinalIgnoreCase)))
        {
            merged.HybridMassKg = rootMass.DocumentMassKg;
            merged.HybridMassConfidence = Math.Clamp(rootMass.DocumentMassConfidence, 1, 99);
            merged.HybridMassCoveragePercent = 100;
            merged.HybridMassProjectAuthoritative = true;
            merged.HybridMassSource = "jawna masa root assembly";
            merged.HybridMassContributions.Add(new MassReconstructionContribution
            {
                FamilyKey = resolution.RootEntityKey,
                SourceKind = "DOCUMENT_TOTAL",
                MassKg = rootMass.DocumentMassKg.Value,
                Quantity = 1,
                Confidence = merged.HybridMassConfidence,
                Basis = rootMass.DocumentMassEvidence
            });
            return;
        }

        var bomByFamily = merged.BomItems
            .Select(x => new { Item = x, Key = DocumentFamilyResolver.ExtractEntityKey(x.PartNumber) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Key) && targetFamilies.Contains(x.Key))
            .GroupBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.Select(x => x.Item).ToList(), StringComparer.OrdinalIgnoreCase);

        double QuantityFor(string family)
        {
            if (!bomByFamily.TryGetValue(family, out var rows)) return 1;
            var q = rows.Select(x => NormalizeQuantity(x.Quantity)).Where(x => x > 0).DefaultIfEmpty(1).Max();
            return Math.Max(1, q);
        }

        var docsByFamily = drawings
            .Select(x => new { Item = x, Key = DocumentFamilyResolver.ExtractEntityKey(x.SourceFile) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Key) && targetFamilies.Contains(x.Key))
            .GroupBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.Select(x => x.Item).ToList(), StringComparer.OrdinalIgnoreCase);

        var stepsByFamily = geometry.Parts
            .Select(x => new { Part = x, Key = DocumentFamilyResolver.ExtractEntityKey(x.SourceFile) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Key) && targetFamilies.Contains(x.Key))
            .GroupBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.Select(x => x.Part).ToList(), StringComparer.OrdinalIgnoreCase);

        var dxfByFamily = dxfs
            .Where(x => x.GeometryMeasurementReliable && x.ClosedProfileAreaMm2 > 0)
            .Select(x => new { Item = x, Key = DocumentFamilyResolver.ExtractEntityKey(x.SourceFile) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Key) && targetFamilies.Contains(x.Key))
            .GroupBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key,
                g => g.OrderByDescending(x => x.Item.ClosedProfileAreaMm2)
                      .ThenBy(x => x.Item.OpenPathCount)
                      .First().Item,
                StringComparer.OrdinalIgnoreCase);

        foreach (var family in targetFamilies.OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
        {
            var quantity = QuantityFor(family);
            var material = MaterialFor(family, bomByFamily, docsByFamily);
            var density = DensityFor(material);

            // 1) BOM mass is strongest per-family evidence. Use one representative
            // hierarchy-safe row set instead of summing aliases blindly.
            if (bomByFamily.TryGetValue(family, out var rows))
            {
                var mass = SafeBomFamilyMass(rows, quantity);
                if (mass is > 0)
                {
                    merged.HybridMassContributions.Add(new MassReconstructionContribution
                    {
                        FamilyKey = family,
                        SourceKind = "BOM_MASS",
                        Material = material,
                        MassKg = mass.Value,
                        Quantity = quantity,
                        Confidence = 90,
                        Basis = $"jawna masa pozycji BOM / liścia hierarchii; ilość produkcyjna ×{quantity:0.###}"
                    });
                    continue;
                }
            }

            // 2) A labelled local drawing weight is good evidence for that family.
            if (docsByFamily.TryGetValue(family, out var docs))
            {
                var local = docs
                    .Where(x => x.DocumentMassKg is > 0 && x.DocumentMassConfidence >= 82)
                    .Where(x => x.DocumentMassScope is "PART" or "SUBASSEMBLY" or "UNKNOWN")
                    .OrderByDescending(x => x.DocumentMassConfidence)
                    .ThenBy(x => x.DocumentMassKg)
                    .FirstOrDefault();
                if (local?.DocumentMassKg is > 0 && local.DocumentMassKg < 25_000)
                {
                    var multiplier = string.Equals(local.DocumentMassScope, "SUBASSEMBLY", StringComparison.OrdinalIgnoreCase) ? 1 : quantity;
                    merged.HybridMassContributions.Add(new MassReconstructionContribution
                    {
                        FamilyKey = family,
                        SourceKind = "DRAWING_MASS",
                        Material = material,
                        MassKg = local.DocumentMassKg.Value * multiplier,
                        Quantity = multiplier,
                        Confidence = Math.Clamp(local.DocumentMassConfidence, 55, 95),
                        Basis = $"lokalna masa z {local.SourceFile}; scope {local.DocumentMassScope}; mnożnik ×{multiplier:0.###}"
                    });
                    continue;
                }
            }

            // 3) Exact local STEP volume. This remains local even if the overall STEP
            // package covers only a few root-BOM families.
            if (stepsByFamily.TryGetValue(family, out var parts) && parts.Count > 0)
            {
                var nativeQty = Math.Max(1, parts.Sum(x => Math.Max(1, x.Quantity)));
                var multiplier = nativeQty <= 1.0001 ? Math.Max(1, quantity) : 1;
                var mass = parts.Sum(x => Math.Max(0, x.VolumeMm3Each) * Math.Max(1, x.Quantity)) * 1e-9 * density * multiplier;
                if (mass is > 0.001 and < 100_000)
                {
                    merged.HybridMassContributions.Add(new MassReconstructionContribution
                    {
                        FamilyKey = family,
                        SourceKind = "STEP_LOCAL",
                        Material = material,
                        MassKg = mass,
                        Quantity = Math.Max(nativeQty, quantity),
                        Confidence = string.IsNullOrWhiteSpace(material) ? 78 : 90,
                        Basis = $"lokalny wolumen STEP × gęstość {density:0} kg/m³; mnożnik BOM ×{multiplier:0.###}"
                    });
                    continue;
                }
            }

            // 4) Flat part from DXF + trustworthy thickness. This works when the
            // customer sends 2D manufacturing geometry but no STEP at all.
            if (dxfByFamily.TryGetValue(family, out var dxf))
            {
                var thickness = InferThicknessMm(family, bomByFamily, stepsByFamily);
                if (thickness is > 0.1 and <= 250 && dxf.ClosedProfileAreaMm2 > 0)
                {
                    var mass = dxf.ClosedProfileAreaMm2 * thickness.Value * 1e-9 * density * quantity;
                    if (mass is > 0.001 and < 100_000)
                    {
                        var openRatio = dxf.OpenPathCount / (double)Math.Max(1, dxf.ClosedProfileCount);
                        var confidence = openRatio > 8 ? 62 : 76;
                        merged.HybridMassContributions.Add(new MassReconstructionContribution
                        {
                            FamilyKey = family,
                            SourceKind = "DXF_AREA_THICKNESS",
                            Material = material,
                            MassKg = mass,
                            Quantity = quantity,
                            ThicknessMm = thickness,
                            Confidence = confidence,
                            Basis = $"pole zamkniętych konturów DXF × t={thickness.Value:0.###} mm × ρ={density:0} × {quantity:0.###} szt.; otwarte/closed={openRatio:0.##}"
                        });
                    }
                }
            }
        }

        var contributions = merged.HybridMassContributions.Where(x => x.MassKg > 0.001).ToList();
        if (contributions.Count == 0)
            return;

        var covered = contributions.Select(x => x.FamilyKey).Distinct(StringComparer.OrdinalIgnoreCase).Count();
        var coverage = 100.0 * covered / Math.Max(1, targetFamilies.Count);
        var total = contributions.Sum(x => x.MassKg);
        var weightedConfidence = (int)Math.Round(contributions.Sum(x => x.MassKg * x.Confidence) / Math.Max(0.001, total));
        if (coverage < 75) weightedConfidence = Math.Min(weightedConfidence, 68);
        else if (coverage < 90) weightedConfidence = Math.Min(weightedConfidence, 76);

        // Do not allow one huge OCR/BOM artefact to dominate a reconstructed assembly.
        var maxShare = contributions.Max(x => x.MassKg) / Math.Max(total, 0.001);
        if (maxShare > 0.97 && contributions.Count >= 5)
            weightedConfidence = Math.Min(weightedConfidence, 62);

        merged.HybridMassKg = total;
        merged.HybridMassCoveragePercent = coverage;
        merged.HybridMassConfidence = Math.Clamp(weightedConfidence, 25, 96);
        merged.HybridMassProjectAuthoritative = coverage >= 90 && merged.HybridMassConfidence >= 75 && maxShare < 0.97;
        merged.HybridMassSource = merged.HybridMassProjectAuthoritative
            ? "rekonstrukcja per rodzina BOM"
            : "częściowa rekonstrukcja per rodzina BOM";

        merged.Findings.Add(
            $"FIX14 Mass Reconstruction: {total:0.###} kg z {covered}/{targetFamilies.Count} rodzin ({coverage:0.#}%); " +
            $"pewność {merged.HybridMassConfidence}%; authority={(merged.HybridMassProjectAuthoritative ? "PROJECT" : "PARTIAL_ONLY")}.");

        if (!merged.HybridMassProjectAuthoritative)
            merged.Warnings.Add(
                $"FIX14: rozpoznano częściową masę {total:0.###} kg ({coverage:0.#}% rodzin). Może zasilać koszt rozpoznanego materiału, ale nie odblokowuje pełnej ceny ofertowej.");
    }

    private static double? SafeBomFamilyMass(List<BomItemSignal> rows, double familyQuantity)
    {
        var candidates = rows
            .Select(x => new
            {
                Item = x,
                Total = x.TotalMassKg is > 0 ? x.TotalMassKg.Value : 0,
                Each = x.MassKgEach is > 0 ? x.MassKgEach.Value : 0,
                Q = NormalizeQuantity(x.Quantity)
            })
            .Where(x => (x.Total > 0 || x.Each > 0) && Math.Max(x.Total, x.Each) < 25_000)
            .ToList();
        if (candidates.Count == 0) return null;

        // Prefer explicit total mass from the most specific/deepest row. If only
        // unit mass exists, multiply by the authoritative family quantity once.
        var totalRows = candidates.Where(x => x.Total > 0).OrderByDescending(x => x.Item.Level).ToList();
        if (totalRows.Count > 0)
        {
            var values = totalRows.Select(x => x.Total).OrderBy(x => x).ToList();
            return values[values.Count / 2];
        }

        var eachValues = candidates.Where(x => x.Each > 0).Select(x => x.Each).OrderBy(x => x).ToList();
        if (eachValues.Count == 0) return null;
        return eachValues[eachValues.Count / 2] * Math.Max(1, familyQuantity);
    }

    private static string MaterialFor(
        string family,
        IReadOnlyDictionary<string, List<BomItemSignal>> bomByFamily,
        IReadOnlyDictionary<string, List<DrawingIntelligence>> docsByFamily)
    {
        var values = new List<string>();
        if (bomByFamily.TryGetValue(family, out var rows))
            values.AddRange(rows.Select(x => x.Material));
        if (docsByFamily.TryGetValue(family, out var docs))
            values.AddRange(docs.Select(x => x.MaterialHint));
        return values.Where(x => !string.IsNullOrWhiteSpace(x))
            .GroupBy(x => x.Trim(), StringComparer.OrdinalIgnoreCase)
            .OrderByDescending(g => g.Count())
            .ThenByDescending(g => g.Key.Length)
            .Select(g => g.Key)
            .FirstOrDefault() ?? "";
    }

    private static double DensityFor(string material)
    {
        var m = (material ?? "").ToUpperInvariant();
        if (m.Contains("EN AW") || m.Contains("ALUMIN")) return 2700;
        if (m.Contains("1.4301") || m.Contains("1.4404") || m.Contains("AISI 304") || m.Contains("AISI 316")) return 7950;
        return 7850;
    }

    private static double? InferThicknessMm(
        string family,
        IReadOnlyDictionary<string, List<BomItemSignal>> bomByFamily,
        IReadOnlyDictionary<string, List<PartGroup>> stepByFamily)
    {
        if (stepByFamily.TryGetValue(family, out var parts))
        {
            var values = parts
                .Where(x => x.Classification.Contains("Blacha", StringComparison.OrdinalIgnoreCase) ||
                            x.Classification.Contains("płyta", StringComparison.OrdinalIgnoreCase))
                .Select(x => new[] { x.Xmm, x.Ymm, x.Zmm }.Where(v => v > 0.05).DefaultIfEmpty(0).Min())
                .Where(x => x is > 0.1 and <= 250)
                .OrderBy(x => x)
                .ToList();
            if (values.Count > 0) return values[values.Count / 2];
        }

        if (!bomByFamily.TryGetValue(family, out var rows)) return null;
        foreach (var text in rows.Select(x => $"{x.PartNumber} {x.Description}"))
        {
            var match = ThicknessRx.Match(text);
            if (!match.Success) continue;
            var raw = match.Groups["t"].Value.Replace(',', '.');
            if (double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out var t) && t is > 0.1 and <= 250)
                return t;
        }
        return null;
    }

    private static double NormalizeQuantity(double q)
    {
        if (!double.IsFinite(q) || q <= 0) return 1;
        if (q > 100 && Math.Abs(q - Math.Round(q)) > 0.001) return 1;
        return Math.Clamp(q, 1, 10_000);
    }
}
