using System.Globalization;
using System.Text;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

public sealed class DiagnosticReportService
{
    public void Export(QuoteProject project, CostingSettings settings, string path)
    {
        var sb = new StringBuilder();
        var a = project.Analysis;

        Line(sb, "DS ESTIMATE - RAPORT DIAGNOSTYCZNY");
        Line(sb, "================================");
        Line(sb, "Wersja raportu: DS Estimate 1.2 MINIMAL UI");
        Line(sb, "Warstwa audytowa: FIX12A SHADOW / DUAL-RUN");
        Line(sb, "Patch: FIX18 RELEASE SAFETY + SNAPSHOT + ENGINE HEALTH + GROUPED CALIBRATION + STEP JOB LIMIT / FIX17 BUILD RESUME + RUNTIME HEALTH + HOLDOUT VALIDATION + QUOTE READINESS / FIX16E STEP WORKER SHUTDOWN FIX / FIX16D NATIVE TEST SHUTDOWN FIX / FIX16C EMBEDDED PYTHON EXIT FIX / FIX16B COMPILE FIX / FIX16A RELIABILITY HARDENING / FIX16 DECISION SUPPORT");
        Line(sb, $"Hash silnika STEP: {EngineResultCache.VersionForScript("step-v1", "analyze_step.py")}");
        Line(sb, $"Hash silników dokumentów: {EngineResultCache.VersionForScripts("document-v1", "analyze_document.py", "analyze_dxf.py", "analyze_tabular.py")}");
        Line(sb, $"Data raportu: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        Line(sb, "");

        Section(sb, "PROJEKT");
        Line(sb, $"ID: {project.Id}");
        Line(sb, $"Rewizja: {project.Revision}");
        Line(sb, $"Nazwa: {project.Name}");
        Line(sb, $"Klient / producent: {project.Customer}");
        Line(sb, $"Utworzono: {project.CreatedAt:yyyy-MM-dd HH:mm:ss}");
        Line(sb, $"Zmodyfikowano: {project.ModifiedAt:yyyy-MM-dd HH:mm:ss}");
        Line(sb, $"Masa ręczna: {Fmt(project.ManualWeightKg)} kg");
        Line(sb, $"FIX13A ręczne override procesów: {project.ProcessOverrides?.Values.Count(x => x.HasAny) ?? 0}");
        if (project.ProcessOverrides?.Values.Any(x => x.HasAny) == true)
            Line(sb, "  " + string.Join(" | ", project.ProcessOverrides.Values.Where(x => x.HasAny).OrderBy(x => x.Code).Select(x =>
                $"{x.Code}:" +
                (x.OverrideEnabled ? $" ON={(x.Enabled ? "TAK" : "NIE")}" : "") +
                (x.OverrideHours ? $" {x.Hours:0.###}h" : "") +
                (x.OverrideRate ? $" {x.RatePlnPerHour:0.##}PLN/h" : ""))));
        if (project.ResumeState?.WasInterrupted == true || project.ResumeState?.InProgress == true)
            Line(sb, $"FIX13A checkpoint: poprzednia analiza przerwana/w toku; ukończone pliki {project.ResumeState.CompletedDocumentCount}; cache analizatorów może zostać użyty przy kolejnym LICZ.");
        Line(sb, $"FIX18 wyjątek wydania: {(project.ReleaseOverride?.Granted == true ? "ZAPISANY" : "NIE")}");
        if (project.ReleaseOverride?.Granted == true)
        {
            Line(sb, $"  Zatwierdził: {project.ReleaseOverride.ApprovedBy} · {project.ReleaseOverride.ApprovedAt:yyyy-MM-dd HH:mm:ss}");
            Line(sb, $"  Powód: {project.ReleaseOverride.Reason}");
            Line(sb, $"  Odcisk zatwierdzenia: {project.ReleaseOverride.ApprovedFingerprint}");
        }
        if (project.FrozenSnapshot is not null)
        {
            Line(sb, $"FIX18 zamrożony snapshot: {project.FrozenSnapshot.Summary}");
            Line(sb, $"  Analiza: {project.FrozenSnapshot.AnalysisHash}");
            Line(sb, $"  Ustawienia: {project.FrozenSnapshot.SettingsHash}");
            Line(sb, $"  Kalibracja: {project.FrozenSnapshot.CalibrationHash}");
            Line(sb, $"  Silniki: {project.FrozenSnapshot.EngineHash}");
            Line(sb, $"  Audyt wydania: {project.FrozenSnapshot.ReleaseAuditHash}");
            foreach (var hash in project.FrozenSnapshot.DocumentHashes.OrderBy(x => x.Key, StringComparer.OrdinalIgnoreCase))
                Line(sb, $"  Dokument: {hash.Key} · {hash.Value}");
        }
        Line(sb, "");

        Section(sb, "FIX18 STAN SILNIKÓW LOKALNYCH");
        var engineHealth = new EngineHealthService().Capture();
        Line(sb, engineHealth.Summary);
        foreach (var engine in engineHealth.Items)
            Line(sb, $"- {engine.Display}");
        var goldenSet = new FirmGoldenSetService();
        var goldenSetReport = goldenSet.LoadAndEvaluate(FirmGoldenSetService.FindDefaultPath() ?? "");
        Line(sb, goldenSetReport.Summary);
        Line(sb, "");

        if (project.HistoryImport is not null)
        {
            var h = project.HistoryImport;
            Section(sb, "IMPORT HISTORII / METRYKA");
            Line(sb, $"Folder źródłowy: {h.SourceFolder}");
            Line(sb, $"Metryka: {h.MetricWorkbook}");
            Line(sb, $"Nr rysunku: {h.DrawingNumber}");
            Line(sb, $"Arkusze metryki: {h.MetricSheetCount}");
            Line(sb, $"Agregacja arkuszy: {h.MetricAggregationBasis}");
            Line(sb, $"CNC 3201 ciężka / duża: {h.CncHeavyHours:0.###} h");
            Line(sb, $"CNC 3202 średnia: {h.CncMediumHours:0.###} h");
            Line(sb, $"CNC 3203 lekka / mała: {h.CncLightHours:0.###} h");
            Line(sb, $"CNC 3205 operacje ręczne: {h.CncManualHours:0.###} h");
            Line(sb, $"Model CNC split małe/średnie/duże: {h.ModelCncSmallHours:0.###} / {h.ModelCncMediumHours:0.###} / {h.ModelCncLargeHours:0.###} h");
            Line(sb, $"3401 montaż + spawanie: {h.CombinedWeldAssemblyHours:0.###} h");
            Line(sb, $"3403 spawanie zrobotyzowane: {h.RobotWeldingHours:0.###} h (poza kalibracją WELD)");
            Line(sb, $"Historyczny koszt materiału: {Fmt(h.HistoricalMaterialCostPln)} PLN");
            Line(sb, $"Historyczny koszt całkowity: {Fmt(h.HistoricalTotalCostPln)} PLN");
            Line(sb, $"Historyczna cena: {Fmt(h.HistoricalPricePln)} PLN");
            Line(sb, $"Podział 3401: {h.SplitBasis}");
            Line(sb, "");
        }

        Section(sb, "DOKUMENTY");
        if (project.Documents.Count == 0)
        {
            Line(sb, "(brak)");
        }
        else
        {
            foreach (var d in project.Documents)
            {
                Line(sb, $"- {d.Name}");
                Line(sb, $"  Typ: {d.Kind}");
            Line(sb, $"  Źródło paczki: {d.PackageSource}");
            Line(sb, $"  Ścieżka względna: {d.RelativePath}");
            Line(sb, $"  Klasyfikacja 1.0: {d.RoleDisplay} · pewność {d.RoleConfidence}%" +
                     (string.IsNullOrWhiteSpace(d.RoleReason) ? "" : $" · {d.RoleReason}"));
            if (!string.IsNullOrWhiteSpace(d.ProjectGroupKey))
                Line(sb, $"  Podwycena / grupa: {d.ProjectGroupKey}");
            if (!string.IsNullOrWhiteSpace(d.ContentHash))
                Line(sb, $"  SHA-256 treści: {(d.ContentHash.Length > 16 ? d.ContentHash[..16] : d.ContentHash)}…");
            if (!string.IsNullOrWhiteSpace(d.ContentDuplicateOf))
                Line(sb, $"  Duplikat treści: TAK · źródło kanoniczne: {d.ContentDuplicateOf}");
                Line(sb, $"  Aktywna rewizja: {(d.IsActiveRevision ? "TAK" : "NIE")}");
                Line(sb, $"  Wyłączony z analizy: {(d.ExcludeFromAnalysis ? "TAK" : "NIE")}");
                Line(sb, $"  Rozmiar: {d.SizeBytes} B");
                Line(sb, $"  Status: {d.Status}");
                Line(sb, $"  Podsumowanie: {d.Summary}");
            }
        }
        Line(sb, "");

        if (a is null)
        {
            Section(sb, "ANALIZA");
            Line(sb, "Brak wyniku analizy.");
            File.WriteAllText(path, sb.ToString(), new UTF8Encoding(true));
            return;
        }

        Section(sb, "PODSUMOWANIE ANALIZY");
        Line(sb, $"Analiza wykonana: {a.AnalyzedAt:yyyy-MM-dd HH:mm:ss}");
        Line(sb, $"Gotowość: {a.ReadinessPercent}%");
        Line(sb, $"Pewność: {a.ConfidencePercent}%");
        Line(sb, $"Materiał: {a.Material}");
        Line(sb, $"Gęstość: {a.DensityKgM3:0.###} kg/m3");
        Line(sb, $"Gęstość zastępcza: {(a.DensityAssumed ? "TAK" : "NIE")}");
        Line(sb, $"Masa wynikowa: {Fmt(a.WeightKg)} kg");
        Line(sb, $"Źródło masy: {(string.IsNullOrWhiteSpace(a.WeightSource) ? "—" : a.WeightSource)}");
        if (a.Drawing.BomTotalMassKg is > 0)
            Line(sb, $"Masa z BOM: {a.Drawing.BomTotalMassKg.Value:0.###} kg · pozycje z masą: {a.Drawing.BomMassRowCount} · źródła: {a.Drawing.BomMassSourceCount}");
        Line(sb, $"Łączny czas procesu: {a.TotalHours:0.###} h");
        Line(sb, "");

        var evidence = a.Evidence ?? new EvidenceOrchestrationSummary();
        var featureCoverage = a.Geometry.UniquePartGroups > 0
            ? 100.0 * Math.Clamp(a.Geometry.FullyAnalyzedUniqueSolids, 0, a.Geometry.UniquePartGroups) / a.Geometry.UniquePartGroups
            : (a.Geometry.Available && !a.Geometry.WatchdogTriggered ? 100.0 : 0.0);
        var cncProcess = a.Processes.FirstOrDefault(x => x.Code.Equals("CNC", StringComparison.OrdinalIgnoreCase));
        var usedFiles = evidence.Facts
            .Where(x => x.SupportsDecision && !string.IsNullOrWhiteSpace(x.SourceFile))
            .Select(x => x.SourceFile)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x, StringComparer.OrdinalIgnoreCase)
            .ToList();
        var blockingRisks = a.Risks.Where(x => x.Blocking).ToList();

        Section(sb, "UŻYTE DO WYCENY / ŹRÓDŁA DECYZJI");
        Line(sb, $"Masa: {Fmt(a.WeightKg)} kg · źródło: {(string.IsNullOrWhiteSpace(a.WeightSource) ? "—" : a.WeightSource)} · materiał: {a.Material} · gęstość {(a.DensityAssumed ? "ZAŁOŻONA" : "rozpoznana")}");
        Line(sb, $"Spoiny: {(a.Welding.Enabled ? $"{a.Welding.EffectiveLengthM:0.###} m · {a.Welding.Source} · pewność {a.Welding.Confidence}%" : "nieaktywne / brak potwierdzenia")}");
        Line(sb, $"STEP features: {a.Geometry.FullyAnalyzedUniqueSolids}/{a.Geometry.UniquePartGroups} unikalnych grup · pokrycie {featureCoverage:0.#}% · watchdog {(a.Geometry.WatchdogTriggered ? "TAK" : "NIE")}");
        Line(sb, $"CNC: {(cncProcess is null ? "brak kroku" : $"{(cncProcess.Enabled ? "AKTYWNE" : "nieaktywne")} · {cncProcess.Hours:0.###} h · pewność {cncProcess.Confidence}%")}");
        if (cncProcess is not null && !string.IsNullOrWhiteSpace(cncProcess.Basis))
            Line(sb, $"  Podstawa CNC: {cncProcess.Basis}");
        Line(sb, $"Ryzyka blokujące: {blockingRisks.Count}" +
                 (blockingRisks.Count > 0 ? $" · {string.Join(" | ", blockingRisks.Select(x => x.Title).Take(6))}" : ""));
        Line(sb, $"Pliki z dowodami użytymi w decyzjach: {(usedFiles.Count == 0 ? "—" : string.Join(", ", usedFiles))}");
        Line(sb, "");

        Section(sb, "CZASY SILNIKÓW / DS ESTIMATE 1.2 MINIMAL UI");
        Line(sb, $"Czas rzeczywisty analizy: {a.AnalysisWallSeconds:0.###} s");
        Line(sb, $"Suma pracy silników: {a.AnalysisWorkSeconds:0.###} s");
        Line(sb, $"Zysk z równoległości/cache: {a.ParallelEfficiencyGainPercent:0.#}%");
        foreach (var timing in a.EngineTimings.OrderByDescending(x => x.ElapsedSeconds))
            Line(sb, $"- {timing.Engine} · {timing.Detail}: {timing.ElapsedSeconds:0.###} s" +
                     (timing.FromCache ? " · CACHE" : "") +
                     (timing.RanInParallel ? " · równolegle" : ""));
        Line(sb, "");

        Section(sb, "DS EVIDENCE ORCHESTRATOR FIX10 / AUDYT DECYZJI");
        Line(sb, $"Wersja: {evidence.Version}");
        Line(sb, $"Tryb: {evidence.Mode}");
        Line(sb, $"Podsumowanie: {evidence.Summary}");
        Line(sb, "FIX10 odrzuca wielokrotne głosowanie identycznej treści przed Cost Engine; decyzje i odrzucone aliasy pozostają widoczne w audycie.");
        if (evidence.Decisions.Count == 0)
        {
            Line(sb, "(brak decyzji — projekt pochodzi ze starszej wersji lub nie został przeliczony FIX10)");
        }
        else
        {
            foreach (var decision in evidence.Decisions)
            {
                Line(sb, $"- {decision.State} | {decision.Label}: {decision.DisplayValue} | pewność {decision.Confidence}%");
                Line(sb, $"    Poparcie: {decision.SupportingSources}; sprzeczne: {decision.ConflictingSources}; odstające: {decision.OutlierSources}; przegląd: {(decision.NeedsReview ? "TAK" : "NIE")}");
                Line(sb, $"    Reguła: {decision.Rule}");
                Line(sb, $"    Wyjaśnienie: {decision.Explanation}");
                if (decision.SourceFiles.Count > 0)
                    Line(sb, $"    Źródła: {string.Join(", ", decision.SourceFiles)}");
                if (!string.IsNullOrWhiteSpace(decision.NextAction))
                    Line(sb, $"    Następna czynność: {decision.NextAction}");
            }
        }
        Line(sb, "");

        Section(sb, "DS EVIDENCE ORCHESTRATOR FIX10 / DUPLIKATY TREŚCI");
        if (evidence.ContentDuplicates.Count == 0)
        {
            Line(sb, "(nie wykryto identycznych plików pod różnymi nazwami)");
        }
        else
        {
            foreach (var duplicate in evidence.ContentDuplicates)
            {
                Line(sb, $"- SHA256 {duplicate.ContentHashPrefix}… | źródło kanoniczne: {duplicate.CanonicalSource} | aliasy: {duplicate.AliasCount}");
                Line(sb, $"    Pliki: {string.Join(", ", duplicate.Files)}");
                Line(sb, "    Zasada: wszystkie pozostają widoczne; koordynator liczy jeden niezależny głos dowodowy.");
            }
        }
        Line(sb, "");

        Section(sb, "DS EVIDENCE ORCHESTRATOR FIX10 / SUROWE DOWODY");
        if (evidence.Facts.Count == 0)
        {
            Line(sb, "(brak)");
        }
        else
        {
            foreach (var fact in evidence.Facts.Take(1000))
            {
                var flags = new List<string>();
                if (fact.SupportsDecision) flags.Add("POPIERA");
                if (fact.ConflictsWithDecision) flags.Add("SPRZECZNE");
                if (fact.Outlier) flags.Add("ODSTAJĄCE/SKALA");
                Line(sb, $"- {fact.Field} | {fact.DisplayValue} | {fact.SourceFile} | {fact.SourceKind} | {fact.Method} | zakres {fact.Scope} | {fact.Confidence}%" +
                         (flags.Count > 0 ? $" | {string.Join(",", flags)}" : ""));
                if (fact.SourceAliases.Count > 1)
                    Line(sb, $"    Aliasy tej samej treści: {string.Join(", ", fact.SourceAliases)}");
                if (!string.IsNullOrWhiteSpace(fact.Note))
                    Line(sb, $"    {fact.Note}");
            }
            if (evidence.Facts.Count > 1000)
                Line(sb, $"... pominięto w raporcie {evidence.Facts.Count - 1000} dalszych dowodów; wynik projektu zachowuje pełną listę.");
        }
        Line(sb, "");

        Section(sb, "DS EVIDENCE ORCHESTRATOR FIX10 / ROUTING PLIKÓW");
        if (evidence.Routes.Count == 0)
        {
            Line(sb, "(brak śladu routingu)");
        }
        else
        {
            foreach (var route in evidence.Routes.Take(1000))
            {
                Line(sb, $"- P{route.Priority:00} | {route.SourceFile} | {route.DocumentKind} | {route.Strategy}");
                Line(sb, $"    Silnik: {route.Engine}; kosztowny: {(route.Expensive ? "TAK" : "NIE")}; cache: {(route.FromCache ? "TAK" : "NIE")}; niezależny dowód: {(route.IndependentEvidence ? "TAK" : "NIE")}; wynik: {route.Outcome}");
                Line(sb, $"    Powód: {route.Reason}");
                if (!string.IsNullOrWhiteSpace(route.NextAction))
                    Line(sb, $"    Następna czynność: {route.NextAction}");
            }
            if (evidence.Routes.Count > 1000)
                Line(sb, $"... pominięto w raporcie {evidence.Routes.Count - 1000} dalszych tras.");
        }
        Line(sb, "");

        Section(sb, "DS EVIDENCE ORCHESTRATOR FIX10 / ZALECANE CZYNNOŚCI");
        foreach (var action in evidence.RecommendedActions)
            Line(sb, $"- {action}");
        Line(sb, "");

        Section(sb, "FIX12A / SHADOW TECHNOLOGY GRAPH — DUAL-RUN");
        var shadow = a.ShadowTechnologyGraph;
        Line(sb, $"Wersja: {shadow.Version}");
        Line(sb, $"Tryb: {(shadow.ShadowOnly ? "SHADOW / AUDIT" : "ACTIVE")}");
        Line(sb, $"Prawo zmiany ceny: {(shadow.HasPriceAuthority ? "TAK" : "NIE")}");
        Line(sb, $"Podsumowanie: {shadow.Summary}");
        Line(sb, $"Cena legacy FIX11 zachowana: {shadow.LegacyRecommendedPricePln:0.00} PLN");
        Line(sb, $"POST_WELD machining: {(shadow.PostWeldMachiningDetected ? "TAK" : "NIE")}");
        Line(sb, $"Legacy route: {shadow.LegacyRoute}");
        Line(sb, $"Shadow route: {shadow.ShadowRoute}");
        if (shadow.Warnings.Count > 0)
        {
            Line(sb, "Reality checks / ostrzeżenia shadow:");
            foreach (var warning in shadow.Warnings.Take(100))
                Line(sb, $"  - {warning}");
        }
        Line(sb, "Stany geometrii:");
        foreach (var state in shadow.States.Take(100))
            Line(sb, $"  - {state.Id} | {state.State} | {state.Name} | {state.Geometry.BoundingBoxText} | {state.Geometry.MassKg:0.###} kg | encje {state.EntityIds.Count}");
        Line(sb, "Procesy shadow (legacy cost tylko do porównania; brak wpływu na cenę):");
        foreach (var node in shadow.Processes.Take(100))
        {
            Line(sb, $"  - {node.Id} | {node.Process} | {node.Name} | {string.Join(",", node.InputStateIds)} → {node.OutputStateId}");
            Line(sb, $"      confidence: existence {node.Confidence.ExistencePercent}% · binding {node.Confidence.BindingPercent}% · geometry {node.Confidence.GeometryPercent}% · parameters {node.Confidence.ParametersPercent}% · cost {node.Confidence.CostPercent}%");
            Line(sb, $"      legacy: {node.LegacyHours:0.###} h / {node.LegacyCostPln:0.00} PLN · evidence {node.EvidenceIds.Count} · shadow-only {(node.ShadowOnly ? "TAK" : "NIE")}");
        }
        Line(sb, $"UniquePartGroup: {shadow.UniquePartGroups.Count}");
        foreach (var group in shadow.UniquePartGroups.Take(100))
            Line(sb, $"  - {group.Id} | {group.Name} ×{group.Quantity} | {group.Classification} | {group.Geometry.BoundingBoxText} | {group.Geometry.MassKg:0.###} kg/szt. | evidence {group.EvidenceIds.Count}");
        Line(sb, $"EvidenceBinding: {shadow.EvidenceBindings.Count}");
        foreach (var binding in shadow.EvidenceBindings.Take(200))
        {
            var target = !string.IsNullOrWhiteSpace(binding.ResolvedTargetId)
                ? binding.ResolvedTargetId
                : binding.TargetCandidates.Count > 0
                    ? string.Join(", ", binding.TargetCandidates.Take(3).Select(x => $"{x.EntityId}:{x.Score:P0}"))
                    : "UNRESOLVED";
            Line(sb, $"  - {binding.Id} | {binding.SourceFile} | {binding.Field} | {binding.Observation} | target {target} | constraint {binding.ProcessConstraint}");
            Line(sb, $"      confidence: existence {binding.Confidence.ExistencePercent}% · binding {binding.Confidence.BindingPercent}% · geometry {binding.Confidence.GeometryPercent}% · parameters {binding.Confidence.ParametersPercent}% · cost {binding.Confidence.CostPercent}% · review {(binding.NeedsReview ? "TAK" : "NIE")}");
        }
        Line(sb, "");

        Section(sb, "FIX12D / RESOLVER RODZIN DOKUMENTÓW");
        if (a.Drawing.ResolvedRootBomFamilyCount <= 0)
        {
            Line(sb, "Root BOM: nie rozpoznano wiarygodnej nadrzędnej listy części; użyto bezpiecznego trybu legacy bez twardego filtrowania rodzin.");
        }
        else
        {
            Line(sb, $"Root entity: {(string.IsNullOrWhiteSpace(a.Drawing.ResolvedRootEntityKey) ? "—" : a.Drawing.ResolvedRootEntityKey)}");
            Line(sb, $"Rodziny produkcyjne z root BOM: {a.Drawing.ResolvedRootBomFamilyCount} · egzekwowanie scope: {(a.Drawing.ResolvedFamilyScopeEnforced ? "TAK" : "NIE — tylko audyt")}");
            Line(sb, $"Pokrycie STEP: {a.Drawing.ResolvedStepFamilyMatchCount}/{a.Drawing.ResolvedStepFamilyCount} rodzin plików STEP · geometria częściowa: {(a.Drawing.StepGeometryProjectCoveragePartial ? "TAK" : "NIE")}");
            Line(sb, $"Pokrycie DXF: {a.Drawing.ResolvedDxfFamilyMatchCount}/{a.Drawing.ResolvedDxfFamilyCount} rodzin DXF · scope ograniczony: {(a.Drawing.DxfScopeLimited ? "TAK" : "NIE")}");
            Line(sb, "Zasada: numerowany PDF/DXF/STEP spoza root BOM pozostaje widoczny w audycie, ale nie głosuje do globalnej masy, materiału, spoin ani cięcia.");
        }
        Line(sb, "");

        Section(sb, "FIX12E / HYBRYDOWA REKONSTRUKCJA POWIERZCHNI");
        if (a.Drawing.HybridSurfaceAreaM2 is > 0)
        {
            Line(sb, $"Powierzchnia zrekonstruowana: {a.Drawing.HybridSurfaceAreaM2.Value:0.###} m²");
            Line(sb, $"Pokrycie rodzin BOM: {a.Drawing.HybridSurfaceAreaCoveragePercent:0.#}%");
            Line(sb, $"Pewność pola: {a.Drawing.HybridSurfaceAreaConfidence}%");
            Line(sb, $"Źródła: {a.Drawing.HybridSurfaceAreaSource}");
            foreach (var c in a.Drawing.HybridSurfaceAreaContributions.OrderByDescending(x => x.AreaM2).Take(100))
                Line(sb, $"  - {c.FamilyKey} | {c.SourceKind} | {c.AreaM2:0.###} m² | ×{c.Quantity:0.###} | t={(c.ThicknessMm.HasValue ? $"{c.ThicknessMm.Value:0.###} mm" : "—")} | {c.Confidence}% | {c.Basis}");
            if (a.Drawing.HybridSurfaceAreaContributions.Count > 100)
                Line(sb, $"  ... pominięto {a.Drawing.HybridSurfaceAreaContributions.Count - 100} dalszych rodzin.");
        }
        else
        {
            Line(sb, "Nie użyto rekonstrukcji hybrydowej — pełny STEP lub brak wiarygodnego root BOM / geometrii 2D.");
        }
        Line(sb, "Zasada FIX12E: jedna rodzina = jedno najlepsze źródło powierzchni; STEP, DXF i BOM tej samej części nie są sumowane podwójnie.");
        Line(sb, "");

        Section(sb, "FIX14 / REKONSTRUKCJA MASY I CZĘŚCIOWY KOSZT MATERIAŁU");
        if (a.Drawing.HybridMassKg is > 0)
        {
            Line(sb, $"Masa zrekonstruowana: {a.Drawing.HybridMassKg.Value:0.###} kg");
            Line(sb, $"Pokrycie rodzin BOM: {a.Drawing.HybridMassCoveragePercent:0.#}%");
            Line(sb, $"Pewność: {a.Drawing.HybridMassConfidence}%");
            Line(sb, $"Prawo do masy projektu: {(a.Drawing.HybridMassProjectAuthoritative ? "TAK" : "NIE — TYLKO CZĘŚCIOWY ZAKRES")}");
            Line(sb, $"Źródło: {a.Drawing.HybridMassSource}");
            foreach (var c in a.Drawing.HybridMassContributions.OrderByDescending(x => x.MassKg).Take(120))
                Line(sb, $"  - {c.FamilyKey} | {c.SourceKind} | {c.Material} | {c.MassKg:0.###} kg | ×{c.Quantity:0.###} | {c.Confidence}% | {c.Basis}");
        }
        else
        {
            Line(sb, "Brak bezpiecznej rekonstrukcji masy per rodzina.");
        }
        Line(sb, $"Rozpoznany częściowy koszt materiału: {a.RecognizedPartialMaterialCostPln:0.##} PLN");
        Line(sb, "Zasada: częściowa masa może wycenić rozpoznany zakres, ale nie odblokowuje ceny ofertowej bez wymaganej kompletności root BOM.");
        Line(sb, "");

        Section(sb, "AUTOQUOTE / AUTOMATYCZNA WYCENA");
        Line(sb, $"Status: {a.AutoQuote.Status}");
        Line(sb, $"Opis: {a.AutoQuote.StatusDetail}");
        Line(sb, a.AutoQuote.RecommendedPricePln > 0 ? $"{a.AutoQuote.PriceLabel}: {a.AutoQuote.RecommendedPricePln:0.00} PLN" : $"{a.AutoQuote.PriceLabel}: —");
        if (!a.AutoQuote.IsPriceComplete && !string.IsNullOrWhiteSpace(a.AutoQuote.PriceCompletenessNote))
            Line(sb, $"UWAGA CENOWA: {a.AutoQuote.PriceCompletenessNote}");
        Line(sb, a.AutoQuote.HasRecommendedPrice ? $"P50 / zakres ryzyka: {a.AutoQuote.P50PricePln:0.00} PLN / {a.AutoQuote.PriceLowPln:0.00} - {a.AutoQuote.PriceHighPln:0.00} PLN" : "P50 / zakres ryzyka: NIE WYZNACZONO");
        Line(sb, $"Niepewność: {a.AutoQuote.UncertaintyPercent:0.#}%");
        if (!string.IsNullOrWhiteSpace(a.AutoQuote.UncertaintyDrivers))
            Line(sb, $"Czynniki niepewności: {a.AutoQuote.UncertaintyDrivers}");
        Line(sb, $"Operacje automatyczne: {a.AutoQuote.EnabledOperationCount}");
        Line(sb, $"Założenia automatyczne: {a.AutoQuote.AutomaticAssumptionCount}");
        Line(sb, $"Operacje zewnętrzne bez stawki: {a.AutoQuote.UnpricedExternalOperationCount}");
        Line(sb, $"Routing: {a.AutoQuote.RouteSummary}");
        Line(sb, $"Założenia: {a.AutoQuote.MainAssumptions}");
        Line(sb, $"Profil stawek: {a.AutoQuote.PricingProfileName}");
        Line(sb, $"Status stawek: {a.AutoQuote.RatesStatus}");
        Line(sb, $"Gotowość wyceny: {a.AutoQuote.ReadinessSummary}");
        foreach (var readiness in a.AutoQuote.ReadinessItems)
            Line(sb, $"  {readiness.Status} | {readiness.Label} | {readiness.Detail} | następny krok: {readiness.NextAction}");
        Line(sb, $"FIX15 kalibracja: {a.ExternalCalibration.Summary}");
        Line(sb, $"FIX18 walidacja profilu: {settings.CompanyProfileValidationStatus} | uczenie {settings.CompanyProfileValidationTrainingProjects} | walidacja {settings.CompanyProfileValidationProjects} | MAPE {settings.CompanyProfileValidationBaselineMapePercent:0.#}% -> {settings.CompanyProfileValidationProposedMapePercent:0.#}% | bias {settings.CompanyProfileValidationBaselineBiasPercent:+0.#;-0.#;0}% -> {settings.CompanyProfileValidationProposedBiasPercent:+0.#;-0.#;0}% | P90 {settings.CompanyProfileValidationBaselineP90Percent:0.#}% -> {settings.CompanyProfileValidationProposedP90Percent:0.#}%");
        if (settings.CompanyProfileValidationRollingFolds > 0)
            Line(sb, $"FIX18 rolling backtest: {settings.CompanyProfileValidationRollingFolds} fold(y) | MAPE {settings.CompanyProfileValidationRollingBaselineMapePercent:0.#}% -> {settings.CompanyProfileValidationRollingProposedMapePercent:0.#}%");
        if (!string.IsNullOrWhiteSpace(settings.CompanyProfileValidationSummary))
            Line(sb, $"FIX17 wynik walidacji: {settings.CompanyProfileValidationSummary}");
        Line(sb, $"FIX15 trust: {a.Trust.Summary}");
        Line(sb, $"FIX16 blachy gięte: {a.SheetMetal.Summary}");
        if (a.SheetMetal.IsRelevant) Line(sb, $"FIX16 następna czynność: {a.SheetMetal.NextAction}");
        foreach (var warning in a.PriceAgeWarnings) Line(sb, $"CENNIK: {warning.Level} | {warning.Message}");
        Line(sb, $"Koszt modelowany / should-cost: {a.AutoQuote.ModeledCostPln:0.00} PLN");
        Line(sb, $"Koszt rozpoznanego zakresu: {a.AutoQuote.RecognizedCostPln:0.00} PLN");
        Line(sb, $"Rozpoznany materiał: {a.AutoQuote.RecognizedMaterialCostPln:0.00} PLN · pokrycie {a.AutoQuote.RecognizedMaterialCoveragePercent:0.#}% · nierozwiązane rodziny {a.AutoQuote.UnresolvedFamilyCount}");
        Line(sb, $"Narzut / korekta ceny: {a.AutoQuote.SellingUpliftPln:0.00} PLN");
        Line(sb, $"Koszt/kg: {a.AutoQuote.CostPerKg:0.00} PLN/kg");
        Line(sb, $"Cena/kg: {a.AutoQuote.PricePerKg:0.00} PLN/kg");
        Line(sb, $"Konflikty danych: {a.AutoQuote.ConflictCount}");
        Line(sb, $"Pakiet / rewizje: {a.Package.RevisionSummary}");
        foreach (var scenario in a.QuoteScenarios)
            Line(sb, $"WHAT-IF {scenario.Code}: {scenario.Name} | koszt {scenario.CostPln:0.00} PLN | cena {(scenario.HasOfferPrice ? scenario.PricePln.ToString("0.00") + " PLN" : "NIE WYZNACZONO")} | {scenario.DeltaDisplay} | {scenario.Assumption}");
        Line(sb, "");

        if (a.Drawing.Conflicts.Count > 0)
        {
            Section(sb, "KONFLIKTY DANYCH MIĘDZY DOKUMENTAMI");
            foreach (var conflict in a.Drawing.Conflicts)
            {
                var scope = conflict.IsLocalVariation ? "LOKALNA RÓŻNICA — nie konflikt projektu" : conflict.Level.ToString();
                Line(sb, $"{scope} | {conflict.Field}: {conflict.Values}");
                Line(sb, $"    Źródła: {conflict.Sources}");
                Line(sb, $"    Reguła: {conflict.Resolution}");
            }
            Line(sb, "");
        }

        Section(sb, "PACZKA RFQ / GRUPOWANIE DOKUMENTÓW");
        Line(sb, $"Pliki: {a.Package.DocumentCount}; istotne produkcyjnie: {a.Package.RelevantDocumentCount}; " +
                 $"neutralnie pominięte: {a.Package.NeutralSkippedDocumentCount}; pominięte wymagające uwagi: {a.Package.SkippedDocumentCount}; " +
                 $"uwagi: {a.Package.WarningDocumentCount}");
        Line(sb, $"Rewizje: {a.Package.RevisionSummary}");
        if (a.Package.SelectedRevisionFiles.Count > 0)
            Line(sb, $"Wybrane rewizje: {string.Join(", ", a.Package.SelectedRevisionFiles)}");
        if (a.Package.IgnoredOlderRevisionFiles.Count > 0)
            Line(sb, $"Starsze pominięte: {string.Join(", ", a.Package.IgnoredOlderRevisionFiles)}");
        foreach (var group in a.Package.DocumentGroups.Take(100))
            Line(sb, $"- {group.Summary} | STEP: {string.Join(",", group.StepFiles)} | BOM: {string.Join(",", group.BomFiles)} | rysunki: {string.Join(",", group.DrawingFiles)}");
        Line(sb, "");

        Section(sb, "HIERARCHIA ZŁOŻENIA / BOM");
        foreach (var node in a.AssemblyTree.Take(500))
        {
            Line(sb, $"{new string(' ', node.Level * 2)}- [{node.Kind}] {node.Name} {node.QuantityText} | {node.Material} | {node.MassText}");
            Line(sb, $"{new string(' ', node.Level * 2 + 2)}Źródło: {node.Source} | {node.MatchBasis}");
        }
        Line(sb, "");

        Section(sb, "FIX13 / MATERIAŁY I PÓŁFABRYKATY");
        if (a.MaterialBreakdown.Count == 0)
        {
            Line(sb, "Brak wiarygodnego rozbicia materiałowego per rodzina.");
        }
        else
        {
            foreach (var item in a.MaterialBreakdown.OrderByDescending(x => x.MassKg))
                Line(sb, $"- {item.Material} | {item.SemiFinishedKind} | {item.MassKg:0.###} kg | {item.SharePercent:0.#}% masy | rodziny {item.FamilyCount} | pewność {item.Confidence}% | {item.Source}");
        }
        if (a.SemiFinishedProducts.Count > 0)
        {
            Line(sb, "Półfabrykaty:");
            foreach (var item in a.SemiFinishedProducts.OrderByDescending(x => x.MassKg).ThenBy(x => x.Kind))
                Line(sb, $"  - {item.Kind} | {item.Material} | ilość {item.Quantity:0.###} | {item.MassKg:0.###} kg | pewność {item.Confidence}% | {item.Source}");
        }
        Line(sb, "");

        Section(sb, "FIX14 / ZAKRES NDT I STREFY MALARSKIE");
        if (a.Drawing.NdtFamilySignals.Count == 0)
            Line(sb, "NDT per rodzina: brak lokalnych sygnałów.");
        else
            foreach (var x in a.Drawing.NdtFamilySignals.OrderBy(x => x.FamilyKey))
                Line(sb, $"- NDT {x.FamilyKey}: {string.Join("/", x.Methods)} | {x.Confidence}% | {x.Basis}");
        if (a.Drawing.PaintZoneSignals.Count == 0)
            Line(sb, "Strefy malarskie per rodzina: brak lokalnych sygnałów.");
        else
            foreach (var x in a.Drawing.PaintZoneSignals.OrderBy(x => x.FamilyKey).Take(200))
                Line(sb, $"- PAINT {x.FamilyKey}: klasa {x.CorrosionClass} | prep {x.Preparation} | kolor {x.Colour} | DFT {(x.DftMicron.HasValue ? x.DftMicron.Value.ToString("0.#") + " µm" : "—")} | {x.Confidence}%");
        Line(sb, "");

        Section(sb, "RULE ENGINE / DFM");
        if (a.RuleHits.Count == 0)
            Line(sb, "(brak aktywowanych reguł)");
        foreach (var hit in a.RuleHits)
        {
            Line(sb, $"- {hit.Code} | {hit.Name} | pewność {hit.Confidence}%");
            Line(sb, $"  Efekt: {hit.Effect}");
            Line(sb, $"  Podstawa: {hit.Basis}");
        }
        Line(sb, "");

        Section(sb, "KALIBRACJA PLAN / WYKONANIE");
        if (a.CalibrationFactors.Count == 0)
            Line(sb, "Brak wystarczającej historii wykonania do automatycznej korekty.");
        foreach (var factor in a.CalibrationFactors)
            Line(sb, $"- {factor.Display} | {factor.Basis}");
        Line(sb, "");

        Section(sb, "FIX13 / KALIBRACJA HISTORYCZNA PODOBNYMI REALIZACJAMI");
        var hc = a.HistoricalCalibration;
        Line(sb, $"Zastosowana: {(hc.Applied ? "TAK" : "NIE")} | sąsiedzi wykonania: {hc.NeighborCount} | sąsiedzi ceny: {hc.PriceNeighborCount} | pewność {hc.Confidence}%");
        Line(sb, $"Ważona cena historyczna: {(hc.WeightedHistoricalPricePln.HasValue ? hc.WeightedHistoricalPricePln.Value.ToString("0.##", CultureInfo.InvariantCulture) + " PLN" : "—")}");
        Line(sb, $"Wskazanie kosztu kooperacji z historii: {(hc.ExternalCostHintPln.HasValue ? hc.ExternalCostHintPln.Value.ToString("0.##", CultureInfo.InvariantCulture) + " PLN (diagnostyczne)" : "—")}");
        Line(sb, $"Podstawa: {(string.IsNullOrWhiteSpace(hc.Basis) ? "—" : hc.Basis)}");
        foreach (var adj in hc.ProcessAdjustments.OrderByDescending(x => Math.Abs(x.AppliedFactor - 1.0)))
        {
            Line(sb, $"- {adj.ProcessCode} | {adj.ProcessName}: {adj.BeforeHours:0.###} h → {adj.AfterHours:0.###} h | ×{adj.AppliedFactor:0.###} (surowe ×{adj.RawFactor:0.###}) | próbki {adj.Samples} | podobieństwo {adj.AverageSimilarityPercent:0.#}% | pewność {adj.Confidence}%");
            Line(sb, $"  {adj.Basis}");
        }
        Line(sb, "");

        foreach (var step in a.AutoRoute.OrderBy(x => x.Sequence))
        {
            Line(sb, $"{step.SequenceText} | {step.Name} | {step.Source} | pewność {step.Confidence}% | {step.Hours:0.###} h | {step.CostText}");
            Line(sb, $"    {step.Basis}");
        }
        Line(sb, "");

        Section(sb, "GEOMETRIA STEP");
        var g = a.Geometry;
        Line(sb, $"Geometry Engine dostępny: {(g.Available ? "TAK" : "NIE")}");
        Line(sb, $"Tryb analizy STEP: {(string.IsNullOrWhiteSpace(g.AnalysisMode) ? "—" : g.AnalysisMode)}");
        Line(sb, $"Watchdog uruchomiony: {(g.WatchdogTriggered ? "TAK" : "NIE")}");
        Line(sb, $"Limit watchdoga: {(g.WatchdogLimitSeconds is > 0 ? g.WatchdogLimitSeconds.Value.ToString("0.###", CultureInfo.InvariantCulture) + " s" : "—")}");
        Line(sb, $"Importer STEP: {(string.IsNullOrWhiteSpace(g.Importer) ? "(brak danych)" : g.Importer)}");
        Line(sb, $"Hole Engine: {(string.IsNullOrWhiteSpace(g.HoleEngineVersion) ? "1.x / brak danych" : g.HoleEngineVersion)}");
        Line(sb, $"Joint Engine: {(string.IsNullOrWhiteSpace(g.JointEngineVersion) ? "(brak danych)" : g.JointEngineVersion)}");
        Line(sb, $"Surface Engine: {(string.IsNullOrWhiteSpace(g.SurfaceEngineVersion) ? "(brak danych)" : g.SurfaceEngineVersion)}");
        Line(sb, $"Bryły: {g.SolidCount}");
        Line(sb, $"Unikalne grupy detali: {g.UniquePartGroups}");
        Line(sb, $"Potencjalne styki <=0,25 mm: {g.ContactPairs}");
        Line(sb, $"Nominalne styki <=0,10 mm: {g.ContactPairsNominal}");
        Line(sb, $"Ścisłe styki <=0,05 mm: {g.ContactPairsTight}");
        Line(sb, $"Kandydaci do styków: {g.ContactCandidatePairs}");
        Line(sb, $"Dokładne sprawdzenia styków: {g.ContactExactChecks}");
        Line(sb, $"Limit styków osiągnięty: {(g.ContactLimitReached ? "TAK" : "NIE")}");
        Line(sb, $"Objętość: {g.VolumeMm3:0.###} mm3");
        Line(sb, $"Powierzchnia brutto: {g.SurfaceMm2:0.###} mm2");
        Line(sb, $"Powierzchnia dolegania (jedna strona): {g.PlanarMatingAreaMm2:0.###} mm2");
        Line(sb, $"Powierzchnie ukryte w stykach (obie strony): {g.HiddenMatingSurfaceMm2:0.###} mm2");
        Line(sb, $"Powierzchnia po złożeniu: {g.ExposedSurfaceMm2:0.###} mm2");
        Line(sb, $"Pewne powierzchnie wewnętrzne wyłączone z malowania: {g.InternalPaintExcludedMm2:0.###} mm2");
        Line(sb, $"Powierzchnie zamkniętych komór wyłączone z malowania: {g.SealedCavitySurfaceMm2:0.###} mm2");
        Line(sb, $"Sprawdzone ściany dostępności: {g.SurfaceAccessibilityCheckedFaces}");
        Line(sb, $"Limit dostępności powierzchni: {(g.SurfaceAccessibilityLimitReached ? "TAK" : "NIE")}");
        Line(sb, $"Powierzchnia do malowania: {g.PaintableSurfaceMm2:0.###} mm2");
        Line(sb, $"Kandydaci połączeń spawanych: {g.WeldCandidatePairs}");
        Line(sb, $"Pary możliwie śrubowe: {g.PossibleBoltedJointPairs}");
        Line(sb, $"Kandydacka długość krawędzi spoin: {g.WeldCandidateLengthMm:0.###} mm");
        Line(sb, $"Limit Joint/Surface Engine: {(g.JointAnalysisLimitReached ? "TAK" : "NIE")}");
        Line(sb, $"Sprawdzenia kandydackich par ścian złączy: {g.JointFaceChecks}");
        Line(sb, $"Gabaryt: {g.BoundingXmm:0.###} x {g.BoundingYmm:0.###} x {g.BoundingZmm:0.###} mm");
        Line(sb, $"Rozpoznane otwory: {g.TotalHoleCount}");
        Line(sb, $"Możliwe fazy/ukosy: {g.TotalBevelFaces}");

        if (g.Warnings.Count > 0)
        {
            Line(sb, "Uwagi Geometry Engine:");
            foreach (var warning in g.Warnings)
                Line(sb, $"  - {warning}");
        }
        Line(sb, "");

        Section(sb, "POŁĄCZENIA / STYKI KONSTRUKCYJNE");
        if (g.JointCandidates.Count == 0)
        {
            Line(sb, "(brak rozpoznanych planarno-dolegających połączeń)");
        }
        else
        {
            foreach (var joint in g.JointCandidates.Take(100))
            {
                Line(sb, $"Bryła {joint.BodyA} ↔ {joint.BodyB}: {joint.Type}");
                Line(sb, $"    Źródło: {joint.SourceFile}");
                Line(sb, $"    Szczelina: {joint.DistanceMm:0.###} mm");
                Line(sb, $"    Rzeczywista powierzchnia dolegania: {joint.ContactAreaMm2:0.###} mm2");
                Line(sb, $"    Obszar złącza po projekcji: {joint.ProjectedJointAreaMm2:0.###} mm2");
                Line(sb, $"    Kandydacka długość spoiny: {joint.CandidateWeldLengthMm:0.###} mm");
                Line(sb, $"    Podstawa długości: {joint.WeldLengthBasis}");
                Line(sb, $"    Możliwe połączenie śrubowe: {(joint.PossibleBoltedJoint ? "TAK" : "NIE")} · zgodne otwory {joint.MatchingThroughHoles}");
                Line(sb, $"    Kandydat konstrukcyjny: {(joint.StructuralCandidate ? "TAK" : "NIE")} · pewność {joint.Confidence}%");
                Line(sb, $"    Podstawa: {joint.Basis}");
            }

            if (g.JointCandidates.Count > 100)
                Line(sb, $"... pominięto {g.JointCandidates.Count - 100} dalszych połączeń w raporcie.");
        }
        Line(sb, "");

        Section(sb, "DETALE / GRUPY");
        if (g.Parts.Count == 0)
        {
            Line(sb, "(brak)");
        }
        else
        {
            var i = 1;
            foreach (var p in g.Parts)
            {
                Line(sb, $"[{i}] {p.Name}  x{p.Quantity}");
                Line(sb, $"    Źródło: {p.SourceFile}");
                Line(sb, $"    Typ: {p.Classification} ({p.ClassificationConfidence}%)");
                if (!string.IsNullOrWhiteSpace(p.ClassificationBasis))
                    Line(sb, $"    Podstawa klasyfikacji: {p.ClassificationBasis}");
                Line(sb, $"    Gabaryt: {p.Xmm:0.###} x {p.Ymm:0.###} x {p.Zmm:0.###} mm");
                Line(sb, $"    Objętość / szt.: {p.VolumeMm3Each:0.###} mm3");
                Line(sb, $"    Powierzchnia / szt.: {p.SurfaceMm2Each:0.###} mm2");
                Line(sb, $"    Masa / szt.: {p.MassKgEach:0.###} kg");
                Line(sb, $"    Masa grupy: {p.MassKgEach * p.Quantity:0.###} kg");
                Line(sb, $"    Ściany: {p.FaceCount}");
                Line(sb, $"    Krawędzie: {p.EdgeCount}");
                Line(sb, $"    Planarne: {p.PlanarFaceCount}");
                Line(sb, $"      - wewnętrzne planarne (heurystyka): {p.InternalPlanarFaceCount}");
                Line(sb, $"    Wyłączona powierzchnia wewnętrzna / szt.: {p.InternalPaintExcludedMm2Each:0.###} mm2");
                Line(sb, $"    Walcowe: {p.CylindricalFaceCount}");
                Line(sb, $"      - wewnętrzne: {p.InternalCylindricalFaceCount}");
                Line(sb, $"      - zewnętrzne: {p.ExternalCylindricalFaceCount}");
                Line(sb, $"      - niejednoznaczne: {p.UncertainCylindricalFaceCount}");
                Line(sb, $"    Stożkowe: {p.ConicalFaceCount}");
                Line(sb, $"    Ukosy/fazy: {p.Bevel.Display}");

                if (p.Holes.Count == 0)
                {
                    Line(sb, "    Otwory: brak");
                }
                else
                {
                    Line(sb, "    Otwory:");
                    foreach (var hole in p.Holes)
                        Line(sb, $"      - {hole.Display}");
                }

                i++;
            }
        }
        Line(sb, "");

        Section(sb, "DOKUMENTACJA / PDF / OCR");
        Line(sb, $"Materiał z dokumentacji: {a.Drawing.MaterialHint}");
        var materialReferenceText = string.IsNullOrWhiteSpace(a.Drawing.MaterialReference)
            ? "—"
            : $"{a.Drawing.MaterialReference} (diagnostyczna; nie zastępuje gatunku)";
        Line(sb, $"Referencja/specyfikacja materiałowa: {materialReferenceText}");
        Line(sb, $"Masa z PDF/DXF: {(a.Drawing.DocumentMassKg.HasValue ? $"{a.Drawing.DocumentMassKg.Value:0.###} kg ({a.Drawing.DocumentMassConfidence}% · {a.Drawing.DocumentMassEvidence})" : "—")}");
        Line(sb, $"Powierzchnia jawna z dokumentacji: {(a.Drawing.DocumentSurfaceAreaM2.HasValue ? $"{a.Drawing.DocumentSurfaceAreaM2.Value:0.###} m² ({a.Drawing.DocumentSurfaceAreaConfidence}%)" : "—")}");
        Line(sb, $"Długość odczytanego tekstu: {a.Drawing.ExtractedTextLength}");
        if (a.Drawing.PdfPageCount > 0)
            Line(sb, $"Liczba arkuszy PDF: {a.Drawing.PdfPageCount}");
        if (a.Drawing.PageEvidence.Count > 0)
        {
            Line(sb, "Dowody wg arkuszy PDF (informacyjne, bez automatycznego przypisania do BOM):");
            foreach (var page in a.Drawing.PageEvidence.Take(40))
            {
                var ids = page.DrawingNumbers.Count > 0 ? Join(page.DrawingNumbers) : "—";
                var parts = page.BomPartNumbers.Count > 0 ? Join(page.BomPartNumbers) : "—";
                Line(sb, $"  {page.SourceFile}, arkusz {page.PageNumber}: rys. {ids}; " +
                    $"materiał {(string.IsNullOrWhiteSpace(page.MaterialHint) ? "—" : page.MaterialHint)}; " +
                    $"BOM {page.BomRowCount} pozycji ({parts}); " +
                    $"OCR {(page.OcrApplied ? (page.OcrTextPresent ? "odczytano" : "bez tekstu") : "nie wykonywano")}");
            }
            if (a.Drawing.PageEvidence.Count > 40)
                Line(sb, $"  ...pominięto w raporcie {a.Drawing.PageEvidence.Count - 40} kolejnych arkuszy z dowodami.");
        }
        if (a.Drawing.DrawingBomLinks.Count > 0)
        {
            Line(sb, "Zgodne numery rysunków i pozycji BOM (wyłącznie informacyjne):");
            foreach (var link in a.Drawing.DrawingBomLinks.Take(40))
                Line(sb, $"  {link.SourceFile}: rys. {link.DrawingNumber} (arkusz {link.DrawingPageNumber}) " +
                    $"= BOM {link.BomPartNumber} (arkusz {link.BomPageNumber}); " +
                    "bez automatycznego przypisania materiału, ilości i kosztu.");
            if (a.Drawing.DrawingBomLinks.Count > 40)
                Line(sb, $"  ...pominięto {a.Drawing.DrawingBomLinks.Count - 40} dalszych dopasowań.");
        }
        if (a.Drawing.DrawingStepLinks.Count > 0)
        {
            Line(sb, "PDF/BOM ↔ STEP (diagnostyka, zgodność numeru z NAZWĄ pliku; geometria niezweryfikowana):");
            foreach (var link in a.Drawing.DrawingStepLinks.Take(40))
                Line(sb, $"  {link.SourcePdf}: {link.DrawingNumber} (rys. arkusz {link.DrawingPageNumber}, " +
                    $"BOM arkusz {link.BomPageNumber}) ↔ {link.StepFile}; " +
                    "bez automatycznego przypisania materiału, ilości, operacji i kosztów.");
            if (a.Drawing.DrawingStepLinks.Count > 40)
                Line(sb, $"  ...pominięto {a.Drawing.DrawingStepLinks.Count - 40} dalszych powiązań STEP.");
        }
        if (a.Drawing.DrawingStepAmbiguousNumbers.Count > 0)
            Line(sb, $"Niejednoznaczne numery PDF/BOM↔STEP (bez dopasowania): " +
                Join(a.Drawing.DrawingStepAmbiguousNumbers.Take(40).ToList()));
        Line(sb, $"Rozpoznane języki: {Join(a.Drawing.DetectedLanguages)}");
        Line(sb, $"Silnik OCR: {(string.IsNullOrWhiteSpace(a.Drawing.OcrEnginePath) ? "(nie znaleziono / nie dotyczy)" : a.Drawing.OcrEnginePath)}");
        Line(sb, $"Języki OCR użyte: {(string.IsNullOrWhiteSpace(a.Drawing.OcrLanguagesUsed) ? "(nie dotyczy)" : a.Drawing.OcrLanguagesUsed)}");
        Line(sb, $"Pewność OCR średnia: {(a.Drawing.OcrMeanConfidence.HasValue ? $"{a.Drawing.OcrMeanConfidence.Value:0}%" : "—")}");
        Line(sb, $"Pewność OCR — dane krytyczne: {(a.Drawing.OcrCriticalConfidence.HasValue ? $"{a.Drawing.OcrCriticalConfidence.Value:0}%" : "—")}");
        if (a.Drawing.OcrLowConfidenceSignals.Count > 0)
            Line(sb, $"Niskopewne tokeny OCR: {Join(a.Drawing.OcrLowConfidenceSignals)}");
        if (a.Drawing.OcrCriticalConflicts.Count > 0)
            Line(sb, $"Konflikty cross-check OCR: {Join(a.Drawing.OcrCriticalConflicts)}");
        Line(sb, $"Sygnały / słowa kluczowe: {Join(a.Drawing.Keywords)}");
        Line(sb, $"Normy: {Join(a.Drawing.Norms)}");
        Line(sb, $"Proces spawania: {(string.IsNullOrWhiteSpace(a.Drawing.WeldProcessCode) ? "—" : a.Drawing.WeldProcessCode)}");
        Line(sb, $"Typ spoiny z dokumentacji: {(string.IsNullOrWhiteSpace(a.Drawing.WeldTypeHint) ? "—" : a.Drawing.WeldTypeHint)}");
        Line(sb, $"Wymiar spoiny: {(a.Drawing.WeldSizeMm.HasValue ? $"{a.Drawing.WeldSizeKind}{a.Drawing.WeldSizeMm.Value:0.##}" : "—")}");
        Line(sb, $"Strony spoiny: {(a.Drawing.WeldSideCount > 0 ? a.Drawing.WeldSideCount.ToString() : "—")}{(a.Drawing.WeldSideCountConfirmed ? " (potwierdzone)" : "")}");
        Line(sb, $"Spoina przerywana: {(a.Drawing.WeldIntermittent ? "TAK" : "NIE")}");
        Line(sb, $"Przygotowanie powierzchni: {(string.IsNullOrWhiteSpace(a.Drawing.SurfacePreparation) ? "—" : a.Drawing.SurfacePreparation)}");
        Line(sb, $"Klasa korozyjności: {(string.IsNullOrWhiteSpace(a.Drawing.CorrosionClass) ? "—" : a.Drawing.CorrosionClass)}");
        Line(sb, $"Kolor: {(string.IsNullOrWhiteSpace(a.Drawing.PaintColour) ? "—" : a.Drawing.PaintColour)}");
        Line(sb, $"Łączna DFT: {(a.Drawing.TotalDftMicron.HasValue ? $"{a.Drawing.TotalDftMicron.Value:0.#} µm" : "—")}");
        if (a.Drawing.DimensionalTolerances.Count > 0)
        {
            Line(sb, "Tolerancje wymiarowe:");
            foreach (var t in a.Drawing.DimensionalTolerances.Take(20))
            {
                var toleranceDisplay = t.SymmetricMm.HasValue
                    ? $"±{t.SymmetricMm.Value:0.###}"
                    : $"+{(t.PlusMm ?? 0):0.###}/-{(t.MinusMm ?? 0):0.###}";
                Line(sb, $"  - {t.Kind}: {toleranceDisplay} mm{(t.Tight ? " · PRECYZYJNA" : "")} · {t.SourceText}");
            }
        }
        if (a.Drawing.GeometricTolerances.Count > 0)
        {
            Line(sb, "Tolerancje kształtu i położenia:");
            foreach (var t in a.Drawing.GeometricTolerances.Take(20))
                Line(sb, $"  - {t.Type}: {(t.ValueMm.HasValue ? $"{t.ValueMm.Value:0.###} mm" : "wartość nieodczytana")}{(string.IsNullOrWhiteSpace(t.Datum) ? "" : $" · baza {t.Datum}")}{(t.Tight ? " · PRECYZYJNA" : "")} · {t.SourceText}");
        }

        if (a.Drawing.Findings.Count > 0)
        {
            Line(sb, "Ustalenia:");
            foreach (var item in a.Drawing.Findings)
                Line(sb, $"  - {item}");
        }

        if (a.Drawing.Warnings.Count > 0)
        {
            Line(sb, "Uwagi:");
            foreach (var item in a.Drawing.Warnings)
                Line(sb, $"  - {item}");
        }
        Line(sb, "");

        Section(sb, "DXF");
        Line(sb, $"Reader: {a.Dxf.Reader}");
        Line(sb, $"Warstwy: {a.Dxf.LayerCount}; kodowanie: {(string.IsNullOrWhiteSpace(a.Dxf.FileEncoding) ? "—" : a.Dxf.FileEncoding)}; format binarny: {(a.Dxf.BinaryFormat ? "TAK" : "NIE")}");
        Line(sb, $"Typy encji: {(string.IsNullOrWhiteSpace(a.Dxf.EntityTypeSummary) ? "—" : a.Dxf.EntityTypeSummary)}");
        Line(sb, $"Zakres/extents: {(string.IsNullOrWhiteSpace(a.Dxf.ExtentsSummary) ? "—" : a.Dxf.ExtentsSummary)}");
        Line(sb, $"Tylko referencja/XREF prawdopodobna: {(a.Dxf.ReferenceOnlyLikely ? "TAK" : "NIE")}");
        if (!string.IsNullOrWhiteSpace(a.Dxf.DiagnosticSummary))
            Line(sb, $"DXF_DIAG: {a.Dxf.DiagnosticSummary}");
        Line(sb, $"LINE: {a.Dxf.Lines}");
        Line(sb, $"ARC: {a.Dxf.Arcs}");
        Line(sb, $"CIRCLE: {a.Dxf.Circles}");
        Line(sb, $"POLYLINE/LWPOLYLINE: {a.Dxf.Polylines}");
        Line(sb, $"SPLINE: {a.Dxf.Splines}");
        Line(sb, $"ELLIPSE: {a.Dxf.Ellipses}");
        Line(sb, $"HATCH: {a.Dxf.Hatches}");
        Line(sb, $"INSERT: {a.Dxf.Inserts}");
        Line(sb, $"DIMENSION: {a.Dxf.Dimensions}");
        Line(sb, $"TEXT/MTEXT/ATTRIB: {a.Dxf.TextEntities}");
        Line(sb, $"Inne encje: {a.Dxf.OtherEntities}");
        Line(sb, $"Razem elementów: {a.Dxf.EntityCount}");
        Line(sb, $"Długość geometrii cięcia: {a.Dxf.CutLengthMm / 1000.0:0.###} m ({a.Dxf.CutGeometryEntityCount} encji cięcia)");
        Line(sb, $"Geometria znakowania/etch: {a.Dxf.MarkingLengthMm / 1000.0:0.###} m");
        Line(sb, $"Pominięta geometria pomocnicza: {a.Dxf.IgnoredNonCutLengthMm / 1000.0:0.###} m");
        Line(sb, $"Kontury zamknięte: {a.Dxf.ClosedProfileCount}");
        Line(sb, $"Otwarte komponenty geometrii: {a.Dxf.OpenPathCount}");
        Line(sb, $"Minimalna liczba przebić: {a.Dxf.MinimumPierceCount}");
        Line(sb, $"Jednostki DXF: {(string.IsNullOrWhiteSpace(a.Dxf.DrawingUnits) ? "—" : a.Dxf.DrawingUnits)}; pomiar wiarygodny: {(a.Dxf.GeometryMeasurementReliable ? "TAK" : "NIE")}");
        Line(sb, $"Tekst DXF: {a.Dxf.ExtractedTextLength} znaków");
        if (a.Dxf.Warnings.Count > 0)
        {
            Line(sb, "Uwagi DXF:");
            foreach (var item in a.Dxf.Warnings)
                Line(sb, $"  - {item}");
        }
        Line(sb, "");

        Section(sb, "FIX13 / CNC FEATURE MODEL");
        var cf = a.CncFeatures;
        Line(sb, $"Rodziny obrabiane: {cf.MachinedFamilyCount} | setupy: {cf.SetupCount} | kieszenie-kandydaci: {cf.PocketCandidateCount} | złożoność: {cf.ComplexityScore}/100 | pewność {cf.Confidence}%");
        Line(sb, $"Otwory: precyzyjne {cf.PrecisionHoleCount}, wiercone {cf.DrilledHoleCount}, rozwiercane {cf.ReamedHoleCount}, gwintowane {cf.ThreadedHoleCount}, wytaczane {cf.BoredHoleCount}, wtórne {cf.SecondaryOperationCount}");
        Line(sb, $"Tolerancje ciasne: wymiarowe {cf.TightDimensionalToleranceCount}, geometryczne {cf.TightGeometricToleranceCount}; powierzchnie ukosowane: {cf.BevelFaceCount}");
        Line(sb, $"Następna czynność: {(string.IsNullOrWhiteSpace(cf.NextAction) ? "—" : cf.NextAction)}");
        Line(sb, $"Podstawa: {(string.IsNullOrWhiteSpace(cf.Basis) ? "—" : cf.Basis)}");
        Line(sb, "");

        Section(sb, "MODEL SPAWANIA");
        var w = a.Welding;
        Line(sb, $"Aktywny: {(w.Enabled ? "TAK" : "NIE")}");
        Line(sb, $"Źródło: {w.Source}");
        Line(sb, $"Typ: {w.Type}");
        Line(sb, $"Proces ISO 4063: {w.ProcessCode}{(w.ProcessAssumed ? " (założony)" : "")}");
        Line(sb, $"Wymiar: {w.SizeKind}{w.SizeMm:0.##}{(w.SizeAssumed ? " (założony)" : "")}");
        Line(sb, $"Długość geometryczna: {w.GeometricLengthM:0.###} m");
        Line(sb, $"Liczba stron: {w.SideCount}{(w.SideCountConfirmed ? " (potwierdzona)" : " (domyślna)")}");
        Line(sb, $"Długość efektywna: {w.EffectiveLengthM:0.###} m");
        Line(sb, $"Spoina przerywana: {(w.Intermittent ? "TAK" : "NIE")}");
        Line(sb, $"Pole przekroju modelowego: {w.CrossSectionMm2:0.###} mm2");
        Line(sb, $"Metal spoiny: {w.WeldMetalMassKg:0.###} kg");
        Line(sb, $"Spoiwo z uwzględnieniem sprawności: {w.FillerMetalKg:0.###} kg");
        Line(sb, $"Liczba ściegów (model): {w.NumberOfPasses}");
        Line(sb, $"Wydajność depozycji: {w.DepositionRateKgH:0.###} kg/h");
        Line(sb, $"Czas łuku: {w.ArcHours:0.###} h");
        Line(sb, $"Obsługa / dopasowanie: {w.HandlingHours:0.###} h");
        Line(sb, $"Czas razem: {w.TotalHours:0.###} h");
        Line(sb, $"Koszt spoiwa: {w.ConsumableCostPln:0.##} PLN");
        Line(sb, $"Pewność: {w.Confidence}%");
        Line(sb, $"Podstawa: {w.Basis}");
        if (w.FamilyBreakdown.Count > 0)
        {
            Line(sb, $"FIX13 spoiny per rodzina: {(w.FamilyScoped ? "AKTYWNE W KOSZCIE" : "AUDYT / FALLBACK")} · {w.FamilyBreakdown.Count} profili");
            foreach (var fw in w.FamilyBreakdown.OrderByDescending(x => x.WeldMetalMassKg).Take(80))
                Line(sb, $"  - {fw.FamilyKey}: {fw.SizeKind}{fw.SizeMm:0.##} | ISO 4063 {fw.ProcessCode} | L={fw.LengthM:0.###} m × qty {fw.Quantity:0.###} | metal {fw.WeldMetalMassKg:0.###} kg | łuk {fw.ArcHours:0.###} h | pewność {fw.Confidence}%");
        }
        Line(sb, "");

        Section(sb, "MODEL MALOWANIA");
        var paint = a.Painting;
        Line(sb, $"Aktywny: {(paint.Enabled ? "TAK" : "NIE")}");
        Line(sb, $"Przygotowanie wymagane: {(paint.SurfacePreparationRequired ? "TAK" : "NIE")}");
        Line(sb, $"Powłoka malarska wymagana: {(paint.CoatingRequired ? "TAK" : "NIE")}");
        Line(sb, $"Przygotowanie: {(string.IsNullOrWhiteSpace(paint.SurfacePreparation) ? "—" : paint.SurfacePreparation)}");
        Line(sb, $"Klasa: {(string.IsNullOrWhiteSpace(paint.CorrosionClass) ? "—" : paint.CorrosionClass)}");
        Line(sb, $"Kolor: {(string.IsNullOrWhiteSpace(paint.Colour) ? "—" : paint.Colour)}");
        Line(sb, $"Zakres malowania: {paint.ScopeDisplay}");
        Line(sb, $"Wnętrza wliczone: {paint.InternalAreaIncludedM2:0.###} m2");
        Line(sb, $"Malowanie wnętrz przed zamknięciem: {(paint.PreAssemblyInternalPaintingRequired ? "TAK" : "NIE")}");
        if (paint.PreAssemblyInternalPaintingRequired)
            Line(sb, $"  - powierzchnia przed zamknięciem: {paint.PreAssemblyInternalAreaM2:0.###} m2 · dodatkowa obsługa: {paint.PreAssemblyHandlingHours:0.###} h");
        Line(sb, $"Powierzchnia brutto: {paint.GrossAreaM2:0.###} m2");
        Line(sb, $"Ukryte styki: {paint.HiddenContactAreaM2:0.###} m2");
        Line(sb, $"Zamknięte / niedostępne wnętrza: {paint.ClosedInternalAreaM2:0.###} m2");
        Line(sb, $"Powierzchnia do malowania: {paint.PaintableAreaM2:0.###} m2");
        Line(sb, $"Źródło powierzchni: {(string.IsNullOrWhiteSpace(paint.AreaSource) ? "—" : paint.AreaSource)}");
        Line(sb, $"Pewność / pokrycie powierzchni: {paint.AreaConfidence}% / {paint.AreaCoveragePercent:0.#}%");
        Line(sb, $"DFT: {paint.TotalDftMicron:0.#} µm{(paint.DftAssumed ? " (założona)" : "")}");
        Line(sb, $"Liczba warstw: {paint.LayerCount}");
        Line(sb, $"Kompletność systemu powłok: {paint.SystemCompletenessPercent}%");
        Line(sb, $"Kompletność — podstawa: {(string.IsNullOrWhiteSpace(paint.SystemCompletenessBasis) ? "—" : paint.SystemCompletenessBasis)}");
        if (paint.Layers.Count > 0)
        {
            foreach (var layer in paint.Layers)
            {
                Line(sb, $"  - {layer.Name}: {layer.DftMicron:0.#} µm · {layer.LitersWithLoss:0.###} l ze stratami · {layer.MaterialCostPln:0.##} PLN");
            }
        }
        Line(sb, $"Części stałe objętościowo: {paint.VolumeSolidsPercent:0.#}%");
        Line(sb, $"Straty technologiczne: {paint.LossPercent:0.#}%");
        Line(sb, $"Wydajność teoretyczna: {paint.TheoreticalCoverageM2PerL:0.###} m2/l");
        Line(sb, $"Farba teoretycznie: {paint.PaintLitersTheoretical:0.###} l");
        Line(sb, $"Farba ze stratami: {paint.PaintLitersWithLoss:0.###} l");
        Line(sb, $"Przygotowanie powierzchni: {paint.SurfacePrepHours:0.###} h");
        Line(sb, $"Aplikacja: {paint.ApplicationHours:0.###} h");
        Line(sb, $"Czas razem: {paint.TotalHours:0.###} h");
        Line(sb, $"Koszt farby: {paint.PaintMaterialCostPln:0.##} PLN");
        Line(sb, $"Pewność: {paint.Confidence}%");
        Line(sb, $"Podstawa: {paint.Basis}");
        Line(sb, "");

        Section(sb, "PROCES PRODUKCYJNY");
        if (a.Processes.Count == 0)
        {
            Line(sb, "(brak)");
        }
        else
        {
            foreach (var p in a.Processes)
            {
                Line(sb, $"- {p.Name}");
                Line(sb, $"  Kod: {p.Code}");
                Line(sb, $"  Aktywny: {(p.Enabled ? "TAK" : "NIE")}");
                Line(sb, $"  Stanowisko: {(string.IsNullOrWhiteSpace(p.WorkstationName) ? "—" : p.WorkstationName)}");
                Line(sb, $"  Czas bazowy: {(p.BaseHours > 0 ? p.BaseHours : p.Hours):0.###} h");
                Line(sb, $"  Kalibracja: ×{p.CalibrationFactor:0.###}");
                Line(sb, $"  Czas: {p.Hours:0.###} h");
                Line(sb, $"  Stawka: {p.RatePlnPerHour:0.##} PLN/h");
                Line(sb, $"  Koszt: {p.CostPln:0.##} PLN");
                Line(sb, $"  Pewność: {p.Confidence}%");
                Line(sb, $"  Podstawa: {p.Basis}");
            }
        }
        Line(sb, "");

        Section(sb, "KOSZT");
        Line(sb, $"Materiał: {a.MaterialCostPln:0.##} PLN");
        Line(sb, $"Materiały technologiczne (spoiwo + farba): {a.TechnologyMaterialCostPln:0.##} PLN");
        Line(sb, $"Procesy: {a.ProcessCostPln:0.##} PLN");
        Line(sb, $"Usługi zewnętrzne: {a.ExternalCostPln:0.##} PLN");
        Line(sb, $"Koszt razem: {a.CostTotalPln:0.##} PLN");
        Line(sb, $"Cena technologiczna: {a.TechnicalPricePln:0.##} PLN");
        Line(sb, $"Cena historyczna: {FmtMoney(a.HistoricalPricePln)}");
        if (a.AutoQuote.RecommendedPricePln > 0)
            Line(sb, $"{a.AutoQuote.PriceLabel}: {a.AutoQuote.RecommendedPricePln:0.##} PLN");
        else
            Line(sb, $"{a.AutoQuote.PriceLabel}: — (koszt rozpoznanego zakresu {a.AutoQuote.RecognizedCostPln:0.##} PLN pozostaje diagnostyczny)");
        Line(sb, "");

        Section(sb, "FIX13 / PEWNOŚĆ SKŁADNIKÓW KOSZTU");
        if (a.CostConfidence.Count == 0)
        {
            Line(sb, "(brak)");
        }
        else
        {
            foreach (var c in a.CostConfidence)
            {
                Line(sb, $"- {c.Code} | {c.Name}: {c.AmountPln:0.##} PLN | udział {c.SharePercent:0.#}% | pewność {c.Confidence}%");
                Line(sb, $"  Co podnieść: {(string.IsNullOrWhiteSpace(c.NextAction) ? "—" : c.NextAction)}");
                Line(sb, $"  Podstawa: {c.Basis}");
            }
        }
        Line(sb, "");

        Section(sb, "FIX14 / SANITY CHECK");
        if (a.SanityChecks.Count == 0)
            Line(sb, "Brak dodatkowych anomalii spójności wyniku.");
        else
            foreach (var x in a.SanityChecks.OrderByDescending(x => x.Level))
                Line(sb, $"- [{x.Level}] {x.Code}: {x.Message} | {x.Basis}");
        Line(sb, "");

        Section(sb, "RYZYKA");
        if (a.Risks.Count == 0)
        {
            Line(sb, "(brak)");
        }
        else
        {
            foreach (var r in a.Risks.OrderByDescending(x => x.Level))
            {
                Line(sb, $"- [{r.Level}] {r.Title}");
                Line(sb, $"  Kod: {r.Code}");
                Line(sb, $"  Blokujące: {(r.Blocking ? "TAK" : "NIE")}");
                Line(sb, $"  Opis: {r.Message}");
            }
        }
        Line(sb, "");

        Section(sb, "PODOBNE PROJEKTY");
        if (a.SimilarProjects.Count == 0)
        {
            Line(sb, "(brak)");
        }
        else
        {
            foreach (var s in a.SimilarProjects)
            {
                Line(sb,
                    $"- {s.Name} | klient: {s.Customer} | podobieństwo: {s.SimilarityPercent:0.#}% | masa: {Fmt(s.WeightKg)} kg | cena: {s.FinalPricePln:0.##} PLN");
                if (!string.IsNullOrWhiteSpace(s.SimilarityBasis))
                    Line(sb, $"  Podobieństwo: {s.SimilarityBasis}");
            }
        }
        Line(sb, "");

        Section(sb, "RZECZYWISTE WYKONANIE (JEŚLI UZUPEŁNIONE)");
        Line(sb, $"Cięcie: {project.Actuals.CuttingHours:0.###} h");
        Line(sb, $"Spawanie: {project.Actuals.WeldingHours:0.###} h");
        Line(sb, $"CNC: {project.Actuals.MachiningHours:0.###} h");
        Line(sb, $"Powierzchnia: {project.Actuals.SurfaceHours:0.###} h");
        Line(sb, $"Montaż: {project.Actuals.AssemblyHours:0.###} h");
        Line(sb, $"Koszt rzeczywisty: {project.Actuals.ActualTotalCostPln:0.##} PLN");
        if (project.Actuals.SskHours.Count > 0)
            Line(sb, "SSK rzeczywiste: " + string.Join(" · ", project.Actuals.SskHours
                .Where(x => x.Value > 0)
                .OrderBy(x => x.Key)
                .Select(x => $"{x.Key}={x.Value:0.###} h")));
        Line(sb, $"Notatka: {project.Actuals.Note}");
        Line(sb, "");

        Section(sb, "USTAWIENIA MODELU");
        Line(sb, $"Domyślna gęstość stali: {settings.DefaultSteelDensityKgM3:0.###} kg/m3");
        Line(sb, $"Cena materiału: {settings.MaterialPricePlnKg:0.###} PLN/kg");
        Line(sb, $"Naddatek materiału: {settings.MaterialWastePercent:0.###}%");
        Line(sb, $"Cięcie: {settings.CuttingRatePlnH:0.###} PLN/h");
        Line(sb, $"Spawanie: {settings.WeldingRatePlnH:0.###} PLN/h");
        Line(sb, $"CNC: {settings.MachiningRatePlnH:0.###} PLN/h");
        Line(sb, $"Malowanie: {settings.PaintingRatePlnH:0.###} PLN/h");
        Line(sb, $"Montaż: {settings.AssemblyRatePlnH:0.###} PLN/h");
        Line(sb, $"Narzut: {settings.MarkupPercent:0.###}%");
        Line(sb, $"Wpływ historii: {settings.HistoricalBlendPercent:0.###}%");
        Line(sb, $"Domyślna spoina: a{settings.DefaultWeldSizeAmm:0.##}, proces {settings.DefaultWeldProcessCode}");
        Line(sb, $"Spoiwo: {settings.WeldConsumablePricePlnKg:0.##} PLN/kg, sprawność {settings.WeldConsumableEfficiencyPercent:0.#}%");
        Line(sb, $"Depozycja 111/135/136: {settings.WeldDepositionRate111KgH:0.##} / {settings.WeldDepositionRate135KgH:0.##} / {settings.WeldDepositionRate136KgH:0.##} kg/h");
        Line(sb, $"Domyślna DFT: {settings.DefaultPaintDftMicron:0.#} µm");
        Line(sb, $"Części stałe farby: {settings.DefaultPaintVolumeSolidsPercent:0.#}%");
        Line(sb, $"Straty farby: {settings.PaintLossPercent:0.#}%");
        Line(sb, $"Cena farby: {settings.PaintPricePlnL:0.##} PLN/l");
        Line(sb, $"Wydajność przygotowania / aplikacji: {settings.SurfacePrepM2PerHour:0.##} / {settings.PaintApplicationM2PerHour:0.##} m2/h");
        Line(sb, "");

        Section(sb, "KONIEC RAPORTU");
        Line(sb, "Raport służy do diagnostyki i porównania wyniku DS Estimate z dokumentacją źródłową.");

        File.WriteAllText(path, sb.ToString(), new UTF8Encoding(true));
    }

    private static void Section(StringBuilder sb, string title) =>
        Line(sb, $"=== {title} ===");

    private static void Line(StringBuilder sb, string value) =>
        sb.AppendLine(value);

    private static string Fmt(double? value) =>
        value.HasValue
            ? value.Value.ToString("0.###", CultureInfo.InvariantCulture)
            : "brak";

    private static string FmtMoney(double? value) =>
        value.HasValue
            ? value.Value.ToString("0.##", CultureInfo.InvariantCulture) + " PLN"
            : "brak";

    private static string Join(IEnumerable<string> values)
    {
        var list = values.Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
        return list.Count == 0 ? "(brak)" : string.Join(", ", list);
    }
}
