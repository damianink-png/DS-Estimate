﻿using System.IO.Compression;
using System.Text;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

/// <summary>
/// FIX14: writes a deliberately small, source-free crash package. It contains no
/// customer documents, extracted drawing text, paths to source files or OCR images.
/// </summary>
public static class CrashDiagnosticService
{
    public static string Write(Exception exception, string stage, AnalysisResult? analysis = null)
    {
        try
        {
            var root = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "DSEstimateNext",
                "crash");
            Directory.CreateDirectory(root);

            var stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");
            var safeStage = SanitizeToken(stage);
            var zipPath = Path.Combine(root, $"DS_Estimate_CRASH_{stamp}_{safeStage}.zip");
            var memory = ResourceGovernor.GetSnapshot();

            using var archive = ZipFile.Open(zipPath, ZipArchiveMode.Create);
            WriteEntry(archive, "crash.txt", BuildCrashText(exception, stage));
            WriteEntry(archive, "environment.txt", BuildEnvironmentText(memory));
            var workerLifecycle = ReadWorkerLifecycle();
            if (!string.IsNullOrWhiteSpace(workerLifecycle))
                WriteEntry(archive, "step_worker_lifecycle.txt", workerLifecycle);
            if (analysis is not null)
                WriteEntry(archive, "analysis_summary.txt", BuildAnalysisSummary(analysis));

            return zipPath;
        }
        catch
        {
            return "nie udało się utworzyć pakietu diagnostycznego";
        }
    }

    private static string BuildCrashText(Exception ex, string stage)
    {
        var sb = new StringBuilder();
        sb.AppendLine("DS Estimate 1.2 - crash diagnostic (FIX14)");
        sb.AppendLine($"Timestamp: {DateTime.Now:O}");
        sb.AppendLine($"Stage: {SanitizeLine(stage)}");
        sb.AppendLine($"Exception: {ex.GetType().FullName}");
        sb.AppendLine($"Message: {SanitizeLine(ex.Message)}");
        if (ex.InnerException is not null)
        {
            sb.AppendLine($"Inner: {ex.InnerException.GetType().FullName}");
            sb.AppendLine($"InnerMessage: {SanitizeLine(ex.InnerException.Message)}");
        }
        sb.AppendLine();
        sb.AppendLine("Stack trace (paths reduced):");
        sb.AppendLine(SanitizeStack(ex.StackTrace));
        return sb.ToString();
    }

    private static string BuildEnvironmentText(ResourceGovernor.Snapshot memory)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"OS: {Environment.OSVersion.VersionString}");
        sb.AppendLine($"64-bit OS/process: {Environment.Is64BitOperatingSystem}/{Environment.Is64BitProcess}");
        sb.AppendLine($"CPU logical: {Environment.ProcessorCount}");
        sb.AppendLine($".NET: {Environment.Version}");
        sb.AppendLine($"Working set MB: {memory.WorkingSetBytes / 1024d / 1024d:0}");
        sb.AppendLine($"Physical total MB: {memory.TotalPhysicalBytes / 1024d / 1024d:0}");
        sb.AppendLine($"Physical free MB: {memory.AvailablePhysicalBytes / 1024d / 1024d:0}");
        sb.AppendLine($"Memory load: {memory.MemoryLoadPercent:0.#}%");
        return sb.ToString();
    }

    private static string BuildAnalysisSummary(AnalysisResult a)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"AnalyzedAt: {a.AnalyzedAt:O}");
        sb.AppendLine($"GeometryAvailable: {a.Geometry.Available}");
        sb.AppendLine($"SolidCount: {a.Geometry.SolidCount}");
        sb.AppendLine($"UniqueGroups: {a.Geometry.UniquePartGroups}");
        sb.AppendLine($"RootBomFamilies: {a.Drawing.ResolvedRootBomFamilyCount}");
        sb.AppendLine($"StepFamilyCoverage: {a.Drawing.ResolvedStepFamilyMatchCount}/{a.Drawing.ResolvedRootBomFamilyCount}");
        sb.AppendLine($"DxfFamilyCoverage: {a.Drawing.ResolvedDxfFamilyMatchCount}/{a.Drawing.ResolvedRootBomFamilyCount}");
        sb.AppendLine($"HasWeight: {a.HasWeight}");
        sb.AppendLine($"WeightSource: {SanitizeLine(a.WeightSource)}");
        sb.AppendLine($"HybridMassCoverage: {a.Drawing.HybridMassCoveragePercent:0.#}%");
        sb.AppendLine($"HybridSurfaceCoverage: {a.Drawing.HybridSurfaceAreaCoveragePercent:0.#}%");
        sb.AppendLine($"ProcessCount: {a.Processes.Count}");
        sb.AppendLine($"RiskCount/Blocking: {a.Risks.Count}/{a.Risks.Count(x => x.Blocking)}");
        sb.AppendLine($"AutoQuoteStatus: {SanitizeLine(a.AutoQuote.Status)}");
        sb.AppendLine($"OfferPriceAvailable: {a.AutoQuote.HasRecommendedPrice}");
        sb.AppendLine($"RecognizedCostPln: {a.AutoQuote.RecognizedCostPln:0.##}");
        return sb.ToString();
    }

    private static void WriteEntry(ZipArchive archive, string name, string content)
    {
        var entry = archive.CreateEntry(name, CompressionLevel.Fastest);
        using var writer = new StreamWriter(entry.Open(), new UTF8Encoding(false));
        writer.Write(content);
    }

    private static string ReadWorkerLifecycle()
    {
        try
        {
            var path = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "DSEstimateNext", "logs", "step_worker_lifecycle.log");
            if (!File.Exists(path)) return "";
            return string.Join(Environment.NewLine, File.ReadLines(path).TakeLast(100));
        }
        catch
        {
            return "";
        }
    }

    private static string SanitizeStack(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "(brak)";
        var lines = value.Replace('\r', '\n').Split('\n', StringSplitOptions.RemoveEmptyEntries);
        return string.Join(Environment.NewLine, lines.Take(80).Select(line =>
        {
            var at = line.IndexOf(" in ", StringComparison.OrdinalIgnoreCase);
            return at >= 0 ? line[..at] : line;
        }));
    }

    private static string SanitizeLine(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "";
        var clean = value.Replace('\r', ' ').Replace('\n', ' ').Trim();
        return clean.Length <= 500 ? clean : clean[..500] + "…";
    }

    private static string SanitizeToken(string? value)
    {
        var chars = (value ?? "unknown").Where(c => char.IsLetterOrDigit(c) || c is '-' or '_').ToArray();
        return chars.Length == 0 ? "unknown" : new string(chars);
    }
}
