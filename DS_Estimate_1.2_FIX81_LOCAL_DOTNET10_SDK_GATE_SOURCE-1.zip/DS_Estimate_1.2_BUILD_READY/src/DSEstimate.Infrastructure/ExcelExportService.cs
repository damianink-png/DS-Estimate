using ClosedXML.Excel;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

public sealed class ExcelExportService
{
    public void Export(QuoteProject project, string path)
    {
        using var wb = new XLWorkbook();
        WriteSummary(wb, project);
        WriteScenarios(wb, project);
        WriteParts(wb, project);
        WriteProcesses(wb, project);
        WriteHierarchy(wb, project);
        WriteRuleEngine(wb, project);
        WritePlanActual(wb, project);
        WriteRisks(wb, project);
        WriteConflicts(wb, project);
        wb.SaveAs(path);
    }

    private static void WriteSummary(XLWorkbook wb, QuoteProject p)
    {
        var ws = wb.Worksheets.Add("Wycena");
        var a = p.Analysis;

        ws.Cell("A1").Value = "DS Estimate 1.0 — wycena";
        ws.Cell("A1").Style.Font.Bold = true;
        ws.Cell("A1").Style.Font.FontSize = 18;

        ws.Cell("A3").Value = "Projekt";
        ws.Cell("B3").Value = p.Name;
        ws.Cell("A4").Value = "Klient";
        ws.Cell("B4").Value = p.Customer;
        ws.Cell("A5").Value = "Rewizja";
        ws.Cell("B5").Value = p.Revision;
        ws.Cell("A6").Value = "Data";
        ws.Cell("B6").Value = p.ModifiedAt;

        if (a is not null)
        {
            ws.Cell("A8").Value = "Materiał";
            ws.Cell("B8").Value = a.Material;
            ws.Cell("A9").Value = "Masa [kg]";
            ws.Cell("B9").Value = a.WeightKg ?? 0;
            ws.Cell("A10").Value = "Gotowość";
            ws.Cell("B10").Value = a.ReadinessPercent / 100.0;
            ws.Cell("B10").Style.NumberFormat.Format = "0%";

            ws.Cell("A12").Value = "Koszt materiału";
            ws.Cell("B12").Value = a.MaterialCostPln;
            ws.Cell("A13").Value = "Koszt procesów";
            ws.Cell("B13").Value = a.ProcessCostPln;
            ws.Cell("A14").Value = "Koszt modelowany / should-cost";
            ws.Cell("B14").Value = a.CostTotalPln;
            ws.Cell("A15").Value = "Cena technologiczna po narzucie";
            ws.Cell("B15").Value = a.TechnicalPricePln;
            ws.Cell("A16").Value = "Referencja historyczna";
            ws.Cell("B16").Value = a.HistoricalPricePln ?? 0;
            ws.Cell("A17").Value = a.AutoQuote.PriceLabel;
            if (a.AutoQuote.HasRecommendedPrice)
                ws.Cell("B17").Value = a.AutoQuote.RecommendedPricePln;
            else
                ws.Cell("B17").Value = "NIE WYZNACZONO";
            ws.Cell("A18").Value = "Profil stawek";
            ws.Cell("B18").Value = a.PricingProfileName;
            ws.Cell("A19").Value = "Stawki firmowo potwierdzone";
            ws.Cell("B19").Value = a.RatesConfirmedByCompany ? "TAK" : "NIE - ROBOCZE";
            ws.Cell("A20").Value = "Konflikty danych";
            ws.Cell("B20").Value = a.Drawing.Conflicts.Count(x => !x.IsLocalVariation);
            ws.Cell("A21").Value = "Rewizje";
            ws.Cell("B21").Value = a.Package.RevisionSummary;
            ws.Cell("A22").Value = "Koszt rozpoznanego zakresu";
            ws.Cell("B22").Value = a.AutoQuote.RecognizedCostPln;
            ws.Cell("A23").Value = "Rozpoznany materiał / pokrycie";
            ws.Cell("B23").Value = $"{a.AutoQuote.RecognizedMaterialCostPln:0.##} PLN / {a.AutoQuote.RecognizedMaterialCoveragePercent:0.#}% / nierozwiązane rodziny {a.AutoQuote.UnresolvedFamilyCount}";
            ws.Cell("A24").Value = "P50 / zakres ryzyka";
            ws.Cell("B24").Value = a.AutoQuote.HasRecommendedPrice ? a.AutoQuote.PriceRangeDisplay : "NIE WYZNACZONO";
            ws.Cell("A25").Value = "Niepewność";
            ws.Cell("B25").Value = a.AutoQuote.UncertaintyPercent / 100.0;
            ws.Cell("B25").Style.NumberFormat.Format = "0.0%";
            ws.Cell("A26").Value = "Wiek cenników";
            ws.Cell("B26").Value = a.PriceAgeWarnings.Count == 0 ? "OK" : string.Join(" | ", a.PriceAgeWarnings.Select(x => x.Message));
            ws.Cell("A27").Value = "Kalibracja";
            ws.Cell("B27").Value = a.ExternalCalibration.Summary;
            ws.Cell("A28").Value = "Gięcie / walcowanie";
            ws.Cell("B28").Value = a.SheetMetal.Summary;
            ws.Cell("A30").Value = "Tryb wydania";
            ws.Cell("B30").Value = p.FrozenSnapshot?.ReleaseMode ?? "BRAK SNAPSHOTU";
            ws.Cell("A31").Value = "Odcisk wydanej oferty SHA-256";
            ws.Cell("B31").Value = p.FrozenSnapshot?.Fingerprint ?? "";
            ws.Cell("A32").Value = "Snapshot utworzono";
            if (p.FrozenSnapshot is not null)
                ws.Cell("B32").Value = p.FrozenSnapshot.CreatedAt;
            ws.Cell("A33").Value = "Hash dokumentów / analiza / ustawienia / kalibracja / silniki";
            ws.Cell("B33").Value = p.FrozenSnapshot is null
                ? ""
                : $"DOC {p.FrozenSnapshot.DocumentHashes.Count} · ANA {Short(p.FrozenSnapshot.AnalysisHash)} · SET {Short(p.FrozenSnapshot.SettingsHash)} · CAL {Short(p.FrozenSnapshot.CalibrationHash)} · ENG {Short(p.FrozenSnapshot.EngineHash)} · AUD {Short(p.FrozenSnapshot.ReleaseAuditHash)}";
            ws.Cell("A34").Value = "Wyjątek audytowany";
            ws.Cell("B34").Value = p.FrozenSnapshot?.ReleaseMode == "WYJĄTEK AUDYTOWANY"
                ? $"{p.ReleaseOverride?.ApprovedAt:yyyy-MM-dd HH:mm:ss} · {p.ReleaseOverride?.ApprovedBy} · {p.ReleaseOverride?.Reason}"
                : "NIE";
            ws.Cell("A17").Style.Font.Bold = true;
            ws.Cell("B17").Style.Font.Bold = true;
        }

        ws.Columns().AdjustToContents();
    }

    private static string Short(string? value) => string.IsNullOrWhiteSpace(value) ? "BRAK" : value.Length > 12 ? value[..12] : value;

    private static void WriteScenarios(XLWorkbook wb, QuoteProject p)
    {
        var ws = wb.Worksheets.Add("Scenariusze what-if");
        string[] headers = ["Scenariusz", "Założenie", "Koszt [PLN]", "Delta kosztu [PLN]", "Cena P50 [PLN]", "Delta ceny [PLN]", "Delta ceny [%]", "Cena dostępna"];
        for (var i = 0; i < headers.Length; i++) ws.Cell(1, i + 1).Value = headers[i];
        ws.Range(1, 1, 1, headers.Length).Style.Font.Bold = true;
        var row = 1;
        foreach (var item in p.Analysis?.QuoteScenarios ?? [])
        {
            row++;
            ws.Cell(row, 1).Value = item.Name;
            ws.Cell(row, 2).Value = item.Assumption;
            ws.Cell(row, 3).Value = item.CostPln;
            ws.Cell(row, 4).Value = item.DeltaCostPln;
            if (item.HasOfferPrice) ws.Cell(row, 5).Value = item.PricePln;
            else ws.Cell(row, 5).Value = "NIE WYZNACZONO";
            ws.Cell(row, 6).Value = item.DeltaPricePln;
            ws.Cell(row, 7).Value = item.DeltaPercent / 100.0;
            ws.Cell(row, 7).Style.NumberFormat.Format = "+0.0%;-0.0%;0.0%";
            ws.Cell(row, 8).Value = !item.HasOfferPrice ? "NIE" : item.IsPriceComplete ? "TAK" : "CZĘŚCIOWA";
        }
        row += 2;
        ws.Cell(row, 1).Value = "Blachy gięte / walcowane";
        ws.Cell(row, 2).Value = p.Analysis?.SheetMetal.Summary ?? "brak analizy";
        ws.Cell(row + 1, 1).Value = "Następna czynność";
        ws.Cell(row + 1, 2).Value = p.Analysis?.SheetMetal.NextAction ?? "";
        ws.Columns().AdjustToContents();
        ws.Column(2).Width = Math.Min(90, Math.Max(ws.Column(2).Width, 45));
        ws.Column(2).Style.Alignment.WrapText = true;
    }

    private static void WriteParts(XLWorkbook wb, QuoteProject p)
    {
        var ws = wb.Worksheets.Add("Detale");
        string[] headers =
        [
            "Detal", "Źródło", "Typ", "Ilość", "X", "Y", "Z",
            "Masa grupy [kg]", "Otwory", "Ukosy", "Ściany", "Krawędzie"
        ];

        for (var i = 0; i < headers.Length; i++)
            ws.Cell(1, i + 1).Value = headers[i];

        ws.Range(1, 1, 1, headers.Length).Style.Font.Bold = true;

        var row = 1;
        foreach (var part in p.Analysis?.Geometry.Parts ?? [])
        {
            row++;
            ws.Cell(row, 1).Value = part.Name;
            ws.Cell(row, 2).Value = part.SourceFile;
            ws.Cell(row, 3).Value = part.Classification;
            ws.Cell(row, 4).Value = part.Quantity;
            ws.Cell(row, 5).Value = part.Xmm;
            ws.Cell(row, 6).Value = part.Ymm;
            ws.Cell(row, 7).Value = part.Zmm;
            ws.Cell(row, 8).Value = part.MassKgEach * part.Quantity;
            ws.Cell(row, 9).Value = part.Holes.Sum(x => x.Count);
            ws.Cell(row, 10).Value = part.Bevel.Count;
            ws.Cell(row, 11).Value = part.FaceCount;
            ws.Cell(row, 12).Value = part.EdgeCount;
        }

        ws.Columns().AdjustToContents(8, 45);
    }

    private static void WriteProcesses(XLWorkbook wb, QuoteProject p)
    {
        var ws = wb.Worksheets.Add("Proces");
        string[] headers = ["Proces", "Stanowisko", "Aktywny", "Godziny bazowe", "Kalibracja", "Godziny", "Stawka", "Koszt", "Pewność", "Podstawa"];

        for (var i = 0; i < headers.Length; i++)
            ws.Cell(1, i + 1).Value = headers[i];

        ws.Range(1, 1, 1, headers.Length).Style.Font.Bold = true;

        var row = 1;
        foreach (var process in p.Analysis?.Processes ?? [])
        {
            row++;
            ws.Cell(row, 1).Value = process.Name;
            ws.Cell(row, 2).Value = process.WorkstationName;
            ws.Cell(row, 3).Value = process.Enabled ? "TAK" : "NIE";
            ws.Cell(row, 4).Value = process.BaseHours > 0 ? process.BaseHours : process.Hours;
            ws.Cell(row, 5).Value = process.CalibrationFactor;
            ws.Cell(row, 6).Value = process.Hours;
            ws.Cell(row, 7).Value = process.RatePlnPerHour;
            ws.Cell(row, 8).Value = process.CostPln;
            ws.Cell(row, 9).Value = process.Confidence / 100.0;
            ws.Cell(row, 9).Style.NumberFormat.Format = "0%";
            ws.Cell(row, 10).Value = process.Basis;
        }

        ws.Columns().AdjustToContents(8, 70);
    }

    private static void WriteHierarchy(XLWorkbook wb, QuoteProject p)
    {
        var ws = wb.Worksheets.Add("Hierarchia BOM");
        string[] headers = ["Poziom", "Typ", "Element", "Nr części", "Ilość", "Materiał", "Masa [kg]", "Źródło", "Podstawa dopasowania"];
        for (var i = 0; i < headers.Length; i++)
            ws.Cell(1, i + 1).Value = headers[i];
        ws.Range(1, 1, 1, headers.Length).Style.Font.Bold = true;

        var row = 1;
        foreach (var node in p.Analysis?.AssemblyTree ?? [])
        {
            row++;
            ws.Cell(row, 1).Value = node.Level;
            ws.Cell(row, 2).Value = node.Kind;
            ws.Cell(row, 3).Value = node.Name;
            ws.Cell(row, 4).Value = node.PartNumber;
            ws.Cell(row, 5).Value = node.Quantity;
            ws.Cell(row, 6).Value = node.Material;
            ws.Cell(row, 7).Value = node.MassKg;
            ws.Cell(row, 8).Value = node.Source;
            ws.Cell(row, 9).Value = node.MatchBasis;
        }
        ws.Columns().AdjustToContents(8, 70);
    }

    private static void WriteRuleEngine(XLWorkbook wb, QuoteProject p)
    {
        var ws = wb.Worksheets.Add("Rule Engine DFM");
        string[] headers = ["Kod", "Reguła", "Efekt", "Podstawa", "Pewność"];
        for (var i = 0; i < headers.Length; i++)
            ws.Cell(1, i + 1).Value = headers[i];
        ws.Range(1, 1, 1, headers.Length).Style.Font.Bold = true;
        var row = 1;
        foreach (var hit in p.Analysis?.RuleHits ?? [])
        {
            row++;
            ws.Cell(row, 1).Value = hit.Code;
            ws.Cell(row, 2).Value = hit.Name;
            ws.Cell(row, 3).Value = hit.Effect;
            ws.Cell(row, 4).Value = hit.Basis;
            ws.Cell(row, 5).Value = hit.Confidence / 100.0;
            ws.Cell(row, 5).Style.NumberFormat.Format = "0%";
        }
        ws.Columns().AdjustToContents(8, 80);
    }

    private static void WritePlanActual(XLWorkbook wb, QuoteProject p)
    {
        var ws = wb.Worksheets.Add("Plan vs wykonanie");
        ws.Cell("A1").Value = "Proces";
        ws.Cell("B1").Value = "Plan [h]";
        ws.Cell("C1").Value = "Wykonanie [h]";
        ws.Cell("D1").Value = "Wykonanie / plan";
        ws.Range("A1:D1").Style.Font.Bold = true;

        var rows = new[]
        {
            ("CUT", "Cięcie"), ("WELD", "Spawanie"), ("CNC", "CNC"),
            ("SURF", "Powierzchnia"), ("ASSY", "Montaż")
        };
        var row = 1;
        foreach (var (code, name) in rows)
        {
            row++;
            var proc = p.Analysis?.Processes.FirstOrDefault(x => x.Code == code);
            var plan = proc is null ? 0 : proc.BaseHours > 0 ? proc.BaseHours : proc.Hours;
            var actual = p.Actuals.GetHours(code);
            ws.Cell(row, 1).Value = name;
            ws.Cell(row, 2).Value = plan;
            ws.Cell(row, 3).Value = actual;
            ws.Cell(row, 4).Value = plan > 0 && actual > 0 ? actual / plan : 0;
        }

        ws.Cell("F1").Value = "Rzeczywisty koszt [PLN]";
        ws.Cell("G1").Value = p.Actuals.ActualTotalCostPln;
        ws.Cell("F2").Value = "Notatka";
        ws.Cell("G2").Value = p.Actuals.Note;

        ws.Cell("F4").Value = "Kalibracje użyte w tej wycenie";
        var cr = 4;
        foreach (var c in p.Analysis?.CalibrationFactors ?? [])
        {
            cr++;
            ws.Cell(cr, 6).Value = c.ProcessName;
            ws.Cell(cr, 7).Value = c.Factor;
            ws.Cell(cr, 8).Value = c.Samples;
        }
        ws.Columns().AdjustToContents(8, 60);
    }

    private static void WriteConflicts(XLWorkbook wb, QuoteProject p)
    {
        var ws = wb.Worksheets.Add("Konflikty danych");
        string[] headers = ["Pole", "Wartości", "Źródła", "Reguła automatyczna", "Poziom"];
        for (var i = 0; i < headers.Length; i++)
            ws.Cell(1, i + 1).Value = headers[i];
        ws.Range(1, 1, 1, headers.Length).Style.Font.Bold = true;

        var row = 1;
        foreach (var conflict in p.Analysis?.Drawing.Conflicts ?? [])
        {
            row++;
            ws.Cell(row, 1).Value = conflict.Field;
            ws.Cell(row, 2).Value = conflict.Values;
            ws.Cell(row, 3).Value = conflict.Sources;
            ws.Cell(row, 4).Value = conflict.Resolution;
            ws.Cell(row, 5).Value = conflict.Level.ToString();
        }
        ws.Columns().AdjustToContents(8, 80);
    }

    private static void WriteRisks(XLWorkbook wb, QuoteProject p)
    {
        var ws = wb.Worksheets.Add("Ryzyka");
        ws.Cell("A1").Value = "Poziom";
        ws.Cell("B1").Value = "Ryzyko";
        ws.Cell("C1").Value = "Opis";
        ws.Cell("D1").Value = "Blokujące";
        ws.Range("A1:D1").Style.Font.Bold = true;

        var row = 1;
        foreach (var risk in p.Analysis?.Risks ?? [])
        {
            row++;
            ws.Cell(row, 1).Value = risk.Level.ToString();
            ws.Cell(row, 2).Value = risk.Title;
            ws.Cell(row, 3).Value = risk.Message;
            ws.Cell(row, 4).Value = risk.Blocking ? "TAK" : "NIE";
        }

        ws.Columns().AdjustToContents(8, 80);
    }
}
