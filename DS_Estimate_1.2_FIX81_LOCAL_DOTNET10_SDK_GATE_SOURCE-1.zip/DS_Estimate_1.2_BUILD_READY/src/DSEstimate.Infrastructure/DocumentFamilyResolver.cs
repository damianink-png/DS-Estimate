using System.Text.RegularExpressions;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

/// <summary>
/// FIX12D: resolves the scope of a large RFQ before Data Fusion. A root parts list
/// (STL/Stueckliste/BOM) defines which drawing-number families belong to the quoted
/// assembly. PDF/DXF/STEP files outside that set remain visible in the project but
/// cannot silently vote into project-wide material, weld, cut or mass calculations.
/// </summary>
public sealed class DocumentFamilyResolution
{
    public string RootEntityKey { get; init; } = "";
    public bool HasAuthoritativeRootBom { get; init; }
    public bool ScopeEnforced { get; init; }
    public HashSet<string> ProductionFamilies { get; init; } = new(StringComparer.OrdinalIgnoreCase);
    public int RootBomFamilyCount => ProductionFamilies.Count;
    public int StepFamilyCount { get; init; }
    public int StepFamilyMatchCount { get; init; }
    public int DxfFamilyCount { get; init; }
    public int DxfFamilyMatchCount { get; init; }
    public bool StepCoveragePartial { get; init; }
    public bool DxfScopeLimited { get; init; }
    public int ExcludedDrawingCount { get; init; }
    public int ExcludedDxfCount { get; init; }

    public bool Allows(string? sourceFile)
    {
        if (!HasAuthoritativeRootBom || !ScopeEnforced) return true;
        var key = DocumentFamilyResolver.ExtractEntityKey(sourceFile);
        // General specifications without a drawing number are retained. Only a
        // positively identified foreign drawing family is scope-limited.
        return string.IsNullOrWhiteSpace(key) ||
               key.Equals(RootEntityKey, StringComparison.OrdinalIgnoreCase) ||
               ProductionFamilies.Contains(key);
    }
}

public static class DocumentFamilyResolver
{
    private static readonly Regex EntityRx = new(@"(?<!\d)(\d{8,14})(?!\d)", RegexOptions.Compiled);

    public static string ExtractEntityKey(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "";
        var matches = EntityRx.Matches(value);
        if (matches.Count == 0) return "";
        // Supplier drawing numbers in real RFQs are usually 10-12 digits. Prefer
        // the longest token so dates / short ERP counters do not win accidentally.
        return matches.Select(m => m.Groups[1].Value)
            .OrderByDescending(x => x.Length)
            .ThenBy(x => x, StringComparer.OrdinalIgnoreCase)
            .FirstOrDefault() ?? "";
    }

    public static string RoutingKey(string? value)
    {
        var entity = ExtractEntityKey(value);
        if (!string.IsNullOrWhiteSpace(entity)) return entity;
        var stem = Path.GetFileNameWithoutExtension(value ?? "").ToUpperInvariant();
        stem = Regex.Replace(stem, @"\s*\[KONFLIKT\s+\d+\]\s*$", "", RegexOptions.IgnoreCase);
        stem = Regex.Replace(stem, @"(?ix)(?:^|[ _\-.])(?:REV(?:ISION)?[ _\-.]*[A-Z0-9]{1,4}|R(?:[0-9]{1,4}|[A-Z]))(?=$|[ _\-.])", " ");
        stem = Regex.Replace(stem, @"(?ix)(?:^|[ _\-.])(BOM|STL|STUECKLISTE|STÜCKLISTE|PARTLIST|DRAWING|RYS(?:UNEK)?|WELD(?:ING)?|SPAW(?:ANIE)?|MODEL|STEP)(?=$|[ _\-.])", " ");
        return Regex.Replace(stem, @"[^A-Z0-9]+", "").Trim();
    }

    public static bool IsAuthoritativeBomSource(string? sourceFile)
    {
        var name = Path.GetFileNameWithoutExtension(sourceFile ?? "").ToUpperInvariant();
        return name.StartsWith("STL_", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("STUECKLISTE", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("STÜCKLISTE", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("PARTLIST", StringComparison.OrdinalIgnoreCase) ||
               Regex.IsMatch(name, @"(?:^|[_\- ])BOM(?:$|[_\- ])", RegexOptions.IgnoreCase);
    }

    public static DocumentFamilyResolution Resolve(
        IReadOnlyList<DrawingIntelligence> drawings,
        IReadOnlyList<DxfSignals> dxfs,
        IReadOnlyList<ProjectDocument> activeDocuments)
    {
        var candidates = drawings
            .Where(x => IsAuthoritativeBomSource(x.SourceFile) && x.BomItems.Count >= 3)
            .ToList();

        if (candidates.Count == 0)
            return new DocumentFamilyResolution();

        static IEnumerable<string> BomChildren(DrawingIntelligence drawing) => drawing.BomItems
            .Select(x => ExtractEntityKey(x.PartNumber))
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase);

        // FIX12D hierarchical root selection: the main BOM is normally the BOM
        // that is not itself referenced by another authoritative BOM. This is safer
        // than simply picking the longest child list.
        var candidateKeys = candidates
            .Select(x => new { Drawing = x, Key = ExtractEntityKey(x.SourceFile) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Key))
            .ToList();
        var referencedBomKeys = candidates.SelectMany(BomChildren)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var rootChoices = candidateKeys
            .Where(x => !referencedBomKeys.Contains(x.Key))
            .OrderByDescending(x => x.Drawing.BomItems.Count)
            .ThenByDescending(x => x.Drawing.BomPositiveMassRowCount)
            .ToList();
        var ambiguousRoots = rootChoices.Count > 1;
        var rootBom = (rootChoices.Count > 0 ? rootChoices[0].Drawing : candidates
            .OrderByDescending(x => x.BomItems.Count)
            .ThenByDescending(x => x.BomPositiveMassRowCount)
            .First());
        var rootKey = ExtractEntityKey(rootBom.SourceFile);

        // Expand the BOM transitively through child STL/Stueckliste/BOM documents.
        // This keeps leaf DXF/PDF files belonging to a nested subassembly in scope,
        // while unrelated folders/drawings remain excluded.
        var bomByEntity = candidates
            .Select(x => new { Drawing = x, Key = ExtractEntityKey(x.SourceFile) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Key))
            .GroupBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key,
                g => g.OrderByDescending(x => x.Drawing.BomItems.Count).First().Drawing,
                StringComparer.OrdinalIgnoreCase);
        var families = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var queue = new Queue<string>();
        if (!string.IsNullOrWhiteSpace(rootKey))
        {
            families.Add(rootKey);
            queue.Enqueue(rootKey);
        }
        else
        {
            foreach (var child in BomChildren(rootBom))
                if (families.Add(child)) queue.Enqueue(child);
        }

        var expandedBoms = 0;
        while (queue.Count > 0 && families.Count < 5000 && expandedBoms < 1000)
        {
            var entity = queue.Dequeue();
            DrawingIntelligence? bom = null;
            if (entity.Equals(rootKey, StringComparison.OrdinalIgnoreCase))
                bom = rootBom;
            else
                bomByEntity.TryGetValue(entity, out bom);
            if (bom is null) continue;
            expandedBoms++;
            foreach (var child in BomChildren(bom))
                if (families.Add(child)) queue.Enqueue(child);
        }

        // Fewer than eight identified rows is too weak to police a whole RFQ.
        // Fall back to the legacy all-source behaviour instead of over-filtering.
        if (families.Count < 8)
            return new DocumentFamilyResolution();

        var stepKeys = activeDocuments
            .Where(x => x.Kind == DocumentKind.Step && x.IsActiveRevision && !x.ExcludeFromAnalysis)
            .Select(x => ExtractEntityKey(x.Name))
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        var dxfKeys = dxfs
            .Select(x => ExtractEntityKey(x.SourceFile))
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        var stepMatches = stepKeys.Count(families.Contains);
        var dxfMatches = dxfKeys.Count(families.Contains);
        var stepCoverage = families.Count > 0 ? stepMatches / (double)families.Count : 1.0;
        var stepPartial = stepKeys.Count > 0 && stepCoverage < 0.25;

        // A noisy OCR table must not become an accidental allow-list.  Enforce
        // family scope only when the root list is corroborated by a useful number
        // of actual CAD/drawing families.  STEP may legitimately be sparse, so DXF
        // or any production drawing family can provide the corroboration.
        var drawingKeys = drawings
            .Select(x => ExtractEntityKey(x.SourceFile))
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        var drawingMatches = drawingKeys.Count(families.Contains);
        var corroboration = Math.Max(dxfMatches, drawingMatches);
        var minCorroboration = Math.Min(8, Math.Max(3, (int)Math.Ceiling(families.Count * 0.10)));
        var scopeEnforced = !ambiguousRoots && corroboration >= minCorroboration;

        var excludedDrawings = drawings.Count(x =>
        {
            var key = ExtractEntityKey(x.SourceFile);
            return !string.IsNullOrWhiteSpace(key) && !families.Contains(key) &&
                   !key.Equals(rootKey, StringComparison.OrdinalIgnoreCase);
        });
        var excludedDxfs = dxfs.Count(x =>
        {
            var key = ExtractEntityKey(x.SourceFile);
            return !string.IsNullOrWhiteSpace(key) && !families.Contains(key) &&
                   !key.Equals(rootKey, StringComparison.OrdinalIgnoreCase);
        });

        return new DocumentFamilyResolution
        {
            RootEntityKey = rootKey,
            HasAuthoritativeRootBom = true,
            ScopeEnforced = scopeEnforced,
            ProductionFamilies = families,
            StepFamilyCount = stepKeys.Count,
            StepFamilyMatchCount = stepMatches,
            DxfFamilyCount = dxfKeys.Count,
            DxfFamilyMatchCount = dxfMatches,
            StepCoveragePartial = scopeEnforced && stepPartial,
            DxfScopeLimited = scopeEnforced && excludedDxfs > 0,
            ExcludedDrawingCount = scopeEnforced ? excludedDrawings : 0,
            ExcludedDxfCount = scopeEnforced ? excludedDxfs : 0
        };
    }
}
