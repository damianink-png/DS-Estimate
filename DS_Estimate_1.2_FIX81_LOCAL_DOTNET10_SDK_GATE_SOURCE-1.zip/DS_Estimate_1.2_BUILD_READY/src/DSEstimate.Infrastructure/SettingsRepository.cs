using System.Text.Json;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

public sealed class SettingsRepository
{
    private readonly string _path;

    public SettingsRepository()
    {
        var dir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "DSEstimateNext");

        Directory.CreateDirectory(dir);
        _path = Path.Combine(dir, "settings.json");
    }

    public CostingSettings Load()
    {
        foreach (var candidate in new[] { _path, _path + ".bak" })
        {
            try
            {
                if (!File.Exists(candidate))
                    continue;
                var json = File.ReadAllText(candidate);
                var loaded = JsonSerializer.Deserialize<CostingSettings>(json);
                if (loaded is null)
                    continue;
                ApplyDefaultsMigration(loaded);
                loaded.RuntimeCalibration = new CalibrationRepository().LoadOrCreate();
                return loaded;
            }
            catch
            {
                // Try the atomically maintained backup before falling back to defaults.
            }
        }
        var defaults = new CostingSettings();
        defaults.RuntimeCalibration = new CalibrationRepository().LoadOrCreate();
        return defaults;
    }


    private static void ApplyDefaultsMigration(CostingSettings loaded)
    {
        var defaults = new CostingSettings();
        loaded.Workstations ??= [];
        loaded.SheetStocks ??= [];
        loaded.PurchasedPartPrices ??= [];
        loaded.CompanyProcessFactors ??= [];
        loaded.CompanyProfileBaselineWorkstations ??= [];
        loaded.MaterialPriceOverridesPlnKg ??= new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        if (loaded.SheetStocks.Count == 0)
            loaded.SheetStocks = defaults.SheetStocks.Select(x => new SheetStockDefinition { Name = x.Name, Xmm = x.Xmm, Ymm = x.Ymm, Enabled = x.Enabled }).ToList();
        if (loaded.PurchasedPartPrices.Count == 0)
            loaded.PurchasedPartPrices = defaults.PurchasedPartPrices.Select(x => new PurchasedPartPrice
            {
                Code = x.Code, Name = x.Name, Category = x.Category, MatchExpression = x.MatchExpression,
                Unit = x.Unit, PricePln = x.PricePln, Enabled = x.Enabled, MarketReference = x.MarketReference,
                Source = x.Source, SourceDate = x.SourceDate
            }).ToList();

        // Keep user-defined stations, but ensure every standard process station exists.
        foreach (var template in defaults.Workstations)
        {
            var station = loaded.Workstations.FirstOrDefault(x =>
                string.Equals(x.Code, template.Code, StringComparison.OrdinalIgnoreCase));

            if (station is null)
            {
                loaded.Workstations.Add(CloneStation(template));
                continue;
            }

            // R8.3 migration: older releases stored 0 in nearly every workstation field.
            // Fill only missing/zero values; never overwrite a non-zero user value.
            if (loaded.WorkstationDefaultsVersion < 1)
            {
                if (station.RatePlnPerHour <= 0) station.RatePlnPerHour = template.RatePlnPerHour;
                if (station.MaxXmm <= 0) station.MaxXmm = template.MaxXmm;
                if (station.MaxYmm <= 0) station.MaxYmm = template.MaxYmm;
                if (station.MaxZmm <= 0) station.MaxZmm = template.MaxZmm;
                if (station.MaxWeightKg <= 0) station.MaxWeightKg = template.MaxWeightKg;
                if (station.MaxThicknessMm <= 0) station.MaxThicknessMm = template.MaxThicknessMm;
            }
            if (station.TimeFactor <= 0) station.TimeFactor = template.TimeFactor > 0 ? template.TimeFactor : 1.0;
        }

        if (loaded.WorkstationDefaultsVersion < 1)
        {
            // Migrate only unchanged historical defaults. These are market-informed starting
            // assumptions, not company-confirmed rates.
            if (Math.Abs(loaded.CuttingRatePlnH - 180) < 0.001) loaded.CuttingRatePlnH = defaults.CuttingRatePlnH;
            if (Math.Abs(loaded.WeldingRatePlnH - 160) < 0.001) loaded.WeldingRatePlnH = defaults.WeldingRatePlnH;
            if (Math.Abs(loaded.MachiningRatePlnH - 300) < 0.001) loaded.MachiningRatePlnH = defaults.MachiningRatePlnH;
            if (Math.Abs(loaded.PaintingRatePlnH - 140) < 0.001) loaded.PaintingRatePlnH = defaults.PaintingRatePlnH;
            if (Math.Abs(loaded.AssemblyRatePlnH - 150) < 0.001) loaded.AssemblyRatePlnH = defaults.AssemblyRatePlnH;
            if (string.IsNullOrWhiteSpace(loaded.PricingProfileName) ||
                loaded.PricingProfileName.StartsWith("Robocze", StringComparison.OrdinalIgnoreCase))
                loaded.PricingProfileName = defaults.PricingProfileName;
            loaded.WorkstationDefaultsVersion = 1;
        }

        if (loaded.WorkstationDefaultsVersion < 2)
        {
            // R9.1.0: company-provided 2026 RBH card. This is an explicit user
            // configuration request, so the effective process rates are migrated to
            // the supplied values instead of retaining the old generic PL defaults.
            foreach (var template in defaults.Workstations)
            {
                var station = loaded.Workstations.FirstOrDefault(x =>
                    string.Equals(x.Code, template.Code, StringComparison.OrdinalIgnoreCase));
                if (station is null)
                {
                    loaded.Workstations.Add(CloneStation(template));
                    continue;
                }

                station.Name = template.Name;
                station.ProcessCode = template.ProcessCode;
                station.MatchTag = template.MatchTag;
                station.Priority = template.Priority;
                station.RatePlnPerHour = template.RatePlnPerHour;
                station.CostCenterCode = template.CostCenterCode;
                station.CostCenterName = template.CostCenterName;
                station.DisplayInRateCard = template.DisplayInRateCard;
                station.AutomaticRoutingCandidate = template.AutomaticRoutingCandidate;
                station.DirectLaborRatePlnH = template.DirectLaborRatePlnH;
                station.DepartmentOverheadPercent = template.DepartmentOverheadPercent;
                station.DepartmentCostRatePlnH = template.DepartmentCostRatePlnH;
                station.ManufacturingCostRatePlnH = template.ManufacturingCostRatePlnH;
                station.GeneralOverheadPercent = template.GeneralOverheadPercent;
                station.GeneralCostRatePlnH = template.GeneralCostRatePlnH;
                station.VariableDepartmentPercent = template.VariableDepartmentPercent;
                station.VariableDepartmentRatePlnH = template.VariableDepartmentRatePlnH;
            }

            // Sync internal stations sharing SSK 3401 to the visible company rate card.
            var bySsk = loaded.Workstations
                .Where(x => x.DisplayInRateCard && !string.IsNullOrWhiteSpace(x.CostCenterCode))
                .ToDictionary(x => x.CostCenterCode, x => x, StringComparer.OrdinalIgnoreCase);
            foreach (var station in loaded.Workstations.Where(x => !x.DisplayInRateCard && !string.IsNullOrWhiteSpace(x.CostCenterCode)))
            {
                if (bySsk.TryGetValue(station.CostCenterCode, out var source))
                    station.RatePlnPerHour = source.RatePlnPerHour;
            }

            loaded.CuttingRatePlnH = defaults.CuttingRatePlnH;
            loaded.WeldingRatePlnH = defaults.WeldingRatePlnH;
            loaded.MachiningRatePlnH = defaults.MachiningRatePlnH;
            loaded.PaintingRatePlnH = defaults.PaintingRatePlnH;
            loaded.AssemblyRatePlnH = defaults.AssemblyRatePlnH;
            loaded.MaterialWastePercent = defaults.MaterialWastePercent;
            loaded.PricingProfileName = defaults.PricingProfileName;
            loaded.RatesConfirmedByCompany = true;
            loaded.WorkstationDefaultsVersion = 2;
        }

        if (loaded.WorkstationDefaultsVersion < 3)
        {
            // R9.1.0: historical prices are a diagnostic cross-check by default,
            // not an automatic 25% ingredient of every new quote. Preserve any
            // deliberately customized value, migrate only the old default 25%.
            if (Math.Abs(loaded.HistoricalBlendPercent - 25.0) < 0.001)
                loaded.HistoricalBlendPercent = 0.0;
            loaded.WorkstationDefaultsVersion = 3;
        }

        if (loaded.WorkstationDefaultsVersion < 4)
        {
            // FIX12B: previously these three cost centres were display-only references.
            // They now participate in automatic routing, while preserving the user's rates.
            var processMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                ["CNC_MANUAL_3205"] = "CNC_MANUAL",
                ["PREP_MANUAL_3302"] = "PREP_MANUAL",
                ["PREP_MACHINE_3303"] = "PREP_MACHINE"
            };
            foreach (var pair in processMap)
            {
                var station = loaded.Workstations.FirstOrDefault(x => string.Equals(x.Code, pair.Key, StringComparison.OrdinalIgnoreCase));
                if (station is null) continue;
                station.ProcessCode = pair.Value;
                station.AutomaticRoutingCandidate = true;
                if (station.Priority >= 90) station.Priority = 10;
            }
            loaded.WorkstationDefaultsVersion = 4;
        }
    }

    private static WorkstationDefinition CloneStation(WorkstationDefinition x) => new()
    {
        Code = x.Code, Name = x.Name, ProcessCode = x.ProcessCode, MatchTag = x.MatchTag,
        Enabled = x.Enabled, Priority = x.Priority, RatePlnPerHour = x.RatePlnPerHour,
        CostCenterCode = x.CostCenterCode, CostCenterName = x.CostCenterName,
        DisplayInRateCard = x.DisplayInRateCard, AutomaticRoutingCandidate = x.AutomaticRoutingCandidate,
        DirectLaborRatePlnH = x.DirectLaborRatePlnH, DepartmentOverheadPercent = x.DepartmentOverheadPercent,
        DepartmentCostRatePlnH = x.DepartmentCostRatePlnH, ManufacturingCostRatePlnH = x.ManufacturingCostRatePlnH,
        GeneralOverheadPercent = x.GeneralOverheadPercent, GeneralCostRatePlnH = x.GeneralCostRatePlnH,
        VariableDepartmentPercent = x.VariableDepartmentPercent, VariableDepartmentRatePlnH = x.VariableDepartmentRatePlnH,
        MaxXmm = x.MaxXmm, MaxYmm = x.MaxYmm, MaxZmm = x.MaxZmm,
        MaxWeightKg = x.MaxWeightKg, MaxThicknessMm = x.MaxThicknessMm,
        TimeFactor = x.TimeFactor, LearnedSamples = x.LearnedSamples
    };

    public void Save(CostingSettings settings)
    {
        var json = JsonSerializer.Serialize(
            settings,
            new JsonSerializerOptions { WriteIndented = true });

        var temp = _path + ".tmp";
        var backup = _path + ".bak";
        File.WriteAllText(temp, json);
        try
        {
            if (File.Exists(_path))
                File.Replace(temp, _path, backup, ignoreMetadataErrors: true);
            else
                File.Move(temp, _path);
        }
        catch
        {
            // Some filesystems do not support Replace. Keep a last-known-good copy
            // and still make the final move atomic inside the same directory.
            if (File.Exists(_path))
                File.Copy(_path, backup, overwrite: true);
            File.Move(temp, _path, overwrite: true);
        }
        finally
        {
            try { if (File.Exists(temp)) File.Delete(temp); } catch { }
        }
    }
}
