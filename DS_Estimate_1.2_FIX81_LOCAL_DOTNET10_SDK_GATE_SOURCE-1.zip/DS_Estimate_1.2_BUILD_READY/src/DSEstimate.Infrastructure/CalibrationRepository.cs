using System.Text.Json;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

public sealed class CalibrationRepository
{
    private readonly string _path;
    private static readonly JsonSerializerOptions Json = new() { WriteIndented = true, PropertyNameCaseInsensitive = true };
    public string Path => _path;

    public CalibrationRepository()
    {
        var dir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DSEstimateNext");
        Directory.CreateDirectory(dir);
        _path = System.IO.Path.Combine(dir, "calibration.json");
    }

    public CalibrationProfile LoadOrCreate()
    {
        try
        {
            if (File.Exists(_path))
            {
                var loaded = JsonSerializer.Deserialize<CalibrationProfile>(File.ReadAllText(_path), Json);
                // Preserve a syntactically valid but unsupported profile so the
                // Trust layer can reject it visibly instead of silently replacing it.
                if (loaded is not null) return Normalize(loaded);
            }
        }
        catch { }
        var profile = LoadPackagedDefault() ?? new CalibrationProfile();
        Save(profile);
        return profile;
    }

    private static CalibrationProfile? LoadPackagedDefault()
    {
        var candidates = new[]
        {
            System.IO.Path.Combine(AppContext.BaseDirectory, "config", "calibration.json"),
            System.IO.Path.Combine(AppContext.BaseDirectory, "calibration.json"),
            System.IO.Path.Combine(Environment.CurrentDirectory, "config", "calibration.json")
        };
        foreach (var candidate in candidates.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            try
            {
                if (!File.Exists(candidate)) continue;
                var profile = JsonSerializer.Deserialize<CalibrationProfile>(File.ReadAllText(candidate), Json);
                if (profile is not null && profile.Schema == "ds-estimate-calibration-v1")
                    return Normalize(profile);
            }
            catch
            {
                // A damaged packaged seed must not overwrite a valid user profile.
            }
        }
        return null;
    }

    public void Save(CalibrationProfile profile)
    {
        profile = Normalize(profile);
        var tmp = _path + ".tmp";
        File.WriteAllText(tmp, JsonSerializer.Serialize(profile, Json));
        File.Move(tmp, _path, true);
    }

    private static CalibrationProfile Normalize(CalibrationProfile profile)
    {
        static Dictionary<string, double> Copy(IReadOnlyDictionary<string, double>? source)
        {
            var result = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            if (source is null) return result;
            foreach (var pair in source)
            {
                var key = pair.Key?.Trim();
                if (!string.IsNullOrWhiteSpace(key)) result[key] = pair.Value;
            }
            return result;
        }

        profile.ProcessMultipliers = Copy(profile.ProcessMultipliers);
        profile.MaterialMultipliers = Copy(profile.MaterialMultipliers);
        return profile;
    }
}
