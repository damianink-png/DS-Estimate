using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text.Json;

namespace DSEstimate.Infrastructure;

internal static class EngineResultCache
{
    private static readonly ConcurrentDictionary<string, string> ScriptFingerprints = new(StringComparer.OrdinalIgnoreCase);
    private static readonly ConcurrentDictionary<string, DateTime> LastCleanupUtc = new(StringComparer.OrdinalIgnoreCase);
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    /// <summary>
    /// Couples cached JSON with both its schema and the exact analyzer implementation.
    /// A changed Python script therefore cannot reuse a stale result just because a
    /// developer forgot to increment a hand-written cache constant.
    /// </summary>
    public static string VersionForScript(string schemaVersion, string scriptName)
    {
        var script = ResolveEngineScript(scriptName);
        if (script is null)
            return $"{schemaVersion}-script-missing";

        try
        {
            var info = new FileInfo(script);
            var identity = $"{info.FullName}|{info.Length}|{info.LastWriteTimeUtc.Ticks}";
            var fingerprint = ScriptFingerprints.GetOrAdd(identity, _ =>
            {
                using var stream = File.OpenRead(info.FullName);
                return Convert.ToHexString(SHA256.HashData(stream))[..16].ToLowerInvariant();
            });
            return $"{schemaVersion}-{fingerprint}";
        }
        catch
        {
            return $"{schemaVersion}-script-unreadable";
        }
    }

    /// <summary>
    /// Couples a cached result with the complete Python dependency set. This is
    /// required for wrapper analyzers such as analyze_tabular.py and analyze_dxf.py,
    /// which import semantic parsing from analyze_document.py. A change in any
    /// dependency automatically produces a new cache namespace.
    /// </summary>
    public static string VersionForScripts(string schemaVersion, params string[] scriptNames)
    {
        var dependencies = scriptNames
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x, StringComparer.OrdinalIgnoreCase)
            .Select(x => x.ToUpperInvariant() + "=" + VersionForScript("dependency", x))
            .ToList();
        if (dependencies.Count == 0)
            return $"{schemaVersion}-dependencies-empty";

        var payload = System.Text.Encoding.UTF8.GetBytes(string.Join("|", dependencies));
        var fingerprint = Convert.ToHexString(SHA256.HashData(payload))[..16].ToLowerInvariant();
        return $"{schemaVersion}-{fingerprint}";
    }

    public static async Task<(bool Hit, T? Value)> TryReadAsync<T>(
        string engine,
        string version,
        string path,
        string mode,
        CancellationToken cancellationToken)
    {
        try
        {
            var cachePath = await BuildPathAsync(engine, version, path, mode, cancellationToken);
            if (!File.Exists(cachePath))
                return (false, default);
            var json = await File.ReadAllTextAsync(cachePath, cancellationToken);
            var value = JsonSerializer.Deserialize<T>(json, JsonOptions);
            return value is null ? (false, default) : (true, value);
        }
        catch
        {
            return (false, default);
        }
    }

    public static async Task WriteAsync<T>(
        string engine,
        string version,
        string path,
        string mode,
        T value,
        CancellationToken cancellationToken)
    {
        try
        {
            var cachePath = await BuildPathAsync(engine, version, path, mode, cancellationToken);
            Directory.CreateDirectory(Path.GetDirectoryName(cachePath)!);
            var tmp = cachePath + ".tmp-" + Guid.NewGuid().ToString("N");
            await File.WriteAllTextAsync(tmp, JsonSerializer.Serialize(value), cancellationToken);
            File.Move(tmp, cachePath, true);
            CleanupBestEffort(Path.GetDirectoryName(cachePath)!);
        }
        catch
        {
            // Cache is best-effort only.
        }
    }

    private static async Task<string> BuildPathAsync(
        string engine,
        string version,
        string path,
        string mode,
        CancellationToken cancellationToken)
    {
        await using var stream = File.OpenRead(path);
        var hash = Convert.ToHexString(await SHA256.HashDataAsync(stream, cancellationToken));
        var safeMode = string.Concat((mode ?? "default").Select(ch => char.IsLetterOrDigit(ch) ? ch : '_'));
        var dir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "DSEstimateNext", "cache", engine);
        return Path.Combine(dir, $"{version}_{safeMode}_{hash}.json");
    }

    private static string? ResolveEngineScript(string scriptName)
    {
        var candidates = new List<string>
        {
            Path.Combine(AppContext.BaseDirectory, "engines", "python", scriptName),
            Path.Combine(Environment.CurrentDirectory, "engines", "python", scriptName)
        };

        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        for (var i = 0; i < 8 && dir is not null; i++, dir = dir.Parent)
            candidates.Add(Path.Combine(dir.FullName, "engines", "python", scriptName));

        return candidates.Distinct(StringComparer.OrdinalIgnoreCase).FirstOrDefault(File.Exists);
    }

    private static void CleanupBestEffort(string directory)
    {
        try
        {
            var now = DateTime.UtcNow;
            if (LastCleanupUtc.TryGetValue(directory, out var previous) && now - previous < TimeSpan.FromHours(12))
                return;
            LastCleanupUtc[directory] = now;

            var files = new DirectoryInfo(directory)
                .EnumerateFiles("*.json", SearchOption.TopDirectoryOnly)
                .OrderByDescending(x => x.LastWriteTimeUtc)
                .ToList();
            const int maximumFiles = 512;
            const long maximumBytes = 2L * 1024 * 1024 * 1024;
            var retainedBytes = 0L;
            for (var i = 0; i < files.Count; i++)
            {
                var expired = now - files[i].LastWriteTimeUtc > TimeSpan.FromDays(120);
                var overLimit = i >= maximumFiles || retainedBytes + files[i].Length > maximumBytes;
                if (expired || overLimit)
                    files[i].Delete();
                else
                    retainedBytes += files[i].Length;
            }
        }
        catch
        {
            // Cache retention is best-effort and never blocks an estimate.
        }
    }
}
