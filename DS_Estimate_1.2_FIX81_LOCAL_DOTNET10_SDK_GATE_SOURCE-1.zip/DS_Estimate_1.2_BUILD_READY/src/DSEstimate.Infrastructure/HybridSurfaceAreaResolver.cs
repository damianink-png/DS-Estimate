﻿using System.Globalization;
using System.Text.RegularExpressions;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

/// <summary>
/// FIX12E: reconstructs paintable surface per production family when the client
/// package does not contain one complete 3D model.  Sources are deliberately
/// selected per family so the same detail is never counted once from STEP and
/// again from DXF/BOM.
///
/// Priority per family:
///  1. explicit drawing area,
///  2. STEP surface for that exact drawing family,
///  3. DXF closed profiles (2 broad faces + edge area when thickness is known),
///  4. common RHS/SHS/pipe profile geometry from BOM text,
///  5. physically grounded BOM-mass fallback.
/// </summary>
public static class HybridSurfaceAreaResolver
{
    private static readonly Regex ThicknessRx = new(
        @"(?ix)(?:\b(?:T|THK|THICKNESS|GR|GRUBO[ŚS]Ć|DICKE)\s*[:=]?\s*|\b(?:BL|PL|PLATE|BLECH)\s+)(?<t>\d{1,3}(?:[\.,]\d{1,2})?)\s*(?:MM)?\b",
        RegexOptions.Compiled);

    private static readonly Regex RhsRx = new(
        @"(?ix)\b(?:RHS|SHS|PROFIL(?:\s+ZAMKNI[ĘE]TY)?)\s*(?<a>\d{2,4}(?:[\.,]\d+)?)\s*[x×]\s*(?<b>\d{2,4}(?:[\.,]\d+)?)\s*[x×]\s*(?<t>\d{1,2}(?:[\.,]\d+)?)\b",
        RegexOptions.Compiled);

    private static readonly Regex PipeRx = new(
        @"(?ix)\b(?:PIPE|TUBE|ROHR|RURA)\s*(?:Ø|D)?\s*(?<d>\d{2,4}(?:[\.,]\d+)?)\s*(?:[x×]\s*(?<t>\d{1,2}(?:[\.,]\d+)?))?\b",
        RegexOptions.Compiled);

    private static readonly Regex LengthRx = new(
        @"(?ix)\b(?:L|LEN|LENGTH|D[ŁL]|DL|D[ŁL]UGO[ŚS]Ć|L[ÄA]NGE)\s*[:=]?\s*(?<l>\d{2,6}(?:[\.,]\d+)?)\s*(?<u>MM|M)?\b",
        RegexOptions.Compiled);

    public static void Apply(
        DrawingIntelligence merged,
        GeometrySummary geometry,
        IReadOnlyList<DrawingIntelligence> drawings,
        IReadOnlyList<DxfSignals> dxfs,
        DocumentFamilyResolution resolution)
    {
        merged.HybridSurfaceAreaM2 = null;
        merged.HybridSurfaceAreaConfidence = 0;
        merged.HybridSurfaceAreaCoveragePercent = 0;
        merged.HybridSurfaceAreaSource = "";
        merged.HybridSurfaceAreaContributions.Clear();

        // Full STEP remains the strongest project-wide source.  The hybrid resolver
        // is mainly for incomplete assemblies / BOM-driven RFQs.
        if (!resolution.HasAuthoritativeRootBom || !resolution.ScopeEnforced)
            return;

        var targetFamilies = resolution.ProductionFamilies
            .Where(x => !string.IsNullOrWhiteSpace(x) &&
                        !x.Equals(resolution.RootEntityKey, StringComparison.OrdinalIgnoreCase))
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (targetFamilies.Count == 0)
            return;

        // A root drawing may explicitly state the whole coating area.  Use it as a
        // project total only when it belongs to the root entity and is high-confidence.
        var rootExplicit = drawings
            .Where(x => x.DocumentSurfaceAreaM2 is > 0 && x.DocumentSurfaceAreaConfidence >= 80)
            .Where(x => DocumentFamilyResolver.ExtractEntityKey(x.SourceFile)
                .Equals(resolution.RootEntityKey, StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(x => x.DocumentSurfaceAreaConfidence)
            .ThenByDescending(x => x.DocumentSurfaceAreaM2)
            .FirstOrDefault();
        if (rootExplicit?.DocumentSurfaceAreaM2 is > 0)
        {
            merged.HybridSurfaceAreaM2 = rootExplicit.DocumentSurfaceAreaM2;
            merged.HybridSurfaceAreaConfidence = Math.Clamp(rootExplicit.DocumentSurfaceAreaConfidence, 1, 99);
            merged.HybridSurfaceAreaCoveragePercent = 100;
            merged.HybridSurfaceAreaSource = "jawna powierzchnia root assembly";
            merged.HybridSurfaceAreaContributions.Add(new SurfaceAreaContribution
            {
                FamilyKey = resolution.RootEntityKey,
                SourceKind = "DOCUMENT_TOTAL",
                AreaM2 = rootExplicit.DocumentSurfaceAreaM2.Value,
                Quantity = 1,
                Confidence = merged.HybridSurfaceAreaConfidence,
                Basis = rootExplicit.DocumentSurfaceAreaEvidence
            });
            merged.Findings.Add(
                $"FIX12E Surface Resolver: jawna powierzchnia całego root assembly {rootExplicit.DocumentSurfaceAreaM2.Value:0.###} m² ({merged.HybridSurfaceAreaConfidence}%).");
            return;
        }

        var bomByFamily = merged.BomItems
            .Select(x => new { Item = x, Key = DocumentFamilyResolver.ExtractEntityKey(x.PartNumber) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Key) && targetFamilies.Contains(x.Key))
            .GroupBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.Select(x => x.Item).ToList(), StringComparer.OrdinalIgnoreCase);

        double QuantityFor(string family)
        {
            if (!bomByFamily.TryGetValue(family, out var rows)) return 1;
            var quantities = rows.Select(x => NormalizeQuantity(x.Quantity)).Where(x => x > 0).ToList();
            return quantities.Count == 0 ? 1 : Math.Max(1, quantities.Max());
        }

        var explicitByFamily = drawings
            .Where(x => x.DocumentSurfaceAreaM2 is > 0 && x.DocumentSurfaceAreaConfidence >= 65)
            .Select(x => new { Drawing = x, Key = DocumentFamilyResolver.ExtractEntityKey(x.SourceFile) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Key) && targetFamilies.Contains(x.Key))
            .GroupBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key,
                g => g.OrderByDescending(x => x.Drawing.DocumentSurfaceAreaConfidence)
                      .ThenByDescending(x => x.Drawing.DocumentSurfaceAreaM2)
                      .First().Drawing,
                StringComparer.OrdinalIgnoreCase);

        var stepByFamily = geometry.Parts
            .Select(x => new { Part = x, Key = DocumentFamilyResolver.ExtractEntityKey(x.SourceFile) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Key) && targetFamilies.Contains(x.Key))
            .GroupBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.Select(x => x.Part).ToList(), StringComparer.OrdinalIgnoreCase);

        var dxfByFamily = dxfs
            .Where(x => x.GeometryMeasurementReliable && x.ClosedProfileAreaMm2 > 0 && x.ClosedProfileCount > 0)
            .Select(x => new { Dxf = x, Key = DocumentFamilyResolver.ExtractEntityKey(x.SourceFile) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Key) && targetFamilies.Contains(x.Key))
            .GroupBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key,
                g => g.OrderByDescending(x => DxfQualityScore(x.Dxf)).First().Dxf,
                StringComparer.OrdinalIgnoreCase);

        foreach (var family in targetFamilies.OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
        {
            var quantity = QuantityFor(family);

            if (explicitByFamily.TryGetValue(family, out var explicitArea) && explicitArea.DocumentSurfaceAreaM2 is > 0)
            {
                merged.HybridSurfaceAreaContributions.Add(new SurfaceAreaContribution
                {
                    FamilyKey = family,
                    SourceKind = "DOCUMENT",
                    AreaM2 = explicitArea.DocumentSurfaceAreaM2.Value * quantity,
                    Quantity = quantity,
                    Confidence = Math.Clamp(explicitArea.DocumentSurfaceAreaConfidence, 55, 96),
                    Basis = $"jawna powierzchnia {explicitArea.DocumentSurfaceAreaM2.Value:0.###} m²/szt. × {quantity:0.###}"
                });
                continue;
            }

            if (stepByFamily.TryGetValue(family, out var stepParts) && stepParts.Count > 0)
            {
                // STEP part quantities already describe the geometry source.  Do not
                // multiply again by BOM unless the model contains a single unit and BOM
                // clearly requests more physical pieces.
                var nativeQuantity = Math.Max(1, stepParts.Sum(x => Math.Max(1, x.Quantity)));
                var multiplier = nativeQuantity <= 1.0001 ? Math.Max(1, quantity) : 1;
                var areaM2 = stepParts.Sum(x => Math.Max(0, x.SurfaceMm2Each - x.InternalPaintExcludedMm2Each) * Math.Max(1, x.Quantity))
                             / 1_000_000.0 * multiplier;
                if (areaM2 > 0.0001)
                {
                    merged.HybridSurfaceAreaContributions.Add(new SurfaceAreaContribution
                    {
                        FamilyKey = family,
                        SourceKind = "STEP",
                        AreaM2 = areaM2,
                        Quantity = Math.Max(nativeQuantity, quantity),
                        Confidence = 92,
                        Basis = $"dokładna powierzchnia lokalnego STEP; wykluczono rozpoznane wnętrza; mnożnik BOM ×{multiplier:0.###}"
                    });
                    continue;
                }
            }

            if (dxfByFamily.TryGetValue(family, out var dxf))
            {
                var thickness = InferThicknessMm(family, bomByFamily, stepByFamily);
                var facesM2 = 2.0 * dxf.ClosedProfileAreaMm2 / 1_000_000.0;
                var edgesM2 = thickness is > 0
                    ? dxf.CutLengthMm * thickness.Value / 1_000_000.0
                    : 0;
                var areaM2 = Math.Max(0, (facesM2 + edgesM2) * quantity);
                if (areaM2 > 0.0001)
                {
                    var openRatio = dxf.ClosedProfileCount > 0
                        ? dxf.OpenPathCount / (double)Math.Max(1, dxf.ClosedProfileCount)
                        : 99;
                    var confidence = thickness is > 0 ? 82 : 74;
                    if (openRatio > 8) confidence -= 8;
                    merged.HybridSurfaceAreaContributions.Add(new SurfaceAreaContribution
                    {
                        FamilyKey = family,
                        SourceKind = thickness is > 0 ? "DXF+THICKNESS" : "DXF",
                        AreaM2 = areaM2,
                        Quantity = quantity,
                        ThicknessMm = thickness,
                        Confidence = Math.Clamp(confidence, 50, 90),
                        Basis = thickness is > 0
                            ? $"2×pole zamkniętych konturów + obwód cięcia×t; t={thickness.Value:0.###} mm; ×{quantity:0.###} szt."
                            : $"2×pole zamkniętych konturów; brak wiarygodnej grubości — krawędzie pominięte; ×{quantity:0.###} szt."
                    });
                    continue;
                }
            }

            if (bomByFamily.TryGetValue(family, out var bomRows))
            {
                var profile = TryProfileArea(bomRows, quantity);
                if (profile is not null)
                {
                    profile.FamilyKey = family;
                    merged.HybridSurfaceAreaContributions.Add(profile);
                    continue;
                }

                var massContribution = TryMassArea(bomRows, quantity);
                if (massContribution is not null)
                {
                    massContribution.FamilyKey = family;
                    merged.HybridSurfaceAreaContributions.Add(massContribution);
                }
            }
        }

        var contributions = merged.HybridSurfaceAreaContributions
            .Where(x => x.AreaM2 > 0.0001)
            .ToList();
        if (contributions.Count == 0)
            return;

        var total = contributions.Sum(x => x.AreaM2);
        var coverage = 100.0 * contributions.Select(x => x.FamilyKey).Distinct(StringComparer.OrdinalIgnoreCase).Count()
                       / Math.Max(1, targetFamilies.Count);
        var weightedConfidence = contributions.Sum(x => x.AreaM2 * x.Confidence) / Math.Max(total, 0.001);
        // Missing families matter, but a small uncovered fastener family should not
        // destroy a large area reconstructed from plate DXFs.
        var coverageFactor = 0.65 + 0.35 * Math.Sqrt(Math.Clamp(coverage / 100.0, 0, 1));
        var confidenceFinal = (int)Math.Round(Math.Clamp(weightedConfidence * coverageFactor, 30, 95));

        merged.HybridSurfaceAreaM2 = total;
        merged.HybridSurfaceAreaConfidence = confidenceFinal;
        merged.HybridSurfaceAreaCoveragePercent = coverage;
        merged.HybridSurfaceAreaSource = BuildSourceSummary(contributions);
        merged.Findings.Add(
            $"FIX12E Surface Resolver: {total:0.###} m² z {contributions.Count}/{targetFamilies.Count} rodzin ({coverage:0.#}% pokrycia); " +
            $"źródła: {merged.HybridSurfaceAreaSource}; pewność {confidenceFinal}%.");

        if (coverage < 70)
            merged.Warnings.Add(
                $"FIX12E: powierzchnia projektu jest rekonstrukcją częściową ({coverage:0.#}% rodzin BOM). Brakujące rodziny nie zostały arbitralnie dopisane.");
    }

    private static double DxfQualityScore(DxfSignals dxf)
    {
        var openPenalty = Math.Min(dxf.OpenPathCount, 5000) * 1000.0;
        return dxf.ClosedProfileAreaMm2 + dxf.ClosedProfileCount * 100_000.0 - openPenalty;
    }

    private static double NormalizeQuantity(double q)
    {
        if (!double.IsFinite(q) || q <= 0) return 1;
        // OCR corruption such as 561,626 szt. must not explode a coating estimate.
        if (q > 100 && Math.Abs(q - Math.Round(q)) > 0.001) return 1;
        return Math.Clamp(q, 1, 10_000);
    }

    private static double? InferThicknessMm(
        string family,
        IReadOnlyDictionary<string, List<BomItemSignal>> bomByFamily,
        IReadOnlyDictionary<string, List<PartGroup>> stepByFamily)
    {
        if (stepByFamily.TryGetValue(family, out var parts))
        {
            var values = parts
                .Where(x => x.Classification.Contains("Blacha", StringComparison.OrdinalIgnoreCase) ||
                            x.Classification.Contains("płyta", StringComparison.OrdinalIgnoreCase))
                .Select(x => new[] { x.Xmm, x.Ymm, x.Zmm }.Where(v => v > 0.05).DefaultIfEmpty(0).Min())
                .Where(x => x is > 0.1 and <= 250)
                .ToList();
            if (values.Count > 0) return values.OrderBy(x => x).ElementAt(values.Count / 2);
        }

        if (!bomByFamily.TryGetValue(family, out var rows)) return null;
        foreach (var text in rows.Select(x => $"{x.PartNumber} {x.Description}"))
        {
            var m = ThicknessRx.Match(text);
            if (m.Success && TryNumber(m.Groups["t"].Value, out var t) && t is > 0.1 and <= 250)
                return t;
        }
        return null;
    }

    private static SurfaceAreaContribution? TryProfileArea(List<BomItemSignal> rows, double quantity)
    {
        foreach (var row in rows)
        {
            var text = $"{row.PartNumber} {row.Description}";
            var lm = LengthRx.Match(text);
            if (!lm.Success || !TryNumber(lm.Groups["l"].Value, out var length)) continue;
            var unit = lm.Groups["u"].Value.ToUpperInvariant();
            var lengthMm = unit == "M" ? length * 1000.0 : length;
            if (lengthMm is < 50 or > 100_000) continue;

            var rhs = RhsRx.Match(text);
            if (rhs.Success && TryNumber(rhs.Groups["a"].Value, out var a) && TryNumber(rhs.Groups["b"].Value, out var b))
            {
                var externalM2 = 2.0 * (a + b) * lengthMm / 1_000_000.0;
                var endsM2 = 2.0 * a * b / 1_000_000.0;
                return new SurfaceAreaContribution
                {
                    SourceKind = "BOM_PROFILE",
                    AreaM2 = (externalM2 + endsM2) * quantity,
                    Quantity = quantity,
                    Confidence = 70,
                    Basis = $"RHS/SHS {a:0.#}×{b:0.#}, L={lengthMm:0.#} mm; powierzchnia z obwodu zewnętrznego ×{quantity:0.###}"
                };
            }

            var pipe = PipeRx.Match(text);
            if (pipe.Success && TryNumber(pipe.Groups["d"].Value, out var d))
            {
                var externalM2 = Math.PI * d * lengthMm / 1_000_000.0;
                var endsM2 = 2.0 * Math.PI * d * d / 4.0 / 1_000_000.0;
                return new SurfaceAreaContribution
                {
                    SourceKind = "BOM_PROFILE",
                    AreaM2 = (externalM2 + endsM2) * quantity,
                    Quantity = quantity,
                    Confidence = 68,
                    Basis = $"rura Ø{d:0.#}, L={lengthMm:0.#} mm; powierzchnia z obwodu zewnętrznego ×{quantity:0.###}"
                };
            }
        }
        return null;
    }

    private static SurfaceAreaContribution? TryMassArea(List<BomItemSignal> rows, double quantity)
    {
        // The same physical row may appear as L/ZEZ aliases.  Use one conservative
        // representative rather than summing duplicates.
        var masses = rows.Select(x =>
            {
                var q = NormalizeQuantity(x.Quantity);
                var each = x.MassKgEach ?? (x.TotalMassKg is > 0 ? x.TotalMassKg.Value / Math.Max(q, 1) : 0);
                return each;
            })
            .Where(x => x is > 0.001 and < 25_000)
            .OrderBy(x => x)
            .ToList();
        if (masses.Count == 0) return null;

        var eachMass = masses[masses.Count / 2];
        // Reject a lonely many-ton OCR value if the same family also contains very
        // small/normal values.  Large OCR mass false positives are caught
        // by the hard upper bound above and never becomes paint area.
        if (eachMass > 5000 && masses.Any(x => x < eachMass / 20.0))
            return null;

        var thickness = rows.Select(x => ThicknessRx.Match($"{x.PartNumber} {x.Description}"))
            .Where(x => x.Success && TryNumber(x.Groups["t"].Value, out _))
            .Select(x => { TryNumber(x.Groups["t"].Value, out var t); return t; })
            .FirstOrDefault(x => x is > 0.1 and <= 250);

        double areaPerKg;
        string basis;
        int confidence;
        if (thickness > 0)
        {
            // Broad-face area of a steel plate: A≈2*m/(rho*t).  This is more
            // physically meaningful than one universal m²/kg factor.
            areaPerKg = 2.0 / (7850.0 * (thickness / 1000.0));
            basis = $"fallback z masy blachy i grubości t={thickness:0.###} mm: A≈2m/(ρt)";
            confidence = 58;
        }
        else
        {
            areaPerKg = 0.025;
            basis = "fallback z masy rodziny 0,025 m²/kg; brak geometrii/grubości";
            confidence = 42;
        }

        return new SurfaceAreaContribution
        {
            SourceKind = thickness > 0 ? "BOM_MASS_THICKNESS" : "BOM_MASS",
            AreaM2 = eachMass * Math.Max(1, quantity) * areaPerKg,
            Quantity = quantity,
            ThicknessMm = thickness > 0 ? thickness : null,
            Confidence = confidence,
            Basis = $"{basis}; {eachMass:0.###} kg/szt. × {quantity:0.###}"
        };
    }

    private static bool TryNumber(string text, out double value) =>
        double.TryParse(text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out value);

    private static string BuildSourceSummary(IReadOnlyList<SurfaceAreaContribution> contributions)
    {
        var total = contributions.Sum(x => x.AreaM2);
        if (total <= 0) return "brak";
        return string.Join(", ", contributions
            .GroupBy(x => x.SourceKind, StringComparer.OrdinalIgnoreCase)
            .Select(g => new { Kind = g.Key, Area = g.Sum(x => x.AreaM2) })
            .OrderByDescending(x => x.Area)
            .Select(x => $"{x.Kind} {100.0 * x.Area / total:0.#}%"));
    }
}
