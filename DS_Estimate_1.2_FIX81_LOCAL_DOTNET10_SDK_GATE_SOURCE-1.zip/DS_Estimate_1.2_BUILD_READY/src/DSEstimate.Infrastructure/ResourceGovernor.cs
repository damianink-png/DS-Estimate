﻿using System.Diagnostics;
using System.Runtime.InteropServices;

namespace DSEstimate.Infrastructure;

/// <summary>
/// FIX14: coarse process-launch governor for heavy native/Python engines. It does not
/// try to micromanage Windows; it simply refuses to start another expensive worker
/// while physical-memory headroom is dangerously low. This protects the desktop from
/// swap storms during large A0/A1 OCR and multi-STEP history scans.
/// </summary>
public static class ResourceGovernor
{
    private const ulong DefaultReserveBytes = 2UL * 1024 * 1024 * 1024;
    private const double MaxMemoryLoadPercent = 88.0;

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private struct MemoryStatusEx
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool GlobalMemoryStatusEx(ref MemoryStatusEx lpBuffer);

    public sealed record Snapshot(
        long WorkingSetBytes,
        ulong TotalPhysicalBytes,
        ulong AvailablePhysicalBytes,
        double MemoryLoadPercent,
        bool IsWindows)
    {
        public string Summary =>
            $"RAM load {MemoryLoadPercent:0.#}% · free {AvailablePhysicalBytes / 1024.0 / 1024.0 / 1024.0:0.00} GB · " +
            $"DS {WorkingSetBytes / 1024.0 / 1024.0 / 1024.0:0.00} GB";
    }

    public static Snapshot GetSnapshot()
    {
        var working = Environment.WorkingSet;
        if (OperatingSystem.IsWindows())
        {
            var status = new MemoryStatusEx { dwLength = (uint)Marshal.SizeOf<MemoryStatusEx>() };
            if (GlobalMemoryStatusEx(ref status))
                return new Snapshot(working, status.ullTotalPhys, status.ullAvailPhys, status.dwMemoryLoad, true);
        }

        var info = GC.GetGCMemoryInfo();
        var total = (ulong)Math.Max(0, info.TotalAvailableMemoryBytes);
        var used = (ulong)Math.Max(0, working);
        var available = total > used ? total - used : 0;
        var load = total > 0 ? used * 100.0 / total : 0;
        return new Snapshot(working, total, available, load, false);
    }

    public static async Task<bool> WaitForHeadroomAsync(
        CancellationToken cancellationToken,
        TimeSpan? maxWait = null,
        ulong reserveBytes = DefaultReserveBytes)
    {
        var deadline = DateTime.UtcNow + (maxWait ?? TimeSpan.FromSeconds(75));
        do
        {
            cancellationToken.ThrowIfCancellationRequested();
            var snapshot = GetSnapshot();
            if (snapshot.TotalPhysicalBytes == 0 ||
                (snapshot.AvailablePhysicalBytes >= reserveBytes && snapshot.MemoryLoadPercent <= MaxMemoryLoadPercent))
                return true;

            // Encourage release of completed large managed buffers before waiting.
            GC.Collect(1, GCCollectionMode.Optimized, blocking: false, compacting: false);
            await Task.Delay(750, cancellationToken);
        }
        while (DateTime.UtcNow < deadline);

        return false;
    }
}
