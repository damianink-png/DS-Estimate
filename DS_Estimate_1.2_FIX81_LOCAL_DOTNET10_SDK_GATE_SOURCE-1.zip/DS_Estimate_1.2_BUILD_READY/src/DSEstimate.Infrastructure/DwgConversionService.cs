﻿using ACadSharp;
using ACadSharp.IO;
using System.Security.Cryptography;

namespace DSEstimate.Infrastructure;

public sealed class DwgConversionResult : IDisposable
{
    public bool Ok { get; init; }
    public string DxfPath { get; init; } = "";
    public string Engine { get; init; } = "ACadSharp";
    public List<string> Warnings { get; init; } = [];

    public void Dispose()
    {
        if (string.IsNullOrWhiteSpace(DxfPath))
            return;
        try
        {
            if (File.Exists(DxfPath))
                File.Delete(DxfPath);
        }
        catch
        {
            // Temporary conversion files are best-effort cleanup only.
        }
    }
}

/// <summary>
/// Local DWG -> DXF bridge.  ACadSharp is MIT-licensed and is kept as a normal
/// NuGet dependency so the self-contained publish carries it with the app.
/// The converter intentionally does not mutate the source DWG.
/// </summary>
public sealed class DwgConversionService
{
    public Task<DwgConversionResult> ConvertToDxfAsync(
        string dwgPath,
        CancellationToken cancellationToken = default)
    {
        return Task.Run(() => ConvertToDxf(dwgPath, cancellationToken), cancellationToken);
    }

    private static DwgConversionResult ConvertToDxf(
        string dwgPath,
        CancellationToken cancellationToken)
    {
        var warnings = new List<string>();
        if (!File.Exists(dwgPath))
        {
            return new DwgConversionResult
            {
                Ok = false,
                Warnings = ["DWG nie istnieje."]
            };
        }

        var outDir = Path.Combine(Path.GetTempPath(), "DS_Estimate", "dwg-cache");
        Directory.CreateDirectory(outDir);
        var dxfPath = Path.Combine(
            outDir,
            $"{Path.GetFileNameWithoutExtension(dwgPath)}_{Guid.NewGuid():N}.dxf");

        try
        {
            cancellationToken.ThrowIfCancellationRequested();

            // R9.2.0: cache the expensive ACadSharp conversion by source content.
            // A cached DXF is copied to a disposable temp path so legacy cleanup
            // behaviour remains unchanged and the persistent cache cannot be deleted.
            string? persistentCache = null;
            try
            {
                using var stream = File.OpenRead(dwgPath);
                var hash = Convert.ToHexString(SHA256.HashData(stream));
                var cacheDir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "DSEstimateNext", "cache", "dwg");
                Directory.CreateDirectory(cacheDir);
                persistentCache = Path.Combine(cacheDir, $"r920-dwg-v1_{hash}.dxf");
                if (File.Exists(persistentCache) && new FileInfo(persistentCache).Length > 128)
                {
                    File.Copy(persistentCache, dxfPath, true);
                    return new DwgConversionResult
                    {
                        Ok = true,
                        DxfPath = dxfPath,
                        Engine = "ACadSharp cache",
                        Warnings = ["DWG cache: użyto wcześniej przekonwertowanego DXF dla identycznego pliku DWG."]
                    };
                }
            }
            catch
            {
                persistentCache = null;
            }

            CadDocument document;
            using (var reader = new DwgReader(dwgPath))
            {
                reader.OnNotification += (_, e) =>
                {
                    var msg = e?.Message?.Trim();
                    if (!string.IsNullOrWhiteSpace(msg))
                        warnings.Add("ACadSharp read: " + msg);
                };
                document = reader.Read();
            }

            cancellationToken.ThrowIfCancellationRequested();

            // ASCII DXF is deliberate: ezdxf can then validate and interrogate
            // geometry/layers/text with the same engine used for native DXF input.
            using (var writer = new DxfWriter(dxfPath, document, false))
            {
                writer.OnNotification += (_, e) =>
                {
                    var msg = e?.Message?.Trim();
                    if (!string.IsNullOrWhiteSpace(msg))
                        warnings.Add("ACadSharp write: " + msg);
                };
                writer.Write();
            }

            var ok = File.Exists(dxfPath) && new FileInfo(dxfPath).Length > 128;
            if (!ok)
                warnings.Add("Konwersja DWG->DXF nie utworzyła użytecznego pliku.");
            else if (!string.IsNullOrWhiteSpace(persistentCache))
            {
                try { File.Copy(dxfPath, persistentCache, true); } catch { }
            }

            return new DwgConversionResult
            {
                Ok = ok,
                DxfPath = ok ? dxfPath : "",
                Engine = "ACadSharp 3.6.51",
                Warnings = warnings.Distinct().Take(30).ToList()
            };
        }
        catch (OperationCanceledException)
        {
            try { if (File.Exists(dxfPath)) File.Delete(dxfPath); } catch { }
            throw;
        }
        catch (Exception ex)
        {
            try { if (File.Exists(dxfPath)) File.Delete(dxfPath); } catch { }
            warnings.Add($"DWG_CONVERSION_FAILED: {ex.GetType().Name}: {ex.Message}");
            return new DwgConversionResult
            {
                Ok = false,
                Engine = "ACadSharp 3.6.51",
                Warnings = warnings.Distinct().Take(30).ToList()
            };
        }
    }
}
