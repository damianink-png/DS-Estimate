using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

public sealed class QuoteReleaseDecision
{
    public bool CanExport { get; set; }
    public bool UsesOverride { get; set; }
    public bool OverrideInvalidated { get; set; }
    public string Fingerprint { get; set; } = "";
    public List<string> Blockers { get; set; } = [];
    public string Summary => CanExport
        ? UsesOverride
            ? "Eksport dozwolony jako audytowany wyjątek. Powód i osoba zatwierdzająca trafią do raportu oraz XLSX."
            : "Oferta gotowa do eksportu. Wszystkie wymagane obszary mają podstawę."
        : OverrideInvalidated
            ? $"Poprzedni wyjątek został unieważniony przez zmianę danych lub ustawień. Eksport zablokowany: {string.Join(" · ", Blockers)}"
        : Blockers.Count == 0
            ? "Oferta nie jest gotowa do eksportu."
            : $"Eksport oferty zablokowany: {string.Join(" · ", Blockers)}";
}

/// <summary>
/// FIX18 release gate. The diagnostic report always remains available, but an offer
/// XLSX is released only from a complete result or an explicit, state-bound exception.
/// </summary>
public sealed class QuoteReleaseService
{
    private static readonly JsonSerializerOptions HashJson = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = false
    };

    public QuoteReleaseDecision Evaluate(QuoteProject project, CostingSettings settings)
    {
        var blockers = BuildBlockers(project, settings);
        var fingerprint = ComputeFingerprint(project, settings);
        var approved = project.ReleaseOverride is
        {
            Granted: true,
            ApprovedAt: not null
        } approval &&
            (approval.Reason ?? "").Trim().Length >= 12 &&
            FixedEquals(approval.ApprovedFingerprint ?? "", fingerprint);

        return new QuoteReleaseDecision
        {
            CanExport = blockers.Count == 0 || approved,
            UsesOverride = blockers.Count > 0 && approved,
            OverrideInvalidated = blockers.Count > 0 && project.ReleaseOverride?.Granted == true && !approved,
            Fingerprint = fingerprint,
            Blockers = blockers
        };
    }

    public QuoteReleaseDecision ApproveOverride(
        QuoteProject project,
        CostingSettings settings,
        string reason,
        string approvedBy = "Użytkownik lokalny")
    {
        reason = (reason ?? "").Trim();
        if (reason.Length < 12)
            throw new InvalidOperationException("Podaj konkretne uzasadnienie wyjątku (minimum 12 znaków).");

        var decision = Evaluate(project, settings);
        if (decision.Blockers.Count == 0)
            throw new InvalidOperationException("Wycena jest kompletna — wyjątek nie jest potrzebny.");

        project.ReleaseOverride = new QuoteReleaseOverride
        {
            Granted = true,
            Reason = reason,
            ApprovedBy = string.IsNullOrWhiteSpace(approvedBy) ? "Użytkownik lokalny" : approvedBy.Trim(),
            ApprovedAt = DateTime.Now,
            ApprovedFingerprint = decision.Fingerprint
        };
        return Evaluate(project, settings);
    }

    public FrozenQuoteSnapshot FreezeForExport(QuoteProject project, CostingSettings settings)
    {
        var decision = Evaluate(project, settings);
        if (!decision.CanExport)
            throw new InvalidOperationException(decision.Summary);

        var documentHashes = GetDocumentHashes(project);
        var analysisHash = HashObject(project.Analysis);
        var settingsHash = HashObject(settings);
        var calibrationHash = HashObject(settings.RuntimeCalibration ?? new CalibrationProfile());
        var engineHash = HashText(string.Join("|", new[]
        {
            EngineResultCache.VersionForScript("step-v1", "analyze_step.py"),
            EngineResultCache.VersionForScripts("document-v1", "analyze_document.py", "analyze_dxf.py", "analyze_tabular.py")
        }));

        var snapshot = new FrozenQuoteSnapshot
        {
            CreatedAt = DateTime.Now,
            ReleaseMode = decision.UsesOverride ? "WYJĄTEK AUDYTOWANY" : "STANDARD",
            Fingerprint = decision.Fingerprint,
            AnalysisHash = analysisHash,
            SettingsHash = settingsHash,
            CalibrationHash = calibrationHash,
            EngineHash = engineHash,
            ReleaseAuditHash = HashObject(project.ReleaseOverride ?? new QuoteReleaseOverride()),
            DocumentHashes = documentHashes
        };
        project.FrozenSnapshot = snapshot;
        return snapshot;
    }

    public string ComputeFingerprint(QuoteProject project, CostingSettings settings)
    {
        var state = new
        {
            project.Id,
            project.Revision,
            Name = project.Name?.Trim(),
            Customer = project.Customer?.Trim(),
            project.ManualWeightKg,
            Documents = GetDocumentHashes(project).OrderBy(x => x.Key, StringComparer.OrdinalIgnoreCase),
            AnalysisHash = HashObject(project.Analysis),
            SettingsHash = HashObject(settings),
            CalibrationHash = HashObject(settings.RuntimeCalibration ?? new CalibrationProfile()),
            EngineHash = HashText(string.Join("|", new[]
            {
                EngineResultCache.VersionForScript("step-v1", "analyze_step.py"),
                EngineResultCache.VersionForScripts("document-v1", "analyze_document.py", "analyze_dxf.py", "analyze_tabular.py")
            }))
        };
        return HashObject(state);
    }

    public string ComputeSettingsHash(CostingSettings settings) => HashText(
        HashObject(settings) + "|" + HashObject(settings.RuntimeCalibration ?? new CalibrationProfile()));

    private List<string> BuildBlockers(QuoteProject project, CostingSettings settings)
    {
        var blockers = new List<string>();
        var analysis = project.Analysis;
        if (analysis is null)
            return ["brak wyniku analizy"];

        if (!analysis.AutoQuote.HasRecommendedPrice || !analysis.AutoQuote.IsPriceComplete)
            blockers.Add("brak kompletnej ceny rekomendowanej");
        var currentSettingsHash = ComputeSettingsHash(settings);
        if (string.IsNullOrWhiteSpace(analysis.ReleaseSettingsHash))
            blockers.Add("wynik wymaga przeliczenia w FIX18");
        else if (!FixedEquals(analysis.ReleaseSettingsHash, currentSettingsHash))
            blockers.Add("ustawienia zmieniły się od ostatniego przeliczenia");
        if (!analysis.RatesConfirmedByCompany)
            blockers.Add("stawki nie są potwierdzone firmowo");
        if (analysis.AutoQuote.UnpricedExternalOperationCount > 0)
            blockers.Add($"operacje zewnętrzne bez ceny: {analysis.AutoQuote.UnpricedExternalOperationCount}");
        if (analysis.AutoQuote.RevisionWarning ||
            analysis.Risks.Any(x => x.Blocking && x.Code.Contains("REV", StringComparison.OrdinalIgnoreCase)))
            blockers.Add("niejednoznaczna rewizja dokumentacji");

        var readiness = analysis.AutoQuote.ReadinessItems
            .Where(x => !x.IsReady)
            .Select(x => $"{x.Label}: {x.Status}")
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        if (readiness.Count > 0)
            blockers.Add("gotowość: " + string.Join(", ", readiness.Take(6)));
        return blockers.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }

    private static Dictionary<string, string> GetDocumentHashes(QuoteProject project)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var document in project.Documents
                     .OrderBy(x => x.RelativePath, StringComparer.OrdinalIgnoreCase)
                     .ThenBy(x => x.Name, StringComparer.OrdinalIgnoreCase))
        {
            var key = string.IsNullOrWhiteSpace(document.RelativePath) ? document.Name : document.RelativePath;
            var hash = document.ContentHash?.Trim() ?? "";
            if (hash.Length == 0 && File.Exists(document.Path))
            {
                try
                {
                    using var stream = File.OpenRead(document.Path);
                    hash = Convert.ToHexString(SHA256.HashData(stream));
                }
                catch
                {
                    hash = $"UNREADABLE:{document.SizeBytes}";
                }
            }
            if (hash.Length == 0)
                hash = $"NOHASH:{document.SizeBytes}";
            result[$"{key}|{document.SizeBytes}"] = hash.ToUpperInvariant();
        }
        return result;
    }

    private static string HashObject(object? value) =>
        HashText(JsonSerializer.Serialize(value, HashJson));

    private static string HashText(string value) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value ?? "")));

    private static bool FixedEquals(string left, string right)
    {
        if (left.Length != right.Length || left.Length == 0)
            return false;
        return CryptographicOperations.FixedTimeEquals(
            Encoding.ASCII.GetBytes(left.ToUpperInvariant()),
            Encoding.ASCII.GetBytes(right.ToUpperInvariant()));
    }
}
