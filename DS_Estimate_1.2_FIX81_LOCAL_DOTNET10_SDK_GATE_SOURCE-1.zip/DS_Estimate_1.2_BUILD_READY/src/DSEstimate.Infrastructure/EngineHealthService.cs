using System.Diagnostics;
using System.Reflection;

namespace DSEstimate.Infrastructure;

public sealed class EngineHealthItem
{
    public string Engine { get; set; } = "";
    public string Status { get; set; } = "NIEZNANY";
    public string Version { get; set; } = "";
    public string Detail { get; set; } = "";
    public bool IsReady => Status is "GOTOWY" or "CZUWA";
    public bool NeedsAttention => !IsReady;
    public string Display => string.IsNullOrWhiteSpace(Version)
        ? $"{Engine}: {Status} · {Detail}"
        : $"{Engine}: {Status} · {Version} · {Detail}";
}

public sealed class EngineHealthReport
{
    public DateTime CapturedAt { get; set; } = DateTime.Now;
    public List<EngineHealthItem> Items { get; set; } = [];
    public int ReadyCount => Items.Count(x => x.IsReady);
    public int AttentionCount => Items.Count(x => x.NeedsAttention);
    public string Summary => AttentionCount == 0
        ? $"Silniki gotowe: {ReadyCount}/{Items.Count} · {CapturedAt:HH:mm:ss}"
        : $"Silniki gotowe: {ReadyCount}/{Items.Count} · sprawdź {AttentionCount} · {CapturedAt:HH:mm:ss}";
}

/// <summary>Fast, offline-only runtime inventory for the Settings status panel.</summary>
public sealed class EngineHealthService
{
    public EngineHealthReport Capture()
    {
        var report = new EngineHealthReport();
        var python = FindFile(Path.Combine("py", "python.exe"));
        var tesseract = FindFile(Path.Combine("tools", "ocr", "tesseract.exe"));
        var acad = FindFile("ACadSharp.dll");
        var documentEngine = FindFile(Path.Combine("engines", "python", "analyze_document.py"));
        var stepEngine = FindFile(Path.Combine("engines", "python", "analyze_step.py"));

        report.Items.Add(new EngineHealthItem
        {
            Engine = ".NET",
            Status = "GOTOWY",
            Version = Environment.Version.ToString(),
            Detail = Environment.Is64BitProcess ? "proces 64-bit" : "proces 32-bit"
        });
        report.Items.Add(FileItem("Python / moduły", python, "wbudowany runtime offline"));
        report.Items.Add(FileItem("STEP / CadQuery", stepEngine, "analizator geometrii"));

        var workers = PythonRunner.GetStepWorkerHealth();
        report.Items.Add(new EngineHealthItem
        {
            Engine = "STEP worker",
            Status = workers.Count == 0 ? "CZUWA" : workers.Any(x => x.Status == "PRACUJE") ? "GOTOWY" : "CZUWA",
            Version = $"pool {Math.Max(2, workers.Count)}",
            Detail = workers.Count == 0
                ? "uruchomi się przy pierwszym STEP"
                : string.Join(" | ", workers.Select(x => x.Summary))
        });

        var ocr = FileItem("Tesseract OCR", tesseract, "OCR lokalny");
        if (!string.IsNullOrWhiteSpace(tesseract))
        {
            ocr.Version = FileVersion(tesseract);
            var tessdata = Path.Combine(Path.GetDirectoryName(tesseract)!, "tessdata");
            var languages = new[] { "pol", "eng", "deu", "fra" }
                .Where(x => File.Exists(Path.Combine(tessdata, x + ".traineddata")))
                .ToList();
            ocr.Detail = $"języki {string.Join(", ", languages)}";
            if (languages.Count < 4)
                ocr.Status = "UWAGA";
        }
        report.Items.Add(ocr);
        report.Items.Add(FileItem("Dokumenty PDF/BOM", documentEngine, "pypdf · PyMuPDF · openpyxl · xlrd · docx"));
        report.Items.Add(FileItem("DWG / ACadSharp", acad, "lokalna konwersja DWG → DXF"));

        var ram = ResourceGovernor.GetSnapshot();
        report.Items.Add(new EngineHealthItem
        {
            Engine = "Pamięć",
            Status = ram.MemoryLoadPercent <= 88 ? "GOTOWY" : "UWAGA",
            Version = "RAM",
            Detail = ram.Summary
        });
        return report;
    }

    private static EngineHealthItem FileItem(string engine, string? path, string detail)
    {
        var exists = !string.IsNullOrWhiteSpace(path) && File.Exists(path);
        return new EngineHealthItem
        {
            Engine = engine,
            Status = exists ? "GOTOWY" : "BRAK",
            Version = exists ? FileVersion(path!) : "",
            Detail = exists ? detail : "nie znaleziono składnika w paczce aplikacji"
        };
    }

    private static string FileVersion(string path)
    {
        try
        {
            return FileVersionInfo.GetVersionInfo(path).FileVersion ??
                   AssemblyName.GetAssemblyName(path).Version?.ToString() ?? "wersja niepodana";
        }
        catch
        {
            return "wersja niepodana";
        }
    }

    private static string? FindFile(string relativePath)
    {
        var roots = new List<string> { AppContext.BaseDirectory, Environment.CurrentDirectory };
        var cursor = new DirectoryInfo(AppContext.BaseDirectory);
        for (var i = 0; i < 6 && cursor is not null; i++, cursor = cursor.Parent)
            roots.Add(cursor.FullName);
        foreach (var root in roots.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            var candidate = Path.Combine(root, relativePath);
            if (File.Exists(candidate))
                return Path.GetFullPath(candidate);
        }
        return null;
    }
}
