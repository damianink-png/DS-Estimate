﻿using System.Text.Json;
using DSEstimate.Core;
using Microsoft.Data.Sqlite;

namespace DSEstimate.Infrastructure;

public sealed class ProjectRepository
{
    private readonly string _databasePath;
    private readonly JsonSerializerOptions _json = new() { WriteIndented = false };

    public ProjectRepository()
    {
        var dir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "DSEstimateNext");

        Directory.CreateDirectory(dir);
        _databasePath = Path.Combine(dir, "dse_next.db");
        Initialize();
    }

    private string ConnectionString => $"Data Source={_databasePath}";

    private void Initialize()
    {
        using var connection = new SqliteConnection(ConnectionString);
        connection.Open();

        using var cmd = connection.CreateCommand();
        cmd.CommandText = """
            PRAGMA journal_mode=WAL;

            CREATE TABLE IF NOT EXISTS projects (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                customer TEXT NOT NULL,
                revision INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                modified_at TEXT NOT NULL,
                final_price REAL NULL,
                payload_json TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_projects_modified
            ON projects(modified_at DESC);

            CREATE INDEX IF NOT EXISTS idx_projects_name
            ON projects(name);

            CREATE TABLE IF NOT EXISTS revisions (
                project_id TEXT NOT NULL,
                revision INTEGER NOT NULL,
                saved_at TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                PRIMARY KEY(project_id, revision)
            );

            CREATE TABLE IF NOT EXISTS drafts (
                slot TEXT PRIMARY KEY,
                modified_at TEXT NOT NULL,
                payload_json TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS history_imports (
                source_key TEXT PRIMARY KEY,
                project_id TEXT NOT NULL,
                imported_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_history_import_project
            ON history_imports(project_id);
            """;
        cmd.ExecuteNonQuery();
    }

    public void SaveDraft(QuoteProject project)
    {
        project.ModifiedAt = DateTime.Now;
        var payload = JsonSerializer.Serialize(project, _json);

        using var connection = new SqliteConnection(ConnectionString);
        connection.Open();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = """
            INSERT INTO drafts(slot, modified_at, payload_json)
            VALUES('current', $modified, $payload)
            ON CONFLICT(slot) DO UPDATE SET
                modified_at=$modified,
                payload_json=$payload;
            """;
        cmd.Parameters.AddWithValue("$modified", project.ModifiedAt.ToString("O"));
        cmd.Parameters.AddWithValue("$payload", payload);
        cmd.ExecuteNonQuery();
    }

    public QuoteProject? LoadDraft()
    {
        using var connection = new SqliteConnection(ConnectionString);
        connection.Open();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT payload_json FROM drafts WHERE slot='current' LIMIT 1;";
        var payload = cmd.ExecuteScalar() as string;
        return string.IsNullOrWhiteSpace(payload)
            ? null
            : JsonSerializer.Deserialize<QuoteProject>(payload);
    }

    public void DeleteDraft()
    {
        using var connection = new SqliteConnection(ConnectionString);
        connection.Open();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "DELETE FROM drafts WHERE slot='current';";
        cmd.ExecuteNonQuery();
    }

    public async Task SaveAsync(QuoteProject project)
    {
        project.ModifiedAt = DateTime.Now;
        project.Revision += 1;

        var payload = JsonSerializer.Serialize(project, _json);

        await using var connection = new SqliteConnection(ConnectionString);
        await connection.OpenAsync();
        using var transaction = connection.BeginTransaction();

        await using (var cmd = connection.CreateCommand())
        {
            cmd.Transaction = transaction;
            cmd.CommandText = """
                INSERT INTO projects(
                    id, name, customer, revision, created_at, modified_at, final_price, payload_json)
                VALUES(
                    $id, $name, $customer, $revision, $created, $modified, $price, $payload)
                ON CONFLICT(id) DO UPDATE SET
                    name=$name,
                    customer=$customer,
                    revision=$revision,
                    modified_at=$modified,
                    final_price=$price,
                    payload_json=$payload;
                """;

            cmd.Parameters.AddWithValue("$id", project.Id.ToString());
            cmd.Parameters.AddWithValue("$name", project.Name);
            cmd.Parameters.AddWithValue("$customer", project.Customer ?? "");
            cmd.Parameters.AddWithValue("$revision", project.Revision);
            cmd.Parameters.AddWithValue("$created", project.CreatedAt.ToString("O"));
            cmd.Parameters.AddWithValue("$modified", project.ModifiedAt.ToString("O"));
            cmd.Parameters.AddWithValue(
                "$price",
                project.Analysis is null
                    ? (object)DBNull.Value
                    : project.Analysis.FinalPricePln);
            cmd.Parameters.AddWithValue("$payload", payload);

            await cmd.ExecuteNonQueryAsync();
        }

        await using (var rev = connection.CreateCommand())
        {
            rev.Transaction = transaction;
            rev.CommandText = """
                INSERT OR REPLACE INTO revisions(
                    project_id, revision, saved_at, payload_json)
                VALUES($id, $revision, $saved, $payload);
                """;

            rev.Parameters.AddWithValue("$id", project.Id.ToString());
            rev.Parameters.AddWithValue("$revision", project.Revision);
            rev.Parameters.AddWithValue("$saved", DateTime.Now.ToString("O"));
            rev.Parameters.AddWithValue("$payload", payload);
            await rev.ExecuteNonQueryAsync();
        }

        transaction.Commit();
    }

    public async Task<QuoteProject?> LoadAsync(Guid id)
    {
        await using var connection = new SqliteConnection(ConnectionString);
        await connection.OpenAsync();

        await using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT payload_json FROM projects WHERE id=$id LIMIT 1;";
        cmd.Parameters.AddWithValue("$id", id.ToString());

        var payload = await cmd.ExecuteScalarAsync() as string;
        return string.IsNullOrWhiteSpace(payload)
            ? null
            : JsonSerializer.Deserialize<QuoteProject>(payload);
    }

    public Task<List<ProjectListItem>> RecentAsync(int limit = 6) =>
        SearchAsync("", limit);

    public async Task<List<ProjectListItem>> SearchAsync(string query, int limit = 200)
    {
        var items = new List<ProjectListItem>();

        await using var connection = new SqliteConnection(ConnectionString);
        await connection.OpenAsync();

        await using var cmd = connection.CreateCommand();
        var hasQuery = !string.IsNullOrWhiteSpace(query);

        cmd.CommandText = hasQuery
            ? """
              SELECT id, name, customer, modified_at, final_price, revision
              FROM projects
              WHERE name LIKE $q COLLATE NOCASE
                 OR customer LIKE $q COLLATE NOCASE
              ORDER BY modified_at DESC
              LIMIT $limit;
              """
            : """
              SELECT id, name, customer, modified_at, final_price, revision
              FROM projects
              ORDER BY modified_at DESC
              LIMIT $limit;
              """;

        if (hasQuery)
            cmd.Parameters.AddWithValue("$q", $"%{query.Trim()}%");

        cmd.Parameters.AddWithValue("$limit", limit);

        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            items.Add(new ProjectListItem
            {
                Id = Guid.Parse(reader.GetString(0)),
                Name = reader.GetString(1),
                Customer = reader.GetString(2),
                ModifiedAt = DateTime.Parse(reader.GetString(3)),
                PricePln = reader.IsDBNull(4) ? null : reader.GetDouble(4),
                Revision = reader.GetInt32(5)
            });
        }

        return items;
    }

    public async Task<List<QuoteProject>> LoadRecentProjectsAsync(int limit = 80)
    {
        var result = new List<QuoteProject>();

        await using var connection = new SqliteConnection(ConnectionString);
        await connection.OpenAsync();

        await using var cmd = connection.CreateCommand();
        cmd.CommandText = """
            SELECT payload_json
            FROM projects
            ORDER BY modified_at DESC
            LIMIT $limit;
            """;
        cmd.Parameters.AddWithValue("$limit", limit);

        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            var item = JsonSerializer.Deserialize<QuoteProject>(reader.GetString(0));
            if (item is not null)
                result.Add(item);
        }

        return result;
    }


    public async Task<bool> IsHistorySourceImportedAsync(string sourceKey)
    {
        if (string.IsNullOrWhiteSpace(sourceKey))
            return false;

        await using var connection = new SqliteConnection(ConnectionString);
        await connection.OpenAsync();
        await using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT 1 FROM history_imports WHERE source_key=$key LIMIT 1;";
        cmd.Parameters.AddWithValue("$key", sourceKey);
        return await cmd.ExecuteScalarAsync() is not null;
    }

    public async Task<Guid?> GetHistoryProjectIdAsync(string sourceKey)
    {
        if (string.IsNullOrWhiteSpace(sourceKey))
            return null;

        await using var connection = new SqliteConnection(ConnectionString);
        await connection.OpenAsync();
        await using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT project_id FROM history_imports WHERE source_key=$key LIMIT 1;";
        cmd.Parameters.AddWithValue("$key", sourceKey);
        var value = await cmd.ExecuteScalarAsync() as string;
        return Guid.TryParse(value, out var id) ? id : null;
    }

    public async Task DeleteProjectDataAsync(Guid projectId)
    {
        await using var connection = new SqliteConnection(ConnectionString);
        await connection.OpenAsync();
        using var transaction = connection.BeginTransaction();

        await using (var rev = connection.CreateCommand())
        {
            rev.Transaction = transaction;
            rev.CommandText = "DELETE FROM revisions WHERE project_id=$id;";
            rev.Parameters.AddWithValue("$id", projectId.ToString());
            await rev.ExecuteNonQueryAsync();
        }

        await using (var proj = connection.CreateCommand())
        {
            proj.Transaction = transaction;
            proj.CommandText = "DELETE FROM projects WHERE id=$id;";
            proj.Parameters.AddWithValue("$id", projectId.ToString());
            await proj.ExecuteNonQueryAsync();
        }

        transaction.Commit();
    }

    public async Task RegisterHistoryImportAsync(string sourceKey, Guid projectId)
    {
        if (string.IsNullOrWhiteSpace(sourceKey))
            return;

        await using var connection = new SqliteConnection(ConnectionString);
        await connection.OpenAsync();
        await using var cmd = connection.CreateCommand();
        cmd.CommandText = """
            INSERT OR REPLACE INTO history_imports(source_key, project_id, imported_at)
            VALUES($key, $project, $at);
            """;
        cmd.Parameters.AddWithValue("$key", sourceKey);
        cmd.Parameters.AddWithValue("$project", projectId.ToString());
        cmd.Parameters.AddWithValue("$at", DateTime.Now.ToString("O"));
        await cmd.ExecuteNonQueryAsync();
    }


    public async Task<int> ClearImportedHistoryAsync()
    {
        await using var connection = new SqliteConnection(ConnectionString);
        await connection.OpenAsync();
        using var transaction = connection.BeginTransaction();

        int count;
        await using (var c = connection.CreateCommand())
        {
            c.Transaction = transaction;
            c.CommandText = "SELECT COUNT(*) FROM history_imports;";
            count = Convert.ToInt32(await c.ExecuteScalarAsync() ?? 0);
        }

        await using (var rev = connection.CreateCommand())
        {
            rev.Transaction = transaction;
            rev.CommandText = "DELETE FROM revisions WHERE project_id IN (SELECT project_id FROM history_imports);";
            await rev.ExecuteNonQueryAsync();
        }
        await using (var proj = connection.CreateCommand())
        {
            proj.Transaction = transaction;
            proj.CommandText = "DELETE FROM projects WHERE id IN (SELECT project_id FROM history_imports);";
            await proj.ExecuteNonQueryAsync();
        }
        await using (var hist = connection.CreateCommand())
        {
            hist.Transaction = transaction;
            hist.CommandText = "DELETE FROM history_imports;";
            await hist.ExecuteNonQueryAsync();
        }

        transaction.Commit();
        return count;
    }

    public async Task DeleteAsync(Guid id)
    {
        await using var connection = new SqliteConnection(ConnectionString);
        await connection.OpenAsync();
        using var transaction = connection.BeginTransaction();

        await using (var r = connection.CreateCommand())
        {
            r.Transaction = transaction;
            r.CommandText = "DELETE FROM revisions WHERE project_id=$id;";
            r.Parameters.AddWithValue("$id", id.ToString());
            await r.ExecuteNonQueryAsync();
        }

        await using (var h = connection.CreateCommand())
        {
            h.Transaction = transaction;
            h.CommandText = "DELETE FROM history_imports WHERE project_id=$id;";
            h.Parameters.AddWithValue("$id", id.ToString());
            await h.ExecuteNonQueryAsync();
        }

        await using (var p = connection.CreateCommand())
        {
            p.Transaction = transaction;
            p.CommandText = "DELETE FROM projects WHERE id=$id;";
            p.Parameters.AddWithValue("$id", id.ToString());
            await p.ExecuteNonQueryAsync();
        }

        transaction.Commit();
    }
}
