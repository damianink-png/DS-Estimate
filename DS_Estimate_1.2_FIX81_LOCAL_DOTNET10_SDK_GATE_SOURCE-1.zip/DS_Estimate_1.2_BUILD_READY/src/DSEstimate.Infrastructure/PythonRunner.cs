﻿using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text;
using System.Text.Json;

namespace DSEstimate.Infrastructure;

public sealed class StepWorkerHealthInfo
{
    public int WorkerNumber { get; set; }
    public string Status { get; set; } = "NIEURUCHOMIONY";
    public int ProcessId { get; set; }
    public int CompletedJobs { get; set; }
    public double PrivateMemoryMb { get; set; }
    public DateTime? StartedUtc { get; set; }
    public string LastLifecycleReason { get; set; } = "";
    public string Summary => ProcessId <= 0
        ? $"worker {WorkerNumber}: {Status.ToLowerInvariant()}"
        : $"worker {WorkerNumber}: {Status.ToLowerInvariant()} · PID {ProcessId} · {PrivateMemoryMb:0} MB · zadania {CompletedJobs}";
}

public sealed class PythonRunner
{
    private static readonly SemaphoreSlim RuntimeLock = new(1, 1);
    private static readonly ConcurrentDictionary<string, string> PreferredPythonByProfile =
        new(StringComparer.OrdinalIgnoreCase);
    // FIX10K / A1: keep up to two CadQuery/OCP Python processes alive.  Importing
    // CadQuery/OCP is expensive, while consecutive STEP jobs in one RFQ normally use
    // the same runtime.  The pool is keyed by the resolved Python runtime so portable
    // and developer environments never share a worker accidentally.
    private static readonly ConcurrentDictionary<string, StepWorkerPool> StepWorkerPools =
        new(StringComparer.OrdinalIgnoreCase);
    // FIX14: even when ProjectAnalysisService discovers many PDFs in parallel, only
    // two document-engine processes may exist at once. OCR inside each process is
    // additionally streamed page-by-page by analyze_document.py.
    private static readonly SemaphoreSlim DocumentEngineLock = new(2, 2);

    public static IReadOnlyList<StepWorkerHealthInfo> GetStepWorkerHealth() =>
        StepWorkerPools.Values.SelectMany(x => x.GetHealth()).ToList();

    public static int RestartIdleStepWorkers()
    {
        var restarted = 0;
        foreach (var pool in StepWorkerPools.Values)
            restarted += pool.RestartIdleWorkers();
        return restarted;
    }

    public async Task<(bool Ok, string Stdout, string Stderr)> RunAsync(
        string scriptName,
        string argument,
        CancellationToken cancellationToken = default,
        IReadOnlyDictionary<string, string>? environment = null,
        TimeSpan? executionTimeout = null,
        Action<string>? progressLine = null)
    {
        var script = ResolveScript(scriptName);
        if (script is null)
            return (false, "", $"Nie znaleziono skryptu {scriptName}. Folder aplikacji: {AppContext.BaseDirectory}");

        var requirement = RuntimeRequirementFor(scriptName, argument);
        var diagnostics = new List<string>();
        var python = await ResolveHealthyPythonAsync(script, requirement, diagnostics, cancellationToken);
        if (string.IsNullOrWhiteSpace(python))
        {
            return (
                false,
                "",
                $"Profil silnika Python '{requirement.Key}' nie jest gotowy. " +
                string.Join(" | ", diagnostics.TakeLast(8)));
        }

        var heavyEngine = Path.GetFileName(script).Equals("analyze_document.py", StringComparison.OrdinalIgnoreCase) ||
                          Path.GetFileName(script).Equals("analyze_step.py", StringComparison.OrdinalIgnoreCase) ||
                          Path.GetFileName(script).Equals("prescan_step_batch.py", StringComparison.OrdinalIgnoreCase);
        if (heavyEngine && !await ResourceGovernor.WaitForHeadroomAsync(cancellationToken))
        {
            var snapshot = ResourceGovernor.GetSnapshot();
            return (false, "", $"RESOURCE_GOVERNOR: wstrzymano {scriptName}, bo system nie odzyskał bezpiecznego zapasu pamięci. {snapshot.Summary}. Zamknij ciężkie aplikacje lub spróbuj ponownie.");
        }

        // FIX10K / A1 persistent STEP worker.  One worker stays sequential and the
        // host owns a two-worker pool, so multi-root STEP analysis still has the same
        // memory safety limit as before but avoids repeated CadQuery/OCP cold starts.
        // Set DSE_DISABLE_PERSISTENT_STEP_WORKER=1 only for diagnostics/recovery.
        if (Path.GetFileName(script).Equals("analyze_step.py", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(Environment.GetEnvironmentVariable("DSE_DISABLE_PERSISTENT_STEP_WORKER"), "1", StringComparison.Ordinal))
        {
            var workerScript = ResolveScript("step_worker.py");
            if (workerScript is not null)
            {
                var poolKey = Path.GetFullPath(python) + "|" + Path.GetFullPath(workerScript);
                var pool = StepWorkerPools.GetOrAdd(poolKey, _ => new StepWorkerPool(python, workerScript, 2));
                return await pool.RunAsync(argument, environment, executionTimeout, cancellationToken, progressLine);
            }
        }

        ProcessResult run;
        using var watchdog = executionTimeout.HasValue
            ? CancellationTokenSource.CreateLinkedTokenSource(cancellationToken)
            : null;
        if (watchdog is not null)
            watchdog.CancelAfter(executionTimeout!.Value);

        var documentGateHeld = false;
        try
        {
            if (Path.GetFileName(script).Equals("analyze_document.py", StringComparison.OrdinalIgnoreCase))
            {
                await DocumentEngineLock.WaitAsync(watchdog?.Token ?? cancellationToken);
                documentGateHeld = true;
            }
            run = await ExecuteAsync(
                python,
                [],
                [script, argument],
                watchdog?.Token ?? cancellationToken,
                environment,
                progressLine);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested && executionTimeout.HasValue)
        {
            return (false, "", $"TIMEOUT: analizator {scriptName} przekroczył limit {executionTimeout.Value.TotalSeconds:0} s i został zatrzymany przez watchdog.");
        }
        catch (OutOfMemoryException ex)
        {
            return (false, "", $"RESOURCE_GOVERNOR/OOM: {scriptName} zatrzymany przed wyczerpaniem pamięci: {ex.Message}");
        }
        finally
        {
            if (documentGateHeld)
                DocumentEngineLock.Release();
        }

        if (run.ExitCode == 0 && !string.IsNullOrWhiteSpace(run.Stdout))
            return (true, run.Stdout, run.Stderr);

        diagnostics.Add(
            $"{Path.GetFileName(python)} exit={run.ExitCode}: {Tail(run.Stderr, 800)}");

        return (
            false,
            run.Stdout,
            "Nie udało się uruchomić analizatora. " + string.Join(" | ", diagnostics.TakeLast(8)));
    }

    private static async Task<string?> ResolveHealthyPythonAsync(
        string script,
        RuntimeRequirement requirement,
        List<string> diagnostics,
        CancellationToken cancellationToken)
    {
        if (PreferredPythonByProfile.TryGetValue(requirement.Key, out var preferred) &&
            CandidateStillAvailable(preferred))
            return preferred;

        await RuntimeLock.WaitAsync(cancellationToken);
        try
        {
            if (PreferredPythonByProfile.TryGetValue(requirement.Key, out preferred) &&
                CandidateStillAvailable(preferred))
                return preferred;

            var requirements = Path.Combine(Path.GetDirectoryName(script)!, "requirements.txt");

            // Full-portable builds carry an official CPython embeddable runtime
            // under runtime\python. Prefer it before any machine-level Python or venv.
            // A healthy bundled runtime means the target PC needs no Python install
            // and no network access.
            var bundled = BundledPythonPath();
            if (File.Exists(bundled))
            {
                if (await IsHealthyRuntimeAsync(bundled, requirement, cancellationToken))
                {
                    PreferredPythonByProfile[requirement.Key] = bundled;
                    return bundled;
                }
                diagnostics.Add($"Wbudowany runtime nie spełnia profilu {requirement.Key}: {bundled}");
            }

            // A full portable release is intentionally network-free on the target PC.
            // If the bundled runtime is missing/corrupted, fail clearly instead of
            // trying pip/venv/system Python and accidentally reaching the Internet.
            if (IsOfflinePortable())
            {
                diagnostics.Add(
                    "Tryb OFFLINE_PORTABLE: wymagany jest dołączony runtime Python; " +
                    $"brakuje zależności profilu {requirement.Key}; automatyczna instalacja/naprawa przez pip jest wyłączona.");
                return null;
            }

            foreach (var candidate in ExistingVenvCandidates())
            {
                if (!File.Exists(candidate))
                    continue;

                if (await IsHealthyRuntimeAsync(candidate, requirement, cancellationToken))
                {
                    PreferredPythonByProfile[requirement.Key] = candidate;
                    return candidate;
                }

                diagnostics.Add($"Środowisko nie spełnia profilu {requirement.Key}: {candidate}");

                // Existing source/test venvs are repaired in place first. This
                // avoids downloading a second CadQuery environment after an update.
                if (File.Exists(requirements))
                {
                    var repair = await ExecuteAsync(
                        candidate,
                        [],
                        ["-m", "pip", "install", "--disable-pip-version-check", "-r", requirements],
                        cancellationToken);
                    if (repair.ExitCode == 0 && await IsHealthyRuntimeAsync(candidate, requirement, cancellationToken))
                    {
                        PreferredPythonByProfile[requirement.Key] = candidate;
                        return candidate;
                    }
                    diagnostics.Add($"Naprawa venv: {Tail(repair.Stderr, 800)}");
                }
            }

            var managed = ManagedPythonPath();
            if (File.Exists(managed) && await IsHealthyRuntimeAsync(managed, requirement, cancellationToken))
            {
                PreferredPythonByProfile[requirement.Key] = managed;
                return managed;
            }

            if (!File.Exists(requirements))
            {
                diagnostics.Add($"Brak requirements.txt przy silnikach: {requirements}");
                return null;
            }

            var created = await EnsureManagedRuntimeAsync(
                managed,
                requirements,
                diagnostics,
                cancellationToken);

            if (created && File.Exists(managed) && await IsHealthyRuntimeAsync(managed, requirement, cancellationToken))
            {
                PreferredPythonByProfile[requirement.Key] = managed;
                return managed;
            }

            // Last chance: a system Python may already have all packages.
            foreach (var candidate in SystemPythonCandidates())
            {
                if (await IsHealthyRuntimeAsync(candidate.FileName, candidate.PrefixArgs, requirement, cancellationToken))
                {
                    // System launcher with prefix args cannot be stored as a simple path,
                    // so only direct python.exe candidates are promoted here.
                    if (candidate.PrefixArgs.Length == 0 &&
                        !candidate.FileName.Equals("py", StringComparison.OrdinalIgnoreCase))
                    {
                        PreferredPythonByProfile[requirement.Key] = candidate.FileName;
                        return candidate.FileName;
                    }
                }
            }

            return null;
        }
        finally
        {
            RuntimeLock.Release();
        }
    }

    private static async Task<bool> EnsureManagedRuntimeAsync(
        string managedPython,
        string requirements,
        List<string> diagnostics,
        CancellationToken cancellationToken)
    {
        var venvDir = Directory.GetParent(Directory.GetParent(managedPython)!.FullName)!.FullName;
        Directory.CreateDirectory(Path.GetDirectoryName(venvDir)!);

        var basePython = await FindCompatibleBasePythonAsync(diagnostics, cancellationToken);
        if (basePython is null)
        {
            diagnostics.Add("Nie znaleziono zgodnego Python 3.9–3.12 do utworzenia runtime.");
            return false;
        }

        try
        {
            if (!File.Exists(managedPython))
            {
                var createArgs = basePython.PrefixArgs
                    .Concat(["-m", "venv", venvDir])
                    .ToArray();
                var create = await ExecuteAsync(
                    basePython.FileName,
                    [],
                    createArgs,
                    cancellationToken);

                if (create.ExitCode != 0 || !File.Exists(managedPython))
                {
                    diagnostics.Add($"Tworzenie runtime: {Tail(create.Stderr, 1000)}");
                    return false;
                }
            }

            var pip = await ExecuteAsync(
                managedPython,
                [],
                ["-m", "pip", "install", "--disable-pip-version-check", "-r", requirements],
                cancellationToken);

            WriteBootstrapLog(pip.Stdout, pip.Stderr);
            if (pip.ExitCode != 0)
            {
                diagnostics.Add($"Instalacja bibliotek Python: {Tail(pip.Stderr, 1200)}");
                return false;
            }

            return true;
        }
        catch (Exception ex)
        {
            diagnostics.Add($"Runtime Python: {ex.GetType().Name}: {ex.Message}");
            return false;
        }
    }

    private static async Task<PythonCandidate?> FindCompatibleBasePythonAsync(
        List<string> diagnostics,
        CancellationToken cancellationToken)
    {
        foreach (var candidate in SystemPythonCandidates())
        {
            try
            {
                var args = candidate.PrefixArgs
                    .Concat(["-c", "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"])
                    .ToArray();
                var run = await ExecuteAsync(candidate.FileName, [], args, cancellationToken);
                if (run.ExitCode != 0)
                    continue;

                var version = run.Stdout.Trim().Split('.');
                if (version.Length < 2 || !int.TryParse(version[0], out var major) || !int.TryParse(version[1], out var minor))
                    continue;

                if (major == 3 && minor is >= 9 and <= 12)
                    return candidate;

                diagnostics.Add($"{candidate.Label}: Python {major}.{minor} poza zakresem 3.9–3.12.");
            }
            catch
            {
                // Try the next launcher.
            }
        }

        return null;
    }

    private static Task<bool> IsHealthyRuntimeAsync(
        string python,
        RuntimeRequirement requirement,
        CancellationToken cancellationToken) =>
        IsHealthyRuntimeAsync(python, [], requirement, cancellationToken);

    private static async Task<bool> IsHealthyRuntimeAsync(
        string python,
        string[] prefixArgs,
        RuntimeRequirement requirement,
        CancellationToken cancellationToken)
    {
        try
        {
            var imports = requirement.Modules.Length == 0
                ? ""
                : $"import {string.Join(", ", requirement.Modules)}; ";
            var code = imports + $"print('DS_ESTIMATE_RUNTIME_OK:{requirement.Key}')";
            var args = prefixArgs.Concat(["-c", code]).ToArray();
            var run = await ExecuteAsync(python, [], args, cancellationToken);
            return run.ExitCode == 0 &&
                   run.Stdout.Contains($"DS_ESTIMATE_RUNTIME_OK:{requirement.Key}", StringComparison.Ordinal);
        }
        catch
        {
            return false;
        }
    }

    private static RuntimeRequirement RuntimeRequirementFor(string scriptName, string argument)
    {
        var script = Path.GetFileName(scriptName).ToLowerInvariant();
        var extension = Path.GetExtension(argument).ToLowerInvariant();

        if (script is "analyze_step.py" or "prescan_step_batch.py")
            return new RuntimeRequirement("accurate", ["cadquery"]);

        if (script == "analyze_document.py")
        {
            // PDF text extraction is independently usable even when optional OCR is
            // unavailable. Raster input, in contrast, needs Pillow + Tesseract bridge.
            return extension == ".pdf"
                ? new RuntimeRequirement("document-pdf", ["pypdf", "pymupdf"])
                : new RuntimeRequirement("document-image", ["PIL", "pytesseract"]);
        }

        if (script == "analyze_dxf.py")
            // The analyzer contains a production ASCII fallback; ezdxf is an optional
            // richer reader and must not block unrelated DXF work.
            return new RuntimeRequirement("dxf-basic", []);

        if (script == "analyze_tabular.py")
        {
            return extension switch
            {
                ".xlsx" or ".xlsm" => new RuntimeRequirement("tabular-openxml", ["openpyxl"]),
                ".xls" => new RuntimeRequirement("tabular-xls", ["xlrd"]),
                ".docx" => new RuntimeRequirement("tabular-docx", ["docx"]),
                _ => new RuntimeRequirement("tabular-basic", [])
            };
        }

        return new RuntimeRequirement("python-basic", []);
    }

    private static bool CandidateStillAvailable(string python) =>
        File.Exists(python) ||
        (!python.Contains(Path.DirectorySeparatorChar) && !python.Contains(Path.AltDirectorySeparatorChar));

    private static async Task<ProcessResult> ExecuteAsync(
        string fileName,
        IReadOnlyList<string> prefixArgs,
        IReadOnlyList<string> args,
        CancellationToken cancellationToken,
        IReadOnlyDictionary<string, string>? environment = null,
        Action<string>? progressLine = null)
    {
        var psi = new ProcessStartInfo
        {
            FileName = fileName,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true,
            // Python is forced to UTF-8 below. Decode both redirected streams with
            // the same encoding on Polish Windows instead of the legacy ANSI page.
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8
        };
        psi.Environment["PYTHONUTF8"] = "1";
        psi.Environment["PYTHONIOENCODING"] = "utf-8";
        try
        {
            // The portable package intentionally ships without thousands of .pyc
            // files. Compile only modules that are really used and keep their cache
            // outside the app in a short, persistent path. This speeds later engine
            // starts without recreating deep __pycache__ trees in the installation.
            var localData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (!string.IsNullOrWhiteSpace(localData))
            {
                var bytecodeCache = Path.Combine(localData, "DSEstimateNext", "pycache", "cp312");
                var matplotlibCache = Path.Combine(localData, "DSEstimateNext", "cache", "matplotlib");
                Directory.CreateDirectory(bytecodeCache);
                Directory.CreateDirectory(matplotlibCache);
                psi.Environment["PYTHONPYCACHEPREFIX"] = bytecodeCache;
                psi.Environment["MPLCONFIGDIR"] = matplotlibCache;
            }
        }
        catch
        {
            // Cache placement is an optimisation. Python can still run without it.
        }
        if (environment is not null)
        {
            foreach (var pair in environment)
                psi.Environment[pair.Key] = pair.Value;
        }

        foreach (var item in prefixArgs)
            psi.ArgumentList.Add(item);
        foreach (var item in args)
            psi.ArgumentList.Add(item);

        using var process = Process.Start(psi);
        if (process is null)
            return new ProcessResult(-1, "", $"Nie udało się uruchomić {fileName}.");

        var stdoutTask = process.StandardOutput.ReadToEndAsync(cancellationToken);
        var stderrTask = ReadStderrAsync(process, progressLine, cancellationToken);
        try
        {
            await process.WaitForExitAsync(cancellationToken);
        }
        catch (OperationCanceledException)
        {
            try
            {
                if (!process.HasExited)
                    process.Kill(entireProcessTree: true);
            }
            catch
            {
                // Watchdog/cancel is best-effort; cancellation still propagates.
            }
            throw;
        }
        return new ProcessResult(process.ExitCode, await stdoutTask, await stderrTask);
    }

    private static async Task<string> ReadStderrAsync(
        Process process,
        Action<string>? progressLine,
        CancellationToken cancellationToken)
    {
        var sb = new StringBuilder();
        while (true)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var line = await process.StandardError.ReadLineAsync(cancellationToken);
            if (line is null)
                break;

            if (line.StartsWith("DSEPROGRESS|", StringComparison.Ordinal))
            {
                try { progressLine?.Invoke(line); } catch { }
                continue;
            }

            if (sb.Length > 0) sb.AppendLine();
            sb.Append(line);
        }
        return sb.ToString();
    }


    private sealed class StepWorkerPool
    {
        private readonly StepWorker[] _workers;
        private readonly SemaphoreSlim _slots;
        private int _next = -1;

        public StepWorkerPool(string python, string workerScript, int size)
        {
            size = Math.Clamp(size, 1, 2);
            _workers = Enumerable.Range(0, size)
                .Select(_ => new StepWorker(python, workerScript))
                .ToArray();
            _slots = new SemaphoreSlim(size, size);
        }

        public async Task<(bool Ok, string Stdout, string Stderr)> RunAsync(
            string path,
            IReadOnlyDictionary<string, string>? environment,
            TimeSpan? executionTimeout,
            CancellationToken cancellationToken,
            Action<string>? progressLine)
        {
            await _slots.WaitAsync(cancellationToken);
            try
            {
                var index = (int)((uint)Interlocked.Increment(ref _next) % (uint)_workers.Length);
                return await _workers[index].RunAsync(path, environment, executionTimeout, cancellationToken, progressLine);
            }
            finally
            {
                _slots.Release();
            }
        }

        public IEnumerable<StepWorkerHealthInfo> GetHealth()
        {
            for (var i = 0; i < _workers.Length; i++)
                yield return _workers[i].GetHealth(i + 1);
        }

        public int RestartIdleWorkers() => _workers.Count(x => x.RestartFromHealthPanel());
    }

    private sealed class StepWorker
    {
        private readonly string _python;
        private readonly string _workerScript;
        private readonly SemaphoreSlim _gate = new(1, 1);
        private readonly object _stderrSync = new();
        private readonly StringBuilder _stderr = new();
        private Process? _process;
        private Action<string>? _progressLine;
        private long _lastProgressUtcTicks;
        private int _completedJobs;
        private DateTime _startedUtc;
        private string _lastLifecycleReason = "";

        // FIX17: OCP/CadQuery may retain native allocations after Python gc.collect().
        // Recycle only between completed requests, preserving warm-start performance
        // without allowing one native process to grow for the whole application session.
        private static readonly int MaxJobs = ReadBoundedEnvironmentInt("DSE_STEP_WORKER_MAX_JOBS", 20, 1, 500);
        private static readonly int MaxPrivateMemoryMb = ReadBoundedEnvironmentInt("DSE_STEP_WORKER_MAX_PRIVATE_MB", 1536, 256, 32768);
        // FIX18: a native OCP allocation spike can exhaust the machine before the
        // between-job recycler runs. Poll the active process and terminate this one
        // request at a separate, higher ceiling. Project checkpoints/cache survive.
        private static readonly int MaxSingleJobPrivateMemoryMb = ReadBoundedEnvironmentInt("DSE_STEP_JOB_MAX_PRIVATE_MB", 2304, 512, 32768);
        private static readonly int JobHealthPollMilliseconds = ReadBoundedEnvironmentInt("DSE_STEP_JOB_HEALTH_POLL_MS", 2000, 250, 10000);
        private static readonly int MaxLifetimeMinutes = ReadBoundedEnvironmentInt("DSE_STEP_WORKER_MAX_MINUTES", 45, 1, 1440);
        private static readonly int QuitTimeoutSeconds = ReadBoundedEnvironmentInt("DSE_STEP_WORKER_QUIT_TIMEOUT_SECONDS", 3, 1, 30);

        public StepWorker(string python, string workerScript)
        {
            _python = python;
            _workerScript = workerScript;
        }

        public async Task<(bool Ok, string Stdout, string Stderr)> RunAsync(
            string path,
            IReadOnlyDictionary<string, string>? environment,
            TimeSpan? executionTimeout,
            CancellationToken cancellationToken,
            Action<string>? progressLine)
        {
            await _gate.WaitAsync(cancellationToken);
            try
            {
                EnsureStarted();
                lock (_stderrSync) _stderr.Clear();
                _progressLine = progressLine;

                var request = JsonSerializer.Serialize(new StepWorkerRequest
                {
                    Path = path,
                    Env = environment is null
                        ? new Dictionary<string, string>()
                        : environment.ToDictionary(x => x.Key, x => x.Value, StringComparer.Ordinal)
                });

                using var watchdog = executionTimeout.HasValue
                    ? CancellationTokenSource.CreateLinkedTokenSource(cancellationToken)
                    : null;
                if (watchdog is not null)
                    watchdog.CancelAfter(executionTimeout!.Value);
                var token = watchdog?.Token ?? cancellationToken;

                var idleWatchdogSeconds = 0;
                if (environment is not null && environment.TryGetValue("DSE_PROGRESS_IDLE_WATCHDOG_SECONDS", out var idleText))
                    int.TryParse(idleText, out idleWatchdogSeconds);
                Interlocked.Exchange(ref _lastProgressUtcTicks, DateTime.UtcNow.Ticks);

                try
                {
                    await _process!.StandardInput.WriteLineAsync(request.AsMemory(), token);
                    await _process.StandardInput.FlushAsync(token);
                    var responseTask = _process.StandardOutput.ReadLineAsync(token).AsTask();
                    while (!responseTask.IsCompleted)
                    {
                        await Task.WhenAny(responseTask, Task.Delay(JobHealthPollMilliseconds, token));
                        if (responseTask.IsCompleted)
                            break;

                        if (TryGetPrivateMemoryMb(out var privateMb) && privateMb >= MaxSingleJobPrivateMemoryMb)
                        {
                            Restart($"limit pamięci pojedynczego zadania {privateMb:0} MB >= {MaxSingleJobPrivateMemoryMb} MB");
                            return (false, "", $"RESOURCE_LIMIT: pojedyncza analiza STEP osiągnęła {privateMb:0} MB (limit {MaxSingleJobPrivateMemoryMb} MB) i została bezpiecznie zatrzymana. Ukończone pliki oraz checkpoint zostały zachowane; ponowne LICZ WYCENĘ wznowi pracę z cache.");
                        }

                        if (idleWatchdogSeconds > 0)
                        {
                            var lastTicks = Interlocked.Read(ref _lastProgressUtcTicks);
                            var idle = DateTime.UtcNow - new DateTime(lastTicks, DateTimeKind.Utc);
                            if (idle.TotalSeconds >= idleWatchdogSeconds)
                            {
                                Restart("idle watchdog");
                                return (false, "", $"TIMEOUT_IDLE: analizator STEP nie zgłosił postępu przez {idleWatchdogSeconds} s; worker został zrestartowany.");
                            }
                        }
                    }
                    var line = await responseTask;
                    if (string.IsNullOrWhiteSpace(line))
                    {
                        var stderr = TakeStderr();
                        Restart("pusta odpowiedź");
                        return (false, "", "STEP worker zakończył odpowiedź bez danych. " + stderr);
                    }

                    var response = JsonSerializer.Deserialize<StepWorkerResponse>(line, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });
                    if (response is null)
                    {
                        var stderr = TakeStderr();
                        Restart("nieprawidłowa odpowiedź protokołu");
                        return (false, "", "Nieprawidłowa odpowiedź trwałego STEP workera. " + stderr);
                    }

                    var workerStderr = TakeStderr();
                    var combinedStderr = string.Join(" | ", new[] { response.Stderr, workerStderr }
                        .Where(x => !string.IsNullOrWhiteSpace(x)));
                    _completedJobs++;
                    var recycleReason = GetRecycleReason();
                    if (!string.IsNullOrWhiteSpace(recycleReason))
                        await RecycleAsync(recycleReason);
                    return (response.Ok, response.Stdout ?? "", combinedStderr);
                }
                catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested && executionTimeout.HasValue)
                {
                    Restart("watchdog czasu wykonania");
                    return (false, "", $"TIMEOUT: analizator analyze_step.py przekroczył limit {executionTimeout.Value.TotalSeconds:0} s i worker został zrestartowany przez watchdog.");
                }
                catch (OperationCanceledException)
                {
                    Restart("anulowanie przez użytkownika");
                    throw;
                }
                catch (Exception ex)
                {
                    var stderr = TakeStderr();
                    Restart("wyjątek hosta: " + ex.GetType().Name);
                    return (false, "", $"STEP worker: {ex.GetType().Name}: {ex.Message}" +
                        (string.IsNullOrWhiteSpace(stderr) ? "" : " | " + stderr));
                }
                finally
                {
                    _progressLine = null;
                }
            }
            finally
            {
                _gate.Release();
            }
        }

        private void EnsureStarted()
        {
            if (_process is not null && !_process.HasExited)
                return;

            try { _process?.Dispose(); } catch { }
            _process = null;

            var psi = new ProcessStartInfo
            {
                FileName = _python,
                UseShellExecute = false,
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8
            };
            psi.Environment["PYTHONUTF8"] = "1";
            psi.Environment["PYTHONIOENCODING"] = "utf-8";
            psi.Environment["DSE_PERSISTENT_STEP_WORKER"] = "1";
            ApplyPersistentCacheEnvironment(psi);
            psi.ArgumentList.Add("-u");
            psi.ArgumentList.Add(_workerScript);

            _process = Process.Start(psi) ?? throw new InvalidOperationException("Nie udało się uruchomić trwałego STEP workera.");
            _completedJobs = 0;
            _startedUtc = DateTime.UtcNow;
            _ = Task.Run(() => PumpStderrAsync(_process));
        }

        private async Task PumpStderrAsync(Process process)
        {
            try
            {
                while (!process.HasExited)
                {
                    var line = await process.StandardError.ReadLineAsync();
                    if (line is null) break;
                    if (line.StartsWith("DSEPROGRESS|", StringComparison.Ordinal))
                    {
                        Interlocked.Exchange(ref _lastProgressUtcTicks, DateTime.UtcNow.Ticks);
                        try { _progressLine?.Invoke(line); } catch { }
                    }
                    else
                    {
                        lock (_stderrSync)
                        {
                            if (_stderr.Length > 0) _stderr.AppendLine();
                            _stderr.Append(line);
                        }
                    }
                }
            }
            catch
            {
                // Process termination during watchdog/cancel is expected.
            }
        }

        private string TakeStderr()
        {
            lock (_stderrSync)
                return _stderr.ToString();
        }

        private string? GetRecycleReason()
        {
            if (_process is null || _process.HasExited)
                return "proces zakończony";
            if (_completedJobs >= MaxJobs)
                return $"limit zadań {_completedJobs}/{MaxJobs}";
            if (_startedUtc != default && DateTime.UtcNow - _startedUtc >= TimeSpan.FromMinutes(MaxLifetimeMinutes))
                return $"limit czasu pracy {MaxLifetimeMinutes} min";
            try
            {
                _process.Refresh();
                var privateMb = _process.PrivateMemorySize64 / 1024.0 / 1024.0;
                if (privateMb >= MaxPrivateMemoryMb)
                    return $"pamięć prywatna {privateMb:0} MB >= {MaxPrivateMemoryMb} MB";
            }
            catch
            {
                // A process may end between response and telemetry. It will be
                // recreated naturally by EnsureStarted on the next request.
            }
            return null;
        }

        private bool TryGetPrivateMemoryMb(out double privateMemoryMb)
        {
            privateMemoryMb = 0;
            try
            {
                if (_process is null || _process.HasExited)
                    return false;
                _process.Refresh();
                privateMemoryMb = _process.PrivateMemorySize64 / 1024.0 / 1024.0;
                return true;
            }
            catch
            {
                return false;
            }
        }

        public StepWorkerHealthInfo GetHealth(int workerNumber)
        {
            var info = new StepWorkerHealthInfo
            {
                WorkerNumber = workerNumber,
                CompletedJobs = _completedJobs,
                StartedUtc = _startedUtc == default ? null : _startedUtc,
                LastLifecycleReason = _lastLifecycleReason,
                Status = _gate.CurrentCount == 0 ? "PRACUJE" : "GOTOWY"
            };
            try
            {
                if (_process is null || _process.HasExited)
                {
                    info.Status = "NIEURUCHOMIONY";
                    return info;
                }
                _process.Refresh();
                info.ProcessId = _process.Id;
                info.PrivateMemoryMb = _process.PrivateMemorySize64 / 1024.0 / 1024.0;
            }
            catch
            {
                info.Status = "NIEDOSTĘPNY";
            }
            return info;
        }

        public bool RestartFromHealthPanel()
        {
            if (!_gate.Wait(0))
                return false;
            try
            {
                if (_process is null)
                    return false;
                Restart("ręczny restart z panelu stanu silników");
                return true;
            }
            finally
            {
                _gate.Release();
            }
        }

        private async Task RecycleAsync(string reason)
        {
            var process = _process;
            _process = null;
            if (process is null)
                return;

            _lastLifecycleReason = "RECYCLE: " + reason;
            RecordLifecycleEvent("RECYCLE", reason, process, _completedJobs);
            try
            {
                if (!process.HasExited)
                {
                    using var quit = new CancellationTokenSource(TimeSpan.FromSeconds(QuitTimeoutSeconds));
                    await process.StandardInput.WriteLineAsync("__quit__".AsMemory(), quit.Token);
                    await process.StandardInput.FlushAsync(quit.Token);
                    await process.WaitForExitAsync(quit.Token);
                }
            }
            catch
            {
                try
                {
                    if (!process.HasExited)
                        process.Kill(entireProcessTree: true);
                }
                catch { }
            }
            finally
            {
                try { process.Dispose(); } catch { }
                _completedJobs = 0;
                _startedUtc = default;
            }
        }

        private void Restart(string reason)
        {
            var process = _process;
            _lastLifecycleReason = "RESTART: " + reason;
            RecordLifecycleEvent("RESTART", reason, process, _completedJobs);
            try
            {
                if (process is not null && !process.HasExited)
                    process.Kill(entireProcessTree: true);
            }
            catch { }
            try { process?.Dispose(); } catch { }
            _process = null;
            _completedJobs = 0;
            _startedUtc = default;
        }

        private static int ReadBoundedEnvironmentInt(string name, int fallback, int minimum, int maximum)
        {
            var text = Environment.GetEnvironmentVariable(name);
            return int.TryParse(text, out var value)
                ? Math.Clamp(value, minimum, maximum)
                : fallback;
        }

        private static void RecordLifecycleEvent(string action, string reason, Process? process, int jobs)
        {
            try
            {
                var localData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                if (string.IsNullOrWhiteSpace(localData)) return;
                var logDir = Path.Combine(localData, "DSEstimateNext", "logs");
                Directory.CreateDirectory(logDir);
                var path = Path.Combine(logDir, "step_worker_lifecycle.log");
                if (File.Exists(path) && new FileInfo(path).Length > 1024 * 1024)
                    File.Move(path, path + ".previous", true);
                var memoryMb = 0.0;
                var pid = 0;
                try
                {
                    if (process is not null)
                    {
                        process.Refresh();
                        pid = process.Id;
                        memoryMb = process.PrivateMemorySize64 / 1024.0 / 1024.0;
                    }
                }
                catch { }
                File.AppendAllText(path,
                    $"{DateTime.UtcNow:O}\t{action}\tpid={pid}\tjobs={jobs}\tprivate_mb={memoryMb:0}\treason={reason}{Environment.NewLine}",
                    Encoding.UTF8);
            }
            catch
            {
                // Lifecycle telemetry is diagnostic only and must never block a quote.
            }
        }
    }

    private static void ApplyPersistentCacheEnvironment(ProcessStartInfo psi)
    {
        try
        {
            var localData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (string.IsNullOrWhiteSpace(localData)) return;
            var bytecodeCache = Path.Combine(localData, "DSEstimateNext", "pycache", "cp312");
            var matplotlibCache = Path.Combine(localData, "DSEstimateNext", "cache", "matplotlib");
            Directory.CreateDirectory(bytecodeCache);
            Directory.CreateDirectory(matplotlibCache);
            psi.Environment["PYTHONPYCACHEPREFIX"] = bytecodeCache;
            psi.Environment["MPLCONFIGDIR"] = matplotlibCache;
        }
        catch { }
    }

    private sealed class StepWorkerRequest
    {
        public string Path { get; set; } = "";
        public Dictionary<string, string> Env { get; set; } = new(StringComparer.Ordinal);
    }

    private sealed class StepWorkerResponse
    {
        public bool Ok { get; set; }
        public string Stdout { get; set; } = "";
        public string Stderr { get; set; } = "";
    }

    private static IEnumerable<string> ExistingVenvCandidates()
    {
        var candidates = new List<string>
        {
            ManagedPythonPath(),
            Path.Combine(AppContext.BaseDirectory, ".venv", "Scripts", "python.exe"),
            Path.Combine(Environment.CurrentDirectory, ".venv", "Scripts", "python.exe")
        };

        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        for (var i = 0; i < 8 && dir is not null; i++, dir = dir.Parent)
            candidates.Add(Path.Combine(dir.FullName, ".venv", "Scripts", "python.exe"));

        return candidates.Distinct(StringComparer.OrdinalIgnoreCase);
    }

    private static IEnumerable<PythonCandidate> SystemPythonCandidates()
    {
        yield return new PythonCandidate("python", [], "python");
        yield return new PythonCandidate("py", ["-3.12"], "py -3.12");
        yield return new PythonCandidate("py", ["-3.11"], "py -3.11");
        yield return new PythonCandidate("py", ["-3.10"], "py -3.10");
        yield return new PythonCandidate("py", ["-3.9"], "py -3.9");
        yield return new PythonCandidate("py", [], "py");
    }

    private static string BundledPythonPath()
    {
        // R8.8.1+: short internal path reduces native OCP/VTK DLL path length on Windows.
        var shortPortable = Path.Combine(AppContext.BaseDirectory, "py", "python.exe");
        if (File.Exists(shortPortable))
            return shortPortable;

        // Backward compatibility with older full-portable packages.
        return Path.Combine(AppContext.BaseDirectory, "runtime", "python", "python.exe");
    }

    private static bool IsOfflinePortable() =>
        File.Exists(Path.Combine(AppContext.BaseDirectory, "OFFLINE_PORTABLE.flag"));

    private static string ManagedPythonPath() =>
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "DSEstimateNext",
            "runtime",
            ".venv",
            "Scripts",
            "python.exe");

    private static string? ResolveScript(string name)
    {
        var candidates = new List<string>
        {
            Path.Combine(AppContext.BaseDirectory, "engines", "python", name),
            Path.Combine(Environment.CurrentDirectory, "engines", "python", name)
        };

        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        for (var i = 0; i < 8 && dir is not null; i++, dir = dir.Parent)
            candidates.Add(Path.Combine(dir.FullName, "engines", "python", name));

        return candidates
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .FirstOrDefault(File.Exists);
    }

    private static string Tail(string value, int maxChars)
    {
        if (string.IsNullOrWhiteSpace(value))
            return "brak szczegółów";
        value = value.Trim();
        return value.Length <= maxChars ? value : value[^maxChars..];
    }

    private static void WriteBootstrapLog(string stdout, string stderr)
    {
        try
        {
            var dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "DSEstimateNext",
                "runtime");
            Directory.CreateDirectory(dir);
            File.WriteAllText(
                Path.Combine(dir, "bootstrap.log"),
                $"UTC: {DateTime.UtcNow:O}{Environment.NewLine}{stdout}{Environment.NewLine}{stderr}",
                Encoding.UTF8);
        }
        catch
        {
            // Diagnostics must not stop analysis.
        }
    }

    private sealed record PythonCandidate(string FileName, string[] PrefixArgs, string Label);
    private sealed record RuntimeRequirement(string Key, string[] Modules);
    private sealed record ProcessResult(int ExitCode, string Stdout, string Stderr);
}
