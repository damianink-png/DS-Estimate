﻿using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using ClosedXML.Excel;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

public sealed class HistoricalMetricSheetData
{
    public string SheetName { get; set; } = "";
    public string Customer { get; set; } = "";
    public string ProductName { get; set; } = "";
    public string DrawingNumber { get; set; } = "";
    public double? WeightKg { get; set; }
    public double ProductionQuantity { get; set; } = 1.0;
    public Dictionary<string, double> SskHours { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public double? HistoricalMaterialCostPln { get; set; }
    public double? HistoricalTotalCostPln { get; set; }
    public double? HistoricalPricePln { get; set; }
    public bool IsSummary { get; set; }
    public bool IsDuplicate { get; set; }
    public bool IncludedInAggregate { get; set; }

    // Filled after client documentation has been analysed. Used only for safe
    // workstation-capacity learning; ambiguous sheets are never force-matched.
    public string MatchedSourceFile { get; set; } = "";
    public string MatchBasis { get; set; } = "";
    public bool GeometryMatched => !string.IsNullOrWhiteSpace(MatchedSourceFile);

    public double CncHeavyHours => Get("3201");
    public double CncMediumHours => Get("3202");
    public double CncLightHours => Get("3203");
    public double CncManualHours => Get("3205");
    public double CncMachineHours => CncHeavyHours + CncMediumHours + CncLightHours;
    public double CombinedWeldAssemblyHours => Get("3401");
    public double TotalSskHours => SskHours.Values.Where(double.IsFinite).Sum(x => Math.Max(0, x));

    public double Get(string code) => SskHours.TryGetValue(code, out var value) ? Math.Max(0, value) : 0;
}

public sealed class HistoricalMetricData
{
    public string WorkbookPath { get; set; } = "";
    public string Customer { get; set; } = "";
    public string ProductName { get; set; } = "";
    public string DrawingNumber { get; set; } = "";
    public double? WeightKg { get; set; }
    public double ProductionQuantity { get; set; } = 1.0;
    public Dictionary<string, double> SskHours { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public List<HistoricalMetricSheetData> MetricSheets { get; set; } = [];
    public string AggregationBasis { get; set; } = "";
    public string SummarySheetName { get; set; } = "";
    public int MetricSheetCount => MetricSheets.Count;
    public int ComponentSheetCount => MetricSheets.Count(x => !x.IsSummary && !x.IsDuplicate);
    public bool HasMultipleMetricSheets => MetricSheetCount > 1;

    public double CncHeavyHours => Get("3201");
    public double CncMediumHours => Get("3202");
    public double CncLightHours => Get("3203");
    public double CncManualHours => Get("3205");
    public double CncMachineHours => CncHeavyHours + CncMediumHours + CncLightHours;
    public double CncHours => CncMachineHours + CncManualHours;
    public double CuttingHours => Sum("3301", "3302", "3303");
    public double CombinedWeldAssemblyHours => Get("3401");
    public double SurfaceHours => Get("3402");
    public double RobotWeldingHours => Get("3403");
    public double? HistoricalMaterialCostPln { get; set; }
    public double? HistoricalTotalCostPln { get; set; }
    public double? HistoricalPricePln { get; set; }
    public Dictionary<string, double> CostCenterRatesPlnH { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    private double Sum(params string[] codes) => codes.Sum(Get);
    public double Get(string code) => SskHours.TryGetValue(code, out var value) ? Math.Max(0, value) : 0;
}

public sealed class HistoryImportProgress
{
    public int Current { get; set; }
    public int Total { get; set; }
    public string FolderName { get; set; } = "";
    public string Phase { get; set; } = "";
    public string Text => Total <= 0
        ? Phase
        : $"{Current}/{Total} · {FolderName} · {Phase}";
    public double Percent => Total <= 0 ? 0 : Math.Clamp(Current * 100.0 / Total, 0, 100);
}

public sealed class HistoryCalibrationSuggestion
{
    public string ProcessCode { get; set; } = "";
    public string ProcessName { get; set; } = "";
    public int Samples { get; set; }
    public int OutlierCount { get; set; }
    public double MinOutlierRatio { get; set; }
    public double MaxOutlierRatio { get; set; }
    public double RawMedianFactor { get; set; } = 1;
    public double SuggestedFactor { get; set; } = 1;
    public bool Usable { get; set; }

    public string FactorText => $"×{SuggestedFactor:0.###}";
    public string SampleText => OutlierCount > 0
        ? $"{Samples} próbek + {OutlierCount} outlierów"
        : $"{Samples} próbek";
    public string Interpretation => RawMedianFactor switch
    {
        > 1.03 => $"model zaniża czas o ok. {(RawMedianFactor - 1) * 100:0}%",
        < 0.97 => $"model zawyża czas o ok. {(1 - RawMedianFactor) * 100:0}%",
        _ => "model jest blisko historii"
    };
    public string StatusText => OutlierCount > 0
        ? (Usable ? $"auto-kalibracja; {OutlierCount} skrajnych wyników tylko diagnostycznie ({MinOutlierRatio:0.##}–{MaxOutlierRatio:0.##}×)" : $"za mało próbek; {OutlierCount} skrajnych wyników do diagnostyki")
        : (Usable ? "gotowe do auto-kalibracji" : "za mało próbek");
}

public sealed class CalibrationValidationMetric
{
    public string ProcessCode { get; set; } = "";
    public string ProcessName { get; set; } = "";
    public int TrainingSamples { get; set; }
    public int ValidationSamples { get; set; }
    public double LearnedFactor { get; set; } = 1.0;
    public double BaselineMapePercent { get; set; }
    public double ProposedMapePercent { get; set; }
    public double BaselineBiasPercent { get; set; }
    public double ProposedBiasPercent { get; set; }
    public double BaselineP90Percent { get; set; }
    public double ProposedP90Percent { get; set; }
    public bool Passed { get; set; }
    public string ResultText => Passed ? "PASS" : "REGRESJA";
    public string ErrorText => $"MAPE {BaselineMapePercent:0.#}% → {ProposedMapePercent:0.#}% · P90 {BaselineP90Percent:0.#}% → {ProposedP90Percent:0.#}%";
}

public sealed class CalibrationValidationReport
{
    public string Status { get; set; } = "BRAK DANYCH";
    public string Summary { get; set; } = "Za mało projektów do niezależnej walidacji.";
    public int TrainingProjects { get; set; }
    public int ValidationProjects { get; set; }
    public double BaselineMapePercent { get; set; }
    public double ProposedMapePercent { get; set; }
    public double BaselineBiasPercent { get; set; }
    public double ProposedBiasPercent { get; set; }
    public double BaselineP90Percent { get; set; }
    public double ProposedP90Percent { get; set; }
    public int TrainingGroups { get; set; }
    public int ValidationGroups { get; set; }
    public int RollingFoldCount { get; set; }
    public double RollingBaselineMapePercent { get; set; }
    public double RollingProposedMapePercent { get; set; }
    public string SplitMethod { get; set; } = "chronologiczny, grupowany rodziną/revizją";
    public bool HasIndependentHoldout { get; set; }
    public bool Passed { get; set; } = true;
    public bool BlocksProfileUpdate => HasIndependentHoldout && !Passed;
    public List<CalibrationValidationMetric> Metrics { get; set; } = [];

    // Runtime-only inputs used to build the accepted company profile without
    // leaking holdout projects into the learned factors.
    internal List<HistoryCalibrationSuggestion> TrainingSuggestions { get; set; } = [];
    internal HashSet<string> TrainingSourceKeys { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public string SplitText => HasIndependentHoldout
        ? $"chronologicznie: uczenie {TrainingProjects}/{TrainingGroups} grup · walidacja {ValidationProjects}/{ValidationGroups} grup" +
          (RollingFoldCount > 0 ? $" · rolling {RollingFoldCount} fold(y)" : "")
        : $"projekty {TrainingProjects + ValidationProjects} · oczekiwanie na min. niezależny zbiór";
    public string ErrorText => HasIndependentHoldout
        ? $"MAPE {BaselineMapePercent:0.#}% → {ProposedMapePercent:0.#}% · bias {BaselineBiasPercent:+0.#;-0.#;0}% → {ProposedBiasPercent:+0.#;-0.#;0}% · P90 {BaselineP90Percent:0.#}% → {ProposedP90Percent:0.#}%"
        : "MAPE zostanie pokazane po zebraniu większej historii";
}

public sealed class HistoryRateSuggestion
{
    public string StationCode { get; set; } = "";
    public string StationName { get; set; } = "";
    public string SourceSsk { get; set; } = "";
    public int Samples { get; set; }
    public double CurrentRatePlnH { get; set; }
    public double SuggestedRatePlnH { get; set; }
    public bool Usable { get; set; }
    public string CurrentText => $"{CurrentRatePlnH:0.##} PLN/h";
    public string SuggestedText => $"{SuggestedRatePlnH:0.##} PLN/h";
    public string SampleText => $"{Samples} metryk";
    public string Basis => $"Mediana stawki RBH po koszcie całkowitym z BAZA ZAŁOŻEŃ · SSK {SourceSsk}.";
}

public sealed class CncCapacitySample
{
    public string StationCode { get; set; } = "";
    public string Source { get; set; } = "";
    public double Hours { get; set; }
    public double LengthMm { get; set; }
    public double WidthMm { get; set; }
    public double HeightMm { get; set; }
    public double WeightKg { get; set; }
    public string Basis { get; set; } = "";
}

public sealed class CncCapacitySuggestion
{
    public string StationCode { get; set; } = "";
    public string StationName { get; set; } = "";
    public int Samples { get; set; }
    public double SuggestedXmm { get; set; }
    public double SuggestedYmm { get; set; }
    public double SuggestedZmm { get; set; }
    public double SuggestedWeightKg { get; set; }
    public double CurrentXmm { get; set; }
    public double CurrentYmm { get; set; }
    public double CurrentZmm { get; set; }
    public double CurrentWeightKg { get; set; }
    public bool Usable { get; set; }
    public bool IsLargeBoundary { get; set; }
    public string Basis { get; set; } = "";

    public string CurrentText => $"{CurrentXmm:0} × {CurrentYmm:0} × {CurrentZmm:0} mm · {CurrentWeightKg:0} kg";
    public string SuggestedText => IsLargeBoundary
        ? "powyżej zakresu CNC średniego; górnego limitu nie nadpisuj bez danych maszyny"
        : $"{SuggestedXmm:0} × {SuggestedYmm:0} × {SuggestedZmm:0} mm · {SuggestedWeightKg:0} kg";
    public string SampleText => $"{Samples} pewnych próbek";
    public string StatusText => Usable ? "można zastosować" : "za mało pewnych danych";
}

public sealed class HistoryImportCandidate
{
    public string SourceKey { get; set; } = "";
    public string FolderPath { get; set; } = "";
    public string FolderName { get; set; } = "";
    public string MetricFileName { get; set; } = "";
    public string ProjectName { get; set; } = "";
    public string Customer { get; set; } = "";
    public string DrawingNumber { get; set; } = "";
    public DateTime CalibrationDate { get; set; }
    public string CalibrationGroupKey { get; set; } = "";
    public int DocumentCount { get; set; }
    public double? WeightKg { get; set; }
    public double ProductionQuantity { get; set; } = 1.0;
    public string ProjectClass { get; set; } = "";
    public string Status { get; set; } = "Oczekuje";
    public string Message { get; set; } = "";
    public bool ReadyToImport { get; set; }
    public bool Imported { get; set; }
    public bool AlreadyImported { get; set; }
    public double ModelCutHours { get; set; }
    public double ModelCncHours { get; set; }
    public double ModelWeldHours { get; set; }
    public double ModelAssemblyHours { get; set; }
    public double ModelSurfaceHours { get; set; }
    public double ActualCutHours { get; set; }
    public double ActualCncHours { get; set; }
    public double ActualWeldHours { get; set; }
    public double ActualAssemblyHours { get; set; }
    public double ActualWeldAssemblyHours { get; set; }
    public double ActualSurfaceHours { get; set; }
    public double RobotWeldingHoursIgnored { get; set; }
    public double ActualCncHeavyHours { get; set; }
    public double ActualCncMediumHours { get; set; }
    public double ActualCncLightHours { get; set; }
    public double ActualCncManualHours { get; set; }
    public double ModelCncLargeHours { get; set; }
    public double ModelCncMediumHours { get; set; }
    public double ModelCncSmallHours { get; set; }
    public string ModelCncStationName { get; set; } = "";
    public double MachiningLengthMm { get; set; }
    public double MachiningWidthMm { get; set; }
    public double MachiningHeightMm { get; set; }
    public double MachiningMaxPartWeightKg { get; set; }
    public int MachiningGroupCount { get; set; }
    public int MachiningHoleCount { get; set; }
    public int MetricSheetCount { get; set; }
    public string MetricSheetSummary { get; set; } = "";
    public List<CncCapacitySample> CncCapacitySamples { get; set; } = [];
    public Dictionary<string, double> HistoricalRateHintsPlnH { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public double? HistoricalTotalCostPln { get; set; }
    public double? HistoricalPricePln { get; set; }
    public QuoteProject? PreparedProject { get; set; }
    public Guid PreparedProjectId { get; set; }
    public string PreparedProjectSnapshotPath { get; set; } = "";
    public bool HasPreparedProject => PreparedProject is not null ||
                                      (!string.IsNullOrWhiteSpace(PreparedProjectSnapshotPath) && File.Exists(PreparedProjectSnapshotPath));

    public double ModelTotalHours => ModelCutHours + ModelCncHours + ModelWeldHours + ModelAssemblyHours + ModelSurfaceHours;
    public double ActualTotalHours => ActualCutHours + ActualCncHours + ActualWeldHours + ActualAssemblyHours + ActualSurfaceHours;
    public string WeightText => WeightKg.HasValue ? $"{WeightKg.Value:N0} kg" : "—";
    public string ModelHoursText => $"CUT {ModelCutHours:0.#} · CNC {ModelCncHours:0.#} · SPAW {ModelWeldHours:0.#} · MON {ModelAssemblyHours:0.#} · POW {ModelSurfaceHours:0.#}";
    public string ActualHoursText => $"CUT {ActualCutHours:0.#} · CNC {ActualCncHours:0.#} · SPAW {ActualWeldHours:0.#} · MON {ActualAssemblyHours:0.#} · POW {ActualSurfaceHours:0.#}";
    public string CncHistoryText => $"Historia CNC: ciężka/duża {ActualCncHeavyHours:0.#} h · średnia {ActualCncMediumHours:0.#} h · lekka/mała {ActualCncLightHours:0.#} h · ręczne 3205 {ActualCncManualHours:0.#} h";
    public string CncModelSplitText => $"Model CNC: duża {ModelCncLargeHours:0.#} h · średnia {ModelCncMediumHours:0.#} h · mała {ModelCncSmallHours:0.#} h";
    public string MachiningEnvelopeText => MachiningLengthMm > 0
        ? $"Gabaryt obrabianych detali: do {MachiningLengthMm:0} × {MachiningWidthMm:0} × {MachiningHeightMm:0} mm · max {MachiningMaxPartWeightKg:0.#} kg · grup {MachiningGroupCount} · otworów {MachiningHoleCount} · model: {ModelCncStationName}"
        : $"Gabaryt CNC: brak pewnego detalu · model: {ModelCncStationName}";
    public string TotalComparisonText
    {
        get
        {
            if (ModelTotalHours <= 0 || ActualTotalHours <= 0)
                return "brak pełnego porównania godzin";
            var delta = (ActualTotalHours - ModelTotalHours) / ModelTotalHours * 100.0;
            return $"model {ModelTotalHours:0.#} h → historia {ActualTotalHours:0.#} h ({delta:+0;-0;0}%)";
        }
    }
    public string HistoricalMoneyText
    {
        get
        {
            var parts = new List<string>();
            if (HistoricalTotalCostPln is > 0) parts.Add($"koszt hist. {HistoricalTotalCostPln:N0} PLN");
            if (HistoricalPricePln is > 0) parts.Add($"cena hist. {HistoricalPricePln:N0} PLN");
            return parts.Count == 0 ? "" : string.Join(" · ", parts);
        }
    }
}

public sealed class HistoryImportScanResult
{
    public List<HistoryImportCandidate> Candidates { get; set; } = [];
    public List<HistoryCalibrationSuggestion> Suggestions { get; set; } = [];
    public List<CncCapacitySuggestion> CncCapacitySuggestions { get; set; } = [];
    public List<HistoryRateSuggestion> RateSuggestions { get; set; } = [];
    public CalibrationValidationReport CalibrationValidation { get; set; } = new();
    public int FolderCount { get; set; }
    public int ReadyCount => Candidates.Count(x => x.ReadyToImport && !x.AlreadyImported);
    public int WarningCount => Candidates.Count(x => x.Status == "Uwaga");
    public int ErrorCount => Candidates.Count(x => x.Status == "Błąd");
}

public sealed class HistoricalMetricReader
{
    private static readonly string[] SskCodes = ["3201", "3202", "3203", "3205", "3301", "3302", "3303", "3401", "3402", "3403"];

    public bool LooksLikeMetric(string path)
    {
        try
        {
            using var workbook = new XLWorkbook(path);
            return workbook.Worksheets.Any(IsMetricWorksheet);
        }
        catch
        {
            return false;
        }
    }

    public HistoricalMetricData Read(string path)
    {
        using var workbook = new XLWorkbook(path);
        var sheets = workbook.Worksheets
            .Where(IsMetricWorksheet)
            .Select(ReadSheet)
            .ToList();

        if (sheets.Count == 0)
            throw new InvalidDataException("Nie znaleziono arkusza metryki z pozycjami SSK 3201–3403.");

        MarkDuplicates(sheets);
        var nonDuplicates = sheets.Where(x => !x.IsDuplicate).ToList();
        var summary = FindSummarySheet(nonDuplicates);
        if (summary is not null)
            summary.IsSummary = true;

        var aggregateSheets = summary is not null
            ? new List<HistoricalMetricSheetData> { summary }
            : nonDuplicates;
        foreach (var sheet in sheets)
            sheet.IncludedInAggregate = aggregateSheets.Contains(sheet);

        var data = new HistoricalMetricData
        {
            WorkbookPath = path,
            MetricSheets = sheets,
            SummarySheetName = summary?.SheetName ?? ""
        };

        foreach (var code in SskCodes)
            data.SskHours[code] = aggregateSheets.Sum(x => x.Get(code));

        var metaSource = summary ?? aggregateSheets.First();
        data.Customer = MostCommonNonEmpty(aggregateSheets.Select(x => x.Customer)) ?? metaSource.Customer;

        var productNames = aggregateSheets.Select(x => x.ProductName).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        data.ProductName = productNames.Count == 1 ? productNames[0] : metaSource.ProductName;

        var drawings = aggregateSheets.Select(x => x.DrawingNumber).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        data.DrawingNumber = drawings.Count == 1 ? drawings[0] : metaSource.DrawingNumber;

        if (summary?.WeightKg is > 0)
            data.WeightKg = summary.WeightKg;
        else
            data.WeightKg = AggregateWeight(aggregateSheets);
        var qtyValues = aggregateSheets.Select(x => x.ProductionQuantity).Where(x => x is > 0 and <= 10000).OrderBy(x => x).ToList();
        data.ProductionQuantity = summary?.ProductionQuantity is > 0
            ? summary.ProductionQuantity
            : qtyValues.Count > 0 ? qtyValues[qtyValues.Count / 2] : 1.0;

        data.HistoricalMaterialCostPln = AggregateMoney(aggregateSheets, x => x.HistoricalMaterialCostPln, summary);
        data.HistoricalTotalCostPln = AggregateMoney(aggregateSheets, x => x.HistoricalTotalCostPln, summary);
        data.HistoricalPricePln = AggregateMoney(aggregateSheets, x => x.HistoricalPricePln, summary);
        data.CostCenterRatesPlnH = ReadCostCenterRates(workbook);

        var duplicateCount = sheets.Count(x => x.IsDuplicate);
        data.AggregationBasis = summary is not null
            ? $"{sheets.Count} arkuszy metryki; „{summary.SheetName}” rozpoznano jako podsumowanie i użyto do sum projektu. Pozostałe arkusze zachowano do próby dopasowania zespołów."
            : sheets.Count == 1
                ? $"1 arkusz metryki: „{sheets[0].SheetName}”."
                : $"{sheets.Count} arkuszy metryki; zsumowano {aggregateSheets.Count} niepowtarzających się arkuszy" + (duplicateCount > 0 ? $", pominięto {duplicateCount} duplikat(y)." : ".");

        return data;
    }

    private static HistoricalMetricSheetData ReadSheet(IXLWorksheet ws)
    {
        var data = new HistoricalMetricSheetData { SheetName = ws.Name };
        var hoursColumn = FindColumnContaining(ws, "Pracochłonność technologiczna");
        if (hoursColumn <= 0) hoursColumn = FindColumnContaining(ws, "Godziny");
        if (hoursColumn <= 0) hoursColumn = FindColumnContaining(ws, "Hours");
        if (hoursColumn <= 0) hoursColumn = 3; // legacy metryka: kolumna C
        foreach (var code in SskCodes)
        {
            var row = FindSskRow(ws, code);
            if (row <= 0)
                continue;
            data.SskHours[code] = ReadNumber(ws.Cell(row, hoursColumn));
        }

        data.Customer = ReadValueRightOfLabel(ws, "Odbiorca");
        data.ProductName = ReadValueRightOfLabel(ws, "Nazwa wyrobu");
        data.DrawingNumber = ReadValueRightOfLabel(ws, "Nr rysunku");
        data.WeightKg = ReadNumberRightOfLabel(ws, "Ciężar netto");
        if (data.WeightKg is not > 0) data.WeightKg = ReadNumberRightOfLabel(ws, "Masa całkowita");
        if (data.WeightKg is not > 0) data.WeightKg = ReadNumberRightOfLabel(ws, "Masa calkowita");
        if (data.WeightKg is not > 0) data.WeightKg = ReadNumberRightOfLabel(ws, "Total weight");
        var qty = ReadNumberRightOfLabel(ws, "Ilość") ?? 0.0;
        if (qty <= 0) qty = ReadNumberRightOfLabel(ws, "Ilosc") ?? 0.0;
        if (qty <= 0) qty = ReadNumberRightOfLabel(ws, "Qty") ?? 0.0;
        data.ProductionQuantity = qty is > 0 and <= 10000 ? qty : 1.0;

        var materialRow = FindRowContaining(ws, "Razem materiały");
        if (materialRow > 0)
        {
            var value = ReadNumber(ws.Cell(materialRow, 7));
            data.HistoricalMaterialCostPln = value > 0 ? value : null;
        }

        var totalCostRow = FindRowContaining(ws, "Całkowity koszt własny");
        if (totalCostRow > 0)
        {
            var value = ReadNumber(ws.Cell(totalCostRow, 6));
            data.HistoricalTotalCostPln = value > 0 ? value : null;
        }

        var priceRow = FindRowContaining(ws, "12.a Cena");
        if (priceRow > 0)
        {
            var series = ReadNumber(ws.Cell(priceRow, 6));
            var prototype = ReadNumber(ws.Cell(priceRow, 3));
            var price = series > 0 ? series : prototype;
            data.HistoricalPricePln = price > 0 ? price : null;
        }
        if (data.HistoricalPricePln is not > 0)
            data.HistoricalPricePln = ReadNumberRightOfLabel(ws, "Cena historyczna");
        if (data.HistoricalPricePln is not > 0)
            data.HistoricalPricePln = ReadNumberRightOfLabel(ws, "Historical price");
        if (data.HistoricalTotalCostPln is not > 0)
            data.HistoricalTotalCostPln = ReadNumberRightOfLabel(ws, "Koszt historyczny");
        return data;
    }

    private static Dictionary<string, double> ReadCostCenterRates(XLWorkbook workbook)
    {
        var result = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        var ws = workbook.Worksheets.FirstOrDefault(x => Normalize(x.Name).Contains("bazazalozen", StringComparison.Ordinal));
        if (ws is null)
        {
            // Compact history exports may carry SSK + Godziny + effective RBH directly
            // in one worksheet instead of a separate BAZA ZAŁOŻEŃ sheet.
            ws = workbook.Worksheets.FirstOrDefault(IsMetricWorksheet);
            if (ws is null)
                return result;
        }

        // Do not trust a fixed Excel column. Company templates move columns between
        // revisions, while the semantic header remains stable. Prefer the header
        // "Wartość rbh po koszcie całkowitym" and only then use legacy fallbacks.
        var totalColumn = FindColumnContaining(ws, "Wartość rbh po koszcie całkowitym");
        var manufacturingColumn = FindColumnContaining(ws, "Wartość rbh po koszcie wytworzenia");
        if (totalColumn <= 0)
            totalColumn = FindColumnContaining(ws, "RBH po koszcie całkowitym");

        foreach (var code in SskCodes)
        {
            var row = FindSskRow(ws, code);
            if (row <= 0)
                continue;

            var totalCostRate = totalColumn > 0 ? ReadNumber(ws.Cell(row, totalColumn)) : 0;
            var manufacturingRate = manufacturingColumn > 0 ? ReadNumber(ws.Cell(row, manufacturingColumn)) : 0;

            // Older variants were seen with the total-RBH column around J/K. Keep a
            // conservative fallback, but never prefer it over a named header.
            if (totalCostRate <= 0)
            {
                foreach (var col in new[] { 10, 11 })
                {
                    var fallback = ReadNumber(ws.Cell(row, col));
                    if (fallback >= 80 && fallback <= 1000)
                    {
                        totalCostRate = fallback;
                        break;
                    }
                }
            }
            if (manufacturingRate <= 0)
            {
                foreach (var col in new[] { 7, 8 })
                {
                    var fallback = ReadNumber(ws.Cell(row, col));
                    if (fallback >= 50 && fallback <= 1000)
                    {
                        manufacturingRate = fallback;
                        break;
                    }
                }
            }

            var rate = totalCostRate > 0 ? totalCostRate : manufacturingRate;
            if (rate > 0)
                result[code] = rate;
        }
        return result;
    }

    private static int FindColumnContaining(IXLWorksheet ws, string label)
    {
        var wanted = Normalize(label);
        var used = ws.RangeUsed();
        if (used is null)
            return 0;
        foreach (var cell in used.CellsUsed())
        {
            var text = Normalize(cell.GetFormattedString());
            if (text.Contains(wanted, StringComparison.Ordinal))
                return cell.Address.ColumnNumber;
        }
        return 0;
    }

    private static bool IsMetricWorksheet(IXLWorksheet ws)
    {
        var normalizedName = Normalize(ws.Name);
        if (normalizedName.Contains("bazazalozen", StringComparison.Ordinal))
            return false;
        if (FindSskRow(ws, "3201") <= 0 || FindSskRow(ws, "3401") <= 0)
            return false;
        if (FindRowContaining(ws, "Pracochłonność technologiczna") > 0)
            return true;
        // R9.2.2: accept compact history sheets: SSK | Nazwa | Godziny | RBH...
        // They contain the same exact cost-centre truth without the legacy template labels.
        return FindRowContaining(ws, "SSK") > 0 &&
               (FindRowContaining(ws, "Godziny") > 0 || FindRowContaining(ws, "Hours") > 0);
    }

    private static void MarkDuplicates(List<HistoricalMetricSheetData> sheets)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var sheet in sheets)
        {
            var signature = BuildSignature(sheet);
            if (!seen.Add(signature))
                sheet.IsDuplicate = true;
        }
    }

    private static string BuildSignature(HistoricalMetricSheetData s)
    {
        var hours = string.Join("|", SskCodes.Select(code => Math.Round(s.Get(code), 3).ToString("0.###", CultureInfo.InvariantCulture)));
        return $"{Normalize(s.DrawingNumber)}|{Normalize(s.ProductName)}|{Math.Round(s.WeightKg ?? 0, 2):0.##}|{hours}";
    }

    private static HistoricalMetricSheetData? FindSummarySheet(List<HistoricalMetricSheetData> sheets)
    {
        if (sheets.Count < 3)
            return null;

        foreach (var candidate in sheets.OrderByDescending(x => x.TotalSskHours))
        {
            var others = sheets.Where(x => !ReferenceEquals(x, candidate)).ToList();
            var sumOthers = others.Sum(x => x.TotalSskHours);
            if (candidate.TotalSskHours <= 0 || sumOthers <= 0)
                continue;

            var totalDiff = Math.Abs(candidate.TotalSskHours - sumOthers) / Math.Max(candidate.TotalSskHours, sumOthers);
            if (totalDiff > 0.05)
                continue;

            var vectorAbs = SskCodes.Sum(code => Math.Abs(candidate.Get(code) - others.Sum(x => x.Get(code))));
            var vectorBase = Math.Max(1.0, SskCodes.Sum(code => Math.Max(candidate.Get(code), others.Sum(x => x.Get(code)))));
            if (vectorAbs / vectorBase <= 0.08)
                return candidate;
        }
        return null;
    }

    private static double? AggregateWeight(List<HistoricalMetricSheetData> sheets)
    {
        var weights = sheets.Select(x => x.WeightKg ?? 0).Where(x => x > 0).ToList();
        if (weights.Count == 0)
            return null;
        if (weights.Count == 1)
            return weights[0];

        // If all sheets repeat nearly the same weight, it is probably the total project
        // weight copied into each sheet rather than additive subassembly weights.
        if (weights.Max() / Math.Max(0.001, weights.Min()) < 1.03)
            return weights.Max();
        return weights.Sum();
    }

    private static double? AggregateMoney(
        List<HistoricalMetricSheetData> sheets,
        Func<HistoricalMetricSheetData, double?> selector,
        HistoricalMetricSheetData? summary)
    {
        if (summary is not null)
            return selector(summary);
        var values = sheets.Select(selector).Where(x => x is > 0).Select(x => x!.Value).ToList();
        return values.Count == 0 ? null : values.Sum();
    }

    private static string? MostCommonNonEmpty(IEnumerable<string> values) => values
        .Where(x => !string.IsNullOrWhiteSpace(x))
        .GroupBy(x => x.Trim(), StringComparer.OrdinalIgnoreCase)
        .OrderByDescending(x => x.Count())
        .Select(x => x.Key)
        .FirstOrDefault();

    private static int FindSskRow(IXLWorksheet ws, string code)
    {
        var last = ws.LastRowUsed()?.RowNumber() ?? 0;
        for (var row = 1; row <= last; row++)
        {
            var text = ws.Cell(row, 2).GetFormattedString().Trim();
            if (text.StartsWith(code + " ", StringComparison.OrdinalIgnoreCase) ||
                text.StartsWith(code + "-", StringComparison.OrdinalIgnoreCase))
                return row;
        }
        return 0;
    }

    private static int FindRowContaining(IXLWorksheet ws, string label)
    {
        var wanted = Normalize(label);
        var used = ws.RangeUsed();
        if (used is null)
            return 0;
        foreach (var cell in used.CellsUsed())
        {
            var text = Normalize(cell.GetFormattedString());
            if (text.Contains(wanted, StringComparison.Ordinal))
                return cell.Address.RowNumber;
        }
        return 0;
    }

    private static IXLCell? FindLabelCell(IXLWorksheet ws, string label)
    {
        var wanted = Normalize(label);
        var used = ws.RangeUsed();
        if (used is null)
            return null;
        foreach (var cell in used.CellsUsed())
        {
            var text = Normalize(cell.GetFormattedString());
            if (text.Contains(wanted, StringComparison.Ordinal))
                return cell;
        }
        return null;
    }

    private static string ReadValueRightOfLabel(IXLWorksheet ws, string label)
    {
        var cell = FindLabelCell(ws, label);
        if (cell is null)
            return "";
        for (var col = cell.Address.ColumnNumber + 1; col <= Math.Min(cell.Address.ColumnNumber + 5, 20); col++)
        {
            var candidate = ws.Cell(cell.Address.RowNumber, col).GetFormattedString().Trim();
            if (!string.IsNullOrWhiteSpace(candidate))
                return candidate;
        }
        return "";
    }

    private static double? ReadNumberRightOfLabel(IXLWorksheet ws, string label)
    {
        var cell = FindLabelCell(ws, label);
        if (cell is null)
            return null;
        for (var col = cell.Address.ColumnNumber + 1; col <= Math.Min(cell.Address.ColumnNumber + 5, 20); col++)
        {
            var value = ReadNumber(ws.Cell(cell.Address.RowNumber, col));
            if (value > 0)
                return value;
        }
        return null;
    }

    private static double ReadNumber(IXLCell cell)
    {
        if (cell.TryGetValue<double>(out var value) && double.IsFinite(value))
            return value;

        var text = cell.GetFormattedString().Trim().Replace("\u00A0", " ");
        text = new string(text.Where(c => char.IsDigit(c) || c is '-' or '+' or ',' or '.').ToArray());
        if (double.TryParse(text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out value) && double.IsFinite(value))
            return value;
        return 0;
    }

    private static string Normalize(string value)
    {
        var decomposed = (value ?? "").Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder(decomposed.Length);
        foreach (var c in decomposed)
        {
            var category = CharUnicodeInfo.GetUnicodeCategory(c);
            if (category == UnicodeCategory.NonSpacingMark)
                continue;
            if (char.IsLetterOrDigit(c))
                sb.Append(char.ToLowerInvariant(c));
        }
        return sb.ToString().Normalize(NormalizationForm.FormC);
    }
}

public sealed class HistoryImportService
{
    private readonly HistoricalMetricReader _metricReader = new();
    private readonly ClientPackageImportService _packageImport = new();
    private readonly ProjectAnalysisService _analysis = new();
    private static readonly JsonSerializerOptions SnapshotJson = new() { WriteIndented = false };

    private static readonly HashSet<string> DirectTechnicalExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".step", ".stp", ".dxf", ".dwg", ".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp",
        ".xlsx", ".xlsm", ".xls", ".csv", ".docx", ".doc", ".rtf", ".txt", ".bom", ".log", ".md", ".zip"
    };

    public async Task<HistoryImportScanResult> AnalyzeRootAsync(
        string rootPath,
        CostingSettings settings,
        IProgress<HistoryImportProgress>? progress = null,
        CancellationToken cancellationToken = default,
        bool fastMode = true)
    {
        if (string.IsNullOrWhiteSpace(rootPath) || !Directory.Exists(rootPath))
            throw new DirectoryNotFoundException("Nie znaleziono wybranego folderu historii.");

        var projectFolders = DiscoverProjectFolders(rootPath);
        var result = new HistoryImportScanResult { FolderCount = projectFolders.Count };
        // FIX14 safety: large historical databases always start in metadata/vector mode.
        // Full OCR can still be run later on a selected project; it is unsafe and wasteful
        // to OCR hundreds of A0/A1 drawings merely to learn plan-vs-actual calibration.
        var effectiveFastMode = fastMode || projectFolders.Count >= 12;
        if (effectiveFastMode && !fastMode && projectFolders.Count >= 12)
            progress?.Report(new HistoryImportProgress { Current = 0, Total = projectFolders.Count, FolderName = "", Phase = "tryb bezpieczny: duża baza, OCR skanów wyłączony" });

        for (var index = 0; index < projectFolders.Count; index++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var folder = projectFolders[index];
            var folderName = new DirectoryInfo(folder).Name;
            var candidate = new HistoryImportCandidate
            {
                FolderPath = folder,
                FolderName = folderName,
                ProjectName = folderName,
                Status = "Analiza"
            };
            result.Candidates.Add(candidate);

            try
            {
                progress?.Report(new HistoryImportProgress { Current = index + 1, Total = projectFolders.Count, FolderName = folderName, Phase = "szukanie metryki" });
                var metricPath = await Task.Run(() => FindMetricWorkbook(folder), cancellationToken);
                if (metricPath is null)
                {
                    candidate.Status = "Błąd";
                    candidate.Message = "Nie znaleziono pliku XLSX/XLSM z arkuszem „Szablon” i pozycjami SSK.";
                    continue;
                }

                candidate.MetricFileName = Path.GetFileName(metricPath);
                candidate.CalibrationDate = File.GetLastWriteTime(metricPath);
                var metric = await Task.Run(() => _metricReader.Read(metricPath), cancellationToken);
                candidate.Customer = metric.Customer;
                candidate.DrawingNumber = metric.DrawingNumber;
                candidate.WeightKg = metric.WeightKg;
                candidate.ProductionQuantity = metric.ProductionQuantity;
                candidate.MetricSheetCount = metric.MetricSheetCount;
                candidate.MetricSheetSummary = metric.AggregationBasis;
                candidate.HistoricalTotalCostPln = metric.HistoricalTotalCostPln;
                candidate.HistoricalPricePln = metric.HistoricalPricePln;

                var inputs = DiscoverClientInputs(folder, metricPath);
                if (inputs.Count == 0)
                {
                    candidate.Status = "Błąd";
                    candidate.Message = "Metryka jest poprawna, ale nie znaleziono ZIP-a ani dokumentacji klienta do analizy.";
                    continue;
                }

                candidate.SourceKey = ComputeSourceKey(metricPath, inputs);
                var project = new QuoteProject
                {
                    Id = Guid.NewGuid(),
                    Revision = 0,
                    Name = BuildProjectName(folderName, metric.ProductName, metric.DrawingNumber),
                    Customer = metric.Customer,
                    CreatedAt = File.GetLastWriteTime(metricPath),
                    ModifiedAt = File.GetLastWriteTime(metricPath),
                    ManualWeightKg = metric.WeightKg,
                    HistoryImport = new HistoryImportMetadata
                    {
                        AnalysisEngineVersion = "1.0",
                        SourceKey = candidate.SourceKey,
                        SourceFolder = folderName,
                        MetricWorkbook = Path.GetFileName(metricPath),
                        DrawingNumber = metric.DrawingNumber,
                        CombinedWeldAssemblyHours = metric.CombinedWeldAssemblyHours,
                        RobotWeldingHours = metric.RobotWeldingHours,
                        MetricSheetCount = metric.MetricSheetCount,
                        MetricAggregationBasis = metric.AggregationBasis,
                        CncHeavyHours = metric.CncHeavyHours,
                        CncMediumHours = metric.CncMediumHours,
                        CncLightHours = metric.CncLightHours,
                        CncManualHours = metric.CncManualHours,
                        HistoricalMaterialCostPln = metric.HistoricalMaterialCostPln,
                        HistoricalTotalCostPln = metric.HistoricalTotalCostPln,
                        HistoricalPricePln = metric.HistoricalPricePln,
                        ProductionQuantity = metric.ProductionQuantity,
                        SskHours = new Dictionary<string, double>(metric.SskHours, StringComparer.OrdinalIgnoreCase),
                        HistoricalRateHintsPlnH = new Dictionary<string, double>(metric.CostCenterRatesPlnH, StringComparer.OrdinalIgnoreCase)
                    }
                };
                candidate.ProjectName = project.Name;
                candidate.HistoricalRateHintsPlnH = new Dictionary<string, double>(metric.CostCenterRatesPlnH, StringComparer.OrdinalIgnoreCase);
                candidate.PreparedProject = project; // held only until the compact disk snapshot is written
                candidate.PreparedProjectId = project.Id;

                progress?.Report(new HistoryImportProgress { Current = index + 1, Total = projectFolders.Count, FolderName = folderName, Phase = "wczytywanie dokumentacji" });
                var imported = await _packageImport.ExpandAsync(inputs, project.Id, settings.MaxZipExtractGb, cancellationToken);
                foreach (var item in imported.Files)
                {
                    var file = new FileInfo(item.Path);
                    project.Documents.Add(new ProjectDocument
                    {
                        Path = item.Path,
                        Name = Path.GetFileName(item.RelativePath),
                        RelativePath = item.RelativePath,
                        PackageSource = item.Source,
                        Kind = DetectKind(file.Extension),
                        SizeBytes = file.Exists ? file.Length : 0,
                        Status = "Oczekuje",
                        IsActiveRevision = true
                    });
                }
                candidate.DocumentCount = project.Documents.Count;
                if (project.Documents.Count == 0)
                {
                    candidate.Status = "Błąd";
                    candidate.Message = "Dokumentacja nie zawiera obsługiwanych plików technicznych.";
                    _packageImport.DeleteProjectImports(project.Id);
                    continue;
                }

                progress?.Report(new HistoryImportProgress { Current = index + 1, Total = projectFolders.Count, FolderName = folderName, Phase = "analiza STEP/PDF/DXF i modelu kosztowego" });
                var analysis = await _analysis.AnalyzeAsync(project, settings, cancellationToken, effectiveFastMode);
                project.Analysis = analysis;
                candidate.ProjectClass = analysis.ProjectClass?.Code ?? "";
                if (project.HistoryImport is not null)
                    project.HistoryImport.ProjectClass = candidate.ProjectClass;

                FillModelHours(candidate, analysis);
                FillCncMachineComparison(candidate, analysis, settings);
                if (project.HistoryImport is not null)
                {
                    project.HistoryImport.ModelCncLargeHours = candidate.ModelCncLargeHours;
                    project.HistoryImport.ModelCncMediumHours = candidate.ModelCncMediumHours;
                    project.HistoryImport.ModelCncSmallHours = candidate.ModelCncSmallHours;
                }
                MatchMetricSheetsToGeometry(metric, project, analysis);
                BuildCapacitySamples(candidate, metric, analysis);
                var splitMessage = ApplyHistoricalActuals(project, candidate, metric);

                // Keep a private copy of the historical metric for audit/opening later,
                // but mark it inactive so recalculation never treats the costing sheet as BOM/RFQ input.
                var metricCopy = CopyMetricIntoProject(metricPath, project.Id);
                project.Documents.Add(new ProjectDocument
                {
                    Path = metricCopy,
                    Name = Path.GetFileName(metricCopy),
                    RelativePath = Path.Combine("HISTORIA", Path.GetFileName(metricCopy)),
                    PackageSource = "Metryka historyczna",
                    Kind = DocumentKind.Excel,
                    SizeBytes = new FileInfo(metricCopy).Length,
                    Status = "Historia",
                    Summary = "Źródło rzeczywistych godzin SSK — wyłączone z analizy technicznej",
                    IsActiveRevision = false,
                    ExcludeFromAnalysis = true
                });

                // FIX14: do not retain every full AnalysisResult in RAM until the user
                // clicks Import. Persist the prepared project to a local temporary JSON
                // snapshot and release the object graph immediately.
                PersistPreparedSnapshot(candidate, project);
                candidate.PreparedProject = null;

                candidate.ReadyToImport = true;
                candidate.Status = string.IsNullOrWhiteSpace(splitMessage) && imported.Warnings.Count == 0 ? "Gotowy" : "Uwaga";

                var messageParts = new List<string>();
                if (!string.IsNullOrWhiteSpace(splitMessage)) messageParts.Add(splitMessage);
                if (metric.HasMultipleMetricSheets) messageParts.Add(metric.AggregationBasis);
                var unresolvedSheets = metric.MetricSheets.Count(x => !x.IsSummary && !x.IsDuplicate && !x.GeometryMatched);
                if (metric.HasMultipleMetricSheets && unresolvedSheets > 0)
                {
                    candidate.Status = "Uwaga";
                    messageParts.Add($"{unresolvedSheets} arkusz(y) zespołów nie dopasowano jednoznacznie do plików STEP — ich godziny wchodzą do sum projektu, ale nie uczą zakresów maszyn CNC.");
                }
                if (metric.RobotWeldingHours > 0) messageParts.Add($"3403 spawanie zrobotyzowane {metric.RobotWeldingHours:0.##} h zachowano informacyjnie i nie użyto do kalibracji zwykłego WELD.");
                if (imported.Warnings.Count > 0) messageParts.Add($"Uwagi dokumentacji: {imported.Warnings.Count}.");
                candidate.Message = messageParts.Count == 0 ? "Gotowy do importu do historii." : string.Join(" ", messageParts);
            }
            catch (OperationCanceledException)
            {
                // The analyzer-level cache is intentionally preserved, but imported
                // temporary customer files and prepared project snapshots are not.
                // This keeps cancellation cheap without leaking GB of extracted data.
                foreach (var pending in result.Candidates.Where(x => !x.Imported))
                {
                    var id = pending.PreparedProject?.Id ?? pending.PreparedProjectId;
                    if (id != Guid.Empty)
                        _packageImport.DeleteProjectImports(id);
                    DeletePreparedSnapshot(pending);
                    pending.PreparedProject = null;
                }
                throw;
            }
            catch (Exception ex)
            {
                candidate.Status = "Błąd";
                candidate.Message = $"{ex.GetType().Name}: {ex.Message}";
                if (candidate.PreparedProjectId != Guid.Empty)
                    _packageImport.DeleteProjectImports(candidate.PreparedProjectId);
                DeletePreparedSnapshot(candidate);
                candidate.PreparedProject = null;
            }
        }

        result.Suggestions = BuildSuggestions(result.Candidates, settings);
        result.CncCapacitySuggestions = BuildCncCapacitySuggestions(result.Candidates, settings);
        result.RateSuggestions = BuildRateSuggestions(result.Candidates, settings);
        progress?.Report(new HistoryImportProgress { Current = projectFolders.Count, Total = projectFolders.Count, FolderName = "", Phase = "analiza zakończona" });
        return result;
    }

    public void CleanupUnimported(IEnumerable<HistoryImportCandidate> candidates)
    {
        foreach (var candidate in candidates.Where(x => !x.Imported && x.HasPreparedProject))
        {
            var id = candidate.PreparedProject?.Id ?? candidate.PreparedProjectId;
            if (id != Guid.Empty)
                _packageImport.DeleteProjectImports(id);
            DeletePreparedSnapshot(candidate);
            candidate.PreparedProject = null;
        }
    }

    public QuoteProject? LoadPreparedProject(HistoryImportCandidate candidate)
    {
        if (candidate.PreparedProject is not null)
            return candidate.PreparedProject;
        if (string.IsNullOrWhiteSpace(candidate.PreparedProjectSnapshotPath) || !File.Exists(candidate.PreparedProjectSnapshotPath))
            return null;
        try
        {
            var json = File.ReadAllText(candidate.PreparedProjectSnapshotPath);
            return JsonSerializer.Deserialize<QuoteProject>(json, SnapshotJson);
        }
        catch
        {
            return null;
        }
    }

    public void ReleasePreparedSnapshot(HistoryImportCandidate candidate) => DeletePreparedSnapshot(candidate);

    private static void PersistPreparedSnapshot(HistoryImportCandidate candidate, QuoteProject project)
    {
        var root = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "DSEstimateNext", "history_scan");
        Directory.CreateDirectory(root);
        var path = Path.Combine(root, $"{project.Id:N}.json");
        File.WriteAllText(path, JsonSerializer.Serialize(project, SnapshotJson));
        candidate.PreparedProjectId = project.Id;
        candidate.PreparedProjectSnapshotPath = path;
    }

    private static void DeletePreparedSnapshot(HistoryImportCandidate candidate)
    {
        try
        {
            if (!string.IsNullOrWhiteSpace(candidate.PreparedProjectSnapshotPath) && File.Exists(candidate.PreparedProjectSnapshotPath))
                File.Delete(candidate.PreparedProjectSnapshotPath);
        }
        catch { }
        candidate.PreparedProjectSnapshotPath = "";
    }

    private List<string> DiscoverProjectFolders(string rootPath)
    {
        var subfolders = Directory.EnumerateDirectories(rootPath)
            .OrderBy(NaturalSortKey, StringComparer.OrdinalIgnoreCase)
            .ToList();

        // Preferred structure is root\001, root\002, ... . If subfolders exist,
        // do not mistake a spare blank template kept in the root for a project.
        if (subfolders.Count > 0)
            return subfolders;

        var rootMetric = FindMetricWorkbook(rootPath);
        return rootMetric is not null ? [Path.GetFullPath(rootPath)] : [];
    }

    private string? FindMetricWorkbook(string folder)
    {
        var files = Directory.EnumerateFiles(folder, "*.*", SearchOption.TopDirectoryOnly)
            .Where(x =>
            {
                var ext = Path.GetExtension(x);
                return ext.Equals(".xlsx", StringComparison.OrdinalIgnoreCase) ||
                       ext.Equals(".xlsm", StringComparison.OrdinalIgnoreCase);
            })
            .OrderBy(x => Path.GetFileName(x), StringComparer.OrdinalIgnoreCase)
            .ToList();

        foreach (var file in files)
            if (_metricReader.LooksLikeMetric(file))
                return file;
        return null;
    }

    private static List<string> DiscoverClientInputs(string folder, string metricPath)
    {
        var result = new List<string>();
        var metricFull = Path.GetFullPath(metricPath);
        foreach (var file in Directory.EnumerateFiles(folder, "*", SearchOption.TopDirectoryOnly))
        {
            if (string.Equals(Path.GetFullPath(file), metricFull, StringComparison.OrdinalIgnoreCase))
                continue;
            if (DirectTechnicalExtensions.Contains(Path.GetExtension(file)))
                result.Add(file);
        }
        foreach (var dir in Directory.EnumerateDirectories(folder))
            result.Add(dir);
        return result;
    }

    private static void FillModelHours(HistoryImportCandidate c, AnalysisResult analysis)
    {
        c.ModelCutHours = GetBaseHours(analysis, "CUT");
        c.ModelCncHours = GetBaseHours(analysis, "CNC");
        c.ModelWeldHours = GetBaseHours(analysis, "WELD");
        c.ModelAssemblyHours = GetBaseHours(analysis, "ASSY");
        c.ModelSurfaceHours = GetBaseHours(analysis, "SURF");
    }

    private static bool IsMachiningCandidate(PartGroup part) =>
        part.Holes.Count > 0 || part.FaceCount >= 18 || part.CylindricalFaceCount >= 4;

    private static (double L, double W, double H) SortedDimensions(PartGroup part)
    {
        var d = new[] { Math.Max(0, part.Xmm), Math.Max(0, part.Ymm), Math.Max(0, part.Zmm) }
            .OrderByDescending(x => x)
            .ToArray();
        return (d.ElementAtOrDefault(0), d.ElementAtOrDefault(1), d.ElementAtOrDefault(2));
    }

    private static void FillCncMachineComparison(HistoryImportCandidate c, AnalysisResult analysis, CostingSettings settings)
    {
        var cncProcess = analysis.Processes.FirstOrDefault(x => x.Enabled && string.Equals(x.Code, "CNC", StringComparison.OrdinalIgnoreCase));
        c.ModelCncStationName = cncProcess?.WorkstationName ?? "brak wyboru";

        var parts = analysis.Geometry.Parts.Where(IsMachiningCandidate).ToList();
        if (parts.Count == 0 && analysis.Geometry.Parts.Count > 0)
            parts = analysis.Geometry.Parts.OrderByDescending(x => x.Xmm * x.Ymm * x.Zmm).Take(1).ToList();

        c.MachiningGroupCount = parts.Count;
        c.MachiningHoleCount = parts.Sum(x => x.Holes.Sum(h => Math.Max(0, h.Count)) * Math.Max(1, x.Quantity));
        if (parts.Count > 0)
        {
            var dims = parts.Select(SortedDimensions).ToList();
            c.MachiningLengthMm = dims.Max(x => x.L);
            c.MachiningWidthMm = dims.Max(x => x.W);
            c.MachiningHeightMm = dims.Max(x => x.H);
            c.MachiningMaxPartWeightKg = parts.Max(x => Math.Max(0, x.MassKgEach));
        }

        var buckets = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
        {
            ["CNC_SMALL"] = 0,
            ["CNC_MEDIUM"] = 0,
            ["CNC_LARGE"] = 0
        };

        foreach (var part in parts)
        {
            var code = SelectSmallestCncStation(part, settings);
            var holeCount = part.Holes.Sum(h => Math.Max(0, h.Count));
            var complexityWeight = Math.Max(1, part.Quantity) *
                                   (5.0 + holeCount * 0.8 + Math.Max(0, part.FaceCount) * 0.12 + Math.Min(15.0, Math.Max(0, part.MassKgEach) / 250.0));
            if (!buckets.ContainsKey(code))
                code = "CNC_LARGE";
            buckets[code] += complexityWeight;
        }

        var totalWeight = buckets.Values.Sum();
        if (totalWeight <= 0 && c.ModelCncHours > 0)
        {
            var selected = cncProcess?.WorkstationCode;
            if (string.IsNullOrWhiteSpace(selected) || !buckets.ContainsKey(selected))
                selected = "CNC_MEDIUM";
            buckets[selected] = 1;
            totalWeight = 1;
        }

        if (totalWeight > 0)
        {
            c.ModelCncSmallHours = c.ModelCncHours * buckets["CNC_SMALL"] / totalWeight;
            c.ModelCncMediumHours = c.ModelCncHours * buckets["CNC_MEDIUM"] / totalWeight;
            c.ModelCncLargeHours = c.ModelCncHours * buckets["CNC_LARGE"] / totalWeight;
        }
    }

    private static string SelectSmallestCncStation(PartGroup part, CostingSettings settings)
    {
        foreach (var station in settings.Workstations
                     .Where(x => x.Enabled && x.AutomaticRoutingCandidate && string.Equals(x.ProcessCode, "CNC", StringComparison.OrdinalIgnoreCase))
                     .OrderBy(x => x.Priority))
        {
            if (FitsPart(part, station))
                return station.Code;
        }
        return "CNC_LARGE";
    }

    private static bool FitsPart(PartGroup part, WorkstationDefinition station)
    {
        var dims = new[] { Math.Max(0, part.Xmm), Math.Max(0, part.Ymm), Math.Max(0, part.Zmm) }.OrderBy(x => x).ToArray();
        var limits = new[]
        {
            station.MaxXmm <= 0 ? double.MaxValue : station.MaxXmm,
            station.MaxYmm <= 0 ? double.MaxValue : station.MaxYmm,
            station.MaxZmm <= 0 ? double.MaxValue : station.MaxZmm
        }.OrderBy(x => x).ToArray();
        if (dims[0] > limits[0] || dims[1] > limits[1] || dims[2] > limits[2])
            return false;
        return station.MaxWeightKg <= 0 || part.MassKgEach <= station.MaxWeightKg;
    }

    private static void MatchMetricSheetsToGeometry(HistoricalMetricData metric, QuoteProject project, AnalysisResult analysis)
    {
        var stepDocs = project.Documents
            .Where(x => x.Kind == DocumentKind.Step && !x.ExcludeFromAnalysis)
            .ToList();

        var componentSheets = metric.MetricSheets.Where(x => !x.IsSummary && !x.IsDuplicate).ToList();
        if (componentSheets.Count == 1 && stepDocs.Count == 1)
        {
            componentSheets[0].MatchedSourceFile = stepDocs[0].Name;
            componentSheets[0].MatchBasis = "jedyny arkusz metryki + jedyny model STEP";
            return;
        }

        foreach (var sheet in componentSheets)
        {
            var refs = new[] { sheet.DrawingNumber, sheet.ProductName, sheet.SheetName }
                .Select(NormalizeMatchToken)
                .Where(x => x.Length >= 4)
                .Distinct()
                .ToList();
            if (refs.Count == 0)
                continue;

            var ranked = stepDocs
                .Select(doc => new
                {
                    Doc = doc,
                    Score = ScoreDocumentMatch(refs, NormalizeMatchToken(Path.GetFileNameWithoutExtension(doc.Name)), NormalizeMatchToken(doc.RelativePath))
                })
                .OrderByDescending(x => x.Score)
                .ToList();

            if (ranked.Count == 0 || ranked[0].Score < 60)
                continue;
            if (ranked.Count > 1 && ranked[0].Score - ranked[1].Score < 15)
                continue;

            sheet.MatchedSourceFile = ranked[0].Doc.Name;
            sheet.MatchBasis = $"dopasowanie nazwy/nr rysunku do STEP ({ranked[0].Score} pkt)";
        }
    }

    private static int ScoreDocumentMatch(IReadOnlyList<string> refs, string fileStem, string relativePath)
    {
        var score = 0;
        foreach (var r in refs)
        {
            if (fileStem == r) score = Math.Max(score, 120);
            else if (fileStem.Contains(r, StringComparison.Ordinal) || r.Contains(fileStem, StringComparison.Ordinal)) score = Math.Max(score, 95);
            else if (relativePath.Contains(r, StringComparison.Ordinal)) score = Math.Max(score, 75);
            else
            {
                var tokens = SplitTokens(r);
                var hits = tokens.Count(t => fileStem.Contains(t, StringComparison.Ordinal) || relativePath.Contains(t, StringComparison.Ordinal));
                if (tokens.Count >= 2 && hits >= Math.Max(2, tokens.Count - 1))
                    score = Math.Max(score, 60 + hits * 5);
            }
        }
        return score;
    }

    private static List<string> SplitTokens(string value)
    {
        var raw = new StringBuilder();
        foreach (var c in value)
            raw.Append(char.IsLetterOrDigit(c) ? c : ' ');
        return raw.ToString().Split(' ', StringSplitOptions.RemoveEmptyEntries)
            .Where(x => x.Length >= 3)
            .Distinct()
            .ToList();
    }

    private static string NormalizeMatchToken(string value)
    {
        var decomposed = (value ?? "").Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder(decomposed.Length);
        foreach (var c in decomposed)
        {
            if (CharUnicodeInfo.GetUnicodeCategory(c) == UnicodeCategory.NonSpacingMark)
                continue;
            if (char.IsLetterOrDigit(c)) sb.Append(char.ToLowerInvariant(c));
            else sb.Append(' ');
        }
        return string.Join(" ", sb.ToString().Split(' ', StringSplitOptions.RemoveEmptyEntries));
    }

    private static void BuildCapacitySamples(HistoryImportCandidate candidate, HistoricalMetricData metric, AnalysisResult analysis)
    {
        candidate.CncCapacitySamples.Clear();
        var componentSheets = metric.MetricSheets.Where(x => !x.IsSummary && !x.IsDuplicate).ToList();

        if (componentSheets.Count == 1)
        {
            var sheet = componentSheets[0];
            var parts = string.IsNullOrWhiteSpace(sheet.MatchedSourceFile)
                ? analysis.Geometry.Parts.Where(IsMachiningCandidate).ToList()
                : analysis.Geometry.Parts.Where(x => IsMachiningCandidate(x) && string.Equals(Path.GetFileName(x.SourceFile), Path.GetFileName(sheet.MatchedSourceFile), StringComparison.OrdinalIgnoreCase)).ToList();
            TryAddCapacitySample(candidate, sheet, parts, "projekt jednoarkuszowy");
            return;
        }

        foreach (var sheet in componentSheets.Where(x => x.GeometryMatched))
        {
            var parts = analysis.Geometry.Parts
                .Where(x => IsMachiningCandidate(x) && string.Equals(Path.GetFileName(x.SourceFile), Path.GetFileName(sheet.MatchedSourceFile), StringComparison.OrdinalIgnoreCase))
                .ToList();
            TryAddCapacitySample(candidate, sheet, parts, $"arkusz „{sheet.SheetName}” → {sheet.MatchedSourceFile}");
        }
    }

    private static void TryAddCapacitySample(HistoryImportCandidate candidate, HistoricalMetricSheetData sheet, List<PartGroup> parts, string basis)
    {
        if (parts.Count == 0 || sheet.CncMachineHours <= 0)
            return;

        var shares = new[]
        {
            (Code: "CNC_LARGE", Hours: sheet.CncHeavyHours),
            (Code: "CNC_MEDIUM", Hours: sheet.CncMediumHours),
            (Code: "CNC_SMALL", Hours: sheet.CncLightHours)
        }.OrderByDescending(x => x.Hours).ToList();
        var dominant = shares[0];
        var dominantShare = dominant.Hours / Math.Max(0.001, sheet.CncMachineHours);
        if (dominant.Hours <= 0 || dominantShare < 0.70)
            return;

        // A clean small-machine sample must not contain any medium/heavy machine time.
        if (dominant.Code == "CNC_SMALL" && sheet.CncHeavyHours + sheet.CncMediumHours > 0.001)
            return;
        // A medium sample can include light operations, but no heavy-machine operation.
        if (dominant.Code == "CNC_MEDIUM" && sheet.CncHeavyHours > 0.001)
            return;

        var dims = parts.Select(SortedDimensions).ToList();
        candidate.CncCapacitySamples.Add(new CncCapacitySample
        {
            StationCode = dominant.Code,
            Source = sheet.SheetName,
            Hours = dominant.Hours,
            LengthMm = dims.Max(x => x.L),
            WidthMm = dims.Max(x => x.W),
            HeightMm = dims.Max(x => x.H),
            WeightKg = parts.Max(x => Math.Max(0, x.MassKgEach)),
            Basis = $"{basis}; klasa historyczna {dominantShare:P0} czasu maszynowego CNC"
        });
    }

    private static string ApplyHistoricalActuals(QuoteProject project, HistoryImportCandidate candidate, HistoricalMetricData metric)
    {
        candidate.ActualCutHours = metric.CuttingHours;
        candidate.ActualCncHeavyHours = metric.CncHeavyHours;
        candidate.ActualCncMediumHours = metric.CncMediumHours;
        candidate.ActualCncLightHours = metric.CncLightHours;
        candidate.ActualCncManualHours = metric.CncManualHours;
        // Overall CNC calibration retains 3205 because the DS Estimate CNC model includes
        // setup/loading/manual handling. Machine-capacity learning uses only 3201–3203.
        candidate.ActualCncHours = metric.CncHours;
        candidate.ActualSurfaceHours = metric.SurfaceHours;
        candidate.RobotWeldingHoursIgnored = metric.RobotWeldingHours;

        var combined = metric.CombinedWeldAssemblyHours;
        candidate.ActualWeldAssemblyHours = combined;
        var modelWeld = candidate.ModelWeldHours;
        var modelAssy = candidate.ModelAssemblyHours;
        var splitBasis = "";
        var splitWarning = "";

        if (combined > 0)
        {
            if (modelWeld > 0.01 && modelAssy > 0.01)
            {
                var total = modelWeld + modelAssy;
                candidate.ActualWeldHours = combined * modelWeld / total;
                candidate.ActualAssemblyHours = combined - candidate.ActualWeldHours;
                splitBasis = $"3401 {combined:0.##} h rozdzielono tylko do podglądu wg proporcji modelu WELD/ASSY; kalibracja używa 3401 łącznie, żeby uniknąć uczenia modelu jego własnym podziałem.";
            }
            else if (modelWeld > 0.01)
            {
                candidate.ActualWeldHours = combined;
                splitBasis = $"3401 {combined:0.##} h przypisano do WELD, bo model nie wykrył osobnego montażu.";
                splitWarning = "3401 nie dało się podzielić na spawanie i montaż — całość przypisano do spawania.";
            }
            else if (modelAssy > 0.01)
            {
                candidate.ActualAssemblyHours = combined;
                splitBasis = $"3401 {combined:0.##} h przypisano do ASSY, bo model nie wykrył osobnego spawania.";
                splitWarning = "3401 nie dało się podzielić na spawanie i montaż — całość przypisano do montażu.";
            }
            else
            {
                splitBasis = $"3401 {combined:0.##} h pozostawiono bez automatycznego podziału — model nie wykrył WELD ani ASSY.";
                splitWarning = "3401 zawiera godziny, ale dokumentacja nie pozwoliła wyznaczyć proporcji WELD/ASSY; te godziny nie wejdą do kalibracji obu procesów.";
            }
        }

        var actuals = new ProductionActuals
        {
            CompletedAt = File.GetLastWriteTime(metric.WorkbookPath),
            SskHours = metric.SskHours
                .Where(x => double.IsFinite(x.Value) && x.Value >= 0)
                .ToDictionary(x => x.Key, x => Round(x.Value), StringComparer.OrdinalIgnoreCase),
            CuttingHours = Round(candidate.ActualCutHours),
            MachiningHours = Round(candidate.ActualCncHours),
            WeldingHours = Round(candidate.ActualWeldHours),
            AssemblyHours = Round(candidate.ActualAssemblyHours),
            SurfaceHours = Round(candidate.ActualSurfaceHours),
            ActualTotalCostPln = metric.HistoricalTotalCostPln ?? 0,
            Note = $"Import historii z {Path.GetFileName(metric.WorkbookPath)}. {splitBasis} " +
                   $"CNC: 3201 ciężka {metric.CncHeavyHours:0.##} h; 3202 średnia {metric.CncMediumHours:0.##} h; 3203 lekka {metric.CncLightHours:0.##} h; 3205 ręczne {metric.CncManualHours:0.##} h. " +
                   metric.AggregationBasis +
                   (metric.RobotWeldingHours > 0 ? $" 3403 robot: {metric.RobotWeldingHours:0.##} h (informacyjnie, poza kalibracją WELD)." : "")
        };
        project.Actuals = actuals;
        if (project.HistoryImport is not null)
            project.HistoryImport.SplitBasis = splitBasis;
        return splitWarning;
    }

    public List<HistoryImportCandidate> BuildCandidatesFromImportedProjects(IEnumerable<QuoteProject> projects)
    {
        var output = new List<HistoryImportCandidate>();
        foreach (var project in projects.Where(x => x.HistoryImport is not null && x.Analysis is not null))
        {
            var meta = project.HistoryImport!;
            var analysis = project.Analysis!;
            var c = new HistoryImportCandidate
            {
                SourceKey = meta.SourceKey,
                FolderName = meta.SourceFolder,
                MetricFileName = meta.MetricWorkbook,
                ProjectName = project.Name,
                Customer = project.Customer,
                DrawingNumber = meta.DrawingNumber,
                CalibrationDate = project.Actuals.CompletedAt ?? project.ModifiedAt,
                WeightKg = analysis.WeightKg ?? project.ManualWeightKg,
                ProductionQuantity = meta.ProductionQuantity > 0 ? meta.ProductionQuantity : 1.0,
                ProjectClass = string.IsNullOrWhiteSpace(meta.ProjectClass) ? (analysis.ProjectClass?.Code ?? "") : meta.ProjectClass,
                ActualCutHours = project.Actuals.CuttingHours,
                ActualCncHours = project.Actuals.MachiningHours,
                ActualWeldHours = project.Actuals.WeldingHours,
                ActualAssemblyHours = project.Actuals.AssemblyHours,
                ActualWeldAssemblyHours = project.Actuals.WeldingHours + project.Actuals.AssemblyHours,
                ActualSurfaceHours = project.Actuals.SurfaceHours,
                RobotWeldingHoursIgnored = meta.RobotWeldingHours,
                ActualCncHeavyHours = project.Actuals.SskHours.TryGetValue("3201", out var ssk3201) ? ssk3201 : meta.CncHeavyHours,
                ActualCncMediumHours = project.Actuals.SskHours.TryGetValue("3202", out var ssk3202) ? ssk3202 : meta.CncMediumHours,
                ActualCncLightHours = project.Actuals.SskHours.TryGetValue("3203", out var ssk3203) ? ssk3203 : meta.CncLightHours,
                ActualCncManualHours = project.Actuals.SskHours.TryGetValue("3205", out var ssk3205) ? ssk3205 : meta.CncManualHours,
                ModelCncLargeHours = meta.ModelCncLargeHours,
                ModelCncMediumHours = meta.ModelCncMediumHours,
                ModelCncSmallHours = meta.ModelCncSmallHours,
                HistoricalTotalCostPln = meta.HistoricalTotalCostPln,
                HistoricalPricePln = meta.HistoricalPricePln,
                HistoricalRateHintsPlnH = new Dictionary<string, double>(meta.HistoricalRateHintsPlnH ?? new Dictionary<string, double>(), StringComparer.OrdinalIgnoreCase),
                PreparedProject = project,
                Imported = true,
                Status = "Historia"
            };
            if (project.Actuals.SskHours.TryGetValue("3401", out var ssk3401))
                c.ActualWeldAssemblyHours = Math.Max(0, ssk3401);
            if (project.Actuals.SskHours.TryGetValue("3402", out var ssk3402))
                c.ActualSurfaceHours = Math.Max(0, ssk3402);
            if (project.Actuals.SskHours.TryGetValue("3403", out var ssk3403))
                c.RobotWeldingHoursIgnored = Math.Max(0, ssk3403);
            FillModelHours(c, analysis);
            output.Add(c);
        }
        return output;
    }

    public List<HistoryCalibrationSuggestion> BuildSuggestions(IEnumerable<HistoryImportCandidate> candidates, CostingSettings settings)
    {
        var definitions = new[]
        {
            (Code: "CUT", Name: "Cięcie", Model: (Func<HistoryImportCandidate,double>)(x => x.ModelCutHours), Actual: (Func<HistoryImportCandidate,double>)(x => x.ActualCutHours)),
            (Code: "CNC", Name: "CNC — razem z 3205", Model: (Func<HistoryImportCandidate,double>)(x => x.ModelCncHours), Actual: (Func<HistoryImportCandidate,double>)(x => x.ActualCncHours)),
            (Code: "CNC_SMALL", Name: "CNC małe / 3203 lekkie", Model: (Func<HistoryImportCandidate,double>)(x => x.ModelCncSmallHours), Actual: (Func<HistoryImportCandidate,double>)(x => x.ActualCncLightHours)),
            (Code: "CNC_MEDIUM", Name: "CNC średnie / 3202", Model: (Func<HistoryImportCandidate,double>)(x => x.ModelCncMediumHours), Actual: (Func<HistoryImportCandidate,double>)(x => x.ActualCncMediumHours)),
            (Code: "CNC_LARGE", Name: "CNC duże / 3201 ciężkie", Model: (Func<HistoryImportCandidate,double>)(x => x.ModelCncLargeHours), Actual: (Func<HistoryImportCandidate,double>)(x => x.ActualCncHeavyHours)),
            (Code: "WELD_ASSY_3401", Name: "3401 Montaż + spawanie", Model: (Func<HistoryImportCandidate,double>)(x => x.ModelWeldHours + x.ModelAssemblyHours), Actual: (Func<HistoryImportCandidate,double>)(x => x.ActualWeldAssemblyHours)),
            (Code: "SURF", Name: "Powierzchnia / malowanie", Model: (Func<HistoryImportCandidate,double>)(x => x.ModelSurfaceHours), Actual: (Func<HistoryImportCandidate,double>)(x => x.ActualSurfaceHours))
        };

        var result = new List<HistoryCalibrationSuggestion>();
        foreach (var d in definitions)
        {
            var allRatios = candidates
                .Where(x => x.Imported || x.ReadyToImport || x.Status == "Uwaga")
                .Select(x => new { Model = d.Model(x), Actual = d.Actual(x) })
                .Where(x => x.Model > 0.05 && x.Actual > 0)
                .Select(x => x.Actual / x.Model)
                .Where(double.IsFinite)
                .OrderBy(x => x)
                .ToList();
            var ratios = allRatios.Where(x => x is >= 0.25 and <= 4.0).ToList();
            var outliers = allRatios.Where(x => x < 0.25 || x > 4.0).ToList();

            if (ratios.Count == 0)
            {
                result.Add(new HistoryCalibrationSuggestion
                {
                    ProcessCode = d.Code, ProcessName = d.Name, Samples = 0, OutlierCount = outliers.Count,
                    MinOutlierRatio = outliers.Count > 0 ? outliers.Min() : 0, MaxOutlierRatio = outliers.Count > 0 ? outliers.Max() : 0, Usable = false
                });
                continue;
            }

            var median = RobustMedian(ratios);
            result.Add(new HistoryCalibrationSuggestion
            {
                ProcessCode = d.Code,
                ProcessName = d.Name,
                Samples = ratios.Count,
                OutlierCount = outliers.Count,
                MinOutlierRatio = outliers.Count > 0 ? outliers.Min() : 0,
                MaxOutlierRatio = outliers.Count > 0 ? outliers.Max() : 0,
                RawMedianFactor = median,
                SuggestedFactor = Math.Clamp(median, settings.AutoCalibrationMinFactor, settings.AutoCalibrationMaxFactor),
                Usable = settings.AutoCalibrationEnabled && ratios.Count >= Math.Max(1, settings.AutoCalibrationMinSamples)
            });
        }
        return result;
    }

    public CalibrationValidationReport BuildCalibrationValidation(
        IEnumerable<HistoryImportCandidate> candidates,
        CostingSettings settings)
    {
        var source = candidates
            .Where(x => x.Imported || x.ReadyToImport || x.Status == "Uwaga")
            .GroupBy(CalibrationIdentity, StringComparer.OrdinalIgnoreCase)
            .Select(x => x.First())
            .ToList();

        // FIX18: revisions/variants of one drawing are one family and may never be
        // split across training and validation. Families are ordered by completion
        // date, so the holdout simulates genuinely later work instead of a random bag.
        var orderedGroups = source
            .GroupBy(CalibrationFamilyKey, StringComparer.OrdinalIgnoreCase)
            .Select(x => new CalibrationFamilyGroup(
                x.Key,
                x.OrderBy(y => y.CalibrationDate == default ? DateTime.MinValue : y.CalibrationDate)
                    .ThenBy(StableCalibrationOrder, StringComparer.Ordinal)
                    .ToList()))
            .OrderBy(x => x.LastDate)
            .ThenBy(x => x.StableOrder, StringComparer.Ordinal)
            .ToList();
        source = orderedGroups.SelectMany(x => x.Items).ToList();

        var minimumProjects = Math.Max(6, settings.CalibrationValidationMinimumProjects);
        if (!settings.CalibrationValidationEnabled || source.Count < minimumProjects)
        {
            return new CalibrationValidationReport
            {
                Status = settings.CalibrationValidationEnabled ? "OCZEKUJE" : "WYŁĄCZONA",
                Summary = settings.CalibrationValidationEnabled
                    ? $"Zebrano {source.Count}/{minimumProjects} projektów. Do tego czasu profil działa konserwatywnie, a niezależna bramka MAPE nie blokuje aktualizacji."
                    : "Niezależna walidacja kalibracji została wyłączona w ustawieniach.",
                TrainingProjects = source.Count,
                TrainingGroups = orderedGroups.Count,
                ValidationProjects = 0,
                HasIndependentHoldout = false,
                Passed = true,
                TrainingSuggestions = BuildSuggestions(source, settings),
                TrainingSourceKeys = source.Select(CalibrationIdentity).ToHashSet(StringComparer.OrdinalIgnoreCase)
            };
        }

        var holdoutFraction = Math.Clamp(settings.CalibrationValidationHoldoutPercent, 15, 40) / 100.0;
        var minimumTraining = Math.Max(4, settings.AutoCalibrationMinSamples * 2);
        var requestedHoldout = Math.Max(2, (int)Math.Ceiling(source.Count * holdoutFraction));
        var validationGroups = new List<CalibrationFamilyGroup>();
        var selectedProjects = 0;
        for (var i = orderedGroups.Count - 1; i >= 0 && selectedProjects < requestedHoldout; i--)
        {
            var group = orderedGroups[i];
            if (source.Count - selectedProjects - group.Items.Count < minimumTraining)
                break;
            validationGroups.Add(group);
            selectedProjects += group.Items.Count;
        }
        validationGroups.Reverse();
        var validationKeys = validationGroups.Select(x => x.Key).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var validation = validationGroups.SelectMany(x => x.Items).ToList();
        var trainingGroups = orderedGroups.Where(x => !validationKeys.Contains(x.Key)).ToList();
        var training = trainingGroups.SelectMany(x => x.Items).ToList();
        if (validation.Count == 0 || training.Count < minimumTraining)
        {
            return new CalibrationValidationReport
            {
                Status = "OCZEKUJE",
                Summary = "Nie można utworzyć niezależnego holdoutu bez rozdzielenia rewizji jednej rodziny. Dodaj więcej zakończonych projektów.",
                TrainingProjects = source.Count,
                TrainingGroups = orderedGroups.Count,
                HasIndependentHoldout = false,
                Passed = true,
                TrainingSuggestions = BuildSuggestions(source, settings),
                TrainingSourceKeys = source.Select(CalibrationIdentity).ToHashSet(StringComparer.OrdinalIgnoreCase)
            };
        }
        var trainingSuggestions = BuildSuggestions(training, settings);

        var report = new CalibrationValidationReport
        {
            Status = "WALIDACJA",
            TrainingProjects = training.Count,
            TrainingGroups = trainingGroups.Count,
            ValidationProjects = validation.Count,
            ValidationGroups = validationGroups.Count,
            HasIndependentHoldout = true,
            TrainingSuggestions = trainingSuggestions,
            TrainingSourceKeys = training.Select(CalibrationIdentity).ToHashSet(StringComparer.OrdinalIgnoreCase)
        };

        var baselineErrors = new List<double>();
        var proposedErrors = new List<double>();
        var baselineSigned = new List<double>();
        var proposedSigned = new List<double>();
        foreach (var definition in CalibrationDefinitions())
        {
            var suggestion = trainingSuggestions.FirstOrDefault(x =>
                string.Equals(x.ProcessCode, definition.Code, StringComparison.OrdinalIgnoreCase));
            if (suggestion is null || !suggestion.Usable)
                continue;

            var points = validation
                .Select(x => new { Model = definition.Model(x), Actual = definition.Actual(x) })
                .Where(x => x.Model > 0.05 && x.Actual > 0)
                .ToList();
            if (points.Count == 0)
                continue;

            var baselineDelta = points.Select(x => (x.Model - x.Actual) / x.Actual * 100.0).ToList();
            var proposedDelta = points.Select(x => (x.Model * suggestion.SuggestedFactor - x.Actual) / x.Actual * 100.0).ToList();
            var baseline = baselineDelta.Select(Math.Abs).ToList();
            var proposed = proposedDelta.Select(Math.Abs).ToList();
            baselineErrors.AddRange(baseline);
            proposedErrors.AddRange(proposed);
            baselineSigned.AddRange(baselineDelta);
            proposedSigned.AddRange(proposedDelta);
            var baselineMape = baseline.Average();
            var proposedMape = proposed.Average();
            var baselineBias = baselineDelta.Average();
            var proposedBias = proposedDelta.Average();
            var baselineP90 = Percentile90(baseline);
            var proposedP90 = Percentile90(proposed);
            var tolerance = settings.CalibrationValidationMaxRegressionPercentPoints;
            report.Metrics.Add(new CalibrationValidationMetric
            {
                ProcessCode = definition.Code,
                ProcessName = definition.Name,
                TrainingSamples = suggestion.Samples,
                ValidationSamples = points.Count,
                LearnedFactor = suggestion.SuggestedFactor,
                BaselineMapePercent = baselineMape,
                ProposedMapePercent = proposedMape,
                BaselineBiasPercent = baselineBias,
                ProposedBiasPercent = proposedBias,
                BaselineP90Percent = baselineP90,
                ProposedP90Percent = proposedP90,
                Passed = proposedMape <= baselineMape + tolerance &&
                         proposedP90 <= baselineP90 + 2 * tolerance &&
                         Math.Abs(proposedBias) <= Math.Abs(baselineBias) + tolerance
            });
        }

        report.BaselineMapePercent = baselineErrors.Count == 0 ? 0 : baselineErrors.Average();
        report.ProposedMapePercent = proposedErrors.Count == 0 ? 0 : proposedErrors.Average();
        report.BaselineBiasPercent = baselineSigned.Count == 0 ? 0 : baselineSigned.Average();
        report.ProposedBiasPercent = proposedSigned.Count == 0 ? 0 : proposedSigned.Average();
        report.BaselineP90Percent = Percentile90(baselineErrors);
        report.ProposedP90Percent = Percentile90(proposedErrors);
        BuildRollingValidation(report, orderedGroups, settings);
        var rollingPassed = report.RollingFoldCount == 0 ||
                            report.RollingProposedMapePercent <= report.RollingBaselineMapePercent + settings.CalibrationValidationMaxRegressionPercentPoints;
        report.Passed = report.Metrics.Count > 0 &&
                        report.Metrics.All(x => x.Passed) &&
                        report.ProposedMapePercent <= report.BaselineMapePercent + settings.CalibrationValidationMaxRegressionPercentPoints &&
                        rollingPassed;
        report.Status = report.Passed ? "PASS" : "BLOKADA";
        report.Summary = report.Metrics.Count == 0
            ? "Niezależny zbiór istnieje, ale nie ma wspólnych procesów z dodatnimi godzinami model/rzeczywiste. Profil nie zostanie automatycznie zmieniony."
            : report.Passed
                ? $"Kalibracja przeszła chronologiczny holdout bez przecieku rewizji: MAPE {report.BaselineMapePercent:0.#}% → {report.ProposedMapePercent:0.#}%, P90 {report.BaselineP90Percent:0.#}% → {report.ProposedP90Percent:0.#}%. Profil może zostać zaktualizowany."
                : $"Aktualizacja profilu zablokowana: MAPE {report.BaselineMapePercent:0.#}% → {report.ProposedMapePercent:0.#}%, P90 {report.BaselineP90Percent:0.#}% → {report.ProposedP90Percent:0.#}% lub regresja procesu/rolling przekracza próg.";
        return report;
    }

    private static readonly Regex CalibrationRevisionSuffix = new(
        @"(?:[\s_.-]+REV(?:ISION)?[\s_.-]*[A-Z0-9]+|[\s_.-]+R\d+)(?=$|[\s_.-]+(?:MODEL|DRAWING)$)",
        RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Compiled);

    private sealed record CalibrationFamilyGroup(string Key, List<HistoryImportCandidate> Items)
    {
        public DateTime LastDate => Items.Select(x => x.CalibrationDate).DefaultIfEmpty(DateTime.MinValue).Max();
        public string StableOrder => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Key.ToUpperInvariant())));
    }

    private sealed record CalibrationDefinition(
        string Code,
        string Name,
        Func<HistoryImportCandidate, double> Model,
        Func<HistoryImportCandidate, double> Actual);

    private static IReadOnlyList<CalibrationDefinition> CalibrationDefinitions() =>
    [
        new("CUT", "Cięcie", x => x.ModelCutHours, x => x.ActualCutHours),
        new("CNC", "CNC — razem z 3205", x => x.ModelCncHours, x => x.ActualCncHours),
        new("CNC_SMALL", "CNC małe / 3203", x => x.ModelCncSmallHours, x => x.ActualCncLightHours),
        new("CNC_MEDIUM", "CNC średnie / 3202", x => x.ModelCncMediumHours, x => x.ActualCncMediumHours),
        new("CNC_LARGE", "CNC duże / 3201", x => x.ModelCncLargeHours, x => x.ActualCncHeavyHours),
        new("WELD_ASSY_3401", "3401 Montaż + spawanie", x => x.ModelWeldHours + x.ModelAssemblyHours, x => x.ActualWeldAssemblyHours),
        new("SURF", "Powierzchnia / malowanie", x => x.ModelSurfaceHours, x => x.ActualSurfaceHours)
    ];

    private void BuildRollingValidation(
        CalibrationValidationReport report,
        IReadOnlyList<CalibrationFamilyGroup> groups,
        CostingSettings settings)
    {
        if (groups.Sum(x => x.Items.Count) < 20 || groups.Count < 6)
            return;

        var baseline = new List<double>();
        var proposed = new List<double>();
        foreach (var fraction in new[] { 0.50, 0.67, 0.80 })
        {
            var cut = Math.Clamp((int)Math.Floor(groups.Count * fraction), 3, groups.Count - 1);
            var train = groups.Take(cut).SelectMany(x => x.Items).ToList();
            var validation = groups.Skip(cut).Take(Math.Max(1, (groups.Count - cut + 1) / 2)).SelectMany(x => x.Items).ToList();
            var suggestions = BuildSuggestions(train, settings);
            var foldPoints = 0;
            foreach (var definition in CalibrationDefinitions())
            {
                var suggestion = suggestions.FirstOrDefault(x =>
                    string.Equals(x.ProcessCode, definition.Code, StringComparison.OrdinalIgnoreCase));
                if (suggestion is null || !suggestion.Usable)
                    continue;
                foreach (var point in validation
                             .Select(x => new { Model = definition.Model(x), Actual = definition.Actual(x) })
                             .Where(x => x.Model > 0.05 && x.Actual > 0))
                {
                    baseline.Add(Math.Abs(point.Model - point.Actual) / point.Actual * 100);
                    proposed.Add(Math.Abs(point.Model * suggestion.SuggestedFactor - point.Actual) / point.Actual * 100);
                    foldPoints++;
                }
            }
            if (foldPoints > 0)
                report.RollingFoldCount++;
        }
        report.RollingBaselineMapePercent = baseline.Count == 0 ? 0 : baseline.Average();
        report.RollingProposedMapePercent = proposed.Count == 0 ? 0 : proposed.Average();
    }

    private static double Percentile90(IEnumerable<double> values)
    {
        var ordered = values.Where(double.IsFinite).OrderBy(x => x).ToList();
        if (ordered.Count == 0)
            return 0;
        var index = Math.Clamp((int)Math.Ceiling(ordered.Count * 0.9) - 1, 0, ordered.Count - 1);
        return ordered[index];
    }

    private static string CalibrationIdentity(HistoryImportCandidate candidate)
    {
        var identity = string.Join("|", new[]
        {
            candidate.SourceKey,
            candidate.DrawingNumber,
            candidate.ProjectName,
            candidate.FolderName
        }.Where(x => !string.IsNullOrWhiteSpace(x)));
        return identity.Length > 0
            ? identity
            : $"anonymous|{candidate.ModelTotalHours:0.######}|{candidate.ActualTotalHours:0.######}";
    }

    private static string CalibrationFamilyKey(HistoryImportCandidate candidate)
    {
        if (!string.IsNullOrWhiteSpace(candidate.CalibrationGroupKey))
            return candidate.CalibrationGroupKey.Trim().ToUpperInvariant();

        var source = !string.IsNullOrWhiteSpace(candidate.DrawingNumber)
            ? candidate.DrawingNumber
            : !string.IsNullOrWhiteSpace(candidate.ProjectName)
                ? candidate.ProjectName
                : candidate.FolderName;
        source = CalibrationRevisionSuffix.Replace(source ?? "", "");
        source = Regex.Replace(source, @"[\s_.-]+(?:MODEL|DRAWING)$", "", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
        source = Regex.Replace(source, @"[^A-Z0-9]+", "-", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant).Trim('-').ToUpperInvariant();
        var customer = Regex.Replace(candidate.Customer ?? "", @"[^A-Z0-9]+", "-", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant).Trim('-').ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(source))
            source = StableCalibrationOrder(candidate);
        return $"{customer}|{source}";
    }

    private static string StableCalibrationOrder(HistoryImportCandidate candidate)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(CalibrationIdentity(candidate).ToUpperInvariant()));
        return Convert.ToHexString(bytes);
    }

    public List<HistoryRateSuggestion> BuildRateSuggestions(IEnumerable<HistoryImportCandidate> candidates, CostingSettings settings)
    {
        var source = candidates.Where(x => x.Imported || x.ReadyToImport || x.Status == "Uwaga").ToList();
        var result = new List<HistoryRateSuggestion>();

        foreach (var station in settings.Workstations
                     .Where(x => x.DisplayInRateCard && !string.IsNullOrWhiteSpace(x.CostCenterCode))
                     .OrderBy(x => RateCardOrder(x.CostCenterCode)))
        {
            // ZKS has no SSK hours/rate row in historical metryka scans used for process
            // calibration, but it remains visible/editable in the company rate card.
            if (!station.CostCenterCode.All(char.IsDigit))
                continue;

            var values = source
                .Select(x => x.HistoricalRateHintsPlnH.TryGetValue(station.CostCenterCode, out var rate) ? rate : 0)
                .Where(x => x > 0)
                .OrderBy(x => x)
                .ToList();

            result.Add(new HistoryRateSuggestion
            {
                StationCode = station.Code,
                StationName = $"{station.CostCenterCode} - {station.CostCenterName}",
                SourceSsk = station.CostCenterCode,
                Samples = values.Count,
                CurrentRatePlnH = station.RatePlnPerHour,
                SuggestedRatePlnH = values.Count > 0 ? Math.Round(RobustMedian(values), 2) : station.RatePlnPerHour,
                Usable = values.Count >= Math.Max(2, settings.AutoCalibrationMinSamples)
            });
        }
        return result;
    }

    private static int RateCardOrder(string code)
    {
        if (int.TryParse(code, out var value))
            return value;
        return int.MaxValue;
    }

    public int ApplyRateSuggestions(CostingSettings settings, IEnumerable<HistoryRateSuggestion> suggestions)
    {
        var changed = 0;
        foreach (var suggestion in suggestions.Where(x => x.Usable && x.SuggestedRatePlnH > 0))
        {
            var sourceStation = settings.Workstations.FirstOrDefault(x =>
                string.Equals(x.Code, suggestion.StationCode, StringComparison.OrdinalIgnoreCase));
            if (sourceStation is null)
                continue;

            var costCenter = sourceStation.CostCenterCode;
            foreach (var station in settings.Workstations.Where(x =>
                         !string.IsNullOrWhiteSpace(costCenter) &&
                         string.Equals(x.CostCenterCode, costCenter, StringComparison.OrdinalIgnoreCase)))
                station.RatePlnPerHour = suggestion.SuggestedRatePlnH;
            changed++;
        }

        SynchronizeBaseProcessRates(settings);
        settings.PricingProfileName = "ZKS 2026 — RBH po koszcie całkowitym (historia zweryfikowana)";
        settings.RatesConfirmedByCompany = true;
        return changed;
    }

    public static void SynchronizeBaseProcessRates(CostingSettings settings)
    {
        double? Rate(string ssk) => settings.Workstations
            .FirstOrDefault(x => x.DisplayInRateCard && string.Equals(x.CostCenterCode, ssk, StringComparison.OrdinalIgnoreCase))
            ?.RatePlnPerHour;

        var cutting = Rate("3301");
        var weldingAssembly = Rate("3401");
        var machining = Rate("3202");
        var painting = Rate("3402");

        if (cutting is > 0) settings.CuttingRatePlnH = cutting.Value;
        if (weldingAssembly is > 0)
        {
            settings.WeldingRatePlnH = weldingAssembly.Value;
            settings.AssemblyRatePlnH = weldingAssembly.Value;
        }
        if (machining is > 0) settings.MachiningRatePlnH = machining.Value;
        if (painting is > 0) settings.PaintingRatePlnH = painting.Value;
    }

    public List<CncCapacitySuggestion> BuildCncCapacitySuggestions(IEnumerable<HistoryImportCandidate> candidates, CostingSettings settings)
    {
        var all = candidates
            .Where(x => x.Imported || x.ReadyToImport || x.Status == "Uwaga")
            .SelectMany(x => x.CncCapacitySamples)
            .ToList();

        var result = new List<CncCapacitySuggestion>();
        foreach (var code in new[] { "CNC_SMALL", "CNC_MEDIUM", "CNC_LARGE" })
        {
            var station = settings.Workstations.FirstOrDefault(x => string.Equals(x.Code, code, StringComparison.OrdinalIgnoreCase));
            if (station is null)
                continue;

            var samples = all.Where(x => string.Equals(x.StationCode, code, StringComparison.OrdinalIgnoreCase)).ToList();
            var isLarge = code == "CNC_LARGE";
            var suggestion = new CncCapacitySuggestion
            {
                StationCode = code,
                StationName = station.Name,
                Samples = samples.Count,
                CurrentXmm = station.MaxXmm,
                CurrentYmm = station.MaxYmm,
                CurrentZmm = station.MaxZmm,
                CurrentWeightKg = station.MaxWeightKg,
                IsLargeBoundary = isLarge,
                Usable = !isLarge && samples.Count >= Math.Max(2, settings.AutoCalibrationMinSamples)
            };

            if (samples.Count > 0)
            {
                // This is an empirical routing boundary, not a declaration of the real machine travel.
                // It is deliberately slightly above the largest *confirmed* historical part.
                suggestion.SuggestedXmm = RoundUp(samples.Max(x => x.LengthMm) * 1.05, 100);
                suggestion.SuggestedYmm = RoundUp(samples.Max(x => x.WidthMm) * 1.05, 100);
                suggestion.SuggestedZmm = RoundUp(samples.Max(x => x.HeightMm) * 1.05, 50);
                suggestion.SuggestedWeightKg = RoundUp(samples.Max(x => x.WeightKg) * 1.10, 50);
            }

            suggestion.Basis = isLarge
                ? samples.Count == 0
                    ? "Duża maszyna jest traktowana jako kolejny poziom ponad zakresem CNC średniego. Brak pewnych próbek 3201 do oceny górnego limitu."
                    : $"{samples.Count} próbek 3201 potwierdza użycie dużej maszyny. Dolna granica wynika z przekroczenia CNC średniego; górnego fizycznego limitu nie zmieniamy automatycznie."
                : samples.Count == 0
                    ? "Brak jednoznacznych arkuszy z geometrią i dominującą klasą historyczną."
                    : $"Największy jednoznacznie dopasowany detal historyczny + 5% zapasu wymiarowego i 10% masy. To granica routingu uczona z historii, nie gwarantowany fizyczny przesuw maszyny.";
            result.Add(suggestion);
        }

        var small = result.FirstOrDefault(x => x.StationCode == "CNC_SMALL" && x.Usable);
        var medium = result.FirstOrDefault(x => x.StationCode == "CNC_MEDIUM" && x.Usable);
        if (small is not null && medium is not null)
        {
            medium.SuggestedXmm = Math.Max(medium.SuggestedXmm, small.SuggestedXmm);
            medium.SuggestedYmm = Math.Max(medium.SuggestedYmm, small.SuggestedYmm);
            medium.SuggestedZmm = Math.Max(medium.SuggestedZmm, small.SuggestedZmm);
            medium.SuggestedWeightKg = Math.Max(medium.SuggestedWeightKg, small.SuggestedWeightKg);
        }
        return result;
    }

    public int ApplyCncCapacitySuggestions(CostingSettings settings, IEnumerable<CncCapacitySuggestion> suggestions)
    {
        var changed = 0;
        foreach (var suggestion in suggestions.Where(x => x.Usable && !x.IsLargeBoundary))
        {
            var station = settings.Workstations.FirstOrDefault(x => string.Equals(x.Code, suggestion.StationCode, StringComparison.OrdinalIgnoreCase));
            if (station is null)
                continue;
            station.MaxXmm = suggestion.SuggestedXmm;
            station.MaxYmm = suggestion.SuggestedYmm;
            station.MaxZmm = suggestion.SuggestedZmm;
            station.MaxWeightKg = suggestion.SuggestedWeightKg;
            changed++;
        }
        return changed;
    }

    public CompanyProfileInfo ApplyCompanyProfile(
        CostingSettings settings,
        IEnumerable<HistoryImportCandidate> candidates,
        IEnumerable<HistoryCalibrationSuggestion> calibration,
        IEnumerable<HistoryRateSuggestion> rates,
        IEnumerable<CncCapacitySuggestion> capacities)
    {
        var source = candidates.Where(x => x.Imported || x.ReadyToImport || x.Status == "Uwaga").ToList();
        if (!settings.AutoCompanyProfileEnabled || source.Count == 0)
            return new CompanyProfileInfo
            {
                Version = settings.CompanyProfileVersion,
                HistoryProjects = settings.CompanyProfileHistoryProjects,
                Confidence = settings.CompanyProfileConfidence,
                UpdatedAt = settings.CompanyProfileUpdatedAt,
                Applied = false,
                ValidationStatus = settings.CompanyProfileValidationStatus,
                ValidationSummary = settings.CompanyProfileValidationSummary,
                ValidationBaselineMapePercent = settings.CompanyProfileValidationBaselineMapePercent,
                ValidationProposedMapePercent = settings.CompanyProfileValidationProposedMapePercent,
                ValidationProjects = settings.CompanyProfileValidationProjects
            };

        var validation = BuildCalibrationValidation(source, settings);
        settings.CompanyProfileValidationStatus = validation.Status;
        settings.CompanyProfileValidationSummary = validation.Summary;
        settings.CompanyProfileValidationTrainingProjects = validation.TrainingProjects;
        settings.CompanyProfileValidationProjects = validation.ValidationProjects;
        settings.CompanyProfileValidationBaselineMapePercent = validation.BaselineMapePercent;
        settings.CompanyProfileValidationProposedMapePercent = validation.ProposedMapePercent;
        settings.CompanyProfileValidationBaselineBiasPercent = validation.BaselineBiasPercent;
        settings.CompanyProfileValidationProposedBiasPercent = validation.ProposedBiasPercent;
        settings.CompanyProfileValidationBaselineP90Percent = validation.BaselineP90Percent;
        settings.CompanyProfileValidationProposedP90Percent = validation.ProposedP90Percent;
        settings.CompanyProfileValidationRollingFolds = validation.RollingFoldCount;
        settings.CompanyProfileValidationRollingBaselineMapePercent = validation.RollingBaselineMapePercent;
        settings.CompanyProfileValidationRollingProposedMapePercent = validation.RollingProposedMapePercent;
        if (validation.BlocksProfileUpdate)
        {
            return new CompanyProfileInfo
            {
                Version = settings.CompanyProfileVersion,
                HistoryProjects = settings.CompanyProfileHistoryProjects,
                Confidence = settings.CompanyProfileConfidence,
                UpdatedAt = settings.CompanyProfileUpdatedAt,
                Applied = false,
                ValidationStatus = validation.Status,
                ValidationSummary = validation.Summary,
                ValidationBaselineMapePercent = validation.BaselineMapePercent,
                ValidationProposedMapePercent = validation.ProposedMapePercent,
                ValidationProjects = validation.ValidationProjects
            };
        }

        var acceptedCalibration = validation.HasIndependentHoldout
            ? validation.TrainingSuggestions
            : calibration.ToList();
        var profileSource = validation.HasIndependentHoldout
            ? source.Where(x => validation.TrainingSourceKeys.Contains(CalibrationIdentity(x))).ToList()
            : source;

        if (settings.AutoApplyHistoryProfile)
        {
            if (settings.CompanyProfileBaselineWorkstations.Count == 0)
            {
                settings.CompanyProfileBaselineWorkstations = settings.Workstations.Select(CloneWorkstationForBaseline).ToList();
                settings.CompanyProfileBaselinePricingProfileName = settings.PricingProfileName;
                settings.CompanyProfileBaselineRatesConfirmedByCompany = settings.RatesConfirmedByCompany;
            }
            // Company RBH is authoritative. History may SUGGEST rates in the UI,
            // but only an explicit user click applies them. Automatic profile updates
            // learn times/capacity, never overwrite the 2026 rate card.
            ApplyCncCapacitySuggestions(settings, capacities);
        }

        var profiles = new List<ProcessCalibrationProfile>();
        foreach (var suggestion in acceptedCalibration.Where(x => x.Usable))
        {
            var workstation = suggestion.ProcessCode.StartsWith("CNC_", StringComparison.OrdinalIgnoreCase)
                ? suggestion.ProcessCode
                : "";
            var processCode = suggestion.ProcessCode.StartsWith("CNC_", StringComparison.OrdinalIgnoreCase)
                ? "CNC"
                : suggestion.ProcessCode;
            if (string.Equals(suggestion.ProcessCode, "WELD_ASSY_3401", StringComparison.OrdinalIgnoreCase))
            {
                foreach (var target in new[] { "WELD", "ASSY" })
                    profiles.Add(new ProcessCalibrationProfile
                    {
                        ProcessCode = target, Samples = suggestion.Samples, Factor = suggestion.SuggestedFactor,
                        Confidence = Math.Clamp(55 + suggestion.Samples * 4, 55, 95),
                        Basis = $"SSK 3401 łącznie (montaż + spawanie); {suggestion.Samples} próbek. Ten sam współczynnik skaluje oba składniki bez kołowego podziału wg modelu."
                    });
            }
            else
            {
                profiles.Add(new ProcessCalibrationProfile
                {
                    ProcessCode = processCode,
                    WorkstationCode = workstation,
                    Samples = suggestion.Samples,
                    Factor = suggestion.SuggestedFactor,
                    Confidence = Math.Clamp(55 + suggestion.Samples * 4, 55, 95),
                    Basis = $"Mediana historia/model; {suggestion.Samples} próbek, filtr 0,25–4,00; outliery zachowane diagnostycznie."
                });
            }
        }

        // Add class-specific profiles only when the class has enough independent projects.
        foreach (var cls in profileSource.Where(x => !string.IsNullOrWhiteSpace(x.ProjectClass)).GroupBy(x => x.ProjectClass))
        {
            foreach (var code in new[] { "CUT", "CNC", "SURF" })
            {
                var ratios = cls.Select(x => RatioFor(x, code)).Where(x => x is >= 0.25 and <= 4.0).OrderBy(x => x).ToList();
                if (ratios.Count < Math.Max(3, settings.AutoCalibrationMinSamples))
                    continue;
                var factor = Math.Clamp(RobustMedian(ratios), settings.AutoCalibrationMinFactor, settings.AutoCalibrationMaxFactor);
                profiles.Add(new ProcessCalibrationProfile
                {
                    ProcessCode = code, ProjectClass = cls.Key, Samples = ratios.Count, Factor = factor,
                    Confidence = Math.Clamp(58 + ratios.Count * 4, 58, 96),
                    Basis = $"Klasa {cls.Key}; odporna mediana rzeczywiste/model z {ratios.Count} projektów."
                });
            }
        }

        settings.CompanyProcessFactors = profiles;
        settings.CompanyProfileVersion = Math.Max(1, settings.CompanyProfileVersion + 1);
        settings.CompanyProfileHistoryProjects = source.Count;
        var usableProfiles = profiles.Where(x => x.Samples >= Math.Max(1, settings.AutoCalibrationMinSamples)).ToList();
        settings.CompanyProfileConfidence = usableProfiles.Count == 0 ? 35 :
            Math.Clamp((int)Math.Round(usableProfiles.Average(x => x.Confidence)), 35, 96);
        settings.CompanyProfileUpdatedAt = DateTime.Now;
        settings.PricingProfileName = $"ZKS 2026 — RBH firmowe + kalibracja czasu ({source.Count} projektów)";
        // Import historii never downgrades/overwrites company confirmation of RBH.
        // Rate suggestions stay manual in the dedicated UI card.
        settings.RatesConfirmedByCompany = true;

        return new CompanyProfileInfo
        {
            Version = settings.CompanyProfileVersion,
            HistoryProjects = settings.CompanyProfileHistoryProjects,
            Confidence = settings.CompanyProfileConfidence,
            UpdatedAt = settings.CompanyProfileUpdatedAt,
            Applied = true,
            ValidationStatus = validation.Status,
            ValidationSummary = validation.Summary,
            ValidationBaselineMapePercent = validation.BaselineMapePercent,
            ValidationProposedMapePercent = validation.ProposedMapePercent,
            ValidationProjects = validation.ValidationProjects
        };
    }

    private static WorkstationDefinition CloneWorkstationForBaseline(WorkstationDefinition x) => new()
    {
        Code = x.Code, Name = x.Name, ProcessCode = x.ProcessCode, MatchTag = x.MatchTag,
        Enabled = x.Enabled, Priority = x.Priority, RatePlnPerHour = x.RatePlnPerHour,
        CostCenterCode = x.CostCenterCode, CostCenterName = x.CostCenterName,
        DisplayInRateCard = x.DisplayInRateCard, AutomaticRoutingCandidate = x.AutomaticRoutingCandidate,
        DirectLaborRatePlnH = x.DirectLaborRatePlnH, DepartmentOverheadPercent = x.DepartmentOverheadPercent,
        DepartmentCostRatePlnH = x.DepartmentCostRatePlnH, ManufacturingCostRatePlnH = x.ManufacturingCostRatePlnH,
        GeneralOverheadPercent = x.GeneralOverheadPercent, GeneralCostRatePlnH = x.GeneralCostRatePlnH,
        VariableDepartmentPercent = x.VariableDepartmentPercent, VariableDepartmentRatePlnH = x.VariableDepartmentRatePlnH,
        MaxXmm = x.MaxXmm, MaxYmm = x.MaxYmm, MaxZmm = x.MaxZmm,
        MaxWeightKg = x.MaxWeightKg, MaxThicknessMm = x.MaxThicknessMm,
        TimeFactor = x.TimeFactor, LearnedSamples = x.LearnedSamples
    };

    private static double RatioFor(HistoryImportCandidate c, string code)
    {
        var (model, actual) = code switch
        {
            "CUT" => (c.ModelCutHours, c.ActualCutHours),
            "CNC" => (c.ModelCncHours, c.ActualCncHours),
            "WELD" => (c.ModelWeldHours, c.ActualWeldHours),
            "ASSY" => (c.ModelAssemblyHours, c.ActualAssemblyHours),
            "SURF" => (c.ModelSurfaceHours, c.ActualSurfaceHours),
            _ => (0.0, 0.0)
        };
        return model > 0.05 && actual > 0 ? actual / model : 0;
    }

    private static double RobustMedian(List<double> values)
    {
        if (values.Count == 0) return 0;
        values = values.Where(double.IsFinite).OrderBy(x => x).ToList();
        if (values.Count >= 6)
        {
            var q1 = values[(int)Math.Floor((values.Count - 1) * 0.25)];
            var q3 = values[(int)Math.Floor((values.Count - 1) * 0.75)];
            var iqr = Math.Max(0.0001, q3 - q1);
            var lo = q1 - 1.5 * iqr;
            var hi = q3 + 1.5 * iqr;
            var filtered = values.Where(x => x >= lo && x <= hi).ToList();
            if (filtered.Count >= 3) values = filtered;
        }
        return Median(values);
    }

    private static double RoundUp(double value, double step)
    {
        if (value <= 0 || step <= 0)
            return 0;
        return Math.Ceiling(value / step) * step;
    }

    private static string CopyMetricIntoProject(string metricPath, Guid projectId)
    {
        var dir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "DSEi", projectId.ToString("N")[..8], "history");
        Directory.CreateDirectory(dir);
        var target = Path.Combine(dir, Path.GetFileName(metricPath));
        File.Copy(metricPath, target, overwrite: true);
        return target;
    }

    private static string ComputeSourceKey(string metricPath, IReadOnlyList<string> inputs)
    {
        using var sha = SHA256.Create();
        using var stream = new MemoryStream();
        var metricHash = SHA256.HashData(File.ReadAllBytes(metricPath));
        stream.Write(metricHash);
        foreach (var input in inputs.OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
        {
            var text = Directory.Exists(input)
                ? $"D|{Path.GetFileName(input)}|{Directory.GetLastWriteTimeUtc(input).Ticks}"
                : $"F|{Path.GetFileName(input)}|{new FileInfo(input).Length}|{File.GetLastWriteTimeUtc(input).Ticks}";
            var bytes = Encoding.UTF8.GetBytes(text);
            stream.Write(bytes);
        }
        stream.Position = 0;
        return Convert.ToHexString(sha.ComputeHash(stream));
    }

    private static string BuildProjectName(string folderName, string productName, string drawingNumber)
    {
        var core = !string.IsNullOrWhiteSpace(productName)
            ? productName.Trim()
            : !string.IsNullOrWhiteSpace(drawingNumber)
                ? drawingNumber.Trim()
                : folderName;
        if (string.Equals(core, folderName, StringComparison.OrdinalIgnoreCase))
            return core;
        return $"{folderName} — {core}";
    }

    private static double GetBaseHours(AnalysisResult analysis, string code)
    {
        var p = analysis.Processes.FirstOrDefault(x => x.Enabled && string.Equals(x.Code, code, StringComparison.OrdinalIgnoreCase));
        if (p is null)
            return 0;
        return p.BaseHours > 0 ? p.BaseHours : p.Hours;
    }

    private static double Median(List<double> values)
    {
        if (values.Count == 0) return 1;
        var mid = values.Count / 2;
        return values.Count % 2 == 1 ? values[mid] : (values[mid - 1] + values[mid]) / 2.0;
    }

    private static double Round(double value) => Math.Round(Math.Max(0, value), 3, MidpointRounding.AwayFromZero);

    private static string NaturalSortKey(string path)
    {
        var name = Path.GetFileName(path);
        return string.Concat(name.Select(c => char.IsDigit(c) ? c : char.ToUpperInvariant(c)));
    }

    private static DocumentKind DetectKind(string extension) => extension.ToLowerInvariant() switch
    {
        ".step" or ".stp" => DocumentKind.Step,
        ".dxf" => DocumentKind.Dxf,
        ".dwg" => DocumentKind.Dwg,
        ".pdf" => DocumentKind.Pdf,
        ".png" or ".jpg" or ".jpeg" or ".tif" or ".tiff" or ".bmp" => DocumentKind.Image,
        ".xlsx" or ".xlsm" or ".xls" or ".csv" => DocumentKind.Excel,
        ".txt" or ".bom" or ".log" or ".md" or ".docx" or ".doc" or ".rtf" => DocumentKind.Text,
        _ => DocumentKind.Other
    };
}
