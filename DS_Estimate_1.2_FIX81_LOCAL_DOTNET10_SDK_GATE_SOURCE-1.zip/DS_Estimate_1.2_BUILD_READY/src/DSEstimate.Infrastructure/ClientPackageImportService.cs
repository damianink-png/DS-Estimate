using System.IO.Compression;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text.Json;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

public sealed class ImportedPackageFile
{
    public string Path { get; set; } = "";
    public string RelativePath { get; set; } = "";
    public string Source { get; set; } = "";
    public string ContentHash { get; set; } = "";
    public string DuplicateContentOf { get; set; } = "";
    public DocumentRole Role { get; set; } = DocumentRole.Unknown;
    public int RoleConfidence { get; set; }
    public string RoleReason { get; set; } = "";
    public string ProjectGroupKey { get; set; } = "";
}

public sealed class ImportedProjectGroup
{
    public string Key { get; set; } = "";
    public string Name { get; set; } = "";
    public List<ImportedPackageFile> Files { get; set; } = [];
}

public sealed class ClientPackageImportResult
{
    public List<ImportedPackageFile> Files { get; set; } = [];
    public List<string> Warnings { get; set; } = [];
    public int ZipCount { get; set; }
    public int NestedZipCount { get; set; }
    public int FolderCount { get; set; }
    public int ReusedArchiveCount { get; set; }
    // Byte-identical duplicates with the same visible filename automatically removed.
    public int DuplicateNameCount { get; set; }
    // Byte-identical files under different names stay visible, but are marked as
    // aliases so the evidence layer does not count them as independent sources.
    public int DuplicateContentAliasCount { get; set; }
    // Same visible name but different SHA256: both are preserved for revision/conflict analysis.
    public int ConflictingNameCount { get; set; }
    public int SkippedUnsupportedCount { get; set; }
    public List<ImportedProjectGroup> ProjectGroups { get; set; } = [];
}

public sealed class PackageImportProgress
{
    public int Percent { get; init; }
    public string Message { get; init; } = "";
}

public sealed class ClientPackageImportService
{
    private const int MaxNestedZipDepth = 4;
    private const int MaxArchiveEntries = 50_000;
    // Realne paczki CAD (STEP/PDF/DXF) mieszczą się grubo poniżej 200:1.
    private const long MaxCompressionRatio = 200;
    private const long MinRatioCheckCompressedBytes = 8L * 1024 * 1024;
    private const string PackageCacheVersion = "dse101-zipguard";
    private const string CacheManifestName = "manifest.json";

    [DllImport("kernel32.dll", EntryPoint = "CreateHardLinkW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CreateHardLinkWindows(
        string newFileName,
        string existingFileName,
        IntPtr securityAttributes);

    private static readonly HashSet<string> SupportedExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".step", ".stp", ".dxf", ".dwg", ".pdf",
        ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp",
        ".xlsx", ".xlsm", ".xls", ".csv",
        ".docx", ".doc", ".rtf",
        ".txt", ".bom", ".log", ".md"
    };

    private sealed class ExtractionBudget
    {
        public long MaxBytes { get; init; }
        public long SeenBytes { get; set; }
        public int SeenEntries { get; set; }
        // 1.0.1 zip-bomb guard: skompresowany rozmiar wejścia vs rozmiar po rozpakowaniu.
        public long SeenCompressedBytes { get; set; }
    }

    private sealed class CachedArchiveManifest
    {
        public CachedArchiveManifest() { }
        public int CountedEntries { get; set; }
        public long CountedBytes { get; set; }
        public int SkippedUnsupportedCount { get; set; }
        public List<CachedArchiveEntry> Entries { get; set; } = [];
    }

    private sealed class CachedArchiveEntry
    {
        public CachedArchiveEntry() { }
        public string StoredName { get; set; } = "";
        public string LogicalPath { get; set; } = "";
        public string ContentHash { get; set; } = "";
        public bool NestedZip { get; set; }
    }

    public void DeleteProjectImports(Guid projectId)
    {
        foreach (var dir in new[]
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DSEi", projectId.ToString("N")[..8]),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DSEstimateNext", "imports", projectId.ToString("N"))
        })
        {
            try
            {
                if (Directory.Exists(dir))
                    Directory.Delete(dir, recursive: true);
            }
            catch
            {
                // Cleanup must never block normal work.
            }
        }
    }

    public Task<ClientPackageImportResult> ExpandAsync(
        IEnumerable<string> inputs,
        Guid projectId,
        double maxZipExtractGb,
        CancellationToken cancellationToken = default,
        IProgress<PackageImportProgress>? progress = null)
    {
        // Materialize the enumerable on the caller thread, then move hashing,
        // decompression and duplicate detection away from the Avalonia UI thread.
        var inputList = inputs
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        return Task.Run(
            () => ExpandCore(inputList, projectId, maxZipExtractGb, cancellationToken, progress),
            cancellationToken);
    }

    private static ClientPackageImportResult ExpandCore(
        IReadOnlyList<string> inputs,
        Guid projectId,
        double maxZipExtractGb,
        CancellationToken cancellationToken,
        IProgress<PackageImportProgress>? progress)
    {
        var result = new ClientPackageImportResult();
        var maxBytes = (long)(Math.Clamp(maxZipExtractGb, 0.25, 100.0) * 1024 * 1024 * 1024);
        var budget = new ExtractionBudget { MaxBytes = maxBytes };

        progress?.Report(new PackageImportProgress { Percent = 2, Message = "Przygotowanie importu dokumentacji…" });
        for (var inputIndex = 0; inputIndex < inputs.Count; inputIndex++)
        {
            var input = inputs[inputIndex];
            cancellationToken.ThrowIfCancellationRequested();
            var inputStart = 5.0 + inputIndex * 88.0 / Math.Max(1, inputs.Count);
            var inputSpan = 88.0 / Math.Max(1, inputs.Count);
            progress?.Report(new PackageImportProgress
            {
                Percent = (int)Math.Round(inputStart),
                Message = $"Wczytywanie {inputIndex + 1}/{inputs.Count}: {Path.GetFileName(input)}"
            });

            try
            {
                if (Directory.Exists(input))
                {
                    result.FolderCount++;
                    AddFolder(result, input, projectId, budget, cancellationToken, progress, inputStart, inputSpan);
                }
                else if (File.Exists(input) && string.Equals(Path.GetExtension(input), ".zip", StringComparison.OrdinalIgnoreCase))
                {
                    result.ZipCount++;
                    ExtractZip(result, input, projectId, budget, cancellationToken, depth: 0, logicalPrefix: "",
                        progress: progress, progressStart: inputStart, progressSpan: inputSpan);
                }
                else if (File.Exists(input))
                {
                    AddFile(result, input, Path.GetFileName(input), "Pliki bezpośrednie");
                }
                else
                {
                    result.Warnings.Add($"Pominięto nieistniejącą ścieżkę: {input}");
                }
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                result.Warnings.Add($"Nie udało się wczytać {input}: {ex.GetType().Name}: {ex.Message}");
            }
        }

        var sameNameDeduplicated = DeduplicateByVisibleFileName(result, result.Files);
        MarkCrossNameContentAliases(result, sameNameDeduplicated);
        ClassifyFiles(sameNameDeduplicated);
        DetectIndependentProjectGroups(result, inputs, sameNameDeduplicated);
        result.Files = sameNameDeduplicated
            .OrderBy(x => x.ProjectGroupKey, StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.RelativePath, StringComparer.OrdinalIgnoreCase)
            .ToList();

        progress?.Report(new PackageImportProgress
        {
            Percent = 100,
            Message = $"Import zakończony · {result.Files.Count} obsługiwanych plików"
        });

        return result;
    }

    private static void ClassifyFiles(IEnumerable<ImportedPackageFile> files)
    {
        foreach (var file in files)
        {
            var classification = DocumentSelectionPolicy.Classify(
                file.Path, file.RelativePath, Path.GetExtension(file.Path));
            file.Role = classification.Role;
            file.RoleConfidence = classification.Confidence;
            file.RoleReason = classification.Reason;
        }
    }

    private static void DetectIndependentProjectGroups(
        ClientPackageImportResult result,
        IReadOnlyList<string> inputs,
        IReadOnlyList<ImportedPackageFile> files)
    {
        // FIX10 deliberately splits only a single user-selected folder. ZIPs and
        // arbitrary multi-selection keep their current one-project semantics.
        if (inputs.Count != 1 || !Directory.Exists(inputs[0]))
            return;

        static string TopSegment(string relativePath)
        {
            var normalized = (relativePath ?? "").Replace('\\', '/').Trim('/');
            var slash = normalized.IndexOf('/');
            return slash < 0 ? "" : normalized[..slash];
        }

        static bool StrongAnchor(ImportedPackageFile file)
        {
            var ext = Path.GetExtension(file.Path).ToLowerInvariant();
            return file.Role == DocumentRole.Production && ext is ".step" or ".stp" or ".dxf" or ".dwg";
        }

        static bool SupportingTechnical(ImportedPackageFile file)
        {
            if (file.Role != DocumentRole.Production)
                return false;
            var ext = Path.GetExtension(file.Path).ToLowerInvariant();
            return ext is ".pdf" or ".xlsx" or ".xlsm" or ".xls" or ".csv" or ".bom" or ".docx" or ".doc" or ".rtf" or ".txt";
        }

        var candidates = files
            .Select(x => new { File = x, Top = TopSegment(x.RelativePath) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Top))
            .GroupBy(x => x.Top, StringComparer.OrdinalIgnoreCase)
            .Select(group => new
            {
                Key = group.Key,
                Files = group.Select(x => x.File).ToList(),
                Strong = group.Count(x => StrongAnchor(x.File)),
                Support = group.Count(x => SupportingTechnical(x.File))
            })
            .Where(x => !DocumentSelectionPolicy.IsGenericContainerName(x.Key))
            .Where(x => x.Strong >= 1 && (x.Strong >= 2 || x.Support >= 1))
            .OrderBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (candidates.Count < 2)
            return;

        // Avoid splitting a documentation tree because of two incidental CAD files.
        var productionCount = files.Count(x => x.Role == DocumentRole.Production);
        var coveredProduction = candidates.Sum(x => x.Files.Count(f => f.Role == DocumentRole.Production));
        if (productionCount > 0 && coveredProduction < Math.Ceiling(productionCount * 0.60))
            return;

        foreach (var candidate in candidates)
        {
            foreach (var file in candidate.Files)
                file.ProjectGroupKey = candidate.Key;
            result.ProjectGroups.Add(new ImportedProjectGroup
            {
                Key = candidate.Key,
                Name = candidate.Key,
                Files = candidate.Files.OrderBy(x => x.RelativePath, StringComparer.OrdinalIgnoreCase).ToList()
            });
        }

        result.Warnings.Add(
            $"FIX10: wykryto {result.ProjectGroups.Count} niezależne projekty w jednym folderze; utworzono osobne podwyceny.");
    }

    public string MaterializeImportedFileForProject(ImportedPackageFile item, Guid projectId)
    {
        if (string.IsNullOrWhiteSpace(item.Path) || !File.Exists(item.Path))
            return item.Path;

        var full = Path.GetFullPath(item.Path);
        var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        var managedRoots = new[]
        {
            Path.Combine(local, "DSEi"),
            Path.Combine(local, "DSEstimateNext", "imports")
        };
        var fromManagedImport = managedRoots.Any(root =>
            full.StartsWith(Path.GetFullPath(root) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase));
        if (!fromManagedImport)
            return full; // direct user files remain referenced in place

        var targetRoot = Path.Combine(local, "DSEi", projectId.ToString("N")[..8], "fix10-split");
        var safeRelative = (item.RelativePath ?? Path.GetFileName(full))
            .Replace("!/", "__ZIP__/")
            .Replace('\\', '/');
        var segments = safeRelative.Split('/', StringSplitOptions.RemoveEmptyEntries)
            .Select(x => string.Concat(x.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c)))
            .ToArray();
        var target = segments.Length == 0
            ? Path.Combine(targetRoot, Path.GetFileName(full))
            : Path.Combine(new[] { targetRoot }.Concat(segments).ToArray());
        Directory.CreateDirectory(Path.GetDirectoryName(target)!);
        if (File.Exists(target))
            return target;

        try
        {
            if (OperatingSystem.IsWindows() && CreateHardLinkWindows(target, full, IntPtr.Zero))
                return target;
        }
        catch
        {
            // Cross-volume / permissions: fall back to copy.
        }
        File.Copy(full, target, overwrite: false);
        return target;
    }

    private static void AddFolder(
        ClientPackageImportResult result,
        string folder,
        Guid projectId,
        ExtractionBudget budget,
        CancellationToken ct,
        IProgress<PackageImportProgress>? progress,
        double progressStart,
        double progressSpan)
    {
        var root = Path.GetFullPath(folder);
        var source = Path.GetFileName(root.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
        var files = Directory.EnumerateFiles(root, "*", SearchOption.AllDirectories).ToList();
        for (var fileIndex = 0; fileIndex < files.Count; fileIndex++)
        {
            var file = files[fileIndex];
            ct.ThrowIfCancellationRequested();
            ReportImportProgress(progress, progressStart, progressSpan,
                fileIndex + 1, Math.Max(1, files.Count), $"Skanowanie folderu: {fileIndex + 1}/{files.Count}");
            if (string.Equals(Path.GetExtension(file), ".zip", StringComparison.OrdinalIgnoreCase))
            {
                result.ZipCount++;
                result.NestedZipCount++;
                var rel = Path.GetRelativePath(root, file).Replace('\\', '/');
                ExtractZip(result, file, projectId, budget, ct, depth: 1, logicalPrefix: rel + "!/",
                    progress: progress, progressStart: progressStart, progressSpan: progressSpan);
                continue;
            }

            AddFile(result, file, Path.GetRelativePath(root, file), source);
        }
    }

    private static void ExtractZip(
        ClientPackageImportResult result,
        string zipPath,
        Guid projectId,
        ExtractionBudget budget,
        CancellationToken ct,
        int depth,
        string logicalPrefix,
        IProgress<PackageImportProgress>? progress,
        double progressStart,
        double progressSpan)
    {
        if (depth > MaxNestedZipDepth)
        {
            result.Warnings.Add($"Pominięto ZIP zagnieżdżony głębiej niż {MaxNestedZipDepth} poziomy: {logicalPrefix}{Path.GetFileName(zipPath)}");
            return;
        }

        var archiveHash = SafeHash(zipPath);
        if (string.IsNullOrWhiteSpace(archiveHash))
            throw new InvalidDataException($"Nie można obliczyć SHA256 paczki ZIP: {Path.GetFileName(zipPath)}");

        var cacheDir = PackageCacheDirectory(archiveHash);
        var manifestPath = Path.Combine(cacheDir, CacheManifestName);
        var source = depth == 0
            ? Path.GetFileName(zipPath)
            : $"ZIP zagnieżdżony: {NestedArchiveDisplayName(logicalPrefix)}";

        if (TryReadCacheManifest(manifestPath, cacheDir, out var cachedManifest))
        {
            progress?.Report(new PackageImportProgress
            {
                Percent = (int)Math.Round(progressStart + progressSpan * 0.75),
                Message = $"ZIP z cache: {NestedArchiveDisplayName(logicalPrefix + Path.GetFileName(zipPath))}"
            });
            ApplyArchiveBudget(cachedManifest!, budget);
            result.ReusedArchiveCount++;
            result.SkippedUnsupportedCount += cachedManifest!.SkippedUnsupportedCount;
            ReplayCachedArchive(result, cachedManifest!, cacheDir, archiveHash, source, projectId, budget, ct, depth, logicalPrefix,
                progress, progressStart, progressSpan);
            return;
        }

        var parent = Path.GetDirectoryName(cacheDir)!;
        Directory.CreateDirectory(parent);
        var stagingDir = cacheDir + ".tmp-" + Guid.NewGuid().ToString("N");
        Directory.CreateDirectory(stagingDir);

        try
        {
            var manifest = new CachedArchiveManifest();
            using var archive = ZipFile.OpenRead(zipPath);
            if (archive.Entries.Count > MaxArchiveEntries)
                throw new InvalidDataException($"ZIP zawiera ponad {MaxArchiveEntries:N0} wpisów — automatyczne rozpakowanie zatrzymano.");

            var fileIndex = 0;
            var entryIndex = 0;
            foreach (var entry in archive.Entries)
            {
                entryIndex++;
                ct.ThrowIfCancellationRequested();
                ReportImportProgress(progress, progressStart, progressSpan,
                    entryIndex, Math.Max(1, archive.Entries.Count),
                    $"Rozpakowywanie ZIP: {entryIndex}/{archive.Entries.Count} · {Path.GetFileName(entry.FullName)}");
                if (string.IsNullOrEmpty(entry.Name))
                    continue;

                manifest.CountedEntries++;
                manifest.CountedBytes += Math.Max(0, entry.Length);
                budget.SeenEntries++;
                budget.SeenBytes += Math.Max(0, entry.Length);
                budget.SeenCompressedBytes += Math.Max(0, entry.CompressedLength);
                ValidateBudget(budget);

                var normalizedEntry = entry.FullName.Replace('\\', '/');
                if (normalizedEntry.StartsWith("/", StringComparison.Ordinal) ||
                    normalizedEntry.Split('/').Any(x => x == ".."))
                {
                    result.Warnings.Add($"Pominięto niebezpieczną ścieżkę ZIP: {entry.FullName}");
                    continue;
                }

                var ext = Path.GetExtension(entry.Name);
                if (string.Equals(ext, ".zip", StringComparison.OrdinalIgnoreCase))
                {
                    if (depth >= MaxNestedZipDepth)
                    {
                        result.Warnings.Add($"Pominięto ZIP na maksymalnej głębokości {MaxNestedZipDepth}: {logicalPrefix}{normalizedEntry}");
                        continue;
                    }

                    fileIndex++;
                    var storedName = $"z{fileIndex:00000}.zip";
                    var storedPath = Path.Combine(stagingDir, storedName);
                    entry.ExtractToFile(storedPath, overwrite: true);
                    manifest.Entries.Add(new CachedArchiveEntry
                    {
                        StoredName = storedName,
                        LogicalPath = normalizedEntry,
                        ContentHash = SafeHash(storedPath),
                        NestedZip = true
                    });
                    continue;
                }

                if (!SupportedExtensions.Contains(ext))
                {
                    result.SkippedUnsupportedCount++;
                    manifest.SkippedUnsupportedCount++;
                    continue;
                }

                fileIndex++;
                var targetName = $"f{fileIndex:00000}{ext.ToLowerInvariant()}";
                var target = Path.Combine(stagingDir, targetName);
                entry.ExtractToFile(target, overwrite: true);
                manifest.Entries.Add(new CachedArchiveEntry
                {
                    StoredName = targetName,
                    LogicalPath = normalizedEntry,
                    ContentHash = SafeHash(target),
                    NestedZip = false
                });
            }

            File.WriteAllText(
                Path.Combine(stagingDir, CacheManifestName),
                JsonSerializer.Serialize(manifest));

            if (Directory.Exists(cacheDir))
                Directory.Delete(cacheDir, recursive: true);
            Directory.Move(stagingDir, cacheDir);

            // The cold extraction already consumed this archive's budget. Nested ZIPs
            // are counted by their own ExtractZip calls below.
            ReplayCachedArchive(result, manifest, cacheDir, archiveHash, source, projectId, budget, ct, depth, logicalPrefix,
                progress, progressStart, progressSpan);
        }
        finally
        {
            try
            {
                if (Directory.Exists(stagingDir))
                    Directory.Delete(stagingDir, recursive: true);
            }
            catch
            {
                // An incomplete cache folder is ignored on the next import.
            }
        }
    }

    private static void ReplayCachedArchive(
        ClientPackageImportResult result,
        CachedArchiveManifest manifest,
        string cacheDir,
        string archiveHash,
        string source,
        Guid projectId,
        ExtractionBudget budget,
        CancellationToken ct,
        int depth,
        string logicalPrefix,
        IProgress<PackageImportProgress>? progress,
        double progressStart,
        double progressSpan)
    {
        foreach (var entry in manifest.Entries)
        {
            ct.ThrowIfCancellationRequested();
            var cachedPath = Path.Combine(cacheDir, entry.StoredName);
            var logicalPath = logicalPrefix + entry.LogicalPath;

            if (entry.NestedZip)
            {
                result.ZipCount++;
                result.NestedZipCount++;
                var nestedTarget = cachedPath;
                ExtractZip(result, nestedTarget, projectId, budget, ct, depth + 1, logicalPath + "!/",
                    progress, progressStart, progressSpan);
                continue;
            }

            var projectPath = MaterializeForProject(cachedPath, projectId, archiveHash, entry.StoredName);
            AddFile(result, projectPath, logicalPath, source, entry.ContentHash);
        }
    }

    private static string MaterializeForProject(
        string cachedPath,
        Guid projectId,
        string archiveHash,
        string storedName)
    {
        var projectDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "DSEi",
            projectId.ToString("N")[..8],
            $"c{archiveHash[..16].ToLowerInvariant()}");
        Directory.CreateDirectory(projectDir);
        var target = Path.Combine(projectDir, storedName);

        if (File.Exists(target) && new FileInfo(target).Length == new FileInfo(cachedPath).Length)
            return target;

        try
        {
            if (File.Exists(target))
                File.Delete(target);
            if (!OperatingSystem.IsWindows() ||
                !CreateHardLinkWindows(target, cachedPath, IntPtr.Zero))
                throw new IOException("System plików nie obsługuje bezpiecznego dowiązania cache.");
        }
        catch
        {
            File.Copy(cachedPath, target, overwrite: true);
        }
        return target;
    }

    private static bool TryReadCacheManifest(
        string manifestPath,
        string cacheDir,
        out CachedArchiveManifest? manifest)
    {
        manifest = null;
        try
        {
            if (!File.Exists(manifestPath))
                return false;
            manifest = JsonSerializer.Deserialize<CachedArchiveManifest>(File.ReadAllText(manifestPath));
            return manifest is not null && manifest.Entries.All(x =>
                !string.IsNullOrWhiteSpace(x.StoredName) &&
                File.Exists(Path.Combine(cacheDir, x.StoredName)));
        }
        catch
        {
            manifest = null;
            return false;
        }
    }

    private static void ApplyArchiveBudget(CachedArchiveManifest manifest, ExtractionBudget budget)
    {
        budget.SeenEntries += manifest.CountedEntries;
        budget.SeenBytes += manifest.CountedBytes;
        ValidateBudget(budget);
    }

    private static void ValidateBudget(ExtractionBudget budget)
    {
        if (budget.SeenEntries > MaxArchiveEntries)
            throw new InvalidDataException($"Łączna liczba wpisów ZIP przekroczyła {MaxArchiveEntries:N0}; zatrzymano ochronnie rekurencję.");
        if (budget.SeenBytes > budget.MaxBytes)
            throw new InvalidDataException($"Łączna zawartość rozpakowanych ZIP-ów przekracza limit {budget.MaxBytes / 1024d / 1024d / 1024d:0.##} GB.");
        // 1.0.1: ochrona przed zip bombą. Sam limit bezwzględny nie wystarcza, bo
        // kilkusetkilobajtowy plik potrafi rozpakować się do dziesiątek GB.
        if (budget.SeenCompressedBytes >= MinRatioCheckCompressedBytes &&
            budget.SeenBytes > budget.SeenCompressedBytes * MaxCompressionRatio)
            throw new InvalidDataException(
                $"Podejrzany współczynnik kompresji paczki ({budget.SeenBytes / (double)Math.Max(1, budget.SeenCompressedBytes):0} : 1). " +
                "Import zatrzymano ochronnie — rozpakuj paczkę ręcznie i wskaż folder.");
    }

    private static string PackageCacheDirectory(string hash) => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "DSEstimateNext", "package-cache", PackageCacheVersion,
        hash[..2].ToLowerInvariant(), hash.ToLowerInvariant());

    private static string NestedArchiveDisplayName(string logicalPrefix)
    {
        var value = logicalPrefix.TrimEnd('/', '!');
        var marker = value.LastIndexOf("!/", StringComparison.Ordinal);
        if (marker >= 0)
            value = value[(marker + 2)..];
        return string.IsNullOrWhiteSpace(value) ? "archiwum.zip" : Path.GetFileName(value);
    }

    private static void ReportImportProgress(
        IProgress<PackageImportProgress>? progress,
        double start,
        double span,
        int completed,
        int total,
        string message)
    {
        if (progress is null)
            return;
        var reportEvery = Math.Max(1, total / 200);
        if (completed != 1 && completed != total && completed % reportEvery != 0)
            return;
        var fraction = Math.Clamp(completed / (double)Math.Max(1, total), 0, 1);
        progress.Report(new PackageImportProgress
        {
            Percent = Math.Clamp((int)Math.Round(start + span * fraction), 0, 99),
            Message = message
        });
    }

    private static List<ImportedPackageFile> DeduplicateByVisibleFileName(
        ClientPackageImportResult result,
        IEnumerable<ImportedPackageFile> files)
    {
        var output = new List<ImportedPackageFile>();
        foreach (var group in files
                     .GroupBy(x => Path.GetFileName(x.RelativePath), StringComparer.OrdinalIgnoreCase)
                     .OrderBy(g => g.Key, StringComparer.OrdinalIgnoreCase))
        {
            var ordered = group
                .OrderBy(x => x.RelativePath.Count(c => c is '/' or '\\'))
                .ThenBy(x => x.RelativePath.Length)
                .ThenBy(x => x.RelativePath, StringComparer.OrdinalIgnoreCase)
                .ToList();

            var byContent = ordered
                .Select(x =>
                {
                    if (string.IsNullOrWhiteSpace(x.ContentHash))
                        x.ContentHash = SafeHash(x.Path);
                    return new { File = x, Hash = x.ContentHash };
                })
                .GroupBy(x => string.IsNullOrWhiteSpace(x.Hash) ? $"UNHASHED|{x.File.RelativePath}" : x.Hash, StringComparer.OrdinalIgnoreCase)
                .ToList();

            var distinctContent = new List<ImportedPackageFile>();
            foreach (var contentGroup in byContent)
            {
                var candidates = contentGroup.Select(x => x.File).ToList();
                var keep = candidates[0];
                distinctContent.Add(keep);
                if (candidates.Count > 1)
                {
                    result.DuplicateNameCount += candidates.Count - 1;
                    result.Warnings.Add($"Identyczny duplikat SHA256 pominięty: {group.Key} (zachowano {keep.RelativePath}).");
                }
            }

            if (distinctContent.Count > 1)
            {
                result.ConflictingNameCount += distinctContent.Count - 1;
                result.Warnings.Add(
                    $"Konflikt nazwy: {group.Key} występuje w {distinctContent.Count} różnych wersjach binarnych. " +
                    "Zachowano wszystkie; analiza rewizji/rodziny dokumentu zdecyduje o użyciu zamiast kasować dane klienta.");
            }

            output.AddRange(distinctContent);
        }
        return output;
    }

    private static void MarkCrossNameContentAliases(
        ClientPackageImportResult result,
        IReadOnlyList<ImportedPackageFile> files)
    {
        foreach (var group in files
                     .Where(x => !string.IsNullOrWhiteSpace(x.ContentHash))
                     .GroupBy(x => x.ContentHash, StringComparer.OrdinalIgnoreCase))
        {
            var ordered = group
                .OrderBy(x => x.RelativePath.Count(c => c is '/' or '\\'))
                .ThenBy(x => x.RelativePath.Length)
                .ThenBy(x => x.RelativePath, StringComparer.OrdinalIgnoreCase)
                .ToList();
            var visibleNames = ordered.Select(x => Path.GetFileName(x.RelativePath))
                .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            if (ordered.Count < 2 || visibleNames.Count < 2)
                continue;

            var canonical = ordered[0];
            foreach (var alias in ordered.Skip(1))
            {
                alias.DuplicateContentOf = canonical.RelativePath;
                result.DuplicateContentAliasCount++;
            }

            var prefix = group.Key.Length > 16 ? group.Key[..16] : group.Key;
            result.Warnings.Add(
                $"Identyczna treść SHA256 {prefix} pod różnymi nazwami: " +
                $"{string.Join(", ", ordered.Select(x => x.RelativePath))}. " +
                $"Zachowano wszystkie pliki; niezależny głos dowodowy ma {canonical.RelativePath}.");
        }
    }

    private static string SafeHash(string path)
    {
        try
        {
            using var stream = File.OpenRead(path);
            return Convert.ToHexString(SHA256.HashData(stream));
        }
        catch
        {
            return "";
        }
    }

    private static void AddFile(
        ClientPackageImportResult result,
        string path,
        string relativePath,
        string source,
        string contentHash = "")
    {
        if (!SupportedExtensions.Contains(Path.GetExtension(path)))
        {
            result.SkippedUnsupportedCount++;
            return;
        }

        result.Files.Add(new ImportedPackageFile
        {
            Path = Path.GetFullPath(path),
            RelativePath = relativePath,
            Source = source,
            ContentHash = contentHash
        });
    }
}
