﻿using System.Text.RegularExpressions;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Globalization;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

public sealed class AnalysisProgress
{
    public int Percent { get; init; }
    public string Message { get; init; } = "";
    public string CurrentFile { get; init; } = "";
    public string DocumentPath { get; init; } = "";
    public string DocumentStatus { get; init; } = "";
    public string DocumentSummary { get; init; } = "";
}

internal sealed class WeightedAnalysisProgress
{
    private readonly object _sync = new();
    private readonly Dictionary<string, double> _weights;
    private readonly Dictionary<string, double> _fractions = new(StringComparer.OrdinalIgnoreCase);
    private readonly IProgress<AnalysisProgress>? _progress;
    private readonly double _totalWeight;

    public WeightedAnalysisProgress(IEnumerable<ProjectDocument> documents, IProgress<AnalysisProgress>? progress)
    {
        _progress = progress;
        _weights = documents.ToDictionary(x => Key(x), Weight, StringComparer.OrdinalIgnoreCase);
        _totalWeight = Math.Max(1, _weights.Values.Sum());
    }

    public void Update(ProjectDocument doc, double fraction, string message)
    {
        lock (_sync)
        {
            _fractions[Key(doc)] = Math.Clamp(fraction, 0, 1);
            var done = _weights.Sum(pair => pair.Value * (_fractions.TryGetValue(pair.Key, out var f) ? f : 0));
            var percent = 5 + (int)Math.Round(77.0 * done / _totalWeight);
            _progress?.Report(new AnalysisProgress
            {
                Percent = Math.Clamp(percent, 5, 82),
                Message = message,
                CurrentFile = doc.Name
            });
        }
    }

    public void Complete(ProjectDocument doc, string message) => Update(doc, 1, message);

    public void Complete(ProjectDocument doc, string message, string status, string summary)
    {
        lock (_sync)
        {
            _fractions[Key(doc)] = 1;
            var done = _weights.Sum(pair => pair.Value * (_fractions.TryGetValue(pair.Key, out var f) ? f : 0));
            var percent = 5 + (int)Math.Round(77.0 * done / _totalWeight);
            _progress?.Report(new AnalysisProgress
            {
                Percent = Math.Clamp(percent, 5, 82),
                Message = message,
                CurrentFile = doc.Name,
                DocumentPath = doc.Path,
                DocumentStatus = status,
                DocumentSummary = summary
            });
        }
    }

    private static string Key(ProjectDocument doc) => $"{doc.Kind}|{doc.Path}";

    private static double Weight(ProjectDocument doc)
    {
        var mb = Math.Max(0, doc.SizeBytes) / 1024.0 / 1024.0;
        return doc.Kind switch
        {
            DocumentKind.Step => Math.Clamp(7.0 + mb / 2.5, 7.0, 24.0),
            DocumentKind.Pdf => Math.Clamp(3.0 + mb / 4.0, 3.0, 8.0),
            DocumentKind.Image => 3.0,
            DocumentKind.Dwg => 2.5,
            DocumentKind.Dxf => 1.3,
            DocumentKind.Excel => 1.2,
            DocumentKind.Text => 0.8,
            _ => 0.5
        };
    }
}

public sealed class ProjectAnalysisService
{
    private readonly GeometryAnalyzer _geometry = new();
    private readonly DrawingAnalyzer _drawing = new();
    private readonly DxfAnalyzer _dxf = new();
    private readonly DwgConversionService _dwg = new();
    private readonly OfficeDocumentAnalyzer _office = new();
    private readonly HistoricalMetricReader _historicalMetricReader = new();
    private readonly CostEngine _cost = new();

    private sealed record DocumentWorkResult(
        ProjectDocument Document,
        string Status,
        string Summary,
        DrawingIntelligence? Drawing = null,
        DxfSignals? Dxf = null);

    private sealed record EngineConcurrencyProfile(
        int LightWorkers,
        int PdfDocuments,
        int PdfDocumentsBoosted,
        int OcrWorkers,
        int OcrWorkersBoosted,
        int CoreStepWorkers,
        int StepFeatureWorkers,
        int DwgWorkers,
        int CpuCount,
        double AvailableMemoryGb)
    {
        public static EngineConcurrencyProfile Detect()
        {
            var cpu = Math.Max(1, Environment.ProcessorCount);
            var memoryBytes = GC.GetGCMemoryInfo().TotalAvailableMemoryBytes;
            var memoryGb = memoryBytes > 0 ? memoryBytes / 1024.0 / 1024.0 / 1024.0 : 8.0;

            // R9.2.3D: document workers are deliberately conservative while STEP/OCP is
            // active, then expand when CAD work is absent or finished.  This avoids the
            // old fixed PDFx2/OCRx1 bottleneck without launching one worker per file.
            if (cpu <= 4 || memoryGb < 4.5)
                return new(2, 1, 2, 1, 1, 1, 1, 1, cpu, memoryGb);
            if (cpu < 8 || memoryGb < 6)
                return new(3, 2, 3, 1, 1, 1, 2, 1, cpu, memoryGb);
            if (cpu < 16 && memoryGb < 12)
                return new(4, 2, 4, 1, 2, 1, 2, 1, cpu, memoryGb);
            if (cpu < 16 || memoryGb < 24)
                return new(4, 2, 4, 1, 2, 2, 2, 1, cpu, memoryGb);
            return new(5, 3, 6, 1, 2, 2, 2, 2, cpu, memoryGb);
        }
    }

    public async Task<AnalysisResult> AnalyzeAsync(
        QuoteProject project,
        CostingSettings settings,
        CancellationToken cancellationToken = default,
        bool fastHistory = false,
        IProgress<AnalysisProgress>? progress = null)
    {
        var wallClock = Stopwatch.StartNew();
        var timings = new ConcurrentBag<EngineTimingItem>();
        var profile = EngineConcurrencyProfile.Detect();
        var geometries = new List<GeometrySummary>();
        var drawings = new List<DrawingIntelligence>();
        var dxfs = new List<DxfSignals>();
        HistoricalMetricData? embeddedHistoricalMetric = null;
        var embeddedHistorySync = new object();
        var selectedDocuments = SelectActiveRevisions(project.Documents).ToList();
        foreach (var document in selectedDocuments)
            DocumentSelectionPolicy.EnsureClassified(document);

        var tracker = new WeightedAnalysisProgress(selectedDocuments, progress);
        var noTechnicalDocuments = selectedDocuments.Where(DocumentSelectionPolicy.ShouldSkipTechnicalAnalysis).ToList();
        var externalReferenceSourcesSkipped = noTechnicalDocuments.Count(DocumentSelectionPolicy.IsExternalReferenceCorpus);
        var benchmarkSupportSourcesSkipped = noTechnicalDocuments.Count(DocumentSelectionPolicy.IsBenchmarkSupportArtifact);
        var sourceGuardSourcesSkipped = noTechnicalDocuments.Count;
        foreach (var document in noTechnicalDocuments)
        {
            document.Status = "Pominięto — brak danych technicznych";
            document.Summary = $"1.0: {document.RoleDisplay}; {document.RoleReason}";
            tracker.Complete(document, "Selekcja 1.0: plik pominięty przed kosztowną analizą", document.Status, document.Summary);
        }

        // FIX10: a byte-identical copy may remain visible for audit/revision purposes,
        // but it cannot launch another specialist or receive a second Data Fusion vote.
        var duplicateDocuments = new List<ProjectDocument>();
        var activeDocuments = selectedDocuments
            .Where(x => !noTechnicalDocuments.Contains(x))
            .GroupBy(x => string.IsNullOrWhiteSpace(x.ContentHash)
                ? $"PATH|{x.Path}"
                : $"SHA|{x.ContentHash}", StringComparer.OrdinalIgnoreCase)
            .SelectMany(group =>
            {
                var ordered = group
                    .OrderBy(x => x.IsContentDuplicate ? 1 : 0)
                    .ThenBy(x => x.RelativePath, StringComparer.OrdinalIgnoreCase)
                    .ThenBy(x => x.Name, StringComparer.OrdinalIgnoreCase)
                    .ToList();
                duplicateDocuments.AddRange(ordered.Skip(1));
                return ordered.Take(1);
            })
            .OrderBy(x => x.RelativePath, StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.Name, StringComparer.OrdinalIgnoreCase)
            .ToList();
        foreach (var duplicate in duplicateDocuments)
        {
            duplicate.Status = "Pominięto — identyczna treść";
            duplicate.Summary = "FIX10 Data Fusion: identyczny SHA-256 ma już źródło kanoniczne; brak drugiego głosu i brak ponownej analizy.";
            tracker.Complete(duplicate, "FIX10: identyczna kopia nie głosuje drugi raz", duplicate.Status, duplicate.Summary);
        }

        var parallelRun = activeDocuments.Count > 1;
        var hasStepDocuments = activeDocuments.Any(x => x.Kind == DocumentKind.Step && File.Exists(x.Path));
        var initialDocumentWorkers = hasStepDocuments ? profile.PdfDocuments : profile.PdfDocumentsBoosted;
        var stepHeavyPhase = hasStepDocuments ? 1 : 0;
        var documentBoostApplied = hasStepDocuments ? 0 : 1;
        var activeDocumentAnalyses = 0;

        using var lightGate = new SemaphoreSlim(profile.LightWorkers, profile.LightWorkers);
        using var pdfGate = new SemaphoreSlim(initialDocumentWorkers, profile.PdfDocumentsBoosted);
        using var coreStepGate = new SemaphoreSlim(profile.CoreStepWorkers, profile.CoreStepWorkers);
        using var dwgGate = new SemaphoreSlim(profile.DwgWorkers, profile.DwgWorkers);

        progress?.Report(new AnalysisProgress
        {
            Percent = 2,
            Message = $"DS 1.0 Adaptive Scheduler / Engine Profiles · CPU {profile.CpuCount} · RAM~{profile.AvailableMemoryGb:0.#} GB · " +
                      $"DOC×{initialDocumentWorkers}→{profile.PdfDocumentsBoosted}/OCR×{profile.OcrWorkers}→{profile.OcrWorkersBoosted}/STEP×{profile.StepFeatureWorkers}"
        });

        async Task<T> TimedAsync<T>(
            string engine,
            string detail,
            Func<Task<T>> action,
            Func<T, bool>? cacheDetector = null,
            bool ranInParallel = true)
        {
            var sw = Stopwatch.StartNew();
            var value = await action();
            sw.Stop();
            timings.Add(new EngineTimingItem
            {
                Engine = engine,
                Detail = detail,
                ElapsedSeconds = sw.Elapsed.TotalSeconds,
                FromCache = cacheDetector?.Invoke(value) ?? false,
                RanInParallel = ranInParallel && parallelRun
            });
            return value;
        }

        static bool DrawingFromCache(DrawingIntelligence d) =>
            d.Warnings.Any(x => x.Contains("cache:", StringComparison.OrdinalIgnoreCase));
        static bool DxfFromCache(DxfSignals d) =>
            d.Warnings.Any(x => x.Contains("cache:", StringComparison.OrdinalIgnoreCase));
        static bool GeometryFromCache(GeometrySummary g) =>
            g.Warnings.Any(x => x.Contains("Geometry cache:", StringComparison.OrdinalIgnoreCase));

        async Task<DocumentWorkResult> AnalyzeDxfOrDwgAsync(ProjectDocument doc)
        {
            if (!File.Exists(doc.Path))
                return new(doc, "Pominięto", "Plik nie istnieje",
                    new DrawingIntelligence { SourceFile = doc.Name, Warnings = [$"Pominięto brakujący plik: {doc.Name}"] });

            tracker.Update(doc, 0.05, $"Równolegle: przygotowanie {doc.Kind}");
            if (doc.Kind == DocumentKind.Dwg)
            {
                await dwgGate.WaitAsync(cancellationToken);
                try
                {
                    var converted = await TimedAsync(
                        "DWG→DXF", doc.Name,
                        () => _dwg.ConvertToDxfAsync(doc.Path, cancellationToken),
                        ranInParallel: true);
                    using (converted)
                    {
                        if (!converted.Ok || string.IsNullOrWhiteSpace(converted.DxfPath))
                        {
                            tracker.Complete(doc, "DWG zakończony z ostrzeżeniem; pozostałe silniki nadal pracują");
                            return new(doc, "Uwaga", "DWG: konwersja nieudana",
                                new DrawingIntelligence
                                {
                                    SourceFile = doc.Name,
                                    Warnings = converted.Warnings.Count > 0
                                        ? converted.Warnings.ToList()
                                        : [$"DWG {doc.Name}: konwersja do DXF nie powiodła się."]
                                });
                        }

                        var d = await TimedAsync(
                            "DXF", doc.Name,
                            () => _dxf.AnalyzeAsync(converted.DxfPath, cancellationToken),
                            DxfFromCache);
                        d.SourceFile = doc.Name;
                        ApplyCriticalSourceGuard(doc, d);
                        d.Reader = $"DWG→DXF {converted.Engine} → {d.Reader}";
                        d.Findings.Insert(0, $"DWG {doc.Name}: lokalna konwersja do DXF przez {converted.Engine}.");
                        foreach (var warning in converted.Warnings)
                            if (!d.Warnings.Contains(warning))
                                d.Warnings.Add(warning);
                        var summary = d.EntityCount > 0
                            ? $"DWG→DXF · {d.EntityCount} elementów" +
                              (d.GeometryMeasurementReliable ? $" · cięcie {d.CutLengthMm / 1000.0:0.###} m" : "")
                            : "DWG przekonwertowany, ale brak rozpoznanej geometrii";
                        tracker.Complete(doc, d.GeometryMeasurementReliable
                            ? $"DWG/DXF gotowy · cięcie {d.CutLengthMm / 1000.0:0.##} m; STEP/PDF mogą nadal pracować"
                            : "DWG/DXF gotowy; STEP/PDF mogą nadal pracować");
                        return new(doc, d.EntityCount > 0 ? "Przeanalizowany" : "Uwaga", summary, Dxf: d);
                    }
                }
                finally
                {
                    dwgGate.Release();
                }
            }

            await lightGate.WaitAsync(cancellationToken);
            try
            {
                var d = await TimedAsync(
                    "DXF", doc.Name,
                    () => _dxf.AnalyzeAsync(doc.Path, cancellationToken),
                    DxfFromCache);
                d.SourceFile = doc.Name;
                ApplyCriticalSourceGuard(doc, d);
                var summary = d.EntityCount > 0
                    ? $"{d.EntityCount} elementów · {d.Reader}" +
                      (d.ExtractedTextLength > 0 ? $" · tekst {d.ExtractedTextLength} zn." : "")
                    : "DXF: " + (!string.IsNullOrWhiteSpace(d.DiagnosticSummary)
                        ? d.DiagnosticSummary
                        : FirstWarning(d.Warnings, "0 rozpoznanych elementów"));
                var status = d.EntityCount > 0 ? "Przeanalizowany" : "Uwaga";
                tracker.Complete(doc, d.GeometryMeasurementReliable
                    ? $"DXF gotowy · cięcie {d.CutLengthMm / 1000.0:0.##} m; inne silniki pracują równolegle"
                    : "DXF gotowy; inne silniki pracują równolegle", status, summary);
                return new(doc, status, summary, Dxf: d);
            }
            finally
            {
                lightGate.Release();
            }
        }

        async Task<DocumentWorkResult> AnalyzeOfficeAsync(ProjectDocument doc)
        {
            if (!File.Exists(doc.Path))
                return new(doc, "Pominięto", "Plik nie istnieje",
                    new DrawingIntelligence { SourceFile = doc.Name, Warnings = [$"Pominięto brakujący plik: {doc.Name}"] });

            // R9.2.2: a historical costing workbook inside a project is not a BOM.
            // Read exact SSK actuals with the dedicated metric reader and keep it out
            // of technical Data Fusion so it cannot create fake parts/material rows.
            var ext = Path.GetExtension(doc.Path);
            if ((ext.Equals(".xlsx", StringComparison.OrdinalIgnoreCase) || ext.Equals(".xlsm", StringComparison.OrdinalIgnoreCase)) &&
                _historicalMetricReader.LooksLikeMetric(doc.Path))
            {
                tracker.Update(doc, 0.10, "Historia: odczyt rzeczywistych godzin SSK");
                var metric = await Task.Run(() => _historicalMetricReader.Read(doc.Path), cancellationToken);
                lock (embeddedHistorySync)
                {
                    embeddedHistoricalMetric ??= metric;
                }
                var historyDrawing = new DrawingIntelligence
                {
                    SourceFile = doc.Name,
                    ExtractedTextLength = 1,
                    Findings = [$"Metryka historyczna: odczytano {metric.SskHours.Count(x => x.Value > 0)} pozycji SSK; nie użyto jako BOM/RFQ."]
                };
                tracker.Complete(doc, $"Historia gotowa · SSK {metric.SskHours.Count(x => x.Value > 0)}; dokument wyłączony z technicznego BOM");
                return new(doc, "Historia", $"Historia SSK · {metric.SskHours.Count(x => x.Value > 0)} pozycji", historyDrawing);
            }

            await lightGate.WaitAsync(cancellationToken);
            try
            {
                tracker.Update(doc, 0.08, "Równolegle: analiza BOM / dokumentu tabelarycznego");
                var d = await TimedAsync(
                    "BOM/Tabela", doc.Name,
                    () => _office.AnalyzeAsync(doc.Path, cancellationToken),
                    DrawingFromCache);
                d.SourceFile = doc.Name;
                foreach (var bomItem in d.BomItems)
                    bomItem.SourceFile = doc.Name;
                ApplyCriticalSourceGuard(doc, d);
                var summary = d.ExtractedTextLength > 0
                    ? $"{d.ExtractedTextLength:N0} znaków · {d.Norms.Count} norm · BOM {d.BomItems.Count}"
                    : d.BomItems.Count > 0 ? $"BOM {d.BomItems.Count} pozycji" : "Nie odczytano treści";
                var status = d.ExtractedTextLength > 0 || d.BomItems.Count > 0
                    ? "Przeanalizowany"
                    : HasTimeout(d.Warnings) ? "Timeout dokumentu" : "Uwaga";
                tracker.Complete(doc, d.BomItems.Count > 0
                    ? $"BOM gotowy · {d.BomItems.Count} pozycji; STEP/PDF nadal mogą pracować"
                    : "Dokument tabelaryczny gotowy; pozostałe silniki pracują", status, summary);
                return new(doc, status, summary, d);
            }
            finally
            {
                lightGate.Release();
            }
        }

        // Start DXF/DWG and BOM immediately. PDF of the same drawing awaits only its
        // paired DXF result; it does not wait for STEP or unrelated documents.
        var nonStepTasks = new Dictionary<ProjectDocument, Task<DocumentWorkResult>>();
        var pairTasks = new Dictionary<string, Task<DocumentWorkResult>>(StringComparer.OrdinalIgnoreCase);

        foreach (var doc in activeDocuments.Where(x => x.Kind == DocumentKind.Dxf))
        {
            var task = AnalyzeDxfOrDwgAsync(doc);
            nonStepTasks[doc] = task;
            RegisterPairTask(pairTasks, doc.Name, task);
        }
        foreach (var doc in activeDocuments.Where(x => x.Kind == DocumentKind.Dwg))
        {
            var task = AnalyzeDxfOrDwgAsync(doc);
            nonStepTasks[doc] = task;
            RegisterPairTask(pairTasks, doc.Name, task);
        }
        foreach (var doc in activeDocuments.Where(x => x.Kind is DocumentKind.Excel or DocumentKind.Text))
            nonStepTasks[doc] = AnalyzeOfficeAsync(doc);

        var pdfTasks = new Dictionary<string, Task<DocumentWorkResult>>(StringComparer.OrdinalIgnoreCase);

        async Task<DocumentWorkResult> AnalyzePdfOrImageAsync(ProjectDocument doc)
        {
            if (!File.Exists(doc.Path))
                return new(doc, "Pominięto", "Plik nie istnieje",
                    new DrawingIntelligence { SourceFile = doc.Name, Warnings = [$"Pominięto brakujący plik: {doc.Name}"] });

            DxfSignals? pairedDxf = null;
            if (TryGetPairTask(pairTasks, doc.Name, out var pairTask))
            {
                tracker.Update(doc, 0.05, doc.Kind == DocumentKind.Pdf
                    ? "PDF: czekam tylko na sparowany DXF; STEP/BOM pracują równolegle"
                    : "Raster: sprawdzam najpierw sparowany DXF/PDF");
                var pair = await pairTask;
                pairedDxf = pair.Dxf;
            }

            // Source hierarchy for the SAME drawing: geometry/text DXF > PDF > raster.
            // Raster remains a fallback when the richer representation failed or lacks
            // enough technical content.  This is intentionally not a blanket TIF skip.
            if (doc.Kind == DocumentKind.Image && pairedDxf is not null &&
                pairedDxf.TotalEntities > 0 && IsRichTechnicalDxf(pairedDxf))
            {
                var hierarchy = new DrawingIntelligence { SourceFile = doc.Name };
                hierarchy.Findings.Add(
                    $"Source Hierarchy DS 1.0: pominięto OCR rastra; sparowany DXF jest bogatym źródłem " +
                    $"({pairedDxf.TotalEntities} encji / {pairedDxf.ExtractedTextLength} zn.).");
                const string summary = "Raster redundantny · użyto sparowanego DXF";
                tracker.Complete(doc, "Raster pominięty: bogaty DXF tego samego rysunku ma wyższy priorytet", "Pominięto", summary);
                return new(doc, "Pominięto", summary, hierarchy);
            }

            if (doc.Kind == DocumentKind.Image && TryGetPairTask(pdfTasks, doc.Name, out var pairedPdfTask))
            {
                var pairedPdf = await pairedPdfTask;
                if (pairedPdf.Drawing is not null && IsRichTechnicalDrawing(pairedPdf.Drawing))
                {
                    var hierarchy = new DrawingIntelligence { SourceFile = doc.Name };
                    hierarchy.Findings.Add(
                        $"Source Hierarchy DS 1.0: pominięto OCR rastra; sparowany PDF dostarczył " +
                        $"{pairedPdf.Drawing.ExtractedTextLength} zn. i wystarczające sygnały techniczne.");
                    const string summary = "Raster redundantny · użyto sparowanego PDF";
                    tracker.Complete(doc, "Raster pominięty: PDF tego samego rysunku ma wyższy priorytet", "Pominięto", summary);
                    return new(doc, "Pominięto", summary, hierarchy);
                }
            }

            await pdfGate.WaitAsync(cancellationToken);
            var activeDocsNow = Interlocked.Increment(ref activeDocumentAnalyses);
            try
            {
                tracker.Update(doc, 0.10, doc.Kind == DocumentKind.Pdf
                    ? "Równolegle: PDF / warstwa tekstowa / OCR"
                    : "Równolegle: OCR obrazu (fallback hierarchii źródeł)");
                var skipOcr = doc.Kind == DocumentKind.Pdf && pairedDxf is not null && IsRichTechnicalDxf(pairedDxf);
                var boostedPhase = Volatile.Read(ref stepHeavyPhase) == 0;
                var localOcrWorkers = boostedPhase && activeDocsNow <= 2
                    ? profile.OcrWorkersBoosted
                    : profile.OcrWorkers;
                var d = await TimedAsync(
                    doc.Kind == DocumentKind.Pdf ? "PDF/OCR" : "OCR obrazu",
                    doc.Name,
                    () => _drawing.AnalyzeAsync(doc.Path, cancellationToken, fastHistory, skipOcr, localOcrWorkers),
                    DrawingFromCache);
                if (skipOcr && pairedDxf is not null)
                    d.Findings.Add($"PDF + DXF: pominięto kosztowny OCR, ponieważ sparowany DXF zawiera bogatą warstwę tekstową ({pairedDxf.ExtractedTextLength} zn.).");
                d.SourceFile = doc.Name;
                foreach (var bomItem in d.BomItems)
                    bomItem.SourceFile = doc.Name;
                ApplyCriticalSourceGuard(doc, d);
                var usedPairedDxf = skipOcr && pairedDxf is not null;
                var summary = d.ExtractedTextLength > 0
                    ? $"{d.ExtractedTextLength:N0} znaków · {d.Norms.Count} norm"
                    : usedPairedDxf
                        ? $"Źródło zastępcze: DXF · tekst {pairedDxf!.ExtractedTextLength:N0} znaków"
                    : "PDF/OCR: " + FirstWarning(d.Warnings, "nie odczytano tekstu");
                var status = d.ExtractedTextLength > 0 || usedPairedDxf
                    ? "Przeanalizowany"
                    : HasTimeout(d.Warnings) ? "Timeout PDF/OCR" : "Uwaga";
                tracker.Complete(doc, d.ExtractedTextLength > 0
                    ? $"PDF/OCR gotowy · {d.Norms.Count} norm / {d.ExtractedTextLength:N0} znaków; STEP może nadal pracować"
                    : usedPairedDxf
                        ? "PDF gotowy · OCR celowo pominięty; użyto bogatszego sparowanego DXF"
                    : "PDF/OCR zakończony z ostrzeżeniem", status, summary);
                return new(doc, status, summary, d);
            }
            finally
            {
                Interlocked.Decrement(ref activeDocumentAnalyses);
                pdfGate.Release();
            }
        }

        // PDFs are registered before rasters so a TIF/JPG/PNG can wait for the richer
        // representation of the same drawing and avoid a second OCR pass.
        foreach (var doc in activeDocuments.Where(x => x.Kind == DocumentKind.Pdf))
        {
            var task = AnalyzePdfOrImageAsync(doc);
            nonStepTasks[doc] = task;
            RegisterPairTask(pdfTasks, doc.Name, task);
        }
        foreach (var doc in activeDocuments.Where(x => x.Kind == DocumentKind.Image))
            nonStepTasks[doc] = AnalyzePdfOrImageAsync(doc);

        foreach (var doc in activeDocuments.Where(x =>
                     x.Kind is not DocumentKind.Step and not DocumentKind.Dxf and not DocumentKind.Dwg and
                     not DocumentKind.Excel and not DocumentKind.Text and not DocumentKind.Pdf and not DocumentKind.Image))
        {
            tracker.Complete(doc, "Format zachowany w paczce; brak analizatora");
            nonStepTasks[doc] = Task.FromResult(new DocumentWorkResult(doc, "Dołączony", "Format zachowany w paczce; brak analizatora"));
        }

        async Task<int?> ResolveAuthoritativeBomItemCountAsync(
            IReadOnlyDictionary<ProjectDocument, Task<DocumentWorkResult>> work)
        {
            // Prefer explicitly named BOM/parts-list spreadsheets.  They are already
            // running in parallel with STEP, so awaiting them here normally adds no wall
            // time after a large root STEP has finished.  Historical workbooks are
            // excluded by AnalyzeOfficeAsync and therefore report zero BOM rows.
            var named = work
                .Where(x => x.Key.Kind == DocumentKind.Excel && IsAuthoritativeBomDocumentName(x.Key.Name))
                .Select(x => x.Value)
                .ToList();

            var candidates = named.Count > 0
                ? named
                : work.Where(x => x.Key.Kind == DocumentKind.Excel).Select(x => x.Value).ToList();

            var counts = new List<int>();
            foreach (var task in candidates)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var result = await task;
                var count = result.Drawing?.BomItems.Count ?? 0;
                if (count > 0)
                    counts.Add(count);
            }

            // More than one technical spreadsheet may exist.  A single dominant row
            // count is enough for the root-completeness check; use the largest parsed BOM.
            return counts.Count == 0 ? null : counts.Max();
        }

        // STEP R9.2.2B: assembly-root fast path with partial sidecar support.
        // A customer package often contains one large assembly STEP plus one standalone
        // STEP export for every unique part.  R9.2.2 still pre-scanned / fully analysed
        // many child exports before reaching the assembly, which duplicated solids and
        // made a cold run take minutes.  Detect a strongly dominant root by file size,
        // analyse it FIRST, and when its unique-group count matches the standalone export
        // count, treat the children as redundant representations of geometry already
        // analysed in the root.  In that high-confidence case no batch pre-scan is needed
        // at all -- this also makes warm-cache runs near-instant.
        var stepDocuments = activeDocuments.Where(x => x.Kind == DocumentKind.Step && File.Exists(x.Path)).ToList();
        GeometrySummary? dominantAssembly = null;
        ProjectDocument? dominantAssemblyDocument = null;
        var containedCoreTasks = new List<Task<(ProjectDocument Doc, GeometrySummary Component)>>();
        var originalStepCount = stepDocuments.Count;
        var parallelIndependentRootCount = 0;
        var largeStepPackage = originalStepCount >= 40;
        // FIX10G: after reference/library CAD has been removed, a small production STEP
        // set may spend more of the saved budget on contact/joint/surface accuracy.
        var priorityAccurateStepSet = !fastHistory && originalStepCount > 0 && originalStepCount <= 24;
        var assemblyRootFastPathHandled = false;

        var strongAssemblyRoot = SelectStrongAssemblyRoot(stepDocuments);
        if (strongAssemblyRoot is not null)
        {
            tracker.Update(strongAssemblyRoot, 0.10, "STEP: najpierw główne złożenie (Assembly Root Fast Path R9.2.2)");
            var rootGeometry = await TimedAsync(
                "STEP pełny", strongAssemblyRoot.Name,
                () => _geometry.AnalyzeAsync(
                    strongAssemblyRoot.Path, cancellationToken, fastHistory, coreOnly: false,
                    stepWorkers: profile.StepFeatureWorkers,
                    progress: (pct, message) => tracker.Update(strongAssemblyRoot, 0.08 + 0.88 * pct / 100.0, message),
                    priorityAccurate: priorityAccurateStepSet),
                GeometryFromCache,
                ranInParallel: true);

            geometries.Add(rootGeometry);
            strongAssemblyRoot.Summary = rootGeometry.Available
                ? $"{rootGeometry.SolidCount} brył · {rootGeometry.UniquePartGroups} grup · {rootGeometry.TotalHoleCount} otworów" +
                  (rootGeometry.ReusedSolidAnalyses > 0 ? $" · cache instancji {rootGeometry.ReusedSolidAnalyses}" : "")
                : "STEP: " + FirstWarning(rootGeometry.Warnings, "brak użytecznej geometrii");
            strongAssemblyRoot.Status = rootGeometry.Available
                ? rootGeometry.WatchdogTriggered ? "Uwaga" : "Przeanalizowany"
                : rootGeometry.WatchdogTriggered || string.Equals(rootGeometry.AnalysisMode, "timeout", StringComparison.OrdinalIgnoreCase)
                    ? "Timeout STEP"
                    : "Uwaga";
            tracker.Complete(strongAssemblyRoot, rootGeometry.Available
                ? $"STEP głównego złożenia gotowy · {rootGeometry.SolidCount} brył / {rootGeometry.UniquePartGroups} grup"
                : "STEP głównego złożenia zakończony z ostrzeżeniem");

            if (rootGeometry.Available && rootGeometry.SolidCount > 1)
            {
                dominantAssembly = rootGeometry;
                dominantAssemblyDocument = strongAssemblyRoot;
            }

            // R9.2.2B: when the package also contains an authoritative BOM workbook,
            // use its row count to confirm that the root assembly already represents the
            // complete project.  Sidecar STEP exports may be only a SUBSET of the root
            // groups (e.g. 100 of 220 or 60 of 350); requiring a 1:1 child/group count
            // caused those sidecars to be analysed and added a second time.
            var authoritativeBomItemCount = await ResolveAuthoritativeBomItemCountAsync(nonStepTasks);

            if (CanUseAssemblyRootFastPath(strongAssemblyRoot, rootGeometry, stepDocuments, authoritativeBomItemCount))
            {
                var skipped = 0;
                foreach (var child in stepDocuments.Where(x => !ReferenceEquals(x, strongAssemblyRoot)))
                {
                    child.Status = "Przeanalizowany";
                    child.Summary = "STEP składnika · użyto pełnej geometrii głównego złożenia; pominięto redundantny pre-scan/CORE i bez dublowania masy";
                    tracker.Complete(child, "STEP składnika: geometria już policzona w głównym złożeniu");
                    skipped++;
                }

                rootGeometry.Warnings.Add(
                    $"Assembly Root Fast Path R9.2.2B: główne złożenie {strongAssemblyRoot.Name} zawiera " +
                    $"{rootGeometry.SolidCount} brył / {rootGeometry.UniquePartGroups} unikalnych grup; " +
                    (authoritativeBomItemCount.HasValue
                        ? $"BOM potwierdza {authoritativeBomItemCount.Value} pozycji; "
                        : "") +
                    $"pominięto {skipped} redundantnych eksportów STEP (pełny zestaw lub podzbiór) bez batch pre-scan i bez ponownego OCP.");
                assemblyRootFastPathHandled = true;
            }
            else
            {
                // Root has already been analysed.  Only the unresolved remainder needs
                // pre-scan/classification; never analyse the root a second time.
                stepDocuments = stepDocuments
                    .Where(x => !ReferenceEquals(x, strongAssemblyRoot))
                    .ToList();
            }
        }

        if (!assemblyRootFastPathHandled)
        {
            // FIX10: probe the FULL geometry cache first. A warm full result is already
            // richer than pre-scan, so scheduling another Python/OCP pre-scan would only
            // waste time. Only genuinely unresolved files enter the batch pre-scan.
            var stepPrescans = new Dictionary<string, GeometrySummary>(StringComparer.OrdinalIgnoreCase);
            var fullCachedSteps = new Dictionary<string, GeometrySummary>(StringComparer.OrdinalIgnoreCase);
            foreach (var stepDoc in stepDocuments)
            {
                var fullCached = await _geometry.TryReadFullCacheAsync(
                    stepDoc.Path, cancellationToken, fastHistory, coreOnly: false,
                    priorityAccurate: priorityAccurateStepSet);
                if (fullCached is not null)
                {
                    fullCachedSteps[stepDoc.Path] = fullCached;
                    stepPrescans[stepDoc.Path] = fullCached;
                    tracker.Update(stepDoc, 0.06, "STEP: pełny wynik jest w cache — pomijam pre-scan");
                }
            }

            var unresolvedPreScan = stepDocuments
                .Where(x => !stepPrescans.ContainsKey(x.Path))
                .ToList();

            // FIX10J: for a small ambiguous package with 2-4 top-level STEP files, a
            // serial batch pre-scan followed by serial watchdogs created the worst
            // possible cold path (e.g. ~60 s + 300 s + 300 s). On machines that can
            // safely host two native CAD workers, start the full analyses directly and
            // resolve containment AFTER both results return. This preserves correctness
            // while removing a redundant pre-scan from the common multi-root case.
            var directParallelMultiRoot = dominantAssembly is null &&
                                          unresolvedPreScan.Count is >= 2 and <= 4 &&
                                          unresolvedPreScan.Count == stepDocuments.Count &&
                                          profile.CoreStepWorkers >= 2;
            if (unresolvedPreScan.Count > 1 && !directParallelMultiRoot)
            {
                foreach (var stepDoc in unresolvedPreScan)
                    tracker.Update(stepDoc, 0.02, $"Równolegle: batch pre-scan STEP 0/{unresolvedPreScan.Count}");
                // R9.2 compatibility + FIX10: non-STEP tasks are already running before
                // this task is created. Keep the batch task explicit so the release gate can
                // verify that DXF/BOM scheduling still precedes STEP pre-scan.
                Task<Dictionary<string, GeometrySummary>>? batchPreScanTask = TimedAsync(
                    "STEP pre-scan", $"{unresolvedPreScan.Count} plików",
                    () => _geometry.PreScanBatchAsync(unresolvedPreScan.Select(x => x.Path).ToList(), cancellationToken),
                    ranInParallel: true);
                var batch = await batchPreScanTask;
                foreach (var pair in batch)
                    stepPrescans[pair.Key] = pair.Value;
            }

            if (stepDocuments.Count > 1)
            {
                // Fallbacks are only for the largest unresolved files and stay strictly
                // bounded.  They must never become one Python/OCP launch per child STEP.
                var missingScans = stepDocuments
                    .Where(x => !stepPrescans.ContainsKey(x.Path))
                    .OrderByDescending(x => x.SizeBytes)
                    .ToList();
                var fallbackBudget = originalStepCount >= 40
                    ? Math.Min(3, missingScans.Count)
                    : originalStepCount >= 16
                        ? Math.Min(8, missingScans.Count)
                        : missingScans.Count;

                for (var i = 0; i < fallbackBudget; i++)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    var stepDoc = missingScans[i];
                    var scan = await TimedAsync(
                        "STEP pre-scan fallback", stepDoc.Name,
                        () => _geometry.PreScanAsync(stepDoc.Path, cancellationToken),
                        ranInParallel: true);
                    if (scan.Available || GeometryAnalyzer.IsDeterministicUnavailable(scan))
                        stepPrescans[stepDoc.Path] = scan;
                }

                foreach (var stepDoc in stepDocuments)
                    tracker.Update(stepDoc, 0.06, "Batch pre-scan STEP zakończony");
            }

            // If no assembly root was selected up-front, prioritize multi-solid / large
            // candidates.  File size is the tie-breaker so a failed pre-scan can no longer
            // push the real assembly behind hundreds of tiny child files.
            stepDocuments = stepDocuments
                .OrderByDescending(x => stepPrescans.TryGetValue(x.Path, out var scan) && scan.Available ? scan.SolidCount : 0)
                .ThenByDescending(x => stepPrescans.TryGetValue(x.Path, out var scan) && scan.Available ? scan.UniquePartGroups : 0)
                .ThenByDescending(x => x.SizeBytes)
                .ThenBy(x => x.Name, StringComparer.OrdinalIgnoreCase)
                .ToList();

            // FIX10I real-world multi-root scheduling. Two to four top-level STEP files
            // that are all available in pre-scan and are pairwise NOT contained in each
            // other are independent roots. Analyse at most two external OCP processes in
            // parallel instead of awaiting each 300/420-second watchdog serially. Each
            // process gets one feature worker to keep native-kernel RAM/CPU contention bounded.
            var parallelIndependentFull = new Dictionary<string, GeometrySummary>(StringComparer.OrdinalIgnoreCase);
            var parallelContainedByRoot = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var parallelRootCandidates = stepDocuments
                .Where(x => !fullCachedSteps.ContainsKey(x.Path) &&
                            (directParallelMultiRoot ||
                             (stepPrescans.TryGetValue(x.Path, out var sc) && sc.Available)))
                .ToList();
            var parallelRootsEligible = dominantAssembly is null &&
                                        parallelRootCandidates.Count is >= 2 and <= 4 &&
                                        parallelRootCandidates.Count == stepDocuments.Count &&
                                        profile.CoreStepWorkers >= 2;

            // When pre-scan already exists, it can cheaply prove containment before
            // launching redundant full work. In FIX10J direct mode there is deliberately
            // no pre-scan: both roots are analysed together and containment is resolved
            // from the richer full/checkpoint results afterwards.
            if (parallelRootsEligible && !directParallelMultiRoot)
            {
                for (var i = 0; i < parallelRootCandidates.Count && parallelRootsEligible; i++)
                for (var j = i + 1; j < parallelRootCandidates.Count && parallelRootsEligible; j++)
                {
                    var a = stepPrescans[parallelRootCandidates[i].Path];
                    var b = stepPrescans[parallelRootCandidates[j].Path];
                    if (IsContainedInAssembly(a, b) || IsContainedInAssembly(b, a))
                        parallelRootsEligible = false;
                }
            }

            if (parallelRootsEligible)
            {
                using var independentRootGate = new SemaphoreSlim(Math.Min(2, parallelRootCandidates.Count));
                var independentTasks = parallelRootCandidates.Select(async doc =>
                {
                    await independentRootGate.WaitAsync(cancellationToken);
                    try
                    {
                        tracker.Update(doc, 0.10, "1.0: główny STEP — równoległa pełna analiza");
                        var g = await TimedAsync(
                            "STEP pełny", doc.Name,
                            () => _geometry.AnalyzeAsync(
                                doc.Path, cancellationToken, fastHistory, coreOnly: false,
                                stepWorkers: 1,
                                progress: (pct, message) => tracker.Update(doc, 0.08 + 0.88 * pct / 100.0, message),
                                priorityAccurate: priorityAccurateStepSet),
                            GeometryFromCache,
                            ranInParallel: true);
                        return (Doc: doc, Geometry: g);
                    }
                    finally
                    {
                        independentRootGate.Release();
                    }
                }).ToList();

                var independentResults = await Task.WhenAll(independentTasks);
                foreach (var item in independentResults.OrderBy(x => x.Doc.Name, StringComparer.OrdinalIgnoreCase))
                    parallelIndependentFull[item.Doc.Path] = item.Geometry;

                // Full results are authoritative enough to resolve a real assembly +
                // child sidecar relation without double-counting. Analyse concurrently
                // for wall-clock speed, then deterministically suppress only proven
                // contained geometry during aggregation.
                var orderedParallel = independentResults
                    .Where(x => x.Geometry.Available)
                    .OrderByDescending(x => x.Geometry.SolidCount)
                    .ThenByDescending(x => x.Geometry.VolumeMm3)
                    .ThenBy(x => x.Doc.Name, StringComparer.OrdinalIgnoreCase)
                    .ToList();
                for (var i = 0; i < orderedParallel.Count; i++)
                for (var j = i + 1; j < orderedParallel.Count; j++)
                {
                    var root = orderedParallel[i];
                    var child = orderedParallel[j];
                    if (parallelContainedByRoot.ContainsKey(child.Doc.Path))
                        continue;
                    if (!IsContainedInAssembly(child.Geometry, root.Geometry))
                        continue;
                    parallelContainedByRoot[child.Doc.Path] = root.Doc.Path;
                    root.Geometry.Warnings.Add(
                        $"Assembly Root 1.0: {child.Doc.Name} przeanalizowano równolegle, następnie potwierdzono zawartość w {root.Doc.Name}; geometria składnika nie jest sumowana drugi raz.");
                }
                parallelIndependentRootCount = parallelIndependentFull.Count - parallelContainedByRoot.Count;
            }

            foreach (var doc in stepDocuments)
            {
                cancellationToken.ThrowIfCancellationRequested();

                // FIX10D determinism guard: a FULL cached result is authoritative for the
                // same file and must never be demoted later to "STEP składnika" merely
                // because its geometry also fits another assembly pre-scan.
                if (fullCachedSteps.TryGetValue(doc.Path, out var cachedFull))
                {
                    geometries.Add(cachedFull);
                    doc.Summary = cachedFull.Available
                        ? $"{cachedFull.SolidCount} brył · {cachedFull.UniquePartGroups} grup · {cachedFull.TotalHoleCount} otworów · CACHE FULL"
                        : "STEP: " + FirstWarning(cachedFull.Warnings, "zapamiętany brak użytecznej geometrii");
                    doc.Status = cachedFull.Available
                        ? cachedFull.WatchdogTriggered ? "Uwaga" : "Przeanalizowany"
                        : cachedFull.WatchdogTriggered || string.Equals(cachedFull.AnalysisMode, "timeout", StringComparison.OrdinalIgnoreCase)
                            ? "Timeout STEP"
                            : "Uwaga";
                    tracker.Complete(doc, cachedFull.Available
                        ? "STEP: użyto pełnego wyniku cache bez ponownego pre-scan/containment"
                        : "STEP: użyto zapamiętanej diagnostyki pełnej analizy");
                    if (cachedFull.Available && cachedFull.SolidCount > 1 &&
                        (dominantAssembly is null || cachedFull.VolumeMm3 > dominantAssembly.VolumeMm3))
                    {
                        dominantAssembly = cachedFull;
                        dominantAssemblyDocument = doc;
                    }
                    continue;
                }

                if (stepPrescans.TryGetValue(doc.Path, out var unavailableScan) &&
                    GeometryAnalyzer.IsDeterministicUnavailable(unavailableScan))
                {
                    geometries.Add(unavailableScan);
                    var invalidPlaceholder = unavailableScan.Warnings.Any(x =>
                        x.Contains("Git LFS", StringComparison.OrdinalIgnoreCase) ||
                        x.Contains("pustym plikiem", StringComparison.OrdinalIgnoreCase));
                    doc.Status = invalidPlaceholder ? "Błąd" : "Uwaga";
                    doc.Summary = "STEP: " + FirstWarning(unavailableScan.Warnings, "brak zamkniętych brył SOLID");
                    tracker.Complete(doc, invalidPlaceholder
                        ? "STEP odrzucony: plik nie zawiera modelu CAD"
                        : "STEP pominięty: brak zamkniętych brył; użyto zapamiętanej diagnostyki");
                    continue;
                }

                if (parallelIndependentFull.TryGetValue(doc.Path, out var parallelGeometry))
                {
                    if (parallelContainedByRoot.TryGetValue(doc.Path, out var rootPath))
                    {
                        var rootName = stepDocuments.FirstOrDefault(x =>
                            string.Equals(x.Path, rootPath, StringComparison.OrdinalIgnoreCase))?.Name ?? Path.GetFileName(rootPath);
                        doc.Status = "Przeanalizowany";
                        doc.Summary = $"STEP składnika · przeanalizowany równolegle i potwierdzony w {rootName}; bez dublowania masy";
                        tracker.Complete(doc, $"1.0: STEP składnika zawarty w {rootName}; wynik nie jest sumowany drugi raz");
                        continue;
                    }
                    geometries.Add(parallelGeometry);
                    doc.Summary = parallelGeometry.Available
                        ? $"{parallelGeometry.SolidCount} brył · {parallelGeometry.UniquePartGroups} grup · {parallelGeometry.TotalHoleCount} otworów" +
                          (parallelGeometry.ReusedSolidAnalyses > 0 ? $" · cache instancji {parallelGeometry.ReusedSolidAnalyses}" : "")
                        : "STEP: " + FirstWarning(parallelGeometry.Warnings, "brak użytecznej geometrii");
                    doc.Status = parallelGeometry.Available
                        ? parallelGeometry.WatchdogTriggered ? "Uwaga" : "Przeanalizowany"
                        : parallelGeometry.WatchdogTriggered || string.Equals(parallelGeometry.AnalysisMode, "timeout", StringComparison.OrdinalIgnoreCase)
                            ? "Timeout STEP"
                            : "Uwaga";
                    tracker.Complete(doc, parallelGeometry.Available
                        ? $"FIX10I STEP równoległy gotowy · {parallelGeometry.SolidCount} brył / {parallelGeometry.UniquePartGroups} grup"
                        : "FIX10I STEP równoległy zakończony z ostrzeżeniem");
                    continue;
                }

                if (dominantAssembly is not null)
                {
                    var hasScan = stepPrescans.TryGetValue(doc.Path, out var stepScan) && stepScan.Available;
                    if (hasScan && IsContainedInAssembly(stepScan!, dominantAssembly))
                    {
                        if (dominantAssembly.UniquePartGroups > 0 &&
                            dominantAssembly.FullyAnalyzedUniqueSolids >= dominantAssembly.UniquePartGroups)
                        {
                            var identified = EnrichAssemblyIdentityFromContainedPreScan(dominantAssembly, stepScan!, doc.Name);
                            doc.Status = "Przeanalizowany";
                            doc.Summary = $"STEP składnika · rozpoznano w pełnym złożeniu · dopasowano {identified} grup; bez ponownego CORE i bez dublowania masy";
                            dominantAssembly.Warnings.Add(
                                $"Assembly Root R9.2.2: {doc.Name} dopasowano z pre-scan do pełnego złożenia; pominięto redundantny STEP CORE ({identified} grup)." );
                            tracker.Complete(doc, $"STEP składnika użył analizy głównego złożenia · {identified} grup");
                            continue;
                        }

                        containedCoreTasks.Add(Task.Run(async () =>
                        {
                            await coreStepGate.WaitAsync(cancellationToken);
                            try
                            {
                                tracker.Update(doc, 0.12, "STEP składnika: CORE tylko gdy złożenie nie ma pełnych cech");
                                var component = await TimedAsync(
                                    "STEP CORE", doc.Name,
                                    () => _geometry.AnalyzeAsync(
                                        doc.Path, cancellationToken, fastHistory, coreOnly: true,
                                        stepWorkers: Math.Min(2, profile.StepFeatureWorkers),
                                        progress: (pct, message) => tracker.Update(doc, 0.10 + 0.82 * pct / 100.0, message)),
                                    GeometryFromCache,
                                    ranInParallel: true);
                                return (doc, component);
                            }
                            finally
                            {
                                coreStepGate.Release();
                            }
                        }, cancellationToken));
                        continue;
                    }

                    if (!hasScan && largeStepPackage && dominantAssemblyDocument is not null &&
                        dominantAssembly.UniquePartGroups > 0 &&
                        dominantAssembly.FullyAnalyzedUniqueSolids >= dominantAssembly.UniquePartGroups)
                    {
                        var knownComponentScans = stepDocuments
                            .Where(x => !ReferenceEquals(x, dominantAssemblyDocument) &&
                                        stepPrescans.TryGetValue(x.Path, out var sc) && sc.Available)
                            .Select(x => stepPrescans[x.Path])
                            .ToList();
                        var containedKnown = knownComponentScans.Count(x => IsContainedInAssembly(x, dominantAssembly));
                        var containedRatio = knownComponentScans.Count == 0 ? 0 : containedKnown / (double)knownComponentScans.Count;
                        var smallRelativeToAssembly = doc.SizeBytes <= Math.Max(1_000_000, dominantAssemblyDocument.SizeBytes * 0.25);
                        if (knownComponentScans.Count >= 5 && containedRatio >= 0.75 && smallRelativeToAssembly)
                        {
                            doc.Status = "Przeanalizowany";
                            doc.Summary = "STEP składnika · pominięto redundantną analizę w dużej paczce; pełne cechy pochodzą z głównego złożenia";
                            dominantAssembly.Warnings.Add(
                                $"Assembly Root R9.2.2: {doc.Name} bez wyniku batch pre-scan; pominięto osobny OCP, ponieważ {containedKnown}/{knownComponentScans.Count} sprawdzonych plików składników należy do dominującego złożenia." );
                            tracker.Complete(doc, "STEP składnika: użyto pełnej geometrii głównego złożenia");
                            continue;
                        }
                    }
                }

                tracker.Update(doc, 0.10, "STEP: pełna analiza; PDF/DXF/BOM pracują równolegle");
                var g = await TimedAsync(
                    "STEP pełny", doc.Name,
                    () => _geometry.AnalyzeAsync(
                        doc.Path, cancellationToken, fastHistory, coreOnly: false,
                        stepWorkers: profile.StepFeatureWorkers,
                        progress: (pct, message) => tracker.Update(doc, 0.08 + 0.88 * pct / 100.0, message),
                        priorityAccurate: priorityAccurateStepSet),
                    GeometryFromCache,
                    ranInParallel: true);
                geometries.Add(g);
                doc.Summary = g.Available
                    ? $"{g.SolidCount} brył · {g.UniquePartGroups} grup · {g.TotalHoleCount} otworów" +
                      (g.ReusedSolidAnalyses > 0 ? $" · cache instancji {g.ReusedSolidAnalyses}" : "")
                    : "STEP: " + FirstWarning(g.Warnings, "brak użytecznej geometrii");
                doc.Status = g.Available
                    ? g.WatchdogTriggered ? "Uwaga" : "Przeanalizowany"
                    : g.WatchdogTriggered || string.Equals(g.AnalysisMode, "timeout", StringComparison.OrdinalIgnoreCase)
                        ? "Timeout STEP"
                        : "Uwaga";
                tracker.Complete(doc, g.Available
                    ? $"STEP gotowy · {g.SolidCount} brył / {g.UniquePartGroups} grup; składanie pozostałych wyników"
                    : "STEP zakończony z ostrzeżeniem");

                if (g.Available && g.SolidCount > 1 &&
                    (dominantAssembly is null || g.VolumeMm3 > dominantAssembly.VolumeMm3))
                {
                    dominantAssembly = g;
                    dominantAssemblyDocument = doc;
                }
            }

            if (containedCoreTasks.Count > 0)
            {
                var coreResults = await Task.WhenAll(containedCoreTasks);
                foreach (var (doc, component) in coreResults)
                {
                    if (component.Available && dominantAssembly is not null)
                    {
                        var enriched = EnrichAssemblyFromContainedStep(dominantAssembly, component, doc.Name);
                        doc.Status = "Przeanalizowany";
                        doc.Summary = $"STEP składnika · {component.SolidCount} brył · {component.TotalHoleCount} otworów · wzbogacono {enriched} grup; bez dublowania masy";
                        dominantAssembly.Warnings.Add(
                            $"Parallel Assembly: {doc.Name} przeanalizowano CORE i użyto do wzbogacenia {enriched} grup; masy/brył nie doliczono drugi raz.");
                        tracker.Complete(doc, $"STEP CORE gotowy · wzbogacono {enriched} grup złożenia");
                    }
                    else
                    {
                        doc.Status = "Uwaga";
                        doc.Summary = "STEP składnika: analiza CORE nie zwróciła użytecznej geometrii";
                        tracker.Complete(doc, "STEP CORE zakończony z ostrzeżeniem");
                    }
                }
            }
        }

        // STEP/OCP no longer needs the conservative document cap.  Release extra
        // permits once, so waiting PDF/image jobs immediately consume otherwise idle
        // CPU. Packages without STEP started at the boosted cap from the beginning.
        if (hasStepDocuments)
        {
            Interlocked.Exchange(ref stepHeavyPhase, 0);
            if (Interlocked.Exchange(ref documentBoostApplied, 1) == 0)
            {
                var extra = Math.Max(0, profile.PdfDocumentsBoosted - profile.PdfDocuments);
                if (extra > 0)
                    pdfGate.Release(extra);
                progress?.Report(new AnalysisProgress
                {
                    Percent = 80,
                    Message = $"Adaptive Scheduler: STEP zakończony · dokumenty DOC×{profile.PdfDocuments}→{profile.PdfDocumentsBoosted}"
                });
            }
        }

        // Collect the non-STEP engines. Most of them have already finished while STEP ran.
        if (nonStepTasks.Count > 0)
        {
            var nonStepResults = await Task.WhenAll(nonStepTasks.Values);
            foreach (var item in nonStepResults)
            {
                item.Document.Status = item.Status;
                item.Document.Summary = item.Summary;
                if (item.Drawing is not null)
                    drawings.Add(item.Drawing);
                if (item.Dxf is not null)
                {
                    dxfs.Add(item.Dxf);
                    if (HasDxfDrawingSignals(item.Dxf))
                        drawings.Add(DrawingFromDxf(item.Document.Name, item.Dxf));
                }
            }
        }

        // Include STEP documents that were missing on disk in diagnostics/progress.
        foreach (var doc in activeDocuments.Where(x => x.Kind == DocumentKind.Step && !File.Exists(x.Path)))
        {
            doc.Status = "Pominięto";
            doc.Summary = "Plik nie istnieje";
            drawings.Add(new DrawingIntelligence { SourceFile = doc.Name, Warnings = [$"Pominięto brakujący plik: {doc.Name}"] });
            tracker.Complete(doc, "Pominięto brakujący STEP");
        }

        progress?.Report(new AnalysisProgress { Percent = 84, Message = "Data Fusion: łączenie wyników PDF/DXF/STEP/BOM…" });
        var fusionSw = Stopwatch.StartNew();
        geometries = geometries.OrderBy(x => x.Parts.FirstOrDefault()?.SourceFile ?? "", StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.SolidCount).ThenBy(x => x.VolumeMm3).ToList();
        drawings = drawings.OrderBy(x => x.SourceFile, StringComparer.OrdinalIgnoreCase).ToList();
        dxfs = dxfs.OrderBy(x => x.SourceFile, StringComparer.OrdinalIgnoreCase).ToList();
        var geometry = MergeGeometry(geometries);

        // FIX12D: resolve the authoritative root parts-list before project-wide
        // Data Fusion. Foreign drawing-number families stay visible in the package
        // audit, but cannot silently alter the quoted assembly's material/weld/cut.
        var familyResolution = DocumentFamilyResolver.Resolve(drawings, dxfs, activeDocuments);
        var drawingsForFusion = familyResolution.HasAuthoritativeRootBom && familyResolution.ScopeEnforced
            ? drawings.Where(x => familyResolution.Allows(x.SourceFile) || DocumentFamilyResolver.IsAuthoritativeBomSource(x.SourceFile)).ToList()
            : drawings;
        var dxfsForFusion = familyResolution.HasAuthoritativeRootBom && familyResolution.ScopeEnforced
            ? dxfs.Where(x => familyResolution.Allows(x.SourceFile)).ToList()
            : dxfs;

        var drawing = MergeDrawings(drawingsForFusion);
        // FIX30: audit-only. Match only already verified PDF↔BOM IDs to
        // unique, existing active STEP filenames. No geometric/cost authority.
        var stepEvidence = DrawingStepEvidenceResolver.Resolve(drawing.DrawingBomLinks, activeDocuments);
        drawing.DrawingStepLinks = stepEvidence.Links;
        drawing.DrawingStepAmbiguousNumbers = stepEvidence.AmbiguousIdentifiers;
        drawing.ResolvedRootEntityKey = familyResolution.RootEntityKey;
        drawing.ResolvedRootBomFamilyCount = familyResolution.RootBomFamilyCount;
        drawing.ResolvedFamilyScopeEnforced = familyResolution.ScopeEnforced;
        drawing.ResolvedStepFamilyCount = familyResolution.StepFamilyCount;
        drawing.ResolvedStepFamilyMatchCount = familyResolution.StepFamilyMatchCount;
        drawing.ResolvedDxfFamilyCount = familyResolution.DxfFamilyCount;
        drawing.ResolvedDxfFamilyMatchCount = familyResolution.DxfFamilyMatchCount;
        drawing.StepGeometryProjectCoveragePartial = familyResolution.StepCoveragePartial;
        drawing.DxfScopeLimited = familyResolution.DxfScopeLimited;
        drawing.ResolvedProductionFamilies = familyResolution.ProductionFamilies.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).Take(1000).ToList();
        if (familyResolution.HasAuthoritativeRootBom)
        {
            drawing.Findings.Add(
                $"FIX12D Family Resolver: root {familyResolution.RootEntityKey}; BOM {familyResolution.RootBomFamilyCount} rodzin; " +
                $"STEP {familyResolution.StepFamilyMatchCount}/{familyResolution.StepFamilyCount}; DXF {familyResolution.DxfFamilyMatchCount}/{familyResolution.DxfFamilyCount}; " +
                $"scope {(familyResolution.ScopeEnforced ? "ENFORCED" : "AUDIT_ONLY")}; wyłączono z globalnego Data Fusion " +
                $"{familyResolution.ExcludedDrawingCount} obcych rodzin dokumentów i {familyResolution.ExcludedDxfCount} DXF.");
            if (familyResolution.StepCoveragePartial)
                drawing.Warnings.Add(
                    $"FIX12D: STEP pokrywa tylko {familyResolution.StepFamilyMatchCount} z {familyResolution.RootBomFamilyCount} rodzin głównego BOM. " +
                    "Masa z dostępnych STEP jest masą częściową i nie może być automatycznie ceną/masą całego projektu.");
        }

        ApplySurfacePreparationGuard(drawing, drawingsForFusion, activeDocuments);
        if (duplicateDocuments.Count > 0)
            drawing.Findings.Add($"FIX10 Protected Data Fusion: odrzucono {duplicateDocuments.Count} dodatkowych głosów identycznej treści SHA-256; aliasy pozostają widoczne w audycie.");
        GuardUnscopedBomMaterial(drawing, drawingsForFusion, activeDocuments);
        ApplyHoleSemantics(geometry, drawing);
        var bomQuantitiesByFamily = BuildBomQuantityMap(drawing.BomItems);
        if (!geometry.Available && bomQuantitiesByFamily.Count > 0)
            ApplyBomQuantitiesTo2dDrawing(drawingsForFusion, drawing, bomQuantitiesByFamily);
        var dxf = MergeDxf(dxfsForFusion, bomQuantitiesByFamily);
        if (bomQuantitiesByFamily.Count > 0)
            drawing.Findings.Add($"BOM quantity routing 2D: zastosowano ilości produkcyjne dla {bomQuantitiesByFamily.Count} rodzin dokumentów przy cięciu/otworach 2D.");

        // FIX12E: a complete coating area must not depend on one complete STEP.
        // Reconstruct it per root-BOM family from local STEP / DXF / BOM evidence.
        HybridSurfaceAreaResolver.Apply(drawing, geometry, drawingsForFusion, dxfsForFusion, familyResolution);
        // FIX14: reconstruct mass independently from surface. A partial STEP can still
        // contribute local volumes, while BOM/DXF/document masses fill other families.
        HybridMassResolver.Apply(drawing, geometry, drawingsForFusion, dxfsForFusion, familyResolution);

        var package = AnalyzePackage(project.Documents.Where(x => !x.ExcludeFromAnalysis).ToList());
        package.MultiRootDecision = project.MultiRootDecision?.Trim().ToUpperInvariant() ?? "";
        fusionSw.Stop();
        timings.Add(new EngineTimingItem
        {
            Engine = "Data Fusion", Detail = $"{activeDocuments.Count} dokumentów",
            ElapsedSeconds = fusionSw.Elapsed.TotalSeconds, RanInParallel = false
        });

        progress?.Report(new AnalysisProgress { Percent = 90, Message = "Cost Engine: budowanie procesu i kosztów…" });
        var costSw = Stopwatch.StartNew();
        var result = _cost.Build(
            geometry,
            drawing,
            dxf,
            project.ManualWeightKg,
            settings,
            package);
        costSw.Stop();
        timings.Add(new EngineTimingItem
        {
            Engine = "Cost Engine", Detail = "model technologiczny",
            ElapsedSeconds = costSw.Elapsed.TotalSeconds, RanInParallel = false
        });

        if (embeddedHistoricalMetric is not null)
            ApplyEmbeddedHistoricalMetric(project, result, embeddedHistoricalMetric);

        result.AssemblyTree = AssemblyHierarchyEngine.Build(project, result);
        var qtyMismatch = result.AssemblyTree.Where(x => x.QuantityMismatch).Take(10).ToList();
        if (qtyMismatch.Count > 0)
        {
            result.Risks.Add(new RiskItem
            {
                Code = "BOM_QUANTITY_MISMATCH",
                Level = RiskLevel.High,
                Title = "Ilości BOM różnią się od modelu STEP",
                Message = $"Wykryto {result.AssemblyTree.Count(x => x.QuantityMismatch)} dopasowanych pozycji z różną ilością. " +
                          string.Join("; ", qtyMismatch.Select(x => $"{x.Name}: STEP ×{x.GeometryQuantity:0.###}, BOM ×{x.Quantity:0.###}")) +
                          ". Program nie mnoży kosztu po cichu, żeby nie podwajać ilości z poprawnego złożenia.",
                Blocking = false
            });
            result.ConfidencePercent = Math.Max(15, result.ConfidencePercent - 8);
            result.ReadinessPercent = Math.Max(10, result.ReadinessPercent - 10);
            AutoQuoteEngine.Apply(result);
        }

        // FIX10 keeps Evidence Orchestrator explainable, but duplicate/source
        // protection now happens BEFORE Data Fusion and Cost Engine. The evidence
        // pass records the canonical result plus all visible aliases for audit.
        progress?.Report(new AnalysisProgress
        {
            Percent = 93,
            Message = "DS Evidence Orchestrator FIX10: chroniony konsensus i ścieżki źródeł…"
        });
        var evidenceSw = Stopwatch.StartNew();
        result.Evidence = EvidenceOrchestrator.Build(
            project,
            geometries,
            drawingsForFusion,
            dxfsForFusion,
            result);
        evidenceSw.Stop();
        timings.Add(new EngineTimingItem
        {
            Engine = "DS Evidence Orchestrator FIX10",
            Detail = result.Evidence.Summary,
            ElapsedSeconds = evidenceSw.Elapsed.TotalSeconds,
            RanInParallel = false
        });
        result.Drawing.Findings.Add(
            $"DS Evidence Orchestrator FIX10 ({result.Evidence.Mode}): {result.Evidence.Summary}. " +
            "Identyczna treść ma najwyżej jeden głos przed Cost Engine; aliasy i konflikty pozostają audytowalne.");

        // FIX12A: dual-run / shadow CAPP pipeline. It consumes the stable FIX11 result
        // after Evidence Orchestration and builds a stateful technology graph only for
        // audit. It has no price authority and cannot mutate CostEngine/AutoQuote values.
        var shadowSw = Stopwatch.StartNew();
        result.ShadowTechnologyGraph = AssemblyStateGraphBuilder.Build(project, result);
        shadowSw.Stop();
        timings.Add(new EngineTimingItem
        {
            Engine = "FIX12A Shadow Technology Graph",
            Detail = result.ShadowTechnologyGraph.Summary,
            ElapsedSeconds = shadowSw.Elapsed.TotalSeconds,
            RanInParallel = false
        });
        result.Drawing.Findings.Add(
            $"FIX12A Shadow Pipeline: {result.ShadowTechnologyGraph.Summary}. " +
            "Graf jest audytowy i nie ma prawa zmienić ceny FIX11.");
        if (sourceGuardSourcesSkipped > 0)
            result.Drawing.Findings.Add(
                $"DS 1.0 Source Selection: pominięto {sourceGuardSourcesSkipped} plików przed analizatorami specjalistycznymi " +
                $"(korpus reference/library: {externalReferenceSourcesSkipped}, pliki kontrolne/testowe: {benchmarkSupportSourcesSkipped}); " +
                "właściwe pliki produkcyjne zachowały pełną analizę.");
        if (priorityAccurateStepSet)
            result.Drawing.Findings.Add(
                $"FIX10G Accuracy Priority: aktywne dla {originalStepCount} produkcyjnych STEP; zwiększone limity styków/spoin/powierzchni nadal podlegają watchdogowi.");
        if (parallelIndependentRootCount > 1)
            result.Drawing.Findings.Add(
                $"DS 1.0 Multi-Root Scheduler: {parallelIndependentRootCount} niezależne główne STEP-y policzono z maksymalnie 2 procesami OCP równolegle; agregacja geometrii pozostaje deterministyczna, a relację wariant/podzespół sygnalizuje ryzyko MULTI_ROOT_STEP.");

        wallClock.Stop();
        result.EngineTimings = timings.OrderByDescending(x => x.ElapsedSeconds).ToList();
        result.AnalysisWallSeconds = wallClock.Elapsed.TotalSeconds;
        result.Drawing.Findings.Add(
            $"Adaptive Analysis Engine DS 1.0: CPU {profile.CpuCount}, RAM~{profile.AvailableMemoryGb:0.#} GB; " +
            $"DOC×{initialDocumentWorkers}→{profile.PdfDocumentsBoosted}, OCR×{profile.OcrWorkers}→{profile.OcrWorkersBoosted}, " +
            $"STEP-features×{profile.StepFeatureWorkers}, CORE×{profile.CoreStepWorkers}; po STEP wolne sloty przechodzą do PDF/OCR.");
        result.Drawing.Findings.Add(
            "Source Hierarchy DS 1.0: dla tej samej rodziny rysunku STEP/BOM zachowują własne role; " +
            "DXF ma priorytet dla geometrii 2D, PDF dla notatek/warstwy tekstowej, raster TIF/JPG/PNG jest fallbackiem OCR.");
        result.Drawing.Findings.Add(
            $"Czas rzeczywisty {result.AnalysisWallSeconds:0.0} s; suma pracy silników {result.AnalysisWorkSeconds:0.0} s; " +
            $"zysk równoległości/cache ~{result.ParallelEfficiencyGainPercent:0}%.");
        result.ReleaseSettingsHash = new QuoteReleaseService().ComputeSettingsHash(settings);

        progress?.Report(new AnalysisProgress { Percent = 94, Message = "Końcowa ocena ryzyk i gotowości…" });
        return result;
    }

    public void ApplyHistory(
        AnalysisResult analysis,
        QuoteProject current,
        IReadOnlyList<QuoteProject> history,
        CostingSettings settings)
    {
        // FIX16: historical calibration must learn from the frozen physical model,
        // not from hours already multiplied by external calibration.json. The
        // external layer is applied once, after all history corrections.
        _cost.PrepareForHistoricalCalibration(analysis, settings);
        _cost.ApplyProductionCalibration(
            analysis,
            history.Where(x => x.Id != current.Id).ToList(),
            settings);
        var similar = new List<SimilarProject>();

        static double RatioScore(double a, double b)
        {
            a = Math.Max(Math.Abs(a), 1e-6);
            b = Math.Max(Math.Abs(b), 1e-6);
            return Math.Min(a, b) / Math.Max(a, b);
        }

        static double BboxScore(GeometrySummary a, GeometrySummary b)
        {
            var aa = new[] { a.BoundingXmm, a.BoundingYmm, a.BoundingZmm }.OrderBy(x => x).ToArray();
            var bb = new[] { b.BoundingXmm, b.BoundingYmm, b.BoundingZmm }.OrderBy(x => x).ToArray();
            if (aa.Max() <= 0 || bb.Max() <= 0) return 0.5;
            return (RatioScore(aa[0], bb[0]) + RatioScore(aa[1], bb[1]) + RatioScore(aa[2], bb[2])) / 3.0;
        }

        foreach (var old in history)
        {
            if (old.Id == current.Id || old.Analysis is null)
                continue;

            var oldAnalysis = old.Analysis;
            var referencePrice = old.HistoryImport is not null
                ? old.HistoryImport.HistoricalPricePln
                : oldAnalysis.FinalPricePln;
            if (referencePrice is not > 0)
                continue;

            var score = 8.0;
            var basis = new List<string>();

            var currentClassCode = analysis.ProjectClass?.Code;
            var sameClass = !string.IsNullOrWhiteSpace(currentClassCode) &&
                            string.Equals(currentClassCode, oldAnalysis.ProjectClass?.Code, StringComparison.OrdinalIgnoreCase);
            if (sameClass)
            {
                score += 22;
                basis.Add($"ta sama klasa {currentClassCode}");
            }

            if (!string.IsNullOrWhiteSpace(current.Customer) &&
                !string.IsNullOrWhiteSpace(old.Customer) &&
                string.Equals(current.Customer.Trim(), old.Customer.Trim(), StringComparison.OrdinalIgnoreCase))
            {
                score += 10;
                basis.Add("ten sam klient");
            }

            if (string.Equals(analysis.Material, oldAnalysis.Material, StringComparison.OrdinalIgnoreCase) &&
                analysis.Material != "Nie rozpoznano")
            {
                score += 8;
                basis.Add("ten sam materiał");
            }

            if (analysis.WeightKg.HasValue && oldAnalysis.WeightKg.HasValue)
            {
                var r = RatioScore(analysis.WeightKg.Value, oldAnalysis.WeightKg.Value);
                score += 18 * r;
                if (r >= 0.75) basis.Add("podobna masa");
            }

            var bbox = BboxScore(analysis.Geometry, oldAnalysis.Geometry);
            score += 12 * bbox;
            if (bbox >= 0.75) basis.Add("podobny gabaryt");

            var currentParts = Math.Max(analysis.Geometry.SolidCount, 1);
            var oldParts = Math.Max(oldAnalysis.Geometry.SolidCount, 1);
            var partRatio = RatioScore(currentParts, oldParts);
            score += 7 * partRatio;

            var holeRatio = (analysis.Geometry.TotalHoleCount == 0 && oldAnalysis.Geometry.TotalHoleCount == 0)
                ? 1.0 : RatioScore(analysis.Geometry.TotalHoleCount + 1, oldAnalysis.Geometry.TotalHoleCount + 1);
            score += 6 * holeRatio;

            var weldRatio = (analysis.Welding.EffectiveLengthM <= 0 && oldAnalysis.Welding.EffectiveLengthM <= 0)
                ? 1.0 : RatioScore(analysis.Welding.EffectiveLengthM + 0.1, oldAnalysis.Welding.EffectiveLengthM + 0.1);
            score += 7 * weldRatio;

            var areaRatio = (analysis.Painting.PaintableAreaM2 <= 0 && oldAnalysis.Painting.PaintableAreaM2 <= 0)
                ? 1.0 : RatioScore(analysis.Painting.PaintableAreaM2 + 0.1, oldAnalysis.Painting.PaintableAreaM2 + 0.1);
            score += 5 * areaRatio;

            var aProc = analysis.Processes.Where(x => x.Enabled).Select(x => x.Code).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var bProc = oldAnalysis.Processes.Where(x => x.Enabled).Select(x => x.Code).ToHashSet(StringComparer.OrdinalIgnoreCase);
            if (aProc.Count > 0 && bProc.Count > 0)
            {
                var intersection = aProc.Intersect(bProc, StringComparer.OrdinalIgnoreCase).Count();
                var union = aProc.Union(bProc, StringComparer.OrdinalIgnoreCase).Count();
                var procScore = union == 0 ? 0 : intersection / (double)union;
                score += 7 * procScore;
                if (procScore >= 0.8) basis.Add("podobny routing");
            }

            similar.Add(new SimilarProject
            {
                ProjectId = old.Id,
                Name = old.Name,
                Customer = old.Customer,
                SimilarityPercent = Math.Clamp(score, 0, 99),
                WeightKg = oldAnalysis.WeightKg,
                FinalPricePln = referencePrice.Value,
                ProjectClass = oldAnalysis.ProjectClass?.Code ?? old.HistoryImport?.ProjectClass ?? "",
                SimilarityBasis = basis.Count == 0 ? "podobieństwo geometryczno-procesowe" : string.Join(" · ", basis.Take(5))
            });
        }

        var top = similar.OrderByDescending(x => x.SimilarityPercent).Take(8).ToList();
        _cost.ApplySimilarityAwareCalibration(
            analysis,
            history.Where(x => x.Id != current.Id).ToList(),
            top,
            settings);
        _cost.ApplyHistory(analysis, top, settings);
        _cost.FinalizeExternalCalibration(analysis, settings);

        // Anomaly detector: do not alter the quote silently. If the current price/kg is far
        // outside a robust historical neighbourhood, flag it for review.
        var comparable = top.Where(x => x.SimilarityPercent >= 68 && x.WeightKg is > 0 && x.FinalPricePln > 0)
            .Select(x => x.FinalPricePln / x.WeightKg!.Value)
            .OrderBy(x => x).ToList();
        if (analysis.WeightKg is > 0 && comparable.Count >= 3)
        {
            var median = comparable.Count % 2 == 1
                ? comparable[comparable.Count / 2]
                : (comparable[comparable.Count / 2 - 1] + comparable[comparable.Count / 2]) / 2.0;
            var currentPerKg = analysis.FinalPricePln / analysis.WeightKg.Value;
            var ratio = currentPerKg / Math.Max(0.01, median);
            if (ratio < 0.45 || ratio > 2.20)
            {
                analysis.Risks.Add(new RiskItem
                {
                    Code = "HISTORY_OUTLIER",
                    Level = RiskLevel.Medium,
                    Title = "Wycena odstaje od podobnych projektów",
                    Message = $"Cena {currentPerKg:0.##} PLN/kg vs mediana podobnych {median:0.##} PLN/kg ({comparable.Count} projektów). Sprawdź procesy/ilości; wynik nie został automatycznie zmieniony.",
                    Blocking = false
                });
                AutoQuoteEngine.Apply(analysis);
            }
        }
    }

    private static bool HasTimeout(IEnumerable<string> warnings) =>
        warnings.Any(x => x.Contains("TIMEOUT:", StringComparison.OrdinalIgnoreCase) ||
                          x.Contains("watchdog", StringComparison.OrdinalIgnoreCase));

    private static bool SuspiciousSourceText(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return false;
        if (Regex.IsMatch(text, @"https?://|amazon|taobao|aliexpress|seeedstudio|mouser|digikey|igus", RegexOptions.IgnoreCase))
            return true;
        return text.Count(c => c == '|') >= 4;
    }

    private static bool PlausibleThread(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return true;
        var t = value.Trim().Replace(" ", "");
        return Regex.IsMatch(t,
            @"^(?:M\d{1,3}(?:[\.,]\d+)?(?:[xX]\d+(?:[\.,]\d+)?)?(?:-(?:6H|6G|5H|5G|4H|4G))?|G\d+(?:[\.,]\d+)?|R\d+(?:[\.,]\d+)?|(?:UNC|UNF|UNEF)[- ]?\d+|\d+(?:/\d+)?[- ]?(?:UNC|UNF|UNEF))$",
            RegexOptions.IgnoreCase);
    }

    private static string NormalizeSurfacePreparation(string? value)
    {
        var v = (value ?? "").Trim().ToUpperInvariant().Replace("SA2,5", "SA 2.5").Replace("SA 2,5", "SA 2.5");
        if (v.Contains("SSPC-SP 10", StringComparison.OrdinalIgnoreCase) || v.Contains("SSPC SP 10", StringComparison.OrdinalIgnoreCase))
            return "SA 2.5";
        if (Regex.IsMatch(v, @"\bSA\s*3\b", RegexOptions.IgnoreCase)) return "SA 3";
        if (Regex.IsMatch(v, @"\bSA\s*2(?:[\.,]5)\b", RegexOptions.IgnoreCase)) return "SA 2.5";
        if (Regex.IsMatch(v, @"\bST\s*3\b", RegexOptions.IgnoreCase)) return "ST 3";
        return (value ?? "").Trim();
    }

    private static void ApplyCriticalSourceGuard(ProjectDocument document, DrawingIntelligence drawing)
    {
        var trusted = DocumentSelectionPolicy.IsTrustedForCriticalFusion(document);
        if (!trusted)
        {
            // Purchased spreadsheets may still carry quantities/part numbers, but their
            // catalogue prose must not become global manufacturing requirements.
            if (document.Role != DocumentRole.PurchasedItem)
            {
                drawing.BomItems.Clear();
                drawing.BomTotalMassKg = null;
                drawing.BomMassRowCount = 0;
                drawing.BomPositiveMassRowCount = 0;
                drawing.BomMassSourceCount = 0;
            }
            drawing.MaterialHint = "";
            drawing.MaterialReference = "";
            drawing.MaterialReferenceConfidence = 0;
            drawing.MaterialReferenceEvidence = "";
            drawing.DocumentMassKg = null;
            drawing.DocumentMassConfidence = 0;
            drawing.DocumentMassEvidence = "";
            drawing.DocumentMassScope = "UNKNOWN";
            drawing.DocumentSurfaceAreaM2 = null;
            drawing.DocumentSurfaceAreaConfidence = 0;
            drawing.DocumentSurfaceAreaEvidence = "";
            drawing.SurfacePreparation = "";
            drawing.CorrosionClass = "";
            drawing.PaintColour = "";
            drawing.TotalDftMicron = null;
            drawing.PaintLayers.Clear();
            drawing.PaintStripeCoatRequired = false;
            drawing.WeldProcessCode = "";
            drawing.WeldTypeHint = "";
            drawing.WeldSizeKind = "";
            drawing.WeldSizeMm = null;
            drawing.WeldSideCount = 0;
            drawing.WeldSideCountConfirmed = false;
            drawing.WeldIntermittent = false;
            drawing.WeldIntermittentLengthMm = null;
            drawing.WeldPitchMm = null;
            drawing.WeldExplicitLengthMm = null;
            drawing.WeldExplicitLengthConfidence = 0;
            drawing.WeldExplicitLengthEvidence = "";
            drawing.WeldIntermittencyConfirmed = false;
            drawing.WeldAllAround = false;
            drawing.WeldGrooveAngleDeg = null;
            drawing.WeldRootGapMm = null;
            drawing.HoleRequirements.Clear();
            drawing.DimensionalTolerances.Clear();
            drawing.GeometricTolerances.Clear();
            drawing.Norms.Clear();
            drawing.ProjectQuantityHint = null;
            drawing.Findings.Add($"FIX10 Source Guard: {document.RoleDisplay} nie głosuje w krytycznych danych produkcyjnych.");
            return;
        }

        if (drawing.DocumentMassKg.HasValue &&
            (drawing.DocumentMassConfidence < 70 || SuspiciousSourceText(drawing.DocumentMassEvidence)))
        {
            drawing.Findings.Add($"FIX10 Mass Guard: odrzucono niepewną masę {drawing.DocumentMassKg:0.###} kg ({drawing.DocumentMassConfidence}%).");
            drawing.DocumentMassKg = null;
            drawing.DocumentMassConfidence = 0;
            drawing.DocumentMassEvidence = "";
            drawing.DocumentMassScope = "UNKNOWN";
        }

        foreach (var hole in drawing.HoleRequirements)
        {
            if (!string.IsNullOrWhiteSpace(hole.ThreadCode) &&
                (!PlausibleThread(hole.ThreadCode) || SuspiciousSourceText(hole.SourceText)))
            {
                hole.ThreadCode = "";
                hole.RequiresTap = false;
                if (string.Equals(hole.OperationHint, "THREAD", StringComparison.OrdinalIgnoreCase))
                    hole.OperationHint = "DRAWING_DIAMETER";
            }
        }
        drawing.HoleRequirements = drawing.HoleRequirements
            .Where(x => !SuspiciousSourceText(x.SourceText) || x.NominalDiameterMm is > 0)
            .ToList();
        drawing.DimensionalTolerances = drawing.DimensionalTolerances
            .Where(x => !SuspiciousSourceText(x.SourceText))
            .ToList();
        drawing.GeometricTolerances = drawing.GeometricTolerances
            .Where(x => !SuspiciousSourceText(x.SourceText))
            .ToList();
        drawing.SurfacePreparation = NormalizeSurfacePreparation(drawing.SurfacePreparation);
    }

    private static void ApplyCriticalSourceGuard(ProjectDocument document, DxfSignals dxf)
    {
        if (!DocumentSelectionPolicy.IsTrustedForCriticalFusion(document))
        {
            dxf.MaterialHint = "";
            dxf.MaterialReference = "";
            dxf.MaterialReferenceConfidence = 0;
            dxf.MaterialReferenceEvidence = "";
            dxf.DocumentMassKg = null;
            dxf.DocumentMassConfidence = 0;
            dxf.DocumentMassEvidence = "";
            dxf.DocumentMassScope = "UNKNOWN";
            dxf.DocumentSurfaceAreaM2 = null;
            dxf.DocumentSurfaceAreaConfidence = 0;
            dxf.DocumentSurfaceAreaEvidence = "";
            dxf.SurfacePreparation = "";
            dxf.CorrosionClass = "";
            dxf.PaintColour = "";
            dxf.TotalDftMicron = null;
            dxf.PaintLayers.Clear();
            dxf.WeldProcessCode = "";
            dxf.WeldTypeHint = "";
            dxf.WeldSizeKind = "";
            dxf.WeldSizeMm = null;
            dxf.HoleRequirements.Clear();
            dxf.DimensionalTolerances.Clear();
            dxf.GeometricTolerances.Clear();
            dxf.Norms.Clear();
            dxf.Findings.Add($"FIX10 Source Guard: {document.RoleDisplay} zachowuje geometrię 2D, ale nie głosuje w krytycznych notatkach.");
            return;
        }
        if (dxf.DocumentMassKg.HasValue &&
            (dxf.DocumentMassConfidence < 70 || SuspiciousSourceText(dxf.DocumentMassEvidence)))
        {
            dxf.DocumentMassKg = null;
            dxf.DocumentMassConfidence = 0;
            dxf.DocumentMassEvidence = "";
            dxf.DocumentMassScope = "UNKNOWN";
        }
        foreach (var hole in dxf.HoleRequirements)
        {
            if (!string.IsNullOrWhiteSpace(hole.ThreadCode) &&
                (!PlausibleThread(hole.ThreadCode) || SuspiciousSourceText(hole.SourceText)))
            {
                hole.ThreadCode = "";
                hole.RequiresTap = false;
            }
        }
        dxf.DimensionalTolerances = dxf.DimensionalTolerances.Where(x => !SuspiciousSourceText(x.SourceText)).ToList();
        dxf.GeometricTolerances = dxf.GeometricTolerances.Where(x => !SuspiciousSourceText(x.SourceText)).ToList();
        dxf.SurfacePreparation = NormalizeSurfacePreparation(dxf.SurfacePreparation);
    }

    private static void ApplySurfacePreparationGuard(
        DrawingIntelligence merged,
        IReadOnlyList<DrawingIntelligence> drawings,
        IReadOnlyList<ProjectDocument> documents)
    {
        var trustedNames = documents
            .Where(DocumentSelectionPolicy.IsTrustedForCriticalFusion)
            .Select(x => x.Name)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var values = drawings
            .Where(x => trustedNames.Contains(x.SourceFile))
            .Select(x => NormalizeSurfacePreparation(x.SurfacePreparation))
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .ToList();
        var hasSa3 = values.Any(x => string.Equals(x, "SA 3", StringComparison.OrdinalIgnoreCase));
        var hasSa25 = values.Any(x => string.Equals(x, "SA 2.5", StringComparison.OrdinalIgnoreCase));
        if (hasSa3 && hasSa25)
        {
            merged.SurfacePreparation = "SA 3";
            merged.Findings.Add("FIX10 Surface Guard: niezależne dokumenty produkcyjne wskazują SA 2.5 i SA 3; do wyceny konserwatywnie przyjęto SA 3, konflikt pozostaje widoczny.");
            merged.Conflicts.Add(new InformationConflict
            {
                Field = "Przygotowanie powierzchni",
                Values = "SA 2.5 | SA 3",
                Sources = string.Join(" | ", drawings.Where(x => trustedNames.Contains(x.SourceFile) && !string.IsNullOrWhiteSpace(x.SurfacePreparation)).Select(x => $"{x.SourceFile}: {x.SurfacePreparation}")),
                Resolution = "FIX10: konserwatywnie SA 3; wymaga potwierdzenia dokumentacji nadrzędnej.",
                Level = RiskLevel.Medium
            });
        }
        else if (hasSa3)
            merged.SurfacePreparation = "SA 3";
        else if (hasSa25)
            merged.SurfacePreparation = "SA 2.5";
    }

    private static GeometrySummary MergeGeometry(List<GeometrySummary> items)
    {
        if (items.Count == 0)
            return new GeometrySummary();

        var merged = new GeometrySummary
        {
            Available = items.Any(x => x.Available),
            SolidCount = items.Sum(x => x.SolidCount),
            UniquePartGroups = items.Sum(x => x.UniquePartGroups),
            ContactPairs = items.Sum(x => x.ContactPairs),
            ContactPairsTight = items.Sum(x => x.ContactPairsTight),
            ContactPairsNominal = items.Sum(x => x.ContactPairsNominal),
            ContactCandidatePairs = items.Sum(x => x.ContactCandidatePairs),
            ContactExactChecks = items.Sum(x => x.ContactExactChecks),
            ContactLimitReached = items.Any(x => x.ContactLimitReached),
            HoleEngineVersion = items.Select(x => x.HoleEngineVersion).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "",
            JointEngineVersion = items.Select(x => x.JointEngineVersion).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "",
            SurfaceEngineVersion = items.Select(x => x.SurfaceEngineVersion).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "",
            Importer = items.Select(x => x.Importer).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "",
            VolumeMm3 = items.Sum(x => x.VolumeMm3),
            SurfaceMm2 = items.Sum(x => x.SurfaceMm2),
            ExposedSurfaceMm2 = items.Sum(x => x.ExposedSurfaceMm2),
            PaintableSurfaceMm2 = items.Sum(x => x.PaintableSurfaceMm2),
            PlanarMatingAreaMm2 = items.Sum(x => x.PlanarMatingAreaMm2),
            HiddenMatingSurfaceMm2 = items.Sum(x => x.HiddenMatingSurfaceMm2),
            InternalPaintExcludedMm2 = items.Sum(x => x.InternalPaintExcludedMm2),
            SealedCavitySurfaceMm2 = items.Sum(x => x.SealedCavitySurfaceMm2),
            SurfaceAccessibilityCheckedFaces = items.Sum(x => x.SurfaceAccessibilityCheckedFaces),
            SurfaceAccessibilityLimitReached = items.Any(x => x.SurfaceAccessibilityLimitReached),
            WeldCandidatePairs = items.Sum(x => x.WeldCandidatePairs),
            PossibleBoltedJointPairs = items.Sum(x => x.PossibleBoltedJointPairs),
            WeldCandidateLengthMm = items.Sum(x => x.WeldCandidateLengthMm),
            JointAnalysisLimitReached = items.Any(x => x.JointAnalysisLimitReached),
            JointFaceChecks = items.Sum(x => x.JointFaceChecks),
            FullyAnalyzedUniqueSolids = items.Sum(x => x.FullyAnalyzedUniqueSolids),
            ReusedSolidAnalyses = items.Sum(x => x.ReusedSolidAnalyses),
            JointCandidates = items.SelectMany(x => x.JointCandidates)
                .OrderBy(x => x.SourceFile, StringComparer.OrdinalIgnoreCase)
                .ThenBy(x => x.BodyA)
                .ThenBy(x => x.BodyB)
                .ThenBy(x => x.Type, StringComparer.OrdinalIgnoreCase)
                .ThenBy(x => x.DistanceMm)
                .ToList(),
            BoundingXmm = items.Max(x => x.BoundingXmm),
            BoundingYmm = items.Max(x => x.BoundingYmm),
            BoundingZmm = items.Max(x => x.BoundingZmm),
            TotalHoleCount = items.Sum(x => x.TotalHoleCount),
            TotalPocketCandidateCount = items.Sum(x => x.TotalPocketCandidateCount),
            PocketEngineVersion = items.Select(x => x.PocketEngineVersion).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "",
            TotalBevelFaces = items.Sum(x => x.TotalBevelFaces),
            WatchdogTriggered = items.Any(x => x.WatchdogTriggered),
            WatchdogLimitSeconds = items.Select(x => x.WatchdogLimitSeconds).Max(),
            AnalysisMode = items.Any(x => x.WatchdogTriggered) ? "mixed-watchdog" : items.Select(x => x.AnalysisMode).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "full",
            Warnings = items.SelectMany(x => x.Warnings).Distinct().OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList()
        };

        var groups = items
            .SelectMany(x => x.Parts)
            .GroupBy(x => $"{x.SourceFile}|{x.GroupKey}")
            .OrderBy(x => x.Key, StringComparer.OrdinalIgnoreCase);

        var index = 1;
        foreach (var group in groups)
        {
            var first = group.First();
            first.Name = string.IsNullOrWhiteSpace(first.Name)
                ? $"Detal {index:000}"
                : first.Name;
            first.Holes = first.Holes
                .OrderBy(x => x.DiameterMm)
                .ThenBy(x => x.MaxDiameterMm)
                .ThenBy(x => x.DepthMm)
                .ThenBy(x => x.ThreadCode, StringComparer.OrdinalIgnoreCase)
                .ThenBy(x => x.FitCode, StringComparer.OrdinalIgnoreCase)
                .ToList();
            merged.Parts.Add(first);
            index++;
        }

        merged.Parts = merged.Parts
            .OrderBy(x => x.SourceFile, StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.GroupKey, StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.Name, StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.Xmm)
            .ThenBy(x => x.Ymm)
            .ThenBy(x => x.Zmm)
            .ThenBy(x => x.VolumeMm3Each)
            .ToList();
        return merged;
    }

    private static ProjectDocument? SelectStrongAssemblyRoot(IReadOnlyList<ProjectDocument> documents)
    {
        if (documents.Count < 16)
            return null;

        var ordered = documents
            .Where(x => x.SizeBytes > 0)
            .OrderByDescending(x => x.SizeBytes)
            .ToList();
        if (ordered.Count < 2)
            return null;

        var largest = ordered[0];
        var second = ordered[1];
        if (largest.SizeBytes < 1_000_000)
            return null;

        var ratio = largest.SizeBytes / (double)Math.Max(1L, second.SizeBytes);
        return ratio >= 5.0 ? largest : null;
    }

    private static bool CanUseAssemblyRootFastPath(
        ProjectDocument rootDocument,
        GeometrySummary root,
        IReadOnlyList<ProjectDocument> allStepDocuments,
        int? authoritativeBomItemCount)
    {
        if (!root.Available || root.SolidCount < 10 || root.UniquePartGroups < 10)
            return false;
        if (root.FullyAnalyzedUniqueSolids < root.UniquePartGroups)
            return false;

        var children = allStepDocuments.Where(x => !ReferenceEquals(x, rootDocument)).ToList();
        if (children.Count < 10)
            return false;

        // A second substantial STEP may be another independent assembly.  The fast path
        // is only allowed when every child is clearly small compared with the root.
        var maxChildSize = children.Max(x => x.SizeBytes);
        if (maxChildSize > Math.Max(1_000_000L, (long)(rootDocument.SizeBytes * 0.25)))
            return false;

        // Original R9.2.2 pattern: one standalone STEP export for approximately every
        // unique geometry in the assembly.
        var countRatio = children.Count / (double)Math.Max(1, root.UniquePartGroups);
        var fullSidecarSet = countRatio >= 0.85 && countRatio <= 1.15;

        // R9.2.2B: real RFQs may contain only a subset of standalone part exports.
        // If an authoritative BOM workbook confirms the SAME number of project items as
        // the root has unique geometry groups, then the root is complete and any smaller
        // STEP files are sidecar representations, not additional project geometry.
        // Allow a tiny ±1 row tolerance for a title/summary row parser edge case.
        var bomConfirmsRoot = authoritativeBomItemCount.HasValue &&
                              Math.Abs(authoritativeBomItemCount.Value - root.UniquePartGroups) <= 1;
        var partialSidecarSet = bomConfirmsRoot &&
                                children.Count <= root.UniquePartGroups;

        return fullSidecarSet || partialSidecarSet;
    }

    private static bool IsAuthoritativeBomDocumentName(string name)
    {
        var baseName = Path.GetFileNameWithoutExtension(name) ?? string.Empty;
        return baseName.Contains("BOM", StringComparison.OrdinalIgnoreCase) ||
               baseName.Contains("STUECKLIST", StringComparison.OrdinalIgnoreCase) ||
               baseName.Contains("STÜCKLIST", StringComparison.OrdinalIgnoreCase) ||
               baseName.Contains("PARTLIST", StringComparison.OrdinalIgnoreCase) ||
               baseName.Contains("PARTS LIST", StringComparison.OrdinalIgnoreCase) ||
               baseName.Contains("MATERIAL LIST", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsContainedInAssembly(GeometrySummary candidate, GeometrySummary assembly)
    {
        if (!candidate.Available || !assembly.Available || candidate.SolidCount <= 0 || assembly.SolidCount <= 1)
            return false;
        if (candidate.SolidCount > assembly.SolidCount || candidate.Parts.Count == 0 || assembly.Parts.Count == 0)
            return false;

        var remaining = assembly.Parts.Select(x => Math.Max(1, x.Quantity)).ToArray();
        foreach (var part in candidate.Parts.OrderByDescending(x => x.VolumeMm3Each))
        {
            var needed = Math.Max(1, part.Quantity);
            var matched = false;
            for (var i = 0; i < assembly.Parts.Count; i++)
            {
                if (remaining[i] < needed || !SamePartGeometry(part, assembly.Parts[i]))
                    continue;
                remaining[i] -= needed;
                matched = true;
                break;
            }
            if (!matched)
                return false;
        }
        return true;
    }

    private static int EnrichAssemblyIdentityFromContainedPreScan(GeometrySummary assembly, GeometrySummary component, string sourceName)
    {
        var matched = 0;
        foreach (var source in component.Parts)
        {
            var target = assembly.Parts
                .Where(x => SamePartGeometry(source, x))
                .OrderByDescending(x => x.Quantity)
                .FirstOrDefault();
            if (target is null)
                continue;
            if (component.Parts.Count == 1 && !string.IsNullOrWhiteSpace(sourceName))
                target.Name = Path.GetFileNameWithoutExtension(sourceName);
            matched++;
        }
        return matched;
    }

    private static int EnrichAssemblyFromContainedStep(GeometrySummary assembly, GeometrySummary component, string sourceName)
    {
        var enriched = 0;
        foreach (var source in component.Parts)
        {
            var target = assembly.Parts
                .Where(x => SamePartGeometry(source, x))
                .OrderByDescending(x => x.Quantity)
                .FirstOrDefault();
            if (target is null)
                continue;

            if (source.Holes.Count > 0 && (target.Holes.Count == 0 || source.Holes.Sum(x => x.Count) >= target.Holes.Sum(x => x.Count)))
                target.Holes = source.Holes;
            if (source.Bevel.Count > target.Bevel.Count)
                target.Bevel = source.Bevel;
            if (source.ClassificationConfidence > target.ClassificationConfidence)
            {
                target.Classification = source.Classification;
                target.ClassificationConfidence = source.ClassificationConfidence;
                target.ClassificationBasis = source.ClassificationBasis + $"; doprecyzowano z osobnego STEP {sourceName}";
            }
            if (component.Parts.Count == 1 && !string.IsNullOrWhiteSpace(sourceName))
                target.Name = Path.GetFileNameWithoutExtension(sourceName);

            // Preserve the assembly quantity and totals. Only replace per-part feature
            // detail when the standalone export is at least as informative.
            target.FaceCount = Math.Max(target.FaceCount, source.FaceCount);
            target.EdgeCount = Math.Max(target.EdgeCount, source.EdgeCount);
            target.CylindricalFaceCount = Math.Max(target.CylindricalFaceCount, source.CylindricalFaceCount);
            target.InternalCylindricalFaceCount = Math.Max(target.InternalCylindricalFaceCount, source.InternalCylindricalFaceCount);
            target.ExternalCylindricalFaceCount = Math.Max(target.ExternalCylindricalFaceCount, source.ExternalCylindricalFaceCount);
            target.ConicalFaceCount = Math.Max(target.ConicalFaceCount, source.ConicalFaceCount);
            target.PlanarFaceCount = Math.Max(target.PlanarFaceCount, source.PlanarFaceCount);
            if (source.PocketCandidateCount > target.PocketCandidateCount)
            {
                target.PocketCandidateCount = source.PocketCandidateCount;
                target.PocketCandidateAreaMm2 = source.PocketCandidateAreaMm2;
                target.PocketMaxDepthMm = source.PocketMaxDepthMm;
            }
            enriched++;
        }

        // Recompute feature totals from the authoritative assembly part quantities, not
        // from the standalone file quantities.
        assembly.TotalHoleCount = assembly.Parts.Sum(p => p.Holes.Sum(h => h.Count) * Math.Max(1, p.Quantity));
        assembly.TotalBevelFaces = assembly.Parts.Sum(p => p.Bevel.Count * Math.Max(1, p.Quantity));
        assembly.TotalPocketCandidateCount = assembly.Parts.Sum(p => p.PocketCandidateCount * Math.Max(1, p.Quantity));
        return enriched;
    }

    private static bool SamePartGeometry(PartGroup a, PartGroup b)
    {
        static double[] Dims(PartGroup p) => new double[] { p.Xmm, p.Ymm, p.Zmm }.OrderBy(x => x).ToArray();
        static bool Near(double x, double y, double absTol, double relTol)
            => Math.Abs(x - y) <= Math.Max(absTol, Math.Max(Math.Abs(x), Math.Abs(y)) * relTol);

        var ad = Dims(a);
        var bd = Dims(b);
        return Near(ad[0], bd[0], 0.15, 0.0005) &&
               Near(ad[1], bd[1], 0.15, 0.0005) &&
               Near(ad[2], bd[2], 0.15, 0.0005) &&
               Near(a.VolumeMm3Each, b.VolumeMm3Each, 1.0, 0.0005) &&
               Near(a.SurfaceMm2Each, b.SurfaceMm2Each, 1.0, 0.001) &&
               a.FaceCount == b.FaceCount &&
               a.EdgeCount == b.EdgeCount &&
               a.CylindricalFaceCount == b.CylindricalFaceCount &&
               a.ConicalFaceCount == b.ConicalFaceCount &&
               a.PlanarFaceCount == b.PlanarFaceCount;
    }

    private static int AnalysisOrder(DocumentKind kind) => kind switch
    {
        DocumentKind.Dxf => 0,
        DocumentKind.Dwg => 0,
        DocumentKind.Step => 1,
        DocumentKind.Excel => 2,
        DocumentKind.Text => 2,
        DocumentKind.Pdf => 3,
        DocumentKind.Image => 4,
        _ => 5
    };

    private static string DocumentPairKey(string name)
    {
        var stem = Path.GetFileNameWithoutExtension(name ?? "").Trim().ToUpperInvariant();
        stem = Regex.Replace(stem, @"(?:[_\- ](?:PDF|DXF|DWG|TIF|TIFF|JPG|JPEG|PNG|DRAWING|RYSUNEK))$", "", RegexOptions.IgnoreCase);
        return Regex.Replace(stem, @"[^A-Z0-9]+", "");
    }

    private static string DocumentFamilyKey(string name)
    {
        var stem = Path.GetFileNameWithoutExtension(name ?? "").Trim().ToUpperInvariant();
        stem = Regex.Replace(stem, @"(?:[_\- ](?:PDF|DXF|DWG|TIF|TIFF|JPG|JPEG|PNG|DRAWING|RYSUNEK))$", "", RegexOptions.IgnoreCase);
        // Common supplier convention: ..._1 = DXF/TIF and ..._2 = PDF/DXF export of
        // the same drawing.  Revision/sheet tokens (A/B, SH01/SH02) remain in the key.
        stem = Regex.Replace(stem, @"(?:[_\- ]+)[1-4]$", "", RegexOptions.IgnoreCase);
        return Regex.Replace(stem, @"[^A-Z0-9]+", "");
    }

    private static IEnumerable<string> DocumentPairKeys(string name)
    {
        var exact = DocumentPairKey(name);
        if (!string.IsNullOrWhiteSpace(exact))
            yield return "E:" + exact;
        var family = DocumentFamilyKey(name);
        if (!string.IsNullOrWhiteSpace(family) && !family.Equals(exact, StringComparison.OrdinalIgnoreCase))
            yield return "F:" + family;
    }

    private static void RegisterPairTask(
        Dictionary<string, Task<DocumentWorkResult>> map,
        string name,
        Task<DocumentWorkResult> task)
    {
        foreach (var key in DocumentPairKeys(name))
            map.TryAdd(key, task);
    }

    private static bool TryGetPairTask(
        IReadOnlyDictionary<string, Task<DocumentWorkResult>> map,
        string name,
        out Task<DocumentWorkResult> task)
    {
        foreach (var key in DocumentPairKeys(name))
        {
            if (map.TryGetValue(key, out var found))
            {
                task = found;
                return true;
            }
        }
        task = null!;
        return false;
    }

    private static bool IsRichTechnicalDxf(DxfSignals d)
    {
        var semanticCount = d.Norms.Count + d.HoleRequirements.Count +
                            d.DimensionalTolerances.Count + d.GeometricTolerances.Count +
                            (d.DocumentMassKg is > 0 ? 1 : 0) +
                            (!string.IsNullOrWhiteSpace(d.WeldProcessCode) || d.WeldSizeMm.HasValue ? 1 : 0) +
                            (!string.IsNullOrWhiteSpace(d.PaintColour) || d.TotalDftMicron.HasValue ? 1 : 0);
        return d.ExtractedTextLength >= 350 || (d.ExtractedTextLength >= 180 && semanticCount >= 3);
    }

    private static bool IsRichTechnicalDrawing(DrawingIntelligence d)
    {
        var semanticCount = d.Norms.Count + d.HoleRequirements.Count +
                            d.DimensionalTolerances.Count + d.GeometricTolerances.Count +
                            (d.DocumentMassKg is > 0 ? 1 : 0) +
                            (!string.IsNullOrWhiteSpace(d.MaterialHint) ? 1 : 0) +
                            (!string.IsNullOrWhiteSpace(d.WeldProcessCode) || d.WeldSizeMm.HasValue ? 1 : 0) +
                            (!string.IsNullOrWhiteSpace(d.PaintColour) || d.TotalDftMicron.HasValue ? 1 : 0);
        return d.ExtractedTextLength >= 500 || (d.ExtractedTextLength >= 220 && semanticCount >= 3);
    }

    private static bool HasDxfDrawingSignals(DxfSignals d) =>
        d.ExtractedTextLength > 0 || d.Keywords.Count > 0 || d.Norms.Count > 0 ||
        !string.IsNullOrWhiteSpace(d.MaterialHint) || d.DocumentMassKg is > 0 ||
        d.HoleRequirements.Count > 0 || d.DimensionalTolerances.Count > 0 ||
        d.GeometricTolerances.Count > 0 || d.WeldSizeMm.HasValue || d.WeldExplicitLengthMm.HasValue ||
        !string.IsNullOrWhiteSpace(d.WeldProcessCode) || !string.IsNullOrWhiteSpace(d.WeldTypeHint) ||
        !string.IsNullOrWhiteSpace(d.PaintColour) || d.TotalDftMicron.HasValue ||
        !string.IsNullOrWhiteSpace(d.SurfacePreparation);

    private static double EquivalentWeldThroatMm(double value, string? kind) =>
        string.Equals(kind?.Trim(), "z", StringComparison.OrdinalIgnoreCase)
            ? value / Math.Sqrt(2.0)
            : value;

    private static DrawingIntelligence DrawingFromDxf(string sourceFile, DxfSignals d) => new()
    {
        SourceFile = sourceFile,
        MaterialHint = d.MaterialHint,
        MaterialReference = d.MaterialReference,
        MaterialReferenceConfidence = d.MaterialReferenceConfidence,
        MaterialReferenceEvidence = d.MaterialReferenceEvidence,
        Keywords = d.Keywords.ToList(),
        Norms = d.Norms.ToList(),
        Findings = d.Findings.ToList(),
        Warnings = d.Warnings.ToList(),
        ExtractedTextLength = d.ExtractedTextLength,
        WeldProcessCode = d.WeldProcessCode,
        WeldTypeHint = d.WeldTypeHint,
        WeldSizeKind = d.WeldSizeKind,
        WeldSizeMm = d.WeldSizeMm,
        WeldSideCount = d.WeldSideCount,
        WeldSideCountConfirmed = d.WeldSideCountConfirmed,
        WeldIntermittent = d.WeldIntermittent,
        WeldIntermittentLengthMm = d.WeldIntermittentLengthMm,
        WeldPitchMm = d.WeldPitchMm,
        WeldExplicitLengthMm = d.WeldExplicitLengthMm,
        WeldExplicitLengthConfidence = d.WeldExplicitLengthConfidence,
        WeldExplicitLengthEvidence = d.WeldExplicitLengthEvidence,
        WeldIntermittencyConfirmed = d.WeldIntermittencyConfirmed,
        WeldAllAround = d.WeldAllAround,
        WeldGrooveAngleDeg = d.WeldGrooveAngleDeg,
        WeldRootGapMm = d.WeldRootGapMm,
        SurfacePreparation = d.SurfacePreparation,
        CorrosionClass = d.CorrosionClass,
        PaintColour = d.PaintColour,
        TotalDftMicron = d.TotalDftMicron,
        PaintLayers = d.PaintLayers.ToList(),
        PaintStripeCoatRequired = d.PaintStripeCoatRequired,
        HoleRequirements = d.HoleRequirements.ToList(),
        DimensionalTolerances = d.DimensionalTolerances.ToList(),
        GeometricTolerances = d.GeometricTolerances.ToList(),
        DocumentMassKg = d.DocumentMassKg,
        DocumentMassConfidence = d.DocumentMassConfidence,
        DocumentMassEvidence = d.DocumentMassEvidence,
        DocumentMassScope = d.DocumentMassScope,
        DocumentSurfaceAreaM2 = d.DocumentSurfaceAreaM2,
        DocumentSurfaceAreaConfidence = d.DocumentSurfaceAreaConfidence,
        DocumentSurfaceAreaEvidence = d.DocumentSurfaceAreaEvidence,
        PaintMaskMachinedSurfaces = d.PaintMaskMachinedSurfaces,
        PaintScope = d.PaintScope,
        PaintScopeEvidence = d.PaintScopeEvidence,
        PaintScopeConflict = d.PaintScopeConflict,
        ProjectQuantityHint = d.ProjectQuantityHint
    };

    private static DrawingIntelligence MergeDrawings(List<DrawingIntelligence> items)
    {
        var merged = new DrawingIntelligence
        {
            ExtractedTextLength = items.Sum(x => x.ExtractedTextLength)
        };

        merged.PdfPageCount = items.Sum(x => x.PdfPageCount);
        merged.PageEvidence = items.SelectMany(x => x.PageEvidence)
            .OrderBy(x => x.SourceFile, StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.PageNumber).ToList();
        // Each link is computed within its original PDF, not across different
        // customer documents that may reuse the same drawing number.
        merged.DrawingBomLinks = items.SelectMany(x => x.DrawingBomLinks)
            .OrderBy(x => x.SourceFile, StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.DrawingPageNumber).ToList();

        merged.Keywords = items.SelectMany(x => x.Keywords)
            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        merged.Norms = items.SelectMany(x => x.Norms)
            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        merged.Findings = items.SelectMany(x => x.Findings).Distinct().ToList();
        merged.Warnings = items.SelectMany(x => x.Warnings).Distinct().ToList();
        merged.DetectedLanguages = items.SelectMany(x => x.DetectedLanguages)
            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        merged.OcrLanguagesUsed = string.Join(", ", items.Select(x => x.OcrLanguagesUsed)
            .Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase));
        merged.OcrEnginePath = items.Select(x => x.OcrEnginePath)
            .FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "";
        var meanOcr = items.Where(x => x.OcrMeanConfidence.HasValue)
            .Select(x => x.OcrMeanConfidence!.Value).ToList();
        var criticalOcr = items.Where(x => x.OcrCriticalConfidence.HasValue)
            .Select(x => x.OcrCriticalConfidence!.Value).ToList();
        merged.OcrMeanConfidence = meanOcr.Count > 0 ? meanOcr.Average() : null;
        merged.OcrCriticalConfidence = criticalOcr.Count > 0 ? criticalOcr.Average() : null;
        merged.OcrLowConfidenceSignals = items.SelectMany(x => x.OcrLowConfidenceSignals)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(20)
            .ToList();
        merged.OcrCriticalConflicts = items.SelectMany(x => x.OcrCriticalConflicts)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(12)
            .ToList();

        string ChooseText(string field, Func<DrawingIntelligence,string> selector, RiskLevel level, string resolution)
        {
            var values = items
                .Select(x => new { Value = selector(x)?.Trim() ?? "", Source = x.SourceFile })
                .Where(x => !string.IsNullOrWhiteSpace(x.Value))
                .ToList();
            var groups = values.GroupBy(x => x.Value, StringComparer.OrdinalIgnoreCase)
                .OrderByDescending(g => g.Count()).ThenBy(g => g.Key).ToList();
            if (groups.Count > 1)
            {
                merged.Conflicts.Add(new InformationConflict
                {
                    Field = field,
                    Values = string.Join(" | ", groups.Select(g => g.Key)),
                    Sources = string.Join(" | ", values.Select(x => $"{x.Source}: {x.Value}")),
                    Resolution = resolution,
                    Level = level
                });
            }
            return groups.FirstOrDefault()?.Key ?? "";
        }

        string ChooseMaterial()
        {
            var values = items
                .Select(x => new { Value = x.MaterialHint?.Trim() ?? "", Source = x.SourceFile })
                .Where(x => !string.IsNullOrWhiteSpace(x.Value))
                .ToList();
            if (values.Count == 0)
                return "";

            var groups = values.GroupBy(x => x.Value, StringComparer.OrdinalIgnoreCase)
                .OrderByDescending(g => g.Count()).ThenByDescending(g => g.Key.Length).ToList();
            if (groups.Count <= 1)
                return groups[0].Key;

            // A generic family marker (e.g. S355) is not contradictory to one
            // consistently more specific grade (e.g. S355J2+N). Prefer the
            // specific value, but keep real grade/delivery-condition differences
            // as conflicts.
            static string Family(string value)
            {
                var m = Regex.Match(value.ToUpperInvariant(), @"(?<![A-Z0-9])(S\d{3})");
                return m.Success ? m.Groups[1].Value : "";
            }
            static string Compact(string value) => Regex.Replace(value.ToUpperInvariant(), @"[^A-Z0-9+]", "");

            var families = values.Select(x => Family(x.Value)).Where(x => x.Length > 0)
                .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            if (families.Count == 1)
            {
                var family = families[0];
                var specific = groups.Select(g => g.Key)
                    .Where(v => !string.Equals(Compact(v), family, StringComparison.OrdinalIgnoreCase))
                    .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
                if (specific.Count == 1)
                {
                    var chosenSpecific = specific[0];
                    merged.Findings.Add($"Materiał: ogólne oznaczenie {family} doprecyzowano na podstawie pozostałych dokumentów do {chosenSpecific}.");
                    return chosenSpecific;
                }

                // FIX12B scope guard: several drawings in one RFQ may legitimately use
                // S355, S355J2 and S355J2+N on different positions. Without a resolved
                // part binding this is NOT a project-wide contradiction. Keep the most
                // supported specific grade for density/costing, but downgrade the
                // variation to an informational/local-scope conflict.
                var chosenDominant = groups[0].Key;
                merged.Conflicts.Add(new InformationConflict
                {
                    Field = "Materiał — różne pozycje/rysunki",
                    Values = string.Join(" | ", groups.Select(g => g.Key)),
                    Sources = string.Join(" | ", values.Select(x => $"{x.Source}: {x.Value}")),
                    Resolution = $"Wszystkie oznaczenia należą do rodziny {family}; przyjęto dominujące {chosenDominant}. Różnice są traktowane jako lokalne do czasu resolvera detal↔rysunek, nie jako konflikt całego projektu.",
                    Level = RiskLevel.Low,
                    IsLocalVariation = true
                });
                merged.Findings.Add($"Materiał: wykryto kilka wariantów rodziny {family} na różnych rysunkach; nie podniesiono tego do konfliktu projektu.");
                return chosenDominant;
            }

            var distinctSourceEntities = values
                .Select(x => DocumentFamilyResolver.ExtractEntityKey(x.Source))
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
            if (distinctSourceEntities.Count > 1)
            {
                var chosenLocal = groups[0].Key;
                merged.Conflicts.Add(new InformationConflict
                {
                    Field = "Materiały — różne pozycje/rysunki",
                    Values = string.Join(" | ", groups.Select(g => g.Key)),
                    Sources = string.Join(" | ", values.Select(x => $"{x.Source}: {x.Value}")),
                    Resolution = $"FIX12D: różne gatunki pochodzą z różnych rodzin detali; zachowano je lokalnie. {chosenLocal} pozostaje jedynie wskazaniem pomocniczym do czasu pełnego mapowania materiał↔bryła.",
                    Level = RiskLevel.Low,
                    IsLocalVariation = true
                });
                merged.Findings.Add("FIX12D: różne gatunki na różnych numerach rysunków nie są konfliktem materiału całego projektu.");
                return chosenLocal;
            }

            merged.Conflicts.Add(new InformationConflict
            {
                Field = "Materiał",
                Values = string.Join(" | ", groups.Select(g => g.Key)),
                Sources = string.Join(" | ", values.Select(x => $"{x.Source}: {x.Value}")),
                Resolution = "Ta sama rodzina dokumentu zawiera różne rodziny materiałów; wymaga weryfikacji.",
                Level = RiskLevel.High
            });
            return groups[0].Key;
        }

        merged.MaterialHint = ChooseMaterial();
        merged.MaterialReference = ChooseText(
            "Referencja/specyfikacja materiałowa", x => x.MaterialReference, RiskLevel.Low,
            "Zachowano najczęściej występującą referencję; nie jest ona używana jako gatunek materiału.");
        if (!string.IsNullOrWhiteSpace(merged.MaterialReference))
        {
            var refSources = items.Where(x => string.Equals(x.MaterialReference, merged.MaterialReference, StringComparison.OrdinalIgnoreCase)).ToList();
            merged.MaterialReferenceConfidence = refSources.Select(x => x.MaterialReferenceConfidence).DefaultIfEmpty(0).Max();
            merged.MaterialReferenceEvidence = refSources.Select(x => x.MaterialReferenceEvidence).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "";
        }
        merged.WeldProcessCode = ChooseText(
            "Proces spawania", x => x.WeldProcessCode, RiskLevel.Medium,
            "Wybrano najczęściej występujący proces; różne procesy mogą dotyczyć różnych złączy.");
        merged.WeldTypeHint = ChooseText(
            "Typ spoiny", x => x.WeldTypeHint, RiskLevel.Medium,
            "Wybrano najczęściej występujący typ; routing zachowuje ostrzeżenie.");
        merged.SurfacePreparation = ChooseText(
            "Przygotowanie powierzchni", x => x.SurfacePreparation, RiskLevel.Medium,
            "Wybrano najczęściej występującą klasę przygotowania.");
        merged.CorrosionClass = ChooseText(
            "Klasa korozyjności", x => x.CorrosionClass, RiskLevel.Medium,
            "Wybrano najczęściej występującą klasę; sprawdź strefy powłok.");
        merged.PaintColour = ChooseText(
            "Kolor/RAL", x => x.PaintColour, RiskLevel.Low,
            "Wybrano najczęściej występujący kolor; konflikt nie zmienia czasu procesu.");

        // FIX13: keep weld evidence scoped to drawing/part families.  This lets
        // costing use a4 on one family and a13 on another instead of promoting one
        // value to the whole project.
        var weldBomRows = items.SelectMany(x => x.BomItems).ToList();
        double WeldFamilyQuantity(string family)
        {
            var qs = weldBomRows
                .Where(x => string.Equals(DocumentFamilyResolver.ExtractEntityKey(x.PartNumber), family, StringComparison.OrdinalIgnoreCase))
                .Select(x => x.Quantity)
                .Where(x => x > 0 && x <= 10000)
                .ToList();
            return qs.Count == 0 ? 1 : Math.Max(1, qs.Max());
        }

        string ModeText(IEnumerable<string> values)
        {
            return values.Where(x => !string.IsNullOrWhiteSpace(x))
                .GroupBy(x => x.Trim(), StringComparer.OrdinalIgnoreCase)
                .OrderByDescending(g => g.Count())
                .ThenByDescending(g => g.Key.Length)
                .Select(g => g.Key)
                .FirstOrDefault() ?? "";
        }

        merged.WeldFamilySignals = items
            .Select(x => new { Item = x, Family = DocumentFamilyResolver.ExtractEntityKey(x.SourceFile) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Family) &&
                        (x.Item.WeldSizeMm.HasValue || x.Item.WeldExplicitLengthMm is > 0 ||
                         !string.IsNullOrWhiteSpace(x.Item.WeldProcessCode)))
            .GroupBy(x => x.Family, StringComparer.OrdinalIgnoreCase)
            .Select(g =>
            {
                var size = g.Where(x => x.Item.WeldSizeMm.HasValue)
                    .OrderByDescending(x => x.Item.WeldExplicitLengthConfidence)
                    .ThenByDescending(x => x.Item.OcrCriticalConfidence ?? 0)
                    .FirstOrDefault();
                var explicitLength = g.Where(x => x.Item.WeldExplicitLengthMm is > 0)
                    .OrderByDescending(x => x.Item.WeldExplicitLengthConfidence)
                    .ThenByDescending(x => x.Item.WeldExplicitLengthMm)
                    .FirstOrDefault();
                var source = explicitLength?.Item ?? size?.Item ?? g.First().Item;
                var confidence = Math.Max(
                    explicitLength?.Item.WeldExplicitLengthConfidence ?? 0,
                    size?.Item.WeldSizeMm.HasValue == true ? (int)Math.Round(Math.Clamp(size.Item.OcrCriticalConfidence ?? 82, 55, 95)) : 0);
                return new WeldFamilySignal
                {
                    FamilyKey = g.Key,
                    SourceFile = source.SourceFile,
                    ProcessCode = ModeText(g.Select(x => x.Item.WeldProcessCode)),
                    SizeKind = size?.Item.WeldSizeKind ?? "",
                    SizeMm = size?.Item.WeldSizeMm,
                    ExplicitLengthMm = explicitLength?.Item.WeldExplicitLengthMm,
                    SideCount = g.Where(x => x.Item.WeldSideCount > 0).Select(x => x.Item.WeldSideCount).DefaultIfEmpty(1).Max(),
                    Quantity = WeldFamilyQuantity(g.Key),
                    Confidence = Math.Clamp(confidence > 0 ? confidence : 68, 35, 96),
                    Basis = $"FIX13 family scope: {g.Count()} reprezentacji dokumentu; ilość BOM ×{WeldFamilyQuantity(g.Key):0.###}."
                };
            })
            .OrderBy(x => x.FamilyKey, StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (merged.WeldFamilySignals.Count > 1)
            merged.Findings.Add($"FIX13 Weld Family Resolver: zachowano {merged.WeldFamilySignals.Count} lokalnych profili spoin; różne a/z i procesy nie są już parametrem globalnym.");

        // FIX14: keep NDT requirements scoped to the drawing family. Short tokens such
        // as UT/MT/PT/RT are taken only from the document analyzer's canonical keyword
        // set / recognised norms, not from arbitrary filename substrings.
        merged.NdtFamilySignals = items
            .Select(x => new { Item = x, Family = DocumentFamilyResolver.ExtractEntityKey(x.SourceFile) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Family))
            .Select(x => new
            {
                x.Item,
                x.Family,
                Methods = new[] { "UT", "MT", "PT", "RT" }
                    .Where(m => x.Item.Keywords.Any(k => string.Equals(k, m, StringComparison.OrdinalIgnoreCase)) ||
                                x.Item.Norms.Any(n => n.Contains($"-{m}", StringComparison.OrdinalIgnoreCase) ||
                                                     n.EndsWith($" {m}", StringComparison.OrdinalIgnoreCase)))
                    .ToList()
            })
            .Where(x => x.Methods.Count > 0)
            .GroupBy(x => x.Family, StringComparer.OrdinalIgnoreCase)
            .Select(g => new NdtFamilySignal
            {
                FamilyKey = g.Key,
                SourceFile = g.First().Item.SourceFile,
                Methods = g.SelectMany(x => x.Methods).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToList(),
                Confidence = (int)Math.Round(Math.Clamp(g.Average(x => x.Item.OcrCriticalConfidence ?? 82), 55, 96)),
                Basis = $"FIX14 NDT scope: {g.Count()} dokument(y) rodziny; metody przypisane lokalnie."
            })
            .OrderBy(x => x.FamilyKey, StringComparer.OrdinalIgnoreCase)
            .ToList();
        if (merged.NdtFamilySignals.Count > 0)
            merged.Findings.Add($"FIX14 NDT Scope Resolver: {merged.NdtFamilySignals.Count} rodzin z lokalnym zakresem badań.");

        merged.PaintZoneSignals = items
            .Select(x => new { Item = x, Family = DocumentFamilyResolver.ExtractEntityKey(x.SourceFile) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Family) &&
                        (!string.IsNullOrWhiteSpace(x.Item.CorrosionClass) ||
                         !string.IsNullOrWhiteSpace(x.Item.SurfacePreparation) ||
                         !string.IsNullOrWhiteSpace(x.Item.PaintColour) ||
                         x.Item.TotalDftMicron is > 0))
            .GroupBy(x => x.Family, StringComparer.OrdinalIgnoreCase)
            .Select(g =>
            {
                var best = g.OrderByDescending(x =>
                    (string.IsNullOrWhiteSpace(x.Item.CorrosionClass) ? 0 : 1) +
                    (string.IsNullOrWhiteSpace(x.Item.SurfacePreparation) ? 0 : 1) +
                    (string.IsNullOrWhiteSpace(x.Item.PaintColour) ? 0 : 1) +
                    (x.Item.TotalDftMicron is > 0 ? 1 : 0)).First();
                return new PaintZoneSignal
                {
                    FamilyKey = g.Key,
                    SourceFile = best.Item.SourceFile,
                    CorrosionClass = ModeText(g.Select(x => x.Item.CorrosionClass)),
                    Preparation = ModeText(g.Select(x => x.Item.SurfacePreparation)),
                    Colour = ModeText(g.Select(x => x.Item.PaintColour)),
                    DftMicron = g.Where(x => x.Item.TotalDftMicron is > 0).Select(x => x.Item.TotalDftMicron).OrderByDescending(x => x).FirstOrDefault(),
                    Confidence = (int)Math.Round(Math.Clamp(g.Average(x => x.Item.OcrCriticalConfidence ?? 80), 50, 95)),
                    Basis = $"FIX14 Paint Zone: {g.Count()} reprezentacji rodziny."
                };
            })
            .OrderBy(x => x.FamilyKey, StringComparer.OrdinalIgnoreCase)
            .ToList();
        if (merged.PaintZoneSignals.Select(x => x.CorrosionClass).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase).Count() > 1)
            merged.Findings.Add("FIX14 Painting Zones: wykryto różne klasy korozyjności w różnych rodzinach; nie są już traktowane jako jedna strefa całego projektu.");

        var weldSizes = items.Where(x => x.WeldSizeMm.HasValue)
            .Select(x => new
            {
                Value = x.WeldSizeMm!.Value,
                x.WeldSizeKind,
                x.SourceFile,
                EquivalentThroatMm = EquivalentWeldThroatMm(x.WeldSizeMm.Value, x.WeldSizeKind)
            }).ToList();
        if (weldSizes.Count > 0)
        {
            // Values a and z are not directly comparable.  Normalize both to the
            // effective fillet-weld throat before choosing the conservative input.
            // Example: z6.35 -> a≈4.49 mm, therefore a6 is the larger weld.
            var distinctSourceFamilies = weldSizes
                .Select(x => DocumentFamilyResolver.ExtractEntityKey(x.SourceFile))
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
            var localFamilyVariation = distinctSourceFamilies.Count > 1;
            var chosen = localFamilyVariation
                ? weldSizes
                    .GroupBy(x => $"{x.WeldSizeKind.ToUpperInvariant()}|{Math.Round(x.Value, 2):0.00}", StringComparer.OrdinalIgnoreCase)
                    .OrderByDescending(g => g.Count())
                    .ThenByDescending(g => g.Max(x => x.EquivalentThroatMm))
                    .First()
                    .OrderByDescending(x => x.EquivalentThroatMm)
                    .First()
                : weldSizes
                    .OrderByDescending(x => x.EquivalentThroatMm)
                    .ThenByDescending(x => x.Value)
                    .First();
            merged.WeldSizeKind = chosen.WeldSizeKind;
            merged.WeldSizeMm = chosen.Value;
            var distinct = weldSizes.Select(x => $"{x.WeldSizeKind}{x.Value:0.###}")
                .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            if (distinct.Count > 1)
            {
                merged.Conflicts.Add(new InformationConflict
                {
                    Field = localFamilyVariation ? "Wymiary spoin — różne złącza/rodziny" : "Wymiar spoiny a/z",
                    Values = string.Join(" | ", distinct),
                    Sources = string.Join(" | ", weldSizes.Select(x => $"{x.SourceFile}: {x.WeldSizeKind}{x.Value:0.###}")),
                    Resolution = localFamilyVariation
                        ? $"FIX12E: wymiary należą do różnych rodzin/złączy. Do modelu globalnego użyto modalnego {chosen.WeldSizeKind}{chosen.Value:0.###}; wartości lokalne pozostają w dowodach i nie są konfliktem całego projektu."
                        : $"Konserwatywnie przyjęto największy równoważny przekrój spoiny: {chosen.WeldSizeKind}{chosen.Value:0.###} (a≈{chosen.EquivalentThroatMm:0.###} mm).",
                    Level = localFamilyVariation ? RiskLevel.Low : RiskLevel.Medium,
                    IsLocalVariation = localFamilyVariation
                });
            }
        }

        merged.WeldSideCount = items.Select(x => x.WeldSideCount).Where(x => x > 0).DefaultIfEmpty(0).Max();
        merged.WeldSideCountConfirmed = items.Any(x => x.WeldSideCountConfirmed);
        merged.WeldIntermittent = items.Any(x => x.WeldIntermittent);
        merged.WeldIntermittentLengthMm = items.Select(x => x.WeldIntermittentLengthMm).FirstOrDefault(x => x.HasValue);
        merged.WeldPitchMm = items.Select(x => x.WeldPitchMm).FirstOrDefault(x => x.HasValue);

        var explicitWeldLengths = items
            .Where(x => x.WeldExplicitLengthMm is > 0)
            .Select(x => new
            {
                Value = x.WeldExplicitLengthMm!.Value,
                Confidence = x.WeldExplicitLengthConfidence,
                Evidence = x.WeldExplicitLengthEvidence,
                x.SourceFile
            })
            .OrderByDescending(x => x.Confidence)
            .ThenByDescending(x => x.Value)
            .ToList();

        var scopedExplicitWelds = merged.WeldFamilySignals
            .Where(x => x.ExplicitLengthMm is > 0 && x.Quantity > 0)
            .ToList();
        if (scopedExplicitWelds.Count >= 2)
        {
            var totalMm = scopedExplicitWelds.Sum(x => x.ExplicitLengthMm!.Value * Math.Max(1, x.Quantity));
            merged.WeldExplicitLengthMm = totalMm;
            merged.WeldExplicitLengthConfidence = (int)Math.Round(scopedExplicitWelds.Average(x => x.Confidence));
            merged.WeldExplicitLengthEvidence =
                $"FIX13: suma {scopedExplicitWelds.Count} rodzin spoin po ilościach BOM; bez podwójnego liczenia PDF/DXF.";
            merged.Findings.Add(
                $"FIX13 Weld Length: zsumowano lokalne jawne długości {scopedExplicitWelds.Count} rodzin = {totalMm / 1000.0:0.###} m.");
        }
        else if (explicitWeldLengths.Count > 0)
        {
            var chosenLength = explicitWeldLengths[0];
            merged.WeldExplicitLengthMm = chosenLength.Value;
            merged.WeldExplicitLengthConfidence = chosenLength.Confidence;
            merged.WeldExplicitLengthEvidence = chosenLength.Evidence;
            var minLength = explicitWeldLengths.Min(x => x.Value);
            var maxLength = explicitWeldLengths.Max(x => x.Value);
            if (explicitWeldLengths.Count > 1 && minLength > 0 && (maxLength - minLength) / minLength > 0.15)
            {
                var distinctLengthFamilies = explicitWeldLengths
                    .Select(x => DocumentFamilyResolver.ExtractEntityKey(x.SourceFile))
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .Count();
                merged.Conflicts.Add(new InformationConflict
                {
                    Field = distinctLengthFamilies > 1 ? "Długości spoin — różne rodziny/złącza" : "Łączna długość spoin",
                    Values = string.Join(" | ", explicitWeldLengths.Select(x => $"{x.Value / 1000.0:0.###} m")),
                    Sources = string.Join(" | ", explicitWeldLengths.Select(x => $"{x.SourceFile}: {x.Value / 1000.0:0.###} m")),
                    Resolution = distinctLengthFamilies > 1
                        ? "FIX13: lokalne długości zachowano per rodzina; pojedyncza wartość globalna jest tylko fallbackiem diagnostycznym."
                        : $"Pierwszeństwo ma jawna wartość z dokumentacji o najwyższej pewności: {chosenLength.Value / 1000.0:0.###} m; wymagany cross-check z geometrią STEP.",
                    Level = distinctLengthFamilies > 1 ? RiskLevel.Low : RiskLevel.Medium,
                    IsLocalVariation = distinctLengthFamilies > 1
                });
            }
        }

        merged.WeldIntermittencyConfirmed = items.Any(x => x.WeldIntermittencyConfirmed);
        merged.WeldAllAround = items.Any(x => x.WeldAllAround);
        merged.WeldGrooveAngleDeg = items.Where(x => x.WeldGrooveAngleDeg.HasValue)
            .Select(x => x.WeldGrooveAngleDeg).FirstOrDefault();
        merged.WeldRootGapMm = items.Where(x => x.WeldRootGapMm.HasValue)
            .Select(x => x.WeldRootGapMm).FirstOrDefault();

        var dfts = items.Where(x => x.TotalDftMicron.HasValue)
            .Select(x => new { Value = x.TotalDftMicron!.Value, x.SourceFile }).ToList();
        if (dfts.Count > 0)
        {
            merged.TotalDftMicron = dfts.Max(x => x.Value);
            var distinct = dfts.Select(x => Math.Round(x.Value, 1)).Distinct().ToList();
            if (distinct.Count > 1)
            {
                merged.Conflicts.Add(new InformationConflict
                {
                    Field = "DFT",
                    Values = string.Join(" | ", distinct.Select(x => $"{x:0.#} µm")),
                    Sources = string.Join(" | ", dfts.Select(x => $"{x.SourceFile}: {x.Value:0.#} µm")),
                    Resolution = $"Konserwatywnie przyjęto największą całkowitą DFT: {merged.TotalDftMicron:0.#} µm.",
                    Level = RiskLevel.Medium
                });
            }
        }

        merged.PaintLayers = items.SelectMany(x => x.PaintLayers)
            .Where(x => x.DftMicron > 0)
            .GroupBy(x => $"{NormalizePaintLayerName(x.Name)}|{x.DftMicron:0.###}|{Math.Max(1, x.CoatCount)}", StringComparer.OrdinalIgnoreCase)
            .Select(g => g.OrderByDescending(x => x.Name.Length).First())
            .ToList();
        if (merged.TotalDftMicron is > 0 && merged.PaintLayers.Count > 1)
        {
            var total = merged.TotalDftMicron.Value;
            var nonTotalLayers = merged.PaintLayers
                .Where(x => Math.Abs(x.DftMicron * Math.Max(1, x.CoatCount) - total) / Math.Max(total, 1) > 0.03)
                .ToList();
            var nonTotalSum = nonTotalLayers.Sum(x => x.DftMicron * Math.Max(1, x.CoatCount));
            if (nonTotalLayers.Count > 0 && Math.Abs(nonTotalSum - total) / Math.Max(total, 1) <= 0.05)
                merged.PaintLayers = nonTotalLayers;
        }
        // R9.1.0 data fusion: PDF and DXF of ONE drawing are duplicate
        // representations, while two different drawing families are independent parts.
        // Deduplicate multiplicity inside a family, then SUM across different families.
        string SourceFamily(DrawingIntelligence item)
        {
            var family = NormalizeDocumentFamily(item.SourceFile);
            if (!string.IsNullOrWhiteSpace(family)) return family;
            family = DocumentPairKey(item.SourceFile);
            return string.IsNullOrWhiteSpace(family)
                ? Path.GetFileNameWithoutExtension(item.SourceFile).ToUpperInvariant()
                : family;
        }

        var holesByFamily = items
            .GroupBy(SourceFamily, StringComparer.OrdinalIgnoreCase)
            .SelectMany(family => family.SelectMany(x => x.HoleRequirements)
                .GroupBy(x => $"{x.NominalDiameterMm:0.###}|{x.FitCode}|{x.ThreadCode}|{x.OperationHint}", StringComparer.OrdinalIgnoreCase)
                .Select(g => new { Key = g.Key, Signal = g.First(), Count = g.Max(x => Math.Max(1, x.Count)) }));
        merged.HoleRequirements = holesByFamily
            .GroupBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
            .Select(g =>
            {
                var first = g.First().Signal;
                first.Count = g.Sum(x => x.Count);
                return first;
            }).Take(250).ToList();
        merged.DimensionalTolerances = items.SelectMany(x => x.DimensionalTolerances)
            .GroupBy(x => $"{x.Kind}|{x.PlusMm:0.###}|{x.MinusMm:0.###}|{x.SymmetricMm:0.###}", StringComparer.OrdinalIgnoreCase)
            .Select(x => x.OrderByDescending(v => v.SourceText.Length).First()).Take(100).ToList();
        merged.GeometricTolerances = items.SelectMany(x => x.GeometricTolerances)
            .Where(x => x.ValueMm is > 0 and <= 100)
            .GroupBy(x => $"{x.Type}|{x.ValueMm:0.###}|{x.Datum}", StringComparer.OrdinalIgnoreCase)
            .Select(x => x.OrderByDescending(v => v.SourceText.Length).First()).Take(100).ToList();
        merged.PaintMaskMachinedSurfaces = items.Any(x => x.PaintMaskMachinedSurfaces);
        merged.PaintStripeCoatRequired = items.Any(x => x.PaintStripeCoatRequired);

        // Drawing scope overrides geometry only when the documentation is explicit.
        // AUTO is the normal external/accessible default and does not conflict with
        // one explicit note. If explicit documents disagree, use ALL as the safe
        // should-cost resolution and surface the conflict for review.
        var paintScopeItems = items
            .Where(x => !string.IsNullOrWhiteSpace(x.PaintScope) &&
                        !string.Equals(x.PaintScope, "AUTO", StringComparison.OrdinalIgnoreCase))
            .ToList();
        var distinctPaintScopes = paintScopeItems
            .Select(x => x.PaintScope.Trim().ToUpperInvariant())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        merged.PaintScopeConflict = items.Any(x => x.PaintScopeConflict) || distinctPaintScopes.Count > 1;
        if (distinctPaintScopes.Count == 1 && !merged.PaintScopeConflict)
            merged.PaintScope = distinctPaintScopes[0];
        else if (distinctPaintScopes.Count > 0)
            merged.PaintScope = "ALL";
        else
            merged.PaintScope = "AUTO";

        merged.PaintScopeEvidence = string.Join(" | ", paintScopeItems
            .Where(x => !string.IsNullOrWhiteSpace(x.PaintScopeEvidence))
            .Select(x => $"{x.SourceFile}: {x.PaintScopeEvidence}")
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(6));

        if (merged.PaintScopeConflict)
        {
            merged.Conflicts.Add(new InformationConflict
            {
                Field = "Zakres malowania",
                Values = string.Join(" | ", distinctPaintScopes),
                Sources = string.Join(" | ", paintScopeItems.Select(x =>
                    $"{x.SourceFile}: {x.PaintScope}{(string.IsNullOrWhiteSpace(x.PaintScopeEvidence) ? "" : $" ({x.PaintScopeEvidence})")}")),
                Resolution = "Konserwatywnie przyjęto malowanie powierzchni zewnętrznych i wewnętrznych; powierzchnie dolegania nadal nie są automatycznie malowane.",
                Level = RiskLevel.High
            });
        }
        else if (!string.Equals(merged.PaintScope, "AUTO", StringComparison.OrdinalIgnoreCase))
        {
            var label = merged.PaintScope switch
            {
                "ALL" => "zewnętrzne + wewnętrzne",
                "EXTERNAL_ONLY" => "tylko zewnętrzne",
                "INTERNAL_ONLY" => "tylko wewnętrzne",
                _ => merged.PaintScope
            };
            merged.Findings.Add($"Zakres malowania z dokumentacji: {label}.");
        }

        var quantityHints = items.Where(x => x.ProjectQuantityHint is >= 1 and <= 10000)
            .Select(x => x.ProjectQuantityHint!.Value).OrderBy(x => x).ToList();
        merged.ProjectQuantityHint = quantityHints.Count > 0 ? quantityHints[quantityHints.Count / 2] : null;
        if (!merged.TotalDftMicron.HasValue && merged.PaintLayers.Count > 0)
            merged.TotalDftMicron = merged.PaintLayers.Sum(x => x.DftMicron * Math.Max(1, x.CoatCount));

        // Collapse complete, semantically identical BOM exports before building the
        // hierarchy.  Mass corroboration below still keeps every source, but the UI
        // must not show the same four rows three times merely because the customer
        // copied/exported one BOM under different filenames or inside a nested ZIP.
        static string BomDocumentSignature(DrawingIntelligence item) => string.Join("\n",
            item.BomItems
                .Select(x => string.Join("|",
                    x.PartNumber.Trim().ToUpperInvariant(),
                    x.Description.Trim().ToUpperInvariant(),
                    x.Quantity.ToString("0.######", CultureInfo.InvariantCulture),
                    x.Level.ToString(CultureInfo.InvariantCulture),
                    x.Position.Trim().ToUpperInvariant(),
                    x.Material.Trim().ToUpperInvariant(),
                    x.MassKgEach?.ToString("0.######", CultureInfo.InvariantCulture) ?? "",
                    x.EffectiveTotalMassKg.ToString("0.######", CultureInfo.InvariantCulture)))
                .OrderBy(x => x, StringComparer.OrdinalIgnoreCase));

        var canonicalBomDocuments = items
            .Where(x => x.BomItems.Count > 0)
            .GroupBy(BomDocumentSignature, StringComparer.OrdinalIgnoreCase)
            .Select(group =>
            {
                var copies = group.OrderBy(x => x.SourceFile, StringComparer.OrdinalIgnoreCase).ToList();
                if (copies.Count > 1)
                {
                    merged.Findings.Add(
                        $"BOM: zwinięto {copies.Count} identyczne zestawienia do jednego widoku ({string.Join(", ", copies.Select(x => x.SourceFile))}). Źródła nadal potwierdzają masę, ale nie mnożą pozycji.");
                }
                return copies[0];
            })
            .ToList();

        // Same semantic BOM line exported as PDF/XLSX/CSV from the same document
        // family is one item, not several purchased parts. Different subassembly
        // families remain independent.
        merged.BomItems = canonicalBomDocuments
            .GroupBy(SourceFamily, StringComparer.OrdinalIgnoreCase)
            .SelectMany(family => family.SelectMany(x => x.BomItems)
                .GroupBy(x => $"{x.PartNumber.Trim()}|{x.Description.Trim()}|{x.Quantity:0.###}|{x.Material.Trim()}|{x.EffectiveTotalMassKg:0.###}", StringComparer.OrdinalIgnoreCase)
                .Select(g => g.First()))
            .Take(2000)
            .ToList();

        var bomMassSources = items
            .Where(x => x.BomTotalMassKg is > 0 && x.BomMassRowCount > 0)
            .ToList();
        merged.BomMassSourceCount = bomMassSources.Count;
        if (bomMassSources.Count == 1)
        {
            merged.BomTotalMassKg = bomMassSources[0].BomTotalMassKg;
            merged.BomMassRowCount = bomMassSources[0].BomMassRowCount;
            merged.BomPositiveMassRowCount = bomMassSources[0].BomPositiveMassRowCount;
        }
        else if (bomMassSources.Count > 1)
        {
            var values = bomMassSources.Select(x => x.BomTotalMassKg!.Value).OrderBy(x => x).ToList();
            var min = values.First();
            var max = values.Last();
            if (max / Math.Max(0.001, min) <= 1.01)
            {
                // The same full BOM may appear twice (e.g. XLSX + CSV export).
                // Equal totals are safe to treat as one corroborated value.
                merged.BomTotalMassKg = values[values.Count / 2];
                merged.BomMassRowCount = bomMassSources.Max(x => x.BomMassRowCount);
                merged.BomPositiveMassRowCount = bomMassSources.Max(x => x.BomPositiveMassRowCount);
                merged.Findings.Add($"Masa BOM potwierdzona przez {bomMassSources.Count} zgodne źródła: {merged.BomTotalMassKg:0.###} kg.");
            }
            else
            {
                merged.Warnings.Add($"Wiele tabel BOM zawiera różne masy łączne ({min:0.###}–{max:0.###} kg). Nie sumowano ich automatycznie; mogą to być BOM-y podzespołów lub zestawienie + arkusze szczegółowe.");
            }
        }


        // R9.1.0 mass scope: a valid part/subassembly weight must not silently
        // become the mass of the whole quote. Prefer explicit assembly/BOM totals.
        // If scope is unknown, promote it only when all corroborating sources belong
        // to one drawing family; multiple unrelated part drawings remain diagnostic.
        static int MassScopeRank(string? scope) => (scope ?? "").ToUpperInvariant() switch
        {
            "ASSEMBLY_TOTAL" => 4,
            "BOM_TOTAL" => 3,
            "SUBASSEMBLY" => 2,
            "PART" => 1,
            _ => 0
        };

        var documentMassSources = items
            .Where(x => x.DocumentMassKg is > 0 && x.DocumentMassConfidence >= 45)
            .Select(x => new
            {
                Value = x.DocumentMassKg!.Value, Confidence = x.DocumentMassConfidence,
                Scope = string.IsNullOrWhiteSpace(x.DocumentMassScope) ? "UNKNOWN" : x.DocumentMassScope.ToUpperInvariant(),
                Family = SourceFamily(x), x.SourceFile, x.DocumentMassEvidence
            })
            .OrderByDescending(x => MassScopeRank(x.Scope))
            .ThenByDescending(x => x.Confidence)
            .ToList();
        if (documentMassSources.Count > 0)
        {
            var highestRank = documentMassSources.Max(x => MassScopeRank(x.Scope));
            var ranked = documentMassSources.Where(x => MassScopeRank(x.Scope) == highestRank).ToList();
            var distinctFamilies = ranked.Select(x => x.Family).Distinct(StringComparer.OrdinalIgnoreCase).ToList();

            // Unknown/part masses from several different drawings are not a project total.
            // Only an explicit BOM/assembly scope, or one logical drawing family, may
            // become the quote mass.  Different detail drawings are additive BOM rows,
            // not competing whole-project totals.
            var safeToPromote = highestRank >= 3 || distinctFamilies.Count == 1;
            if (safeToPromote)
            {
                var best = ranked[0];
                var corroborating = ranked
                    .Where(x => Math.Abs(x.Value - best.Value) / Math.Max(best.Value, 0.001) <= 0.02)
                    .ToList();
                merged.DocumentMassKg = corroborating.Select(x => x.Value).OrderBy(x => x).ElementAt(corroborating.Count / 2);
                merged.DocumentMassConfidence = Math.Min(98, Math.Max(best.Confidence, corroborating.Count >= 2 ? 92 : best.Confidence));
                merged.DocumentMassScope = highestRank >= 3 ? best.Scope : best.Scope;
                merged.DocumentMassEvidence = string.Join(" | ", corroborating.Select(x => $"{x.SourceFile}: {x.DocumentMassEvidence}").Take(6));
                if (corroborating.Count >= 2)
                    merged.Findings.Add($"Masa dokumentacji ({merged.DocumentMassScope}) potwierdzona przez {corroborating.Count} zgodne źródła: {merged.DocumentMassKg:0.###} kg.");

                var conflicts = ranked.Where(x => Math.Abs(x.Value - merged.DocumentMassKg.Value) / Math.Max(merged.DocumentMassKg.Value, 0.001) > 0.08).ToList();
                if (conflicts.Count > 0)
                    merged.Conflicts.Add(new InformationConflict
                    {
                        Field = "Masa z dokumentacji",
                        Values = string.Join(" | ", ranked.Select(x => $"{x.Value:0.###} kg").Distinct()),
                        Sources = string.Join(" | ", ranked.Select(x => $"{x.SourceFile}: {x.Value:0.###} kg ({x.Scope})")),
                        Resolution = $"Przyjęto wartość o najwyższym zakresie/pewności: {merged.DocumentMassKg:0.###} kg; mas detali/podzespołów nie sumowano.",
                        Level = RiskLevel.High
                    });
            }
            else
            {
                merged.Warnings.Add($"Wykryto {documentMassSources.Count} mas detali z {distinctFamilies.Count} różnych rodzin rysunków. Nie potraktowano ich jako konkurencyjnych mas całego projektu; masa projektu pochodzi z BOM/STEP.");
                foreach (var family in documentMassSources.GroupBy(x => x.Family, StringComparer.OrdinalIgnoreCase))
                {
                    var familyValues = family.Select(x => x.Value).Distinct().ToList();
                    if (familyValues.Count < 2)
                        continue;
                    var minFamily = familyValues.Min();
                    var maxFamily = familyValues.Max();
                    if ((maxFamily - minFamily) / Math.Max(maxFamily, 0.001) <= 0.08)
                        continue;
                    merged.Conflicts.Add(new InformationConflict
                    {
                        Field = $"Masa rysunku {family.Key}",
                        Values = string.Join(" | ", familyValues.Select(x => $"{x:0.###} kg")),
                        Sources = string.Join(" | ", family.Select(x => $"{x.SourceFile}: {x.Value:0.###} kg")),
                        Resolution = "Konflikt pozostawiono w obrębie tej samej rodziny rysunku; nie wpływa on na masę całego projektu, gdy istnieje BOM/STEP.",
                        Level = RiskLevel.High
                    });
                }
            }
        }

        var surfaceSources = items
            .Where(x => x.DocumentSurfaceAreaM2 is > 0 && x.DocumentSurfaceAreaConfidence >= 50)
            .OrderByDescending(x => x.DocumentSurfaceAreaConfidence).ToList();
        if (surfaceSources.Count > 0)
        {
            var best = surfaceSources[0];
            merged.DocumentSurfaceAreaM2 = best.DocumentSurfaceAreaM2;
            merged.DocumentSurfaceAreaConfidence = best.DocumentSurfaceAreaConfidence;
            merged.DocumentSurfaceAreaEvidence = $"{best.SourceFile}: {best.DocumentSurfaceAreaEvidence}";
        }

        return merged;
    }

    private static void GuardUnscopedBomMaterial(
        DrawingIntelligence merged,
        IReadOnlyList<DrawingIntelligence> sourceItems,
        IReadOnlyList<ProjectDocument> activeDocuments)
    {
        if (string.IsNullOrWhiteSpace(merged.MaterialHint))
            return;

        var stepDocuments = activeDocuments
            .Where(x => x.Kind == DocumentKind.Step && !x.ExcludeFromAnalysis && x.IsActiveRevision)
            .GroupBy(x => NormalizeDocumentFamily(x.Name), StringComparer.OrdinalIgnoreCase)
            .Select(x => x.First())
            .ToList();
        if (stepDocuments.Count < 4)
            return;

        // Only question a global material when every source supporting the chosen
        // value is a BOM. A drawing/technical note carrying the same grade is direct
        // evidence that the material applies beyond an isolated parts list.
        var materialSources = sourceItems
            .Where(x => string.Equals(
                x.MaterialHint?.Trim(), merged.MaterialHint.Trim(), StringComparison.OrdinalIgnoreCase))
            .ToList();
        if (materialSources.Count == 0 || materialSources.Any(x => x.BomItems.Count == 0))
            return;

        static string ScopeKey(string? value) => Regex.Replace(
            (value ?? "").ToUpperInvariant(), @"[^A-Z0-9]+", "");
        static bool StrongScopeMatch(string left, string right)
        {
            if (left.Length < 5 || right.Length < 5)
                return false;
            if (string.Equals(left, right, StringComparison.OrdinalIgnoreCase))
                return true;
            var shorter = left.Length <= right.Length ? left : right;
            var longer = left.Length > right.Length ? left : right;
            return shorter.Length >= 8 && longer.Contains(shorter, StringComparison.OrdinalIgnoreCase);
        }

        var bomKeys = materialSources
            .SelectMany(x => x.BomItems)
            .SelectMany(x => new[] { ScopeKey(x.PartNumber), ScopeKey(x.Description) })
            .Where(x => x.Length >= 5)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        if (bomKeys.Count == 0)
            return;

        var matchedSteps = stepDocuments.Count(step =>
        {
            var stepKey = ScopeKey(Path.GetFileNameWithoutExtension(step.Name));
            return bomKeys.Any(bomKey => StrongScopeMatch(stepKey, bomKey));
        });
        var coverage = matchedSteps / (double)stepDocuments.Count;
        if (coverage >= 0.25)
            return;

        var selectedMaterial = merged.MaterialHint.Trim();
        var sourceNames = materialSources.Select(x => x.SourceFile)
            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        merged.MaterialHint = "";
        merged.Warnings.Add(
            $"Materiał {selectedMaterial} występuje tylko w lokalnych BOM-ach i pasuje do {matchedSteps} z {stepDocuments.Count} niezależnych rodzin STEP. Nie zastosowano go globalnie; do obliczeń użyto jawnie oznaczonej gęstości zastępczej.");
        merged.Findings.Add(
            $"Zakres materiału BOM: {selectedMaterial} pozostawiono na pozycjach BOM, ale nie przypisano wszystkim modelom STEP.");
        merged.Conflicts.Add(new InformationConflict
        {
            Field = "Zakres materiału BOM",
            Values = $"{selectedMaterial} | brak globalnego przypisania",
            Sources = string.Join(" | ", sourceNames),
            Resolution = $"Nie zastosowano materiału globalnie: dopasowanie nazw BOM↔STEP wynosi {matchedSteps}/{stepDocuments.Count}. Materiał należy potwierdzić dla właściwego złożenia.",
            Level = RiskLevel.High
        });
    }

    private static List<ProjectDocument> SelectActiveRevisions(IReadOnlyList<ProjectDocument> documents)
    {
        foreach (var doc in documents)
        {
            if (doc.ExcludeFromAnalysis)
            {
                doc.IsActiveRevision = false;
                continue;
            }

            doc.IsActiveRevision = true;
            if (string.Equals(doc.Status, "Starsza rewizja", StringComparison.OrdinalIgnoreCase))
            {
                doc.Status = "Oczekuje";
                doc.Summary = "";
            }
        }

        // Archive/OLD marker: ignore only when a non-archival sibling from the same
        // filename family and extension exists. This avoids silently discarding the only file.
        var archiveRx = new Regex(@"(?ix)(?:^|[ _\-.])(OLD|ARCHIVE|ARCHIW(?:ALNY)?)(?=$|[ _\-.])");
        foreach (var doc in documents.Where(x => archiveRx.IsMatch(Path.GetFileNameWithoutExtension(x.Name))))
        {
            var family = NormalizeDocumentFamily(doc.Name);
            var ext = Path.GetExtension(doc.Name);
            var hasNewerSibling = documents.Any(other =>
                !ReferenceEquals(other, doc) &&
                !archiveRx.IsMatch(Path.GetFileNameWithoutExtension(other.Name)) &&
                string.Equals(Path.GetExtension(other.Name), ext, StringComparison.OrdinalIgnoreCase) &&
                string.Equals(NormalizeDocumentFamily(other.Name), family, StringComparison.OrdinalIgnoreCase));
            if (hasNewerSibling)
            {
                doc.IsActiveRevision = false;
                doc.Status = "Starsza rewizja";
                doc.Summary = "Automatycznie pominięto plik OLD/ARCHIVE; znaleziono aktywny odpowiednik.";
            }
        }

        var parsed = documents
            .Where(d => d.IsActiveRevision)
            .Select(d => new { Doc = d, Rev = ParseRevision(d.Name) })
            .Where(x => x.Rev is not null)
            .ToList();

        foreach (var group in parsed.GroupBy(
                     x => $"{x.Rev!.Value.Family}|{Path.GetExtension(x.Doc.Name)}",
                     StringComparer.OrdinalIgnoreCase))
        {
            var entries = group.ToList();
            if (entries.Count < 2)
                continue;

            var best = entries
                .OrderByDescending(x => x.Rev!.Value.Rank)
                .ThenByDescending(x => x.Doc.Name, StringComparer.OrdinalIgnoreCase)
                .First();

            foreach (var item in entries.Where(x => !ReferenceEquals(x.Doc, best.Doc)))
            {
                item.Doc.IsActiveRevision = false;
                item.Doc.Status = "Starsza rewizja";
                item.Doc.Summary = $"Automatycznie pominięto; wybrano {best.Doc.Name}";
            }
        }

        return documents.Where(x => x.IsActiveRevision).ToList();
    }


    private static void ApplyHoleSemantics(GeometrySummary geometry, DrawingIntelligence drawing)
    {
        if (!geometry.Available || drawing.HoleRequirements.Count == 0)
            return;

        // Coarse metric tap-drill diameters. Used only to reconcile a drawing callout
        // such as M12 with a geometric core hole around Ø10.2; it never invents a thread.
        var metricTap = new Dictionary<int, double>
        {
            [3]=2.5, [4]=3.3, [5]=4.2, [6]=5.0, [8]=6.8, [10]=8.5,
            [12]=10.2, [14]=12.0, [16]=14.0, [18]=15.5, [20]=17.5,
            [22]=19.5, [24]=21.0, [27]=24.0, [30]=26.5, [33]=29.5, [36]=32.0
        };

        foreach (var part in geometry.Parts)
        foreach (var hole in part.Holes)
        {
            HoleRequirementSignal? best = null;
            var bestDelta = double.MaxValue;

            foreach (var req in drawing.HoleRequirements)
            {
                if (!req.NominalDiameterMm.HasValue)
                    continue;

                var target = req.NominalDiameterMm.Value;
                var tolerance = Math.Max(0.15, target * 0.006); // drawing/model rounding tolerance only

                if (!string.IsNullOrWhiteSpace(req.ThreadCode))
                {
                    var nominalInt = (int)Math.Round(target);
                    if (metricTap.TryGetValue(nominalInt, out var drill))
                    {
                        target = drill;
                        tolerance = Math.Max(0.25, drill * 0.025);
                    }
                    else
                    {
                        // Thread geometry may be modeled at minor diameter; do not bind by
                        // nominal M diameter when no safe tap-drill reference exists.
                        continue;
                    }
                }

                var delta = Math.Abs(hole.DiameterMm - target);
                if (delta <= tolerance && delta < bestDelta)
                {
                    best = req;
                    bestDelta = delta;
                }
            }

            if (best is null)
                continue;

            hole.FitCode = best.FitCode;
            hole.ThreadCode = best.ThreadCode;
            hole.FitConfirmed = best.FitConfirmed;
            hole.PrecisionMachined = best.PrecisionMachined;
            hole.ReamedLikely = best.ReamedLikely;
            hole.RequiresDrill = best.RequiresDrill;
            hole.RequiresReam = best.RequiresReam;
            hole.RequiresTap = best.RequiresTap;
            hole.RequiresBore = best.RequiresBore;
            hole.RequiresCnc = best.RequiresCnc;
            hole.CanThermalCut = best.CanThermalCut;
            hole.SemanticType = !string.IsNullOrWhiteSpace(best.ThreadCode) ? "gwintowany"
                : string.Equals(best.OperationHint, "BOLT_CLEARANCE", StringComparison.OrdinalIgnoreCase) ? "pod śrubę"
                : best.FitConfirmed ? "pasowany"
                : best.ReamedLikely ? "rozwiercany"
                : best.PrecisionMachined ? "precyzyjny"
                : "";
        }
    }

    private static PackageIntelligence AnalyzePackage(IReadOnlyList<ProjectDocument> documents)
    {
        static bool IsNeutralSkip(ProjectDocument d)
        {
            var status = d.Status ?? "";
            return !d.IsActiveRevision || d.ExcludeFromAnalysis || d.IsContentDuplicate ||
                   d.Role is DocumentRole.Reference or DocumentRole.SoftwareGraphic or DocumentRole.PreviousReport ||
                   status.StartsWith("Pominięto — brak danych technicznych", StringComparison.OrdinalIgnoreCase) ||
                   status.StartsWith("Pominięto — identyczna treść", StringComparison.OrdinalIgnoreCase) ||
                   status.StartsWith("Starsza rewizja", StringComparison.OrdinalIgnoreCase);
        }

        var neutralSkipped = documents.Count(IsNeutralSkip);
        var relevantDocuments = documents.Where(x => !IsNeutralSkip(x)).ToList();
        var result = new PackageIntelligence
        {
            DocumentCount = documents.Count,
            RelevantDocumentCount = relevantDocuments.Count,
            NeutralSkippedDocumentCount = neutralSkipped,
            SkippedDocumentCount = relevantDocuments.Count(x =>
                (x.Status ?? "").StartsWith("Pominięto", StringComparison.OrdinalIgnoreCase)),
            WarningDocumentCount = relevantDocuments.Count(x =>
                string.Equals(x.Status, "Uwaga", StringComparison.OrdinalIgnoreCase) ||
                (x.Status ?? "").Contains("Timeout", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(x.Status, "Błąd", StringComparison.OrdinalIgnoreCase))
        };

        result.IgnoredOlderRevisionFiles.AddRange(
            documents.Where(x => !x.IsActiveRevision)
                .Select(x => x.Name));

        var families = new Dictionary<string, List<(ProjectDocument Doc, RevisionToken Rev)>>(StringComparer.OrdinalIgnoreCase);
        foreach (var doc in documents)
        {
            var parsed = ParseRevision(doc.Name);
            if (parsed is null)
                continue;

            var rev = parsed.Value;
            result.RevisionSignals.Add(rev.Label);
            var key = $"{rev.Family}|{Path.GetExtension(doc.Name)}";
            if (!families.TryGetValue(key, out var list))
            {
                list = [];
                families[key] = list;
            }
            list.Add((doc, rev));
        }

        result.RevisionSignals = result.RevisionSignals
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x, StringComparer.OrdinalIgnoreCase)
            .ToList();

        foreach (var pair in families.Where(x => x.Value.Select(v => v.Rev.Label).Distinct(StringComparer.OrdinalIgnoreCase).Count() > 1))
        {
            var values = pair.Value;
            result.MultipleRevisionsDetected = true;
            result.RevisionFamilies.Add($"{pair.Key}: {string.Join("/", values.Select(x => x.Rev.Label).Distinct().OrderBy(x => x))}");
            var active = values.Where(x => x.Doc.IsActiveRevision).ToList();
            result.SelectedRevisionFiles.AddRange(active.Select(x => x.Doc.Name));
            result.IgnoredOlderRevisionFiles.AddRange(values.Where(x => !x.Doc.IsActiveRevision).Select(x => x.Doc.Name));
            result.IgnoredOlderRevisionFiles = result.IgnoredOlderRevisionFiles.Distinct(StringComparer.OrdinalIgnoreCase).ToList();

            var allNumeric = values.All(x => x.Rev.Kind == "NUM");
            var allAlpha = values.All(x => x.Rev.Kind == "ALPHA");
            if (!allNumeric && !allAlpha)
                result.RevisionSelectionConfident = false;
        }

        // Group documents that look like one quote item (CAD + drawing + BOM + notes).
        result.DocumentGroups = documents
            .GroupBy(x => NormalizeDocumentFamily(x.Name), StringComparer.OrdinalIgnoreCase)
            .Where(x => !string.IsNullOrWhiteSpace(x.Key))
            .Select(g => new DocumentGroupInfo
            {
                Key = g.Key,
                FileCount = g.Count(),
                ActiveFileCount = g.Count(x => x.IsActiveRevision),
                Files = g.Select(x => x.Name).OrderBy(x => x).ToList(),
                StepFiles = g.Where(x => x.Kind == DocumentKind.Step && x.IsActiveRevision).Select(x => x.Name).ToList(),
                DrawingFiles = g.Where(x => (x.Kind == DocumentKind.Pdf || x.Kind == DocumentKind.Image || x.Kind == DocumentKind.Dxf || x.Kind == DocumentKind.Dwg) && x.IsActiveRevision).Select(x => x.Name).ToList(),
                BomFiles = g.Where(x => (x.Kind == DocumentKind.Excel || x.Kind == DocumentKind.Text) && x.IsActiveRevision).Select(x => x.Name).ToList()
            })
            .OrderByDescending(x => x.FileCount)
            .ThenBy(x => x.Key)
            .Take(500)
            .ToList();

        return result;
    }

    private readonly record struct RevisionToken(string Family, string Label, long Rank, string Kind);

    private static RevisionToken? ParseRevision(string fileName)
    {
        var stem = Path.GetFileNameWithoutExtension(fileName);

        // FIX14: many customer drawings encode the revision as the single letter
        // immediately after a long drawing number, e.g. 94729371312_C_ZEZ_1.
        // The final _1/_2/_3 is a sheet/representation marker and must not become a
        // revision. Restrict this rule to known document-role tokens to avoid treating
        // arbitrary part-name letters as revisions.
        var customerPattern = new Regex(
            @"(?ix)^(?<part>\d{8,14})[ _.-](?<rev>[A-Z])(?=[ _.-](?:ZEZ|ZTL|ZTS|STL|ASM|ASSY|DWG)(?:[ _.-]|$))");
        var customerMatch = customerPattern.Match(stem);
        if (customerMatch.Success)
        {
            var customerLabel = customerMatch.Groups["rev"].Value.ToUpperInvariant();
            var customerFamily = customerPattern.Replace(stem, customerMatch.Groups["part"].Value);
            customerFamily = Regex.Replace(customerFamily, @"[ _\-.]+", " ").Trim();
            var customerRank = char.ToUpperInvariant(customerLabel[0]) - 'A' + 1;
            return new RevisionToken(customerFamily, customerLabel, customerRank, "ALPHA_CUSTOMER");
        }

        // Conservative revision parsing:
        // - REV/REVISION may carry 1-4 alphanumeric characters (REV_A, REV02).
        // - short R notation is accepted only for digits or ONE letter (R1, RA).
        // This deliberately rejects normal part tokens such as RIB, RHS, RING.
        var rx = new Regex(
            @"(?ix)(?:^|[ _\-.])(?:" +
            @"REV(?:ISION)?[ _\-.]*(?<rev>[A-Z0-9]{1,4})" +
            @"|R(?<shortrev>(?:[0-9]{1,4}(?![ _\-.][0-9])|[A-Z]))" +
            @")(?=$|[ _\-.])");
        var match = rx.Match(stem);
        if (!match.Success)
            return null;

        var label = (match.Groups["rev"].Success
            ? match.Groups["rev"].Value
            : match.Groups["shortrev"].Value).ToUpperInvariant();
        var family = rx.Replace(stem, " ");
        family = Regex.Replace(family, @"[ _\-.]+", " ").Trim();
        if (string.IsNullOrWhiteSpace(family))
            family = stem;

        if (long.TryParse(label, out var number))
            return new RevisionToken(family, label, number, "NUM");

        if (label.All(char.IsLetter))
        {
            long rank = 0;
            foreach (var c in label)
                rank = rank * 26 + (char.ToUpperInvariant(c) - 'A' + 1);
            return new RevisionToken(family, label, rank, "ALPHA");
        }

        long lexical = 0;
        foreach (var c in label)
            lexical = unchecked(lexical * 131 + c);
        return new RevisionToken(family, label, lexical, "MIXED");
    }

    private static Dictionary<string, double> BuildBomQuantityMap(IEnumerable<BomItemSignal> items)
    {
        var map = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        foreach (var item in items.Where(x => x.Quantity > 0 && x.Quantity <= 100000))
        {
            var key = DocumentFamilyResolver.RoutingKey(item.PartNumber);
            if (string.IsNullOrWhiteSpace(key))
                continue;
            // Quantity in ST/PCS should be piece-like. Reject obvious OCR column
            // shifts such as 561,626 being read as quantity from a neighbouring KG cell.
            if (item.Quantity > 100 && Math.Abs(item.Quantity - Math.Round(item.Quantity)) > 0.001)
                continue;
            // Repeated PDF/XLSX representations of the same BOM line are evidence,
            // not additional production quantity.  Keep the highest corroborated qty.
            if (!map.TryGetValue(key, out var existing) || item.Quantity > existing)
                map[key] = item.Quantity;
        }
        return map;
    }

    private static void ApplyBomQuantitiesTo2dDrawing(
        IReadOnlyList<DrawingIntelligence> sourceItems,
        DrawingIntelligence merged,
        IReadOnlyDictionary<string, double> quantityByFamily)
    {
        static HoleRequirementSignal Clone(HoleRequirementSignal x, int count) => new()
        {
            NominalDiameterMm = x.NominalDiameterMm,
            Count = count,
            FitCode = x.FitCode,
            ThreadCode = x.ThreadCode,
            OperationHint = x.OperationHint,
            ReamedLikely = x.ReamedLikely,
            FitConfirmed = x.FitConfirmed,
            PrecisionMachined = x.PrecisionMachined,
            RequiresDrill = x.RequiresDrill,
            RequiresReam = x.RequiresReam,
            RequiresTap = x.RequiresTap,
            RequiresBore = x.RequiresBore,
            RequiresCnc = x.RequiresCnc,
            CanThermalCut = x.CanThermalCut,
            SourceText = x.SourceText
        };

        string Family(DrawingIntelligence item)
        {
            return DocumentFamilyResolver.RoutingKey(item.SourceFile);
        }

        var weighted = sourceItems
            .Where(x => x.HoleRequirements.Count > 0)
            .GroupBy(Family, StringComparer.OrdinalIgnoreCase)
            .SelectMany(family =>
            {
                var qty = quantityByFamily.TryGetValue(family.Key, out var q) ? Math.Max(1, q) : 1.0;
                return family.SelectMany(x => x.HoleRequirements)
                    .GroupBy(x => $"{x.NominalDiameterMm:0.###}|{x.FitCode}|{x.ThreadCode}|{x.OperationHint}", StringComparer.OrdinalIgnoreCase)
                    .Select(g =>
                    {
                        var signal = g.OrderByDescending(x => x.SourceText.Length).First();
                        var perPart = g.Max(x => Math.Max(1, x.Count));
                        var total = (int)Math.Clamp(Math.Round(perPart * qty), 1, 1_000_000);
                        return new { Key = g.Key, Signal = Clone(signal, total) };
                    });
            })
            .GroupBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
            .Select(g =>
            {
                var first = g.First().Signal;
                first.Count = g.Sum(x => x.Signal.Count);
                return first;
            })
            .Take(500)
            .ToList();

        if (weighted.Count > 0)
            merged.HoleRequirements = weighted;
    }

    private static void ApplyEmbeddedHistoricalMetric(
        QuoteProject project,
        AnalysisResult result,
        HistoricalMetricData metric)
    {
        static double R(double value) => Math.Round(Math.Max(0, value), 3);
        var combined = metric.CombinedWeldAssemblyHours;
        var modelWeld = result.Processes.FirstOrDefault(x => string.Equals(x.Code, "WELD", StringComparison.OrdinalIgnoreCase))?.BaseHours ?? 0;
        var modelAssy = result.Processes.FirstOrDefault(x => string.Equals(x.Code, "ASSY", StringComparison.OrdinalIgnoreCase))?.BaseHours ?? 0;
        double weldActual = 0, assyActual = 0;
        string splitBasis;
        if (combined > 0 && modelWeld > 0.01 && modelAssy > 0.01)
        {
            var total = modelWeld + modelAssy;
            weldActual = combined * modelWeld / total;
            assyActual = combined - weldActual;
            splitBasis = $"3401 {combined:0.##} h rozdzielono tylko do podglądu wg proporcji modelu WELD/ASSY; dokładne 3401 pozostaje w SskHours.";
        }
        else if (combined > 0 && modelWeld > 0.01)
        {
            weldActual = combined;
            splitBasis = $"3401 {combined:0.##} h przypisano do WELD w uproszczonym widoku; dokładne 3401 pozostaje zachowane.";
        }
        else if (combined > 0 && modelAssy > 0.01)
        {
            assyActual = combined;
            splitBasis = $"3401 {combined:0.##} h przypisano do ASSY w uproszczonym widoku; dokładne 3401 pozostaje zachowane.";
        }
        else
        {
            splitBasis = combined > 0
                ? $"3401 {combined:0.##} h zachowano jako dokładne SSK bez sztucznego podziału WELD/ASSY."
                : "Brak godzin 3401.";
        }

        project.Actuals = new ProductionActuals
        {
            CompletedAt = File.Exists(metric.WorkbookPath) ? File.GetLastWriteTime(metric.WorkbookPath) : DateTime.Now,
            SskHours = metric.SskHours
                .Where(x => double.IsFinite(x.Value) && x.Value >= 0)
                .ToDictionary(x => x.Key, x => R(x.Value), StringComparer.OrdinalIgnoreCase),
            CuttingHours = R(metric.CuttingHours),
            MachiningHours = R(metric.CncHours),
            WeldingHours = R(weldActual),
            AssemblyHours = R(assyActual),
            SurfaceHours = R(metric.SurfaceHours),
            ActualTotalCostPln = metric.HistoricalTotalCostPln ?? 0,
            Note = $"Automatyczny import historii z {Path.GetFileName(metric.WorkbookPath)}. {splitBasis} {metric.AggregationBasis}"
        };

        project.HistoryImport = new HistoryImportMetadata
        {
            AnalysisEngineVersion = "1.0",
            SourceKey = Path.GetFileName(metric.WorkbookPath),
            SourceFolder = Path.GetDirectoryName(metric.WorkbookPath) ?? "",
            MetricWorkbook = Path.GetFileName(metric.WorkbookPath),
            DrawingNumber = metric.DrawingNumber,
            CombinedWeldAssemblyHours = metric.CombinedWeldAssemblyHours,
            RobotWeldingHours = metric.RobotWeldingHours,
            MetricSheetCount = metric.MetricSheetCount,
            MetricAggregationBasis = metric.AggregationBasis,
            CncHeavyHours = metric.CncHeavyHours,
            CncMediumHours = metric.CncMediumHours,
            CncLightHours = metric.CncLightHours,
            CncManualHours = metric.CncManualHours,
            HistoricalMaterialCostPln = metric.HistoricalMaterialCostPln,
            HistoricalTotalCostPln = metric.HistoricalTotalCostPln,
            HistoricalPricePln = metric.HistoricalPricePln,
            ProductionQuantity = metric.ProductionQuantity,
            SplitBasis = splitBasis,
            SskHours = new Dictionary<string, double>(project.Actuals.SskHours, StringComparer.OrdinalIgnoreCase),
            HistoricalRateHintsPlnH = new Dictionary<string, double>(metric.CostCenterRatesPlnH, StringComparer.OrdinalIgnoreCase)
        };

        if (metric.WeightKg is > 0)
            result.Drawing.Findings.Add($"Historia: masa referencyjna {metric.WeightKg:0.###} kg; masa techniczna wyceny pozostaje z BOM/STEP.");
        result.Drawing.Findings.Add($"Historia: zachowano rzeczywiste SSK {string.Join(", ", project.Actuals.SskHours.Where(x => x.Value > 0).Select(x => $"{x.Key}={x.Value:0.###}h"))}.");
        result.HistoricalPricePln = metric.HistoricalPricePln;
        AutoQuoteEngine.Apply(result);
    }

    private static string NormalizeDocumentFamily(string fileName)
    {
        var stem = Path.GetFileNameWithoutExtension(fileName).ToUpperInvariant();
        // UI assigns this suffix when two different files share the same visible name.
        // They must stay visible as a conflict, but data fusion should still compare them
        // inside one logical drawing family instead of double-counting both blindly.
        stem = Regex.Replace(stem, @"\s*\[KONFLIKT\s+\d+\]\s*$", "", RegexOptions.IgnoreCase);
        stem = Regex.Replace(
            stem,
            @"(?ix)(?:^|[ _\-.])(?:REV(?:ISION)?[ _\-.]*[A-Z0-9]{1,4}|R(?:[0-9]{1,4}(?![ _\-.][0-9])|[A-Z]))(?=$|[ _\-.])",
            " ");
        stem = Regex.Replace(stem, @"(?ix)(?:^|[ _\-.])(BOM|BILL[ _-]*OF[ _-]*MATERIALS?|DRAWING|RYS(?:UNEK)?|WELD(?:ING)?|SPAW(?:ANIE)?|OLD|ARCHIVE|ARCHIWALNY|MODEL|STEP)(?=$|[ _\-.])", " ");
        stem = Regex.Replace(stem, @"[ _\-.]+", " ").Trim();
        return stem;
    }

    private static string FirstWarning(IEnumerable<string> warnings, string fallback)
    {
        var value = warnings.FirstOrDefault(x => !string.IsNullOrWhiteSpace(x));
        if (string.IsNullOrWhiteSpace(value))
            return fallback;
        value = Regex.Replace(value.Trim(), @"\s+", " ");
        return value.Length <= 180 ? value : value[..177] + "…";
    }

    private static DxfSignals MergeDxf(
        List<DxfSignals> items,
        IReadOnlyDictionary<string, double>? quantityByFamily = null)
    {
        double Quantity(DxfSignals x)
        {
            if (quantityByFamily is null || quantityByFamily.Count == 0 || string.IsNullOrWhiteSpace(x.SourceFile))
                return 1.0;
            var key = DocumentFamilyResolver.RoutingKey(x.SourceFile);
            return quantityByFamily.TryGetValue(key, out var q) ? Math.Max(1, q) : 1.0;
        }

        var reliable = items.Where(x => x.GeometryMeasurementReliable).ToList();
        return new DxfSignals
        {
            Lines = items.Sum(x => x.Lines),
            Arcs = items.Sum(x => x.Arcs),
            Circles = items.Sum(x => x.Circles),
            Polylines = items.Sum(x => x.Polylines),
            Splines = items.Sum(x => x.Splines),
            Ellipses = items.Sum(x => x.Ellipses),
            Hatches = items.Sum(x => x.Hatches),
            Inserts = items.Sum(x => x.Inserts),
            Dimensions = items.Sum(x => x.Dimensions),
            TextEntities = items.Sum(x => x.TextEntities),
            OtherEntities = items.Sum(x => x.OtherEntities),
            TotalEntities = items.Sum(x => x.EntityCount),
            Reader = string.Join(" + ", items.Select(x => x.Reader).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct()),
            LayerCount = items.Sum(x => x.LayerCount),
            EntityTypeSummary = string.Join(" + ", items.Select(x => x.EntityTypeSummary).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct()),
            ExtentsSummary = string.Join(" + ", items.Select(x => x.ExtentsSummary).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct()),
            FileEncoding = string.Join(" + ", items.Select(x => x.FileEncoding).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct()),
            BinaryFormat = items.Any(x => x.BinaryFormat),
            ReferenceOnlyLikely = items.Count > 0 && items.All(x => x.ReferenceOnlyLikely),
            DiagnosticSummary = string.Join(" | ", items.Select(x => x.DiagnosticSummary).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct()),
            // Manufacturing metrics are per produced quantity. Entity diagnostics stay
            // per source file so the report still describes the actual DXF documents.
            CutLengthMm = reliable.Sum(x => x.CutLengthMm * Quantity(x)),
            MarkingLengthMm = reliable.Sum(x => x.MarkingLengthMm * Quantity(x)),
            IgnoredNonCutLengthMm = reliable.Sum(x => x.IgnoredNonCutLengthMm * Quantity(x)),
            CutGeometryEntityCount = (int)Math.Round(reliable.Sum(x => x.CutGeometryEntityCount * Quantity(x))),
            ClosedProfileCount = (int)Math.Round(reliable.Sum(x => x.ClosedProfileCount * Quantity(x))),
            OpenPathCount = (int)Math.Round(reliable.Sum(x => x.OpenPathCount * Quantity(x))),
            MinimumPierceCount = (int)Math.Round(reliable.Sum(x => x.MinimumPierceCount * Quantity(x))),
            CutStartCount = (int)Math.Round(reliable.Sum(x => x.CutStartCount * Quantity(x))),
            CutBoundingXmm = reliable.Select(x => x.CutBoundingXmm).DefaultIfEmpty(0).Max(),
            CutBoundingYmm = reliable.Select(x => x.CutBoundingYmm).DefaultIfEmpty(0).Max(),
            CutBoundingAreaMm2 = reliable.Sum(x => x.CutBoundingAreaMm2 * Quantity(x)),
            ClosedProfileAreaMm2 = reliable.Sum(x => x.ClosedProfileAreaMm2 * Quantity(x)),
            GeometryHoleCandidateCount = (int)Math.Round(reliable.Sum(x => x.GeometryHoleCandidateCount * Quantity(x))),
            EstimatedRapidTravelMm = reliable.Sum(x => x.EstimatedRapidTravelMm * Quantity(x)),
            SourceFileCount = items.Count,
            CutLayers = items.SelectMany(x => x.CutLayers).Distinct(StringComparer.OrdinalIgnoreCase).ToList(),
            MarkingLayers = items.SelectMany(x => x.MarkingLayers).Distinct(StringComparer.OrdinalIgnoreCase).ToList(),
            DrawingUnits = string.Join(" + ", items.Select(x => x.DrawingUnits).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase)),
            GeometryMeasurementReliable = items.Any(x => x.GeometryMeasurementReliable),
            ExtractedTextLength = items.Sum(x => x.ExtractedTextLength),
            MaterialHint = items.Select(x => x.MaterialHint).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "",
            MaterialReference = items.Select(x => x.MaterialReference).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "",
            MaterialReferenceConfidence = items.Where(x => !string.IsNullOrWhiteSpace(x.MaterialReference)).Select(x => x.MaterialReferenceConfidence).DefaultIfEmpty(0).Max(),
            MaterialReferenceEvidence = items.Select(x => x.MaterialReferenceEvidence).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "",
            Keywords = items.SelectMany(x => x.Keywords).Distinct(StringComparer.OrdinalIgnoreCase).ToList(),
            Norms = items.SelectMany(x => x.Norms).Distinct(StringComparer.OrdinalIgnoreCase).ToList(),
            Findings = items.SelectMany(x => x.Findings).Distinct().ToList(),
            Warnings = items.SelectMany(x => x.Warnings).Distinct().ToList()
        };
    }


    private static string NormalizePaintLayerName(string? name)
    {
        if (string.IsNullOrWhiteSpace(name)) return "WARSTWA";
        var value = name.Trim().ToUpperInvariant();
        if (value.Contains("PODKŁAD") || value.Contains("PODKLAD") || value.Contains("PRIMER") || value.Contains("GRUND")) return "PODKLAD";
        if (value.Contains("POŚRED") || value.Contains("POSRED") || value.Contains("INTERMEDIATE") || value.Contains("ZWISCHEN")) return "POSREDNIA";
        if (value.Contains("NAWIERZ") || value.Contains("TOPCOAT") || value.Contains("TOP COAT") || value.Contains("FINISH") || value.Contains("DECKLACK")) return "NAWIERZCHNIA";
        return value;
    }

}
