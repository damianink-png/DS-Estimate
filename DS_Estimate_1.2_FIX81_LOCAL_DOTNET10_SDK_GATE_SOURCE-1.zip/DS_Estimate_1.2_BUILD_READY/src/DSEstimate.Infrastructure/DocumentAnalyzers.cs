﻿using System.Text;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.RegularExpressions;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;
internal static class JsonPayloadHelper
{
    public static string ExtractJson(string stdout, string firstProperty)
    {
        var marker = $"{{\"{firstProperty}\"";
        var index = stdout.LastIndexOf(marker, StringComparison.Ordinal);
        return index >= 0 ? stdout[index..].Trim() : stdout.Trim();
    }
}

public sealed class GeometryAnalyzer
{
    private readonly PythonRunner _runner = new();
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public static bool IsDeterministicUnavailable(GeometrySummary result)
    {
        if (result.Available)
            return false;
        if (string.Equals(result.AnalysisMode, "invalid-input", StringComparison.OrdinalIgnoreCase))
            return true;

        var warnings = string.Join(" | ", result.Warnings);
        return warnings.Contains("brak brył SOLID", StringComparison.OrdinalIgnoreCase) ||
               warnings.Contains("nie zawiera rozpoznawalnych brył", StringComparison.OrdinalIgnoreCase) ||
               warnings.Contains("nie znalazł żadnych TopAbs_SOLID", StringComparison.OrdinalIgnoreCase) ||
               warnings.Contains("nie przeniósł żadnych rootów", StringComparison.OrdinalIgnoreCase) ||
               warnings.Contains("STEPControl_Reader.ReadFile status", StringComparison.OrdinalIgnoreCase) ||
               warnings.Contains("Git LFS", StringComparison.OrdinalIgnoreCase);
    }

    public static bool IsCacheableUnavailable(GeometrySummary result)
    {
        if (result.Available || IsDeterministicUnavailable(result))
            return true;
        var text = string.Join(" | ", result.Warnings);
        return string.Equals(result.AnalysisMode, "timeout", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("TIMEOUT:", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("corrupt", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("uszkodz", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("EOF", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("EndOfStream", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("cannot read", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("nie udało się odczytać", StringComparison.OrdinalIgnoreCase);
    }

    private static bool CacheableFailureText(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return false;
        return text.Contains("TIMEOUT:", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("corrupt", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("uszkodz", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("EOF", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("EndOfStream", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("Unsupported format", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("not a zip file", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("cannot identify image", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("PdfStreamError", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("Expected BOF", StringComparison.OrdinalIgnoreCase);
    }

    private static GeometrySummary? DetectInvalidStepInput(string path)
    {
        try
        {
            var info = new FileInfo(path);
            if (!info.Exists)
                return null;
            if (info.Length == 0)
                return new GeometrySummary
                {
                    Available = false,
                    AnalysisMode = "invalid-input",
                    Warnings = ["STEP jest pustym plikiem (0 bajtów)."]
                };
            if (info.Length > 4096)
                return null;

            var text = File.ReadAllText(path, Encoding.UTF8);
            if (text.StartsWith("version https://git-lfs.github.com/spec/v1", StringComparison.Ordinal))
            {
                return new GeometrySummary
                {
                    Available = false,
                    AnalysisMode = "invalid-input",
                    Warnings = ["Plik STEP jest wskaźnikiem Git LFS, a nie modelem CAD. Pobierz właściwy plik binarny z repozytorium."]
                };
            }
        }
        catch
        {
            // Normal engine diagnostics remain authoritative for unreadable input.
        }
        return null;
    }


    public async Task<Dictionary<string, GeometrySummary>> PreScanBatchAsync(
        IReadOnlyList<string> stepPaths,
        CancellationToken cancellationToken = default)
    {
        var batchCacheVersion = EngineResultCache.VersionForScripts(
            "r930-prescan-v2", "prescan_step_batch.py", "analyze_step.py");
        // A failed/partial batch is completed by PreScanAsync, which uses analyze_step.py.
        // Accept that deterministic single-file result on the next project run too; otherwise
        // the expensive batch pre-scan is repeated even though every STEP is already cached.
        var singleCacheVersion = EngineResultCache.VersionForScript("r930-prescan-v2", "analyze_step.py");
        var output = new Dictionary<string, GeometrySummary>(StringComparer.OrdinalIgnoreCase);
        if (stepPaths.Count == 0)
            return output;

        var missing = new List<string>();
        foreach (var path in stepPaths.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            cancellationToken.ThrowIfCancellationRequested();
            var invalid = DetectInvalidStepInput(path);
            if (invalid is not null)
            {
                output[path] = invalid;
                continue;
            }
            var cached = await EngineResultCache.TryReadAsync<GeometrySummary>(
                "step-prescan", batchCacheVersion, path, "prescan", cancellationToken);
            if (cached.Hit && cached.Value is not null &&
                IsCacheableUnavailable(cached.Value))
            {
                output[path] = cached.Value;
                continue;
            }

            var singleCached = await EngineResultCache.TryReadAsync<GeometrySummary>(
                "step-prescan", singleCacheVersion, path, "prescan", cancellationToken);
            if (singleCached.Hit && singleCached.Value is not null &&
                IsCacheableUnavailable(singleCached.Value))
            {
                output[path] = singleCached.Value;
                continue;
            }
            missing.Add(path);
        }

        if (missing.Count == 0)
            return output;

        var manifest = Path.Combine(Path.GetTempPath(), $"dse_step_prescan_{Guid.NewGuid():N}.json");
        try
        {
            await File.WriteAllTextAsync(manifest, JsonSerializer.Serialize(missing), cancellationToken);
            var timeoutSeconds = Math.Clamp(30 + missing.Count * 15, 60, 300);
            var run = await _runner.RunAsync(
                "prescan_step_batch.py", manifest, cancellationToken, executionTimeout: TimeSpan.FromSeconds(timeoutSeconds));
            if (!run.Ok || string.IsNullOrWhiteSpace(run.Stdout))
            {
                var failureMode = run.Stderr.Contains("TIMEOUT", StringComparison.OrdinalIgnoreCase) ? "prescan-timeout" : "prescan-error";
                if (CacheableFailureText(run.Stderr))
                {
                    foreach (var path in missing)
                    {
                        var failure = new GeometrySummary
                        {
                            Available = false,
                            AnalysisMode = failureMode,
                            WatchdogTriggered = failureMode == "prescan-timeout",
                            WatchdogLimitSeconds = timeoutSeconds,
                            Warnings = [string.IsNullOrWhiteSpace(run.Stderr) ? "STEP batch pre-scan nie zwrócił danych." : run.Stderr.Trim()]
                        };
                        output[path] = failure;
                        await EngineResultCache.WriteAsync(
                            "step-prescan", batchCacheVersion, path, "prescan", failure, cancellationToken);
                    }
                }
                return output;
            }

            var firstBrace = run.Stdout.IndexOf('{');
            var payload = firstBrace >= 0 ? run.Stdout[firstBrace..].Trim() : run.Stdout.Trim();
            var parsed = JsonSerializer.Deserialize<Dictionary<string, GeometrySummary>>(payload, JsonOptions);
            if (parsed is not null)
            {
                foreach (var pair in parsed)
                {
                    output[pair.Key] = pair.Value;
                    if (IsCacheableUnavailable(pair.Value))
                    {
                        await EngineResultCache.WriteAsync(
                            "step-prescan", batchCacheVersion, pair.Key, "prescan", pair.Value, cancellationToken);
                    }
                }
            }
            return output;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch
        {
            return output;
        }
        finally
        {
            try { if (File.Exists(manifest)) File.Delete(manifest); } catch { }
        }
    }

    public async Task<GeometrySummary> PreScanAsync(
        string stepPath,
        CancellationToken cancellationToken = default)
    {
        var invalid = DetectInvalidStepInput(stepPath);
        if (invalid is not null)
            return invalid;

        var cacheVersion = EngineResultCache.VersionForScript("r930-prescan-v2", "analyze_step.py");
        var cached = await EngineResultCache.TryReadAsync<GeometrySummary>(
            "step-prescan", cacheVersion, stepPath, "prescan", cancellationToken);
        if (cached.Hit && cached.Value is not null &&
            IsCacheableUnavailable(cached.Value))
            return cached.Value;

        var env = new Dictionary<string, string> { ["DSE_STEP_PRESCAN"] = "1" };
        var preScanTimeout = File.Exists(stepPath) && new FileInfo(stepPath).Length >= 8L * 1024 * 1024
            ? TimeSpan.FromSeconds(90)
            : TimeSpan.FromSeconds(45);
        var run = await _runner.RunAsync(
            "analyze_step.py", stepPath, cancellationToken, env, preScanTimeout);
        if (!run.Ok)
        {
            var failed = new GeometrySummary
            {
                Available = false,
                AnalysisMode = run.Stderr.Contains("TIMEOUT", StringComparison.OrdinalIgnoreCase) ? "prescan-timeout" : "prescan-error",
                WatchdogTriggered = run.Stderr.Contains("TIMEOUT", StringComparison.OrdinalIgnoreCase),
                WatchdogLimitSeconds = preScanTimeout.TotalSeconds,
                Warnings = [run.Stderr]
            };
            if (CacheableFailureText(run.Stderr))
                await EngineResultCache.WriteAsync(
                    "step-prescan", cacheVersion, stepPath, "prescan", failed, cancellationToken);
            return failed;
        }

        try
        {
            var payload = JsonPayloadHelper.ExtractJson(run.Stdout, "available");
            var result = JsonSerializer.Deserialize<GeometrySummary>(payload, JsonOptions)
                         ?? new GeometrySummary();
            if (!string.IsNullOrWhiteSpace(run.Stderr))
                result.Warnings.Add(run.Stderr.Trim());
            if (IsCacheableUnavailable(result))
                await EngineResultCache.WriteAsync(
                    "step-prescan", cacheVersion, stepPath, "prescan", result, cancellationToken);
            return result;
        }
        catch (Exception ex)
        {
            var failed = new GeometrySummary
            {
                Available = false,
                AnalysisMode = "prescan-error",
                WatchdogLimitSeconds = preScanTimeout.TotalSeconds,
                Warnings = [$"STEP pre-scan: {ex.Message}"]
            };
            await EngineResultCache.WriteAsync(
                "step-prescan", cacheVersion, stepPath, "prescan", failed, cancellationToken);
            return failed;
        }
    }

    public async Task<GeometrySummary?> TryReadFullCacheAsync(
        string stepPath,
        CancellationToken cancellationToken = default,
        bool fastHistory = false,
        bool coreOnly = false,
        bool priorityAccurate = false)
    {
        try
        {
            var engineCacheVersion = EngineResultCache.VersionForScript(
                "surface4-cnc5-pocket1-hole3-dse12-fix20", "analyze_step.py");
            await using var stream = File.OpenRead(stepPath);
            var hash = Convert.ToHexString(await SHA256.HashDataAsync(stream, cancellationToken));
            var cacheDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "DSEstimateNext", "cache", "geometry");
            var modeKey = coreOnly ? "core" : fastHistory ? "fast" : priorityAccurate ? "accurate" : "full";
            var cachePath = Path.Combine(cacheDir, $"{engineCacheVersion}_{modeKey}_{hash}.json");
            if (!File.Exists(cachePath)) return null;
            var cachedJson = await File.ReadAllTextAsync(cachePath, cancellationToken);
            var cached = JsonSerializer.Deserialize<GeometrySummary>(cachedJson, JsonOptions);
            if (cached is null || !IsCacheableUnavailable(cached)) return null;
            // FIX10K / B2: a watchdog checkpoint is an L2 resume cache, not a final
            // full-cache hit. Returning it here would make every warm run instantly
            // repeat the same incomplete result instead of finishing remaining features.
            if (cached.Available && cached.WatchdogTriggered) return null;
            cached.Warnings.Add(cached.Available
                ? "Geometry cache: użyto zapisanego wyniku STEP; geometria nie była liczona ponownie."
                : "Geometry cache: użyto zapamiętanej diagnostyki STEP; plik nie był ponownie importowany.");
            return cached;
        }
        catch
        {
            return null;
        }
    }

    public async Task<GeometrySummary> AnalyzeAsync(
        string stepPath,
        CancellationToken cancellationToken = default,
        bool fastHistory = false,
        bool coreOnly = false,
        int stepWorkers = 1,
        Action<int, string>? progress = null,
        bool priorityAccurate = false)
    {
        var invalid = DetectInvalidStepInput(stepPath);
        if (invalid is not null)
        {
            progress?.Invoke(100, "STEP: niepoprawny plik wejściowy");
            return invalid;
        }

        var engineCacheVersion = EngineResultCache.VersionForScript(
            "surface4-cnc5-pocket1-hole3-dse12-fix20", "analyze_step.py");
        string? cachePath = null;
        string? contentHash = null;
        string modeKey = coreOnly ? "core" : fastHistory ? "fast" : priorityAccurate ? "accurate" : "full";
        try
        {
            await using var stream = File.OpenRead(stepPath);
            var hash = Convert.ToHexString(await SHA256.HashDataAsync(stream, cancellationToken));
            contentHash = hash;
            var cacheDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "DSEstimateNext", "cache", "geometry");
            Directory.CreateDirectory(cacheDir);
            cachePath = Path.Combine(cacheDir, $"{engineCacheVersion}_{modeKey}_{hash}.json");
            if (File.Exists(cachePath))
            {
                var cachedJson = await File.ReadAllTextAsync(cachePath, cancellationToken);
                var cached = JsonSerializer.Deserialize<GeometrySummary>(cachedJson, JsonOptions);
                if (cached is not null && IsCacheableUnavailable(cached))
                {
                    if (cached.Available && cached.WatchdogTriggered)
                    {
                        progress?.Invoke(2, $"STEP: częściowy cache {cached.FullyAnalyzedUniqueSolids}/{Math.Max(1, cached.UniquePartGroups)} grup — wznawiam analizę");
                    }
                    else
                    {
                        cached.Warnings.Add(cached.Available
                            ? "Geometry cache: użyto zapisanego wyniku STEP; geometria nie była liczona ponownie."
                            : "Geometry cache: użyto zapamiętanej diagnostyki STEP; plik nie był ponownie importowany.");
                        progress?.Invoke(100, cached.Available ? "STEP: wynik z cache" : "STEP: zapamiętany brak brył");
                        return cached;
                    }
                }
            }
        }
        catch
        {
            // Cache is an optimisation only; any IO/hash issue falls back to the normal engine.
        }

        var fileSize = File.Exists(stepPath) ? new FileInfo(stepPath).Length : 0L;

        var env = new Dictionary<string, string>
        {
            ["DSE_PROGRESS_STREAM"] = "1",
            ["DSE_STEP_WORKERS"] = Math.Clamp(stepWorkers, 1, 2).ToString()
        };
        if (fastHistory) env["DSE_HISTORY_FAST_STEP"] = "1";
        if (coreOnly) env["DSE_STEP_CORE_ONLY"] = "1";
        if (priorityAccurate && !fastHistory && !coreOnly) env["DSE_STEP_PRIORITY_ACCURATE"] = "1";

        // 1.1: large authoritative STEP files use a progress watchdog. Active work may
        // continue up to the hard safety limit; only a long period with no heartbeat
        // is considered a hang.
        if (!fastHistory && !coreOnly && fileSize >= 24L * 1024 * 1024)
            env["DSE_PROGRESS_IDLE_WATCHDOG_SECONDS"] = "420";

        static void ParseProgress(string line, Action<int, string>? callback)
        {
            if (callback is null || !line.StartsWith("DSEPROGRESS|", StringComparison.Ordinal))
                return;
            var parts = line.Split('|', 3);
            if (parts.Length >= 3 && int.TryParse(parts[1], out var pct))
                callback(Math.Clamp(pct, 0, 100), parts[2]);
        }

        var checkpointRecommended = !coreOnly && !fastHistory && fileSize >= 8L * 1024 * 1024;
        GeometrySummary? quickCheckpoint = null;
        string? liveCheckpointPath = null;
        if (checkpointRecommended)
        {
            // R9.2.3C: do NOT import a difficult supplier STEP twice. The Python
            // full-analysis process writes a checkpoint immediately after its cheap
            // topology/grouping stage. If the watchdog stops later enrichment, we
            // recover that file. This removes the former 90 s pre-scan + 180 s full
            // double wait seen on real customer models.
            var checkpointDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "DSEstimateNext", "cache", "geometry-checkpoints");
            Directory.CreateDirectory(checkpointDir);
            var checkpointIdentity = engineCacheVersion + "|" + modeKey + "|" +
                                     (contentHash ?? (Path.GetFullPath(stepPath).ToUpperInvariant() + "|" + fileSize));
            var checkpointKey = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(
                System.Text.Encoding.UTF8.GetBytes(checkpointIdentity)));
            liveCheckpointPath = Path.Combine(checkpointDir, $"dse1_{checkpointKey}.json");
            env["DSE_STEP_CHECKPOINT_PATH"] = liveCheckpointPath;
            if (File.Exists(liveCheckpointPath))
            {
                env["DSE_STEP_RESUME"] = "1";
                progress?.Invoke(2, "STEP: wznawianie z progresywnego checkpointu cech");
            }
            else
            {
                progress?.Invoke(2, "STEP: pełna analiza z trwałym checkpointem po imporcie");
            }
        }

        // R9.2.3D: STEP is the authoritative geometry source and some real supplier
        // models spend >180 s inside the OpenCascade import itself, before a checkpoint
        // can be written. Give that single import enough time to reach the checkpoint,
        // but keep a hard boundary. There is still no second full/CORE restart for large
        // files, so extending 180 -> 300 s does not recreate the old double-timeout path.
        var largeStepTimeoutSeconds = fileSize >= 24L * 1024 * 1024 ? 1800 : 300;
        var timeout = coreOnly ? TimeSpan.FromSeconds(120)
            : fastHistory ? TimeSpan.FromSeconds(180)
            : checkpointRecommended ? TimeSpan.FromSeconds(largeStepTimeoutSeconds)
            : TimeSpan.FromSeconds(300);
        var run = await _runner.RunAsync(
            "analyze_step.py", stepPath, cancellationToken, env, timeout,
            line => ParseProgress(line, progress));
        var watchdogFallback = false;

        if (!run.Ok && run.Stderr.Contains("TIMEOUT", StringComparison.OrdinalIgnoreCase) && !coreOnly)
        {
            // R9.2.3: never throw away a successful pre-scan. It already carries
            // solids, unique groups, bbox, volume and gross/paintable surface.
            // Returning it also avoids the previous 300 s + 120 s double timeout.
            if (checkpointRecommended && !string.IsNullOrWhiteSpace(liveCheckpointPath) && File.Exists(liveCheckpointPath))
            {
                try
                {
                    var checkpointJson = await File.ReadAllTextAsync(liveCheckpointPath, cancellationToken);
                    quickCheckpoint = JsonSerializer.Deserialize<GeometrySummary>(checkpointJson, JsonOptions);
                }
                catch { quickCheckpoint = null; }
            }

            if (quickCheckpoint is { Available: true } checkpoint)
            {
                checkpoint.AnalysisMode = "checkpoint-fallback";
                checkpoint.WatchdogTriggered = true;
                checkpoint.WatchdogLimitSeconds = timeout.TotalSeconds;
                checkpoint.Warnings.Add(
                    $"STEP watchdog DS 1.1: pełna analiza przekroczyła {timeout.TotalSeconds:0} s. " +
                    "Zachowano checkpoint zapisany przez ten sam import STEP; nie uruchamiano ponownego importu/CORE. " +
                    "Masa/gabaryt/powierzchnia są dostępne; otwory, styki, spoiny i fazy mają obniżoną pewność.");
                if (!string.IsNullOrWhiteSpace(cachePath))
                {
                    try
                    {
                        var fallbackJson = JsonSerializer.Serialize(checkpoint);
                        await File.WriteAllTextAsync(cachePath, fallbackJson, cancellationToken);
                    }
                    catch { }
                }
                progress?.Invoke(100, "STEP: użyto checkpointu po watchdogu");
                return checkpoint;
            }

            // For smaller models preserve the old CORE recovery. Large models
            // without a checkpoint are not restarted from zero for another 120 s.
            if (!checkpointRecommended)
            {
                var fallbackEnv = new Dictionary<string, string>(env);
                fallbackEnv["DSE_STEP_CORE_ONLY"] = "1";
                run = await _runner.RunAsync(
                    "analyze_step.py", stepPath, cancellationToken, fallbackEnv, TimeSpan.FromSeconds(120),
                    line => ParseProgress(line, progress));
                watchdogFallback = run.Ok;
            }
        }

        if (!run.Ok)
        {
            var failed = new GeometrySummary
            {
                Available = false,
                AnalysisMode = run.Stderr.Contains("TIMEOUT", StringComparison.OrdinalIgnoreCase) ? "timeout" : (coreOnly ? "core" : "full"),
                WatchdogTriggered = run.Stderr.Contains("TIMEOUT", StringComparison.OrdinalIgnoreCase),
                WatchdogLimitSeconds = timeout.TotalSeconds,
                Warnings = [run.Stderr]
            };
            if (!string.IsNullOrWhiteSpace(cachePath) && (failed.WatchdogTriggered || CacheableFailureText(run.Stderr)))
            {
                try { await File.WriteAllTextAsync(cachePath, JsonSerializer.Serialize(failed), cancellationToken); } catch { }
            }
            return failed;
        }

        try
        {
            var payload = JsonPayloadHelper.ExtractJson(run.Stdout, "available");
            var result = JsonSerializer.Deserialize<GeometrySummary>(payload, JsonOptions);
            if (result is null)
                throw new InvalidDataException("Pusty wynik Geometry Engine.");

            result.WatchdogLimitSeconds = timeout.TotalSeconds;
            if (!string.IsNullOrWhiteSpace(run.Stderr))
                result.Warnings.Add(run.Stderr.Trim());
            if (watchdogFallback)
            {
                result.AnalysisMode = "core-fallback";
                result.WatchdogTriggered = true;
                result.Warnings.Add("STEP watchdog: pełna analiza przekroczyła limit; wynik ukończono automatycznie w trybie CORE. Styki/spoiny/powierzchnie wymagające pełnej analizy mają obniżoną pewność.");
            }

            if (IsCacheableUnavailable(result) && !string.IsNullOrWhiteSpace(cachePath))
            {
                try
                {
                    var cacheJson = JsonSerializer.Serialize(result);
                    await File.WriteAllTextAsync(cachePath, cacheJson, cancellationToken);
                }
                catch { }
            }
            return result;
        }
        catch (Exception ex)
        {
            var failed = new GeometrySummary
            {
                Available = false,
                AnalysisMode = "parse-error",
                WatchdogLimitSeconds = timeout.TotalSeconds,
                Warnings = [$"Nie udało się odczytać wyniku Geometry Engine: {ex.Message}"]
            };
            if (!string.IsNullOrWhiteSpace(cachePath))
            {
                try { await File.WriteAllTextAsync(cachePath, JsonSerializer.Serialize(failed), cancellationToken); } catch { }
            }
            return failed;
        }
    }
}

public sealed class DrawingAnalyzer
{
    private readonly PythonRunner _runner = new();
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public async Task<DrawingIntelligence> AnalyzeAsync(
        string path,
        CancellationToken cancellationToken = default,
        bool fastHistory = false,
        bool skipOcr = false,
        int ocrWorkers = 1)
    {
        var cacheVersion = EngineResultCache.VersionForScript("fix19-doc-representative-ocr-v1-fix22-mixed-raster-v1-fix23-tiled-inline-v1-fix24-titleblock-raster-v1-fix25-large-tile-union-v1-fix26-page-evidence-v1-fix27-pdf-extractor-page-fusion-v1-fix28-titleblock-drawing-id-v1-fix29-pdf-exact-bom-links-v1", "analyze_document.py");
        var cacheMode = $"{(fastHistory ? "fast" : "full")}-{(skipOcr ? "noocr" : "ocr")}";
        var cached = await EngineResultCache.TryReadAsync<DrawingIntelligence>(
            "document", cacheVersion, path, cacheMode, cancellationToken);
        if (cached.Hit && cached.Value is not null)
        {
            cached.Value.Warnings.Add("Document cache: użyto zapisanego wyniku PDF/OCR; dokument nie był analizowany ponownie.");
            return cached.Value;
        }

        var env = new Dictionary<string, string>
        {
            ["DSE_OCR_WORKERS"] = Math.Clamp(ocrWorkers, 1, 2).ToString(),
            ["DSE_OCR_MAX_MEGAPIXELS"] = "16",
            ["DSE_TESSERACT_TIMEOUT_SECONDS"] = "28"
        };
        if (fastHistory)
        {
            env["DSE_HISTORY_FAST_PDF"] = "1";
            env["DSE_HISTORY_SAFE"] = "1";
            env["DSE_OCR_WORKERS"] = "1";
            env["DSE_OCR_MAX_PAGES"] = "4";
        }
        if (skipOcr)
            env["DSE_SKIP_PDF_OCR"] = "1";
        var run = await _runner.RunAsync(
            "analyze_document.py", path, cancellationToken, env, TimeSpan.FromSeconds(fastHistory ? 90 : 180));

        if (!run.Ok)
        {
            var failed = new DrawingIntelligence { Warnings = [run.Stderr] };
            // Resource pressure and watchdog timeouts are transient. Caching an empty
            // document result would make the next resume permanently skip valid OCR/text.
            var transient = run.Stderr.Contains("RESOURCE_GOVERNOR", StringComparison.OrdinalIgnoreCase) ||
                            run.Stderr.Contains("TIMEOUT", StringComparison.OrdinalIgnoreCase) ||
                            run.Stderr.Contains("OOM", StringComparison.OrdinalIgnoreCase);
            if (!transient)
                await EngineResultCache.WriteAsync("document", cacheVersion, path, cacheMode, failed, cancellationToken);
            return failed;
        }

        try
        {
            var payload = JsonPayloadHelper.ExtractJson(run.Stdout, "materialHint");
            var result = JsonSerializer.Deserialize<DrawingIntelligence>(payload, JsonOptions)
                         ?? new DrawingIntelligence();

            if (!string.IsNullOrWhiteSpace(run.Stderr))
                result.Warnings.Add(run.Stderr.Trim());

            await EngineResultCache.WriteAsync("document", cacheVersion, path, cacheMode, result, cancellationToken);
            return result;
        }
        catch (Exception ex)
        {
            var failed = new DrawingIntelligence
            {
                Warnings = [$"Błąd odczytu PDF/OCR: {ex.Message}"]
            };
            await EngineResultCache.WriteAsync("document", cacheVersion, path, cacheMode, failed, cancellationToken);
            return failed;
        }
    }
}

public sealed class OfficeDocumentAnalyzer
{
    private readonly PythonRunner _runner = new();
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public async Task<DrawingIntelligence> AnalyzeAsync(
        string path,
        CancellationToken cancellationToken = default)
    {
        var cacheVersion = EngineResultCache.VersionForScripts(
            "r930-tabular-v3", "analyze_tabular.py", "analyze_document.py");
        var cached = await EngineResultCache.TryReadAsync<DrawingIntelligence>(
            "tabular", cacheVersion, path, "full", cancellationToken);
        if (cached.Hit && cached.Value is not null)
        {
            cached.Value.Warnings.Add("BOM cache: użyto zapisanego wyniku dokumentu tabelarycznego.");
            return cached.Value;
        }

        var run = await _runner.RunAsync(
            "analyze_tabular.py", path, cancellationToken, executionTimeout: TimeSpan.FromSeconds(90));

        try
        {
            if (string.IsNullOrWhiteSpace(run.Stdout))
            {
                var failed = new DrawingIntelligence { Warnings = [run.Stderr] };
                await EngineResultCache.WriteAsync("tabular", cacheVersion, path, "full", failed, cancellationToken);
                return failed;
            }

            var payload = JsonPayloadHelper.ExtractJson(run.Stdout, "materialHint");
            var result = JsonSerializer.Deserialize<DrawingIntelligence>(payload, JsonOptions)
                         ?? new DrawingIntelligence();

            if (!run.Ok && result.Warnings.Count == 0)
                result.Warnings.Add(string.IsNullOrWhiteSpace(run.Stderr)
                    ? "Nie udało się odczytać dokumentu tabelarycznego/tekstowego."
                    : run.Stderr.Trim());
            else if (!string.IsNullOrWhiteSpace(run.Stderr))
                result.Warnings.Add(run.Stderr.Trim());

            await EngineResultCache.WriteAsync("tabular", cacheVersion, path, "full", result, cancellationToken);
            return result;
        }
        catch (Exception ex)
        {
            var failed = new DrawingIntelligence
            {
                Warnings = [$"Błąd odczytu Excel/CSV/TXT/BOM/DOC: {ex.Message}"]
            };
            await EngineResultCache.WriteAsync("tabular", cacheVersion, path, "full", failed, cancellationToken);
            return failed;
        }
    }
}

public sealed class DxfAnalyzer
{
    private readonly PythonRunner _runner = new();
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public async Task<DxfSignals> AnalyzeAsync(
        string path,
        CancellationToken cancellationToken = default)
    {
        var cacheVersion = EngineResultCache.VersionForScripts(
            "r930-dxf-v2", "analyze_dxf.py", "analyze_document.py");
        var cached = await EngineResultCache.TryReadAsync<DxfSignals>(
            "dxf", cacheVersion, path, "full", cancellationToken);
        if (cached.Hit && cached.Value is not null)
        {
            cached.Value.Warnings.Add("DXF cache: użyto zapisanego wyniku geometrii/tekstu DXF.");
            return cached.Value;
        }

        var run = await _runner.RunAsync("analyze_dxf.py", path, cancellationToken);

        if (run.Ok || !string.IsNullOrWhiteSpace(run.Stdout))
        {
            try
            {
                var payload = JsonPayloadHelper.ExtractJson(run.Stdout, "lines");
                var result = JsonSerializer.Deserialize<DxfSignals>(payload, JsonOptions)
                             ?? new DxfSignals();

                if (!string.IsNullOrWhiteSpace(run.Stderr))
                    result.Warnings.Add(run.Stderr.Trim());

                await EngineResultCache.WriteAsync("dxf", cacheVersion, path, "full", result, cancellationToken);
                return result;
            }
            catch (Exception ex)
            {
                var fallback = await AnalyzeAsciiFallbackAsync(path, cancellationToken);
                fallback.Warnings.Add($"Błąd odczytu wyniku DXF Python: {ex.Message}");
                if (!string.IsNullOrWhiteSpace(run.Stderr))
                    fallback.Warnings.Add(run.Stderr.Trim());
                await EngineResultCache.WriteAsync("dxf", cacheVersion, path, "full", fallback, cancellationToken);
                return fallback;
            }
        }

        var ascii = await AnalyzeAsciiFallbackAsync(path, cancellationToken);
        if (!string.IsNullOrWhiteSpace(run.Stderr))
            ascii.Warnings.Add(run.Stderr.Trim());
        await EngineResultCache.WriteAsync("dxf", cacheVersion, path, "full", ascii, cancellationToken);
        return ascii;
    }

    private static async Task<DxfSignals> AnalyzeAsciiFallbackAsync(
        string path,
        CancellationToken cancellationToken)
    {
        try
        {
            var bytes = await File.ReadAllBytesAsync(path, cancellationToken);
            var binary = bytes.AsSpan().StartsWith("AutoCAD Binary DXF"u8);
            var encodingName = bytes.AsSpan().StartsWith(Encoding.UTF8.GetPreamble())
                ? "UTF-8-BOM"
                : bytes.All(x => x < 128)
                    ? "ASCII"
                    : "LATIN1";
            var text = encodingName == "UTF-8-BOM"
                ? Encoding.UTF8.GetString(bytes.AsSpan(Encoding.UTF8.GetPreamble().Length))
                : Encoding.Latin1.GetString(bytes);
            var known = new Dictionary<string, Action<DxfSignals, int>>(StringComparer.OrdinalIgnoreCase)
            {
                ["LINE"] = (x, n) => x.Lines += n,
                ["ARC"] = (x, n) => x.Arcs += n,
                ["CIRCLE"] = (x, n) => x.Circles += n,
                ["LWPOLYLINE"] = (x, n) => x.Polylines += n,
                ["POLYLINE"] = (x, n) => x.Polylines += n,
                ["SPLINE"] = (x, n) => x.Splines += n,
                ["ELLIPSE"] = (x, n) => x.Ellipses += n,
                ["HATCH"] = (x, n) => x.Hatches += n,
                ["INSERT"] = (x, n) => x.Inserts += n,
                ["DIMENSION"] = (x, n) => x.Dimensions += n,
                ["TEXT"] = (x, n) => x.TextEntities += n,
                ["MTEXT"] = (x, n) => x.TextEntities += n,
                ["ATTRIB"] = (x, n) => x.TextEntities += n,
                ["ATTDEF"] = (x, n) => x.TextEntities += n
            };

            var result = new DxfSignals
            {
                Reader = "C# ASCII recovery",
                FileEncoding = encodingName,
                BinaryFormat = binary,
                ExtentsSummary = "niedostępne w parserze awaryjnym C#"
            };
            if (binary)
            {
                result.DiagnosticSummary =
                    "DXF_DIAG | Reader=C# ASCII recovery | Entities=0 | Layers=0 | Types=brak | " +
                    "Units=unknown | Extents=brak | Binary=True | ParseErrors=format binarny wymaga ezdxf";
                result.Findings.Add(result.DiagnosticSummary);
                result.Warnings.Add("DXF_BINARY_REQUIRES_EZDXF: parser awaryjny C# nie czyta binarnego DXF.");
                return result;
            }

            var total = 0;
            var typeCounts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var (name, apply) in known)
            {
                var count = Regex.Matches(
                    text.Replace("\r\n", "\n").Replace('\r', '\n'),
                    $@"(?mi)^\s*0\s*$\n\s*{Regex.Escape(name)}\s*$").Count;
                if (count <= 0)
                    continue;
                apply(result, count);
                total += count;
                typeCounts[name] = count;
            }

            var otherNames = new[]
            {
                "POINT", "SOLID", "TRACE", "3DFACE", "RAY", "XLINE",
                "LEADER", "MLEADER", "MLINE", "WIPEOUT", "IMAGE", "MESH",
                "VIEWPORT", "SHAPE"
            };
            foreach (var name in otherNames)
            {
                var count = Regex.Matches(
                    text.Replace("\r\n", "\n").Replace('\r', '\n'),
                    $@"(?mi)^\s*0\s*$\n\s*{Regex.Escape(name)}\s*$").Count;
                result.OtherEntities += count;
                total += count;
                if (count > 0)
                    typeCounts[name] = count;
            }

            result.TotalEntities = total;
            result.LayerCount = Regex.Matches(
                text.Replace("\r\n", "\n").Replace('\r', '\n'),
                @"(?mi)^\s*0\s*$\n\s*LAYER\s*$").Count;
            result.EntityTypeSummary = typeCounts.Count == 0
                ? "brak"
                : string.Join(", ", typeCounts.OrderByDescending(x => x.Value).Take(16).Select(x => $"{x.Key}:{x.Value}"));
            var geometricEntities = result.Lines + result.Arcs + result.Circles + result.Polylines +
                                    result.Splines + result.Ellipses;
            result.ReferenceOnlyLikely = total > 0 && geometricEntities == 0 &&
                                         (result.Inserts > 0 || typeCounts.ContainsKey("IMAGE"));
            result.DiagnosticSummary =
                $"DXF_DIAG | Reader=C# ASCII recovery | Entities={total} | Layers={result.LayerCount} | " +
                $"Types={result.EntityTypeSummary} | Units=unknown | Extents={result.ExtentsSummary} | " +
                $"Encoding={encodingName} | Binary=False | ReferenceOnly={result.ReferenceOnlyLikely}";
            result.Findings.Add(result.DiagnosticSummary);
            if (total == 0)
                result.Warnings.Add(
                    $"DXF_ZERO_ENTITIES: parser awaryjny C# nie rozpoznał encji; " +
                    $"warstwy={result.LayerCount}, typy={result.EntityTypeSummary}, kodowanie={encodingName}.");
            return result;
        }
        catch (Exception ex)
        {
            return new DxfSignals
            {
                Reader = "failed",
                DiagnosticSummary =
                    $"DXF_DIAG | Reader=failed | Entities=0 | Layers=0 | Types=brak | " +
                    $"Units=unknown | Extents=brak | ParseErrors={ex.GetType().Name}: {ex.Message}",
                Warnings = [$"DXF fallback: {ex.GetType().Name}: {ex.Message}"]
            };
        }
    }
}
