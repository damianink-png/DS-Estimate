using System.Text.Json;

namespace DSEstimate.Infrastructure;

public sealed class FirmGoldenSetDocument
{
    public string Schema { get; set; } = "ds-estimate-firm-golden-set-v1";
    public string Id { get; set; } = "";
    public string Description { get; set; } = "";
    public int MinimumProjects { get; set; } = 20;
    public double MaximumMapePercent { get; set; } = 25;
    public double MaximumAbsoluteBiasPercent { get; set; } = 10;
    public double MaximumP90Percent { get; set; } = 45;
    public List<FirmGoldenSetCase> Projects { get; set; } = [];
}

public sealed class FirmGoldenSetCase
{
    public string ProjectId { get; set; } = "";
    public string ProjectClass { get; set; } = "";
    public DateTime CompletedAt { get; set; }
    public double ActualPricePln { get; set; }
    public double PredictedPricePln { get; set; }
    public double ActualHours { get; set; }
    public double PredictedHours { get; set; }
    public string EvidenceHash { get; set; } = "";
}

public sealed class FirmGoldenSetReport
{
    public string Status { get; set; } = "OCZEKUJE";
    public string Id { get; set; } = "";
    public int ProjectCount { get; set; }
    public int MinimumProjects { get; set; } = 20;
    public double PriceMapePercent { get; set; }
    public double PriceBiasPercent { get; set; }
    public double PriceP90Percent { get; set; }
    public double HoursMapePercent { get; set; }
    public bool Passed { get; set; }
    public List<string> Errors { get; set; } = [];
    public string Summary => Errors.Count > 0
        ? $"Golden set: BŁĄD · {string.Join(" · ", Errors)}"
        : ProjectCount < MinimumProjects
            ? $"Golden set firmy: {ProjectCount}/{MinimumProjects} realnych projektów · współczynniki pozostają zablokowane"
            : $"Golden set {Status}: {ProjectCount} projektów · cena MAPE {PriceMapePercent:0.#}% · bias {PriceBiasPercent:+0.#;-0.#;0}% · P90 {PriceP90Percent:0.#}%";
}

/// <summary>
/// Validates a company-owned, de-identified reference set. An empty template is a
/// valid waiting state; no synthetic data is ever promoted as firm evidence.
/// </summary>
public sealed class FirmGoldenSetService
{
    public static string? FindDefaultPath()
    {
        var roots = new List<string> { AppContext.BaseDirectory, Environment.CurrentDirectory };
        var cursor = new DirectoryInfo(AppContext.BaseDirectory);
        for (var i = 0; i < 7 && cursor is not null; i++, cursor = cursor.Parent)
            roots.Add(cursor.FullName);
        foreach (var root in roots.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            var candidate = Path.Combine(root, "config", "golden_set_company.json");
            if (File.Exists(candidate))
                return candidate;
        }
        return null;
    }

    public FirmGoldenSetReport LoadAndEvaluate(string path)
    {
        if (!File.Exists(path))
            return new FirmGoldenSetReport { Errors = ["brak config/golden_set_company.json"] };
        try
        {
            var document = JsonSerializer.Deserialize<FirmGoldenSetDocument>(
                File.ReadAllText(path),
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            return document is null
                ? new FirmGoldenSetReport { Errors = ["pusty dokument"] }
                : Evaluate(document);
        }
        catch (Exception ex)
        {
            return new FirmGoldenSetReport { Errors = [$"nie można odczytać: {ex.Message}"] };
        }
    }

    public FirmGoldenSetReport Evaluate(FirmGoldenSetDocument document)
    {
        var report = new FirmGoldenSetReport
        {
            Id = document.Id?.Trim() ?? "",
            MinimumProjects = Math.Clamp(document.MinimumProjects, 20, 50)
        };
        if (!string.Equals(document.Schema, "ds-estimate-firm-golden-set-v1", StringComparison.OrdinalIgnoreCase))
            report.Errors.Add("nieobsługiwany schemat");

        var projects = (document.Projects ?? [])
            .Where(x => x.ActualPricePln > 0 && x.PredictedPricePln > 0 &&
                        x.ActualHours > 0 && x.PredictedHours > 0 &&
                        x.CompletedAt != default &&
                        !string.IsNullOrWhiteSpace(x.ProjectId) &&
                        !string.IsNullOrWhiteSpace(x.ProjectClass) &&
                        !string.IsNullOrWhiteSpace(x.EvidenceHash))
            .GroupBy(x => x.ProjectId.Trim(), StringComparer.OrdinalIgnoreCase)
            .Select(x => x.First())
            .ToList();
        report.ProjectCount = projects.Count;
        if (projects.Count != (document.Projects?.Count ?? 0))
            report.Errors.Add("rekordy niepełne lub zduplikowane");

        if (projects.Count > 0)
        {
            var priceSigned = projects.Select(x => (x.PredictedPricePln - x.ActualPricePln) / x.ActualPricePln * 100).ToList();
            var hourSigned = projects.Select(x => (x.PredictedHours - x.ActualHours) / x.ActualHours * 100).ToList();
            report.PriceMapePercent = priceSigned.Select(Math.Abs).Average();
            report.PriceBiasPercent = priceSigned.Average();
            report.PriceP90Percent = Percentile90(priceSigned.Select(Math.Abs));
            report.HoursMapePercent = hourSigned.Select(Math.Abs).Average();
        }

        var enough = report.ProjectCount >= report.MinimumProjects;
        report.Passed = report.Errors.Count == 0 && enough &&
                        report.PriceMapePercent <= Math.Clamp(document.MaximumMapePercent, 1, 100) &&
                        Math.Abs(report.PriceBiasPercent) <= Math.Clamp(document.MaximumAbsoluteBiasPercent, 1, 100) &&
                        report.PriceP90Percent <= Math.Clamp(document.MaximumP90Percent, 1, 200);
        report.Status = !enough ? "OCZEKUJE" : report.Passed ? "PASS" : "BLOKADA";
        return report;
    }

    private static double Percentile90(IEnumerable<double> values)
    {
        var ordered = values.Where(double.IsFinite).OrderBy(x => x).ToList();
        if (ordered.Count == 0)
            return 0;
        var index = Math.Clamp((int)Math.Ceiling(ordered.Count * 0.9) - 1, 0, ordered.Count - 1);
        return ordered[index];
    }
}
