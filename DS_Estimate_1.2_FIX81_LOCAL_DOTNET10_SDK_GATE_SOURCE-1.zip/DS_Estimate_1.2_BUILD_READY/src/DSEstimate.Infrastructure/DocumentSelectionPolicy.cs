﻿using System.Text.RegularExpressions;
using DSEstimate.Core;

namespace DSEstimate.Infrastructure;

/// <summary>
/// FIX10G cheap, deterministic source selection with cold-run relevance gating. It intentionally uses only path/name/type
/// information, so obviously irrelevant assets can be rejected before expensive OCR.
/// Specialist analyzers are unchanged and remain responsible for technical extraction.
/// </summary>
public static class DocumentSelectionPolicy
{
    private static readonly Regex TechnicalName = new(
        @"(?:drawing|rys|zeichnung|dessin|spec|tech|wymag|anforder|exigenc|bom|part|detail|detal|assembly|assy|weld|spaw|paint|malow|material|plate|shaft|gear|frame|fixture|quality|inspection|cmm|ocr|notes?|note|uwag|hinweis)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex SoftwarePath = new(
        @"(?:^|[\\/])(?:firmware|software|src|source|buildroot|node_modules|\.git|github|assets?|icons?|screenshots?|render(?:s|ings)?|thumbnails?|ui|www)(?:[\\/]|$)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex ReferencePath = new(
        @"(?:^|[\\/])(?:reference|references|ref|examples?|samples?|manual|manuals|instructions?|instrukcja|checklist|docs?)(?:[\\/]|$)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex ExternalReferenceCorpusPath = new(
        @"(?:^|[\\/])(?:\d{1,2}[_ .-]?)?(?:public[_ .-]?licensed(?:[_ .-]?cad(?:[_ .-]?bom)?)?|public[_ .-]?data(?:[_ .-]?cache)?|benchmark(?:s)?|bench|grabcad|cad[_ .-]?library|libraries?|sample[_ .-]?cad|reference[_ .-]?cad|vendor[_ .-]?cad|supplier[_ .-]?cad)(?:[\\/]|$)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex PurchasedPath = new(
        @"(?:^|[\\/])(?:purchased|bought|buy|cots|vendor|supplier|catalog|datasheet|hardware|fasteners?)(?:[\\/]|$)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex VendorUrlWords = new(
        @"(?:amazon|taobao|aliexpress|seeedstudio|igus|mouser|digikey|rs-online|farnell)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex BenchmarkSupportName = new(
        @"^(?:\d{1,2}[_ .-]?)?(?:readme(?:[_ .-]?test)?|test[_ .-]?(?:instructions?|plan|notes?)|expected(?:[_ .-]?(?:targets?|results?|values?))?|sha256sums?|checksums?|public[_ .-]?open[_ .-]?source[_ .-]?(?:references?|sources?)|benchmark[_ .-]?(?:manifest|notes?|expected)|validation[_ .-]?(?:targets?|expected))(?:[_ .-]|$)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    public static (DocumentRole Role, int Confidence, string Reason) Classify(
        string path, string relativePath, string? extension = null)
    {
        var rel = string.IsNullOrWhiteSpace(relativePath) ? Path.GetFileName(path) : relativePath;
        var name = Path.GetFileName(rel);
        var ext = (extension ?? Path.GetExtension(path)).ToLowerInvariant();
        var haystack = (rel + " " + name).Replace('\\', '/');

        if (name.StartsWith("DS_Estimate_RAPORT_", StringComparison.OrdinalIgnoreCase) ||
            Regex.IsMatch(name, @"(?:^|[_ -])(?:raport|report)(?:[_ .-]|$)", RegexOptions.IgnoreCase) &&
            haystack.Contains("estimate", StringComparison.OrdinalIgnoreCase))
            return (DocumentRole.PreviousReport, 100, "nazwa odpowiada wcześniejszemu raportowi DS Estimate");

        // FIX10G: benchmark manifests/checksums/expected-result files are control artifacts,
        // not customer production evidence. This precedes TechnicalName and generic BOM
        // promotion so EXPECTED_TARGETS.csv cannot create a false production conflict.
        if (BenchmarkSupportName.IsMatch(name))
            return (DocumentRole.Reference, 99, "plik kontrolny/testowy/manifest benchmarku; nie głosuje i nie uruchamia analizatora produkcyjnego");

        // FIX10G cold-run guard: a complete external benchmark/reference/library corpus is
        // non-production regardless of whether an item is CAD, BOM, PDF or a sidecar text.
        // This must run BEFORE TechnicalName, otherwise REFERENCE_BOM.csv could be promoted
        // merely because its filename contains the token "BOM".
        if (ExternalReferenceCorpusPath.IsMatch(haystack) && IsTechnicalCorpusExtension(ext))
            return (DocumentRole.Reference, 97, "zewnętrzny korpus danych / benchmark / biblioteka; pominięto analizę produkcyjną");

        // FIX10I real-world raster guard: folders named Renderings/Renders/Screenshots/Assets
        // contain presentation graphics, not production drawings. Path context is stronger
        // than tokens such as "parts" or "assembly" in a JPG filename, so reject these
        // before TechnicalName can promote the raster and launch OCR.
        if (IsRasterExtension(ext) && SoftwarePath.IsMatch(haystack))
            return (DocumentRole.SoftwareGraphic, 99, "katalog renderingu/assetów; raster pomocniczy nie jest rysunkiem produkcyjnym");

        // Explicit technical naming beats generic docs folders, but a clear software tree
        // still stays software unless the file itself looks like a real production document.
        if (TechnicalName.IsMatch(name) &&
            ext is ".step" or ".stp" or ".dxf" or ".dwg" or ".pdf" or ".xlsx" or ".xlsm" or ".xls" or ".csv" or ".docx" or ".doc" or ".rtf" or ".txt" or ".bom")
            return (DocumentRole.Production, 92, "techniczna nazwa i obsługiwany format produkcyjny");

        if (PurchasedPath.IsMatch(haystack) || VendorUrlWords.IsMatch(haystack) ||
            Regex.IsMatch(name, @"(?:purchased|bought|cots|vendor|datasheet|catalog)", RegexOptions.IgnoreCase))
            return (DocumentRole.PurchasedItem, 88, "ścieżka/nazwa wskazuje dokument elementu kupowanego lub katalogowego");

        if (SoftwarePath.IsMatch(haystack) ||
            Regex.IsMatch(name, @"^(?:CMakeLists|package-lock|package|license|changelog)(?:\.|$)|(?:logo|icon|screenshot|render|thumbnail)", RegexOptions.IgnoreCase))
            return (DocumentRole.SoftwareGraphic, 96, "ścieżka/nazwa wskazuje plik oprogramowania albo grafikę pomocniczą");

        if (ReferencePath.IsMatch(haystack) ||
            Regex.IsMatch(name, @"^(?:readme|czytaj|instrukcja|checklist)(?:[_ .-]|$)", RegexOptions.IgnoreCase))
            return (DocumentRole.Reference, 88, "plik pomocniczy/referencyjny, nie źródło produkcyjne");

        if (ext is ".step" or ".stp" or ".dxf" or ".dwg")
            return (DocumentRole.Production, 99, "geometria CAD");
        if (ext is ".bom" or ".csv" or ".xlsx" or ".xlsm" or ".xls")
            return (DocumentRole.Production, 80, "tabela/BOM może sterować ilościami i materiałem");
        if (ext is ".pdf" or ".docx" or ".doc" or ".rtf")
            return (DocumentRole.Production, 72, "dokument może zawierać wymagania produkcyjne");
        if (ext is ".png" or ".jpg" or ".jpeg" or ".tif" or ".tiff" or ".bmp")
            return TechnicalName.IsMatch(haystack)
                ? (DocumentRole.Production, 78, "obraz ma techniczny kontekst nazwy")
                : (DocumentRole.Reference, 58, "obraz bez technicznego kontekstu; OCR wymaga dodatkowego uzasadnienia");
        if (ext is ".md" or ".log")
            return (DocumentRole.Reference, 70, "tekst pomocniczy/log; nie powinien głosować jak rysunek");
        return TechnicalName.IsMatch(haystack)
            ? (DocumentRole.Production, 68, "techniczny kontekst nazwy")
            : (DocumentRole.Unknown, 45, "brak pewnych sygnałów klasyfikacji");
    }

    private static bool IsRasterExtension(string ext) =>
        ext is ".png" or ".jpg" or ".jpeg" or ".tif" or ".tiff" or ".bmp";

    private static bool IsTechnicalCorpusExtension(string ext) =>
        ext is ".step" or ".stp" or ".dxf" or ".dwg" or ".pdf" or ".xlsx" or ".xlsm" or ".xls" or ".csv" or ".docx" or ".doc" or ".rtf" or ".txt" or ".bom" or ".png" or ".jpg" or ".jpeg" or ".tif" or ".tiff" or ".bmp";

    public static bool IsExternalReferenceCorpus(ProjectDocument document)
    {
        EnsureClassified(document);
        var haystack = (document.RelativePath + " " + document.Name).Replace('\\', '/');
        return document.Role == DocumentRole.Reference && ExternalReferenceCorpusPath.IsMatch(haystack);
    }

    public static void EnsureClassified(ProjectDocument document)
    {
        if (document.Role != DocumentRole.Unknown && document.RoleConfidence > 0)
            return;
        var c = Classify(document.Path, document.RelativePath, Path.GetExtension(document.Path));
        document.Role = c.Role;
        document.RoleConfidence = c.Confidence;
        document.RoleReason = c.Reason;
    }

    public static bool IsBenchmarkSupportArtifact(ProjectDocument document)
    {
        EnsureClassified(document);
        var name = Path.GetFileName(string.IsNullOrWhiteSpace(document.RelativePath) ? document.Name : document.RelativePath);
        return document.Role == DocumentRole.Reference && BenchmarkSupportName.IsMatch(name);
    }

    public static bool ShouldSkipTechnicalAnalysis(ProjectDocument document)
    {
        EnsureClassified(document);
        if (document.Role is DocumentRole.PreviousReport or DocumentRole.SoftwareGraphic)
            return true;
        if (IsExternalReferenceCorpus(document) || IsBenchmarkSupportArtifact(document))
            return true;
        if (document.Role == DocumentRole.PurchasedItem && document.Kind is not DocumentKind.Excel)
            return true;
        if (document.Role == DocumentRole.Reference && document.Kind == DocumentKind.Image)
            return !TechnicalName.IsMatch(document.RelativePath + " " + document.Name);
        if (document.Role == DocumentRole.Reference && document.Kind is (DocumentKind.Step or DocumentKind.Dxf or DocumentKind.Dwg))
            return true;
        return false;
    }

    public static bool IsExternalReferenceCad(ProjectDocument document)
    {
        EnsureClassified(document);
        if (document.Kind is not (DocumentKind.Step or DocumentKind.Dxf or DocumentKind.Dwg))
            return false;
        var haystack = (document.RelativePath + " " + document.Name).Replace('\\', '/');
        return document.Role == DocumentRole.Reference && ExternalReferenceCorpusPath.IsMatch(haystack);
    }

    public static bool IsTrustedForCriticalFusion(ProjectDocument document)
    {
        EnsureClassified(document);
        return document.Role == DocumentRole.Production;
    }

    public static bool IsGenericContainerName(string value)
    {
        var name = (value ?? "").Trim();
        if (Regex.IsMatch(name, @"^\d{1,2}[_ .-](?:control|conflict|negative|public|test|fixture|cache|generated|benchmark|ocr|format)", RegexOptions.IgnoreCase))
            return true;
        return Regex.IsMatch(name,
            @"^(?:docs?|drawings?|cad|step|dxf|pdf|images?|assets?|firmware|software|reports?|raporty|public_data(?:_cache)?|controlled.*|fixtures?.*|tests?.*|testy.*|benchmark.*|generated.*|gui_.*|grabCAD.*|negative.*|conflicts?.*|archive|old)$",
            RegexOptions.IgnoreCase);
    }
}
