﻿using System.Diagnostics;
using System.Drawing;
using System.IO.Compression;
using System.Reflection;
using System.Windows.Forms;

namespace DSEstimate.Launcher;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new LauncherForm());
    }
}

internal readonly record struct InstallProgress(int Percent, string Message, string Detail = "");

internal sealed class LauncherForm : Form
{
    private const string PayloadResource = "DSEstimate.Payload.zip";
    private const string HashResource = "DSEstimate.Payload.sha256";
    private const string ReleaseFolder = "1_2";

    private readonly Label _status;
    private readonly Label _detail;
    private readonly ProgressBar _progress;
    private readonly Button _cancel;
    private readonly CancellationTokenSource _cancellation = new();
    private bool _working = true;

    public LauncherForm()
    {
        Text = "DS Estimate — przygotowanie aplikacji";
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = true;
        ClientSize = new Size(560, 214);
        BackColor = Color.FromArgb(23, 27, 30);
        ForeColor = Color.White;
        Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);

        var title = new Label
        {
            AutoSize = false,
            Text = "DS Estimate",
            Font = new Font("Segoe UI", 17F, FontStyle.Bold, GraphicsUnit.Point),
            ForeColor = Color.FromArgb(244, 166, 48),
            Location = new Point(24, 20),
            Size = new Size(500, 34)
        };
        _status = new Label
        {
            AutoSize = false,
            Text = "Przygotowanie bezpiecznego uruchomienia…",
            Font = new Font("Segoe UI", 10.5F, FontStyle.Bold, GraphicsUnit.Point),
            Location = new Point(26, 66),
            Size = new Size(505, 25)
        };
        _detail = new Label
        {
            AutoSize = false,
            Text = "Aplikacja zostanie umieszczona w krótkiej ścieżce użytkownika.",
            ForeColor = Color.FromArgb(174, 191, 204),
            Location = new Point(26, 94),
            Size = new Size(505, 40)
        };
        _progress = new ProgressBar
        {
            Style = ProgressBarStyle.Continuous,
            Minimum = 0,
            Maximum = 100,
            Value = 1,
            Location = new Point(26, 139),
            Size = new Size(505, 18)
        };
        _cancel = new Button
        {
            Text = "Anuluj",
            Location = new Point(421, 172),
            Size = new Size(110, 30),
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.FromArgb(31, 37, 42),
            ForeColor = Color.White
        };
        _cancel.FlatAppearance.BorderColor = Color.FromArgb(62, 70, 76);
        _cancel.Click += (_, _) => RequestCancellation();

        Controls.AddRange([title, _status, _detail, _progress, _cancel]);
        Shown += async (_, _) => await InstallAndLaunchAsync();
        FormClosing += OnFormClosing;
    }

    private async Task InstallAndLaunchAsync()
    {
        try
        {
            var progress = new Progress<InstallProgress>(p =>
            {
                _progress.Value = Math.Clamp(p.Percent, 0, 100);
                _status.Text = p.Message;
                if (!string.IsNullOrWhiteSpace(p.Detail))
                    _detail.Text = p.Detail;
            });

            var installDirectory = await Task.Run(
                () => EnsureInstalled(progress, _cancellation.Token),
                _cancellation.Token);

            _progress.Value = 100;
            _status.Text = "Gotowe — uruchamiam DS Estimate";
            _detail.Text = installDirectory;
            var executable = Path.Combine(installDirectory, "DSEstimate.exe");
            Process.Start(new ProcessStartInfo
            {
                FileName = executable,
                WorkingDirectory = installDirectory,
                UseShellExecute = true
            });
            _working = false;
            Close();
        }
        catch (OperationCanceledException)
        {
            _working = false;
            Close();
        }
        catch (Exception ex)
        {
            _working = false;
            _progress.Value = 0;
            _status.Text = "Nie udało się przygotować aplikacji";
            _detail.Text = ex.Message;
            _cancel.Text = "Zamknij";
            MessageBox.Show(
                this,
                "Launcher nie mógł wypakować lub uruchomić DS Estimate.\n\n" + ex.Message,
                "DS Estimate",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    private static string EnsureInstalled(
        IProgress<InstallProgress> progress,
        CancellationToken cancellationToken)
    {
        var assembly = Assembly.GetExecutingAssembly();
        var expectedHash = ReadExpectedHash(assembly);
        var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        if (string.IsNullOrWhiteSpace(localAppData))
            throw new InvalidOperationException("System Windows nie zwrócił katalogu LOCALAPPDATA.");

        var releaseRoot = Path.Combine(localAppData, "DSE", ReleaseFolder);
        var finalDirectory = Path.Combine(releaseRoot, expectedHash[..12].ToLowerInvariant());
        var markerPath = Path.Combine(finalDirectory, ".payload.sha256");
        var executablePath = Path.Combine(finalDirectory, "DSEstimate.exe");

        if (IsCompleteInstall(markerPath, executablePath, expectedHash))
        {
            progress.Report(new InstallProgress(
                100,
                "Aplikacja jest już gotowa",
                "Pomijam ponowne wypakowywanie i uruchamiam DS Estimate."));
            return finalDirectory;
        }

        Directory.CreateDirectory(releaseRoot);
        var stagingDirectory = Path.Combine(releaseRoot, "tmp-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(stagingDirectory);

        try
        {
            progress.Report(new InstallProgress(
                2,
                "Wypakowywanie aplikacji…",
                "Docelowa krótka ścieżka: " + finalDirectory));
            using var payload = assembly.GetManifestResourceStream(PayloadResource)
                ?? throw new InvalidDataException("W launcherze nie znaleziono archiwum aplikacji.");
            using var archive = new ZipArchive(payload, ZipArchiveMode.Read, leaveOpen: false);
            var files = archive.Entries.Where(x => !string.IsNullOrEmpty(x.Name)).ToList();
            var reportEvery = Math.Max(1, files.Count / 200);
            var completed = 0;

            foreach (var entry in archive.Entries)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var targetPath = ResolveSafeTarget(stagingDirectory, entry.FullName);
                if (string.IsNullOrEmpty(entry.Name))
                {
                    Directory.CreateDirectory(targetPath);
                    continue;
                }

                Directory.CreateDirectory(Path.GetDirectoryName(targetPath)!);
                using (var input = entry.Open())
                using (var output = new FileStream(
                           targetPath,
                           FileMode.Create,
                           FileAccess.Write,
                           FileShare.None,
                           128 * 1024,
                           FileOptions.SequentialScan))
                {
                    input.CopyTo(output, 128 * 1024);
                }

                completed++;
                if (completed == 1 || completed == files.Count || completed % reportEvery == 0)
                {
                    progress.Report(new InstallProgress(
                        Math.Clamp(2 + (int)Math.Round(completed * 94d / Math.Max(1, files.Count)), 2, 96),
                        $"Wypakowywanie aplikacji: {completed:N0}/{files.Count:N0}",
                        entry.FullName));
                }
            }

            File.WriteAllText(
                Path.Combine(stagingDirectory, ".payload.sha256"),
                expectedHash + Environment.NewLine);
            if (!File.Exists(Path.Combine(stagingDirectory, "DSEstimate.exe")))
                throw new InvalidDataException("Archiwum nie zawiera DSEstimate.exe.");

            if (Directory.Exists(finalDirectory))
                Directory.Delete(finalDirectory, recursive: true);
            Directory.Move(stagingDirectory, finalDirectory);
            progress.Report(new InstallProgress(98, "Sprawdzanie instalacji…", finalDirectory));
            return finalDirectory;
        }
        catch
        {
            TryDeleteDirectory(stagingDirectory);
            throw;
        }
    }

    private static string ResolveSafeTarget(string root, string archivePath)
    {
        var fullRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        var relative = archivePath.Replace('/', Path.DirectorySeparatorChar);
        var target = Path.GetFullPath(Path.Combine(fullRoot, relative));
        if (!target.StartsWith(fullRoot, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Archiwum zawiera niebezpieczną ścieżkę: " + archivePath);
        return target;
    }

    private static string ReadExpectedHash(Assembly assembly)
    {
        using var stream = assembly.GetManifestResourceStream(HashResource)
            ?? throw new InvalidDataException("W launcherze nie znaleziono sumy SHA-256.");
        using var reader = new StreamReader(stream);
        var firstToken = reader.ReadToEnd()
            .Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries)
            .FirstOrDefault()
            ?.Trim()
            .ToUpperInvariant();
        if (firstToken is null || firstToken.Length != 64 || firstToken.Any(x => !Uri.IsHexDigit(x)))
            throw new InvalidDataException("Nieprawidłowa suma SHA-256 payloadu.");
        return firstToken;
    }

    private static bool IsCompleteInstall(string markerPath, string executablePath, string expectedHash)
    {
        try
        {
            return File.Exists(executablePath) &&
                   File.Exists(markerPath) &&
                   string.Equals(File.ReadAllText(markerPath).Trim(), expectedHash, StringComparison.OrdinalIgnoreCase);
        }
        catch
        {
            return false;
        }
    }

    private static void TryDeleteDirectory(string path)
    {
        try
        {
            if (Directory.Exists(path))
                Directory.Delete(path, recursive: true);
        }
        catch
        {
            // Katalog tymczasowy ma unikalną nazwę i zostanie pominięty przy kolejnym uruchomieniu.
        }
    }

    private void RequestCancellation()
    {
        if (!_working)
        {
            Close();
            return;
        }
        _status.Text = "Anulowanie…";
        _cancel.Enabled = false;
        _cancellation.Cancel();
    }

    private void OnFormClosing(object? sender, FormClosingEventArgs e)
    {
        if (!_working)
            return;
        e.Cancel = true;
        RequestCancellation();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
            _cancellation.Dispose();
        base.Dispose(disposing);
    }
}
