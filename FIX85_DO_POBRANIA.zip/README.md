# DS Estimate 2.0 — FIX85 engine integration source package

This ZIP contains the unmodified Python document engine from the user's FIX85 source archive, and a bridge for the Tauri 2 project's `desktop-tauri/cad_backend` directory. Copy the `desktop-tauri` directory into the repository root. The bridge was also committed to GitHub, but the large original FIX85 engine is supplied in this ZIP (not yet committed to GitHub).

Use: `python desktop-tauri/cad_backend/legacy_document_bridge.py drawing.pdf`

The original FIX85 engine supports PDF text extraction (PyMuPDF/pypdf), page-specific evidence, raster OCR via Tesseract/pytesseract and technical signals such as weld type, throat, process, side count, intermittent welds, coating and tolerances. Dependencies must be installed and the Tesseract binary and language data provided separately. This is source integration, not yet wired to a packaged Tauri Windows executable. Do not mark graphical weld symbols or automatic STEP joint matching as verified.

Validation performed: Python syntax compilation; direct `result_from_text` regression using a welding technical note (process 135, FILLET, a6, two-sided). End-to-end real PDF/OCR requires further validation with a drawing and a packaged Windows runtime.
