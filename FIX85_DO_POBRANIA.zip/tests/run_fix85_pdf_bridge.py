import sys, pathlib, tempfile, json, subprocess
from reportlab.pdfgen import canvas
root=pathlib.Path(__file__).parent
bridge=root/'desktop-tauri/cad_backend/legacy_document_bridge.py'
with tempfile.TemporaryDirectory() as td:
 p=pathlib.Path(td)/'test.pdf';c=canvas.Canvas(str(p));c.drawString(70,760,'Material S355J2+N');c.drawString(70,730,'Welding process 135 MAG');c.drawString(70,700,'FILLET WELD a6 BOTH SIDES');c.save()
 r=subprocess.run([sys.executable,str(bridge),str(p)],capture_output=True,text=True,timeout=120)
 assert r.returncode==0,r.stderr
 d=json.loads(r.stdout)['result']
 assert d['materialHint']=='S355J2+N'
 assert d['weldProcessCode']=='135'
 assert d['weldTypeHint']=='FILLET'
 assert d['weldSizeMm']==6
 assert d['weldSideCount']==2
 assert d['weldExplicitLengthMm'] is None
 print('PASS 6/6 real PDF extraction checks')
