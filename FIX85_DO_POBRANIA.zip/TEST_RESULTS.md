# FIX85 integration validation
- Verified original FIX85 analyze_document.py byte identical to prior integration archive.
- Real PDF generated with reportlab and processed through subprocess bridge: PASS 6/6.
- Original engine requires pypdf/PyMuPDF and optional Tesseract/Pillow.
- Graphical ISO2553 symbol detection and STEP mapping are NOT supported by this test.
- Bridge is source-level only; Windows packaging not yet validated.
