"""Run the original FIX85 document analysis engine without rewriting its OCR logic."""
import json
import subprocess
import sys
from pathlib import Path

def analyze_document(path, timeout=180):
    engine=Path(__file__).resolve().parent/'legacy_fix85'/'analyze_document.py'
    if not engine.is_file(): raise FileNotFoundError('FIX85 document engine not bundled')
    source=Path(path).resolve()
    if not source.is_file(): raise FileNotFoundError(str(source))
    if source.suffix.lower() not in {'.pdf','.png','.jpg','.jpeg','.tif','.tiff','.bmp'}: raise ValueError('Unsupported drawing format')
    p=subprocess.run([sys.executable,str(engine),str(source)],capture_output=True,text=True,timeout=timeout)
    if p.returncode: raise RuntimeError(f'FIX85 exited {p.returncode}: {p.stderr[-1500:]}')
    return {'engine':'FIX85','source':str(source),'result':json.loads(p.stdout)}

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('file');args=p.parse_args()
    print(json.dumps(analyze_document(args.file),ensure_ascii=False))
